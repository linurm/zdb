package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0211_org_mortbay_jetty_client_HttpConnection {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(ACC_PUBLIC,"Lorg/mortbay/jetty/client/HttpConnection;","Ljava/lang/Object;",new String[]{ "Lorg/mortbay/io/Connection;"});
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("HttpConnection.java");
        if(cv!=null){
            DexAnnotationVisitor av00 = cv.visitAnnotation("Ldalvik/annotation/MemberClasses;", Visibility.SYSTEM);
            if(av00 != null) {
                {
                    DexAnnotationVisitor av01 = av00.visitArray("value");
                    if(av01 != null) {
                        av01.visit(null, new DexType("Lorg/mortbay/jetty/client/HttpConnection$Handler;"));
                        av01.visitEnd();
                    }
                }
                av00.visitEnd();
            }
        }
        f000__connectionHeader(cv);
        f001__destination(cv);
        f002__endp(cv);
        f003__exchange(cv);
        f004__generator(cv);
        f005__http11(cv);
        f006__last(cv);
        f007__message(cv);
        f008__parser(cv);
        f009__pipeline(cv);
        f010__requestComplete(cv);
        f011__requestContentChunk(cv);
        f012__reserved(cv);
        f013__throwable(cv);
        f014__timeout(cv);
        m000__init_(cv);
        m001_commitRequest(cv);
        m002_shouldClose(cv);
        m003_close(cv);
        m004_dump(cv);
        m005_getDestination(cv);
        m006_getEndPoint(cv);
        m007_getLast(cv);
        m008_handle(cv);
        m009_isIdle(cv);
        m010_isReserved(cv);
        m011_reset(cv);
        m012_send(cv);
        m013_setDestination(cv);
        m014_setLast(cv);
        m015_setReserved(cv);
        m016_toDetailString(cv);
        m017_toString(cv);
    }
    public static void f000__connectionHeader(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(0, new Field("Lorg/mortbay/jetty/client/HttpConnection;","_connectionHeader","Lorg/mortbay/io/Buffer;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f001__destination(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(0, new Field("Lorg/mortbay/jetty/client/HttpConnection;","_destination","Lorg/mortbay/jetty/client/HttpDestination;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f002__endp(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(0, new Field("Lorg/mortbay/jetty/client/HttpConnection;","_endp","Lorg/mortbay/io/EndPoint;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f003__exchange(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_VOLATILE, new Field("Lorg/mortbay/jetty/client/HttpConnection;","_exchange","Lorg/mortbay/jetty/client/HttpExchange;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f004__generator(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(0, new Field("Lorg/mortbay/jetty/client/HttpConnection;","_generator","Lorg/mortbay/jetty/HttpGenerator;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f005__http11(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(0, new Field("Lorg/mortbay/jetty/client/HttpConnection;","_http11","Z"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f006__last(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(0, new Field("Lorg/mortbay/jetty/client/HttpConnection;","_last","J"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f007__message(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC, new Field("Lorg/mortbay/jetty/client/HttpConnection;","_message","Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f008__parser(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(0, new Field("Lorg/mortbay/jetty/client/HttpConnection;","_parser","Lorg/mortbay/jetty/HttpParser;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f009__pipeline(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(0, new Field("Lorg/mortbay/jetty/client/HttpConnection;","_pipeline","Lorg/mortbay/jetty/client/HttpExchange;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f010__requestComplete(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(0, new Field("Lorg/mortbay/jetty/client/HttpConnection;","_requestComplete","Z"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f011__requestContentChunk(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(0, new Field("Lorg/mortbay/jetty/client/HttpConnection;","_requestContentChunk","Lorg/mortbay/io/Buffer;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f012__reserved(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC, new Field("Lorg/mortbay/jetty/client/HttpConnection;","_reserved","Z"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f013__throwable(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC, new Field("Lorg/mortbay/jetty/client/HttpConnection;","_throwable","Ljava/lang/Throwable;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f014__timeout(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(0, new Field("Lorg/mortbay/jetty/client/HttpConnection;","_timeout","Lorg/mortbay/thread/Timeout$Task;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void m000__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_CONSTRUCTOR, new Method("Lorg/mortbay/jetty/client/HttpConnection;","<init>",new String[]{ "Lorg/mortbay/io/Buffers;","Lorg/mortbay/io/EndPoint;","I","I"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(11);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"buffers");
                ddv.visitParameterName(1,"endp");
                ddv.visitParameterName(2,"hbs");
                ddv.visitParameterName(3,"cbs");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(112,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(49,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(72,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(113,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(114,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(115,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(116,L6);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 6},new Method("Ljava/lang/Object;","<init>",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitFieldStmt(IPUT_BOOLEAN,0,6,new Field("Lorg/mortbay/jetty/client/HttpConnection;","_http11","Z"));
                code.visitLabel(L2);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Lorg/mortbay/jetty/client/HttpConnection$1;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,6},new Method("Lorg/mortbay/jetty/client/HttpConnection$1;","<init>",new String[]{ "Lorg/mortbay/jetty/client/HttpConnection;"},"V"));
                code.visitFieldStmt(IPUT_OBJECT,0,6,new Field("Lorg/mortbay/jetty/client/HttpConnection;","_timeout","Lorg/mortbay/thread/Timeout$Task;"));
                code.visitLabel(L3);
                code.visitFieldStmt(IPUT_OBJECT,8,6,new Field("Lorg/mortbay/jetty/client/HttpConnection;","_endp","Lorg/mortbay/io/EndPoint;"));
                code.visitLabel(L4);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Lorg/mortbay/jetty/HttpGenerator;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,7,8,9,10},new Method("Lorg/mortbay/jetty/HttpGenerator;","<init>",new String[]{ "Lorg/mortbay/io/Buffers;","Lorg/mortbay/io/EndPoint;","I","I"},"V"));
                code.visitFieldStmt(IPUT_OBJECT,0,6,new Field("Lorg/mortbay/jetty/client/HttpConnection;","_generator","Lorg/mortbay/jetty/HttpGenerator;"));
                code.visitLabel(L5);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Lorg/mortbay/jetty/HttpParser;");
                code.visitTypeStmt(NEW_INSTANCE,3,-1,"Lorg/mortbay/jetty/client/HttpConnection$Handler;");
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 3,6,1},new Method("Lorg/mortbay/jetty/client/HttpConnection$Handler;","<init>",new String[]{ "Lorg/mortbay/jetty/client/HttpConnection;","Lorg/mortbay/jetty/client/HttpConnection$1;"},"V"));
                code.visitStmt2R(MOVE_OBJECT,1,7);
                code.visitStmt2R(MOVE_OBJECT,2,8);
                code.visitStmt2R(MOVE,4,9);
                code.visitStmt2R(MOVE,5,10);
                code.visitMethodStmt(INVOKE_DIRECT_RANGE,new int[]{ 0,1,2,3,4,5},new Method("Lorg/mortbay/jetty/HttpParser;","<init>",new String[]{ "Lorg/mortbay/io/Buffers;","Lorg/mortbay/io/EndPoint;","Lorg/mortbay/jetty/HttpParser$EventHandler;","I","I"},"V"));
                code.visitFieldStmt(IPUT_OBJECT,0,6,new Field("Lorg/mortbay/jetty/client/HttpConnection;","_parser","Lorg/mortbay/jetty/HttpParser;"));
                code.visitLabel(L6);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001_commitRequest(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PRIVATE, new Method("Lorg/mortbay/jetty/client/HttpConnection;","commitRequest",new String[]{ },"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(10);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexLabel L3=new DexLabel();
                DexLabel L4=new DexLabel();
                code.visitTryCatch(L3,L4,new DexLabel[]{L2},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L5=new DexLabel();
                ddv.visitPrologue(L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(388,L6);
                ddv.visitLineNumber(390,L0);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(391,L7);
                ddv.visitLineNumber(447,L2);
                ddv.visitLineNumber(393,L3);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(394,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(396,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(397,L10);
                ddv.visitStartLocal(4,L10,"uri","Ljava/lang/String;",null);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(400,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(402,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(403,L13);
                ddv.visitStartLocal(0,L13,"auth","Lorg/mortbay/jetty/client/security/Authorization;",null);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(404,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(407,L15);
                ddv.visitEndLocal(0,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(409,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(411,L17);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(412,L18);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(415,L19);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(417,L20);
                DexLabel L21=new DexLabel();
                ddv.visitLineNumber(418,L21);
                DexLabel L22=new DexLabel();
                ddv.visitLineNumber(419,L22);
                DexLabel L23=new DexLabel();
                ddv.visitLineNumber(446,L23);
                DexLabel L24=new DexLabel();
                ddv.visitLineNumber(447,L24);
                DexLabel L25=new DexLabel();
                ddv.visitLineNumber(448,L25);
                DexLabel L26=new DexLabel();
                ddv.visitLineNumber(400,L26);
                DexLabel L27=new DexLabel();
                ddv.visitLineNumber(421,L27);
                DexLabel L28=new DexLabel();
                ddv.visitLineNumber(423,L28);
                DexLabel L29=new DexLabel();
                ddv.visitLineNumber(424,L29);
                DexLabel L30=new DexLabel();
                ddv.visitLineNumber(425,L30);
                ddv.visitStartLocal(1,L30,"available","I",null);
                DexLabel L31=new DexLabel();
                ddv.visitLineNumber(430,L31);
                DexLabel L32=new DexLabel();
                ddv.visitLineNumber(431,L32);
                ddv.visitStartLocal(2,L32,"buf","[B",null);
                DexLabel L33=new DexLabel();
                ddv.visitLineNumber(432,L33);
                ddv.visitStartLocal(3,L33,"length","I",null);
                DexLabel L34=new DexLabel();
                ddv.visitLineNumber(437,L34);
                ddv.visitEndLocal(1,L34);
                ddv.visitEndLocal(2,L34);
                ddv.visitEndLocal(3,L34);
                DexLabel L35=new DexLabel();
                ddv.visitLineNumber(443,L35);
                code.visitLabel(L5);
                code.visitConstStmt(CONST_STRING,5,"Content-Length");
                code.visitLabel(L6);
                code.visitStmt1R(MONITOR_ENTER,9);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,5,9,new Field("Lorg/mortbay/jetty/client/HttpConnection;","_exchange","Lorg/mortbay/jetty/client/HttpExchange;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Lorg/mortbay/jetty/client/HttpExchange;","getStatus",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,5);
                code.visitConstStmt(CONST_4,6, Integer.valueOf(2)); // int: 0x00000002  float:0.000000
                code.visitJumpStmt(IF_EQ,5,6,L3);
                code.visitLabel(L7);
                code.visitTypeStmt(NEW_INSTANCE,5,-1,"Ljava/lang/IllegalStateException;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 5},new Method("Ljava/lang/IllegalStateException;","<init>",new String[]{ },"V"));
                code.visitStmt1R(THROW,5);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,5);
                code.visitStmt1R(MONITOR_EXIT,9);
                code.visitLabel(L1);
                code.visitStmt1R(THROW,5);
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,5,9,new Field("Lorg/mortbay/jetty/client/HttpConnection;","_exchange","Lorg/mortbay/jetty/client/HttpExchange;"));
                code.visitConstStmt(CONST_4,6, Integer.valueOf(3)); // int: 0x00000003  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,6},new Method("Lorg/mortbay/jetty/client/HttpExchange;","setStatus",new String[]{ "I"},"V"));
                code.visitLabel(L8);
                code.visitFieldStmt(IGET_OBJECT,5,9,new Field("Lorg/mortbay/jetty/client/HttpConnection;","_generator","Lorg/mortbay/jetty/HttpGenerator;"));
                code.visitFieldStmt(IGET_OBJECT,6,9,new Field("Lorg/mortbay/jetty/client/HttpConnection;","_exchange","Lorg/mortbay/jetty/client/HttpExchange;"));
                code.visitFieldStmt(IGET,6,6,new Field("Lorg/mortbay/jetty/client/HttpExchange;","_version","I"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,6},new Method("Lorg/mortbay/jetty/HttpGenerator;","setVersion",new String[]{ "I"},"V"));
                code.visitLabel(L9);
                code.visitFieldStmt(IGET_OBJECT,5,9,new Field("Lorg/mortbay/jetty/client/HttpConnection;","_exchange","Lorg/mortbay/jetty/client/HttpExchange;"));
                code.visitFieldStmt(IGET_OBJECT,4,5,new Field("Lorg/mortbay/jetty/client/HttpExchange;","_uri","Ljava/lang/String;"));
                code.visitLabel(L10);
                code.visitFieldStmt(IGET_OBJECT,5,9,new Field("Lorg/mortbay/jetty/client/HttpConnection;","_destination","Lorg/mortbay/jetty/client/HttpDestination;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Lorg/mortbay/jetty/client/HttpDestination;","isProxied",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,5);
                code.visitJumpStmt(IF_EQZ,5,-1,L15);
                code.visitConstStmt(CONST_STRING,5,"/");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,5},new Method("Ljava/lang/String;","startsWith",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,5);
                code.visitJumpStmt(IF_EQZ,5,-1,L15);
                code.visitLabel(L11);
                code.visitTypeStmt(NEW_INSTANCE,5,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 5},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitFieldStmt(IGET_OBJECT,6,9,new Field("Lorg/mortbay/jetty/client/HttpConnection;","_destination","Lorg/mortbay/jetty/client/HttpDestination;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Lorg/mortbay/jetty/client/HttpDestination;","isSecure",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,6);
                code.visitJumpStmt(IF_EQZ,6,-1,L26);
                code.visitConstStmt(CONST_STRING,6,"https");
                DexLabel L36=new DexLabel();
                code.visitLabel(L36);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,6},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitConstStmt(CONST_STRING,6,"://");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,6},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitFieldStmt(IGET_OBJECT,6,9,new Field("Lorg/mortbay/jetty/client/HttpConnection;","_destination","Lorg/mortbay/jetty/client/HttpDestination;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Lorg/mortbay/jetty/client/HttpDestination;","getAddress",new String[]{ },"Lorg/mortbay/jetty/client/Address;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Lorg/mortbay/jetty/client/Address;","getHost",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,6},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitConstStmt(CONST_STRING,6,":");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,6},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitFieldStmt(IGET_OBJECT,6,9,new Field("Lorg/mortbay/jetty/client/HttpConnection;","_destination","Lorg/mortbay/jetty/client/HttpDestination;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Lorg/mortbay/jetty/client/HttpDestination;","getAddress",new String[]{ },"Lorg/mortbay/jetty/client/Address;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Lorg/mortbay/jetty/client/Address;","getPort",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,6},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "I"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,4},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitLabel(L12);
                code.visitFieldStmt(IGET_OBJECT,5,9,new Field("Lorg/mortbay/jetty/client/HttpConnection;","_destination","Lorg/mortbay/jetty/client/HttpDestination;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Lorg/mortbay/jetty/client/HttpDestination;","getProxyAuthentication",new String[]{ },"Lorg/mortbay/jetty/client/security/Authorization;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L13);
                code.visitJumpStmt(IF_EQZ,0,-1,L15);
                code.visitLabel(L14);
                code.visitFieldStmt(IGET_OBJECT,5,9,new Field("Lorg/mortbay/jetty/client/HttpConnection;","_exchange","Lorg/mortbay/jetty/client/HttpExchange;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,5},new Method("Lorg/mortbay/jetty/client/security/Authorization;","setCredentials",new String[]{ "Lorg/mortbay/jetty/client/HttpExchange;"},"V"));
                code.visitLabel(L15);
                code.visitFieldStmt(IGET_OBJECT,5,9,new Field("Lorg/mortbay/jetty/client/HttpConnection;","_generator","Lorg/mortbay/jetty/HttpGenerator;"));
                code.visitFieldStmt(IGET_OBJECT,6,9,new Field("Lorg/mortbay/jetty/client/HttpConnection;","_exchange","Lorg/mortbay/jetty/client/HttpExchange;"));
                code.visitFieldStmt(IGET_OBJECT,6,6,new Field("Lorg/mortbay/jetty/client/HttpExchange;","_method","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,6,4},new Method("Lorg/mortbay/jetty/HttpGenerator;","setRequest",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"V"));
                code.visitLabel(L16);
                code.visitFieldStmt(IGET_OBJECT,5,9,new Field("Lorg/mortbay/jetty/client/HttpConnection;","_exchange","Lorg/mortbay/jetty/client/HttpExchange;"));
                code.visitFieldStmt(IGET,5,5,new Field("Lorg/mortbay/jetty/client/HttpExchange;","_version","I"));
                code.visitConstStmt(CONST_16,6, Integer.valueOf(11)); // int: 0x0000000b  float:0.000000
                code.visitJumpStmt(IF_LT,5,6,L19);
                code.visitLabel(L17);
                code.visitFieldStmt(IGET_OBJECT,5,9,new Field("Lorg/mortbay/jetty/client/HttpConnection;","_exchange","Lorg/mortbay/jetty/client/HttpExchange;"));
                code.visitFieldStmt(IGET_OBJECT,5,5,new Field("Lorg/mortbay/jetty/client/HttpExchange;","_requestFields","Lorg/mortbay/jetty/HttpFields;"));
                code.visitFieldStmt(SGET_OBJECT,6,-1,new Field("Lorg/mortbay/jetty/HttpHeaders;","HOST_BUFFER","Lorg/mortbay/io/Buffer;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,6},new Method("Lorg/mortbay/jetty/HttpFields;","containsKey",new String[]{ "Lorg/mortbay/io/Buffer;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,5);
                code.visitJumpStmt(IF_NEZ,5,-1,L19);
                code.visitLabel(L18);
                code.visitFieldStmt(IGET_OBJECT,5,9,new Field("Lorg/mortbay/jetty/client/HttpConnection;","_exchange","Lorg/mortbay/jetty/client/HttpExchange;"));
                code.visitFieldStmt(IGET_OBJECT,5,5,new Field("Lorg/mortbay/jetty/client/HttpExchange;","_requestFields","Lorg/mortbay/jetty/HttpFields;"));
                code.visitFieldStmt(SGET_OBJECT,6,-1,new Field("Lorg/mortbay/jetty/HttpHeaders;","HOST_BUFFER","Lorg/mortbay/io/Buffer;"));
                code.visitFieldStmt(IGET_OBJECT,7,9,new Field("Lorg/mortbay/jetty/client/HttpConnection;","_destination","Lorg/mortbay/jetty/client/HttpDestination;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7},new Method("Lorg/mortbay/jetty/client/HttpDestination;","getHostHeader",new String[]{ },"Lorg/mortbay/io/Buffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,6,7},new Method("Lorg/mortbay/jetty/HttpFields;","add",new String[]{ "Lorg/mortbay/io/Buffer;","Lorg/mortbay/io/Buffer;"},"V"));
                code.visitLabel(L19);
                code.visitFieldStmt(IGET_OBJECT,5,9,new Field("Lorg/mortbay/jetty/client/HttpConnection;","_exchange","Lorg/mortbay/jetty/client/HttpExchange;"));
                code.visitFieldStmt(IGET_OBJECT,5,5,new Field("Lorg/mortbay/jetty/client/HttpExchange;","_requestContent","Lorg/mortbay/io/Buffer;"));
                code.visitJumpStmt(IF_EQZ,5,-1,L27);
                code.visitLabel(L20);
                code.visitFieldStmt(IGET_OBJECT,5,9,new Field("Lorg/mortbay/jetty/client/HttpConnection;","_exchange","Lorg/mortbay/jetty/client/HttpExchange;"));
                code.visitFieldStmt(IGET_OBJECT,5,5,new Field("Lorg/mortbay/jetty/client/HttpExchange;","_requestFields","Lorg/mortbay/jetty/HttpFields;"));
                code.visitConstStmt(CONST_STRING,6,"Content-Length");
                code.visitFieldStmt(IGET_OBJECT,7,9,new Field("Lorg/mortbay/jetty/client/HttpConnection;","_exchange","Lorg/mortbay/jetty/client/HttpExchange;"));
                code.visitFieldStmt(IGET_OBJECT,7,7,new Field("Lorg/mortbay/jetty/client/HttpExchange;","_requestContent","Lorg/mortbay/io/Buffer;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 7},new Method("Lorg/mortbay/io/Buffer;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,7);
                code.visitStmt2R(INT_TO_LONG,7,7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,6,7,8},new Method("Lorg/mortbay/jetty/HttpFields;","putLongField",new String[]{ "Ljava/lang/String;","J"},"V"));
                code.visitLabel(L21);
                code.visitFieldStmt(IGET_OBJECT,5,9,new Field("Lorg/mortbay/jetty/client/HttpConnection;","_generator","Lorg/mortbay/jetty/HttpGenerator;"));
                code.visitFieldStmt(IGET_OBJECT,6,9,new Field("Lorg/mortbay/jetty/client/HttpConnection;","_exchange","Lorg/mortbay/jetty/client/HttpExchange;"));
                code.visitFieldStmt(IGET_OBJECT,6,6,new Field("Lorg/mortbay/jetty/client/HttpExchange;","_requestFields","Lorg/mortbay/jetty/HttpFields;"));
                code.visitConstStmt(CONST_4,7, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,6,7},new Method("Lorg/mortbay/jetty/HttpGenerator;","completeHeader",new String[]{ "Lorg/mortbay/jetty/HttpFields;","Z"},"V"));
                code.visitLabel(L22);
                code.visitFieldStmt(IGET_OBJECT,5,9,new Field("Lorg/mortbay/jetty/client/HttpConnection;","_generator","Lorg/mortbay/jetty/HttpGenerator;"));
                code.visitFieldStmt(IGET_OBJECT,6,9,new Field("Lorg/mortbay/jetty/client/HttpConnection;","_exchange","Lorg/mortbay/jetty/client/HttpExchange;"));
                code.visitFieldStmt(IGET_OBJECT,6,6,new Field("Lorg/mortbay/jetty/client/HttpExchange;","_requestContent","Lorg/mortbay/io/Buffer;"));
                code.visitConstStmt(CONST_4,7, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,6,7},new Method("Lorg/mortbay/jetty/HttpGenerator;","addContent",new String[]{ "Lorg/mortbay/io/Buffer;","Z"},"V"));
                code.visitLabel(L23);
                code.visitFieldStmt(IGET_OBJECT,5,9,new Field("Lorg/mortbay/jetty/client/HttpConnection;","_exchange","Lorg/mortbay/jetty/client/HttpExchange;"));
                code.visitConstStmt(CONST_4,6, Integer.valueOf(4)); // int: 0x00000004  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,6},new Method("Lorg/mortbay/jetty/client/HttpExchange;","setStatus",new String[]{ "I"},"V"));
                code.visitLabel(L24);
                code.visitStmt1R(MONITOR_EXIT,9);
                code.visitLabel(L25);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L26);
                code.visitConstStmt(CONST_STRING,6,"http");
                code.visitJumpStmt(GOTO_16,-1,-1,L36);
                code.visitLabel(L27);
                code.visitFieldStmt(IGET_OBJECT,5,9,new Field("Lorg/mortbay/jetty/client/HttpConnection;","_exchange","Lorg/mortbay/jetty/client/HttpExchange;"));
                code.visitFieldStmt(IGET_OBJECT,5,5,new Field("Lorg/mortbay/jetty/client/HttpExchange;","_requestContentSource","Ljava/io/InputStream;"));
                code.visitJumpStmt(IF_EQZ,5,-1,L34);
                code.visitLabel(L28);
                code.visitFieldStmt(IGET_OBJECT,5,9,new Field("Lorg/mortbay/jetty/client/HttpConnection;","_generator","Lorg/mortbay/jetty/HttpGenerator;"));
                code.visitFieldStmt(IGET_OBJECT,6,9,new Field("Lorg/mortbay/jetty/client/HttpConnection;","_exchange","Lorg/mortbay/jetty/client/HttpExchange;"));
                code.visitFieldStmt(IGET_OBJECT,6,6,new Field("Lorg/mortbay/jetty/client/HttpExchange;","_requestFields","Lorg/mortbay/jetty/HttpFields;"));
                code.visitConstStmt(CONST_4,7, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,6,7},new Method("Lorg/mortbay/jetty/HttpGenerator;","completeHeader",new String[]{ "Lorg/mortbay/jetty/HttpFields;","Z"},"V"));
                code.visitLabel(L29);
                code.visitFieldStmt(IGET_OBJECT,5,9,new Field("Lorg/mortbay/jetty/client/HttpConnection;","_exchange","Lorg/mortbay/jetty/client/HttpExchange;"));
                code.visitFieldStmt(IGET_OBJECT,5,5,new Field("Lorg/mortbay/jetty/client/HttpExchange;","_requestContentSource","Ljava/io/InputStream;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Ljava/io/InputStream;","available",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitLabel(L30);
                code.visitJumpStmt(IF_LEZ,1,-1,L23);
                code.visitLabel(L31);
                code.visitTypeStmt(NEW_ARRAY,2,1,"[B");
                code.visitLabel(L32);
                code.visitFieldStmt(IGET_OBJECT,5,9,new Field("Lorg/mortbay/jetty/client/HttpConnection;","_exchange","Lorg/mortbay/jetty/client/HttpExchange;"));
                code.visitFieldStmt(IGET_OBJECT,5,5,new Field("Lorg/mortbay/jetty/client/HttpExchange;","_requestContentSource","Ljava/io/InputStream;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,2},new Method("Ljava/io/InputStream;","read",new String[]{ "[B"},"I"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitLabel(L33);
                code.visitFieldStmt(IGET_OBJECT,5,9,new Field("Lorg/mortbay/jetty/client/HttpConnection;","_generator","Lorg/mortbay/jetty/HttpGenerator;"));
                code.visitTypeStmt(NEW_INSTANCE,6,-1,"Lorg/mortbay/io/ByteArrayBuffer;");
                code.visitConstStmt(CONST_4,7, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 6,2,7,3},new Method("Lorg/mortbay/io/ByteArrayBuffer;","<init>",new String[]{ "[B","I","I"},"V"));
                code.visitConstStmt(CONST_4,7, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,6,7},new Method("Lorg/mortbay/jetty/HttpGenerator;","addContent",new String[]{ "Lorg/mortbay/io/Buffer;","Z"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L23);
                code.visitLabel(L34);
                code.visitFieldStmt(IGET_OBJECT,5,9,new Field("Lorg/mortbay/jetty/client/HttpConnection;","_exchange","Lorg/mortbay/jetty/client/HttpExchange;"));
                code.visitFieldStmt(IGET_OBJECT,5,5,new Field("Lorg/mortbay/jetty/client/HttpExchange;","_requestFields","Lorg/mortbay/jetty/HttpFields;"));
                code.visitConstStmt(CONST_STRING,6,"Content-Length");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,6},new Method("Lorg/mortbay/jetty/HttpFields;","remove",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L35);
                code.visitFieldStmt(IGET_OBJECT,5,9,new Field("Lorg/mortbay/jetty/client/HttpConnection;","_generator","Lorg/mortbay/jetty/HttpGenerator;"));
                code.visitFieldStmt(IGET_OBJECT,6,9,new Field("Lorg/mortbay/jetty/client/HttpConnection;","_exchange","Lorg/mortbay/jetty/client/HttpExchange;"));
                code.visitFieldStmt(IGET_OBJECT,6,6,new Field("Lorg/mortbay/jetty/client/HttpExchange;","_requestFields","Lorg/mortbay/jetty/HttpFields;"));
                code.visitConstStmt(CONST_4,7, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,6,7},new Method("Lorg/mortbay/jetty/HttpGenerator;","completeHeader",new String[]{ "Lorg/mortbay/jetty/HttpFields;","Z"},"V"));
                code.visitLabel(L4);
                code.visitJumpStmt(GOTO,-1,-1,L23);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m002_shouldClose(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PRIVATE, new Method("Lorg/mortbay/jetty/client/HttpConnection;","shouldClose",new String[]{ },"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(463,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(465,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(470,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(467,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(468,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(470,L6);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,0,4,new Field("Lorg/mortbay/jetty/client/HttpConnection;","_connectionHeader","Lorg/mortbay/io/Buffer;"));
                code.visitJumpStmt(IF_EQZ,0,-1,L6);
                code.visitLabel(L2);
                code.visitFieldStmt(SGET_OBJECT,0,-1,new Field("Lorg/mortbay/jetty/HttpHeaderValues;","CLOSE_BUFFER","Lorg/mortbay/io/Buffer;"));
                code.visitFieldStmt(IGET_OBJECT,1,4,new Field("Lorg/mortbay/jetty/client/HttpConnection;","_connectionHeader","Lorg/mortbay/io/Buffer;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/Object;","equals",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_EQZ,0,-1,L4);
                code.visitStmt2R(MOVE,0,3);
                code.visitLabel(L3);
                code.visitStmt1R(RETURN,0);
                code.visitLabel(L4);
                code.visitFieldStmt(SGET_OBJECT,0,-1,new Field("Lorg/mortbay/jetty/HttpHeaderValues;","KEEP_ALIVE_BUFFER","Lorg/mortbay/io/Buffer;"));
                code.visitFieldStmt(IGET_OBJECT,1,4,new Field("Lorg/mortbay/jetty/client/HttpConnection;","_connectionHeader","Lorg/mortbay/io/Buffer;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/Object;","equals",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_EQZ,0,-1,L6);
                code.visitStmt2R(MOVE,0,2);
                code.visitLabel(L5);
                code.visitJumpStmt(GOTO,-1,-1,L3);
                code.visitLabel(L6);
                code.visitFieldStmt(IGET_BOOLEAN,0,4,new Field("Lorg/mortbay/jetty/client/HttpConnection;","_http11","Z"));
                DexLabel L7=new DexLabel();
                code.visitJumpStmt(IF_NEZ,0,-1,L7);
                code.visitStmt2R(MOVE,0,3);
                code.visitJumpStmt(GOTO,-1,-1,L3);
                code.visitLabel(L7);
                code.visitStmt2R(MOVE,0,2);
                code.visitJumpStmt(GOTO,-1,-1,L3);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m003_close(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/client/HttpConnection;","close",new String[]{ },"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(571,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(572,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/client/HttpConnection;","_endp","Lorg/mortbay/io/EndPoint;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0},new Method("Lorg/mortbay/io/EndPoint;","close",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m004_dump(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/client/HttpConnection;","dump",new String[]{ },"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(64,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(65,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(66,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(67,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(68,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(69,L6);
                DexLabel L7=new DexLabel();
                ddv.visitEndLocal(4,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(70,L8);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_STRING,3," ");
                code.visitLabel(L1);
                code.visitFieldStmt(SGET_OBJECT,0,-1,new Field("Ljava/lang/System;","err","Ljava/io/PrintStream;"));
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,2,"endp=");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitFieldStmt(IGET_OBJECT,2,4,new Field("Lorg/mortbay/jetty/client/HttpConnection;","_endp","Lorg/mortbay/io/EndPoint;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitConstStmt(CONST_STRING,2," ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,3},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitFieldStmt(IGET_OBJECT,2,4,new Field("Lorg/mortbay/jetty/client/HttpConnection;","_endp","Lorg/mortbay/io/EndPoint;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 2},new Method("Lorg/mortbay/io/EndPoint;","isBufferingInput",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Z"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitConstStmt(CONST_STRING,2," ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,3},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitFieldStmt(IGET_OBJECT,2,4,new Field("Lorg/mortbay/jetty/client/HttpConnection;","_endp","Lorg/mortbay/io/EndPoint;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 2},new Method("Lorg/mortbay/io/EndPoint;","isBufferingOutput",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Z"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/io/PrintStream;","println",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L2);
                code.visitFieldStmt(SGET_OBJECT,0,-1,new Field("Ljava/lang/System;","err","Ljava/io/PrintStream;"));
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,2,"generator=");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitFieldStmt(IGET_OBJECT,2,4,new Field("Lorg/mortbay/jetty/client/HttpConnection;","_generator","Lorg/mortbay/jetty/HttpGenerator;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/io/PrintStream;","println",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L3);
                code.visitFieldStmt(SGET_OBJECT,0,-1,new Field("Ljava/lang/System;","err","Ljava/io/PrintStream;"));
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,2,"parser=");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitFieldStmt(IGET_OBJECT,2,4,new Field("Lorg/mortbay/jetty/client/HttpConnection;","_parser","Lorg/mortbay/jetty/HttpParser;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/jetty/HttpParser;","getState",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "I"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitConstStmt(CONST_STRING,2," ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,3},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitFieldStmt(IGET_OBJECT,2,4,new Field("Lorg/mortbay/jetty/client/HttpConnection;","_parser","Lorg/mortbay/jetty/HttpParser;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/jetty/HttpParser;","isMoreInBuffer",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Z"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/io/PrintStream;","println",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L4);
                code.visitFieldStmt(SGET_OBJECT,0,-1,new Field("Ljava/lang/System;","err","Ljava/io/PrintStream;"));
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,2,"exchange=");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitFieldStmt(IGET_OBJECT,2,4,new Field("Lorg/mortbay/jetty/client/HttpConnection;","_exchange","Lorg/mortbay/jetty/client/HttpExchange;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/io/PrintStream;","println",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L5);
                code.visitFieldStmt(IGET_OBJECT,0,4,new Field("Lorg/mortbay/jetty/client/HttpConnection;","_endp","Lorg/mortbay/io/EndPoint;"));
                code.visitTypeStmt(INSTANCE_OF,0,0,"Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;");
                code.visitJumpStmt(IF_EQZ,0,-1,L8);
                code.visitLabel(L6);
                code.visitFieldStmt(IGET_OBJECT,4,4,new Field("Lorg/mortbay/jetty/client/HttpConnection;","_endp","Lorg/mortbay/io/EndPoint;"));
                code.visitLabel(L7);
                code.visitTypeStmt(CHECK_CAST,4,-1,"Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;","dump",new String[]{ },"V"));
                code.visitLabel(L8);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m005_getDestination(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/client/HttpConnection;","getDestination",new String[]{ },"Lorg/mortbay/jetty/client/HttpDestination;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(131,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/client/HttpConnection;","_destination","Lorg/mortbay/jetty/client/HttpDestination;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m006_getEndPoint(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/client/HttpConnection;","getEndPoint",new String[]{ },"Lorg/mortbay/io/EndPoint;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(382,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/client/HttpConnection;","_endp","Lorg/mortbay/io/EndPoint;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m007_getLast(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/client/HttpConnection;","getLast",new String[]{ },"J"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(555,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_WIDE,0,2,new Field("Lorg/mortbay/jetty/client/HttpConnection;","_last","J"));
                code.visitStmt1R(RETURN_WIDE,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m008_handle(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/client/HttpConnection;","handle",new String[]{ },"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(22);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexLabel L3=new DexLabel();
                DexLabel L4=new DexLabel();
                DexLabel L5=new DexLabel();
                code.visitTryCatch(L3,L4,new DexLabel[]{L5,L2},new String[]{ "Ljava/lang/InterruptedException;",null});
                DexLabel L6=new DexLabel();
                DexLabel L7=new DexLabel();
                code.visitTryCatch(L6,L7,new DexLabel[]{L2},new String[]{ null});
                DexLabel L8=new DexLabel();
                DexLabel L9=new DexLabel();
                code.visitTryCatch(L8,L9,new DexLabel[]{L2},new String[]{ null});
                DexLabel L10=new DexLabel();
                DexLabel L11=new DexLabel();
                DexLabel L12=new DexLabel();
                DexLabel L13=new DexLabel();
                code.visitTryCatch(L10,L11,new DexLabel[]{L12,L13},new String[]{ "Ljava/io/IOException;",null});
                DexLabel L14=new DexLabel();
                DexLabel L15=new DexLabel();
                DexLabel L16=new DexLabel();
                code.visitTryCatch(L14,L15,new DexLabel[]{L16},new String[]{ null});
                DexLabel L17=new DexLabel();
                DexLabel L18=new DexLabel();
                code.visitTryCatch(L17,L18,new DexLabel[]{L12,L13},new String[]{ "Ljava/io/IOException;",null});
                DexLabel L19=new DexLabel();
                DexLabel L20=new DexLabel();
                code.visitTryCatch(L18,L19,new DexLabel[]{L20},new String[]{ null});
                DexLabel L21=new DexLabel();
                DexLabel L22=new DexLabel();
                DexLabel L23=new DexLabel();
                code.visitTryCatch(L21,L22,new DexLabel[]{L23},new String[]{ null});
                DexLabel L24=new DexLabel();
                DexLabel L25=new DexLabel();
                DexLabel L26=new DexLabel();
                code.visitTryCatch(L24,L25,new DexLabel[]{L26},new String[]{ null});
                DexLabel L27=new DexLabel();
                DexLabel L28=new DexLabel();
                code.visitTryCatch(L27,L28,new DexLabel[]{L20},new String[]{ null});
                DexLabel L29=new DexLabel();
                code.visitTryCatch(L28,L29,new DexLabel[]{L12,L13},new String[]{ "Ljava/io/IOException;",null});
                DexLabel L30=new DexLabel();
                DexLabel L31=new DexLabel();
                code.visitTryCatch(L30,L31,new DexLabel[]{L20},new String[]{ null});
                code.visitTryCatch(L31,L12,new DexLabel[]{L12,L13},new String[]{ "Ljava/io/IOException;",null});
                DexLabel L32=new DexLabel();
                DexLabel L33=new DexLabel();
                DexLabel L34=new DexLabel();
                code.visitTryCatch(L32,L33,new DexLabel[]{L34},new String[]{ null});
                DexLabel L35=new DexLabel();
                DexLabel L36=new DexLabel();
                code.visitTryCatch(L33,L35,new DexLabel[]{L36},new String[]{ null});
                DexLabel L37=new DexLabel();
                code.visitTryCatch(L37,L34,new DexLabel[]{L34},new String[]{ null});
                DexLabel L38=new DexLabel();
                DexLabel L39=new DexLabel();
                DexLabel L40=new DexLabel();
                code.visitTryCatch(L38,L39,new DexLabel[]{L40},new String[]{ null});
                DexLabel L41=new DexLabel();
                DexLabel L42=new DexLabel();
                code.visitTryCatch(L41,L42,new DexLabel[]{L12,L13},new String[]{ "Ljava/io/IOException;",null});
                DexLabel L43=new DexLabel();
                DexLabel L44=new DexLabel();
                DexLabel L45=new DexLabel();
                code.visitTryCatch(L43,L44,new DexLabel[]{L45,L34},new String[]{ "Ljava/io/IOException;",null});
                DexLabel L46=new DexLabel();
                DexLabel L47=new DexLabel();
                DexLabel L48=new DexLabel();
                code.visitTryCatch(L46,L47,new DexLabel[]{L48},new String[]{ null});
                DexLabel L49=new DexLabel();
                DexLabel L50=new DexLabel();
                code.visitTryCatch(L49,L50,new DexLabel[]{L36},new String[]{ null});
                DexLabel L51=new DexLabel();
                code.visitTryCatch(L50,L51,new DexLabel[]{L34},new String[]{ null});
                DexLabel L52=new DexLabel();
                code.visitTryCatch(L51,L52,new DexLabel[]{L40},new String[]{ null});
                DexLabel L53=new DexLabel();
                DexLabel L54=new DexLabel();
                code.visitTryCatch(L53,L54,new DexLabel[]{L40},new String[]{ null});
                DexLabel L55=new DexLabel();
                DexLabel L56=new DexLabel();
                code.visitTryCatch(L55,L56,new DexLabel[]{L16},new String[]{ null});
                DexLabel L57=new DexLabel();
                DexLabel L58=new DexLabel();
                code.visitTryCatch(L57,L58,new DexLabel[]{L48},new String[]{ null});
                DexLabel L59=new DexLabel();
                DexLabel L60=new DexLabel();
                DexLabel L61=new DexLabel();
                code.visitTryCatch(L59,L60,new DexLabel[]{L61},new String[]{ null});
                DexLabel L62=new DexLabel();
                DexLabel L63=new DexLabel();
                code.visitTryCatch(L62,L63,new DexLabel[]{L61},new String[]{ null});
                DexLabel L64=new DexLabel();
                DexLabel L65=new DexLabel();
                code.visitTryCatch(L64,L65,new DexLabel[]{L26},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L66=new DexLabel();
                ddv.visitPrologue(L66);
                ddv.visitLineNumber(181,L66);
                DexLabel L67=new DexLabel();
                ddv.visitLineNumber(182,L67);
                ddv.visitStartLocal(15,L67,"no_progress","I",null);
                DexLabel L68=new DexLabel();
                ddv.visitLineNumber(184,L68);
                ddv.visitStartLocal(10,L68,"flushed","J",null);
                DexLabel L69=new DexLabel();
                ddv.visitLineNumber(185,L69);
                ddv.visitStartLocal(7,L69,"failed","Z",null);
                DexLabel L70=new DexLabel();
                ddv.visitLineNumber(187,L70);
                ddv.visitLineNumber(189,L0);
                DexLabel L71=new DexLabel();
                ddv.visitLineNumber(191,L71);
                ddv.visitLineNumber(195,L3);
                ddv.visitLineNumber(197,L5);
                ddv.visitLineNumber(199,L6);
                ddv.visitStartLocal(5,L6,"e","Ljava/lang/InterruptedException;",null);
                ddv.visitLineNumber(216,L2);
                ddv.visitEndLocal(5,L2);
                ddv.visitLineNumber(205,L8);
                DexLabel L72=new DexLabel();
                ddv.visitLineNumber(206,L72);
                DexLabel L73=new DexLabel();
                ddv.visitLineNumber(207,L73);
                DexLabel L74=new DexLabel();
                ddv.visitLineNumber(209,L74);
                DexLabel L75=new DexLabel();
                ddv.visitLineNumber(210,L75);
                DexLabel L76=new DexLabel();
                ddv.visitLineNumber(213,L76);
                DexLabel L77=new DexLabel();
                ddv.visitLineNumber(368,L77);
                DexLabel L78=new DexLabel();
                ddv.visitLineNumber(216,L78);
                ddv.visitLineNumber(217,L9);
                DexLabel L79=new DexLabel();
                ddv.visitLineNumber(219,L79);
                DexLabel L80=new DexLabel();
                ddv.visitLineNumber(220,L80);
                DexLabel L81=new DexLabel();
                ddv.visitLineNumber(225,L81);
                ddv.visitEndLocal(15,L81);
                ddv.visitStartLocal(16,L81,"no_progress","I",null);
                ddv.visitLineNumber(226,L10);
                ddv.visitStartLocal(13,L10,"io","J",null);
                DexLabel L82=new DexLabel();
                ddv.visitLineNumber(228,L82);
                DexLabel L83=new DexLabel();
                ddv.visitLineNumber(230,L83);
                DexLabel L84=new DexLabel();
                ddv.visitLineNumber(232,L84);
                DexLabel L85=new DexLabel();
                ddv.visitLineNumber(233,L85);
                DexLabel L86=new DexLabel();
                ddv.visitLineNumber(269,L86);
                DexLabel L87=new DexLabel();
                ddv.visitLineNumber(271,L87);
                DexLabel L88=new DexLabel();
                ddv.visitLineNumber(272,L88);
                ddv.visitStartLocal(8,L88,"filled","J",null);
                DexLabel L89=new DexLabel();
                ddv.visitLineNumber(275,L89);
                ddv.visitEndLocal(8,L89);
                DexLabel L90=new DexLabel();
                ddv.visitLineNumber(276,L90);
                DexLabel L91=new DexLabel();
                ddv.visitLineNumber(303,L91);
                ddv.visitEndLocal(16,L91);
                ddv.visitRestartLocal(15,L91);
                DexLabel L92=new DexLabel();
                ddv.visitLineNumber(304,L92);
                ddv.visitStartLocal(4,L92,"complete","Z",null);
                DexLabel L93=new DexLabel();
                ddv.visitLineNumber(305,L93);
                ddv.visitStartLocal(3,L93,"close","Z",null);
                DexLabel L94=new DexLabel();
                ddv.visitLineNumber(308,L94);
                DexLabel L95=new DexLabel();
                ddv.visitLineNumber(310,L95);
                DexLabel L96=new DexLabel();
                ddv.visitLineNumber(312,L96);
                DexLabel L97=new DexLabel();
                ddv.visitLineNumber(313,L97);
                DexLabel L98=new DexLabel();
                ddv.visitLineNumber(318,L98);
                DexLabel L99=new DexLabel();
                ddv.visitLineNumber(320,L99);
                DexLabel L100=new DexLabel();
                ddv.visitLineNumber(321,L100);
                DexLabel L101=new DexLabel();
                ddv.visitLineNumber(326,L101);
                DexLabel L102=new DexLabel();
                ddv.visitLineNumber(328,L102);
                DexLabel L103=new DexLabel();
                ddv.visitLineNumber(330,L103);
                ddv.visitLineNumber(331,L14);
                DexLabel L104=new DexLabel();
                ddv.visitLineNumber(333,L104);
                DexLabel L105=new DexLabel();
                ddv.visitLineNumber(334,L105);
                DexLabel L106=new DexLabel();
                ddv.visitLineNumber(335,L106);
                DexLabel L107=new DexLabel();
                ddv.visitLineNumber(336,L107);
                DexLabel L108=new DexLabel();
                ddv.visitLineNumber(338,L108);
                DexLabel L109=new DexLabel();
                ddv.visitLineNumber(340,L109);
                DexLabel L110=new DexLabel();
                ddv.visitLineNumber(342,L110);
                DexLabel L111=new DexLabel();
                ddv.visitLineNumber(343,L111);
                DexLabel L112=new DexLabel();
                ddv.visitLineNumber(344,L112);
                DexLabel L113=new DexLabel();
                ddv.visitLineNumber(345,L113);
                ddv.visitLineNumber(364,L16);
                ddv.visitLineNumber(239,L17);
                ddv.visitEndLocal(15,L17);
                ddv.visitEndLocal(4,L17);
                ddv.visitEndLocal(3,L17);
                ddv.visitRestartLocal(16,L17);
                ddv.visitLineNumber(241,L18);
                DexLabel L114=new DexLabel();
                ddv.visitLineNumber(242,L114);
                ddv.visitLineNumber(303,L19);
                DexLabel L115=new DexLabel();
                ddv.visitLineNumber(304,L115);
                ddv.visitRestartLocal(4,L115);
                DexLabel L116=new DexLabel();
                ddv.visitLineNumber(305,L116);
                ddv.visitRestartLocal(3,L116);
                DexLabel L117=new DexLabel();
                ddv.visitLineNumber(308,L117);
                DexLabel L118=new DexLabel();
                ddv.visitLineNumber(310,L118);
                DexLabel L119=new DexLabel();
                ddv.visitLineNumber(312,L119);
                DexLabel L120=new DexLabel();
                ddv.visitLineNumber(313,L120);
                DexLabel L121=new DexLabel();
                ddv.visitLineNumber(318,L121);
                DexLabel L122=new DexLabel();
                ddv.visitLineNumber(320,L122);
                DexLabel L123=new DexLabel();
                ddv.visitLineNumber(321,L123);
                DexLabel L124=new DexLabel();
                ddv.visitLineNumber(326,L124);
                DexLabel L125=new DexLabel();
                ddv.visitLineNumber(328,L125);
                DexLabel L126=new DexLabel();
                ddv.visitLineNumber(330,L126);
                ddv.visitLineNumber(331,L21);
                DexLabel L127=new DexLabel();
                ddv.visitLineNumber(333,L127);
                ddv.visitRestartLocal(3,L127);
                ddv.visitLineNumber(334,L22);
                DexLabel L128=new DexLabel();
                ddv.visitLineNumber(335,L128);
                ddv.visitRestartLocal(15,L128);
                ddv.visitLineNumber(336,L24);
                DexLabel L129=new DexLabel();
                ddv.visitEndLocal(16,L129);
                DexLabel L130=new DexLabel();
                ddv.visitLineNumber(338,L130);
                DexLabel L131=new DexLabel();
                ddv.visitLineNumber(340,L131);
                DexLabel L132=new DexLabel();
                ddv.visitLineNumber(342,L132);
                DexLabel L133=new DexLabel();
                ddv.visitLineNumber(343,L133);
                DexLabel L134=new DexLabel();
                ddv.visitLineNumber(344,L134);
                DexLabel L135=new DexLabel();
                ddv.visitLineNumber(345,L135);
                ddv.visitLineNumber(364,L26);
                ddv.visitLineNumber(243,L27);
                ddv.visitEndLocal(4,L27);
                ddv.visitEndLocal(3,L27);
                ddv.visitEndLocal(15,L27);
                ddv.visitRestartLocal(16,L27);
                DexLabel L136=new DexLabel();
                ddv.visitLineNumber(244,L136);
                DexLabel L137=new DexLabel();
                ddv.visitLineNumber(245,L137);
                ddv.visitLineNumber(247,L28);
                DexLabel L138=new DexLabel();
                ddv.visitLineNumber(249,L138);
                DexLabel L139=new DexLabel();
                ddv.visitLineNumber(250,L139);
                ddv.visitStartLocal(12,L139,"in","Ljava/io/InputStream;",null);
                DexLabel L140=new DexLabel();
                ddv.visitLineNumber(252,L140);
                DexLabel L141=new DexLabel();
                ddv.visitLineNumber(254,L141);
                DexLabel L142=new DexLabel();
                ddv.visitLineNumber(255,L142);
                DexLabel L143=new DexLabel();
                ddv.visitLineNumber(256,L143);
                DexLabel L144=new DexLabel();
                ddv.visitLineNumber(259,L144);
                ddv.visitLineNumber(245,L20);
                ddv.visitEndLocal(12,L20);
                ddv.visitLineNumber(288,L12);
                ddv.visitLineNumber(290,L32);
                ddv.visitEndLocal(16,L32);
                ddv.visitRestartLocal(15,L32);
                ddv.visitStartLocal(5,L32,"e","Ljava/io/IOException;",null);
                ddv.visitLineNumber(292,L33);
                DexLabel L145=new DexLabel();
                ddv.visitLineNumber(294,L145);
                DexLabel L146=new DexLabel();
                ddv.visitLineNumber(295,L146);
                DexLabel L147=new DexLabel();
                ddv.visitLineNumber(297,L147);
                ddv.visitLineNumber(298,L35);
                ddv.visitLineNumber(299,L37);
                ddv.visitLineNumber(303,L34);
                ddv.visitEndLocal(5,L34);
                DexLabel L148=new DexLabel();
                ddv.visitLineNumber(304,L148);
                ddv.visitRestartLocal(4,L148);
                DexLabel L149=new DexLabel();
                ddv.visitLineNumber(305,L149);
                ddv.visitRestartLocal(3,L149);
                DexLabel L150=new DexLabel();
                ddv.visitLineNumber(308,L150);
                DexLabel L151=new DexLabel();
                ddv.visitLineNumber(310,L151);
                DexLabel L152=new DexLabel();
                ddv.visitLineNumber(312,L152);
                DexLabel L153=new DexLabel();
                ddv.visitLineNumber(313,L153);
                DexLabel L154=new DexLabel();
                ddv.visitLineNumber(318,L154);
                DexLabel L155=new DexLabel();
                ddv.visitLineNumber(320,L155);
                DexLabel L156=new DexLabel();
                ddv.visitLineNumber(321,L156);
                DexLabel L157=new DexLabel();
                ddv.visitLineNumber(326,L157);
                DexLabel L158=new DexLabel();
                ddv.visitLineNumber(328,L158);
                DexLabel L159=new DexLabel();
                ddv.visitLineNumber(330,L159);
                ddv.visitLineNumber(331,L38);
                DexLabel L160=new DexLabel();
                ddv.visitLineNumber(333,L160);
                ddv.visitRestartLocal(3,L160);
                DexLabel L161=new DexLabel();
                ddv.visitLineNumber(334,L161);
                DexLabel L162=new DexLabel();
                ddv.visitLineNumber(335,L162);
                DexLabel L163=new DexLabel();
                ddv.visitLineNumber(336,L163);
                DexLabel L164=new DexLabel();
                ddv.visitLineNumber(338,L164);
                DexLabel L165=new DexLabel();
                ddv.visitLineNumber(340,L165);
                DexLabel L166=new DexLabel();
                ddv.visitLineNumber(342,L166);
                DexLabel L167=new DexLabel();
                ddv.visitLineNumber(343,L167);
                DexLabel L168=new DexLabel();
                ddv.visitLineNumber(344,L168);
                DexLabel L169=new DexLabel();
                ddv.visitLineNumber(345,L169);
                ddv.visitLineNumber(364,L40);
                ddv.visitLineNumber(258,L41);
                ddv.visitEndLocal(15,L41);
                ddv.visitEndLocal(4,L41);
                ddv.visitEndLocal(3,L41);
                ddv.visitRestartLocal(12,L41);
                ddv.visitRestartLocal(16,L41);
                ddv.visitLineNumber(303,L13);
                ddv.visitEndLocal(12,L13);
                DexLabel L170=new DexLabel();
                ddv.visitRestartLocal(15,L170);
                DexLabel L171=new DexLabel();
                ddv.visitLineNumber(263,L171);
                ddv.visitEndLocal(15,L171);
                ddv.visitRestartLocal(12,L171);
                DexLabel L172=new DexLabel();
                ddv.visitLineNumber(277,L172);
                ddv.visitEndLocal(12,L172);
                DexLabel L173=new DexLabel();
                ddv.visitRestartLocal(15,L173);
                ddv.visitEndLocal(16,L43);
                DexLabel L174=new DexLabel();
                ddv.visitLineNumber(280,L174);
                DexLabel L175=new DexLabel();
                ddv.visitLineNumber(282,L175);
                DexLabel L176=new DexLabel();
                ddv.visitLineNumber(303,L176);
                DexLabel L177=new DexLabel();
                ddv.visitLineNumber(304,L177);
                ddv.visitRestartLocal(4,L177);
                DexLabel L178=new DexLabel();
                ddv.visitLineNumber(305,L178);
                ddv.visitRestartLocal(3,L178);
                DexLabel L179=new DexLabel();
                ddv.visitLineNumber(308,L179);
                DexLabel L180=new DexLabel();
                ddv.visitLineNumber(310,L180);
                DexLabel L181=new DexLabel();
                ddv.visitLineNumber(312,L181);
                DexLabel L182=new DexLabel();
                ddv.visitLineNumber(313,L182);
                DexLabel L183=new DexLabel();
                ddv.visitLineNumber(318,L183);
                DexLabel L184=new DexLabel();
                ddv.visitLineNumber(320,L184);
                DexLabel L185=new DexLabel();
                ddv.visitLineNumber(321,L185);
                DexLabel L186=new DexLabel();
                ddv.visitLineNumber(326,L186);
                DexLabel L187=new DexLabel();
                ddv.visitLineNumber(328,L187);
                DexLabel L188=new DexLabel();
                ddv.visitLineNumber(330,L188);
                ddv.visitLineNumber(331,L46);
                DexLabel L189=new DexLabel();
                ddv.visitLineNumber(333,L189);
                ddv.visitRestartLocal(3,L189);
                DexLabel L190=new DexLabel();
                ddv.visitLineNumber(334,L190);
                DexLabel L191=new DexLabel();
                ddv.visitLineNumber(335,L191);
                DexLabel L192=new DexLabel();
                ddv.visitLineNumber(336,L192);
                DexLabel L193=new DexLabel();
                ddv.visitLineNumber(338,L193);
                DexLabel L194=new DexLabel();
                ddv.visitLineNumber(340,L194);
                DexLabel L195=new DexLabel();
                ddv.visitLineNumber(342,L195);
                DexLabel L196=new DexLabel();
                ddv.visitLineNumber(343,L196);
                DexLabel L197=new DexLabel();
                ddv.visitLineNumber(344,L197);
                DexLabel L198=new DexLabel();
                ddv.visitLineNumber(345,L198);
                ddv.visitLineNumber(364,L48);
                ddv.visitLineNumber(297,L36);
                ddv.visitEndLocal(4,L36);
                ddv.visitEndLocal(3,L36);
                ddv.visitRestartLocal(5,L36);
                ddv.visitLineNumber(358,L51);
                ddv.visitEndLocal(5,L51);
                ddv.visitRestartLocal(3,L51);
                ddv.visitRestartLocal(4,L51);
                DexLabel L199=new DexLabel();
                ddv.visitLineNumber(359,L199);
                ddv.visitStartLocal(6,L199,"ex","Lorg/mortbay/jetty/client/HttpExchange;",null);
                DexLabel L200=new DexLabel();
                ddv.visitLineNumber(361,L200);
                DexLabel L201=new DexLabel();
                ddv.visitLineNumber(364,L201);
                ddv.visitEndLocal(6,L201);
                ddv.visitLineNumber(303,L52);
                DexLabel L202=new DexLabel();
                ddv.visitLineNumber(349,L202);
                ddv.visitLineNumber(351,L53);
                DexLabel L203=new DexLabel();
                ddv.visitLineNumber(352,L203);
                DexLabel L204=new DexLabel();
                ddv.visitLineNumber(353,L204);
                DexLabel L205=new DexLabel();
                ddv.visitLineNumber(354,L205);
                DexLabel L206=new DexLabel();
                ddv.visitLineNumber(355,L206);
                ddv.visitLineNumber(358,L55);
                DexLabel L207=new DexLabel();
                ddv.visitLineNumber(359,L207);
                ddv.visitRestartLocal(6,L207);
                DexLabel L208=new DexLabel();
                ddv.visitLineNumber(361,L208);
                DexLabel L209=new DexLabel();
                ddv.visitLineNumber(364,L209);
                ddv.visitEndLocal(6,L209);
                DexLabel L210=new DexLabel();
                ddv.visitLineNumber(349,L210);
                DexLabel L211=new DexLabel();
                ddv.visitLineNumber(351,L211);
                DexLabel L212=new DexLabel();
                ddv.visitLineNumber(352,L212);
                DexLabel L213=new DexLabel();
                ddv.visitLineNumber(353,L213);
                DexLabel L214=new DexLabel();
                ddv.visitLineNumber(354,L214);
                DexLabel L215=new DexLabel();
                ddv.visitLineNumber(355,L215);
                ddv.visitLineNumber(358,L57);
                DexLabel L216=new DexLabel();
                ddv.visitLineNumber(359,L216);
                ddv.visitRestartLocal(6,L216);
                DexLabel L217=new DexLabel();
                ddv.visitLineNumber(361,L217);
                DexLabel L218=new DexLabel();
                ddv.visitLineNumber(364,L218);
                ddv.visitEndLocal(6,L218);
                DexLabel L219=new DexLabel();
                ddv.visitLineNumber(349,L219);
                DexLabel L220=new DexLabel();
                ddv.visitLineNumber(351,L220);
                DexLabel L221=new DexLabel();
                ddv.visitLineNumber(352,L221);
                DexLabel L222=new DexLabel();
                ddv.visitLineNumber(353,L222);
                DexLabel L223=new DexLabel();
                ddv.visitLineNumber(354,L223);
                DexLabel L224=new DexLabel();
                ddv.visitLineNumber(355,L224);
                DexLabel L225=new DexLabel();
                ddv.visitLineNumber(303,L225);
                ddv.visitEndLocal(3,L225);
                ddv.visitEndLocal(4,L225);
                DexLabel L226=new DexLabel();
                ddv.visitLineNumber(304,L226);
                ddv.visitRestartLocal(4,L226);
                DexLabel L227=new DexLabel();
                ddv.visitLineNumber(305,L227);
                ddv.visitRestartLocal(3,L227);
                DexLabel L228=new DexLabel();
                ddv.visitLineNumber(308,L228);
                DexLabel L229=new DexLabel();
                ddv.visitLineNumber(310,L229);
                DexLabel L230=new DexLabel();
                ddv.visitLineNumber(312,L230);
                DexLabel L231=new DexLabel();
                ddv.visitLineNumber(313,L231);
                DexLabel L232=new DexLabel();
                ddv.visitLineNumber(318,L232);
                DexLabel L233=new DexLabel();
                ddv.visitLineNumber(320,L233);
                DexLabel L234=new DexLabel();
                ddv.visitLineNumber(321,L234);
                DexLabel L235=new DexLabel();
                ddv.visitLineNumber(326,L235);
                DexLabel L236=new DexLabel();
                ddv.visitLineNumber(328,L236);
                DexLabel L237=new DexLabel();
                ddv.visitLineNumber(330,L237);
                ddv.visitLineNumber(331,L59);
                DexLabel L238=new DexLabel();
                ddv.visitLineNumber(333,L238);
                ddv.visitRestartLocal(3,L238);
                DexLabel L239=new DexLabel();
                ddv.visitLineNumber(334,L239);
                DexLabel L240=new DexLabel();
                ddv.visitLineNumber(335,L240);
                DexLabel L241=new DexLabel();
                ddv.visitLineNumber(336,L241);
                DexLabel L242=new DexLabel();
                ddv.visitLineNumber(338,L242);
                DexLabel L243=new DexLabel();
                ddv.visitLineNumber(340,L243);
                DexLabel L244=new DexLabel();
                ddv.visitLineNumber(342,L244);
                DexLabel L245=new DexLabel();
                ddv.visitLineNumber(343,L245);
                DexLabel L246=new DexLabel();
                ddv.visitLineNumber(344,L246);
                DexLabel L247=new DexLabel();
                ddv.visitLineNumber(345,L247);
                ddv.visitLineNumber(364,L61);
                ddv.visitLineNumber(358,L62);
                DexLabel L248=new DexLabel();
                ddv.visitLineNumber(359,L248);
                ddv.visitRestartLocal(6,L248);
                DexLabel L249=new DexLabel();
                ddv.visitLineNumber(361,L249);
                DexLabel L250=new DexLabel();
                ddv.visitLineNumber(364,L250);
                ddv.visitEndLocal(6,L250);
                DexLabel L251=new DexLabel();
                ddv.visitLineNumber(349,L251);
                DexLabel L252=new DexLabel();
                ddv.visitLineNumber(351,L252);
                DexLabel L253=new DexLabel();
                ddv.visitLineNumber(352,L253);
                DexLabel L254=new DexLabel();
                ddv.visitLineNumber(353,L254);
                DexLabel L255=new DexLabel();
                ddv.visitLineNumber(354,L255);
                DexLabel L256=new DexLabel();
                ddv.visitLineNumber(355,L256);
                ddv.visitLineNumber(358,L64);
                DexLabel L257=new DexLabel();
                ddv.visitLineNumber(359,L257);
                ddv.visitRestartLocal(6,L257);
                DexLabel L258=new DexLabel();
                ddv.visitLineNumber(361,L258);
                DexLabel L259=new DexLabel();
                ddv.visitLineNumber(364,L259);
                ddv.visitEndLocal(6,L259);
                DexLabel L260=new DexLabel();
                ddv.visitLineNumber(349,L260);
                DexLabel L261=new DexLabel();
                ddv.visitLineNumber(351,L261);
                DexLabel L262=new DexLabel();
                ddv.visitLineNumber(352,L262);
                DexLabel L263=new DexLabel();
                ddv.visitLineNumber(353,L263);
                DexLabel L264=new DexLabel();
                ddv.visitLineNumber(354,L264);
                DexLabel L265=new DexLabel();
                ddv.visitLineNumber(355,L265);
                ddv.visitLineNumber(364,L23);
                ddv.visitEndLocal(15,L23);
                ddv.visitRestartLocal(16,L23);
                DexLabel L266=new DexLabel();
                ddv.visitRestartLocal(15,L266);
                ddv.visitLineNumber(288,L45);
                ddv.visitEndLocal(4,L45);
                ddv.visitEndLocal(3,L45);
                ddv.visitEndLocal(16,L45);
                DexLabel L267=new DexLabel();
                ddv.visitEndLocal(15,L267);
                ddv.visitRestartLocal(3,L267);
                ddv.visitRestartLocal(4,L267);
                ddv.visitRestartLocal(16,L267);
                DexLabel L268=new DexLabel();
                ddv.visitRestartLocal(15,L268);
                code.visitLabel(L66);
                code.visitConstStmt(CONST_4,15, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L67);
                code.visitConstStmt(CONST_WIDE_16,10,Long.valueOf(0L)); // long: 0x0000000000000000  double:0.000000
                code.visitLabel(L68);
                code.visitConstStmt(CONST_4,7, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L69);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,21);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/client/HttpConnection;","_endp","Lorg/mortbay/io/EndPoint;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,17,0);
                code.visitMethodStmt(INVOKE_INTERFACE_RANGE,new int[]{ 17},new Method("Lorg/mortbay/io/EndPoint;","isBufferingInput",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,17);
                code.visitJumpStmt(IF_NEZ,17,-1,L70);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,21);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/client/HttpConnection;","_endp","Lorg/mortbay/io/EndPoint;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,17,0);
                code.visitMethodStmt(INVOKE_INTERFACE_RANGE,new int[]{ 17},new Method("Lorg/mortbay/io/EndPoint;","isOpen",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,17);
                code.visitJumpStmt(IF_EQZ,17,-1,L77);
                code.visitLabel(L70);
                code.visitStmt1R(MONITOR_ENTER,21);
                code.visitLabel(L0);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,21);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/client/HttpConnection;","_exchange","Lorg/mortbay/jetty/client/HttpExchange;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,17,0);
                code.visitJumpStmt(IF_NEZ,17,-1,L78);
                code.visitLabel(L71);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,21);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/client/HttpConnection;","_endp","Lorg/mortbay/io/EndPoint;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,17,0);
                code.visitMethodStmt(INVOKE_INTERFACE_RANGE,new int[]{ 17},new Method("Lorg/mortbay/io/EndPoint;","isBlocking",new String[]{ },"Z"));
                code.visitLabel(L1);
                code.visitStmt1R(MOVE_RESULT,17);
                code.visitJumpStmt(IF_EQZ,17,-1,L8);
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 21},new Method("Ljava/lang/Object;","wait",new String[]{ },"V"));
                code.visitLabel(L4);
                code.visitJumpStmt(GOTO,-1,-1,L0);
                code.visitLabel(L5);
                code.visitStmt1R(MOVE_EXCEPTION,5);
                code.visitLabel(L6);
                code.visitTypeStmt(NEW_INSTANCE,17,-1,"Ljava/io/InterruptedIOException;");
                code.visitMethodStmt(INVOKE_DIRECT_RANGE,new int[]{ 17},new Method("Ljava/io/InterruptedIOException;","<init>",new String[]{ },"V"));
                code.visitStmt1R(THROW,17);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,17);
                code.visitStmt1R(MONITOR_EXIT,21);
                code.visitLabel(L7);
                code.visitStmt1R(THROW,17);
                code.visitLabel(L8);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,21);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/client/HttpConnection;","_parser","Lorg/mortbay/jetty/HttpParser;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,17,0);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 17},new Method("Lorg/mortbay/jetty/HttpParser;","fill",new String[]{ },"J"));
                code.visitLabel(L72);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,21);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/client/HttpConnection;","_parser","Lorg/mortbay/jetty/HttpParser;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,17,0);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 17},new Method("Lorg/mortbay/jetty/HttpParser;","skipCRLF",new String[]{ },"V"));
                code.visitLabel(L73);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,21);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/client/HttpConnection;","_parser","Lorg/mortbay/jetty/HttpParser;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,17,0);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 17},new Method("Lorg/mortbay/jetty/HttpParser;","isMoreInBuffer",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,17);
                code.visitJumpStmt(IF_EQZ,17,-1,L76);
                code.visitLabel(L74);
                code.visitConstStmt(CONST_STRING,17,"unexpected data");
                code.visitMethodStmt(INVOKE_STATIC_RANGE,new int[]{ 17},new Method("Lorg/mortbay/log/Log;","warn",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L75);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,21);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/client/HttpConnection;","_endp","Lorg/mortbay/io/EndPoint;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,17,0);
                code.visitMethodStmt(INVOKE_INTERFACE_RANGE,new int[]{ 17},new Method("Lorg/mortbay/io/EndPoint;","close",new String[]{ },"V"));
                code.visitLabel(L76);
                code.visitStmt1R(MONITOR_EXIT,21);
                code.visitLabel(L77);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L78);
                code.visitStmt1R(MONITOR_EXIT,21);
                code.visitLabel(L9);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,21);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/client/HttpConnection;","_exchange","Lorg/mortbay/jetty/client/HttpExchange;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,17,0);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 17},new Method("Lorg/mortbay/jetty/client/HttpExchange;","getStatus",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,17);
                code.visitConstStmt(CONST_16,18, Integer.valueOf(2)); // int: 0x00000002  float:0.000000
                code.visitStmt2R(MOVE_FROM16,0,17);
                code.visitStmt2R(MOVE_FROM16,1,18);
                DexLabel L269=new DexLabel();
                code.visitJumpStmt(IF_NE,0,1,L269);
                code.visitLabel(L79);
                code.visitConstStmt(CONST_4,15, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L80);
                code.visitMethodStmt(INVOKE_DIRECT_RANGE,new int[]{ 21},new Method("Lorg/mortbay/jetty/client/HttpConnection;","commitRequest",new String[]{ },"V"));
                code.visitLabel(L269);
                code.visitStmt2R(MOVE_FROM16,16,15);
                code.visitLabel(L81);
                code.visitConstStmt(CONST_WIDE_16,13,Long.valueOf(0L)); // long: 0x0000000000000000  double:0.000000
                code.visitLabel(L10);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,21);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/client/HttpConnection;","_endp","Lorg/mortbay/io/EndPoint;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,17,0);
                code.visitMethodStmt(INVOKE_INTERFACE_RANGE,new int[]{ 17},new Method("Lorg/mortbay/io/EndPoint;","flush",new String[]{ },"V"));
                code.visitLabel(L82);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,21);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/client/HttpConnection;","_generator","Lorg/mortbay/jetty/HttpGenerator;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,17,0);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 17},new Method("Lorg/mortbay/jetty/HttpGenerator;","isComplete",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,17);
                code.visitJumpStmt(IF_EQZ,17,-1,L17);
                code.visitLabel(L83);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,21);
                code.visitFieldStmt(IGET_BOOLEAN,0,0,new Field("Lorg/mortbay/jetty/client/HttpConnection;","_requestComplete","Z"));
                code.visitStmt2R(MOVE_FROM16,17,0);
                code.visitJumpStmt(IF_NEZ,17,-1,L86);
                code.visitLabel(L84);
                code.visitConstStmt(CONST_16,17, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitStmt2R(MOVE_FROM16,0,17);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,21);
                code.visitFieldStmt(IPUT_BOOLEAN,0,1,new Field("Lorg/mortbay/jetty/client/HttpConnection;","_requestComplete","Z"));
                code.visitLabel(L85);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,21);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/client/HttpConnection;","_exchange","Lorg/mortbay/jetty/client/HttpExchange;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,17,0);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 17},new Method("Lorg/mortbay/jetty/client/HttpExchange;","getEventListener",new String[]{ },"Lorg/mortbay/jetty/client/HttpEventListener;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,17);
                code.visitMethodStmt(INVOKE_INTERFACE_RANGE,new int[]{ 17},new Method("Lorg/mortbay/jetty/client/HttpEventListener;","onRequestComplete",new String[]{ },"V"));
                code.visitLabel(L86);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,21);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/client/HttpConnection;","_parser","Lorg/mortbay/jetty/HttpParser;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,17,0);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 17},new Method("Lorg/mortbay/jetty/HttpParser;","isComplete",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,17);
                code.visitJumpStmt(IF_NEZ,17,-1,L89);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,21);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/client/HttpConnection;","_generator","Lorg/mortbay/jetty/HttpGenerator;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,17,0);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 17},new Method("Lorg/mortbay/jetty/HttpGenerator;","isCommitted",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,17);
                code.visitJumpStmt(IF_EQZ,17,-1,L89);
                code.visitLabel(L87);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,21);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/client/HttpConnection;","_parser","Lorg/mortbay/jetty/HttpParser;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,17,0);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 17},new Method("Lorg/mortbay/jetty/HttpParser;","parseAvailable",new String[]{ },"J"));
                code.visitLabel(L11);
                code.visitStmt1R(MOVE_RESULT_WIDE,8);
                code.visitLabel(L88);
                code.visitStmt2R(ADD_LONG_2ADDR,13,8);
                code.visitLabel(L89);
                code.visitConstStmt(CONST_WIDE_16,17,Long.valueOf(0L)); // long: 0x0000000000000000  double:0.000000
                code.visitStmt3R(CMP_LONG,17,13,17);
                code.visitJumpStmt(IF_LEZ,17,-1,L172);
                code.visitLabel(L90);
                code.visitConstStmt(CONST_4,15, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L91);
                code.visitConstStmt(CONST_4,4, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L92);
                code.visitStmt2R(MOVE,3,7);
                code.visitLabel(L93);
                code.visitJumpStmt(IF_NEZ,7,-1,L101);
                code.visitLabel(L94);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,21);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/client/HttpConnection;","_generator","Lorg/mortbay/jetty/HttpGenerator;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,17,0);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 17},new Method("Lorg/mortbay/jetty/HttpGenerator;","isComplete",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,17);
                code.visitJumpStmt(IF_EQZ,17,-1,L101);
                code.visitLabel(L95);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,21);
                code.visitFieldStmt(IGET_BOOLEAN,0,0,new Field("Lorg/mortbay/jetty/client/HttpConnection;","_requestComplete","Z"));
                code.visitStmt2R(MOVE_FROM16,17,0);
                code.visitJumpStmt(IF_NEZ,17,-1,L98);
                code.visitLabel(L96);
                code.visitConstStmt(CONST_16,17, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitStmt2R(MOVE_FROM16,0,17);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,21);
                code.visitFieldStmt(IPUT_BOOLEAN,0,1,new Field("Lorg/mortbay/jetty/client/HttpConnection;","_requestComplete","Z"));
                code.visitLabel(L97);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,21);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/client/HttpConnection;","_exchange","Lorg/mortbay/jetty/client/HttpExchange;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,17,0);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 17},new Method("Lorg/mortbay/jetty/client/HttpExchange;","getEventListener",new String[]{ },"Lorg/mortbay/jetty/client/HttpEventListener;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,17);
                code.visitMethodStmt(INVOKE_INTERFACE_RANGE,new int[]{ 17},new Method("Lorg/mortbay/jetty/client/HttpEventListener;","onRequestComplete",new String[]{ },"V"));
                code.visitLabel(L98);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,21);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/client/HttpConnection;","_parser","Lorg/mortbay/jetty/HttpParser;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,17,0);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 17},new Method("Lorg/mortbay/jetty/HttpParser;","isComplete",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,17);
                code.visitJumpStmt(IF_EQZ,17,-1,L101);
                code.visitLabel(L99);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,21);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/client/HttpConnection;","_destination","Lorg/mortbay/jetty/client/HttpDestination;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,17,0);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 17},new Method("Lorg/mortbay/jetty/client/HttpDestination;","getHttpClient",new String[]{ },"Lorg/mortbay/jetty/client/HttpClient;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,17);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,21);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/client/HttpConnection;","_timeout","Lorg/mortbay/thread/Timeout$Task;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,18,0);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 17,18},new Method("Lorg/mortbay/jetty/client/HttpClient;","cancel",new String[]{ "Lorg/mortbay/thread/Timeout$Task;"},"V"));
                code.visitLabel(L100);
                code.visitConstStmt(CONST_4,4, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitLabel(L101);
                code.visitJumpStmt(IF_NEZ,4,-1,L102);
                code.visitJumpStmt(IF_EQZ,7,-1,L69);
                code.visitLabel(L102);
                code.visitStmt1R(MONITOR_ENTER,21);
                code.visitLabel(L103);
                code.visitJumpStmt(IF_NEZ,3,-1,L104);
                code.visitLabel(L14);
                code.visitMethodStmt(INVOKE_DIRECT_RANGE,new int[]{ 21},new Method("Lorg/mortbay/jetty/client/HttpConnection;","shouldClose",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitLabel(L104);
                code.visitConstStmt(CONST_16,17, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,21);
                code.visitStmt2R(MOVE_FROM16,1,17);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Lorg/mortbay/jetty/client/HttpConnection;","reset",new String[]{ "Z"},"V"));
                code.visitLabel(L105);
                code.visitConstStmt(CONST_4,15, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L106);
                code.visitConstStmt(CONST_WIDE_16,10,Long.valueOf(-1L)); // long: 0xffffffffffffffff  double:NaN
                code.visitLabel(L107);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,21);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/client/HttpConnection;","_exchange","Lorg/mortbay/jetty/client/HttpExchange;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,17,0);
                code.visitJumpStmt(IF_EQZ,17,-1,L209);
                code.visitLabel(L108);
                code.visitConstStmt(CONST_16,17, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,17);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,21);
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/jetty/client/HttpConnection;","_exchange","Lorg/mortbay/jetty/client/HttpExchange;"));
                code.visitLabel(L109);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,21);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/client/HttpConnection;","_pipeline","Lorg/mortbay/jetty/client/HttpExchange;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,17,0);
                code.visitJumpStmt(IF_NEZ,17,-1,L210);
                code.visitLabel(L110);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 21},new Method("Lorg/mortbay/jetty/client/HttpConnection;","isReserved",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,17);
                code.visitJumpStmt(IF_NEZ,17,-1,L112);
                code.visitLabel(L111);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,21);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/client/HttpConnection;","_destination","Lorg/mortbay/jetty/client/HttpDestination;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,17,0);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,17);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,21);
                code.visitStmt2R(MOVE,2,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1,2},new Method("Lorg/mortbay/jetty/client/HttpDestination;","returnConnection",new String[]{ "Lorg/mortbay/jetty/client/HttpConnection;","Z"},"V"));
                code.visitLabel(L112);
                code.visitJumpStmt(IF_EQZ,3,-1,L209);
                code.visitLabel(L113);
                code.visitStmt1R(MONITOR_EXIT,21);
                code.visitJumpStmt(GOTO_16,-1,-1,L77);
                code.visitLabel(L16);
                code.visitStmt1R(MOVE_EXCEPTION,17);
                code.visitStmt1R(MONITOR_EXIT,21);
                code.visitLabel(L15);
                code.visitStmt1R(THROW,17);
                code.visitLabel(L17);
                code.visitStmt1R(MONITOR_ENTER,21);
                code.visitLabel(L18);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,21);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/client/HttpConnection;","_exchange","Lorg/mortbay/jetty/client/HttpExchange;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,17,0);
                code.visitJumpStmt(IF_NEZ,17,-1,L27);
                code.visitLabel(L114);
                code.visitStmt1R(MONITOR_EXIT,21);
                code.visitLabel(L19);
                code.visitConstStmt(CONST_4,4, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L115);
                code.visitStmt2R(MOVE,3,7);
                code.visitLabel(L116);
                code.visitJumpStmt(IF_NEZ,7,-1,L124);
                code.visitLabel(L117);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,21);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/client/HttpConnection;","_generator","Lorg/mortbay/jetty/HttpGenerator;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,17,0);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 17},new Method("Lorg/mortbay/jetty/HttpGenerator;","isComplete",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,17);
                code.visitJumpStmt(IF_EQZ,17,-1,L124);
                code.visitLabel(L118);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,21);
                code.visitFieldStmt(IGET_BOOLEAN,0,0,new Field("Lorg/mortbay/jetty/client/HttpConnection;","_requestComplete","Z"));
                code.visitStmt2R(MOVE_FROM16,17,0);
                code.visitJumpStmt(IF_NEZ,17,-1,L121);
                code.visitLabel(L119);
                code.visitConstStmt(CONST_16,17, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitStmt2R(MOVE_FROM16,0,17);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,21);
                code.visitFieldStmt(IPUT_BOOLEAN,0,1,new Field("Lorg/mortbay/jetty/client/HttpConnection;","_requestComplete","Z"));
                code.visitLabel(L120);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,21);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/client/HttpConnection;","_exchange","Lorg/mortbay/jetty/client/HttpExchange;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,17,0);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 17},new Method("Lorg/mortbay/jetty/client/HttpExchange;","getEventListener",new String[]{ },"Lorg/mortbay/jetty/client/HttpEventListener;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,17);
                code.visitMethodStmt(INVOKE_INTERFACE_RANGE,new int[]{ 17},new Method("Lorg/mortbay/jetty/client/HttpEventListener;","onRequestComplete",new String[]{ },"V"));
                code.visitLabel(L121);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,21);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/client/HttpConnection;","_parser","Lorg/mortbay/jetty/HttpParser;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,17,0);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 17},new Method("Lorg/mortbay/jetty/HttpParser;","isComplete",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,17);
                code.visitJumpStmt(IF_EQZ,17,-1,L124);
                code.visitLabel(L122);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,21);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/client/HttpConnection;","_destination","Lorg/mortbay/jetty/client/HttpDestination;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,17,0);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 17},new Method("Lorg/mortbay/jetty/client/HttpDestination;","getHttpClient",new String[]{ },"Lorg/mortbay/jetty/client/HttpClient;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,17);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,21);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/client/HttpConnection;","_timeout","Lorg/mortbay/thread/Timeout$Task;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,18,0);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 17,18},new Method("Lorg/mortbay/jetty/client/HttpClient;","cancel",new String[]{ "Lorg/mortbay/thread/Timeout$Task;"},"V"));
                code.visitLabel(L123);
                code.visitConstStmt(CONST_4,4, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitLabel(L124);
                code.visitJumpStmt(IF_NEZ,4,-1,L125);
                code.visitJumpStmt(IF_EQZ,7,-1,L267);
                code.visitLabel(L125);
                code.visitStmt1R(MONITOR_ENTER,21);
                code.visitLabel(L126);
                code.visitJumpStmt(IF_NEZ,3,-1,L127);
                code.visitLabel(L21);
                code.visitMethodStmt(INVOKE_DIRECT_RANGE,new int[]{ 21},new Method("Lorg/mortbay/jetty/client/HttpConnection;","shouldClose",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitLabel(L127);
                code.visitConstStmt(CONST_16,17, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,21);
                code.visitStmt2R(MOVE_FROM16,1,17);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Lorg/mortbay/jetty/client/HttpConnection;","reset",new String[]{ "Z"},"V"));
                code.visitLabel(L22);
                code.visitConstStmt(CONST_4,15, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L128);
                code.visitConstStmt(CONST_WIDE_16,10,Long.valueOf(-1L)); // long: 0xffffffffffffffff  double:NaN
                code.visitLabel(L24);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,21);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/client/HttpConnection;","_exchange","Lorg/mortbay/jetty/client/HttpExchange;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,17,0);
                code.visitLabel(L129);
                code.visitJumpStmt(IF_EQZ,17,-1,L259);
                code.visitLabel(L130);
                code.visitConstStmt(CONST_16,17, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,17);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,21);
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/jetty/client/HttpConnection;","_exchange","Lorg/mortbay/jetty/client/HttpExchange;"));
                code.visitLabel(L131);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,21);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/client/HttpConnection;","_pipeline","Lorg/mortbay/jetty/client/HttpExchange;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,17,0);
                code.visitJumpStmt(IF_NEZ,17,-1,L260);
                code.visitLabel(L132);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 21},new Method("Lorg/mortbay/jetty/client/HttpConnection;","isReserved",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,17);
                code.visitJumpStmt(IF_NEZ,17,-1,L134);
                code.visitLabel(L133);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,21);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/client/HttpConnection;","_destination","Lorg/mortbay/jetty/client/HttpDestination;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,17,0);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,17);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,21);
                code.visitStmt2R(MOVE,2,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1,2},new Method("Lorg/mortbay/jetty/client/HttpDestination;","returnConnection",new String[]{ "Lorg/mortbay/jetty/client/HttpConnection;","Z"},"V"));
                code.visitLabel(L134);
                code.visitJumpStmt(IF_EQZ,3,-1,L259);
                code.visitLabel(L135);
                code.visitStmt1R(MONITOR_EXIT,21);
                code.visitJumpStmt(GOTO_16,-1,-1,L77);
                code.visitLabel(L26);
                code.visitStmt1R(MOVE_EXCEPTION,17);
                DexLabel L270=new DexLabel();
                code.visitLabel(L270);
                code.visitStmt1R(MONITOR_EXIT,21);
                code.visitLabel(L25);
                code.visitStmt1R(THROW,17);
                code.visitLabel(L27);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,21);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/client/HttpConnection;","_generator","Lorg/mortbay/jetty/HttpGenerator;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,17,0);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 17},new Method("Lorg/mortbay/jetty/HttpGenerator;","flush",new String[]{ },"J"));
                code.visitStmt1R(MOVE_RESULT_WIDE,10);
                code.visitLabel(L136);
                code.visitStmt2R(ADD_LONG_2ADDR,13,10);
                code.visitLabel(L137);
                code.visitStmt1R(MONITOR_EXIT,21);
                code.visitLabel(L28);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,21);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/client/HttpConnection;","_generator","Lorg/mortbay/jetty/HttpGenerator;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,17,0);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 17},new Method("Lorg/mortbay/jetty/HttpGenerator;","isComplete",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,17);
                code.visitJumpStmt(IF_NEZ,17,-1,L86);
                code.visitLabel(L138);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,21);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/client/HttpConnection;","_exchange","Lorg/mortbay/jetty/client/HttpExchange;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,17,0);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 17},new Method("Lorg/mortbay/jetty/client/HttpExchange;","getRequestContentSource",new String[]{ },"Ljava/io/InputStream;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,12);
                code.visitLabel(L139);
                code.visitJumpStmt(IF_EQZ,12,-1,L171);
                code.visitLabel(L140);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,21);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/client/HttpConnection;","_requestContentChunk","Lorg/mortbay/io/Buffer;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,17,0);
                code.visitJumpStmt(IF_EQZ,17,-1,L141);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,21);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/client/HttpConnection;","_requestContentChunk","Lorg/mortbay/io/Buffer;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,17,0);
                code.visitMethodStmt(INVOKE_INTERFACE_RANGE,new int[]{ 17},new Method("Lorg/mortbay/io/Buffer;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,17);
                code.visitJumpStmt(IF_NEZ,17,-1,L86);
                code.visitLabel(L141);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,21);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/client/HttpConnection;","_exchange","Lorg/mortbay/jetty/client/HttpExchange;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,17,0);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 17},new Method("Lorg/mortbay/jetty/client/HttpExchange;","getRequestContentChunk",new String[]{ },"Lorg/mortbay/io/Buffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,17);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,17);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,21);
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/jetty/client/HttpConnection;","_requestContentChunk","Lorg/mortbay/io/Buffer;"));
                code.visitLabel(L142);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,21);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/client/HttpConnection;","_requestContentChunk","Lorg/mortbay/io/Buffer;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,17,0);
                code.visitJumpStmt(IF_EQZ,17,-1,L41);
                code.visitLabel(L143);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,21);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/client/HttpConnection;","_generator","Lorg/mortbay/jetty/HttpGenerator;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,17,0);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,21);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/client/HttpConnection;","_requestContentChunk","Lorg/mortbay/io/Buffer;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,18,0);
                code.visitConstStmt(CONST_16,19, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 17,18,19},new Method("Lorg/mortbay/jetty/HttpGenerator;","addContent",new String[]{ "Lorg/mortbay/io/Buffer;","Z"},"V"));
                code.visitLabel(L144);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,21);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/client/HttpConnection;","_generator","Lorg/mortbay/jetty/HttpGenerator;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,17,0);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 17},new Method("Lorg/mortbay/jetty/HttpGenerator;","flush",new String[]{ },"J"));
                code.visitLabel(L29);
                code.visitStmt1R(MOVE_RESULT_WIDE,17);
                code.visitStmt3R(ADD_LONG,13,13,17);
                code.visitJumpStmt(GOTO_16,-1,-1,L86);
                code.visitLabel(L20);
                code.visitStmt1R(MOVE_EXCEPTION,17);
                code.visitLabel(L30);
                code.visitStmt1R(MONITOR_EXIT,21);
                code.visitLabel(L31);
                code.visitStmt1R(THROW,17);
                code.visitLabel(L12);
                code.visitStmt1R(MOVE_EXCEPTION,17);
                code.visitStmt2R(MOVE_OBJECT_FROM16,5,17);
                code.visitStmt2R(MOVE_FROM16,15,16);
                code.visitLabel(L32);
                code.visitStmt1R(MONITOR_ENTER,21);
                code.visitLabel(L33);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,21);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/client/HttpConnection;","_exchange","Lorg/mortbay/jetty/client/HttpExchange;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,17,0);
                code.visitJumpStmt(IF_EQZ,17,-1,L147);
                code.visitLabel(L145);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,21);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/client/HttpConnection;","_exchange","Lorg/mortbay/jetty/client/HttpExchange;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,17,0);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 17},new Method("Lorg/mortbay/jetty/client/HttpExchange;","getEventListener",new String[]{ },"Lorg/mortbay/jetty/client/HttpEventListener;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,17);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,17);
                code.visitStmt2R(MOVE_OBJECT,1,5);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,1},new Method("Lorg/mortbay/jetty/client/HttpEventListener;","onException",new String[]{ "Ljava/lang/Throwable;"},"V"));
                code.visitLabel(L146);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,21);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/client/HttpConnection;","_exchange","Lorg/mortbay/jetty/client/HttpExchange;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,17,0);
                code.visitConstStmt(CONST_16,18, Integer.valueOf(9)); // int: 0x00000009  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 17,18},new Method("Lorg/mortbay/jetty/client/HttpExchange;","setStatus",new String[]{ "I"},"V"));
                code.visitLabel(L147);
                code.visitStmt1R(MONITOR_EXIT,21);
                code.visitLabel(L35);
                code.visitConstStmt(CONST_4,7, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitLabel(L37);
                code.visitStmt1R(THROW,5);
                code.visitLabel(L34);
                code.visitStmt1R(MOVE_EXCEPTION,17);
                DexLabel L271=new DexLabel();
                code.visitLabel(L271);
                code.visitConstStmt(CONST_4,4, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L148);
                code.visitStmt2R(MOVE,3,7);
                code.visitLabel(L149);
                code.visitJumpStmt(IF_NEZ,7,-1,L157);
                code.visitLabel(L150);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,21);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/client/HttpConnection;","_generator","Lorg/mortbay/jetty/HttpGenerator;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,18,0);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 18},new Method("Lorg/mortbay/jetty/HttpGenerator;","isComplete",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,18);
                code.visitJumpStmt(IF_EQZ,18,-1,L157);
                code.visitLabel(L151);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,21);
                code.visitFieldStmt(IGET_BOOLEAN,0,0,new Field("Lorg/mortbay/jetty/client/HttpConnection;","_requestComplete","Z"));
                code.visitStmt2R(MOVE_FROM16,18,0);
                code.visitJumpStmt(IF_NEZ,18,-1,L154);
                code.visitLabel(L152);
                code.visitConstStmt(CONST_16,18, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitStmt2R(MOVE_FROM16,0,18);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,21);
                code.visitFieldStmt(IPUT_BOOLEAN,0,1,new Field("Lorg/mortbay/jetty/client/HttpConnection;","_requestComplete","Z"));
                code.visitLabel(L153);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,21);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/client/HttpConnection;","_exchange","Lorg/mortbay/jetty/client/HttpExchange;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,18,0);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 18},new Method("Lorg/mortbay/jetty/client/HttpExchange;","getEventListener",new String[]{ },"Lorg/mortbay/jetty/client/HttpEventListener;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,18);
                code.visitMethodStmt(INVOKE_INTERFACE_RANGE,new int[]{ 18},new Method("Lorg/mortbay/jetty/client/HttpEventListener;","onRequestComplete",new String[]{ },"V"));
                code.visitLabel(L154);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,21);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/client/HttpConnection;","_parser","Lorg/mortbay/jetty/HttpParser;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,18,0);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 18},new Method("Lorg/mortbay/jetty/HttpParser;","isComplete",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,18);
                code.visitJumpStmt(IF_EQZ,18,-1,L157);
                code.visitLabel(L155);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,21);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/client/HttpConnection;","_destination","Lorg/mortbay/jetty/client/HttpDestination;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,18,0);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 18},new Method("Lorg/mortbay/jetty/client/HttpDestination;","getHttpClient",new String[]{ },"Lorg/mortbay/jetty/client/HttpClient;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,18);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,21);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/client/HttpConnection;","_timeout","Lorg/mortbay/thread/Timeout$Task;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,19,0);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 18,19},new Method("Lorg/mortbay/jetty/client/HttpClient;","cancel",new String[]{ "Lorg/mortbay/thread/Timeout$Task;"},"V"));
                code.visitLabel(L156);
                code.visitConstStmt(CONST_4,4, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitLabel(L157);
                code.visitJumpStmt(IF_NEZ,4,-1,L158);
                code.visitJumpStmt(IF_EQZ,7,-1,L52);
                code.visitLabel(L158);
                code.visitStmt1R(MONITOR_ENTER,21);
                code.visitLabel(L159);
                code.visitJumpStmt(IF_NEZ,3,-1,L160);
                code.visitLabel(L38);
                code.visitMethodStmt(INVOKE_DIRECT_RANGE,new int[]{ 21},new Method("Lorg/mortbay/jetty/client/HttpConnection;","shouldClose",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitLabel(L160);
                code.visitConstStmt(CONST_16,18, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,21);
                code.visitStmt2R(MOVE_FROM16,1,18);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Lorg/mortbay/jetty/client/HttpConnection;","reset",new String[]{ "Z"},"V"));
                code.visitLabel(L161);
                code.visitConstStmt(CONST_4,15, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L162);
                code.visitConstStmt(CONST_WIDE_16,10,Long.valueOf(-1L)); // long: 0xffffffffffffffff  double:NaN
                code.visitLabel(L163);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,21);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/client/HttpConnection;","_exchange","Lorg/mortbay/jetty/client/HttpExchange;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,18,0);
                code.visitJumpStmt(IF_EQZ,18,-1,L201);
                code.visitLabel(L164);
                code.visitConstStmt(CONST_16,18, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,18);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,21);
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/jetty/client/HttpConnection;","_exchange","Lorg/mortbay/jetty/client/HttpExchange;"));
                code.visitLabel(L165);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,21);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/client/HttpConnection;","_pipeline","Lorg/mortbay/jetty/client/HttpExchange;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,18,0);
                code.visitJumpStmt(IF_NEZ,18,-1,L202);
                code.visitLabel(L166);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 21},new Method("Lorg/mortbay/jetty/client/HttpConnection;","isReserved",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,18);
                code.visitJumpStmt(IF_NEZ,18,-1,L168);
                code.visitLabel(L167);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,21);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/client/HttpConnection;","_destination","Lorg/mortbay/jetty/client/HttpDestination;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,18,0);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,18);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,21);
                code.visitStmt2R(MOVE,2,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1,2},new Method("Lorg/mortbay/jetty/client/HttpDestination;","returnConnection",new String[]{ "Lorg/mortbay/jetty/client/HttpConnection;","Z"},"V"));
                code.visitLabel(L168);
                code.visitJumpStmt(IF_EQZ,3,-1,L201);
                code.visitLabel(L169);
                code.visitStmt1R(MONITOR_EXIT,21);
                code.visitJumpStmt(GOTO_16,-1,-1,L77);
                code.visitLabel(L40);
                code.visitStmt1R(MOVE_EXCEPTION,17);
                code.visitStmt1R(MONITOR_EXIT,21);
                code.visitLabel(L39);
                code.visitStmt1R(THROW,17);
                code.visitLabel(L41);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,21);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/client/HttpConnection;","_generator","Lorg/mortbay/jetty/HttpGenerator;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,17,0);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 17},new Method("Lorg/mortbay/jetty/HttpGenerator;","complete",new String[]{ },"V"));
                code.visitJumpStmt(GOTO_16,-1,-1,L144);
                code.visitLabel(L13);
                code.visitStmt1R(MOVE_EXCEPTION,17);
                code.visitStmt2R(MOVE_FROM16,15,16);
                code.visitLabel(L170);
                code.visitJumpStmt(GOTO_16,-1,-1,L271);
                code.visitLabel(L171);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,21);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/client/HttpConnection;","_generator","Lorg/mortbay/jetty/HttpGenerator;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,17,0);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 17},new Method("Lorg/mortbay/jetty/HttpGenerator;","complete",new String[]{ },"V"));
                code.visitLabel(L42);
                code.visitJumpStmt(GOTO_16,-1,-1,L86);
                code.visitLabel(L172);
                code.visitStmt2R1N(ADD_INT_LIT8,15,16,1);
                code.visitLabel(L173);
                code.visitConstStmt(CONST_16,17, Integer.valueOf(2)); // int: 0x00000002  float:0.000000
                code.visitStmt2R(MOVE_FROM16,0,16);
                code.visitStmt2R(MOVE_FROM16,1,17);
                code.visitJumpStmt(IF_LT,0,1,L91);
                code.visitLabel(L43);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,21);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/client/HttpConnection;","_endp","Lorg/mortbay/io/EndPoint;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,17,0);
                code.visitMethodStmt(INVOKE_INTERFACE_RANGE,new int[]{ 17},new Method("Lorg/mortbay/io/EndPoint;","isBlocking",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,17);
                code.visitJumpStmt(IF_NEZ,17,-1,L91);
                code.visitLabel(L174);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,21);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/client/HttpConnection;","_endp","Lorg/mortbay/io/EndPoint;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,17,0);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,17);
                code.visitTypeStmt(INSTANCE_OF,0,0,"Lorg/mortbay/jetty/security/SslHttpChannelEndPoint;");
                code.visitStmt2R(MOVE_FROM16,17,0);
                code.visitJumpStmt(IF_EQZ,17,-1,L225);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,21);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/client/HttpConnection;","_generator","Lorg/mortbay/jetty/HttpGenerator;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,17,0);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 17},new Method("Lorg/mortbay/jetty/HttpGenerator;","isComplete",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,17);
                code.visitJumpStmt(IF_NEZ,17,-1,L225);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,21);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/client/HttpConnection;","_generator","Lorg/mortbay/jetty/HttpGenerator;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,17,0);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 17},new Method("Lorg/mortbay/jetty/HttpGenerator;","isEmpty",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,17);
                code.visitJumpStmt(IF_NEZ,17,-1,L225);
                code.visitLabel(L175);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,21);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/client/HttpConnection;","_generator","Lorg/mortbay/jetty/HttpGenerator;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,17,0);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 17},new Method("Lorg/mortbay/jetty/HttpGenerator;","flush",new String[]{ },"J"));
                code.visitLabel(L44);
                code.visitStmt1R(MOVE_RESULT_WIDE,17);
                code.visitConstStmt(CONST_WIDE_16,19,Long.valueOf(0L)); // long: 0x0000000000000000  double:0.000000
                code.visitStmt3R(CMP_LONG,17,17,19);
                code.visitJumpStmt(IF_LEZ,17,-1,L225);
                code.visitLabel(L176);
                code.visitConstStmt(CONST_4,4, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L177);
                code.visitStmt2R(MOVE,3,7);
                code.visitLabel(L178);
                code.visitJumpStmt(IF_NEZ,7,-1,L186);
                code.visitLabel(L179);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,21);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/client/HttpConnection;","_generator","Lorg/mortbay/jetty/HttpGenerator;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,17,0);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 17},new Method("Lorg/mortbay/jetty/HttpGenerator;","isComplete",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,17);
                code.visitJumpStmt(IF_EQZ,17,-1,L186);
                code.visitLabel(L180);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,21);
                code.visitFieldStmt(IGET_BOOLEAN,0,0,new Field("Lorg/mortbay/jetty/client/HttpConnection;","_requestComplete","Z"));
                code.visitStmt2R(MOVE_FROM16,17,0);
                code.visitJumpStmt(IF_NEZ,17,-1,L183);
                code.visitLabel(L181);
                code.visitConstStmt(CONST_16,17, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitStmt2R(MOVE_FROM16,0,17);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,21);
                code.visitFieldStmt(IPUT_BOOLEAN,0,1,new Field("Lorg/mortbay/jetty/client/HttpConnection;","_requestComplete","Z"));
                code.visitLabel(L182);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,21);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/client/HttpConnection;","_exchange","Lorg/mortbay/jetty/client/HttpExchange;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,17,0);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 17},new Method("Lorg/mortbay/jetty/client/HttpExchange;","getEventListener",new String[]{ },"Lorg/mortbay/jetty/client/HttpEventListener;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,17);
                code.visitMethodStmt(INVOKE_INTERFACE_RANGE,new int[]{ 17},new Method("Lorg/mortbay/jetty/client/HttpEventListener;","onRequestComplete",new String[]{ },"V"));
                code.visitLabel(L183);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,21);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/client/HttpConnection;","_parser","Lorg/mortbay/jetty/HttpParser;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,17,0);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 17},new Method("Lorg/mortbay/jetty/HttpParser;","isComplete",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,17);
                code.visitJumpStmt(IF_EQZ,17,-1,L186);
                code.visitLabel(L184);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,21);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/client/HttpConnection;","_destination","Lorg/mortbay/jetty/client/HttpDestination;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,17,0);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 17},new Method("Lorg/mortbay/jetty/client/HttpDestination;","getHttpClient",new String[]{ },"Lorg/mortbay/jetty/client/HttpClient;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,17);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,21);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/client/HttpConnection;","_timeout","Lorg/mortbay/thread/Timeout$Task;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,18,0);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 17,18},new Method("Lorg/mortbay/jetty/client/HttpClient;","cancel",new String[]{ "Lorg/mortbay/thread/Timeout$Task;"},"V"));
                code.visitLabel(L185);
                code.visitConstStmt(CONST_4,4, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitLabel(L186);
                code.visitJumpStmt(IF_NEZ,4,-1,L187);
                code.visitJumpStmt(IF_EQZ,7,-1,L69);
                code.visitLabel(L187);
                code.visitStmt1R(MONITOR_ENTER,21);
                code.visitLabel(L188);
                code.visitJumpStmt(IF_NEZ,3,-1,L189);
                code.visitLabel(L46);
                code.visitMethodStmt(INVOKE_DIRECT_RANGE,new int[]{ 21},new Method("Lorg/mortbay/jetty/client/HttpConnection;","shouldClose",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitLabel(L189);
                code.visitConstStmt(CONST_16,17, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,21);
                code.visitStmt2R(MOVE_FROM16,1,17);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Lorg/mortbay/jetty/client/HttpConnection;","reset",new String[]{ "Z"},"V"));
                code.visitLabel(L190);
                code.visitConstStmt(CONST_4,15, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L191);
                code.visitConstStmt(CONST_WIDE_16,10,Long.valueOf(-1L)); // long: 0xffffffffffffffff  double:NaN
                code.visitLabel(L192);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,21);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/client/HttpConnection;","_exchange","Lorg/mortbay/jetty/client/HttpExchange;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,17,0);
                code.visitJumpStmt(IF_EQZ,17,-1,L218);
                code.visitLabel(L193);
                code.visitConstStmt(CONST_16,17, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,17);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,21);
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/jetty/client/HttpConnection;","_exchange","Lorg/mortbay/jetty/client/HttpExchange;"));
                code.visitLabel(L194);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,21);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/client/HttpConnection;","_pipeline","Lorg/mortbay/jetty/client/HttpExchange;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,17,0);
                code.visitJumpStmt(IF_NEZ,17,-1,L219);
                code.visitLabel(L195);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 21},new Method("Lorg/mortbay/jetty/client/HttpConnection;","isReserved",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,17);
                code.visitJumpStmt(IF_NEZ,17,-1,L197);
                code.visitLabel(L196);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,21);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/client/HttpConnection;","_destination","Lorg/mortbay/jetty/client/HttpDestination;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,17,0);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,17);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,21);
                code.visitStmt2R(MOVE,2,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1,2},new Method("Lorg/mortbay/jetty/client/HttpDestination;","returnConnection",new String[]{ "Lorg/mortbay/jetty/client/HttpConnection;","Z"},"V"));
                code.visitLabel(L197);
                code.visitJumpStmt(IF_EQZ,3,-1,L218);
                code.visitLabel(L198);
                code.visitStmt1R(MONITOR_EXIT,21);
                code.visitJumpStmt(GOTO_16,-1,-1,L77);
                code.visitLabel(L48);
                code.visitStmt1R(MOVE_EXCEPTION,17);
                code.visitStmt1R(MONITOR_EXIT,21);
                code.visitLabel(L47);
                code.visitStmt1R(THROW,17);
                code.visitLabel(L36);
                code.visitStmt1R(MOVE_EXCEPTION,17);
                code.visitLabel(L49);
                code.visitStmt1R(MONITOR_EXIT,21);
                code.visitLabel(L50);
                code.visitStmt1R(THROW,17);
                code.visitLabel(L51);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,21);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/client/HttpConnection;","_pipeline","Lorg/mortbay/jetty/client/HttpExchange;"));
                code.visitStmt2R(MOVE_OBJECT,6,0);
                code.visitLabel(L199);
                code.visitConstStmt(CONST_16,18, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,18);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,21);
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/jetty/client/HttpConnection;","_pipeline","Lorg/mortbay/jetty/client/HttpExchange;"));
                code.visitLabel(L200);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,21);
                code.visitStmt2R(MOVE_OBJECT,1,6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Lorg/mortbay/jetty/client/HttpConnection;","send",new String[]{ "Lorg/mortbay/jetty/client/HttpExchange;"},"Z"));
                code.visitLabel(L201);
                code.visitStmt1R(MONITOR_EXIT,21);
                code.visitLabel(L52);
                code.visitStmt1R(THROW,17);
                code.visitLabel(L202);
                code.visitJumpStmt(IF_EQZ,3,-1,L51);
                code.visitLabel(L53);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 21},new Method("Lorg/mortbay/jetty/client/HttpConnection;","isReserved",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,17);
                code.visitJumpStmt(IF_NEZ,17,-1,L204);
                code.visitLabel(L203);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,21);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/client/HttpConnection;","_destination","Lorg/mortbay/jetty/client/HttpDestination;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,17,0);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,17);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,21);
                code.visitStmt2R(MOVE,2,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1,2},new Method("Lorg/mortbay/jetty/client/HttpDestination;","returnConnection",new String[]{ "Lorg/mortbay/jetty/client/HttpConnection;","Z"},"V"));
                code.visitLabel(L204);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,21);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/client/HttpConnection;","_destination","Lorg/mortbay/jetty/client/HttpDestination;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,17,0);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,21);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/client/HttpConnection;","_pipeline","Lorg/mortbay/jetty/client/HttpExchange;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,18,0);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 17,18},new Method("Lorg/mortbay/jetty/client/HttpDestination;","send",new String[]{ "Lorg/mortbay/jetty/client/HttpExchange;"},"V"));
                code.visitLabel(L205);
                code.visitConstStmt(CONST_16,17, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,17);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,21);
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/jetty/client/HttpConnection;","_pipeline","Lorg/mortbay/jetty/client/HttpExchange;"));
                code.visitLabel(L206);
                code.visitStmt1R(MONITOR_EXIT,21);
                code.visitLabel(L54);
                code.visitJumpStmt(GOTO_16,-1,-1,L77);
                code.visitLabel(L55);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,21);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/client/HttpConnection;","_pipeline","Lorg/mortbay/jetty/client/HttpExchange;"));
                code.visitStmt2R(MOVE_OBJECT,6,0);
                code.visitLabel(L207);
                code.visitConstStmt(CONST_16,17, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,17);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,21);
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/jetty/client/HttpConnection;","_pipeline","Lorg/mortbay/jetty/client/HttpExchange;"));
                code.visitLabel(L208);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,21);
                code.visitStmt2R(MOVE_OBJECT,1,6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Lorg/mortbay/jetty/client/HttpConnection;","send",new String[]{ "Lorg/mortbay/jetty/client/HttpExchange;"},"Z"));
                code.visitLabel(L209);
                code.visitStmt1R(MONITOR_EXIT,21);
                code.visitJumpStmt(GOTO_16,-1,-1,L69);
                code.visitLabel(L210);
                code.visitJumpStmt(IF_EQZ,3,-1,L55);
                code.visitLabel(L211);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 21},new Method("Lorg/mortbay/jetty/client/HttpConnection;","isReserved",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,17);
                code.visitJumpStmt(IF_NEZ,17,-1,L213);
                code.visitLabel(L212);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,21);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/client/HttpConnection;","_destination","Lorg/mortbay/jetty/client/HttpDestination;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,17,0);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,17);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,21);
                code.visitStmt2R(MOVE,2,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1,2},new Method("Lorg/mortbay/jetty/client/HttpDestination;","returnConnection",new String[]{ "Lorg/mortbay/jetty/client/HttpConnection;","Z"},"V"));
                code.visitLabel(L213);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,21);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/client/HttpConnection;","_destination","Lorg/mortbay/jetty/client/HttpDestination;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,17,0);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,21);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/client/HttpConnection;","_pipeline","Lorg/mortbay/jetty/client/HttpExchange;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,18,0);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 17,18},new Method("Lorg/mortbay/jetty/client/HttpDestination;","send",new String[]{ "Lorg/mortbay/jetty/client/HttpExchange;"},"V"));
                code.visitLabel(L214);
                code.visitConstStmt(CONST_16,17, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,17);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,21);
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/jetty/client/HttpConnection;","_pipeline","Lorg/mortbay/jetty/client/HttpExchange;"));
                code.visitLabel(L215);
                code.visitStmt1R(MONITOR_EXIT,21);
                code.visitLabel(L56);
                code.visitJumpStmt(GOTO_16,-1,-1,L77);
                code.visitLabel(L57);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,21);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/client/HttpConnection;","_pipeline","Lorg/mortbay/jetty/client/HttpExchange;"));
                code.visitStmt2R(MOVE_OBJECT,6,0);
                code.visitLabel(L216);
                code.visitConstStmt(CONST_16,17, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,17);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,21);
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/jetty/client/HttpConnection;","_pipeline","Lorg/mortbay/jetty/client/HttpExchange;"));
                code.visitLabel(L217);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,21);
                code.visitStmt2R(MOVE_OBJECT,1,6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Lorg/mortbay/jetty/client/HttpConnection;","send",new String[]{ "Lorg/mortbay/jetty/client/HttpExchange;"},"Z"));
                code.visitLabel(L218);
                code.visitStmt1R(MONITOR_EXIT,21);
                code.visitJumpStmt(GOTO_16,-1,-1,L69);
                code.visitLabel(L219);
                code.visitJumpStmt(IF_EQZ,3,-1,L57);
                code.visitLabel(L220);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 21},new Method("Lorg/mortbay/jetty/client/HttpConnection;","isReserved",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,17);
                code.visitJumpStmt(IF_NEZ,17,-1,L222);
                code.visitLabel(L221);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,21);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/client/HttpConnection;","_destination","Lorg/mortbay/jetty/client/HttpDestination;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,17,0);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,17);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,21);
                code.visitStmt2R(MOVE,2,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1,2},new Method("Lorg/mortbay/jetty/client/HttpDestination;","returnConnection",new String[]{ "Lorg/mortbay/jetty/client/HttpConnection;","Z"},"V"));
                code.visitLabel(L222);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,21);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/client/HttpConnection;","_destination","Lorg/mortbay/jetty/client/HttpDestination;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,17,0);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,21);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/client/HttpConnection;","_pipeline","Lorg/mortbay/jetty/client/HttpExchange;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,18,0);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 17,18},new Method("Lorg/mortbay/jetty/client/HttpDestination;","send",new String[]{ "Lorg/mortbay/jetty/client/HttpExchange;"},"V"));
                code.visitLabel(L223);
                code.visitConstStmt(CONST_16,17, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,17);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,21);
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/jetty/client/HttpConnection;","_pipeline","Lorg/mortbay/jetty/client/HttpExchange;"));
                code.visitLabel(L224);
                code.visitStmt1R(MONITOR_EXIT,21);
                code.visitLabel(L58);
                code.visitJumpStmt(GOTO_16,-1,-1,L77);
                code.visitLabel(L225);
                code.visitConstStmt(CONST_4,4, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L226);
                code.visitStmt2R(MOVE,3,7);
                code.visitLabel(L227);
                code.visitJumpStmt(IF_NEZ,7,-1,L235);
                code.visitLabel(L228);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,21);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/client/HttpConnection;","_generator","Lorg/mortbay/jetty/HttpGenerator;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,17,0);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 17},new Method("Lorg/mortbay/jetty/HttpGenerator;","isComplete",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,17);
                code.visitJumpStmt(IF_EQZ,17,-1,L235);
                code.visitLabel(L229);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,21);
                code.visitFieldStmt(IGET_BOOLEAN,0,0,new Field("Lorg/mortbay/jetty/client/HttpConnection;","_requestComplete","Z"));
                code.visitStmt2R(MOVE_FROM16,17,0);
                code.visitJumpStmt(IF_NEZ,17,-1,L232);
                code.visitLabel(L230);
                code.visitConstStmt(CONST_16,17, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitStmt2R(MOVE_FROM16,0,17);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,21);
                code.visitFieldStmt(IPUT_BOOLEAN,0,1,new Field("Lorg/mortbay/jetty/client/HttpConnection;","_requestComplete","Z"));
                code.visitLabel(L231);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,21);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/client/HttpConnection;","_exchange","Lorg/mortbay/jetty/client/HttpExchange;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,17,0);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 17},new Method("Lorg/mortbay/jetty/client/HttpExchange;","getEventListener",new String[]{ },"Lorg/mortbay/jetty/client/HttpEventListener;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,17);
                code.visitMethodStmt(INVOKE_INTERFACE_RANGE,new int[]{ 17},new Method("Lorg/mortbay/jetty/client/HttpEventListener;","onRequestComplete",new String[]{ },"V"));
                code.visitLabel(L232);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,21);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/client/HttpConnection;","_parser","Lorg/mortbay/jetty/HttpParser;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,17,0);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 17},new Method("Lorg/mortbay/jetty/HttpParser;","isComplete",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,17);
                code.visitJumpStmt(IF_EQZ,17,-1,L235);
                code.visitLabel(L233);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,21);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/client/HttpConnection;","_destination","Lorg/mortbay/jetty/client/HttpDestination;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,17,0);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 17},new Method("Lorg/mortbay/jetty/client/HttpDestination;","getHttpClient",new String[]{ },"Lorg/mortbay/jetty/client/HttpClient;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,17);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,21);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/client/HttpConnection;","_timeout","Lorg/mortbay/thread/Timeout$Task;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,18,0);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 17,18},new Method("Lorg/mortbay/jetty/client/HttpClient;","cancel",new String[]{ "Lorg/mortbay/thread/Timeout$Task;"},"V"));
                code.visitLabel(L234);
                code.visitConstStmt(CONST_4,4, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitLabel(L235);
                code.visitJumpStmt(IF_NEZ,4,-1,L236);
                code.visitJumpStmt(IF_EQZ,7,-1,L77);
                code.visitLabel(L236);
                code.visitStmt1R(MONITOR_ENTER,21);
                code.visitLabel(L237);
                code.visitJumpStmt(IF_NEZ,3,-1,L238);
                code.visitLabel(L59);
                code.visitMethodStmt(INVOKE_DIRECT_RANGE,new int[]{ 21},new Method("Lorg/mortbay/jetty/client/HttpConnection;","shouldClose",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitLabel(L238);
                code.visitConstStmt(CONST_16,17, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,21);
                code.visitStmt2R(MOVE_FROM16,1,17);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Lorg/mortbay/jetty/client/HttpConnection;","reset",new String[]{ "Z"},"V"));
                code.visitLabel(L239);
                code.visitConstStmt(CONST_4,15, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L240);
                code.visitConstStmt(CONST_WIDE_16,10,Long.valueOf(-1L)); // long: 0xffffffffffffffff  double:NaN
                code.visitLabel(L241);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,21);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/client/HttpConnection;","_exchange","Lorg/mortbay/jetty/client/HttpExchange;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,17,0);
                code.visitJumpStmt(IF_EQZ,17,-1,L250);
                code.visitLabel(L242);
                code.visitConstStmt(CONST_16,17, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,17);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,21);
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/jetty/client/HttpConnection;","_exchange","Lorg/mortbay/jetty/client/HttpExchange;"));
                code.visitLabel(L243);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,21);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/client/HttpConnection;","_pipeline","Lorg/mortbay/jetty/client/HttpExchange;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,17,0);
                code.visitJumpStmt(IF_NEZ,17,-1,L251);
                code.visitLabel(L244);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 21},new Method("Lorg/mortbay/jetty/client/HttpConnection;","isReserved",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,17);
                code.visitJumpStmt(IF_NEZ,17,-1,L246);
                code.visitLabel(L245);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,21);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/client/HttpConnection;","_destination","Lorg/mortbay/jetty/client/HttpDestination;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,17,0);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,17);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,21);
                code.visitStmt2R(MOVE,2,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1,2},new Method("Lorg/mortbay/jetty/client/HttpDestination;","returnConnection",new String[]{ "Lorg/mortbay/jetty/client/HttpConnection;","Z"},"V"));
                code.visitLabel(L246);
                code.visitJumpStmt(IF_EQZ,3,-1,L250);
                code.visitLabel(L247);
                code.visitStmt1R(MONITOR_EXIT,21);
                code.visitJumpStmt(GOTO_16,-1,-1,L77);
                code.visitLabel(L61);
                code.visitStmt1R(MOVE_EXCEPTION,17);
                code.visitStmt1R(MONITOR_EXIT,21);
                code.visitLabel(L60);
                code.visitStmt1R(THROW,17);
                code.visitLabel(L62);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,21);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/client/HttpConnection;","_pipeline","Lorg/mortbay/jetty/client/HttpExchange;"));
                code.visitStmt2R(MOVE_OBJECT,6,0);
                code.visitLabel(L248);
                code.visitConstStmt(CONST_16,17, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,17);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,21);
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/jetty/client/HttpConnection;","_pipeline","Lorg/mortbay/jetty/client/HttpExchange;"));
                code.visitLabel(L249);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,21);
                code.visitStmt2R(MOVE_OBJECT,1,6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Lorg/mortbay/jetty/client/HttpConnection;","send",new String[]{ "Lorg/mortbay/jetty/client/HttpExchange;"},"Z"));
                code.visitLabel(L250);
                code.visitStmt1R(MONITOR_EXIT,21);
                code.visitJumpStmt(GOTO_16,-1,-1,L77);
                code.visitLabel(L251);
                code.visitJumpStmt(IF_EQZ,3,-1,L62);
                code.visitLabel(L252);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 21},new Method("Lorg/mortbay/jetty/client/HttpConnection;","isReserved",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,17);
                code.visitJumpStmt(IF_NEZ,17,-1,L254);
                code.visitLabel(L253);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,21);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/client/HttpConnection;","_destination","Lorg/mortbay/jetty/client/HttpDestination;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,17,0);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,17);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,21);
                code.visitStmt2R(MOVE,2,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1,2},new Method("Lorg/mortbay/jetty/client/HttpDestination;","returnConnection",new String[]{ "Lorg/mortbay/jetty/client/HttpConnection;","Z"},"V"));
                code.visitLabel(L254);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,21);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/client/HttpConnection;","_destination","Lorg/mortbay/jetty/client/HttpDestination;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,17,0);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,21);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/client/HttpConnection;","_pipeline","Lorg/mortbay/jetty/client/HttpExchange;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,18,0);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 17,18},new Method("Lorg/mortbay/jetty/client/HttpDestination;","send",new String[]{ "Lorg/mortbay/jetty/client/HttpExchange;"},"V"));
                code.visitLabel(L255);
                code.visitConstStmt(CONST_16,17, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,17);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,21);
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/jetty/client/HttpConnection;","_pipeline","Lorg/mortbay/jetty/client/HttpExchange;"));
                code.visitLabel(L256);
                code.visitStmt1R(MONITOR_EXIT,21);
                code.visitLabel(L63);
                code.visitJumpStmt(GOTO_16,-1,-1,L77);
                code.visitLabel(L64);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,21);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/client/HttpConnection;","_pipeline","Lorg/mortbay/jetty/client/HttpExchange;"));
                code.visitStmt2R(MOVE_OBJECT,6,0);
                code.visitLabel(L257);
                code.visitConstStmt(CONST_16,17, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,17);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,21);
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/jetty/client/HttpConnection;","_pipeline","Lorg/mortbay/jetty/client/HttpExchange;"));
                code.visitLabel(L258);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,21);
                code.visitStmt2R(MOVE_OBJECT,1,6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Lorg/mortbay/jetty/client/HttpConnection;","send",new String[]{ "Lorg/mortbay/jetty/client/HttpExchange;"},"Z"));
                code.visitLabel(L259);
                code.visitStmt1R(MONITOR_EXIT,21);
                code.visitJumpStmt(GOTO_16,-1,-1,L69);
                code.visitLabel(L260);
                code.visitJumpStmt(IF_EQZ,3,-1,L64);
                code.visitLabel(L261);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 21},new Method("Lorg/mortbay/jetty/client/HttpConnection;","isReserved",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,17);
                code.visitJumpStmt(IF_NEZ,17,-1,L263);
                code.visitLabel(L262);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,21);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/client/HttpConnection;","_destination","Lorg/mortbay/jetty/client/HttpDestination;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,17,0);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,17);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,21);
                code.visitStmt2R(MOVE,2,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1,2},new Method("Lorg/mortbay/jetty/client/HttpDestination;","returnConnection",new String[]{ "Lorg/mortbay/jetty/client/HttpConnection;","Z"},"V"));
                code.visitLabel(L263);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,21);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/client/HttpConnection;","_destination","Lorg/mortbay/jetty/client/HttpDestination;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,17,0);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,21);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/client/HttpConnection;","_pipeline","Lorg/mortbay/jetty/client/HttpExchange;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,18,0);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 17,18},new Method("Lorg/mortbay/jetty/client/HttpDestination;","send",new String[]{ "Lorg/mortbay/jetty/client/HttpExchange;"},"V"));
                code.visitLabel(L264);
                code.visitConstStmt(CONST_16,17, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,17);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,21);
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/jetty/client/HttpConnection;","_pipeline","Lorg/mortbay/jetty/client/HttpExchange;"));
                code.visitLabel(L265);
                code.visitStmt1R(MONITOR_EXIT,21);
                code.visitLabel(L65);
                code.visitJumpStmt(GOTO_16,-1,-1,L77);
                code.visitLabel(L23);
                code.visitStmt1R(MOVE_EXCEPTION,17);
                code.visitStmt2R(MOVE_FROM16,15,16);
                code.visitLabel(L266);
                code.visitJumpStmt(GOTO_16,-1,-1,L270);
                code.visitLabel(L45);
                code.visitStmt1R(MOVE_EXCEPTION,17);
                code.visitStmt2R(MOVE_OBJECT_FROM16,5,17);
                code.visitJumpStmt(GOTO_16,-1,-1,L32);
                code.visitLabel(L267);
                code.visitStmt2R(MOVE_FROM16,15,16);
                code.visitLabel(L268);
                code.visitJumpStmt(GOTO_16,-1,-1,L69);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m009_isIdle(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/client/HttpConnection;","isIdle",new String[]{ },"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L3=new DexLabel();
                ddv.visitPrologue(L3);
                ddv.visitLineNumber(373,L3);
                ddv.visitLineNumber(375,L0);
                ddv.visitLineNumber(376,L2);
                code.visitLabel(L3);
                code.visitStmt1R(MONITOR_ENTER,1);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/client/HttpConnection;","_exchange","Lorg/mortbay/jetty/client/HttpExchange;"));
                DexLabel L4=new DexLabel();
                code.visitJumpStmt(IF_NEZ,0,-1,L4);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                DexLabel L5=new DexLabel();
                code.visitLabel(L5);
                code.visitStmt1R(MONITOR_EXIT,1);
                code.visitStmt1R(RETURN,0);
                code.visitLabel(L4);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L5);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,0);
                code.visitStmt1R(MONITOR_EXIT,1);
                code.visitLabel(L1);
                code.visitStmt1R(THROW,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m010_isReserved(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/client/HttpConnection;","isReserved",new String[]{ },"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(125,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_BOOLEAN,0,1,new Field("Lorg/mortbay/jetty/client/HttpConnection;","_reserved","Z"));
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m011_reset(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Lorg/mortbay/jetty/client/HttpConnection;","reset",new String[]{ "Z"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"returnBuffers");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(453,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(454,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(455,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(456,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(457,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(458,L5);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT_BOOLEAN,0,1,new Field("Lorg/mortbay/jetty/client/HttpConnection;","_requestComplete","Z"));
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/jetty/client/HttpConnection;","_connectionHeader","Lorg/mortbay/io/Buffer;"));
                code.visitLabel(L2);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/client/HttpConnection;","_parser","Lorg/mortbay/jetty/HttpParser;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,2},new Method("Lorg/mortbay/jetty/HttpParser;","reset",new String[]{ "Z"},"V"));
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/client/HttpConnection;","_generator","Lorg/mortbay/jetty/HttpGenerator;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,2},new Method("Lorg/mortbay/jetty/HttpGenerator;","reset",new String[]{ "Z"},"V"));
                code.visitLabel(L4);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitFieldStmt(IPUT_BOOLEAN,0,1,new Field("Lorg/mortbay/jetty/client/HttpConnection;","_http11","Z"));
                code.visitLabel(L5);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m012_send(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/client/HttpConnection;","send",new String[]{ "Lorg/mortbay/jetty/client/HttpExchange;"},"Z"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(6);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexLabel L3=new DexLabel();
                DexLabel L4=new DexLabel();
                code.visitTryCatch(L3,L4,new DexLabel[]{L2},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"ex");
                DexLabel L5=new DexLabel();
                ddv.visitPrologue(L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(146,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(147,L7);
                ddv.visitLineNumber(149,L0);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(151,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(152,L9);
                ddv.visitLineNumber(175,L2);
                ddv.visitLineNumber(153,L3);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(154,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(174,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(157,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(158,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(160,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(161,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(163,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(164,L17);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(171,L18);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(172,L19);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(174,L20);
                DexLabel L21=new DexLabel();
                ddv.visitLineNumber(167,L21);
                DexLabel L22=new DexLabel();
                ddv.visitLineNumber(168,L22);
                ddv.visitStartLocal(0,L22,"scep","Lorg/mortbay/io/nio/SelectChannelEndPoint;",null);
                code.visitLabel(L5);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitLabel(L6);
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Ljava/lang/Throwable;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1},new Method("Ljava/lang/Throwable;","<init>",new String[]{ },"V"));
                code.visitFieldStmt(IPUT_OBJECT,1,4,new Field("Lorg/mortbay/jetty/client/HttpConnection;","_throwable","Ljava/lang/Throwable;"));
                code.visitLabel(L7);
                code.visitStmt1R(MONITOR_ENTER,4);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,1,4,new Field("Lorg/mortbay/jetty/client/HttpConnection;","_exchange","Lorg/mortbay/jetty/client/HttpExchange;"));
                code.visitJumpStmt(IF_EQZ,1,-1,L12);
                code.visitLabel(L8);
                code.visitFieldStmt(IGET_OBJECT,1,4,new Field("Lorg/mortbay/jetty/client/HttpConnection;","_pipeline","Lorg/mortbay/jetty/client/HttpExchange;"));
                code.visitJumpStmt(IF_EQZ,1,-1,L3);
                code.visitLabel(L9);
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Ljava/lang/IllegalStateException;");
                code.visitTypeStmt(NEW_INSTANCE,2,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,4},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitConstStmt(CONST_STRING,3," PIPELINED!!!  _exchange=");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitFieldStmt(IGET_OBJECT,3,4,new Field("Lorg/mortbay/jetty/client/HttpConnection;","_exchange","Lorg/mortbay/jetty/client/HttpExchange;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1,2},new Method("Ljava/lang/IllegalStateException;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitStmt1R(THROW,1);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,1);
                code.visitStmt1R(MONITOR_EXIT,4);
                code.visitLabel(L1);
                code.visitStmt1R(THROW,1);
                code.visitLabel(L3);
                code.visitFieldStmt(IPUT_OBJECT,5,4,new Field("Lorg/mortbay/jetty/client/HttpConnection;","_pipeline","Lorg/mortbay/jetty/client/HttpExchange;"));
                code.visitLabel(L10);
                code.visitStmt1R(MONITOR_EXIT,4);
                code.visitStmt2R(MOVE,1,3);
                code.visitLabel(L11);
                code.visitStmt1R(RETURN,1);
                code.visitLabel(L12);
                code.visitFieldStmt(IGET_OBJECT,1,4,new Field("Lorg/mortbay/jetty/client/HttpConnection;","_endp","Lorg/mortbay/io/EndPoint;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 1},new Method("Lorg/mortbay/io/EndPoint;","isOpen",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitJumpStmt(IF_NEZ,1,-1,L14);
                code.visitLabel(L13);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitStmt1R(MONITOR_EXIT,4);
                code.visitJumpStmt(GOTO,-1,-1,L11);
                code.visitLabel(L14);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(2)); // int: 0x00000002  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,1},new Method("Lorg/mortbay/jetty/client/HttpExchange;","setStatus",new String[]{ "I"},"V"));
                code.visitLabel(L15);
                code.visitFieldStmt(IPUT_OBJECT,5,4,new Field("Lorg/mortbay/jetty/client/HttpConnection;","_exchange","Lorg/mortbay/jetty/client/HttpExchange;"));
                code.visitLabel(L16);
                code.visitFieldStmt(IGET_OBJECT,1,4,new Field("Lorg/mortbay/jetty/client/HttpConnection;","_endp","Lorg/mortbay/io/EndPoint;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 1},new Method("Lorg/mortbay/io/EndPoint;","isBlocking",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitJumpStmt(IF_EQZ,1,-1,L21);
                code.visitLabel(L17);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Ljava/lang/Object;","notify",new String[]{ },"V"));
                code.visitLabel(L18);
                code.visitFieldStmt(IGET_OBJECT,1,4,new Field("Lorg/mortbay/jetty/client/HttpConnection;","_endp","Lorg/mortbay/io/EndPoint;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 1},new Method("Lorg/mortbay/io/EndPoint;","isBlocking",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitJumpStmt(IF_NEZ,1,-1,L20);
                code.visitLabel(L19);
                code.visitFieldStmt(IGET_OBJECT,1,4,new Field("Lorg/mortbay/jetty/client/HttpConnection;","_destination","Lorg/mortbay/jetty/client/HttpDestination;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Lorg/mortbay/jetty/client/HttpDestination;","getHttpClient",new String[]{ },"Lorg/mortbay/jetty/client/HttpClient;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitFieldStmt(IGET_OBJECT,2,4,new Field("Lorg/mortbay/jetty/client/HttpConnection;","_timeout","Lorg/mortbay/thread/Timeout$Task;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2},new Method("Lorg/mortbay/jetty/client/HttpClient;","schedule",new String[]{ "Lorg/mortbay/thread/Timeout$Task;"},"V"));
                code.visitLabel(L20);
                code.visitStmt1R(MONITOR_EXIT,4);
                code.visitStmt2R(MOVE,1,3);
                code.visitJumpStmt(GOTO,-1,-1,L11);
                code.visitLabel(L21);
                code.visitFieldStmt(IGET_OBJECT,0,4,new Field("Lorg/mortbay/jetty/client/HttpConnection;","_endp","Lorg/mortbay/io/EndPoint;"));
                code.visitTypeStmt(CHECK_CAST,0,-1,"Lorg/mortbay/io/nio/SelectChannelEndPoint;");
                code.visitLabel(L22);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/io/nio/SelectChannelEndPoint;","scheduleWrite",new String[]{ },"V"));
                code.visitLabel(L4);
                code.visitJumpStmt(GOTO,-1,-1,L18);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m013_setDestination(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/client/HttpConnection;","setDestination",new String[]{ "Lorg/mortbay/jetty/client/HttpDestination;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"destination");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(137,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(138,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_OBJECT,1,0,new Field("Lorg/mortbay/jetty/client/HttpConnection;","_destination","Lorg/mortbay/jetty/client/HttpDestination;"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m014_setLast(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/client/HttpConnection;","setLast",new String[]{ "J"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"last");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(565,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(566,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_WIDE,1,0,new Field("Lorg/mortbay/jetty/client/HttpConnection;","_last","J"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m015_setReserved(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/client/HttpConnection;","setReserved",new String[]{ "Z"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"reserved");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(120,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(121,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_BOOLEAN,1,0,new Field("Lorg/mortbay/jetty/client/HttpConnection;","_reserved","Z"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m016_toDetailString(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/client/HttpConnection;","toDetailString",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(546,L0);
                code.visitLabel(L0);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Lorg/mortbay/jetty/client/HttpConnection;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitConstStmt(CONST_STRING,1," ex=");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(IGET_OBJECT,1,3,new Field("Lorg/mortbay/jetty/client/HttpConnection;","_exchange","Lorg/mortbay/jetty/client/HttpExchange;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitConstStmt(CONST_STRING,1," ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(IGET_OBJECT,1,3,new Field("Lorg/mortbay/jetty/client/HttpConnection;","_timeout","Lorg/mortbay/thread/Timeout$Task;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Lorg/mortbay/thread/Timeout$Task;","getAge",new String[]{ },"J"));
                code.visitStmt1R(MOVE_RESULT_WIDE,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1,2},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "J"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m017_toString(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/client/HttpConnection;","toString",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(540,L0);
                code.visitLabel(L0);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,1,"HttpConnection@");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Ljava/lang/Object;","hashCode",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "I"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitConstStmt(CONST_STRING,1,"//");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/jetty/client/HttpConnection;","_destination","Lorg/mortbay/jetty/client/HttpDestination;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Lorg/mortbay/jetty/client/HttpDestination;","getAddress",new String[]{ },"Lorg/mortbay/jetty/client/Address;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Lorg/mortbay/jetty/client/Address;","getHost",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitConstStmt(CONST_STRING,1,":");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/jetty/client/HttpConnection;","_destination","Lorg/mortbay/jetty/client/HttpDestination;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Lorg/mortbay/jetty/client/HttpDestination;","getAddress",new String[]{ },"Lorg/mortbay/jetty/client/Address;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Lorg/mortbay/jetty/client/Address;","getPort",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "I"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
