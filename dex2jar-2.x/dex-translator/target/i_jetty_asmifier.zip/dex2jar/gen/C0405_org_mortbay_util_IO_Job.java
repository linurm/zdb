package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0405_org_mortbay_util_IO_Job {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(0,"Lorg/mortbay/util/IO$Job;","Ljava/lang/Object;",new String[]{ "Ljava/lang/Runnable;"});
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("IO.java");
        if(cv!=null){
            DexAnnotationVisitor av00 = cv.visitAnnotation("Ldalvik/annotation/EnclosingClass;", Visibility.SYSTEM);
            if(av00 != null) {
                av00.visit("value", new DexType("Lorg/mortbay/util/IO;"));
                av00.visitEnd();
            }
        }
        if(cv!=null){
            DexAnnotationVisitor av00 = cv.visitAnnotation("Ldalvik/annotation/InnerClass;", Visibility.SYSTEM);
            if(av00 != null) {
                av00.visit("accessFlags",  Integer.valueOf(8));
                av00.visit("name", "Job");
                av00.visitEnd();
            }
        }
        f000_in(cv);
        f001_out(cv);
        f002_read(cv);
        f003_write(cv);
        m000__init_(cv);
        m001__init_(cv);
        m002_run(cv);
    }
    public static void f000_in(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(0, new Field("Lorg/mortbay/util/IO$Job;","in","Ljava/io/InputStream;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f001_out(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(0, new Field("Lorg/mortbay/util/IO$Job;","out","Ljava/io/OutputStream;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f002_read(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(0, new Field("Lorg/mortbay/util/IO$Job;","read","Ljava/io/Reader;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f003_write(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(0, new Field("Lorg/mortbay/util/IO$Job;","write","Ljava/io/Writer;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void m000__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_CONSTRUCTOR, new Method("Lorg/mortbay/util/IO$Job;","<init>",new String[]{ "Ljava/io/InputStream;","Ljava/io/OutputStream;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"in");
                ddv.visitParameterName(1,"out");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(75,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(76,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(77,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(78,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(79,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(80,L6);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1},new Method("Ljava/lang/Object;","<init>",new String[]{ },"V"));
                code.visitLabel(L2);
                code.visitFieldStmt(IPUT_OBJECT,2,1,new Field("Lorg/mortbay/util/IO$Job;","in","Ljava/io/InputStream;"));
                code.visitLabel(L3);
                code.visitFieldStmt(IPUT_OBJECT,3,1,new Field("Lorg/mortbay/util/IO$Job;","out","Ljava/io/OutputStream;"));
                code.visitLabel(L4);
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/util/IO$Job;","read","Ljava/io/Reader;"));
                code.visitLabel(L5);
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/util/IO$Job;","write","Ljava/io/Writer;"));
                code.visitLabel(L6);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_CONSTRUCTOR, new Method("Lorg/mortbay/util/IO$Job;","<init>",new String[]{ "Ljava/io/Reader;","Ljava/io/Writer;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"read");
                ddv.visitParameterName(1,"write");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(82,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(83,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(84,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(85,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(86,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(87,L6);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1},new Method("Ljava/lang/Object;","<init>",new String[]{ },"V"));
                code.visitLabel(L2);
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/util/IO$Job;","in","Ljava/io/InputStream;"));
                code.visitLabel(L3);
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/util/IO$Job;","out","Ljava/io/OutputStream;"));
                code.visitLabel(L4);
                code.visitFieldStmt(IPUT_OBJECT,2,1,new Field("Lorg/mortbay/util/IO$Job;","read","Ljava/io/Reader;"));
                code.visitLabel(L5);
                code.visitFieldStmt(IPUT_OBJECT,3,1,new Field("Lorg/mortbay/util/IO$Job;","write","Ljava/io/Writer;"));
                code.visitLabel(L6);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m002_run(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/util/IO$Job;","run",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(7);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ "Ljava/io/IOException;"});
                DexLabel L3=new DexLabel();
                DexLabel L4=new DexLabel();
                DexLabel L5=new DexLabel();
                code.visitTryCatch(L3,L4,new DexLabel[]{L5},new String[]{ "Ljava/io/IOException;"});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(96,L0);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(97,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(115,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(99,L8);
                ddv.visitLineNumber(101,L2);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(103,L9);
                ddv.visitStartLocal(0,L9,"e","Ljava/io/IOException;",null);
                ddv.visitLineNumber(105,L3);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(106,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(107,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(108,L12);
                ddv.visitLineNumber(110,L5);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(112,L13);
                ddv.visitStartLocal(1,L13,"e2","Ljava/io/IOException;",null);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,2,6,new Field("Lorg/mortbay/util/IO$Job;","in","Ljava/io/InputStream;"));
                code.visitJumpStmt(IF_EQZ,2,-1,L8);
                code.visitLabel(L6);
                code.visitFieldStmt(IGET_OBJECT,2,6,new Field("Lorg/mortbay/util/IO$Job;","in","Ljava/io/InputStream;"));
                code.visitFieldStmt(IGET_OBJECT,3,6,new Field("Lorg/mortbay/util/IO$Job;","out","Ljava/io/OutputStream;"));
                code.visitConstStmt(CONST_WIDE_16,4,Long.valueOf(-1L)); // long: 0xffffffffffffffff  double:NaN
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 2,3,4,5},new Method("Lorg/mortbay/util/IO;","copy",new String[]{ "Ljava/io/InputStream;","Ljava/io/OutputStream;","J"},"V"));
                code.visitLabel(L7);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L8);
                code.visitFieldStmt(IGET_OBJECT,2,6,new Field("Lorg/mortbay/util/IO$Job;","read","Ljava/io/Reader;"));
                code.visitFieldStmt(IGET_OBJECT,3,6,new Field("Lorg/mortbay/util/IO$Job;","write","Ljava/io/Writer;"));
                code.visitConstStmt(CONST_WIDE_16,4,Long.valueOf(-1L)); // long: 0xffffffffffffffff  double:NaN
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 2,3,4,5},new Method("Lorg/mortbay/util/IO;","copy",new String[]{ "Ljava/io/Reader;","Ljava/io/Writer;","J"},"V"));
                code.visitLabel(L1);
                code.visitJumpStmt(GOTO,-1,-1,L7);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,2);
                code.visitStmt2R(MOVE_OBJECT,0,2);
                code.visitLabel(L9);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0},new Method("Lorg/mortbay/log/Log;","ignore",new String[]{ "Ljava/lang/Throwable;"},"V"));
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,2,6,new Field("Lorg/mortbay/util/IO$Job;","out","Ljava/io/OutputStream;"));
                code.visitJumpStmt(IF_EQZ,2,-1,L11);
                code.visitLabel(L10);
                code.visitFieldStmt(IGET_OBJECT,2,6,new Field("Lorg/mortbay/util/IO$Job;","out","Ljava/io/OutputStream;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Ljava/io/OutputStream;","close",new String[]{ },"V"));
                code.visitLabel(L11);
                code.visitFieldStmt(IGET_OBJECT,2,6,new Field("Lorg/mortbay/util/IO$Job;","write","Ljava/io/Writer;"));
                code.visitJumpStmt(IF_EQZ,2,-1,L7);
                code.visitLabel(L12);
                code.visitFieldStmt(IGET_OBJECT,2,6,new Field("Lorg/mortbay/util/IO$Job;","write","Ljava/io/Writer;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Ljava/io/Writer;","close",new String[]{ },"V"));
                code.visitLabel(L4);
                code.visitJumpStmt(GOTO,-1,-1,L7);
                code.visitLabel(L5);
                code.visitStmt1R(MOVE_EXCEPTION,2);
                code.visitStmt2R(MOVE_OBJECT,1,2);
                code.visitLabel(L13);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1},new Method("Lorg/mortbay/log/Log;","ignore",new String[]{ "Ljava/lang/Throwable;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L7);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
