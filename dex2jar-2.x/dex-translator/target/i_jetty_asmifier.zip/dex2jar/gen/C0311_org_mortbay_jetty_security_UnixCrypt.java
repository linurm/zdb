package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0311_org_mortbay_jetty_security_UnixCrypt {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(ACC_PUBLIC,"Lorg/mortbay/jetty/security/UnixCrypt;","Ljava/lang/Object;",new String[]{ });
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("UnixCrypt.java");
        f000_A64TOI(cv);
        f001_CF6464(cv);
        f002_CIFP(cv);
        f003_ExpandTr(cv);
        f004_IE3264(cv);
        f005_IP(cv);
        f006_ITOA64(cv);
        f007_P32Tr(cv);
        f008_PC1(cv);
        f009_PC1ROT(cv);
        f010_PC2(cv);
        f011_PC2ROT(cv);
        f012_Rotates(cv);
        f013_S(cv);
        f014_SPE(cv);
        m000__clinit_(cv);
        m001__init_(cv);
        m002_crypt(cv);
        m003_des_cipher(cv);
        m004_des_setkey(cv);
        m005_init_perm(cv);
        m006_main(cv);
        m007_perm3264(cv);
        m008_perm6464(cv);
        m009_to_six_bit(cv);
        m010_to_six_bit(cv);
    }
    public static void f000_A64TOI(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE|ACC_STATIC, new Field("Lorg/mortbay/jetty/security/UnixCrypt;","A64TOI","[B"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f001_CF6464(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE|ACC_STATIC, new Field("Lorg/mortbay/jetty/security/UnixCrypt;","CF6464","[[J"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f002_CIFP(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/security/UnixCrypt;","CIFP","[B"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f003_ExpandTr(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/security/UnixCrypt;","ExpandTr","[B"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f004_IE3264(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE|ACC_STATIC, new Field("Lorg/mortbay/jetty/security/UnixCrypt;","IE3264","[[J"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f005_IP(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/security/UnixCrypt;","IP","[B"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f006_ITOA64(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/security/UnixCrypt;","ITOA64","[B"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f007_P32Tr(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/security/UnixCrypt;","P32Tr","[B"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f008_PC1(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/security/UnixCrypt;","PC1","[B"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f009_PC1ROT(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE|ACC_STATIC, new Field("Lorg/mortbay/jetty/security/UnixCrypt;","PC1ROT","[[J"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f010_PC2(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/security/UnixCrypt;","PC2","[B"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f011_PC2ROT(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE|ACC_STATIC, new Field("Lorg/mortbay/jetty/security/UnixCrypt;","PC2ROT","[[[J"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f012_Rotates(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/security/UnixCrypt;","Rotates","[B"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f013_S(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/security/UnixCrypt;","S","[[B"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f014_SPE(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE|ACC_STATIC, new Field("Lorg/mortbay/jetty/security/UnixCrypt;","SPE","[[J"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void m000__clinit_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_STATIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/jetty/security/UnixCrypt;","<clinit>",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(10);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(37,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(48,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(58,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(69,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(73,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(84,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(126,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(136,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(147,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(159,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(162,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(165,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(168,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(171,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(174,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(180,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(181,L16);
                ddv.visitStartLocal(4,L16,"perm","[B",null);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(184,L17);
                ddv.visitStartLocal(6,L17,"temp","[B",null);
                DexLabel L18=new DexLabel();
                ddv.visitStartLocal(0,L18,"i","I",null);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(187,L19);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(188,L20);
                DexLabel L21=new DexLabel();
                ddv.visitLineNumber(190,L21);
                DexLabel L22=new DexLabel();
                ddv.visitStartLocal(1,L22,"k","I",null);
                DexLabel L23=new DexLabel();
                ddv.visitLineNumber(188,L23);
                DexLabel L24=new DexLabel();
                ddv.visitLineNumber(191,L24);
                DexLabel L25=new DexLabel();
                ddv.visitLineNumber(192,L25);
                DexLabel L26=new DexLabel();
                ddv.visitLineNumber(193,L26);
                DexLabel L27=new DexLabel();
                ddv.visitLineNumber(194,L27);
                DexLabel L28=new DexLabel();
                ddv.visitLineNumber(195,L28);
                DexLabel L29=new DexLabel();
                ddv.visitLineNumber(196,L29);
                DexLabel L30=new DexLabel();
                ddv.visitLineNumber(197,L30);
                DexLabel L31=new DexLabel();
                ddv.visitLineNumber(199,L31);
                DexLabel L32=new DexLabel();
                ddv.visitLineNumber(201,L32);
                ddv.visitEndLocal(1,L32);
                DexLabel L33=new DexLabel();
                ddv.visitEndLocal(0,L33);
                DexLabel L34=new DexLabel();
                ddv.visitLineNumber(204,L34);
                DexLabel L35=new DexLabel();
                ddv.visitStartLocal(0,L35,"j","I",null);
                DexLabel L36=new DexLabel();
                ddv.visitEndLocal(0,L36);
                ddv.visitStartLocal(1,L36,"j","I",null);
                DexLabel L37=new DexLabel();
                ddv.visitLineNumber(206,L37);
                DexLabel L38=new DexLabel();
                ddv.visitStartLocal(0,L38,"i","I",null);
                DexLabel L39=new DexLabel();
                ddv.visitLineNumber(207,L39);
                DexLabel L40=new DexLabel();
                ddv.visitLineNumber(208,L40);
                DexLabel L41=new DexLabel();
                ddv.visitStartLocal(2,L41,"k","I",null);
                DexLabel L42=new DexLabel();
                ddv.visitLineNumber(207,L42);
                ddv.visitEndLocal(2,L42);
                DexLabel L43=new DexLabel();
                ddv.visitLineNumber(209,L43);
                ddv.visitRestartLocal(2,L43);
                DexLabel L44=new DexLabel();
                ddv.visitLineNumber(211,L44);
                ddv.visitEndLocal(2,L44);
                DexLabel L45=new DexLabel();
                ddv.visitLineNumber(212,L45);
                DexLabel L46=new DexLabel();
                ddv.visitRestartLocal(2,L46);
                DexLabel L47=new DexLabel();
                ddv.visitLineNumber(211,L47);
                DexLabel L48=new DexLabel();
                ddv.visitLineNumber(213,L48);
                DexLabel L49=new DexLabel();
                ddv.visitLineNumber(214,L49);
                DexLabel L50=new DexLabel();
                ddv.visitLineNumber(215,L50);
                DexLabel L51=new DexLabel();
                ddv.visitLineNumber(218,L51);
                ddv.visitEndLocal(2,L51);
                DexLabel L52=new DexLabel();
                ddv.visitEndLocal(0,L52);
                DexLabel L53=new DexLabel();
                ddv.visitLineNumber(204,L53);
                DexLabel L54=new DexLabel();
                ddv.visitStartLocal(0,L54,"j","I",null);
                DexLabel L55=new DexLabel();
                ddv.visitLineNumber(222,L55);
                ddv.visitEndLocal(0,L55);
                DexLabel L56=new DexLabel();
                ddv.visitStartLocal(0,L56,"i","I",null);
                DexLabel L57=new DexLabel();
                ddv.visitLineNumber(223,L57);
                ddv.visitEndLocal(1,L57);
                DexLabel L58=new DexLabel();
                ddv.visitRestartLocal(1,L58);
                DexLabel L59=new DexLabel();
                ddv.visitLineNumber(224,L59);
                DexLabel L60=new DexLabel();
                ddv.visitLineNumber(225,L60);
                ddv.visitRestartLocal(2,L60);
                DexLabel L61=new DexLabel();
                ddv.visitLineNumber(227,L61);
                DexLabel L62=new DexLabel();
                ddv.visitLineNumber(228,L62);
                DexLabel L63=new DexLabel();
                ddv.visitLineNumber(229,L63);
                DexLabel L64=new DexLabel();
                ddv.visitLineNumber(230,L64);
                DexLabel L65=new DexLabel();
                ddv.visitLineNumber(232,L65);
                DexLabel L66=new DexLabel();
                ddv.visitLineNumber(223,L66);
                ddv.visitEndLocal(2,L66);
                DexLabel L67=new DexLabel();
                ddv.visitLineNumber(224,L67);
                DexLabel L68=new DexLabel();
                ddv.visitLineNumber(226,L68);
                ddv.visitRestartLocal(2,L68);
                DexLabel L69=new DexLabel();
                ddv.visitLineNumber(222,L69);
                ddv.visitEndLocal(2,L69);
                DexLabel L70=new DexLabel();
                ddv.visitLineNumber(236,L70);
                ddv.visitEndLocal(1,L70);
                DexLabel L71=new DexLabel();
                ddv.visitEndLocal(0,L71);
                DexLabel L72=new DexLabel();
                ddv.visitLineNumber(239,L72);
                DexLabel L73=new DexLabel();
                ddv.visitRestartLocal(0,L73);
                DexLabel L74=new DexLabel();
                ddv.visitLineNumber(240,L74);
                DexLabel L75=new DexLabel();
                ddv.visitLineNumber(241,L75);
                ddv.visitStartLocal(1,L75,"k","I",null);
                DexLabel L76=new DexLabel();
                ddv.visitLineNumber(242,L76);
                DexLabel L77=new DexLabel();
                ddv.visitLineNumber(243,L77);
                DexLabel L78=new DexLabel();
                ddv.visitLineNumber(244,L78);
                DexLabel L79=new DexLabel();
                ddv.visitLineNumber(246,L79);
                DexLabel L80=new DexLabel();
                ddv.visitLineNumber(239,L80);
                ddv.visitEndLocal(1,L80);
                DexLabel L81=new DexLabel();
                ddv.visitLineNumber(249,L81);
                DexLabel L82=new DexLabel();
                ddv.visitEndLocal(0,L82);
                DexLabel L83=new DexLabel();
                ddv.visitLineNumber(252,L83);
                DexLabel L84=new DexLabel();
                ddv.visitRestartLocal(0,L84);
                DexLabel L85=new DexLabel();
                ddv.visitLineNumber(253,L85);
                DexLabel L86=new DexLabel();
                ddv.visitLineNumber(252,L86);
                DexLabel L87=new DexLabel();
                ddv.visitLineNumber(254,L87);
                DexLabel L88=new DexLabel();
                ddv.visitStartLocal(0,L88,"t","I",null);
                DexLabel L89=new DexLabel();
                ddv.visitEndLocal(0,L89);
                ddv.visitStartLocal(5,L89,"t","I",null);
                DexLabel L90=new DexLabel();
                ddv.visitLineNumber(255,L90);
                DexLabel L91=new DexLabel();
                ddv.visitStartLocal(0,L91,"j","I",null);
                DexLabel L92=new DexLabel();
                ddv.visitEndLocal(0,L92);
                ddv.visitStartLocal(1,L92,"j","I",null);
                DexLabel L93=new DexLabel();
                ddv.visitLineNumber(256,L93);
                DexLabel L94=new DexLabel();
                ddv.visitLineNumber(259,L94);
                ddv.visitStartLocal(0,L94,"k","I",null);
                DexLabel L95=new DexLabel();
                ddv.visitLineNumber(260,L95);
                DexLabel L96=new DexLabel();
                ddv.visitLineNumber(262,L96);
                ddv.visitRestartLocal(2,L96);
                DexLabel L97=new DexLabel();
                ddv.visitStartLocal(0,L97,"i","I",null);
                DexLabel L98=new DexLabel();
                ddv.visitLineNumber(263,L98);
                DexLabel L99=new DexLabel();
                ddv.visitLineNumber(264,L99);
                DexLabel L100=new DexLabel();
                ddv.visitLineNumber(265,L100);
                ddv.visitStartLocal(2,L100,"kk","J",null);
                DexLabel L101=new DexLabel();
                ddv.visitEndLocal(2,L101);
                DexLabel L102=new DexLabel();
                ddv.visitRestartLocal(2,L102);
                DexLabel L103=new DexLabel();
                ddv.visitLineNumber(269,L103);
                DexLabel L104=new DexLabel();
                ddv.visitEndLocal(0,L104);
                DexLabel L105=new DexLabel();
                ddv.visitEndLocal(2,L105);
                DexLabel L106=new DexLabel();
                ddv.visitLineNumber(255,L106);
                DexLabel L107=new DexLabel();
                ddv.visitStartLocal(0,L107,"j","I",null);
                DexLabel L108=new DexLabel();
                ddv.visitLineNumber(254,L108);
                ddv.visitEndLocal(0,L108);
                DexLabel L109=new DexLabel();
                ddv.visitStartLocal(0,L109,"t","I",null);
                DexLabel L110=new DexLabel();
                ddv.visitLineNumber(272,L110);
                ddv.visitEndLocal(1,L110);
                ddv.visitEndLocal(0,L110);
                DexLabel L111=new DexLabel();
                ddv.visitLineNumber(37,L111);
                DexLabel L112=new DexLabel();
                ddv.visitLineNumber(48,L112);
                DexLabel L113=new DexLabel();
                ddv.visitLineNumber(58,L113);
                DexLabel L114=new DexLabel();
                ddv.visitLineNumber(69,L114);
                DexLabel L115=new DexLabel();
                ddv.visitLineNumber(73,L115);
                DexLabel L116=new DexLabel();
                ddv.visitLineNumber(84,L116);
                DexLabel L117=new DexLabel();
                ddv.visitLineNumber(126,L117);
                DexLabel L118=new DexLabel();
                ddv.visitLineNumber(136,L118);
                DexLabel L119=new DexLabel();
                ddv.visitLineNumber(147,L119);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_16,0, Integer.valueOf(64)); // int: 0x00000040  float:0.000000
                code.visitTypeStmt(NEW_ARRAY,0,0,"[B");
                code.visitFieldStmt(SPUT_OBJECT,0,-1,new Field("Lorg/mortbay/jetty/security/UnixCrypt;","IP","[B"));
                code.visitLabel(L1);
                code.visitConstStmt(CONST_16,0, Integer.valueOf(48)); // int: 0x00000030  float:0.000000
                code.visitTypeStmt(NEW_ARRAY,0,0,"[B");
                code.visitFieldStmt(SPUT_OBJECT,0,-1,new Field("Lorg/mortbay/jetty/security/UnixCrypt;","ExpandTr","[B"));
                code.visitLabel(L2);
                code.visitConstStmt(CONST_16,0, Integer.valueOf(56)); // int: 0x00000038  float:0.000000
                code.visitTypeStmt(NEW_ARRAY,0,0,"[B");
                code.visitFieldStmt(SPUT_OBJECT,0,-1,new Field("Lorg/mortbay/jetty/security/UnixCrypt;","PC1","[B"));
                code.visitLabel(L3);
                code.visitConstStmt(CONST_16,0, Integer.valueOf(16)); // int: 0x00000010  float:0.000000
                code.visitTypeStmt(NEW_ARRAY,0,0,"[B");
                code.visitFieldStmt(SPUT_OBJECT,0,-1,new Field("Lorg/mortbay/jetty/security/UnixCrypt;","Rotates","[B"));
                code.visitLabel(L4);
                code.visitConstStmt(CONST_16,0, Integer.valueOf(64)); // int: 0x00000040  float:0.000000
                code.visitTypeStmt(NEW_ARRAY,0,0,"[B");
                code.visitFieldStmt(SPUT_OBJECT,0,-1,new Field("Lorg/mortbay/jetty/security/UnixCrypt;","PC2","[B"));
                code.visitLabel(L5);
                code.visitConstStmt(CONST_16,0, Integer.valueOf(8)); // int: 0x00000008  float:0.000000
                code.visitTypeStmt(NEW_ARRAY,0,0,"[[B");
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitConstStmt(CONST_16,2, Integer.valueOf(64)); // int: 0x00000040  float:0.000000
                code.visitTypeStmt(NEW_ARRAY,2,2,"[B");
                code.visitStmt3R(APUT_OBJECT,2,0,1);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitConstStmt(CONST_16,2, Integer.valueOf(64)); // int: 0x00000040  float:0.000000
                code.visitTypeStmt(NEW_ARRAY,2,2,"[B");
                code.visitStmt3R(APUT_OBJECT,2,0,1);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(2)); // int: 0x00000002  float:0.000000
                code.visitConstStmt(CONST_16,2, Integer.valueOf(64)); // int: 0x00000040  float:0.000000
                code.visitTypeStmt(NEW_ARRAY,2,2,"[B");
                code.visitStmt3R(APUT_OBJECT,2,0,1);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(3)); // int: 0x00000003  float:0.000000
                code.visitConstStmt(CONST_16,2, Integer.valueOf(64)); // int: 0x00000040  float:0.000000
                code.visitTypeStmt(NEW_ARRAY,2,2,"[B");
                code.visitStmt3R(APUT_OBJECT,2,0,1);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(4)); // int: 0x00000004  float:0.000000
                code.visitConstStmt(CONST_16,2, Integer.valueOf(64)); // int: 0x00000040  float:0.000000
                code.visitTypeStmt(NEW_ARRAY,2,2,"[B");
                code.visitStmt3R(APUT_OBJECT,2,0,1);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(5)); // int: 0x00000005  float:0.000000
                code.visitConstStmt(CONST_16,2, Integer.valueOf(64)); // int: 0x00000040  float:0.000000
                code.visitTypeStmt(NEW_ARRAY,2,2,"[B");
                code.visitStmt3R(APUT_OBJECT,2,0,1);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(6)); // int: 0x00000006  float:0.000000
                code.visitConstStmt(CONST_16,2, Integer.valueOf(64)); // int: 0x00000040  float:0.000000
                code.visitTypeStmt(NEW_ARRAY,2,2,"[B");
                code.visitStmt3R(APUT_OBJECT,2,0,1);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(7)); // int: 0x00000007  float:0.000000
                code.visitConstStmt(CONST_16,2, Integer.valueOf(64)); // int: 0x00000040  float:0.000000
                code.visitTypeStmt(NEW_ARRAY,2,2,"[B");
                code.visitStmt3R(APUT_OBJECT,2,0,1);
                code.visitFieldStmt(SPUT_OBJECT,0,-1,new Field("Lorg/mortbay/jetty/security/UnixCrypt;","S","[[B"));
                code.visitLabel(L6);
                code.visitConstStmt(CONST_16,0, Integer.valueOf(32)); // int: 0x00000020  float:0.000000
                code.visitTypeStmt(NEW_ARRAY,0,0,"[B");
                code.visitFieldStmt(SPUT_OBJECT,0,-1,new Field("Lorg/mortbay/jetty/security/UnixCrypt;","P32Tr","[B"));
                code.visitLabel(L7);
                code.visitConstStmt(CONST_16,0, Integer.valueOf(64)); // int: 0x00000040  float:0.000000
                code.visitTypeStmt(NEW_ARRAY,0,0,"[B");
                code.visitFieldStmt(SPUT_OBJECT,0,-1,new Field("Lorg/mortbay/jetty/security/UnixCrypt;","CIFP","[B"));
                code.visitLabel(L8);
                code.visitConstStmt(CONST_16,0, Integer.valueOf(64)); // int: 0x00000040  float:0.000000
                code.visitTypeStmt(NEW_ARRAY,0,0,"[B");
                code.visitFieldStmt(SPUT_OBJECT,0,-1,new Field("Lorg/mortbay/jetty/security/UnixCrypt;","ITOA64","[B"));
                code.visitLabel(L9);
                code.visitConstStmt(CONST_16,0, Integer.valueOf(128)); // int: 0x00000080  float:0.000000
                code.visitTypeStmt(NEW_ARRAY,0,0,"[B");
                code.visitFieldStmt(SPUT_OBJECT,0,-1,new Field("Lorg/mortbay/jetty/security/UnixCrypt;","A64TOI","[B"));
                code.visitLabel(L10);
                code.visitConstStmt(CONST_16,0, Integer.valueOf(16)); // int: 0x00000010  float:0.000000
                code.visitConstStmt(CONST_16,1, Integer.valueOf(16)); // int: 0x00000010  float:0.000000
                code.visitFilledNewArrayStmt(FILLED_NEW_ARRAY,new int[]{ 0,1},"[I");
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(SGET_OBJECT,1,-1,new Field("Ljava/lang/Long;","TYPE","Ljava/lang/Class;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1,0},new Method("Ljava/lang/reflect/Array;","newInstance",new String[]{ "Ljava/lang/Class;","[I"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitTypeStmt(CHECK_CAST,0,-1,"[[J");
                code.visitFieldStmt(SPUT_OBJECT,0,-1,new Field("Lorg/mortbay/jetty/security/UnixCrypt;","PC1ROT","[[J"));
                code.visitLabel(L11);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(2)); // int: 0x00000002  float:0.000000
                code.visitConstStmt(CONST_16,1, Integer.valueOf(16)); // int: 0x00000010  float:0.000000
                code.visitConstStmt(CONST_16,2, Integer.valueOf(16)); // int: 0x00000010  float:0.000000
                code.visitFilledNewArrayStmt(FILLED_NEW_ARRAY,new int[]{ 0,1,2},"[I");
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(SGET_OBJECT,1,-1,new Field("Ljava/lang/Long;","TYPE","Ljava/lang/Class;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1,0},new Method("Ljava/lang/reflect/Array;","newInstance",new String[]{ "Ljava/lang/Class;","[I"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitTypeStmt(CHECK_CAST,0,-1,"[[[J");
                code.visitFieldStmt(SPUT_OBJECT,0,-1,new Field("Lorg/mortbay/jetty/security/UnixCrypt;","PC2ROT","[[[J"));
                code.visitLabel(L12);
                code.visitConstStmt(CONST_16,0, Integer.valueOf(8)); // int: 0x00000008  float:0.000000
                code.visitConstStmt(CONST_16,1, Integer.valueOf(16)); // int: 0x00000010  float:0.000000
                code.visitFilledNewArrayStmt(FILLED_NEW_ARRAY,new int[]{ 0,1},"[I");
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(SGET_OBJECT,1,-1,new Field("Ljava/lang/Long;","TYPE","Ljava/lang/Class;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1,0},new Method("Ljava/lang/reflect/Array;","newInstance",new String[]{ "Ljava/lang/Class;","[I"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitTypeStmt(CHECK_CAST,0,-1,"[[J");
                code.visitFieldStmt(SPUT_OBJECT,0,-1,new Field("Lorg/mortbay/jetty/security/UnixCrypt;","IE3264","[[J"));
                code.visitLabel(L13);
                code.visitConstStmt(CONST_16,0, Integer.valueOf(8)); // int: 0x00000008  float:0.000000
                code.visitConstStmt(CONST_16,1, Integer.valueOf(64)); // int: 0x00000040  float:0.000000
                code.visitFilledNewArrayStmt(FILLED_NEW_ARRAY,new int[]{ 0,1},"[I");
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(SGET_OBJECT,1,-1,new Field("Ljava/lang/Long;","TYPE","Ljava/lang/Class;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1,0},new Method("Ljava/lang/reflect/Array;","newInstance",new String[]{ "Ljava/lang/Class;","[I"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitTypeStmt(CHECK_CAST,0,-1,"[[J");
                code.visitFieldStmt(SPUT_OBJECT,0,-1,new Field("Lorg/mortbay/jetty/security/UnixCrypt;","SPE","[[J"));
                code.visitLabel(L14);
                code.visitConstStmt(CONST_16,0, Integer.valueOf(16)); // int: 0x00000010  float:0.000000
                code.visitConstStmt(CONST_16,1, Integer.valueOf(16)); // int: 0x00000010  float:0.000000
                code.visitFilledNewArrayStmt(FILLED_NEW_ARRAY,new int[]{ 0,1},"[I");
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(SGET_OBJECT,1,-1,new Field("Ljava/lang/Long;","TYPE","Ljava/lang/Class;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1,0},new Method("Ljava/lang/reflect/Array;","newInstance",new String[]{ "Ljava/lang/Class;","[I"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitTypeStmt(CHECK_CAST,0,-1,"[[J");
                code.visitFieldStmt(SPUT_OBJECT,0,-1,new Field("Lorg/mortbay/jetty/security/UnixCrypt;","CF6464","[[J"));
                code.visitLabel(L15);
                code.visitConstStmt(CONST_16,0, Integer.valueOf(64)); // int: 0x00000040  float:0.000000
                code.visitTypeStmt(NEW_ARRAY,4,0,"[B");
                code.visitLabel(L16);
                code.visitConstStmt(CONST_16,0, Integer.valueOf(64)); // int: 0x00000040  float:0.000000
                code.visitTypeStmt(NEW_ARRAY,6,0,"[B");
                code.visitLabel(L17);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L18);
                code.visitConstStmt(CONST_16,1, Integer.valueOf(64)); // int: 0x00000040  float:0.000000
                code.visitJumpStmt(IF_GE,0,1,L19);
                code.visitFieldStmt(SGET_OBJECT,1,-1,new Field("Lorg/mortbay/jetty/security/UnixCrypt;","A64TOI","[B"));
                code.visitFieldStmt(SGET_OBJECT,2,-1,new Field("Lorg/mortbay/jetty/security/UnixCrypt;","ITOA64","[B"));
                code.visitStmt3R(AGET_BYTE,2,2,0);
                code.visitStmt2R(INT_TO_BYTE,3,0);
                code.visitStmt3R(APUT_BYTE,3,1,2);
                code.visitStmt2R1N(ADD_INT_LIT8,0,0,1);
                code.visitJumpStmt(GOTO,-1,-1,L18);
                code.visitLabel(L19);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                DexLabel L120=new DexLabel();
                code.visitLabel(L120);
                code.visitConstStmt(CONST_16,1, Integer.valueOf(64)); // int: 0x00000040  float:0.000000
                code.visitJumpStmt(IF_GE,0,1,L20);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitStmt3R(APUT_BYTE,1,4,0);
                code.visitStmt2R1N(ADD_INT_LIT8,0,0,1);
                code.visitJumpStmt(GOTO,-1,-1,L120);
                code.visitLabel(L20);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                DexLabel L121=new DexLabel();
                code.visitLabel(L121);
                code.visitConstStmt(CONST_16,1, Integer.valueOf(64)); // int: 0x00000040  float:0.000000
                code.visitJumpStmt(IF_GE,0,1,L32);
                code.visitLabel(L21);
                code.visitFieldStmt(SGET_OBJECT,1,-1,new Field("Lorg/mortbay/jetty/security/UnixCrypt;","PC2","[B"));
                code.visitStmt3R(AGET_BYTE,1,1,0);
                code.visitLabel(L22);
                code.visitJumpStmt(IF_NEZ,1,-1,L24);
                code.visitLabel(L23);
                code.visitStmt2R1N(ADD_INT_LIT8,0,0,1);
                code.visitJumpStmt(GOTO,-1,-1,L121);
                code.visitLabel(L24);
                code.visitFieldStmt(SGET_OBJECT,2,-1,new Field("Lorg/mortbay/jetty/security/UnixCrypt;","Rotates","[B"));
                code.visitConstStmt(CONST_4,3, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitStmt3R(AGET_BYTE,2,2,3);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitStmt2R(SUB_INT_2ADDR,2,3);
                code.visitStmt2R(ADD_INT_2ADDR,1,2);
                code.visitLabel(L25);
                code.visitStmt2R1N(REM_INT_LIT8,2,1,28);
                code.visitFieldStmt(SGET_OBJECT,3,-1,new Field("Lorg/mortbay/jetty/security/UnixCrypt;","Rotates","[B"));
                code.visitConstStmt(CONST_4,5, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitStmt3R(AGET_BYTE,3,3,5);
                code.visitJumpStmt(IF_GE,2,3,L26);
                code.visitStmt2R1N(ADD_INT_LIT8,1,1,-28);
                code.visitLabel(L26);
                code.visitFieldStmt(SGET_OBJECT,2,-1,new Field("Lorg/mortbay/jetty/security/UnixCrypt;","PC1","[B"));
                code.visitStmt3R(AGET_BYTE,1,2,1);
                code.visitLabel(L27);
                code.visitJumpStmt(IF_LEZ,1,-1,L31);
                code.visitLabel(L28);
                code.visitStmt2R1N(ADD_INT_LIT8,1,1,-1);
                code.visitLabel(L29);
                code.visitStmt2R1N(OR_INT_LIT8,2,1,7);
                code.visitStmt2R1N(AND_INT_LIT8,1,1,7);
                code.visitStmt3R(SUB_INT,1,2,1);
                code.visitLabel(L30);
                code.visitStmt2R1N(ADD_INT_LIT8,1,1,1);
                code.visitLabel(L31);
                code.visitStmt2R(INT_TO_BYTE,2,1);
                code.visitStmt3R(APUT_BYTE,2,4,0);
                code.visitJumpStmt(GOTO,-1,-1,L23);
                code.visitLabel(L32);
                code.visitFieldStmt(SGET_OBJECT,0,-1,new Field("Lorg/mortbay/jetty/security/UnixCrypt;","PC1ROT","[[J"));
                code.visitLabel(L33);
                code.visitConstStmt(CONST_16,1, Integer.valueOf(8)); // int: 0x00000008  float:0.000000
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0,4,1},new Method("Lorg/mortbay/jetty/security/UnixCrypt;","init_perm",new String[]{ "[[J","[B","I"},"V"));
                code.visitLabel(L34);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L35);
                code.visitStmt2R(MOVE,1,0);
                code.visitLabel(L36);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(2)); // int: 0x00000002  float:0.000000
                code.visitJumpStmt(IF_GE,1,0,L55);
                code.visitLabel(L37);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L38);
                code.visitConstStmt(CONST_16,2, Integer.valueOf(64)); // int: 0x00000040  float:0.000000
                code.visitJumpStmt(IF_GE,0,2,L39);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitStmt3R(APUT_BYTE,2,6,0);
                code.visitStmt3R(APUT_BYTE,2,4,0);
                code.visitStmt2R1N(ADD_INT_LIT8,0,0,1);
                code.visitJumpStmt(GOTO,-1,-1,L38);
                code.visitLabel(L39);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                DexLabel L122=new DexLabel();
                code.visitLabel(L122);
                code.visitConstStmt(CONST_16,2, Integer.valueOf(64)); // int: 0x00000040  float:0.000000
                code.visitJumpStmt(IF_GE,0,2,L44);
                code.visitLabel(L40);
                code.visitFieldStmt(SGET_OBJECT,2,-1,new Field("Lorg/mortbay/jetty/security/UnixCrypt;","PC2","[B"));
                code.visitStmt3R(AGET_BYTE,2,2,0);
                code.visitLabel(L41);
                code.visitJumpStmt(IF_NEZ,2,-1,L43);
                code.visitLabel(L42);
                code.visitStmt2R1N(ADD_INT_LIT8,0,0,1);
                code.visitJumpStmt(GOTO,-1,-1,L122);
                code.visitLabel(L43);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitStmt2R(SUB_INT_2ADDR,2,3);
                code.visitStmt2R1N(ADD_INT_LIT8,3,0,1);
                code.visitStmt2R(INT_TO_BYTE,3,3);
                code.visitStmt3R(APUT_BYTE,3,6,2);
                code.visitJumpStmt(GOTO,-1,-1,L42);
                code.visitLabel(L44);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                DexLabel L123=new DexLabel();
                code.visitLabel(L123);
                code.visitConstStmt(CONST_16,2, Integer.valueOf(64)); // int: 0x00000040  float:0.000000
                code.visitJumpStmt(IF_GE,0,2,L51);
                code.visitLabel(L45);
                code.visitFieldStmt(SGET_OBJECT,2,-1,new Field("Lorg/mortbay/jetty/security/UnixCrypt;","PC2","[B"));
                code.visitStmt3R(AGET_BYTE,2,2,0);
                code.visitLabel(L46);
                code.visitJumpStmt(IF_NEZ,2,-1,L48);
                code.visitLabel(L47);
                code.visitStmt2R1N(ADD_INT_LIT8,0,0,1);
                code.visitJumpStmt(GOTO,-1,-1,L123);
                code.visitLabel(L48);
                code.visitStmt2R(ADD_INT_2ADDR,2,1);
                code.visitLabel(L49);
                code.visitStmt2R1N(REM_INT_LIT8,3,2,28);
                code.visitJumpStmt(IF_GT,3,1,L50);
                code.visitStmt2R1N(ADD_INT_LIT8,2,2,-28);
                code.visitLabel(L50);
                code.visitStmt3R(AGET_BYTE,3,6,2);
                code.visitStmt3R(APUT_BYTE,3,4,0);
                code.visitJumpStmt(GOTO,-1,-1,L47);
                code.visitLabel(L51);
                code.visitFieldStmt(SGET_OBJECT,0,-1,new Field("Lorg/mortbay/jetty/security/UnixCrypt;","PC2ROT","[[[J"));
                code.visitLabel(L52);
                code.visitStmt3R(AGET_OBJECT,0,0,1);
                code.visitConstStmt(CONST_16,2, Integer.valueOf(8)); // int: 0x00000008  float:0.000000
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0,4,2},new Method("Lorg/mortbay/jetty/security/UnixCrypt;","init_perm",new String[]{ "[[J","[B","I"},"V"));
                code.visitLabel(L53);
                code.visitStmt2R1N(ADD_INT_LIT8,0,1,1);
                code.visitLabel(L54);
                code.visitStmt2R(MOVE,1,0);
                code.visitJumpStmt(GOTO,-1,-1,L36);
                code.visitLabel(L55);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L56);
                code.visitConstStmt(CONST_16,1, Integer.valueOf(8)); // int: 0x00000008  float:0.000000
                code.visitJumpStmt(IF_GE,0,1,L70);
                code.visitLabel(L57);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L58);
                code.visitConstStmt(CONST_16,2, Integer.valueOf(8)); // int: 0x00000008  float:0.000000
                code.visitJumpStmt(IF_GE,1,2,L69);
                code.visitLabel(L59);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(2)); // int: 0x00000002  float:0.000000
                code.visitJumpStmt(IF_GE,1,2,L67);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L60);
                code.visitConstStmt(CONST_16,3, Integer.valueOf(32)); // int: 0x00000020  float:0.000000
                code.visitJumpStmt(IF_LE,2,3,L68);
                code.visitStmt2R1N(ADD_INT_LIT8,2,2,-32);
                code.visitLabel(L61);
                code.visitJumpStmt(IF_LEZ,2,-1,L65);
                code.visitLabel(L62);
                code.visitStmt2R1N(ADD_INT_LIT8,2,2,-1);
                code.visitLabel(L63);
                code.visitStmt2R1N(OR_INT_LIT8,3,2,7);
                code.visitStmt2R1N(AND_INT_LIT8,2,2,7);
                code.visitStmt3R(SUB_INT,2,3,2);
                code.visitLabel(L64);
                code.visitStmt2R1N(ADD_INT_LIT8,2,2,1);
                code.visitLabel(L65);
                code.visitStmt2R1N(MUL_INT_LIT8,3,0,8);
                code.visitStmt2R(ADD_INT_2ADDR,3,1);
                code.visitStmt2R(INT_TO_BYTE,2,2);
                code.visitStmt3R(APUT_BYTE,2,4,3);
                code.visitLabel(L66);
                code.visitStmt2R1N(ADD_INT_LIT8,1,1,1);
                code.visitJumpStmt(GOTO,-1,-1,L58);
                code.visitLabel(L67);
                code.visitFieldStmt(SGET_OBJECT,2,-1,new Field("Lorg/mortbay/jetty/security/UnixCrypt;","IP","[B"));
                code.visitFieldStmt(SGET_OBJECT,3,-1,new Field("Lorg/mortbay/jetty/security/UnixCrypt;","ExpandTr","[B"));
                code.visitStmt2R1N(MUL_INT_LIT8,5,0,6);
                code.visitStmt2R(ADD_INT_2ADDR,5,1);
                code.visitConstStmt(CONST_4,7, Integer.valueOf(2)); // int: 0x00000002  float:0.000000
                code.visitStmt2R(SUB_INT_2ADDR,5,7);
                code.visitStmt3R(AGET_BYTE,3,3,5);
                code.visitConstStmt(CONST_4,5, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitStmt2R(SUB_INT_2ADDR,3,5);
                code.visitStmt3R(AGET_BYTE,2,2,3);
                code.visitJumpStmt(GOTO,-1,-1,L60);
                code.visitLabel(L68);
                code.visitJumpStmt(IF_LEZ,2,-1,L61);
                code.visitStmt2R1N(ADD_INT_LIT8,2,2,-1);
                code.visitJumpStmt(GOTO,-1,-1,L61);
                code.visitLabel(L69);
                code.visitStmt2R1N(ADD_INT_LIT8,0,0,1);
                code.visitJumpStmt(GOTO,-1,-1,L56);
                code.visitLabel(L70);
                code.visitFieldStmt(SGET_OBJECT,0,-1,new Field("Lorg/mortbay/jetty/security/UnixCrypt;","IE3264","[[J"));
                code.visitLabel(L71);
                code.visitConstStmt(CONST_16,1, Integer.valueOf(8)); // int: 0x00000008  float:0.000000
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0,4,1},new Method("Lorg/mortbay/jetty/security/UnixCrypt;","init_perm",new String[]{ "[[J","[B","I"},"V"));
                code.visitLabel(L72);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L73);
                code.visitConstStmt(CONST_16,1, Integer.valueOf(64)); // int: 0x00000040  float:0.000000
                code.visitJumpStmt(IF_GE,0,1,L81);
                code.visitLabel(L74);
                code.visitFieldStmt(SGET_OBJECT,1,-1,new Field("Lorg/mortbay/jetty/security/UnixCrypt;","IP","[B"));
                code.visitFieldStmt(SGET_OBJECT,2,-1,new Field("Lorg/mortbay/jetty/security/UnixCrypt;","CIFP","[B"));
                code.visitStmt3R(AGET_BYTE,2,2,0);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitStmt2R(SUB_INT_2ADDR,2,3);
                code.visitStmt3R(AGET_BYTE,1,1,2);
                code.visitLabel(L75);
                code.visitJumpStmt(IF_LEZ,1,-1,L79);
                code.visitLabel(L76);
                code.visitStmt2R1N(ADD_INT_LIT8,1,1,-1);
                code.visitLabel(L77);
                code.visitStmt2R1N(OR_INT_LIT8,2,1,7);
                code.visitStmt2R1N(AND_INT_LIT8,1,1,7);
                code.visitStmt3R(SUB_INT,1,2,1);
                code.visitLabel(L78);
                code.visitStmt2R1N(ADD_INT_LIT8,1,1,1);
                code.visitLabel(L79);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitStmt2R(SUB_INT_2ADDR,1,2);
                code.visitStmt2R1N(ADD_INT_LIT8,2,0,1);
                code.visitStmt2R(INT_TO_BYTE,2,2);
                code.visitStmt3R(APUT_BYTE,2,4,1);
                code.visitLabel(L80);
                code.visitStmt2R1N(ADD_INT_LIT8,0,0,1);
                code.visitJumpStmt(GOTO,-1,-1,L73);
                code.visitLabel(L81);
                code.visitFieldStmt(SGET_OBJECT,0,-1,new Field("Lorg/mortbay/jetty/security/UnixCrypt;","CF6464","[[J"));
                code.visitLabel(L82);
                code.visitConstStmt(CONST_16,1, Integer.valueOf(8)); // int: 0x00000008  float:0.000000
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0,4,1},new Method("Lorg/mortbay/jetty/security/UnixCrypt;","init_perm",new String[]{ "[[J","[B","I"},"V"));
                code.visitLabel(L83);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L84);
                code.visitConstStmt(CONST_16,1, Integer.valueOf(48)); // int: 0x00000030  float:0.000000
                code.visitJumpStmt(IF_GE,0,1,L87);
                code.visitLabel(L85);
                code.visitFieldStmt(SGET_OBJECT,1,-1,new Field("Lorg/mortbay/jetty/security/UnixCrypt;","P32Tr","[B"));
                code.visitFieldStmt(SGET_OBJECT,2,-1,new Field("Lorg/mortbay/jetty/security/UnixCrypt;","ExpandTr","[B"));
                code.visitStmt3R(AGET_BYTE,2,2,0);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitStmt2R(SUB_INT_2ADDR,2,3);
                code.visitStmt3R(AGET_BYTE,1,1,2);
                code.visitStmt3R(APUT_BYTE,1,4,0);
                code.visitLabel(L86);
                code.visitStmt2R1N(ADD_INT_LIT8,0,0,1);
                code.visitJumpStmt(GOTO,-1,-1,L84);
                code.visitLabel(L87);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L88);
                code.visitStmt2R(MOVE,5,0);
                code.visitLabel(L89);
                code.visitConstStmt(CONST_16,0, Integer.valueOf(8)); // int: 0x00000008  float:0.000000
                code.visitJumpStmt(IF_GE,5,0,L110);
                code.visitLabel(L90);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L91);
                code.visitStmt2R(MOVE,1,0);
                code.visitLabel(L92);
                code.visitConstStmt(CONST_16,0, Integer.valueOf(64)); // int: 0x00000040  float:0.000000
                code.visitJumpStmt(IF_GE,1,0,L108);
                code.visitLabel(L93);
                code.visitStmt2R1N(SHR_INT_LIT8,0,1,0);
                code.visitStmt2R1N(AND_INT_LIT8,0,0,1);
                code.visitStmt2R1N(SHL_INT_LIT8,0,0,5);
                code.visitStmt2R1N(SHR_INT_LIT8,2,1,1);
                code.visitStmt2R1N(AND_INT_LIT8,2,2,1);
                code.visitStmt2R1N(SHL_INT_LIT8,2,2,3);
                code.visitStmt2R(OR_INT_2ADDR,0,2);
                code.visitStmt2R1N(SHR_INT_LIT8,2,1,2);
                code.visitStmt2R1N(AND_INT_LIT8,2,2,1);
                code.visitStmt2R1N(SHL_INT_LIT8,2,2,2);
                code.visitStmt2R(OR_INT_2ADDR,0,2);
                code.visitStmt2R1N(SHR_INT_LIT8,2,1,3);
                code.visitStmt2R1N(AND_INT_LIT8,2,2,1);
                code.visitStmt2R1N(SHL_INT_LIT8,2,2,1);
                code.visitStmt2R(OR_INT_2ADDR,0,2);
                code.visitStmt2R1N(SHR_INT_LIT8,2,1,4);
                code.visitStmt2R1N(AND_INT_LIT8,2,2,1);
                code.visitStmt2R1N(SHL_INT_LIT8,2,2,0);
                code.visitStmt2R(OR_INT_2ADDR,0,2);
                code.visitStmt2R1N(SHR_INT_LIT8,2,1,5);
                code.visitStmt2R1N(AND_INT_LIT8,2,2,1);
                code.visitStmt2R1N(SHL_INT_LIT8,2,2,4);
                code.visitStmt2R(OR_INT_2ADDR,0,2);
                code.visitLabel(L94);
                code.visitFieldStmt(SGET_OBJECT,2,-1,new Field("Lorg/mortbay/jetty/security/UnixCrypt;","S","[[B"));
                code.visitStmt3R(AGET_OBJECT,2,2,5);
                code.visitStmt3R(AGET_BYTE,0,2,0);
                code.visitLabel(L95);
                code.visitStmt2R1N(SHR_INT_LIT8,2,0,3);
                code.visitStmt2R1N(AND_INT_LIT8,2,2,1);
                code.visitStmt2R1N(SHL_INT_LIT8,2,2,0);
                code.visitStmt2R1N(SHR_INT_LIT8,3,0,2);
                code.visitStmt2R1N(AND_INT_LIT8,3,3,1);
                code.visitStmt2R1N(SHL_INT_LIT8,3,3,1);
                code.visitStmt2R(OR_INT_2ADDR,2,3);
                code.visitStmt2R1N(SHR_INT_LIT8,3,0,1);
                code.visitStmt2R1N(AND_INT_LIT8,3,3,1);
                code.visitStmt2R1N(SHL_INT_LIT8,3,3,2);
                code.visitStmt2R(OR_INT_2ADDR,2,3);
                code.visitStmt2R1N(SHR_INT_LIT8,0,0,0);
                code.visitStmt2R1N(AND_INT_LIT8,0,0,1);
                code.visitStmt2R1N(SHL_INT_LIT8,0,0,3);
                code.visitStmt2R(OR_INT_2ADDR,2,0);
                code.visitLabel(L96);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L97);
                code.visitConstStmt(CONST_16,3, Integer.valueOf(32)); // int: 0x00000020  float:0.000000
                code.visitJumpStmt(IF_GE,0,3,L98);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitStmt3R(APUT_BYTE,3,6,0);
                code.visitStmt2R1N(ADD_INT_LIT8,0,0,1);
                code.visitJumpStmt(GOTO,-1,-1,L97);
                code.visitLabel(L98);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                DexLabel L124=new DexLabel();
                code.visitLabel(L124);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(4)); // int: 0x00000004  float:0.000000
                code.visitJumpStmt(IF_GE,0,3,L99);
                code.visitStmt2R1N(MUL_INT_LIT8,3,5,4);
                code.visitStmt2R(ADD_INT_2ADDR,3,0);
                code.visitStmt3R(SHR_INT,7,2,0);
                code.visitStmt2R1N(AND_INT_LIT8,7,7,1);
                code.visitStmt2R(INT_TO_BYTE,7,7);
                code.visitStmt3R(APUT_BYTE,7,6,3);
                code.visitStmt2R1N(ADD_INT_LIT8,0,0,1);
                code.visitJumpStmt(GOTO,-1,-1,L124);
                code.visitLabel(L99);
                code.visitConstStmt(CONST_WIDE_16,2,Long.valueOf(0L)); // long: 0x0000000000000000  double:0.000000
                code.visitLabel(L100);
                code.visitConstStmt(CONST_16,0, Integer.valueOf(24)); // int: 0x00000018  float:0.000000
                DexLabel L125=new DexLabel();
                code.visitLabel(L125);
                code.visitStmt2R1N(ADD_INT_LIT8,0,0,-1);
                code.visitJumpStmt(IF_LTZ,0,-1,L103);
                code.visitConstStmt(CONST_4,7, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitStmt2R(SHL_LONG_2ADDR,2,7);
                code.visitStmt3R(AGET_BYTE,7,4,0);
                code.visitLabel(L101);
                code.visitConstStmt(CONST_4,8, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitStmt2R(SUB_INT_2ADDR,7,8);
                code.visitStmt3R(AGET_BYTE,7,6,7);
                code.visitStmt2R(INT_TO_LONG,7,7);
                code.visitConstStmt(CONST_16,9, Integer.valueOf(32)); // int: 0x00000020  float:0.000000
                code.visitStmt2R(SHL_LONG_2ADDR,7,9);
                code.visitStmt2R(OR_LONG_2ADDR,2,7);
                code.visitStmt2R1N(ADD_INT_LIT8,7,0,24);
                code.visitStmt3R(AGET_BYTE,7,4,7);
                code.visitConstStmt(CONST_4,8, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitStmt2R(SUB_INT_2ADDR,7,8);
                code.visitStmt3R(AGET_BYTE,7,6,7);
                code.visitStmt2R(INT_TO_LONG,7,7);
                code.visitStmt2R(OR_LONG_2ADDR,2,7);
                code.visitLabel(L102);
                code.visitJumpStmt(GOTO,-1,-1,L125);
                code.visitLabel(L103);
                code.visitFieldStmt(SGET_OBJECT,0,-1,new Field("Lorg/mortbay/jetty/security/UnixCrypt;","SPE","[[J"));
                code.visitLabel(L104);
                code.visitStmt3R(AGET_OBJECT,0,0,5);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 2,3},new Method("Lorg/mortbay/jetty/security/UnixCrypt;","to_six_bit",new String[]{ "J"},"J"));
                code.visitStmt1R(MOVE_RESULT_WIDE,2);
                code.visitLabel(L105);
                code.visitStmt3R(APUT_WIDE,2,0,1);
                code.visitLabel(L106);
                code.visitStmt2R1N(ADD_INT_LIT8,0,1,1);
                code.visitLabel(L107);
                code.visitStmt2R(MOVE,1,0);
                code.visitJumpStmt(GOTO_16,-1,-1,L92);
                code.visitLabel(L108);
                code.visitStmt2R1N(ADD_INT_LIT8,0,5,1);
                code.visitLabel(L109);
                code.visitStmt2R(MOVE,5,0);
                code.visitJumpStmt(GOTO_16,-1,-1,L89);
                code.visitLabel(L110);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L111);
                code.visitLabel(L112);
                code.visitLabel(L113);
                code.visitLabel(L114);
                code.visitLabel(L115);
                code.visitLabel(L116);
                code.visitLabel(L117);
                code.visitLabel(L118);
                code.visitLabel(L119);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PRIVATE|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/jetty/security/UnixCrypt;","<init>",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(1);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(277,L0);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/lang/Object;","<init>",new String[]{ },"V"));
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m002_crypt(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Lorg/mortbay/jetty/security/UnixCrypt;","crypt",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(11);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"key");
                ddv.visitParameterName(1,"setting");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(428,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(429,L1);
                ddv.visitStartLocal(1,L1,"constdatablock","J",null);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(430,L2);
                ddv.visitStartLocal(3,L2,"cryptresult","[B",null);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(432,L3);
                ddv.visitStartLocal(5,L3,"keyword","J",null);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(433,L4);
                DexLabel L5=new DexLabel();
                ddv.visitEndLocal(9,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(459,L6);
                ddv.visitEndLocal(1,L6);
                ddv.visitEndLocal(5,L6);
                ddv.visitStartLocal(9,L6,"keyword","J",null);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(435,L7);
                ddv.visitRestartLocal(1,L7);
                ddv.visitRestartLocal(5,L7);
                ddv.visitStartLocal(9,L7,"key","Ljava/lang/String;",null);
                ddv.visitRestartLocal(10,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(437,L8);
                ddv.visitStartLocal(4,L8,"keylen","I",null);
                DexLabel L9=new DexLabel();
                ddv.visitStartLocal(0,L9,"i","I",null);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(438,L10);
                DexLabel L11=new DexLabel();
                ddv.visitEndLocal(5,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(437,L12);
                ddv.visitRestartLocal(5,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(438,L13);
                ddv.visitEndLocal(5,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(441,L14);
                ddv.visitRestartLocal(5,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(443,L15);
                ddv.visitStartLocal(9,L15,"KS","[J",null);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(444,L16);
                ddv.visitStartLocal(4,L16,"salt","I",null);
                DexLabel L17=new DexLabel();
                ddv.visitEndLocal(4,L17);
                ddv.visitStartLocal(7,L17,"salt","I",null);
                DexLabel L18=new DexLabel();
                ddv.visitStartLocal(4,L18,"i","I",null);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(445,L19);
                ddv.visitEndLocal(0,L19);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(446,L20);
                ddv.visitStartLocal(0,L20,"c","C",null);
                DexLabel L21=new DexLabel();
                ddv.visitLineNumber(447,L21);
                DexLabel L22=new DexLabel();
                ddv.visitEndLocal(7,L22);
                DexLabel L23=new DexLabel();
                ddv.visitEndLocal(0,L23);
                DexLabel L24=new DexLabel();
                ddv.visitStartLocal(0,L24,"salt","I",null);
                DexLabel L25=new DexLabel();
                ddv.visitRestartLocal(7,L25);
                DexLabel L26=new DexLabel();
                ddv.visitLineNumber(448,L26);
                ddv.visitStartLocal(0,L26,"i","I",null);
                DexLabel L27=new DexLabel();
                ddv.visitLineNumber(445,L27);
                ddv.visitEndLocal(0,L27);
                DexLabel L28=new DexLabel();
                ddv.visitLineNumber(450,L28);
                DexLabel L29=new DexLabel();
                ddv.visitEndLocal(10,L29);
                DexLabel L30=new DexLabel();
                ddv.visitLineNumber(452,L30);
                ddv.visitStartLocal(9,L30,"rsltblock","J",null);
                DexLabel L31=new DexLabel();
                ddv.visitEndLocal(1,L31);
                DexLabel L32=new DexLabel();
                ddv.visitLineNumber(453,L32);
                DexLabel L33=new DexLabel();
                ddv.visitLineNumber(454,L33);
                ddv.visitStartLocal(0,L33,"rsltblock","J",null);
                DexLabel L34=new DexLabel();
                ddv.visitEndLocal(4,L34);
                ddv.visitStartLocal(9,L34,"i","I",null);
                DexLabel L35=new DexLabel();
                ddv.visitLineNumber(455,L35);
                DexLabel L36=new DexLabel();
                ddv.visitLineNumber(456,L36);
                DexLabel L37=new DexLabel();
                ddv.visitLineNumber(459,L37);
                DexLabel L38=new DexLabel();
                ddv.visitEndLocal(9,L38);
                DexLabel L39=new DexLabel();
                ddv.visitEndLocal(0,L39);
                DexLabel L40=new DexLabel();
                ddv.visitStartLocal(9,L40,"keyword","J",null);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_WIDE_16,1,Long.valueOf(0L)); // long: 0x0000000000000000  double:0.000000
                code.visitLabel(L1);
                code.visitConstStmt(CONST_16,0, Integer.valueOf(13)); // int: 0x0000000d  float:0.000000
                code.visitTypeStmt(NEW_ARRAY,3,0,"[B");
                code.visitLabel(L2);
                code.visitConstStmt(CONST_WIDE_16,5,Long.valueOf(0L)); // long: 0x0000000000000000  double:0.000000
                code.visitLabel(L3);
                code.visitJumpStmt(IF_EQZ,9,-1,L4);
                code.visitJumpStmt(IF_NEZ,10,-1,L7);
                code.visitLabel(L4);
                code.visitConstStmt(CONST_STRING,9,"*");
                code.visitLabel(L5);
                code.visitStmt2R(MOVE_OBJECT,0,9);
                code.visitStmt2R(MOVE_WIDE,9,5);
                code.visitLabel(L6);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitLabel(L7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9},new Method("Ljava/lang/String;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,4);
                code.visitLabel(L8);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L9);
                code.visitConstStmt(CONST_16,7, Integer.valueOf(8)); // int: 0x00000008  float:0.000000
                code.visitJumpStmt(IF_GE,0,7,L14);
                code.visitLabel(L10);
                code.visitConstStmt(CONST_16,7, Integer.valueOf(8)); // int: 0x00000008  float:0.000000
                code.visitStmt2R(SHL_LONG_2ADDR,5,7);
                code.visitJumpStmt(IF_GE,0,4,L13);
                code.visitLabel(L11);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9,0},new Method("Ljava/lang/String;","charAt",new String[]{ "I"},"C"));
                code.visitStmt1R(MOVE_RESULT,7);
                code.visitStmt2R1N(MUL_INT_LIT8,7,7,2);
                DexLabel L41=new DexLabel();
                code.visitLabel(L41);
                code.visitStmt2R(INT_TO_LONG,7,7);
                code.visitStmt2R(OR_LONG_2ADDR,5,7);
                code.visitLabel(L12);
                code.visitStmt2R1N(ADD_INT_LIT8,0,0,1);
                code.visitJumpStmt(GOTO,-1,-1,L9);
                code.visitLabel(L13);
                code.visitConstStmt(CONST_4,7, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L41);
                code.visitLabel(L14);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 5,6},new Method("Lorg/mortbay/jetty/security/UnixCrypt;","des_setkey",new String[]{ "J"},"[J"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,9);
                code.visitLabel(L15);
                code.visitConstStmt(CONST_4,4, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L16);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(2)); // int: 0x00000002  float:0.000000
                code.visitStmt2R(MOVE,7,4);
                code.visitLabel(L17);
                code.visitStmt2R1N(ADD_INT_LIT8,4,0,-1);
                code.visitLabel(L18);
                code.visitJumpStmt(IF_LTZ,4,-1,L28);
                code.visitLabel(L19);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10},new Method("Ljava/lang/String;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_GE,4,0,L27);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10,4},new Method("Ljava/lang/String;","charAt",new String[]{ "I"},"C"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitLabel(L20);
                code.visitStmt2R(INT_TO_BYTE,8,0);
                code.visitStmt3R(APUT_BYTE,8,3,4);
                code.visitLabel(L21);
                code.visitStmt2R1N(SHL_INT_LIT8,7,7,6);
                code.visitFieldStmt(SGET_OBJECT,8,-1,new Field("Lorg/mortbay/jetty/security/UnixCrypt;","A64TOI","[B"));
                code.visitLabel(L22);
                code.visitStmt3R(AGET_BYTE,0,8,0);
                code.visitLabel(L23);
                code.visitStmt2R1N(AND_INT_LIT16,0,0,255);
                code.visitStmt2R(OR_INT_2ADDR,0,7);
                code.visitLabel(L24);
                code.visitStmt2R(MOVE,7,0);
                code.visitLabel(L25);
                code.visitStmt2R(MOVE,0,4);
                code.visitLabel(L26);
                code.visitJumpStmt(GOTO,-1,-1,L17);
                code.visitLabel(L27);
                code.visitConstStmt(CONST_16,0, Integer.valueOf(46)); // int: 0x0000002e  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L20);
                code.visitLabel(L28);
                code.visitConstStmt(CONST_16,10, Integer.valueOf(25)); // int: 0x00000019  float:0.000000
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1,2,7,10,9},new Method("Lorg/mortbay/jetty/security/UnixCrypt;","des_cipher",new String[]{ "J","I","I","[J"},"J"));
                code.visitLabel(L29);
                code.visitStmt1R(MOVE_RESULT_WIDE,9);
                code.visitLabel(L30);
                code.visitConstStmt(CONST_16,0, Integer.valueOf(12)); // int: 0x0000000c  float:0.000000
                code.visitFieldStmt(SGET_OBJECT,1,-1,new Field("Lorg/mortbay/jetty/security/UnixCrypt;","ITOA64","[B"));
                code.visitLabel(L31);
                code.visitStmt2R(LONG_TO_INT,2,9);
                code.visitStmt2R1N(SHL_INT_LIT8,2,2,2);
                code.visitStmt2R1N(AND_INT_LIT8,2,2,63);
                code.visitStmt3R(AGET_BYTE,1,1,2);
                code.visitStmt3R(APUT_BYTE,1,3,0);
                code.visitLabel(L32);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(4)); // int: 0x00000004  float:0.000000
                code.visitStmt3R(SHR_LONG,0,9,0);
                code.visitLabel(L33);
                code.visitConstStmt(CONST_16,9, Integer.valueOf(12)); // int: 0x0000000c  float:0.000000
                code.visitLabel(L34);
                code.visitStmt2R1N(ADD_INT_LIT8,9,9,-1);
                code.visitConstStmt(CONST_4,10, Integer.valueOf(2)); // int: 0x00000002  float:0.000000
                code.visitJumpStmt(IF_LT,9,10,L37);
                code.visitLabel(L35);
                code.visitFieldStmt(SGET_OBJECT,10,-1,new Field("Lorg/mortbay/jetty/security/UnixCrypt;","ITOA64","[B"));
                code.visitStmt2R(LONG_TO_INT,2,0);
                code.visitStmt2R1N(AND_INT_LIT8,2,2,63);
                code.visitStmt3R(AGET_BYTE,10,10,2);
                code.visitStmt3R(APUT_BYTE,10,3,9);
                code.visitLabel(L36);
                code.visitConstStmt(CONST_4,10, Integer.valueOf(6)); // int: 0x00000006  float:0.000000
                code.visitStmt2R(SHR_LONG_2ADDR,0,10);
                code.visitJumpStmt(GOTO,-1,-1,L34);
                code.visitLabel(L37);
                code.visitTypeStmt(NEW_INSTANCE,9,-1,"Ljava/lang/String;");
                code.visitLabel(L38);
                code.visitConstStmt(CONST_4,10, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitConstStmt(CONST_16,1, Integer.valueOf(13)); // int: 0x0000000d  float:0.000000
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 9,3,10,0,1},new Method("Ljava/lang/String;","<init>",new String[]{ "[B","I","I","I"},"V"));
                code.visitLabel(L39);
                code.visitStmt2R(MOVE_OBJECT,0,9);
                code.visitStmt2R(MOVE_WIDE,9,5);
                code.visitLabel(L40);
                code.visitJumpStmt(GOTO,-1,-1,L6);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m003_des_cipher(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PRIVATE|ACC_STATIC, new Method("Lorg/mortbay/jetty/security/UnixCrypt;","des_cipher",new String[]{ "J","I","I","[J"},"J"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(17);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"in");
                ddv.visitParameterName(1,"salt");
                ddv.visitParameterName(2,"num_iter");
                ddv.visitParameterName(3,"KS");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(353,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(354,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(355,L2);
                ddv.visitStartLocal(12,L2,"L","J",null);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(356,L3);
                ddv.visitStartLocal(0,L3,"R","J",null);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(357,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(358,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(361,L6);
                DexLabel L7=new DexLabel();
                ddv.visitEndLocal(12,L7);
                ddv.visitEndLocal(0,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(362,L8);
                ddv.visitRestartLocal(12,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(364,L9);
                ddv.visitRestartLocal(0,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(365,L10);
                DexLabel L11=new DexLabel();
                ddv.visitStartLocal(2,L11,"loop_count","I",null);
                DexLabel L12=new DexLabel();
                ddv.visitStartLocal(6,L12,"loop_count","I",null);
                DexLabel L13=new DexLabel();
                ddv.visitStartLocal(2,L13,"R","J",null);
                DexLabel L14=new DexLabel();
                ddv.visitEndLocal(12,L14);
                ddv.visitStartLocal(0,L14,"L","J",null);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(370,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(371,L16);
                ddv.visitStartLocal(4,L16,"kp","J",null);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(372,L17);
                ddv.visitStartLocal(12,L17,"k","J",null);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(373,L18);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(375,L19);
                ddv.visitStartLocal(12,L19,"B","J",null);
                DexLabel L20=new DexLabel();
                ddv.visitEndLocal(4,L20);
                DexLabel L21=new DexLabel();
                ddv.visitEndLocal(12,L21);
                DexLabel L22=new DexLabel();
                ddv.visitLineNumber(380,L22);
                DexLabel L23=new DexLabel();
                ddv.visitLineNumber(381,L23);
                ddv.visitRestartLocal(4,L23);
                DexLabel L24=new DexLabel();
                ddv.visitLineNumber(382,L24);
                ddv.visitStartLocal(12,L24,"k","J",null);
                DexLabel L25=new DexLabel();
                ddv.visitLineNumber(383,L25);
                DexLabel L26=new DexLabel();
                ddv.visitLineNumber(385,L26);
                ddv.visitStartLocal(12,L26,"B","J",null);
                DexLabel L27=new DexLabel();
                ddv.visitEndLocal(4,L27);
                DexLabel L28=new DexLabel();
                ddv.visitEndLocal(12,L28);
                DexLabel L29=new DexLabel();
                ddv.visitLineNumber(365,L29);
                ddv.visitStartLocal(12,L29,"R","J",null);
                DexLabel L30=new DexLabel();
                ddv.visitStartLocal(2,L30,"loop_count","I",null);
                DexLabel L31=new DexLabel();
                ddv.visitStartLocal(2,L31,"R","J",null);
                DexLabel L32=new DexLabel();
                ddv.visitLineNumber(391,L32);
                ddv.visitEndLocal(12,L32);
                DexLabel L33=new DexLabel();
                ddv.visitLineNumber(392,L33);
                ddv.visitStartLocal(12,L33,"L","J",null);
                DexLabel L34=new DexLabel();
                ddv.visitLineNumber(393,L34);
                ddv.visitStartLocal(0,L34,"R","J",null);
                DexLabel L35=new DexLabel();
                ddv.visitLineNumber(395,L35);
                ddv.visitEndLocal(6,L35);
                ddv.visitEndLocal(2,L35);
                DexLabel L36=new DexLabel();
                ddv.visitLineNumber(398,L36);
                DexLabel L37=new DexLabel();
                ddv.visitEndLocal(16,L37);
                ddv.visitEndLocal(14,L37);
                ddv.visitEndLocal(0,L37);
                DexLabel L38=new DexLabel();
                ddv.visitLineNumber(400,L38);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 14},new Method("Lorg/mortbay/jetty/security/UnixCrypt;","to_six_bit",new String[]{ "I"},"I"));
                code.visitStmt1R(MOVE_RESULT,14);
                code.visitLabel(L1);
                code.visitStmt2R(MOVE_WIDE,12,12);
                code.visitLabel(L2);
                code.visitStmt2R(MOVE_WIDE,0,12);
                code.visitLabel(L3);
                code.visitConstStmt(CONST_WIDE,2,Long.valueOf(6148914691236517205L)); // long: 0x5555555555555555  double:11945305291614955000000000000000000000000000000000000000000000000000000000000000000000000000000000000000.000000
                code.visitStmt2R(AND_LONG_2ADDR,12,2);
                code.visitLabel(L4);
                code.visitConstStmt(CONST_WIDE,2,Long.valueOf(-6148914694099828736L)); // long: 0xaaaaaaaa00000000  double:-0.000000
                code.visitStmt2R(AND_LONG_2ADDR,2,0);
                code.visitConstStmt(CONST_4,4, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitStmt2R(SHR_LONG_2ADDR,0,4);
                code.visitConstStmt(CONST_WIDE_32,4,Long.valueOf(1431655765L)); // long: 0x0000000055555555  double:0.000000
                code.visitStmt2R(AND_LONG_2ADDR,0,4);
                code.visitStmt2R(OR_LONG_2ADDR,0,2);
                code.visitLabel(L5);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitStmt3R(SHL_LONG,2,12,2);
                code.visitConstStmt(CONST_16,4, Integer.valueOf(32)); // int: 0x00000020  float:0.000000
                code.visitStmt2R(SHL_LONG_2ADDR,12,4);
                code.visitStmt2R(OR_LONG_2ADDR,12,2);
                code.visitConstStmt(CONST_WIDE,2,Long.valueOf(-4294967296L)); // long: 0xffffffff00000000  double:NaN
                code.visitStmt2R(AND_LONG_2ADDR,12,2);
                code.visitConstStmt(CONST_16,2, Integer.valueOf(32)); // int: 0x00000020  float:0.000000
                code.visitStmt3R(SHR_LONG,2,0,2);
                code.visitStmt2R(OR_LONG_2ADDR,0,2);
                code.visitConstStmt(CONST_WIDE,2,Long.valueOf(4294967295L)); // long: 0x00000000ffffffff  double:0.000000
                code.visitStmt2R(AND_LONG_2ADDR,0,2);
                code.visitStmt2R(OR_LONG_2ADDR,12,0);
                code.visitLabel(L6);
                code.visitConstStmt(CONST_16,0, Integer.valueOf(32)); // int: 0x00000020  float:0.000000
                code.visitStmt2R(SHR_LONG_2ADDR,12,0);
                code.visitStmt2R(LONG_TO_INT,12,12);
                code.visitFieldStmt(SGET_OBJECT,13,-1,new Field("Lorg/mortbay/jetty/security/UnixCrypt;","IE3264","[[J"));
                code.visitLabel(L7);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 12,13},new Method("Lorg/mortbay/jetty/security/UnixCrypt;","perm3264",new String[]{ "I","[[J"},"J"));
                code.visitStmt1R(MOVE_RESULT_WIDE,12);
                code.visitLabel(L8);
                code.visitConstStmt(CONST_WIDE_16,0,Long.valueOf(-1L)); // long: 0xffffffffffffffff  double:NaN
                code.visitStmt2R(AND_LONG_2ADDR,0,12);
                code.visitStmt2R(LONG_TO_INT,0,0);
                code.visitFieldStmt(SGET_OBJECT,1,-1,new Field("Lorg/mortbay/jetty/security/UnixCrypt;","IE3264","[[J"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0,1},new Method("Lorg/mortbay/jetty/security/UnixCrypt;","perm3264",new String[]{ "I","[[J"},"J"));
                code.visitStmt1R(MOVE_RESULT_WIDE,0);
                code.visitLabel(L9);
                code.visitStmt2R1N(ADD_INT_LIT8,15,15,-1);
                code.visitJumpStmt(IF_LTZ,15,-1,L35);
                code.visitLabel(L10);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L11);
                code.visitStmt2R(MOVE,6,2);
                code.visitLabel(L12);
                code.visitStmt2R(MOVE_WIDE,2,0);
                code.visitLabel(L13);
                code.visitStmt2R(MOVE_WIDE,0,12);
                code.visitLabel(L14);
                code.visitConstStmt(CONST_16,12, Integer.valueOf(8)); // int: 0x00000008  float:0.000000
                code.visitJumpStmt(IF_GE,6,12,L32);
                code.visitLabel(L15);
                code.visitStmt2R1N(SHL_INT_LIT8,12,6,1);
                code.visitStmt3R(AGET_WIDE,4,16,12);
                code.visitLabel(L16);
                code.visitConstStmt(CONST_16,12, Integer.valueOf(32)); // int: 0x00000020  float:0.000000
                code.visitStmt3R(SHR_LONG,12,2,12);
                code.visitStmt2R(XOR_LONG_2ADDR,12,2);
                code.visitStmt2R(INT_TO_LONG,7,14);
                code.visitStmt2R(AND_LONG_2ADDR,12,7);
                code.visitConstStmt(CONST_WIDE,7,Long.valueOf(4294967295L)); // long: 0x00000000ffffffff  double:0.000000
                code.visitStmt2R(AND_LONG_2ADDR,12,7);
                code.visitLabel(L17);
                code.visitConstStmt(CONST_16,7, Integer.valueOf(32)); // int: 0x00000020  float:0.000000
                code.visitStmt3R(SHL_LONG,7,12,7);
                code.visitStmt2R(OR_LONG_2ADDR,12,7);
                code.visitLabel(L18);
                code.visitStmt2R(XOR_LONG_2ADDR,12,2);
                code.visitStmt2R(XOR_LONG_2ADDR,12,4);
                code.visitLabel(L19);
                code.visitFieldStmt(SGET_OBJECT,4,-1,new Field("Lorg/mortbay/jetty/security/UnixCrypt;","SPE","[[J"));
                code.visitLabel(L20);
                code.visitConstStmt(CONST_4,5, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitStmt3R(AGET_OBJECT,4,4,5);
                code.visitConstStmt(CONST_16,5, Integer.valueOf(58)); // int: 0x0000003a  float:0.000000
                code.visitStmt3R(SHR_LONG,7,12,5);
                code.visitConstStmt(CONST_WIDE_16,9,Long.valueOf(63L)); // long: 0x000000000000003f  double:0.000000
                code.visitStmt2R(AND_LONG_2ADDR,7,9);
                code.visitStmt2R(LONG_TO_INT,5,7);
                code.visitStmt3R(AGET_WIDE,4,4,5);
                code.visitFieldStmt(SGET_OBJECT,7,-1,new Field("Lorg/mortbay/jetty/security/UnixCrypt;","SPE","[[J"));
                code.visitConstStmt(CONST_4,8, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitStmt3R(AGET_OBJECT,7,7,8);
                code.visitConstStmt(CONST_16,8, Integer.valueOf(50)); // int: 0x00000032  float:0.000000
                code.visitStmt3R(SHR_LONG,8,12,8);
                code.visitConstStmt(CONST_WIDE_16,10,Long.valueOf(63L)); // long: 0x000000000000003f  double:0.000000
                code.visitStmt2R(AND_LONG_2ADDR,8,10);
                code.visitStmt2R(LONG_TO_INT,8,8);
                code.visitStmt3R(AGET_WIDE,7,7,8);
                code.visitStmt2R(XOR_LONG_2ADDR,4,7);
                code.visitFieldStmt(SGET_OBJECT,7,-1,new Field("Lorg/mortbay/jetty/security/UnixCrypt;","SPE","[[J"));
                code.visitConstStmt(CONST_4,8, Integer.valueOf(2)); // int: 0x00000002  float:0.000000
                code.visitStmt3R(AGET_OBJECT,7,7,8);
                code.visitConstStmt(CONST_16,8, Integer.valueOf(42)); // int: 0x0000002a  float:0.000000
                code.visitStmt3R(SHR_LONG,8,12,8);
                code.visitConstStmt(CONST_WIDE_16,10,Long.valueOf(63L)); // long: 0x000000000000003f  double:0.000000
                code.visitStmt2R(AND_LONG_2ADDR,8,10);
                code.visitStmt2R(LONG_TO_INT,8,8);
                code.visitStmt3R(AGET_WIDE,7,7,8);
                code.visitStmt2R(XOR_LONG_2ADDR,4,7);
                code.visitFieldStmt(SGET_OBJECT,7,-1,new Field("Lorg/mortbay/jetty/security/UnixCrypt;","SPE","[[J"));
                code.visitConstStmt(CONST_4,8, Integer.valueOf(3)); // int: 0x00000003  float:0.000000
                code.visitStmt3R(AGET_OBJECT,7,7,8);
                code.visitConstStmt(CONST_16,8, Integer.valueOf(34)); // int: 0x00000022  float:0.000000
                code.visitStmt3R(SHR_LONG,8,12,8);
                code.visitConstStmt(CONST_WIDE_16,10,Long.valueOf(63L)); // long: 0x000000000000003f  double:0.000000
                code.visitStmt2R(AND_LONG_2ADDR,8,10);
                code.visitStmt2R(LONG_TO_INT,8,8);
                code.visitStmt3R(AGET_WIDE,7,7,8);
                code.visitStmt2R(XOR_LONG_2ADDR,4,7);
                code.visitFieldStmt(SGET_OBJECT,7,-1,new Field("Lorg/mortbay/jetty/security/UnixCrypt;","SPE","[[J"));
                code.visitConstStmt(CONST_4,8, Integer.valueOf(4)); // int: 0x00000004  float:0.000000
                code.visitStmt3R(AGET_OBJECT,7,7,8);
                code.visitConstStmt(CONST_16,8, Integer.valueOf(26)); // int: 0x0000001a  float:0.000000
                code.visitStmt3R(SHR_LONG,8,12,8);
                code.visitConstStmt(CONST_WIDE_16,10,Long.valueOf(63L)); // long: 0x000000000000003f  double:0.000000
                code.visitStmt2R(AND_LONG_2ADDR,8,10);
                code.visitStmt2R(LONG_TO_INT,8,8);
                code.visitStmt3R(AGET_WIDE,7,7,8);
                code.visitStmt2R(XOR_LONG_2ADDR,4,7);
                code.visitFieldStmt(SGET_OBJECT,7,-1,new Field("Lorg/mortbay/jetty/security/UnixCrypt;","SPE","[[J"));
                code.visitConstStmt(CONST_4,8, Integer.valueOf(5)); // int: 0x00000005  float:0.000000
                code.visitStmt3R(AGET_OBJECT,7,7,8);
                code.visitConstStmt(CONST_16,8, Integer.valueOf(18)); // int: 0x00000012  float:0.000000
                code.visitStmt3R(SHR_LONG,8,12,8);
                code.visitConstStmt(CONST_WIDE_16,10,Long.valueOf(63L)); // long: 0x000000000000003f  double:0.000000
                code.visitStmt2R(AND_LONG_2ADDR,8,10);
                code.visitStmt2R(LONG_TO_INT,8,8);
                code.visitStmt3R(AGET_WIDE,7,7,8);
                code.visitStmt2R(XOR_LONG_2ADDR,4,7);
                code.visitFieldStmt(SGET_OBJECT,7,-1,new Field("Lorg/mortbay/jetty/security/UnixCrypt;","SPE","[[J"));
                code.visitConstStmt(CONST_4,8, Integer.valueOf(6)); // int: 0x00000006  float:0.000000
                code.visitStmt3R(AGET_OBJECT,7,7,8);
                code.visitConstStmt(CONST_16,8, Integer.valueOf(10)); // int: 0x0000000a  float:0.000000
                code.visitStmt3R(SHR_LONG,8,12,8);
                code.visitConstStmt(CONST_WIDE_16,10,Long.valueOf(63L)); // long: 0x000000000000003f  double:0.000000
                code.visitStmt2R(AND_LONG_2ADDR,8,10);
                code.visitStmt2R(LONG_TO_INT,8,8);
                code.visitStmt3R(AGET_WIDE,7,7,8);
                code.visitStmt2R(XOR_LONG_2ADDR,4,7);
                code.visitFieldStmt(SGET_OBJECT,7,-1,new Field("Lorg/mortbay/jetty/security/UnixCrypt;","SPE","[[J"));
                code.visitConstStmt(CONST_4,8, Integer.valueOf(7)); // int: 0x00000007  float:0.000000
                code.visitStmt3R(AGET_OBJECT,7,7,8);
                code.visitConstStmt(CONST_4,8, Integer.valueOf(2)); // int: 0x00000002  float:0.000000
                code.visitStmt2R(SHR_LONG_2ADDR,12,8);
                code.visitConstStmt(CONST_WIDE_16,8,Long.valueOf(63L)); // long: 0x000000000000003f  double:0.000000
                code.visitStmt2R(AND_LONG_2ADDR,12,8);
                code.visitStmt2R(LONG_TO_INT,12,12);
                code.visitStmt3R(AGET_WIDE,12,7,12);
                code.visitLabel(L21);
                code.visitStmt2R(XOR_LONG_2ADDR,12,4);
                code.visitStmt2R(XOR_LONG_2ADDR,0,12);
                code.visitLabel(L22);
                code.visitStmt2R1N(SHL_INT_LIT8,12,6,1);
                code.visitStmt2R1N(ADD_INT_LIT8,12,12,1);
                code.visitStmt3R(AGET_WIDE,4,16,12);
                code.visitLabel(L23);
                code.visitConstStmt(CONST_16,12, Integer.valueOf(32)); // int: 0x00000020  float:0.000000
                code.visitStmt3R(SHR_LONG,12,0,12);
                code.visitStmt2R(XOR_LONG_2ADDR,12,0);
                code.visitStmt2R(INT_TO_LONG,7,14);
                code.visitStmt2R(AND_LONG_2ADDR,12,7);
                code.visitConstStmt(CONST_WIDE,7,Long.valueOf(4294967295L)); // long: 0x00000000ffffffff  double:0.000000
                code.visitStmt2R(AND_LONG_2ADDR,12,7);
                code.visitLabel(L24);
                code.visitConstStmt(CONST_16,7, Integer.valueOf(32)); // int: 0x00000020  float:0.000000
                code.visitStmt3R(SHL_LONG,7,12,7);
                code.visitStmt2R(OR_LONG_2ADDR,12,7);
                code.visitLabel(L25);
                code.visitStmt2R(XOR_LONG_2ADDR,12,0);
                code.visitStmt2R(XOR_LONG_2ADDR,12,4);
                code.visitLabel(L26);
                code.visitFieldStmt(SGET_OBJECT,4,-1,new Field("Lorg/mortbay/jetty/security/UnixCrypt;","SPE","[[J"));
                code.visitLabel(L27);
                code.visitConstStmt(CONST_4,5, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitStmt3R(AGET_OBJECT,4,4,5);
                code.visitConstStmt(CONST_16,5, Integer.valueOf(58)); // int: 0x0000003a  float:0.000000
                code.visitStmt3R(SHR_LONG,7,12,5);
                code.visitConstStmt(CONST_WIDE_16,9,Long.valueOf(63L)); // long: 0x000000000000003f  double:0.000000
                code.visitStmt2R(AND_LONG_2ADDR,7,9);
                code.visitStmt2R(LONG_TO_INT,5,7);
                code.visitStmt3R(AGET_WIDE,4,4,5);
                code.visitFieldStmt(SGET_OBJECT,7,-1,new Field("Lorg/mortbay/jetty/security/UnixCrypt;","SPE","[[J"));
                code.visitConstStmt(CONST_4,8, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitStmt3R(AGET_OBJECT,7,7,8);
                code.visitConstStmt(CONST_16,8, Integer.valueOf(50)); // int: 0x00000032  float:0.000000
                code.visitStmt3R(SHR_LONG,8,12,8);
                code.visitConstStmt(CONST_WIDE_16,10,Long.valueOf(63L)); // long: 0x000000000000003f  double:0.000000
                code.visitStmt2R(AND_LONG_2ADDR,8,10);
                code.visitStmt2R(LONG_TO_INT,8,8);
                code.visitStmt3R(AGET_WIDE,7,7,8);
                code.visitStmt2R(XOR_LONG_2ADDR,4,7);
                code.visitFieldStmt(SGET_OBJECT,7,-1,new Field("Lorg/mortbay/jetty/security/UnixCrypt;","SPE","[[J"));
                code.visitConstStmt(CONST_4,8, Integer.valueOf(2)); // int: 0x00000002  float:0.000000
                code.visitStmt3R(AGET_OBJECT,7,7,8);
                code.visitConstStmt(CONST_16,8, Integer.valueOf(42)); // int: 0x0000002a  float:0.000000
                code.visitStmt3R(SHR_LONG,8,12,8);
                code.visitConstStmt(CONST_WIDE_16,10,Long.valueOf(63L)); // long: 0x000000000000003f  double:0.000000
                code.visitStmt2R(AND_LONG_2ADDR,8,10);
                code.visitStmt2R(LONG_TO_INT,8,8);
                code.visitStmt3R(AGET_WIDE,7,7,8);
                code.visitStmt2R(XOR_LONG_2ADDR,4,7);
                code.visitFieldStmt(SGET_OBJECT,7,-1,new Field("Lorg/mortbay/jetty/security/UnixCrypt;","SPE","[[J"));
                code.visitConstStmt(CONST_4,8, Integer.valueOf(3)); // int: 0x00000003  float:0.000000
                code.visitStmt3R(AGET_OBJECT,7,7,8);
                code.visitConstStmt(CONST_16,8, Integer.valueOf(34)); // int: 0x00000022  float:0.000000
                code.visitStmt3R(SHR_LONG,8,12,8);
                code.visitConstStmt(CONST_WIDE_16,10,Long.valueOf(63L)); // long: 0x000000000000003f  double:0.000000
                code.visitStmt2R(AND_LONG_2ADDR,8,10);
                code.visitStmt2R(LONG_TO_INT,8,8);
                code.visitStmt3R(AGET_WIDE,7,7,8);
                code.visitStmt2R(XOR_LONG_2ADDR,4,7);
                code.visitFieldStmt(SGET_OBJECT,7,-1,new Field("Lorg/mortbay/jetty/security/UnixCrypt;","SPE","[[J"));
                code.visitConstStmt(CONST_4,8, Integer.valueOf(4)); // int: 0x00000004  float:0.000000
                code.visitStmt3R(AGET_OBJECT,7,7,8);
                code.visitConstStmt(CONST_16,8, Integer.valueOf(26)); // int: 0x0000001a  float:0.000000
                code.visitStmt3R(SHR_LONG,8,12,8);
                code.visitConstStmt(CONST_WIDE_16,10,Long.valueOf(63L)); // long: 0x000000000000003f  double:0.000000
                code.visitStmt2R(AND_LONG_2ADDR,8,10);
                code.visitStmt2R(LONG_TO_INT,8,8);
                code.visitStmt3R(AGET_WIDE,7,7,8);
                code.visitStmt2R(XOR_LONG_2ADDR,4,7);
                code.visitFieldStmt(SGET_OBJECT,7,-1,new Field("Lorg/mortbay/jetty/security/UnixCrypt;","SPE","[[J"));
                code.visitConstStmt(CONST_4,8, Integer.valueOf(5)); // int: 0x00000005  float:0.000000
                code.visitStmt3R(AGET_OBJECT,7,7,8);
                code.visitConstStmt(CONST_16,8, Integer.valueOf(18)); // int: 0x00000012  float:0.000000
                code.visitStmt3R(SHR_LONG,8,12,8);
                code.visitConstStmt(CONST_WIDE_16,10,Long.valueOf(63L)); // long: 0x000000000000003f  double:0.000000
                code.visitStmt2R(AND_LONG_2ADDR,8,10);
                code.visitStmt2R(LONG_TO_INT,8,8);
                code.visitStmt3R(AGET_WIDE,7,7,8);
                code.visitStmt2R(XOR_LONG_2ADDR,4,7);
                code.visitFieldStmt(SGET_OBJECT,7,-1,new Field("Lorg/mortbay/jetty/security/UnixCrypt;","SPE","[[J"));
                code.visitConstStmt(CONST_4,8, Integer.valueOf(6)); // int: 0x00000006  float:0.000000
                code.visitStmt3R(AGET_OBJECT,7,7,8);
                code.visitConstStmt(CONST_16,8, Integer.valueOf(10)); // int: 0x0000000a  float:0.000000
                code.visitStmt3R(SHR_LONG,8,12,8);
                code.visitConstStmt(CONST_WIDE_16,10,Long.valueOf(63L)); // long: 0x000000000000003f  double:0.000000
                code.visitStmt2R(AND_LONG_2ADDR,8,10);
                code.visitStmt2R(LONG_TO_INT,8,8);
                code.visitStmt3R(AGET_WIDE,7,7,8);
                code.visitStmt2R(XOR_LONG_2ADDR,4,7);
                code.visitFieldStmt(SGET_OBJECT,7,-1,new Field("Lorg/mortbay/jetty/security/UnixCrypt;","SPE","[[J"));
                code.visitConstStmt(CONST_4,8, Integer.valueOf(7)); // int: 0x00000007  float:0.000000
                code.visitStmt3R(AGET_OBJECT,7,7,8);
                code.visitConstStmt(CONST_4,8, Integer.valueOf(2)); // int: 0x00000002  float:0.000000
                code.visitStmt2R(SHR_LONG_2ADDR,12,8);
                code.visitConstStmt(CONST_WIDE_16,8,Long.valueOf(63L)); // long: 0x000000000000003f  double:0.000000
                code.visitStmt2R(AND_LONG_2ADDR,12,8);
                code.visitStmt2R(LONG_TO_INT,12,12);
                code.visitStmt3R(AGET_WIDE,12,7,12);
                code.visitLabel(L28);
                code.visitStmt2R(XOR_LONG_2ADDR,12,4);
                code.visitStmt2R(XOR_LONG_2ADDR,12,2);
                code.visitLabel(L29);
                code.visitStmt2R1N(ADD_INT_LIT8,2,6,1);
                code.visitLabel(L30);
                code.visitStmt2R(MOVE,6,2);
                code.visitStmt2R(MOVE_WIDE,2,12);
                code.visitLabel(L31);
                code.visitJumpStmt(GOTO_16,-1,-1,L14);
                code.visitLabel(L32);
                code.visitStmt3R(XOR_LONG,12,0,2);
                code.visitLabel(L33);
                code.visitStmt3R(XOR_LONG,0,2,12);
                code.visitLabel(L34);
                code.visitStmt2R(XOR_LONG_2ADDR,12,0);
                code.visitJumpStmt(GOTO_16,-1,-1,L9);
                code.visitLabel(L35);
                code.visitConstStmt(CONST_16,14, Integer.valueOf(35)); // int: 0x00000023  float:0.000000
                code.visitStmt3R(SHR_LONG,14,12,14);
                code.visitConstStmt(CONST_WIDE_32,2,Long.valueOf(252645135L)); // long: 0x000000000f0f0f0f  double:0.000000
                code.visitStmt2R(AND_LONG_2ADDR,14,2);
                code.visitConstStmt(CONST_WIDE_16,2,Long.valueOf(-1L)); // long: 0xffffffffffffffff  double:NaN
                code.visitStmt2R(AND_LONG_2ADDR,12,2);
                code.visitConstStmt(CONST_16,16, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitStmt3R(SHL_LONG,12,12,16);
                code.visitConstStmt(CONST_WIDE,2,Long.valueOf(4042322160L)); // long: 0x00000000f0f0f0f0  double:0.000000
                code.visitStmt2R(AND_LONG_2ADDR,12,2);
                code.visitStmt2R(OR_LONG_2ADDR,12,14);
                code.visitConstStmt(CONST_16,14, Integer.valueOf(32)); // int: 0x00000020  float:0.000000
                code.visitStmt2R(SHL_LONG_2ADDR,12,14);
                code.visitConstStmt(CONST_16,14, Integer.valueOf(35)); // int: 0x00000023  float:0.000000
                code.visitStmt3R(SHR_LONG,14,0,14);
                code.visitConstStmt(CONST_WIDE_32,2,Long.valueOf(252645135L)); // long: 0x000000000f0f0f0f  double:0.000000
                code.visitStmt2R(AND_LONG_2ADDR,14,2);
                code.visitConstStmt(CONST_WIDE_16,2,Long.valueOf(-1L)); // long: 0xffffffffffffffff  double:NaN
                code.visitStmt2R(AND_LONG_2ADDR,0,2);
                code.visitConstStmt(CONST_16,16, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitStmt3R(SHL_LONG,0,0,16);
                code.visitConstStmt(CONST_WIDE,2,Long.valueOf(4042322160L)); // long: 0x00000000f0f0f0f0  double:0.000000
                code.visitStmt2R(AND_LONG_2ADDR,0,2);
                code.visitStmt2R(OR_LONG_2ADDR,14,0);
                code.visitStmt2R(OR_LONG_2ADDR,12,14);
                code.visitLabel(L36);
                code.visitFieldStmt(SGET_OBJECT,14,-1,new Field("Lorg/mortbay/jetty/security/UnixCrypt;","CF6464","[[J"));
                code.visitLabel(L37);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 12,13,14},new Method("Lorg/mortbay/jetty/security/UnixCrypt;","perm6464",new String[]{ "J","[[J"},"J"));
                code.visitStmt1R(MOVE_RESULT_WIDE,12);
                code.visitLabel(L38);
                code.visitStmt1R(RETURN_WIDE,12);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m004_des_setkey(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PRIVATE|ACC_STATIC, new Method("Lorg/mortbay/jetty/security/UnixCrypt;","des_setkey",new String[]{ "J"},"[J"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(12);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"keyword");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(335,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(336,L2);
                ddv.visitStartLocal(0,L2,"K","J",null);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(337,L3);
                ddv.visitStartLocal(2,L3,"KS","[J",null);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(339,L4);
                DexLabel L5=new DexLabel();
                ddv.visitStartLocal(3,L5,"i","I",null);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(340,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(341,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(343,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(339,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(345,L10);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_WIDE,8,Long.valueOf(-217020518463700993L)); // long: 0xfcfcfcfcffffffff  double:-1157117777211213000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000.000000
                code.visitConstStmt(CONST_16,7, Integer.valueOf(16)); // int: 0x00000010  float:0.000000
                code.visitLabel(L1);
                code.visitFieldStmt(SGET_OBJECT,4,-1,new Field("Lorg/mortbay/jetty/security/UnixCrypt;","PC1ROT","[[J"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 10,11,4},new Method("Lorg/mortbay/jetty/security/UnixCrypt;","perm6464",new String[]{ "J","[[J"},"J"));
                code.visitStmt1R(MOVE_RESULT_WIDE,0);
                code.visitLabel(L2);
                code.visitTypeStmt(NEW_ARRAY,2,7,"[J");
                code.visitLabel(L3);
                code.visitConstStmt(CONST_4,4, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitStmt3R(AND_LONG,5,0,8);
                code.visitStmt3R(APUT_WIDE,5,2,4);
                code.visitLabel(L4);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitLabel(L5);
                code.visitJumpStmt(IF_GE,3,7,L10);
                code.visitLabel(L6);
                code.visitStmt3R(APUT_WIDE,0,2,3);
                code.visitLabel(L7);
                code.visitFieldStmt(SGET_OBJECT,4,-1,new Field("Lorg/mortbay/jetty/security/UnixCrypt;","PC2ROT","[[[J"));
                code.visitFieldStmt(SGET_OBJECT,5,-1,new Field("Lorg/mortbay/jetty/security/UnixCrypt;","Rotates","[B"));
                code.visitStmt3R(AGET_BYTE,5,5,3);
                code.visitConstStmt(CONST_4,6, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitStmt2R(SUB_INT_2ADDR,5,6);
                code.visitStmt3R(AGET_OBJECT,4,4,5);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0,1,4},new Method("Lorg/mortbay/jetty/security/UnixCrypt;","perm6464",new String[]{ "J","[[J"},"J"));
                code.visitStmt1R(MOVE_RESULT_WIDE,0);
                code.visitLabel(L8);
                code.visitStmt3R(AND_LONG,4,0,8);
                code.visitStmt3R(APUT_WIDE,4,2,3);
                code.visitLabel(L9);
                code.visitStmt2R1N(ADD_INT_LIT8,3,3,1);
                code.visitJumpStmt(GOTO,-1,-1,L5);
                code.visitLabel(L10);
                code.visitStmt1R(RETURN_OBJECT,2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m005_init_perm(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PRIVATE|ACC_STATIC, new Method("Lorg/mortbay/jetty/security/UnixCrypt;","init_perm",new String[]{ "[[J","[B","I"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(14);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"perm");
                ddv.visitParameterName(1,"p");
                ddv.visitParameterName(2,"chars_out");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(407,L1);
                DexLabel L2=new DexLabel();
                ddv.visitStartLocal(2,L2,"k","I",null);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(409,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(410,L4);
                ddv.visitStartLocal(3,L4,"l","I",null);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(407,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(411,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(412,L7);
                ddv.visitStartLocal(0,L7,"i","I",null);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(413,L8);
                DexLabel L9=new DexLabel();
                ddv.visitStartLocal(1,L9,"j","I",null);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(414,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(415,L11);
                ddv.visitStartLocal(4,L11,"s","I",null);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(413,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(418,L13);
                ddv.visitEndLocal(3,L13);
                ddv.visitEndLocal(0,L13);
                ddv.visitEndLocal(1,L13);
                ddv.visitEndLocal(4,L13);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,10, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L2);
                code.visitStmt2R1N(MUL_INT_LIT8,5,13,8);
                code.visitJumpStmt(IF_GE,2,5,L13);
                code.visitLabel(L3);
                code.visitStmt3R(AGET_BYTE,5,12,2);
                code.visitStmt3R(SUB_INT,3,5,10);
                code.visitLabel(L4);
                code.visitJumpStmt(IF_GEZ,3,-1,L6);
                code.visitLabel(L5);
                code.visitStmt2R1N(ADD_INT_LIT8,2,2,1);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitLabel(L6);
                code.visitStmt2R1N(SHR_INT_LIT8,0,3,2);
                code.visitLabel(L7);
                code.visitStmt2R1N(AND_INT_LIT8,5,3,3);
                code.visitStmt3R(SHL_INT,3,10,5);
                code.visitLabel(L8);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L9);
                code.visitConstStmt(CONST_16,5, Integer.valueOf(16)); // int: 0x00000010  float:0.000000
                code.visitJumpStmt(IF_GE,1,5,L5);
                code.visitLabel(L10);
                code.visitStmt2R1N(AND_INT_LIT8,5,2,7);
                code.visitConstStmt(CONST_4,6, Integer.valueOf(7)); // int: 0x00000007  float:0.000000
                code.visitStmt2R1N(SHR_INT_LIT8,7,2,3);
                code.visitStmt2R(SUB_INT_2ADDR,6,7);
                code.visitStmt2R1N(SHL_INT_LIT8,6,6,3);
                code.visitStmt3R(ADD_INT,4,5,6);
                code.visitLabel(L11);
                code.visitStmt3R(AND_INT,5,1,3);
                code.visitJumpStmt(IF_EQZ,5,-1,L12);
                code.visitStmt3R(AGET_OBJECT,5,11,0);
                code.visitStmt3R(AGET_WIDE,6,5,1);
                code.visitConstStmt(CONST_WIDE_16,8,Long.valueOf(1L)); // long: 0x0000000000000001  double:0.000000
                code.visitStmt2R(SHL_LONG_2ADDR,8,4);
                code.visitStmt2R(OR_LONG_2ADDR,6,8);
                code.visitStmt3R(APUT_WIDE,6,5,1);
                code.visitLabel(L12);
                code.visitStmt2R1N(ADD_INT_LIT8,1,1,1);
                code.visitJumpStmt(GOTO,-1,-1,L9);
                code.visitLabel(L13);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m006_main(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Lorg/mortbay/jetty/security/UnixCrypt;","main",new String[]{ "[Ljava/lang/String;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"arg");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(464,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(466,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(467,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(470,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(471,L5);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitLabel(L1);
                code.visitStmt2R(ARRAY_LENGTH,0,4);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(2)); // int: 0x00000002  float:0.000000
                code.visitJumpStmt(IF_EQ,0,1,L4);
                code.visitLabel(L2);
                code.visitFieldStmt(SGET_OBJECT,0,-1,new Field("Ljava/lang/System;","err","Ljava/io/PrintStream;"));
                code.visitConstStmt(CONST_STRING,1,"Usage - java org.mortbay.util.UnixCrypt <key> <salt>");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/io/PrintStream;","println",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 3},new Method("Ljava/lang/System;","exit",new String[]{ "I"},"V"));
                code.visitLabel(L4);
                code.visitFieldStmt(SGET_OBJECT,0,-1,new Field("Ljava/lang/System;","err","Ljava/io/PrintStream;"));
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,2,"Crypt=");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitStmt3R(AGET_OBJECT,2,4,2);
                code.visitStmt3R(AGET_OBJECT,3,4,3);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 2,3},new Method("Lorg/mortbay/jetty/security/UnixCrypt;","crypt",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/io/PrintStream;","println",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L5);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m007_perm3264(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PRIVATE|ACC_STATIC, new Method("Lorg/mortbay/jetty/security/UnixCrypt;","perm3264",new String[]{ "I","[[J"},"J"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(10);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"c");
                ddv.visitParameterName(1,"p");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(319,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(320,L1);
                ddv.visitStartLocal(1,L1,"out","J",null);
                DexLabel L2=new DexLabel();
                ddv.visitStartLocal(0,L2,"i","I",null);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(321,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(322,L4);
                ddv.visitStartLocal(3,L4,"t","I",null);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(323,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(324,L6);
                ddv.visitStartLocal(4,L6,"tp","J",null);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(325,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(326,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(327,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(328,L10);
                ddv.visitEndLocal(3,L10);
                ddv.visitEndLocal(4,L10);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_WIDE_16,1,Long.valueOf(0L)); // long: 0x0000000000000000  double:0.000000
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(4)); // int: 0x00000004  float:0.000000
                code.visitLabel(L2);
                code.visitStmt2R1N(ADD_INT_LIT8,0,0,-1);
                code.visitJumpStmt(IF_LTZ,0,-1,L10);
                code.visitLabel(L3);
                code.visitStmt2R1N(AND_INT_LIT16,3,8,255);
                code.visitLabel(L4);
                code.visitStmt2R1N(SHR_INT_LIT8,8,8,8);
                code.visitLabel(L5);
                code.visitStmt2R1N(SHL_INT_LIT8,6,0,1);
                code.visitStmt3R(AGET_OBJECT,6,9,6);
                code.visitStmt2R1N(AND_INT_LIT8,7,3,15);
                code.visitStmt3R(AGET_WIDE,4,6,7);
                code.visitLabel(L6);
                code.visitStmt2R(OR_LONG_2ADDR,1,4);
                code.visitLabel(L7);
                code.visitStmt2R1N(SHL_INT_LIT8,6,0,1);
                code.visitStmt2R1N(ADD_INT_LIT8,6,6,1);
                code.visitStmt3R(AGET_OBJECT,6,9,6);
                code.visitStmt2R1N(SHR_INT_LIT8,7,3,4);
                code.visitStmt3R(AGET_WIDE,4,6,7);
                code.visitLabel(L8);
                code.visitStmt2R(OR_LONG_2ADDR,1,4);
                code.visitLabel(L9);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitLabel(L10);
                code.visitStmt1R(RETURN_WIDE,1);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m008_perm6464(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PRIVATE|ACC_STATIC, new Method("Lorg/mortbay/jetty/security/UnixCrypt;","perm6464",new String[]{ "J","[[J"},"J"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(11);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"c");
                ddv.visitParameterName(1,"p");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(302,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(303,L1);
                ddv.visitStartLocal(1,L1,"out","J",null);
                DexLabel L2=new DexLabel();
                ddv.visitStartLocal(0,L2,"i","I",null);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(304,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(305,L4);
                ddv.visitStartLocal(3,L4,"t","I",null);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(306,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(307,L6);
                ddv.visitStartLocal(4,L6,"tp","J",null);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(308,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(309,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(310,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(311,L10);
                ddv.visitEndLocal(3,L10);
                ddv.visitEndLocal(4,L10);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_WIDE_16,1,Long.valueOf(0L)); // long: 0x0000000000000000  double:0.000000
                code.visitLabel(L1);
                code.visitConstStmt(CONST_16,0, Integer.valueOf(8)); // int: 0x00000008  float:0.000000
                code.visitLabel(L2);
                code.visitStmt2R1N(ADD_INT_LIT8,0,0,-1);
                code.visitJumpStmt(IF_LTZ,0,-1,L10);
                code.visitLabel(L3);
                code.visitConstStmt(CONST_WIDE_16,6,Long.valueOf(255L)); // long: 0x00000000000000ff  double:0.000000
                code.visitStmt2R(AND_LONG_2ADDR,6,8);
                code.visitStmt2R(LONG_TO_INT,3,6);
                code.visitLabel(L4);
                code.visitConstStmt(CONST_16,6, Integer.valueOf(8)); // int: 0x00000008  float:0.000000
                code.visitStmt2R(SHR_LONG_2ADDR,8,6);
                code.visitLabel(L5);
                code.visitStmt2R1N(SHL_INT_LIT8,6,0,1);
                code.visitStmt3R(AGET_OBJECT,6,10,6);
                code.visitStmt2R1N(AND_INT_LIT8,7,3,15);
                code.visitStmt3R(AGET_WIDE,4,6,7);
                code.visitLabel(L6);
                code.visitStmt2R(OR_LONG_2ADDR,1,4);
                code.visitLabel(L7);
                code.visitStmt2R1N(SHL_INT_LIT8,6,0,1);
                code.visitStmt2R1N(ADD_INT_LIT8,6,6,1);
                code.visitStmt3R(AGET_OBJECT,6,10,6);
                code.visitStmt2R1N(SHR_INT_LIT8,7,3,4);
                code.visitStmt3R(AGET_WIDE,4,6,7);
                code.visitLabel(L8);
                code.visitStmt2R(OR_LONG_2ADDR,1,4);
                code.visitLabel(L9);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitLabel(L10);
                code.visitStmt1R(RETURN_WIDE,1);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m009_to_six_bit(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PRIVATE|ACC_STATIC, new Method("Lorg/mortbay/jetty/security/UnixCrypt;","to_six_bit",new String[]{ "I"},"I"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"num");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(284,L0);
                code.visitLabel(L0);
                code.visitStmt2R1N(SHL_INT_LIT8,0,3,26);
                code.visitConstStmt(CONST_HIGH16,1, Integer.valueOf(-67108864)); // int: 0xfc000000  float:-2658455991569831700000000000000000000.000000
                code.visitStmt2R(AND_INT_2ADDR,0,1);
                code.visitStmt2R1N(SHL_INT_LIT8,1,3,12);
                code.visitConstStmt(CONST_HIGH16,2, Integer.valueOf(16515072)); // int: 0x00fc0000  float:0.000000
                code.visitStmt2R(AND_INT_2ADDR,1,2);
                code.visitStmt2R(OR_INT_2ADDR,0,1);
                code.visitStmt2R1N(SHR_INT_LIT8,1,3,2);
                code.visitConstStmt(CONST,2, Integer.valueOf(64512)); // int: 0x0000fc00  float:0.000000
                code.visitStmt2R(AND_INT_2ADDR,1,2);
                code.visitStmt2R(OR_INT_2ADDR,0,1);
                code.visitStmt2R1N(SHR_INT_LIT8,1,3,16);
                code.visitStmt2R1N(AND_INT_LIT16,1,1,252);
                code.visitStmt2R(OR_INT_2ADDR,0,1);
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m010_to_six_bit(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PRIVATE|ACC_STATIC, new Method("Lorg/mortbay/jetty/security/UnixCrypt;","to_six_bit",new String[]{ "J"},"J"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(8);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"num");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(293,L0);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_16,0, Integer.valueOf(26)); // int: 0x0000001a  float:0.000000
                code.visitStmt3R(SHL_LONG,0,6,0);
                code.visitConstStmt(CONST_WIDE,2,Long.valueOf(-288230371923853312L)); // long: 0xfc000000fc000000  double:-19490646320078364000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000.000000
                code.visitStmt2R(AND_LONG_2ADDR,0,2);
                code.visitConstStmt(CONST_16,2, Integer.valueOf(12)); // int: 0x0000000c  float:0.000000
                code.visitStmt3R(SHL_LONG,2,6,2);
                code.visitConstStmt(CONST_WIDE,4,Long.valueOf(70931694147600384L)); // long: 0x00fc000000fc0000  double:0.000000
                code.visitStmt2R(AND_LONG_2ADDR,2,4);
                code.visitStmt2R(OR_LONG_2ADDR,0,2);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(2)); // int: 0x00000002  float:0.000000
                code.visitStmt3R(SHR_LONG,2,6,2);
                code.visitConstStmt(CONST_WIDE,4,Long.valueOf(277076930264064L)); // long: 0x0000fc000000fc00  double:0.000000
                code.visitStmt2R(AND_LONG_2ADDR,2,4);
                code.visitStmt2R(OR_LONG_2ADDR,0,2);
                code.visitConstStmt(CONST_16,2, Integer.valueOf(16)); // int: 0x00000010  float:0.000000
                code.visitStmt3R(SHR_LONG,2,6,2);
                code.visitConstStmt(CONST_WIDE,4,Long.valueOf(1082331758844L)); // long: 0x000000fc000000fc  double:0.000000
                code.visitStmt2R(AND_LONG_2ADDR,2,4);
                code.visitStmt2R(OR_LONG_2ADDR,0,2);
                code.visitStmt1R(RETURN_WIDE,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
