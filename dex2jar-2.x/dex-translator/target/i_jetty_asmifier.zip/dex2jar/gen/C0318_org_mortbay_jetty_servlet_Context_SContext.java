package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0318_org_mortbay_jetty_servlet_Context_SContext {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(ACC_PUBLIC,"Lorg/mortbay/jetty/servlet/Context$SContext;","Lorg/mortbay/jetty/handler/ContextHandler$SContext;",new String[]{ });
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("Context.java");
        if(cv!=null){
            DexAnnotationVisitor av00 = cv.visitAnnotation("Ldalvik/annotation/EnclosingClass;", Visibility.SYSTEM);
            if(av00 != null) {
                av00.visit("value", new DexType("Lorg/mortbay/jetty/servlet/Context;"));
                av00.visitEnd();
            }
        }
        if(cv!=null){
            DexAnnotationVisitor av00 = cv.visitAnnotation("Ldalvik/annotation/InnerClass;", Visibility.SYSTEM);
            if(av00 != null) {
                av00.visit("accessFlags",  Integer.valueOf(1));
                av00.visit("name", "SContext");
                av00.visitEnd();
            }
        }
        f000_this$0(cv);
        m000__init_(cv);
        m001_getNamedDispatcher(cv);
        m002_getRequestDispatcher(cv);
    }
    public static void f000_this$0(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_FINAL|ACC_SYNTHETIC, new Field("Lorg/mortbay/jetty/servlet/Context$SContext;","this$0","Lorg/mortbay/jetty/servlet/Context;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void m000__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/jetty/servlet/Context$SContext;","<init>",new String[]{ "Lorg/mortbay/jetty/servlet/Context;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(298,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_OBJECT,1,0,new Field("Lorg/mortbay/jetty/servlet/Context$SContext;","this$0","Lorg/mortbay/jetty/servlet/Context;"));
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1},new Method("Lorg/mortbay/jetty/handler/ContextHandler$SContext;","<init>",new String[]{ "Lorg/mortbay/jetty/handler/ContextHandler;"},"V"));
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001_getNamedDispatcher(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/servlet/Context$SContext;","getNamedDispatcher",new String[]{ "Ljava/lang/String;"},"Ljavax/servlet/RequestDispatcher;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"name");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(307,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(308,L1);
                ddv.visitStartLocal(0,L1,"context","Lorg/mortbay/jetty/handler/ContextHandler;",null);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(309,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(310,L3);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/jetty/servlet/Context$SContext;","this$0","Lorg/mortbay/jetty/servlet/Context;"));
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/jetty/servlet/Context$SContext;","this$0","Lorg/mortbay/jetty/servlet/Context;"));
                code.visitFieldStmt(IGET_OBJECT,1,1,new Field("Lorg/mortbay/jetty/servlet/Context;","_servletHandler","Lorg/mortbay/jetty/servlet/ServletHandler;"));
                code.visitJumpStmt(IF_EQZ,1,-1,L2);
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/jetty/servlet/Context$SContext;","this$0","Lorg/mortbay/jetty/servlet/Context;"));
                code.visitFieldStmt(IGET_OBJECT,1,1,new Field("Lorg/mortbay/jetty/servlet/Context;","_servletHandler","Lorg/mortbay/jetty/servlet/ServletHandler;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,3},new Method("Lorg/mortbay/jetty/servlet/ServletHandler;","getServlet",new String[]{ "Ljava/lang/String;"},"Lorg/mortbay/jetty/servlet/ServletHolder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                DexLabel L4=new DexLabel();
                code.visitJumpStmt(IF_NEZ,1,-1,L4);
                code.visitLabel(L2);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L3);
                code.visitStmt1R(RETURN_OBJECT,1);
                code.visitLabel(L4);
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Lorg/mortbay/jetty/servlet/Dispatcher;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1,0,3},new Method("Lorg/mortbay/jetty/servlet/Dispatcher;","<init>",new String[]{ "Lorg/mortbay/jetty/handler/ContextHandler;","Ljava/lang/String;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L3);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m002_getRequestDispatcher(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/servlet/Context$SContext;","getRequestDispatcher",new String[]{ "Ljava/lang/String;"},"Ljavax/servlet/RequestDispatcher;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(10);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ "Ljava/lang/Exception;"});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"uriInContext");
                DexLabel L3=new DexLabel();
                ddv.visitPrologue(L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(319,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(346,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(322,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(323,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(327,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(328,L9);
                ddv.visitStartLocal(4,L9,"query","Ljava/lang/String;",null);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(329,L10);
                ddv.visitStartLocal(3,L10,"q","I",null);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(331,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(332,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(334,L13);
                DexLabel L14=new DexLabel();
                ddv.visitRestartLocal(3,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(335,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(337,L16);
                ddv.visitRestartLocal(9,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(338,L17);
                ddv.visitStartLocal(2,L17,"pathInContext","Ljava/lang/String;",null);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(339,L18);
                ddv.visitStartLocal(5,L18,"uri","Ljava/lang/String;",null);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(340,L19);
                ddv.visitStartLocal(0,L19,"context","Lorg/mortbay/jetty/handler/ContextHandler;",null);
                ddv.visitLineNumber(342,L2);
                ddv.visitEndLocal(2,L2);
                ddv.visitEndLocal(5,L2);
                ddv.visitEndLocal(0,L2);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(344,L20);
                ddv.visitStartLocal(1,L20,"e","Ljava/lang/Exception;",null);
                DexLabel L21=new DexLabel();
                ddv.visitLineNumber(346,L21);
                code.visitLabel(L3);
                code.visitConstStmt(CONST_4,7, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L4);
                code.visitJumpStmt(IF_NEZ,9,-1,L6);
                code.visitStmt2R(MOVE_OBJECT,6,7);
                code.visitLabel(L5);
                code.visitStmt1R(RETURN_OBJECT,6);
                code.visitLabel(L6);
                code.visitConstStmt(CONST_STRING,6,"/");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9,6},new Method("Ljava/lang/String;","startsWith",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,6);
                code.visitJumpStmt(IF_NEZ,6,-1,L8);
                code.visitStmt2R(MOVE_OBJECT,6,7);
                code.visitLabel(L7);
                code.visitJumpStmt(GOTO,-1,-1,L5);
                code.visitLabel(L8);
                code.visitConstStmt(CONST_4,4, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L9);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L10);
                code.visitConstStmt(CONST_16,6, Integer.valueOf(63)); // int: 0x0000003f  float:0.000000
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9,6},new Method("Ljava/lang/String;","indexOf",new String[]{ "I"},"I"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitJumpStmt(IF_LEZ,3,-1,L13);
                code.visitLabel(L11);
                code.visitStmt2R1N(ADD_INT_LIT8,6,3,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9,6},new Method("Ljava/lang/String;","substring",new String[]{ "I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitLabel(L12);
                code.visitConstStmt(CONST_4,6, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9,6,3},new Method("Ljava/lang/String;","substring",new String[]{ "I","I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,9);
                code.visitLabel(L13);
                code.visitConstStmt(CONST_16,6, Integer.valueOf(59)); // int: 0x0000003b  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9,6},new Method("Ljava/lang/String;","indexOf",new String[]{ "I"},"I"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitLabel(L14);
                code.visitJumpStmt(IF_LEZ,3,-1,L16);
                code.visitLabel(L15);
                code.visitConstStmt(CONST_4,6, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9,6,3},new Method("Ljava/lang/String;","substring",new String[]{ "I","I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,9);
                code.visitLabel(L16);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 9},new Method("Lorg/mortbay/util/URIUtil;","decodePath",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 6},new Method("Lorg/mortbay/util/URIUtil;","canonicalPath",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitLabel(L17);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8},new Method("Lorg/mortbay/jetty/servlet/Context$SContext;","getContextPath",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 6,9},new Method("Lorg/mortbay/util/URIUtil;","addPaths",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitLabel(L18);
                code.visitFieldStmt(IGET_OBJECT,0,8,new Field("Lorg/mortbay/jetty/servlet/Context$SContext;","this$0","Lorg/mortbay/jetty/servlet/Context;"));
                code.visitLabel(L19);
                code.visitTypeStmt(NEW_INSTANCE,6,-1,"Lorg/mortbay/jetty/servlet/Dispatcher;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 6,0,5,2,4},new Method("Lorg/mortbay/jetty/servlet/Dispatcher;","<init>",new String[]{ "Lorg/mortbay/jetty/handler/ContextHandler;","Ljava/lang/String;","Ljava/lang/String;","Ljava/lang/String;"},"V"));
                code.visitLabel(L1);
                code.visitJumpStmt(GOTO,-1,-1,L5);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,6);
                code.visitStmt2R(MOVE_OBJECT,1,6);
                code.visitLabel(L20);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1},new Method("Lorg/mortbay/log/Log;","ignore",new String[]{ "Ljava/lang/Throwable;"},"V"));
                code.visitStmt2R(MOVE_OBJECT,6,7);
                code.visitLabel(L21);
                code.visitJumpStmt(GOTO,-1,-1,L5);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
