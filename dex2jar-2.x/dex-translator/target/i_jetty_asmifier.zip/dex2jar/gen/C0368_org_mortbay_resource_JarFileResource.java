package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0368_org_mortbay_resource_JarFileResource {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(0,"Lorg/mortbay/resource/JarFileResource;","Lorg/mortbay/resource/JarResource;",new String[]{ });
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("JarFileResource.java");
        f000__directory(cv);
        f001__entry(cv);
        f002__exists(cv);
        f003__file(cv);
        f004__jarFile(cv);
        f005__jarUrl(cv);
        f006__list(cv);
        f007__path(cv);
        m000__init_(cv);
        m001__init_(cv);
        m002_getNonCachingResource(cv);
        m003_checkConnection(cv);
        m004_encode(cv);
        m005_exists(cv);
        m006_isDirectory(cv);
        m007_lastModified(cv);
        m008_length(cv);
        m009_list(cv);
        m010_newConnection(cv);
        m011_release(cv);
    }
    public static void f000__directory(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_TRANSIENT, new Field("Lorg/mortbay/resource/JarFileResource;","_directory","Z"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f001__entry(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_TRANSIENT, new Field("Lorg/mortbay/resource/JarFileResource;","_entry","Ljava/util/jar/JarEntry;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f002__exists(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_TRANSIENT, new Field("Lorg/mortbay/resource/JarFileResource;","_exists","Z"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f003__file(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_TRANSIENT, new Field("Lorg/mortbay/resource/JarFileResource;","_file","Ljava/io/File;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f004__jarFile(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_TRANSIENT, new Field("Lorg/mortbay/resource/JarFileResource;","_jarFile","Ljava/util/jar/JarFile;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f005__jarUrl(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_TRANSIENT, new Field("Lorg/mortbay/resource/JarFileResource;","_jarUrl","Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f006__list(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_TRANSIENT, new Field("Lorg/mortbay/resource/JarFileResource;","_list","[Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f007__path(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_TRANSIENT, new Field("Lorg/mortbay/resource/JarFileResource;","_path","Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void m000__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_CONSTRUCTOR, new Method("Lorg/mortbay/resource/JarFileResource;","<init>",new String[]{ "Ljava/net/URL;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"url");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(44,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(45,L1);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1},new Method("Lorg/mortbay/resource/JarResource;","<init>",new String[]{ "Ljava/net/URL;"},"V"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_CONSTRUCTOR, new Method("Lorg/mortbay/resource/JarFileResource;","<init>",new String[]{ "Ljava/net/URL;","Z"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"url");
                ddv.visitParameterName(1,"useCaches");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(49,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(50,L1);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1,2},new Method("Lorg/mortbay/resource/JarResource;","<init>",new String[]{ "Ljava/net/URL;","Z"},"V"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m002_getNonCachingResource(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Lorg/mortbay/resource/JarFileResource;","getNonCachingResource",new String[]{ "Lorg/mortbay/resource/Resource;"},"Lorg/mortbay/resource/Resource;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(6);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"resource");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(313,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(319,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(316,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(318,L3);
                ddv.visitStartLocal(2,L3,"oldResource","Lorg/mortbay/resource/JarFileResource;",null);
                DexLabel L4=new DexLabel();
                ddv.visitStartLocal(1,L4,"newResource","Lorg/mortbay/resource/JarFileResource;",null);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(319,L5);
                code.visitLabel(L0);
                code.visitTypeStmt(INSTANCE_OF,3,5,"Lorg/mortbay/resource/JarFileResource;");
                code.visitJumpStmt(IF_NEZ,3,-1,L2);
                code.visitStmt2R(MOVE_OBJECT,3,5);
                code.visitLabel(L1);
                code.visitStmt1R(RETURN_OBJECT,3);
                code.visitLabel(L2);
                code.visitStmt2R(MOVE_OBJECT,0,5);
                code.visitTypeStmt(CHECK_CAST,0,-1,"Lorg/mortbay/resource/JarFileResource;");
                code.visitStmt2R(MOVE_OBJECT,2,0);
                code.visitLabel(L3);
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Lorg/mortbay/resource/JarFileResource;");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/resource/JarFileResource;","getURL",new String[]{ },"Ljava/net/URL;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitConstStmt(CONST_4,4, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1,3,4},new Method("Lorg/mortbay/resource/JarFileResource;","<init>",new String[]{ "Ljava/net/URL;","Z"},"V"));
                code.visitLabel(L4);
                code.visitStmt2R(MOVE_OBJECT,3,1);
                code.visitLabel(L5);
                code.visitJumpStmt(GOTO,-1,-1,L1);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m003_checkConnection(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Lorg/mortbay/resource/JarFileResource;","checkConnection",new String[]{ },"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L3=new DexLabel();
                ddv.visitPrologue(L3);
                ddv.visitLineNumber(67,L0);
                ddv.visitLineNumber(71,L1);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(73,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(74,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(75,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(76,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(79,L8);
                ddv.visitLineNumber(71,L2);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(73,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(74,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(75,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(76,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(71,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(79,L14);
                code.visitLabel(L3);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_SUPER,new int[]{ 3},new Method("Lorg/mortbay/resource/JarResource;","checkConnection",new String[]{ },"Z"));
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,0,3,new Field("Lorg/mortbay/resource/JarFileResource;","_jarConnection","Ljava/net/JarURLConnection;"));
                code.visitJumpStmt(IF_NEZ,0,-1,L8);
                code.visitLabel(L4);
                code.visitFieldStmt(IPUT_OBJECT,2,3,new Field("Lorg/mortbay/resource/JarFileResource;","_entry","Ljava/util/jar/JarEntry;"));
                code.visitLabel(L5);
                code.visitFieldStmt(IPUT_OBJECT,2,3,new Field("Lorg/mortbay/resource/JarFileResource;","_file","Ljava/io/File;"));
                code.visitLabel(L6);
                code.visitFieldStmt(IPUT_OBJECT,2,3,new Field("Lorg/mortbay/resource/JarFileResource;","_jarFile","Ljava/util/jar/JarFile;"));
                code.visitLabel(L7);
                code.visitFieldStmt(IPUT_OBJECT,2,3,new Field("Lorg/mortbay/resource/JarFileResource;","_list","[Ljava/lang/String;"));
                code.visitLabel(L8);
                code.visitFieldStmt(IGET_OBJECT,0,3,new Field("Lorg/mortbay/resource/JarFileResource;","_jarFile","Ljava/util/jar/JarFile;"));
                code.visitJumpStmt(IF_EQZ,0,-1,L14);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                DexLabel L15=new DexLabel();
                code.visitLabel(L15);
                code.visitStmt1R(RETURN,0);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,0);
                code.visitFieldStmt(IGET_OBJECT,1,3,new Field("Lorg/mortbay/resource/JarFileResource;","_jarConnection","Ljava/net/JarURLConnection;"));
                code.visitJumpStmt(IF_NEZ,1,-1,L13);
                code.visitLabel(L9);
                code.visitFieldStmt(IPUT_OBJECT,2,3,new Field("Lorg/mortbay/resource/JarFileResource;","_entry","Ljava/util/jar/JarEntry;"));
                code.visitLabel(L10);
                code.visitFieldStmt(IPUT_OBJECT,2,3,new Field("Lorg/mortbay/resource/JarFileResource;","_file","Ljava/io/File;"));
                code.visitLabel(L11);
                code.visitFieldStmt(IPUT_OBJECT,2,3,new Field("Lorg/mortbay/resource/JarFileResource;","_jarFile","Ljava/util/jar/JarFile;"));
                code.visitLabel(L12);
                code.visitFieldStmt(IPUT_OBJECT,2,3,new Field("Lorg/mortbay/resource/JarFileResource;","_list","[Ljava/lang/String;"));
                code.visitLabel(L13);
                code.visitStmt1R(THROW,0);
                code.visitLabel(L14);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L15);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m004_encode(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/resource/JarFileResource;","encode",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"uri");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(301,L0);
                code.visitLabel(L0);
                code.visitStmt1R(RETURN_OBJECT,1);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m005_exists(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/resource/JarFileResource;","exists",new String[]{ },"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(15);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ "Ljava/lang/Exception;"});
                DexLabel L3=new DexLabel();
                DexLabel L4=new DexLabel();
                DexLabel L5=new DexLabel();
                code.visitTryCatch(L3,L4,new DexLabel[]{L5},new String[]{ "Ljava/lang/Exception;"});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L6=new DexLabel();
                ddv.visitPrologue(L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(110,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(188,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(113,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(116,L10);
                ddv.visitLineNumber(117,L0);
                ddv.visitStartLocal(5,L0,"file_url","Ljava/lang/String;",null);
                ddv.visitLineNumber(118,L2);
                DexLabel L11=new DexLabel();
                ddv.visitStartLocal(3,L11,"e","Ljava/lang/Exception;",null);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(121,L12);
                ddv.visitEndLocal(5,L12);
                ddv.visitEndLocal(3,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(124,L13);
                ddv.visitStartLocal(2,L13,"check","Z",null);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(127,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(128,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(133,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(134,L17);
                ddv.visitStartLocal(6,L17,"jarFile","Ljava/util/jar/JarFile;",null);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(136,L18);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(153,L19);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(156,L20);
                DexLabel L21=new DexLabel();
                ddv.visitLineNumber(157,L21);
                ddv.visitStartLocal(3,L21,"e","Ljava/util/Enumeration;",null);
                DexLabel L22=new DexLabel();
                ddv.visitLineNumber(159,L22);
                DexLabel L23=new DexLabel();
                ddv.visitLineNumber(160,L23);
                ddv.visitStartLocal(4,L23,"entry","Ljava/util/jar/JarEntry;",null);
                DexLabel L24=new DexLabel();
                ddv.visitLineNumber(163,L24);
                ddv.visitStartLocal(7,L24,"name","Ljava/lang/String;",null);
                DexLabel L25=new DexLabel();
                ddv.visitLineNumber(165,L25);
                DexLabel L26=new DexLabel();
                ddv.visitLineNumber(167,L26);
                DexLabel L27=new DexLabel();
                ddv.visitLineNumber(187,L27);
                ddv.visitEndLocal(3,L27);
                ddv.visitEndLocal(4,L27);
                ddv.visitEndLocal(7,L27);
                DexLabel L28=new DexLabel();
                ddv.visitLineNumber(188,L28);
                ddv.visitLineNumber(142,L3);
                DexLabel L29=new DexLabel();
                ddv.visitLineNumber(143,L29);
                ddv.visitStartLocal(1,L29,"c","Ljava/net/JarURLConnection;",null);
                DexLabel L30=new DexLabel();
                ddv.visitLineNumber(144,L30);
                DexLabel L31=new DexLabel();
                ddv.visitRestartLocal(6,L31);
                ddv.visitLineNumber(146,L5);
                ddv.visitEndLocal(1,L5);
                DexLabel L32=new DexLabel();
                ddv.visitLineNumber(148,L32);
                ddv.visitStartLocal(3,L32,"e","Ljava/lang/Exception;",null);
                DexLabel L33=new DexLabel();
                ddv.visitLineNumber(170,L33);
                ddv.visitStartLocal(3,L33,"e","Ljava/util/Enumeration;",null);
                ddv.visitRestartLocal(4,L33);
                ddv.visitRestartLocal(7,L33);
                DexLabel L34=new DexLabel();
                ddv.visitLineNumber(172,L34);
                DexLabel L35=new DexLabel();
                ddv.visitLineNumber(174,L35);
                DexLabel L36=new DexLabel();
                ddv.visitLineNumber(178,L36);
                DexLabel L37=new DexLabel();
                ddv.visitLineNumber(180,L37);
                DexLabel L38=new DexLabel();
                ddv.visitEndLocal(3,L38);
                ddv.visitEndLocal(4,L38);
                ddv.visitEndLocal(7,L38);
                DexLabel L39=new DexLabel();
                ddv.visitLineNumber(187,L39);
                code.visitLabel(L6);
                code.visitConstStmt(CONST_16,11, Integer.valueOf(47)); // int: 0x0000002f  float:0.000000
                code.visitConstStmt(CONST_4,12, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitConstStmt(CONST_4,10, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitConstStmt(CONST_STRING,13,"/");
                code.visitLabel(L7);
                code.visitFieldStmt(IGET_BOOLEAN,8,14,new Field("Lorg/mortbay/resource/JarFileResource;","_exists","Z"));
                code.visitJumpStmt(IF_EQZ,8,-1,L9);
                code.visitStmt2R(MOVE,8,10);
                code.visitLabel(L8);
                code.visitStmt1R(RETURN,8);
                code.visitLabel(L9);
                code.visitFieldStmt(IGET_OBJECT,8,14,new Field("Lorg/mortbay/resource/JarFileResource;","_urlString","Ljava/lang/String;"));
                code.visitConstStmt(CONST_STRING,9,"!/");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8,9},new Method("Ljava/lang/String;","endsWith",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,8);
                code.visitJumpStmt(IF_EQZ,8,-1,L12);
                code.visitLabel(L10);
                code.visitFieldStmt(IGET_OBJECT,8,14,new Field("Lorg/mortbay/resource/JarFileResource;","_urlString","Ljava/lang/String;"));
                code.visitConstStmt(CONST_4,9, Integer.valueOf(4)); // int: 0x00000004  float:0.000000
                code.visitFieldStmt(IGET_OBJECT,10,14,new Field("Lorg/mortbay/resource/JarFileResource;","_urlString","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10},new Method("Ljava/lang/String;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,10);
                code.visitConstStmt(CONST_4,11, Integer.valueOf(2)); // int: 0x00000002  float:0.000000
                code.visitStmt2R(SUB_INT_2ADDR,10,11);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8,9,10},new Method("Ljava/lang/String;","substring",new String[]{ "I","I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 5},new Method("Lorg/mortbay/resource/JarFileResource;","newResource",new String[]{ "Ljava/lang/String;"},"Lorg/mortbay/resource/Resource;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8},new Method("Lorg/mortbay/resource/Resource;","exists",new String[]{ },"Z"));
                code.visitLabel(L1);
                code.visitStmt1R(MOVE_RESULT,8);
                code.visitJumpStmt(GOTO,-1,-1,L8);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,8);
                code.visitStmt2R(MOVE_OBJECT,3,8);
                code.visitLabel(L11);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 3},new Method("Lorg/mortbay/log/Log;","ignore",new String[]{ "Ljava/lang/Throwable;"},"V"));
                code.visitStmt2R(MOVE,8,12);
                code.visitJumpStmt(GOTO,-1,-1,L8);
                code.visitLabel(L12);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 14},new Method("Lorg/mortbay/resource/JarFileResource;","checkConnection",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitLabel(L13);
                code.visitFieldStmt(IGET_OBJECT,8,14,new Field("Lorg/mortbay/resource/JarFileResource;","_jarUrl","Ljava/lang/String;"));
                code.visitJumpStmt(IF_EQZ,8,-1,L16);
                code.visitFieldStmt(IGET_OBJECT,8,14,new Field("Lorg/mortbay/resource/JarFileResource;","_path","Ljava/lang/String;"));
                code.visitJumpStmt(IF_NEZ,8,-1,L16);
                code.visitLabel(L14);
                code.visitFieldStmt(IPUT_BOOLEAN,2,14,new Field("Lorg/mortbay/resource/JarFileResource;","_directory","Z"));
                code.visitStmt2R(MOVE,8,10);
                code.visitLabel(L15);
                code.visitJumpStmt(GOTO,-1,-1,L8);
                code.visitLabel(L16);
                code.visitConstStmt(CONST_4,6, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L17);
                code.visitJumpStmt(IF_EQZ,2,-1,L3);
                code.visitLabel(L18);
                code.visitFieldStmt(IGET_OBJECT,6,14,new Field("Lorg/mortbay/resource/JarFileResource;","_jarFile","Ljava/util/jar/JarFile;"));
                code.visitLabel(L19);
                code.visitJumpStmt(IF_EQZ,6,-1,L27);
                code.visitFieldStmt(IGET_OBJECT,8,14,new Field("Lorg/mortbay/resource/JarFileResource;","_entry","Ljava/util/jar/JarEntry;"));
                code.visitJumpStmt(IF_NEZ,8,-1,L27);
                code.visitFieldStmt(IGET_BOOLEAN,8,14,new Field("Lorg/mortbay/resource/JarFileResource;","_directory","Z"));
                code.visitJumpStmt(IF_NEZ,8,-1,L27);
                code.visitLabel(L20);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Ljava/util/jar/JarFile;","entries",new String[]{ },"Ljava/util/Enumeration;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitLabel(L21);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 3},new Method("Ljava/util/Enumeration;","hasMoreElements",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,8);
                code.visitJumpStmt(IF_EQZ,8,-1,L27);
                code.visitLabel(L22);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 3},new Method("Ljava/util/Enumeration;","nextElement",new String[]{ },"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitTypeStmt(CHECK_CAST,4,-1,"Ljava/util/jar/JarEntry;");
                code.visitLabel(L23);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Ljava/util/jar/JarEntry;","getName",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitConstStmt(CONST_16,9, Integer.valueOf(92)); // int: 0x0000005c  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8,9,11},new Method("Ljava/lang/String;","replace",new String[]{ "C","C"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitLabel(L24);
                code.visitFieldStmt(IGET_OBJECT,8,14,new Field("Lorg/mortbay/resource/JarFileResource;","_path","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7,8},new Method("Ljava/lang/String;","equals",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,8);
                code.visitJumpStmt(IF_EQZ,8,-1,L33);
                code.visitLabel(L25);
                code.visitFieldStmt(IPUT_OBJECT,4,14,new Field("Lorg/mortbay/resource/JarFileResource;","_entry","Ljava/util/jar/JarEntry;"));
                code.visitLabel(L26);
                code.visitFieldStmt(IGET_OBJECT,8,14,new Field("Lorg/mortbay/resource/JarFileResource;","_path","Ljava/lang/String;"));
                code.visitConstStmt(CONST_STRING,9,"/");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8,13},new Method("Ljava/lang/String;","endsWith",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,8);
                code.visitFieldStmt(IPUT_BOOLEAN,8,14,new Field("Lorg/mortbay/resource/JarFileResource;","_directory","Z"));
                code.visitLabel(L27);
                code.visitFieldStmt(IGET_BOOLEAN,8,14,new Field("Lorg/mortbay/resource/JarFileResource;","_directory","Z"));
                DexLabel L40=new DexLabel();
                code.visitJumpStmt(IF_NEZ,8,-1,L40);
                code.visitFieldStmt(IGET_OBJECT,8,14,new Field("Lorg/mortbay/resource/JarFileResource;","_entry","Ljava/util/jar/JarEntry;"));
                code.visitJumpStmt(IF_EQZ,8,-1,L38);
                code.visitLabel(L40);
                code.visitStmt2R(MOVE,8,10);
                DexLabel L41=new DexLabel();
                code.visitLabel(L41);
                code.visitFieldStmt(IPUT_BOOLEAN,8,14,new Field("Lorg/mortbay/resource/JarFileResource;","_exists","Z"));
                code.visitLabel(L28);
                code.visitFieldStmt(IGET_BOOLEAN,8,14,new Field("Lorg/mortbay/resource/JarFileResource;","_exists","Z"));
                code.visitJumpStmt(GOTO_16,-1,-1,L8);
                code.visitLabel(L3);
                code.visitTypeStmt(NEW_INSTANCE,8,-1,"Ljava/net/URL;");
                code.visitFieldStmt(IGET_OBJECT,9,14,new Field("Lorg/mortbay/resource/JarFileResource;","_jarUrl","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 8,9},new Method("Ljava/net/URL;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8},new Method("Ljava/net/URL;","openConnection",new String[]{ },"Ljava/net/URLConnection;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitTypeStmt(CHECK_CAST,8,-1,"Ljava/net/JarURLConnection;");
                code.visitStmt2R(MOVE_OBJECT,0,8);
                code.visitTypeStmt(CHECK_CAST,0,-1,"Ljava/net/JarURLConnection;");
                code.visitStmt2R(MOVE_OBJECT,1,0);
                code.visitLabel(L29);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 14},new Method("Lorg/mortbay/resource/JarFileResource;","getUseCaches",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,8);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,8},new Method("Ljava/net/JarURLConnection;","setUseCaches",new String[]{ "Z"},"V"));
                code.visitLabel(L30);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/net/JarURLConnection;","getJarFile",new String[]{ },"Ljava/util/jar/JarFile;"));
                code.visitLabel(L4);
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitLabel(L31);
                code.visitJumpStmt(GOTO,-1,-1,L19);
                code.visitLabel(L5);
                code.visitStmt1R(MOVE_EXCEPTION,8);
                code.visitStmt2R(MOVE_OBJECT,3,8);
                code.visitLabel(L32);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 3},new Method("Lorg/mortbay/log/Log;","ignore",new String[]{ "Ljava/lang/Throwable;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L19);
                code.visitLabel(L33);
                code.visitFieldStmt(IGET_OBJECT,8,14,new Field("Lorg/mortbay/resource/JarFileResource;","_path","Ljava/lang/String;"));
                code.visitConstStmt(CONST_STRING,9,"/");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8,13},new Method("Ljava/lang/String;","endsWith",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,8);
                code.visitJumpStmt(IF_EQZ,8,-1,L36);
                code.visitLabel(L34);
                code.visitFieldStmt(IGET_OBJECT,8,14,new Field("Lorg/mortbay/resource/JarFileResource;","_path","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7,8},new Method("Ljava/lang/String;","startsWith",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,8);
                code.visitJumpStmt(IF_EQZ,8,-1,L21);
                code.visitLabel(L35);
                code.visitFieldStmt(IPUT_BOOLEAN,10,14,new Field("Lorg/mortbay/resource/JarFileResource;","_directory","Z"));
                code.visitJumpStmt(GOTO,-1,-1,L27);
                code.visitLabel(L36);
                code.visitFieldStmt(IGET_OBJECT,8,14,new Field("Lorg/mortbay/resource/JarFileResource;","_path","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7,8},new Method("Ljava/lang/String;","startsWith",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,8);
                code.visitJumpStmt(IF_EQZ,8,-1,L21);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7},new Method("Ljava/lang/String;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,8);
                code.visitFieldStmt(IGET_OBJECT,9,14,new Field("Lorg/mortbay/resource/JarFileResource;","_path","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9},new Method("Ljava/lang/String;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,9);
                code.visitJumpStmt(IF_LE,8,9,L21);
                code.visitFieldStmt(IGET_OBJECT,8,14,new Field("Lorg/mortbay/resource/JarFileResource;","_path","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8},new Method("Ljava/lang/String;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,8);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7,8},new Method("Ljava/lang/String;","charAt",new String[]{ "I"},"C"));
                code.visitStmt1R(MOVE_RESULT,8);
                code.visitJumpStmt(IF_NE,8,11,L21);
                code.visitLabel(L37);
                code.visitFieldStmt(IPUT_BOOLEAN,10,14,new Field("Lorg/mortbay/resource/JarFileResource;","_directory","Z"));
                code.visitJumpStmt(GOTO,-1,-1,L27);
                code.visitLabel(L38);
                code.visitStmt2R(MOVE,8,12);
                code.visitLabel(L39);
                code.visitJumpStmt(GOTO,-1,-1,L41);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m006_isDirectory(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/resource/JarFileResource;","isDirectory",new String[]{ },"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(200,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/resource/JarFileResource;","_urlString","Ljava/lang/String;"));
                code.visitConstStmt(CONST_STRING,1,"/");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/String;","endsWith",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                DexLabel L1=new DexLabel();
                code.visitJumpStmt(IF_NEZ,0,-1,L1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/resource/JarFileResource;","exists",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                DexLabel L2=new DexLabel();
                code.visitJumpStmt(IF_EQZ,0,-1,L2);
                code.visitFieldStmt(IGET_BOOLEAN,0,2,new Field("Lorg/mortbay/resource/JarFileResource;","_directory","Z"));
                code.visitJumpStmt(IF_EQZ,0,-1,L2);
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                DexLabel L3=new DexLabel();
                code.visitLabel(L3);
                code.visitStmt1R(RETURN,0);
                code.visitLabel(L2);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L3);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m007_lastModified(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/resource/JarFileResource;","lastModified",new String[]{ },"J"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(209,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(210,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(211,L2);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/resource/JarFileResource;","checkConnection",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                DexLabel L3=new DexLabel();
                code.visitJumpStmt(IF_EQZ,0,-1,L3);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/resource/JarFileResource;","_file","Ljava/io/File;"));
                code.visitJumpStmt(IF_EQZ,0,-1,L3);
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/resource/JarFileResource;","_file","Ljava/io/File;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/io/File;","lastModified",new String[]{ },"J"));
                code.visitStmt1R(MOVE_RESULT_WIDE,0);
                code.visitLabel(L2);
                code.visitStmt1R(RETURN_WIDE,0);
                code.visitLabel(L3);
                code.visitConstStmt(CONST_WIDE_16,0,Long.valueOf(-1L)); // long: 0xffffffffffffffff  double:NaN
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m008_length(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/resource/JarFileResource;","length",new String[]{ },"J"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(284,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(290,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(287,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(288,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(290,L5);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_WIDE_16,1,Long.valueOf(-1L)); // long: 0xffffffffffffffff  double:NaN
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Lorg/mortbay/resource/JarFileResource;","isDirectory",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_EQZ,0,-1,L3);
                code.visitStmt2R(MOVE_WIDE,0,1);
                code.visitLabel(L2);
                code.visitStmt1R(RETURN_WIDE,0);
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,0,3,new Field("Lorg/mortbay/resource/JarFileResource;","_entry","Ljava/util/jar/JarEntry;"));
                DexLabel L6=new DexLabel();
                code.visitJumpStmt(IF_EQZ,0,-1,L6);
                code.visitLabel(L4);
                code.visitFieldStmt(IGET_OBJECT,0,3,new Field("Lorg/mortbay/resource/JarFileResource;","_entry","Ljava/util/jar/JarEntry;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/util/jar/JarEntry;","getSize",new String[]{ },"J"));
                code.visitStmt1R(MOVE_RESULT_WIDE,0);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitLabel(L6);
                code.visitStmt2R(MOVE_WIDE,0,1);
                code.visitLabel(L5);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m009_list(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/resource/JarFileResource;","list",new String[]{ },"[Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(14);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexLabel L3=new DexLabel();
                DexLabel L4=new DexLabel();
                DexLabel L5=new DexLabel();
                code.visitTryCatch(L3,L4,new DexLabel[]{L5,L2},new String[]{ "Ljava/lang/Exception;",null});
                DexLabel L6=new DexLabel();
                DexLabel L7=new DexLabel();
                code.visitTryCatch(L6,L7,new DexLabel[]{L2},new String[]{ null});
                DexLabel L8=new DexLabel();
                DexLabel L9=new DexLabel();
                code.visitTryCatch(L8,L9,new DexLabel[]{L2},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L10=new DexLabel();
                ddv.visitPrologue(L10);
                ddv.visitLineNumber(218,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(220,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(222,L12);
                ddv.visitStartLocal(7,L12,"list","Ljava/util/ArrayList;",null);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(224,L13);
                ddv.visitLineNumber(225,L1);
                ddv.visitStartLocal(5,L1,"jarFile","Ljava/util/jar/JarFile;",null);
                ddv.visitLineNumber(229,L3);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(230,L14);
                ddv.visitStartLocal(6,L14,"jc","Ljava/net/JarURLConnection;",null);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(231,L15);
                ddv.visitLineNumber(239,L6);
                ddv.visitEndLocal(6,L6);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(240,L16);
                ddv.visitStartLocal(3,L16,"e","Ljava/util/Enumeration;",null);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(241,L17);
                ddv.visitStartLocal(2,L17,"dir","Ljava/lang/String;",null);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(244,L18);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(245,L19);
                ddv.visitStartLocal(4,L19,"entry","Ljava/util/jar/JarEntry;",null);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(246,L20);
                ddv.visitStartLocal(9,L20,"name","Ljava/lang/String;",null);
                DexLabel L21=new DexLabel();
                ddv.visitLineNumber(250,L21);
                DexLabel L22=new DexLabel();
                ddv.visitLineNumber(251,L22);
                ddv.visitStartLocal(8,L22,"listName","Ljava/lang/String;",null);
                DexLabel L23=new DexLabel();
                ddv.visitLineNumber(252,L23);
                ddv.visitStartLocal(1,L23,"dash","I",null);
                DexLabel L24=new DexLabel();
                ddv.visitLineNumber(256,L24);
                DexLabel L25=new DexLabel();
                ddv.visitLineNumber(260,L25);
                DexLabel L26=new DexLabel();
                ddv.visitLineNumber(261,L26);
                DexLabel L27=new DexLabel();
                ddv.visitLineNumber(265,L27);
                DexLabel L28=new DexLabel();
                ddv.visitLineNumber(269,L28);
                ddv.visitLineNumber(218,L2);
                ddv.visitEndLocal(7,L2);
                ddv.visitEndLocal(5,L2);
                ddv.visitEndLocal(3,L2);
                ddv.visitEndLocal(2,L2);
                ddv.visitEndLocal(4,L2);
                ddv.visitEndLocal(9,L2);
                ddv.visitEndLocal(1,L2);
                ddv.visitEndLocal(8,L2);
                ddv.visitLineNumber(233,L5);
                ddv.visitRestartLocal(5,L5);
                ddv.visitRestartLocal(7,L5);
                ddv.visitLineNumber(235,L8);
                ddv.visitStartLocal(3,L8,"e","Ljava/lang/Exception;",null);
                DexLabel L29=new DexLabel();
                ddv.visitLineNumber(263,L29);
                ddv.visitRestartLocal(1,L29);
                ddv.visitRestartLocal(2,L29);
                ddv.visitStartLocal(3,L29,"e","Ljava/util/Enumeration;",null);
                ddv.visitRestartLocal(4,L29);
                ddv.visitRestartLocal(8,L29);
                ddv.visitRestartLocal(9,L29);
                DexLabel L30=new DexLabel();
                ddv.visitRestartLocal(8,L30);
                DexLabel L31=new DexLabel();
                ddv.visitLineNumber(272,L31);
                ddv.visitEndLocal(1,L31);
                ddv.visitEndLocal(4,L31);
                ddv.visitEndLocal(9,L31);
                ddv.visitEndLocal(8,L31);
                DexLabel L32=new DexLabel();
                ddv.visitLineNumber(273,L32);
                DexLabel L33=new DexLabel();
                ddv.visitLineNumber(275,L33);
                ddv.visitEndLocal(5,L33);
                ddv.visitEndLocal(7,L33);
                ddv.visitEndLocal(2,L33);
                ddv.visitEndLocal(3,L33);
                code.visitLabel(L10);
                code.visitStmt1R(MONITOR_ENTER,13);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 13},new Method("Lorg/mortbay/resource/JarFileResource;","isDirectory",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,10);
                code.visitJumpStmt(IF_EQZ,10,-1,L33);
                code.visitFieldStmt(IGET_OBJECT,10,13,new Field("Lorg/mortbay/resource/JarFileResource;","_list","[Ljava/lang/String;"));
                code.visitJumpStmt(IF_NEZ,10,-1,L33);
                code.visitLabel(L11);
                code.visitTypeStmt(NEW_INSTANCE,7,-1,"Ljava/util/ArrayList;");
                code.visitConstStmt(CONST_16,10, Integer.valueOf(32)); // int: 0x00000020  float:0.000000
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 7,10},new Method("Ljava/util/ArrayList;","<init>",new String[]{ "I"},"V"));
                code.visitLabel(L12);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 13},new Method("Lorg/mortbay/resource/JarFileResource;","checkConnection",new String[]{ },"Z"));
                code.visitLabel(L13);
                code.visitFieldStmt(IGET_OBJECT,5,13,new Field("Lorg/mortbay/resource/JarFileResource;","_jarFile","Ljava/util/jar/JarFile;"));
                code.visitLabel(L1);
                code.visitJumpStmt(IF_NEZ,5,-1,L6);
                code.visitLabel(L3);
                code.visitTypeStmt(NEW_INSTANCE,10,-1,"Ljava/net/URL;");
                code.visitFieldStmt(IGET_OBJECT,11,13,new Field("Lorg/mortbay/resource/JarFileResource;","_jarUrl","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 10,11},new Method("Ljava/net/URL;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10},new Method("Ljava/net/URL;","openConnection",new String[]{ },"Ljava/net/URLConnection;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,10);
                code.visitTypeStmt(CHECK_CAST,10,-1,"Ljava/net/JarURLConnection;");
                code.visitStmt2R(MOVE_OBJECT,0,10);
                code.visitTypeStmt(CHECK_CAST,0,-1,"Ljava/net/JarURLConnection;");
                code.visitStmt2R(MOVE_OBJECT,6,0);
                code.visitLabel(L14);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 13},new Method("Lorg/mortbay/resource/JarFileResource;","getUseCaches",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,10);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,10},new Method("Ljava/net/JarURLConnection;","setUseCaches",new String[]{ "Z"},"V"));
                code.visitLabel(L15);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Ljava/net/JarURLConnection;","getJarFile",new String[]{ },"Ljava/util/jar/JarFile;"));
                code.visitLabel(L4);
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitLabel(L6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Ljava/util/jar/JarFile;","entries",new String[]{ },"Ljava/util/Enumeration;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitLabel(L16);
                code.visitFieldStmt(IGET_OBJECT,10,13,new Field("Lorg/mortbay/resource/JarFileResource;","_urlString","Ljava/lang/String;"));
                code.visitFieldStmt(IGET_OBJECT,11,13,new Field("Lorg/mortbay/resource/JarFileResource;","_urlString","Ljava/lang/String;"));
                code.visitConstStmt(CONST_STRING,12,"!/");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 11,12},new Method("Ljava/lang/String;","indexOf",new String[]{ "Ljava/lang/String;"},"I"));
                code.visitStmt1R(MOVE_RESULT,11);
                code.visitStmt2R1N(ADD_INT_LIT8,11,11,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10,11},new Method("Ljava/lang/String;","substring",new String[]{ "I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitLabel(L17);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 3},new Method("Ljava/util/Enumeration;","hasMoreElements",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,10);
                code.visitJumpStmt(IF_EQZ,10,-1,L31);
                code.visitLabel(L18);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 3},new Method("Ljava/util/Enumeration;","nextElement",new String[]{ },"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitTypeStmt(CHECK_CAST,4,-1,"Ljava/util/jar/JarEntry;");
                code.visitLabel(L19);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Ljava/util/jar/JarEntry;","getName",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,10);
                code.visitConstStmt(CONST_16,11, Integer.valueOf(92)); // int: 0x0000005c  float:0.000000
                code.visitConstStmt(CONST_16,12, Integer.valueOf(47)); // int: 0x0000002f  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10,11,12},new Method("Ljava/lang/String;","replace",new String[]{ "C","C"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,9);
                code.visitLabel(L20);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9,2},new Method("Ljava/lang/String;","startsWith",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,10);
                code.visitJumpStmt(IF_EQZ,10,-1,L17);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9},new Method("Ljava/lang/String;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,10);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Ljava/lang/String;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,11);
                code.visitJumpStmt(IF_EQ,10,11,L17);
                code.visitLabel(L21);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Ljava/lang/String;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,10);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9,10},new Method("Ljava/lang/String;","substring",new String[]{ "I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitLabel(L22);
                code.visitConstStmt(CONST_16,10, Integer.valueOf(47)); // int: 0x0000002f  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8,10},new Method("Ljava/lang/String;","indexOf",new String[]{ "I"},"I"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitLabel(L23);
                code.visitJumpStmt(IF_LTZ,1,-1,L28);
                code.visitLabel(L24);
                code.visitJumpStmt(IF_NEZ,1,-1,L25);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8},new Method("Ljava/lang/String;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,10);
                code.visitConstStmt(CONST_4,11, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitJumpStmt(IF_EQ,10,11,L17);
                code.visitLabel(L25);
                code.visitJumpStmt(IF_NEZ,1,-1,L29);
                code.visitLabel(L26);
                code.visitStmt2R1N(ADD_INT_LIT8,10,1,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8},new Method("Ljava/lang/String;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,11);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8,10,11},new Method("Ljava/lang/String;","substring",new String[]{ "I","I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitLabel(L27);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7,8},new Method("Ljava/util/ArrayList;","contains",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,10);
                code.visitJumpStmt(IF_NEZ,10,-1,L17);
                code.visitLabel(L28);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7,8},new Method("Ljava/util/ArrayList;","add",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitLabel(L7);
                code.visitJumpStmt(GOTO,-1,-1,L17);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,10);
                code.visitStmt1R(MONITOR_EXIT,13);
                code.visitStmt1R(THROW,10);
                code.visitLabel(L5);
                code.visitStmt1R(MOVE_EXCEPTION,10);
                code.visitStmt2R(MOVE_OBJECT,3,10);
                code.visitLabel(L8);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 3},new Method("Lorg/mortbay/log/Log;","ignore",new String[]{ "Ljava/lang/Throwable;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L6);
                code.visitLabel(L29);
                code.visitConstStmt(CONST_4,10, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitStmt2R1N(ADD_INT_LIT8,11,1,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8,10,11},new Method("Ljava/lang/String;","substring",new String[]{ "I","I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitLabel(L30);
                code.visitJumpStmt(GOTO,-1,-1,L27);
                code.visitLabel(L31);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7},new Method("Ljava/util/ArrayList;","size",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,10);
                code.visitTypeStmt(NEW_ARRAY,10,10,"[Ljava/lang/String;");
                code.visitFieldStmt(IPUT_OBJECT,10,13,new Field("Lorg/mortbay/resource/JarFileResource;","_list","[Ljava/lang/String;"));
                code.visitLabel(L32);
                code.visitFieldStmt(IGET_OBJECT,10,13,new Field("Lorg/mortbay/resource/JarFileResource;","_list","[Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7,10},new Method("Ljava/util/ArrayList;","toArray",new String[]{ "[Ljava/lang/Object;"},"[Ljava/lang/Object;"));
                code.visitLabel(L33);
                code.visitFieldStmt(IGET_OBJECT,10,13,new Field("Lorg/mortbay/resource/JarFileResource;","_list","[Ljava/lang/String;"));
                code.visitLabel(L9);
                code.visitStmt1R(MONITOR_EXIT,13);
                code.visitStmt1R(RETURN_OBJECT,10);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m010_newConnection(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Lorg/mortbay/resource/JarFileResource;","newConnection",new String[]{ },"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(6);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(87,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(89,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(90,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(91,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(92,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(94,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(95,L7);
                ddv.visitStartLocal(0,L7,"sep","I",null);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(96,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(97,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(98,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(99,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(100,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(101,L13);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,4, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_SUPER,new int[]{ 5},new Method("Lorg/mortbay/resource/JarResource;","newConnection",new String[]{ },"V"));
                code.visitLabel(L2);
                code.visitFieldStmt(IPUT_OBJECT,4,5,new Field("Lorg/mortbay/resource/JarFileResource;","_entry","Ljava/util/jar/JarEntry;"));
                code.visitLabel(L3);
                code.visitFieldStmt(IPUT_OBJECT,4,5,new Field("Lorg/mortbay/resource/JarFileResource;","_file","Ljava/io/File;"));
                code.visitLabel(L4);
                code.visitFieldStmt(IPUT_OBJECT,4,5,new Field("Lorg/mortbay/resource/JarFileResource;","_jarFile","Ljava/util/jar/JarFile;"));
                code.visitLabel(L5);
                code.visitFieldStmt(IPUT_OBJECT,4,5,new Field("Lorg/mortbay/resource/JarFileResource;","_list","[Ljava/lang/String;"));
                code.visitLabel(L6);
                code.visitFieldStmt(IGET_OBJECT,1,5,new Field("Lorg/mortbay/resource/JarFileResource;","_urlString","Ljava/lang/String;"));
                code.visitConstStmt(CONST_STRING,2,"!/");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2},new Method("Ljava/lang/String;","indexOf",new String[]{ "Ljava/lang/String;"},"I"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitLabel(L7);
                code.visitFieldStmt(IGET_OBJECT,1,5,new Field("Lorg/mortbay/resource/JarFileResource;","_urlString","Ljava/lang/String;"));
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitStmt2R1N(ADD_INT_LIT8,3,0,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2,3},new Method("Ljava/lang/String;","substring",new String[]{ "I","I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitFieldStmt(IPUT_OBJECT,1,5,new Field("Lorg/mortbay/resource/JarFileResource;","_jarUrl","Ljava/lang/String;"));
                code.visitLabel(L8);
                code.visitFieldStmt(IGET_OBJECT,1,5,new Field("Lorg/mortbay/resource/JarFileResource;","_urlString","Ljava/lang/String;"));
                code.visitStmt2R1N(ADD_INT_LIT8,2,0,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2},new Method("Ljava/lang/String;","substring",new String[]{ "I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitFieldStmt(IPUT_OBJECT,1,5,new Field("Lorg/mortbay/resource/JarFileResource;","_path","Ljava/lang/String;"));
                code.visitLabel(L9);
                code.visitFieldStmt(IGET_OBJECT,1,5,new Field("Lorg/mortbay/resource/JarFileResource;","_path","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/lang/String;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitJumpStmt(IF_NEZ,1,-1,L11);
                code.visitLabel(L10);
                code.visitFieldStmt(IPUT_OBJECT,4,5,new Field("Lorg/mortbay/resource/JarFileResource;","_path","Ljava/lang/String;"));
                code.visitLabel(L11);
                code.visitFieldStmt(IGET_OBJECT,1,5,new Field("Lorg/mortbay/resource/JarFileResource;","_jarConnection","Ljava/net/JarURLConnection;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/net/JarURLConnection;","getJarFile",new String[]{ },"Ljava/util/jar/JarFile;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitFieldStmt(IPUT_OBJECT,1,5,new Field("Lorg/mortbay/resource/JarFileResource;","_jarFile","Ljava/util/jar/JarFile;"));
                code.visitLabel(L12);
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Ljava/io/File;");
                code.visitFieldStmt(IGET_OBJECT,2,5,new Field("Lorg/mortbay/resource/JarFileResource;","_jarFile","Ljava/util/jar/JarFile;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Ljava/util/jar/JarFile;","getName",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1,2},new Method("Ljava/io/File;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitFieldStmt(IPUT_OBJECT,1,5,new Field("Lorg/mortbay/resource/JarFileResource;","_file","Ljava/io/File;"));
                code.visitLabel(L13);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m011_release(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/resource/JarFileResource;","release",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L3=new DexLabel();
                ddv.visitPrologue(L3);
                ddv.visitLineNumber(56,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(57,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(58,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(59,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(60,L7);
                ddv.visitLineNumber(61,L1);
                ddv.visitLineNumber(56,L2);
                code.visitLabel(L3);
                code.visitStmt1R(MONITOR_ENTER,1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/resource/JarFileResource;","_list","[Ljava/lang/String;"));
                code.visitLabel(L4);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/resource/JarFileResource;","_entry","Ljava/util/jar/JarEntry;"));
                code.visitLabel(L5);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/resource/JarFileResource;","_file","Ljava/io/File;"));
                code.visitLabel(L6);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/resource/JarFileResource;","_jarFile","Ljava/util/jar/JarFile;"));
                code.visitLabel(L7);
                code.visitMethodStmt(INVOKE_SUPER,new int[]{ 1},new Method("Lorg/mortbay/resource/JarResource;","release",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitStmt1R(MONITOR_EXIT,1);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,0);
                code.visitStmt1R(MONITOR_EXIT,1);
                code.visitStmt1R(THROW,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
