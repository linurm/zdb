package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0441_org_mortbay_util_ajax_JSON_2 {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(0,"Lorg/mortbay/util/ajax/JSON$2;","Ljava/lang/Object;",new String[]{ "Lorg/mortbay/util/ajax/JSON$Output;"});
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("JSON.java");
        if(cv!=null){
            DexAnnotationVisitor av00 = cv.visitAnnotation("Ldalvik/annotation/EnclosingMethod;", Visibility.SYSTEM);
            if(av00 != null) {
                av00.visit("value", new Method("Lorg/mortbay/util/ajax/JSON;","appendJSON",new String[]{ "Ljava/lang/StringBuffer;","Lorg/mortbay/util/ajax/JSON$Convertible;"},"V"));
                av00.visitEnd();
            }
        }
        if(cv!=null){
            DexAnnotationVisitor av00 = cv.visitAnnotation("Ldalvik/annotation/InnerClass;", Visibility.SYSTEM);
            if(av00 != null) {
                av00.visit("accessFlags",  Integer.valueOf(0));
                av00.visit("name", null);
                av00.visitEnd();
            }
        }
        f000_this$0(cv);
        f001_val$buffer(cv);
        f002_val$c(cv);
        m000__init_(cv);
        m001_add(cv);
        m002_add(cv);
        m003_add(cv);
        m004_add(cv);
        m005_add(cv);
        m006_addClass(cv);
    }
    public static void f000_this$0(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_FINAL|ACC_SYNTHETIC, new Field("Lorg/mortbay/util/ajax/JSON$2;","this$0","Lorg/mortbay/util/ajax/JSON;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f001_val$buffer(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_FINAL|ACC_SYNTHETIC, new Field("Lorg/mortbay/util/ajax/JSON$2;","val$buffer","Ljava/lang/StringBuffer;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f002_val$c(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_FINAL|ACC_SYNTHETIC, new Field("Lorg/mortbay/util/ajax/JSON$2;","val$c","[C"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void m000__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_CONSTRUCTOR, new Method("Lorg/mortbay/util/ajax/JSON$2;","<init>",new String[]{ "Lorg/mortbay/util/ajax/JSON;","[C","Ljava/lang/StringBuffer;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(355,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_OBJECT,1,0,new Field("Lorg/mortbay/util/ajax/JSON$2;","this$0","Lorg/mortbay/util/ajax/JSON;"));
                code.visitFieldStmt(IPUT_OBJECT,2,0,new Field("Lorg/mortbay/util/ajax/JSON$2;","val$c","[C"));
                code.visitFieldStmt(IPUT_OBJECT,3,0,new Field("Lorg/mortbay/util/ajax/JSON$2;","val$buffer","Ljava/lang/StringBuffer;"));
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/lang/Object;","<init>",new String[]{ },"V"));
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001_add(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/util/ajax/JSON$2;","add",new String[]{ "Ljava/lang/Object;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"obj");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(306,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(307,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(308,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(309,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(310,L5);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,0,3,new Field("Lorg/mortbay/util/ajax/JSON$2;","val$c","[C"));
                code.visitStmt3R(AGET_CHAR,0,0,2);
                code.visitJumpStmt(IF_NEZ,0,-1,L3);
                code.visitLabel(L2);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/lang/IllegalStateException;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/lang/IllegalStateException;","<init>",new String[]{ },"V"));
                code.visitStmt1R(THROW,0);
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,0,3,new Field("Lorg/mortbay/util/ajax/JSON$2;","this$0","Lorg/mortbay/util/ajax/JSON;"));
                code.visitFieldStmt(IGET_OBJECT,1,3,new Field("Lorg/mortbay/util/ajax/JSON$2;","val$buffer","Ljava/lang/StringBuffer;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1,4},new Method("Lorg/mortbay/util/ajax/JSON;","append",new String[]{ "Ljava/lang/StringBuffer;","Ljava/lang/Object;"},"V"));
                code.visitLabel(L4);
                code.visitFieldStmt(IGET_OBJECT,0,3,new Field("Lorg/mortbay/util/ajax/JSON$2;","val$c","[C"));
                code.visitStmt3R(APUT_CHAR,2,0,2);
                code.visitLabel(L5);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m002_add(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/util/ajax/JSON$2;","add",new String[]{ "Ljava/lang/String;","D"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(8);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"name");
                ddv.visitParameterName(1,"value");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(335,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(336,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(337,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(338,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(339,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(340,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(341,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(342,L8);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,0,4,new Field("Lorg/mortbay/util/ajax/JSON$2;","val$c","[C"));
                code.visitStmt3R(AGET_CHAR,0,0,3);
                code.visitJumpStmt(IF_NEZ,0,-1,L3);
                code.visitLabel(L2);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/lang/IllegalStateException;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/lang/IllegalStateException;","<init>",new String[]{ },"V"));
                code.visitStmt1R(THROW,0);
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,0,4,new Field("Lorg/mortbay/util/ajax/JSON$2;","val$buffer","Ljava/lang/StringBuffer;"));
                code.visitFieldStmt(IGET_OBJECT,1,4,new Field("Lorg/mortbay/util/ajax/JSON$2;","val$c","[C"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "[C"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L4);
                code.visitFieldStmt(IGET_OBJECT,0,4,new Field("Lorg/mortbay/util/ajax/JSON$2;","val$buffer","Ljava/lang/StringBuffer;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0,5},new Method("Lorg/mortbay/util/QuotedStringTokenizer;","quote",new String[]{ "Ljava/lang/StringBuffer;","Ljava/lang/String;"},"V"));
                code.visitLabel(L5);
                code.visitFieldStmt(IGET_OBJECT,0,4,new Field("Lorg/mortbay/util/ajax/JSON$2;","val$buffer","Ljava/lang/StringBuffer;"));
                code.visitConstStmt(CONST_16,1, Integer.valueOf(58)); // int: 0x0000003a  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "C"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L6);
                code.visitFieldStmt(IGET_OBJECT,0,4,new Field("Lorg/mortbay/util/ajax/JSON$2;","this$0","Lorg/mortbay/util/ajax/JSON;"));
                code.visitFieldStmt(IGET_OBJECT,1,4,new Field("Lorg/mortbay/util/ajax/JSON$2;","val$buffer","Ljava/lang/StringBuffer;"));
                code.visitTypeStmt(NEW_INSTANCE,2,-1,"Ljava/lang/Double;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2,6,7},new Method("Ljava/lang/Double;","<init>",new String[]{ "D"},"V"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1,2},new Method("Lorg/mortbay/util/ajax/JSON;","appendNumber",new String[]{ "Ljava/lang/StringBuffer;","Ljava/lang/Number;"},"V"));
                code.visitLabel(L7);
                code.visitFieldStmt(IGET_OBJECT,0,4,new Field("Lorg/mortbay/util/ajax/JSON$2;","val$c","[C"));
                code.visitConstStmt(CONST_16,1, Integer.valueOf(44)); // int: 0x0000002c  float:0.000000
                code.visitStmt3R(APUT_CHAR,1,0,3);
                code.visitLabel(L8);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m003_add(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/util/ajax/JSON$2;","add",new String[]{ "Ljava/lang/String;","J"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(8);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"name");
                ddv.visitParameterName(1,"value");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(346,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(347,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(348,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(349,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(350,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(351,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(352,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(353,L8);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,0,4,new Field("Lorg/mortbay/util/ajax/JSON$2;","val$c","[C"));
                code.visitStmt3R(AGET_CHAR,0,0,3);
                code.visitJumpStmt(IF_NEZ,0,-1,L3);
                code.visitLabel(L2);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/lang/IllegalStateException;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/lang/IllegalStateException;","<init>",new String[]{ },"V"));
                code.visitStmt1R(THROW,0);
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,0,4,new Field("Lorg/mortbay/util/ajax/JSON$2;","val$buffer","Ljava/lang/StringBuffer;"));
                code.visitFieldStmt(IGET_OBJECT,1,4,new Field("Lorg/mortbay/util/ajax/JSON$2;","val$c","[C"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "[C"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L4);
                code.visitFieldStmt(IGET_OBJECT,0,4,new Field("Lorg/mortbay/util/ajax/JSON$2;","val$buffer","Ljava/lang/StringBuffer;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0,5},new Method("Lorg/mortbay/util/QuotedStringTokenizer;","quote",new String[]{ "Ljava/lang/StringBuffer;","Ljava/lang/String;"},"V"));
                code.visitLabel(L5);
                code.visitFieldStmt(IGET_OBJECT,0,4,new Field("Lorg/mortbay/util/ajax/JSON$2;","val$buffer","Ljava/lang/StringBuffer;"));
                code.visitConstStmt(CONST_16,1, Integer.valueOf(58)); // int: 0x0000003a  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "C"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L6);
                code.visitFieldStmt(IGET_OBJECT,0,4,new Field("Lorg/mortbay/util/ajax/JSON$2;","this$0","Lorg/mortbay/util/ajax/JSON;"));
                code.visitFieldStmt(IGET_OBJECT,1,4,new Field("Lorg/mortbay/util/ajax/JSON$2;","val$buffer","Ljava/lang/StringBuffer;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 6,7},new Method("Lorg/mortbay/util/TypeUtil;","newLong",new String[]{ "J"},"Ljava/lang/Long;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1,2},new Method("Lorg/mortbay/util/ajax/JSON;","appendNumber",new String[]{ "Ljava/lang/StringBuffer;","Ljava/lang/Number;"},"V"));
                code.visitLabel(L7);
                code.visitFieldStmt(IGET_OBJECT,0,4,new Field("Lorg/mortbay/util/ajax/JSON$2;","val$c","[C"));
                code.visitConstStmt(CONST_16,1, Integer.valueOf(44)); // int: 0x0000002c  float:0.000000
                code.visitStmt3R(APUT_CHAR,1,0,3);
                code.visitLabel(L8);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m004_add(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/util/ajax/JSON$2;","add",new String[]{ "Ljava/lang/String;","Ljava/lang/Object;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(6);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"name");
                ddv.visitParameterName(1,"value");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(324,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(325,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(326,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(327,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(328,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(329,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(330,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(331,L8);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,0,3,new Field("Lorg/mortbay/util/ajax/JSON$2;","val$c","[C"));
                code.visitStmt3R(AGET_CHAR,0,0,2);
                code.visitJumpStmt(IF_NEZ,0,-1,L3);
                code.visitLabel(L2);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/lang/IllegalStateException;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/lang/IllegalStateException;","<init>",new String[]{ },"V"));
                code.visitStmt1R(THROW,0);
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,0,3,new Field("Lorg/mortbay/util/ajax/JSON$2;","val$buffer","Ljava/lang/StringBuffer;"));
                code.visitFieldStmt(IGET_OBJECT,1,3,new Field("Lorg/mortbay/util/ajax/JSON$2;","val$c","[C"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "[C"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L4);
                code.visitFieldStmt(IGET_OBJECT,0,3,new Field("Lorg/mortbay/util/ajax/JSON$2;","val$buffer","Ljava/lang/StringBuffer;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0,4},new Method("Lorg/mortbay/util/QuotedStringTokenizer;","quote",new String[]{ "Ljava/lang/StringBuffer;","Ljava/lang/String;"},"V"));
                code.visitLabel(L5);
                code.visitFieldStmt(IGET_OBJECT,0,3,new Field("Lorg/mortbay/util/ajax/JSON$2;","val$buffer","Ljava/lang/StringBuffer;"));
                code.visitConstStmt(CONST_16,1, Integer.valueOf(58)); // int: 0x0000003a  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "C"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L6);
                code.visitFieldStmt(IGET_OBJECT,0,3,new Field("Lorg/mortbay/util/ajax/JSON$2;","this$0","Lorg/mortbay/util/ajax/JSON;"));
                code.visitFieldStmt(IGET_OBJECT,1,3,new Field("Lorg/mortbay/util/ajax/JSON$2;","val$buffer","Ljava/lang/StringBuffer;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1,5},new Method("Lorg/mortbay/util/ajax/JSON;","append",new String[]{ "Ljava/lang/StringBuffer;","Ljava/lang/Object;"},"V"));
                code.visitLabel(L7);
                code.visitFieldStmt(IGET_OBJECT,0,3,new Field("Lorg/mortbay/util/ajax/JSON$2;","val$c","[C"));
                code.visitConstStmt(CONST_16,1, Integer.valueOf(44)); // int: 0x0000002c  float:0.000000
                code.visitStmt3R(APUT_CHAR,1,0,2);
                code.visitLabel(L8);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m005_add(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/util/ajax/JSON$2;","add",new String[]{ "Ljava/lang/String;","Z"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(7);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"name");
                ddv.visitParameterName(1,"value");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(357,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(358,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(359,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(360,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(361,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(362,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(363,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(364,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(362,L9);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,0,4,new Field("Lorg/mortbay/util/ajax/JSON$2;","val$c","[C"));
                code.visitStmt3R(AGET_CHAR,0,0,3);
                code.visitJumpStmt(IF_NEZ,0,-1,L3);
                code.visitLabel(L2);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/lang/IllegalStateException;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/lang/IllegalStateException;","<init>",new String[]{ },"V"));
                code.visitStmt1R(THROW,0);
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,0,4,new Field("Lorg/mortbay/util/ajax/JSON$2;","val$buffer","Ljava/lang/StringBuffer;"));
                code.visitFieldStmt(IGET_OBJECT,1,4,new Field("Lorg/mortbay/util/ajax/JSON$2;","val$c","[C"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "[C"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L4);
                code.visitFieldStmt(IGET_OBJECT,0,4,new Field("Lorg/mortbay/util/ajax/JSON$2;","val$buffer","Ljava/lang/StringBuffer;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0,5},new Method("Lorg/mortbay/util/QuotedStringTokenizer;","quote",new String[]{ "Ljava/lang/StringBuffer;","Ljava/lang/String;"},"V"));
                code.visitLabel(L5);
                code.visitFieldStmt(IGET_OBJECT,0,4,new Field("Lorg/mortbay/util/ajax/JSON$2;","val$buffer","Ljava/lang/StringBuffer;"));
                code.visitConstStmt(CONST_16,1, Integer.valueOf(58)); // int: 0x0000003a  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "C"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L6);
                code.visitFieldStmt(IGET_OBJECT,0,4,new Field("Lorg/mortbay/util/ajax/JSON$2;","this$0","Lorg/mortbay/util/ajax/JSON;"));
                code.visitFieldStmt(IGET_OBJECT,1,4,new Field("Lorg/mortbay/util/ajax/JSON$2;","val$buffer","Ljava/lang/StringBuffer;"));
                code.visitJumpStmt(IF_EQZ,6,-1,L9);
                code.visitFieldStmt(SGET_OBJECT,2,-1,new Field("Ljava/lang/Boolean;","TRUE","Ljava/lang/Boolean;"));
                DexLabel L10=new DexLabel();
                code.visitLabel(L10);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1,2},new Method("Lorg/mortbay/util/ajax/JSON;","appendBoolean",new String[]{ "Ljava/lang/StringBuffer;","Ljava/lang/Boolean;"},"V"));
                code.visitLabel(L7);
                code.visitFieldStmt(IGET_OBJECT,0,4,new Field("Lorg/mortbay/util/ajax/JSON$2;","val$c","[C"));
                code.visitConstStmt(CONST_16,1, Integer.valueOf(44)); // int: 0x0000002c  float:0.000000
                code.visitStmt3R(APUT_CHAR,1,0,3);
                code.visitLabel(L8);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L9);
                code.visitFieldStmt(SGET_OBJECT,2,-1,new Field("Ljava/lang/Boolean;","FALSE","Ljava/lang/Boolean;"));
                code.visitJumpStmt(GOTO,-1,-1,L10);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m006_addClass(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/util/ajax/JSON$2;","addClass",new String[]{ "Ljava/lang/Class;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(6);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"type");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(314,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(315,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(316,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(317,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(318,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(319,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(320,L7);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,0,4,new Field("Lorg/mortbay/util/ajax/JSON$2;","val$c","[C"));
                code.visitStmt3R(AGET_CHAR,0,0,3);
                code.visitJumpStmt(IF_NEZ,0,-1,L3);
                code.visitLabel(L2);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/lang/IllegalStateException;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/lang/IllegalStateException;","<init>",new String[]{ },"V"));
                code.visitStmt1R(THROW,0);
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,0,4,new Field("Lorg/mortbay/util/ajax/JSON$2;","val$buffer","Ljava/lang/StringBuffer;"));
                code.visitFieldStmt(IGET_OBJECT,1,4,new Field("Lorg/mortbay/util/ajax/JSON$2;","val$c","[C"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "[C"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L4);
                code.visitFieldStmt(IGET_OBJECT,0,4,new Field("Lorg/mortbay/util/ajax/JSON$2;","val$buffer","Ljava/lang/StringBuffer;"));
                code.visitConstStmt(CONST_STRING,1,"\"class\":");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L5);
                code.visitFieldStmt(IGET_OBJECT,0,4,new Field("Lorg/mortbay/util/ajax/JSON$2;","this$0","Lorg/mortbay/util/ajax/JSON;"));
                code.visitFieldStmt(IGET_OBJECT,1,4,new Field("Lorg/mortbay/util/ajax/JSON$2;","val$buffer","Ljava/lang/StringBuffer;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Ljava/lang/Class;","getName",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1,2},new Method("Lorg/mortbay/util/ajax/JSON;","append",new String[]{ "Ljava/lang/StringBuffer;","Ljava/lang/Object;"},"V"));
                code.visitLabel(L6);
                code.visitFieldStmt(IGET_OBJECT,0,4,new Field("Lorg/mortbay/util/ajax/JSON$2;","val$c","[C"));
                code.visitConstStmt(CONST_16,1, Integer.valueOf(44)); // int: 0x0000002c  float:0.000000
                code.visitStmt3R(APUT_CHAR,1,0,3);
                code.visitLabel(L7);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
