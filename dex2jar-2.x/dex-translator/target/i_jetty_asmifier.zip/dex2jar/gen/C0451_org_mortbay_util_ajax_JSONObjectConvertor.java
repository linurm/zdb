package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0451_org_mortbay_util_ajax_JSONObjectConvertor {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(ACC_PUBLIC,"Lorg/mortbay/util/ajax/JSONObjectConvertor;","Ljava/lang/Object;",new String[]{ "Lorg/mortbay/util/ajax/JSON$Convertor;"});
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("JSONObjectConvertor.java");
        f000__excluded(cv);
        f001__fromJSON(cv);
        m000__init_(cv);
        m001__init_(cv);
        m002__init_(cv);
        m003_fromJSON(cv);
        m004_includeField(cv);
        m005_toJSON(cv);
    }
    public static void f000__excluded(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/util/ajax/JSONObjectConvertor;","_excluded","Ljava/util/Set;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f001__fromJSON(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/util/ajax/JSONObjectConvertor;","_fromJSON","Z"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void m000__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/util/ajax/JSONObjectConvertor;","<init>",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(39,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(36,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(40,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(41,L3);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1},new Method("Ljava/lang/Object;","<init>",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/util/ajax/JSONObjectConvertor;","_excluded","Ljava/util/Set;"));
                code.visitLabel(L2);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT_BOOLEAN,0,1,new Field("Lorg/mortbay/util/ajax/JSONObjectConvertor;","_fromJSON","Z"));
                code.visitLabel(L3);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/util/ajax/JSONObjectConvertor;","<init>",new String[]{ "Z"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"fromJSON");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(44,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(36,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(45,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(46,L3);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1},new Method("Ljava/lang/Object;","<init>",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/util/ajax/JSONObjectConvertor;","_excluded","Ljava/util/Set;"));
                code.visitLabel(L2);
                code.visitFieldStmt(IPUT_BOOLEAN,2,1,new Field("Lorg/mortbay/util/ajax/JSONObjectConvertor;","_fromJSON","Z"));
                code.visitLabel(L3);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m002__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/util/ajax/JSONObjectConvertor;","<init>",new String[]{ "Z","[Ljava/lang/String;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"fromJSON");
                ddv.visitParameterName(1,"excluded");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(54,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(36,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(55,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(56,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(57,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(58,L5);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2},new Method("Ljava/lang/Object;","<init>",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT_OBJECT,0,2,new Field("Lorg/mortbay/util/ajax/JSONObjectConvertor;","_excluded","Ljava/util/Set;"));
                code.visitLabel(L2);
                code.visitFieldStmt(IPUT_BOOLEAN,3,2,new Field("Lorg/mortbay/util/ajax/JSONObjectConvertor;","_fromJSON","Z"));
                code.visitLabel(L3);
                code.visitJumpStmt(IF_EQZ,4,-1,L5);
                code.visitLabel(L4);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/util/HashSet;");
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 4},new Method("Ljava/util/Arrays;","asList",new String[]{ "[Ljava/lang/Object;"},"Ljava/util/List;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1},new Method("Ljava/util/HashSet;","<init>",new String[]{ "Ljava/util/Collection;"},"V"));
                code.visitFieldStmt(IPUT_OBJECT,0,2,new Field("Lorg/mortbay/util/ajax/JSONObjectConvertor;","_excluded","Ljava/util/Set;"));
                code.visitLabel(L5);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m003_fromJSON(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/util/ajax/JSONObjectConvertor;","fromJSON",new String[]{ "Ljava/util/Map;"},"Ljava/lang/Object;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"map");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(62,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(63,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(64,L2);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_BOOLEAN,0,1,new Field("Lorg/mortbay/util/ajax/JSONObjectConvertor;","_fromJSON","Z"));
                code.visitJumpStmt(IF_EQZ,0,-1,L2);
                code.visitLabel(L1);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/lang/UnsupportedOperationException;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/lang/UnsupportedOperationException;","<init>",new String[]{ },"V"));
                code.visitStmt1R(THROW,0);
                code.visitLabel(L2);
                code.visitStmt1R(RETURN_OBJECT,2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m004_includeField(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Lorg/mortbay/util/ajax/JSONObjectConvertor;","includeField",new String[]{ "Ljava/lang/String;","Ljava/lang/Object;","Ljava/lang/reflect/Method;"},"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"name");
                ddv.visitParameterName(1,"o");
                ddv.visitParameterName(2,"m");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(107,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/util/ajax/JSONObjectConvertor;","_excluded","Ljava/util/Set;"));
                DexLabel L1=new DexLabel();
                code.visitJumpStmt(IF_EQZ,0,-1,L1);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/util/ajax/JSONObjectConvertor;","_excluded","Ljava/util/Set;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,2},new Method("Ljava/util/Set;","contains",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                DexLabel L2=new DexLabel();
                code.visitJumpStmt(IF_NEZ,0,-1,L2);
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                DexLabel L3=new DexLabel();
                code.visitLabel(L3);
                code.visitStmt1R(RETURN,0);
                code.visitLabel(L2);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L3);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m005_toJSON(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/util/ajax/JSONObjectConvertor;","toJSON",new String[]{ "Ljava/lang/Object;","Lorg/mortbay/util/ajax/JSON$Output;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(12);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ "Ljava/lang/Throwable;"});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"obj");
                ddv.visitParameterName(1,"out");
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(71,L0);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(73,L3);
                ddv.visitStartLocal(0,L3,"c","Ljava/lang/Class;",null);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(74,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(76,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(78,L6);
                ddv.visitStartLocal(4,L6,"methods","[Ljava/lang/reflect/Method;",null);
                DexLabel L7=new DexLabel();
                ddv.visitStartLocal(2,L7,"i","I",null);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(80,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(81,L9);
                ddv.visitStartLocal(3,L9,"m","Ljava/lang/reflect/Method;",null);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(86,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(87,L11);
                ddv.visitStartLocal(5,L11,"name","Ljava/lang/String;",null);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(88,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(94,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(95,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(78,L15);
                ddv.visitEndLocal(5,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(89,L16);
                ddv.visitRestartLocal(5,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(90,L17);
                DexLabel L18=new DexLabel();
                ddv.visitRestartLocal(5,L18);
                ddv.visitLineNumber(99,L2);
                ddv.visitEndLocal(0,L2);
                ddv.visitEndLocal(4,L2);
                ddv.visitEndLocal(2,L2);
                ddv.visitEndLocal(3,L2);
                ddv.visitEndLocal(5,L2);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(101,L19);
                ddv.visitStartLocal(1,L19,"e","Ljava/lang/Throwable;",null);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(103,L20);
                ddv.visitEndLocal(1,L20);
                ddv.visitRestartLocal(0,L20);
                ddv.visitRestartLocal(2,L20);
                ddv.visitRestartLocal(4,L20);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10},new Method("Ljava/lang/Object;","getClass",new String[]{ },"Ljava/lang/Class;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_BOOLEAN,6,9,new Field("Lorg/mortbay/util/ajax/JSONObjectConvertor;","_fromJSON","Z"));
                code.visitJumpStmt(IF_EQZ,6,-1,L5);
                code.visitLabel(L4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10},new Method("Ljava/lang/Object;","getClass",new String[]{ },"Ljava/lang/Class;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 11,6},new Method("Lorg/mortbay/util/ajax/JSON$Output;","addClass",new String[]{ "Ljava/lang/Class;"},"V"));
                code.visitLabel(L5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10},new Method("Ljava/lang/Object;","getClass",new String[]{ },"Ljava/lang/Class;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Ljava/lang/Class;","getMethods",new String[]{ },"[Ljava/lang/reflect/Method;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitLabel(L6);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L7);
                code.visitStmt2R(ARRAY_LENGTH,6,4);
                code.visitJumpStmt(IF_GE,2,6,L20);
                code.visitLabel(L8);
                code.visitStmt3R(AGET_OBJECT,3,4,2);
                code.visitLabel(L9);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Ljava/lang/reflect/Method;","getModifiers",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,6);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 6},new Method("Ljava/lang/reflect/Modifier;","isStatic",new String[]{ "I"},"Z"));
                code.visitStmt1R(MOVE_RESULT,6);
                code.visitJumpStmt(IF_NEZ,6,-1,L15);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Ljava/lang/reflect/Method;","getParameterTypes",new String[]{ },"[Ljava/lang/Class;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitStmt2R(ARRAY_LENGTH,6,6);
                code.visitJumpStmt(IF_NEZ,6,-1,L15);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Ljava/lang/reflect/Method;","getReturnType",new String[]{ },"Ljava/lang/Class;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitJumpStmt(IF_EQZ,6,-1,L15);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Ljava/lang/reflect/Method;","getDeclaringClass",new String[]{ },"Ljava/lang/Class;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitConstStmt(CONST_CLASS,7,new DexType("Ljava/lang/Object;"));
                code.visitJumpStmt(IF_EQ,6,7,L15);
                code.visitLabel(L10);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Ljava/lang/reflect/Method;","getName",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitLabel(L11);
                code.visitConstStmt(CONST_STRING,6,"is");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,6},new Method("Ljava/lang/String;","startsWith",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,6);
                code.visitJumpStmt(IF_EQZ,6,-1,L16);
                code.visitLabel(L12);
                code.visitTypeStmt(NEW_INSTANCE,6,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 6},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_4,7, Integer.valueOf(2)); // int: 0x00000002  float:0.000000
                code.visitConstStmt(CONST_4,8, Integer.valueOf(3)); // int: 0x00000003  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,7,8},new Method("Ljava/lang/String;","substring",new String[]{ "I","I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7},new Method("Ljava/lang/String;","toLowerCase",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,7},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitConstStmt(CONST_4,7, Integer.valueOf(3)); // int: 0x00000003  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,7},new Method("Ljava/lang/String;","substring",new String[]{ "I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,7},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitLabel(L13);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9,5,10,3},new Method("Lorg/mortbay/util/ajax/JSONObjectConvertor;","includeField",new String[]{ "Ljava/lang/String;","Ljava/lang/Object;","Ljava/lang/reflect/Method;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,6);
                code.visitJumpStmt(IF_EQZ,6,-1,L15);
                code.visitLabel(L14);
                code.visitConstStmt(CONST_4,6, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitTypeStmt(CHECK_CAST,6,-1,"[Ljava/lang/Object;");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,10,6},new Method("Ljava/lang/reflect/Method;","invoke",new String[]{ "Ljava/lang/Object;","[Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 11,5,6},new Method("Lorg/mortbay/util/ajax/JSON$Output;","add",new String[]{ "Ljava/lang/String;","Ljava/lang/Object;"},"V"));
                code.visitLabel(L15);
                code.visitStmt2R1N(ADD_INT_LIT8,2,2,1);
                code.visitJumpStmt(GOTO,-1,-1,L7);
                code.visitLabel(L16);
                code.visitConstStmt(CONST_STRING,6,"get");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,6},new Method("Ljava/lang/String;","startsWith",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,6);
                code.visitJumpStmt(IF_EQZ,6,-1,L15);
                code.visitLabel(L17);
                code.visitTypeStmt(NEW_INSTANCE,6,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 6},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_4,7, Integer.valueOf(3)); // int: 0x00000003  float:0.000000
                code.visitConstStmt(CONST_4,8, Integer.valueOf(4)); // int: 0x00000004  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,7,8},new Method("Ljava/lang/String;","substring",new String[]{ "I","I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7},new Method("Ljava/lang/String;","toLowerCase",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,7},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitConstStmt(CONST_4,7, Integer.valueOf(4)); // int: 0x00000004  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,7},new Method("Ljava/lang/String;","substring",new String[]{ "I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,7},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitLabel(L1);
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitLabel(L18);
                code.visitJumpStmt(GOTO,-1,-1,L13);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,6);
                code.visitStmt2R(MOVE_OBJECT,1,6);
                code.visitLabel(L19);
                code.visitTypeStmt(NEW_INSTANCE,6,-1,"Ljava/lang/RuntimeException;");
                code.visitConstStmt(CONST_STRING,7,"Illegal argument");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 6,7,1},new Method("Ljava/lang/RuntimeException;","<init>",new String[]{ "Ljava/lang/String;","Ljava/lang/Throwable;"},"V"));
                code.visitStmt1R(THROW,6);
                code.visitLabel(L20);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
