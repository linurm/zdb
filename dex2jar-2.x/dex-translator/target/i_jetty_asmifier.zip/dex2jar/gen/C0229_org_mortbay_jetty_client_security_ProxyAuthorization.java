package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0229_org_mortbay_jetty_client_security_ProxyAuthorization {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(ACC_PUBLIC,"Lorg/mortbay/jetty/client/security/ProxyAuthorization;","Ljava/lang/Object;",new String[]{ "Lorg/mortbay/jetty/client/security/Authorization;"});
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("ProxyAuthorization.java");
        f000__authorization(cv);
        m000__init_(cv);
        m001_setCredentials(cv);
    }
    public static void f000__authorization(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/client/security/ProxyAuthorization;","_authorization","Lorg/mortbay/io/Buffer;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void m000__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/jetty/client/security/ProxyAuthorization;","<init>",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(7);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"username");
                ddv.visitParameterName(1,"password");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(37,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(38,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(39,L2);
                ddv.visitStartLocal(0,L2,"authenticationString","Ljava/lang/String;",null);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(40,L3);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 4},new Method("Ljava/lang/Object;","<init>",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,2,"Basic ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitTypeStmt(NEW_INSTANCE,2,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,5},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitConstStmt(CONST_STRING,3,":");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,6},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitFieldStmt(SGET_OBJECT,3,-1,new Field("Lorg/mortbay/util/StringUtil;","__ISO_8859_1","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 2,3},new Method("Lorg/mortbay/jetty/security/B64Code;","encode",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L2);
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Lorg/mortbay/io/ByteArrayBuffer;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1,0},new Method("Lorg/mortbay/io/ByteArrayBuffer;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitFieldStmt(IPUT_OBJECT,1,4,new Field("Lorg/mortbay/jetty/client/security/ProxyAuthorization;","_authorization","Lorg/mortbay/io/Buffer;"));
                code.visitLabel(L3);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001_setCredentials(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/client/security/ProxyAuthorization;","setCredentials",new String[]{ "Lorg/mortbay/jetty/client/HttpExchange;"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"exchange");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(51,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(52,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(SGET_OBJECT,0,-1,new Field("Lorg/mortbay/jetty/HttpHeaders;","PROXY_AUTHORIZATION_BUFFER","Lorg/mortbay/io/Buffer;"));
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/jetty/client/security/ProxyAuthorization;","_authorization","Lorg/mortbay/io/Buffer;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,0,1},new Method("Lorg/mortbay/jetty/client/HttpExchange;","setRequestHeader",new String[]{ "Lorg/mortbay/io/Buffer;","Lorg/mortbay/io/Buffer;"},"V"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
