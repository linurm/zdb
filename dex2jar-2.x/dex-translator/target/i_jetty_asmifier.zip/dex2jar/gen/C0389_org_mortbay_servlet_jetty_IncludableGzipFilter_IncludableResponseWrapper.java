package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0389_org_mortbay_servlet_jetty_IncludableGzipFilter_IncludableResponseWrapper {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(ACC_PUBLIC,"Lorg/mortbay/servlet/jetty/IncludableGzipFilter$IncludableResponseWrapper;","Lorg/mortbay/servlet/GzipFilter$GZIPResponseWrapper;",new String[]{ });
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("IncludableGzipFilter.java");
        if(cv!=null){
            DexAnnotationVisitor av00 = cv.visitAnnotation("Ldalvik/annotation/EnclosingClass;", Visibility.SYSTEM);
            if(av00 != null) {
                av00.visit("value", new DexType("Lorg/mortbay/servlet/jetty/IncludableGzipFilter;"));
                av00.visitEnd();
            }
        }
        if(cv!=null){
            DexAnnotationVisitor av00 = cv.visitAnnotation("Ldalvik/annotation/InnerClass;", Visibility.SYSTEM);
            if(av00 != null) {
                av00.visit("accessFlags",  Integer.valueOf(1));
                av00.visit("name", "IncludableResponseWrapper");
                av00.visitEnd();
            }
        }
        f000_this$0(cv);
        m000__init_(cv);
        m001_newGzipStream(cv);
    }
    public static void f000_this$0(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_FINAL|ACC_SYNTHETIC, new Field("Lorg/mortbay/servlet/jetty/IncludableGzipFilter$IncludableResponseWrapper;","this$0","Lorg/mortbay/servlet/jetty/IncludableGzipFilter;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void m000__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/servlet/jetty/IncludableGzipFilter$IncludableResponseWrapper;","<init>",new String[]{ "Lorg/mortbay/servlet/jetty/IncludableGzipFilter;","Ljavax/servlet/http/HttpServletRequest;","Ljavax/servlet/http/HttpServletResponse;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(1,"request");
                ddv.visitParameterName(2,"response");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(47,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(48,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(49,L2);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_OBJECT,1,0,new Field("Lorg/mortbay/servlet/jetty/IncludableGzipFilter$IncludableResponseWrapper;","this$0","Lorg/mortbay/servlet/jetty/IncludableGzipFilter;"));
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1,2,3},new Method("Lorg/mortbay/servlet/GzipFilter$GZIPResponseWrapper;","<init>",new String[]{ "Lorg/mortbay/servlet/GzipFilter;","Ljavax/servlet/http/HttpServletRequest;","Ljavax/servlet/http/HttpServletResponse;"},"V"));
                code.visitLabel(L2);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001_newGzipStream(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Lorg/mortbay/servlet/jetty/IncludableGzipFilter$IncludableResponseWrapper;","newGzipStream",new String[]{ "Ljavax/servlet/http/HttpServletRequest;","Ljavax/servlet/http/HttpServletResponse;","J","I","I"},"Lorg/mortbay/servlet/GzipFilter$GzipStream;"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(15);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"request");
                ddv.visitParameterName(1,"response");
                ddv.visitParameterName(2,"contentLength");
                ddv.visitParameterName(3,"bufferSize");
                ddv.visitParameterName(4,"minGzipSize");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(53,L0);
                code.visitLabel(L0);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Lorg/mortbay/servlet/jetty/IncludableGzipFilter$IncludableGzipStream;");
                code.visitFieldStmt(IGET_OBJECT,1,8,new Field("Lorg/mortbay/servlet/jetty/IncludableGzipFilter$IncludableResponseWrapper;","this$0","Lorg/mortbay/servlet/jetty/IncludableGzipFilter;"));
                code.visitStmt2R(MOVE_OBJECT,2,9);
                code.visitStmt2R(MOVE_OBJECT,3,10);
                code.visitStmt2R(MOVE_WIDE,4,11);
                code.visitStmt2R(MOVE,6,13);
                code.visitStmt2R(MOVE,7,14);
                code.visitMethodStmt(INVOKE_DIRECT_RANGE,new int[]{ 0,1,2,3,4,5,6,7},new Method("Lorg/mortbay/servlet/jetty/IncludableGzipFilter$IncludableGzipStream;","<init>",new String[]{ "Lorg/mortbay/servlet/jetty/IncludableGzipFilter;","Ljavax/servlet/http/HttpServletRequest;","Ljavax/servlet/http/HttpServletResponse;","J","I","I"},"V"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
