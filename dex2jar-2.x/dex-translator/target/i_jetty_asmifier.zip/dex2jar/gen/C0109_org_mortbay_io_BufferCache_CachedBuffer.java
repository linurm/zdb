package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0109_org_mortbay_io_BufferCache_CachedBuffer {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(ACC_PUBLIC,"Lorg/mortbay/io/BufferCache$CachedBuffer;","Lorg/mortbay/io/ByteArrayBuffer$CaseInsensitive;",new String[]{ });
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("BufferCache.java");
        if(cv!=null){
            DexAnnotationVisitor av00 = cv.visitAnnotation("Ldalvik/annotation/EnclosingClass;", Visibility.SYSTEM);
            if(av00 != null) {
                av00.visit("value", new DexType("Lorg/mortbay/io/BufferCache;"));
                av00.visitEnd();
            }
        }
        if(cv!=null){
            DexAnnotationVisitor av00 = cv.visitAnnotation("Ldalvik/annotation/InnerClass;", Visibility.SYSTEM);
            if(av00 != null) {
                av00.visit("accessFlags",  Integer.valueOf(9));
                av00.visit("name", "CachedBuffer");
                av00.visitEnd();
            }
        }
        f000__associateMap(cv);
        f001__ordinal(cv);
        m000__init_(cv);
        m001_getAssociate(cv);
        m002_getOrdinal(cv);
        m003_setAssociate(cv);
    }
    public static void f000__associateMap(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/io/BufferCache$CachedBuffer;","_associateMap","Ljava/util/HashMap;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f001__ordinal(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/io/BufferCache$CachedBuffer;","_ordinal","I"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void m000__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/io/BufferCache$CachedBuffer;","<init>",new String[]{ "Ljava/lang/String;","I"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"value");
                ddv.visitParameterName(1,"ordinal");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(120,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(116,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(121,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(122,L3);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1,2},new Method("Lorg/mortbay/io/ByteArrayBuffer$CaseInsensitive;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/io/BufferCache$CachedBuffer;","_associateMap","Ljava/util/HashMap;"));
                code.visitLabel(L2);
                code.visitFieldStmt(IPUT,3,1,new Field("Lorg/mortbay/io/BufferCache$CachedBuffer;","_ordinal","I"));
                code.visitLabel(L3);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001_getAssociate(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/io/BufferCache$CachedBuffer;","getAssociate",new String[]{ "Ljava/lang/Object;"},"Lorg/mortbay/io/BufferCache$CachedBuffer;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"key");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(131,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(132,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(133,L2);
                ddv.visitEndLocal(1,L2);
                DexLabel L3=new DexLabel();
                ddv.visitRestartLocal(1,L3);
                DexLabel L4=new DexLabel();
                ddv.visitEndLocal(1,L4);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/io/BufferCache$CachedBuffer;","_associateMap","Ljava/util/HashMap;"));
                code.visitJumpStmt(IF_NEZ,0,-1,L3);
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L2);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/io/BufferCache$CachedBuffer;","_associateMap","Ljava/util/HashMap;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,2},new Method("Ljava/util/HashMap;","get",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L4);
                code.visitTypeStmt(CHECK_CAST,1,-1,"Lorg/mortbay/io/BufferCache$CachedBuffer;");
                code.visitStmt2R(MOVE_OBJECT,0,1);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m002_getOrdinal(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/io/BufferCache$CachedBuffer;","getOrdinal",new String[]{ },"I"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(126,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET,0,1,new Field("Lorg/mortbay/io/BufferCache$CachedBuffer;","_ordinal","I"));
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m003_setAssociate(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/io/BufferCache$CachedBuffer;","setAssociate",new String[]{ "Ljava/lang/Object;","Lorg/mortbay/io/BufferCache$CachedBuffer;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"key");
                ddv.visitParameterName(1,"associate");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(139,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(140,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(141,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(142,L3);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/io/BufferCache$CachedBuffer;","_associateMap","Ljava/util/HashMap;"));
                code.visitJumpStmt(IF_NEZ,0,-1,L2);
                code.visitLabel(L1);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/util/HashMap;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/util/HashMap;","<init>",new String[]{ },"V"));
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/io/BufferCache$CachedBuffer;","_associateMap","Ljava/util/HashMap;"));
                code.visitLabel(L2);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/io/BufferCache$CachedBuffer;","_associateMap","Ljava/util/HashMap;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,2,3},new Method("Ljava/util/HashMap;","put",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitLabel(L3);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
