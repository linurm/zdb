package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0399_org_mortbay_util_ArrayQueue {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(ACC_PUBLIC,"Lorg/mortbay/util/ArrayQueue;","Ljava/util/AbstractList;",new String[]{ "Ljava/util/Queue;"});
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("ArrayQueue.java");
        if(cv!=null){
            DexAnnotationVisitor av00 = cv.visitAnnotation("Ldalvik/annotation/Signature;", Visibility.SYSTEM);
            if(av00 != null) {
                {
                    DexAnnotationVisitor av01 = av00.visitArray("value");
                    if(av01 != null) {
                        av01.visit(null, "<E:");
                        av01.visit(null, "Ljava/lang/Object;");
                        av01.visit(null, ">");
                        av01.visit(null, "Ljava/util/AbstractList");
                        av01.visit(null, "<TE;>;");
                        av01.visit(null, "Ljava/util/Queue");
                        av01.visit(null, "<TE;>;");
                        av01.visitEnd();
                    }
                }
                av00.visitEnd();
            }
        }
        f000_DEFAULT_CAPACITY(cv);
        f001_DEFAULT_GROWTH(cv);
        f002__elements(cv);
        f003__growCapacity(cv);
        f004__lock(cv);
        f005__nextE(cv);
        f006__nextSlot(cv);
        f007__size(cv);
        m000__init_(cv);
        m001__init_(cv);
        m002__init_(cv);
        m003__init_(cv);
        m004_add(cv);
        m005_add(cv);
        m006_addUnsafe(cv);
        m007_clear(cv);
        m008_element(cv);
        m009_get(cv);
        m010_getCapacity(cv);
        m011_getUnsafe(cv);
        m012_grow(cv);
        m013_isEmpty(cv);
        m014_offer(cv);
        m015_peek(cv);
        m016_poll(cv);
        m017_remove(cv);
        m018_remove(cv);
        m019_set(cv);
        m020_size(cv);
    }
    public static void f000_DEFAULT_CAPACITY(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_FINAL, new Field("Lorg/mortbay/util/ArrayQueue;","DEFAULT_CAPACITY","I"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f001_DEFAULT_GROWTH(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_FINAL, new Field("Lorg/mortbay/util/ArrayQueue;","DEFAULT_GROWTH","I"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f002__elements(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PROTECTED, new Field("Lorg/mortbay/util/ArrayQueue;","_elements","[Ljava/lang/Object;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f003__growCapacity(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PROTECTED, new Field("Lorg/mortbay/util/ArrayQueue;","_growCapacity","I"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f004__lock(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PROTECTED, new Field("Lorg/mortbay/util/ArrayQueue;","_lock","Ljava/lang/Object;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f005__nextE(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PROTECTED, new Field("Lorg/mortbay/util/ArrayQueue;","_nextE","I"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f006__nextSlot(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PROTECTED, new Field("Lorg/mortbay/util/ArrayQueue;","_nextSlot","I"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f007__size(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PROTECTED, new Field("Lorg/mortbay/util/ArrayQueue;","_size","I"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void m000__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/util/ArrayQueue;","<init>",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitStartLocal(2,L0,"this","Lorg/mortbay/util/ArrayQueue;","Lorg/mortbay/util/ArrayQueue<TE;>;");
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(47,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(36,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(37,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(38,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(48,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(49,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(50,L7);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_16,0, Integer.valueOf(64)); // int: 0x00000040  float:0.000000
                code.visitConstStmt(CONST_16,1, Integer.valueOf(32)); // int: 0x00000020  float:0.000000
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2},new Method("Ljava/util/AbstractList;","<init>",new String[]{ },"V"));
                code.visitLabel(L2);
                code.visitFieldStmt(IPUT,0,2,new Field("Lorg/mortbay/util/ArrayQueue;","DEFAULT_CAPACITY","I"));
                code.visitLabel(L3);
                code.visitFieldStmt(IPUT,1,2,new Field("Lorg/mortbay/util/ArrayQueue;","DEFAULT_GROWTH","I"));
                code.visitLabel(L4);
                code.visitFieldStmt(IPUT_OBJECT,2,2,new Field("Lorg/mortbay/util/ArrayQueue;","_lock","Ljava/lang/Object;"));
                code.visitLabel(L5);
                code.visitTypeStmt(NEW_ARRAY,0,0,"[Ljava/lang/Object;");
                code.visitFieldStmt(IPUT_OBJECT,0,2,new Field("Lorg/mortbay/util/ArrayQueue;","_elements","[Ljava/lang/Object;"));
                code.visitLabel(L6);
                code.visitFieldStmt(IPUT,1,2,new Field("Lorg/mortbay/util/ArrayQueue;","_growCapacity","I"));
                code.visitLabel(L7);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/util/ArrayQueue;","<init>",new String[]{ "I"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"capacity");
                DexLabel L0=new DexLabel();
                ddv.visitStartLocal(1,L0,"this","Lorg/mortbay/util/ArrayQueue;","Lorg/mortbay/util/ArrayQueue<TE;>;");
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(54,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(36,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(37,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(38,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(55,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(56,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(57,L6);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1},new Method("Ljava/util/AbstractList;","<init>",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitConstStmt(CONST_16,0, Integer.valueOf(64)); // int: 0x00000040  float:0.000000
                code.visitFieldStmt(IPUT,0,1,new Field("Lorg/mortbay/util/ArrayQueue;","DEFAULT_CAPACITY","I"));
                code.visitLabel(L2);
                code.visitConstStmt(CONST_16,0, Integer.valueOf(32)); // int: 0x00000020  float:0.000000
                code.visitFieldStmt(IPUT,0,1,new Field("Lorg/mortbay/util/ArrayQueue;","DEFAULT_GROWTH","I"));
                code.visitLabel(L3);
                code.visitFieldStmt(IPUT_OBJECT,1,1,new Field("Lorg/mortbay/util/ArrayQueue;","_lock","Ljava/lang/Object;"));
                code.visitLabel(L4);
                code.visitTypeStmt(NEW_ARRAY,0,2,"[Ljava/lang/Object;");
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/util/ArrayQueue;","_elements","[Ljava/lang/Object;"));
                code.visitLabel(L5);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(-1)); // int: 0xffffffff  float:NaN
                code.visitFieldStmt(IPUT,0,1,new Field("Lorg/mortbay/util/ArrayQueue;","_growCapacity","I"));
                code.visitLabel(L6);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m002__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/util/ArrayQueue;","<init>",new String[]{ "I","I"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"initCapacity");
                ddv.visitParameterName(1,"growBy");
                DexLabel L0=new DexLabel();
                ddv.visitStartLocal(1,L0,"this","Lorg/mortbay/util/ArrayQueue;","Lorg/mortbay/util/ArrayQueue<TE;>;");
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(61,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(36,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(37,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(38,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(62,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(63,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(64,L6);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1},new Method("Ljava/util/AbstractList;","<init>",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitConstStmt(CONST_16,0, Integer.valueOf(64)); // int: 0x00000040  float:0.000000
                code.visitFieldStmt(IPUT,0,1,new Field("Lorg/mortbay/util/ArrayQueue;","DEFAULT_CAPACITY","I"));
                code.visitLabel(L2);
                code.visitConstStmt(CONST_16,0, Integer.valueOf(32)); // int: 0x00000020  float:0.000000
                code.visitFieldStmt(IPUT,0,1,new Field("Lorg/mortbay/util/ArrayQueue;","DEFAULT_GROWTH","I"));
                code.visitLabel(L3);
                code.visitFieldStmt(IPUT_OBJECT,1,1,new Field("Lorg/mortbay/util/ArrayQueue;","_lock","Ljava/lang/Object;"));
                code.visitLabel(L4);
                code.visitTypeStmt(NEW_ARRAY,0,2,"[Ljava/lang/Object;");
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/util/ArrayQueue;","_elements","[Ljava/lang/Object;"));
                code.visitLabel(L5);
                code.visitFieldStmt(IPUT,3,1,new Field("Lorg/mortbay/util/ArrayQueue;","_growCapacity","I"));
                code.visitLabel(L6);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m003__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/util/ArrayQueue;","<init>",new String[]{ "I","I","Ljava/lang/Object;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"initCapacity");
                ddv.visitParameterName(1,"growBy");
                ddv.visitParameterName(2,"lock");
                DexLabel L0=new DexLabel();
                ddv.visitStartLocal(1,L0,"this","Lorg/mortbay/util/ArrayQueue;","Lorg/mortbay/util/ArrayQueue<TE;>;");
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(68,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(36,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(37,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(38,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(69,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(70,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(71,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(72,L7);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1},new Method("Ljava/util/AbstractList;","<init>",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitConstStmt(CONST_16,0, Integer.valueOf(64)); // int: 0x00000040  float:0.000000
                code.visitFieldStmt(IPUT,0,1,new Field("Lorg/mortbay/util/ArrayQueue;","DEFAULT_CAPACITY","I"));
                code.visitLabel(L2);
                code.visitConstStmt(CONST_16,0, Integer.valueOf(32)); // int: 0x00000020  float:0.000000
                code.visitFieldStmt(IPUT,0,1,new Field("Lorg/mortbay/util/ArrayQueue;","DEFAULT_GROWTH","I"));
                code.visitLabel(L3);
                code.visitFieldStmt(IPUT_OBJECT,1,1,new Field("Lorg/mortbay/util/ArrayQueue;","_lock","Ljava/lang/Object;"));
                code.visitLabel(L4);
                code.visitTypeStmt(NEW_ARRAY,0,2,"[Ljava/lang/Object;");
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/util/ArrayQueue;","_elements","[Ljava/lang/Object;"));
                code.visitLabel(L5);
                code.visitFieldStmt(IPUT,3,1,new Field("Lorg/mortbay/util/ArrayQueue;","_growCapacity","I"));
                code.visitLabel(L6);
                code.visitFieldStmt(IPUT_OBJECT,4,1,new Field("Lorg/mortbay/util/ArrayQueue;","_lock","Ljava/lang/Object;"));
                code.visitLabel(L7);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m004_add(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/util/ArrayQueue;","add",new String[]{ "I","Ljava/lang/Object;"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Signature;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, "(ITE;)V");
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(11);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexLabel L3=new DexLabel();
                DexLabel L4=new DexLabel();
                code.visitTryCatch(L3,L4,new DexLabel[]{L2},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"index");
                DexLabel L5=new DexLabel();
                ddv.visitStartLocal(8,L5,"this","Lorg/mortbay/util/ArrayQueue;","Lorg/mortbay/util/ArrayQueue<TE;>;");
                ddv.visitStartLocal(10,L5,"element","Ljava/lang/Object;","TE;");
                ddv.visitPrologue(L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(288,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(290,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(291,L8);
                ddv.visitLineNumber(334,L2);
                ddv.visitLineNumber(293,L3);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(294,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(296,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(298,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(334,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(335,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(302,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(303,L15);
                ddv.visitStartLocal(0,L15,"i","I",null);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(304,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(306,L17);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(307,L18);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(308,L19);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(309,L20);
                DexLabel L21=new DexLabel();
                ddv.visitLineNumber(311,L21);
                DexLabel L22=new DexLabel();
                ddv.visitLineNumber(317,L22);
                DexLabel L23=new DexLabel();
                ddv.visitLineNumber(318,L23);
                DexLabel L24=new DexLabel();
                ddv.visitLineNumber(324,L24);
                DexLabel L25=new DexLabel();
                ddv.visitLineNumber(326,L25);
                DexLabel L26=new DexLabel();
                ddv.visitLineNumber(327,L26);
                DexLabel L27=new DexLabel();
                ddv.visitLineNumber(330,L27);
                DexLabel L28=new DexLabel();
                ddv.visitLineNumber(331,L28);
                code.visitLabel(L5);
                code.visitConstStmt(CONST_4,7, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitLabel(L6);
                code.visitFieldStmt(IGET_OBJECT,1,8,new Field("Lorg/mortbay/util/ArrayQueue;","_lock","Ljava/lang/Object;"));
                code.visitStmt1R(MONITOR_ENTER,1);
                code.visitLabel(L7);
                code.visitJumpStmt(IF_LTZ,9,-1,L8);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET,2,8,new Field("Lorg/mortbay/util/ArrayQueue;","_size","I"));
                code.visitJumpStmt(IF_LE,9,2,L3);
                code.visitLabel(L8);
                code.visitTypeStmt(NEW_INSTANCE,2,-1,"Ljava/lang/IndexOutOfBoundsException;");
                code.visitTypeStmt(NEW_INSTANCE,3,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 3},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,4,"!(0<");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,4},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,9},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "I"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitConstStmt(CONST_STRING,4,"<=");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,4},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitFieldStmt(IGET,4,8,new Field("Lorg/mortbay/util/ArrayQueue;","_size","I"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,4},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "I"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitConstStmt(CONST_STRING,4,")");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,4},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2,3},new Method("Ljava/lang/IndexOutOfBoundsException;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitStmt1R(THROW,2);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,2);
                code.visitStmt1R(MONITOR_EXIT,1);
                code.visitLabel(L1);
                code.visitStmt1R(THROW,2);
                code.visitLabel(L3);
                code.visitFieldStmt(IGET,2,8,new Field("Lorg/mortbay/util/ArrayQueue;","_size","I"));
                code.visitFieldStmt(IGET_OBJECT,3,8,new Field("Lorg/mortbay/util/ArrayQueue;","_elements","[Ljava/lang/Object;"));
                code.visitStmt2R(ARRAY_LENGTH,3,3);
                code.visitJumpStmt(IF_NE,2,3,L10);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8},new Method("Lorg/mortbay/util/ArrayQueue;","grow",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitJumpStmt(IF_NEZ,2,-1,L10);
                code.visitLabel(L9);
                code.visitTypeStmt(NEW_INSTANCE,2,-1,"Ljava/lang/IllegalStateException;");
                code.visitConstStmt(CONST_STRING,3,"Full");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2,3},new Method("Ljava/lang/IllegalStateException;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitStmt1R(THROW,2);
                code.visitLabel(L10);
                code.visitFieldStmt(IGET,2,8,new Field("Lorg/mortbay/util/ArrayQueue;","_size","I"));
                code.visitJumpStmt(IF_NE,9,2,L14);
                code.visitLabel(L11);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8,10},new Method("Lorg/mortbay/util/ArrayQueue;","add",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitLabel(L12);
                code.visitStmt1R(MONITOR_EXIT,1);
                code.visitLabel(L13);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L14);
                code.visitFieldStmt(IGET,2,8,new Field("Lorg/mortbay/util/ArrayQueue;","_nextE","I"));
                code.visitStmt3R(ADD_INT,0,2,9);
                code.visitLabel(L15);
                code.visitFieldStmt(IGET_OBJECT,2,8,new Field("Lorg/mortbay/util/ArrayQueue;","_elements","[Ljava/lang/Object;"));
                code.visitStmt2R(ARRAY_LENGTH,2,2);
                code.visitJumpStmt(IF_LT,0,2,L17);
                code.visitLabel(L16);
                code.visitFieldStmt(IGET_OBJECT,2,8,new Field("Lorg/mortbay/util/ArrayQueue;","_elements","[Ljava/lang/Object;"));
                code.visitStmt2R(ARRAY_LENGTH,2,2);
                code.visitStmt2R(SUB_INT_2ADDR,0,2);
                code.visitLabel(L17);
                code.visitFieldStmt(IGET,2,8,new Field("Lorg/mortbay/util/ArrayQueue;","_size","I"));
                code.visitStmt2R1N(ADD_INT_LIT8,2,2,1);
                code.visitFieldStmt(IPUT,2,8,new Field("Lorg/mortbay/util/ArrayQueue;","_size","I"));
                code.visitLabel(L18);
                code.visitFieldStmt(IGET,2,8,new Field("Lorg/mortbay/util/ArrayQueue;","_nextSlot","I"));
                code.visitStmt2R1N(ADD_INT_LIT8,2,2,1);
                code.visitFieldStmt(IPUT,2,8,new Field("Lorg/mortbay/util/ArrayQueue;","_nextSlot","I"));
                code.visitLabel(L19);
                code.visitFieldStmt(IGET,2,8,new Field("Lorg/mortbay/util/ArrayQueue;","_nextSlot","I"));
                code.visitFieldStmt(IGET_OBJECT,3,8,new Field("Lorg/mortbay/util/ArrayQueue;","_elements","[Ljava/lang/Object;"));
                code.visitStmt2R(ARRAY_LENGTH,3,3);
                code.visitJumpStmt(IF_NE,2,3,L21);
                code.visitLabel(L20);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT,2,8,new Field("Lorg/mortbay/util/ArrayQueue;","_nextSlot","I"));
                code.visitLabel(L21);
                code.visitFieldStmt(IGET,2,8,new Field("Lorg/mortbay/util/ArrayQueue;","_nextSlot","I"));
                code.visitJumpStmt(IF_GE,0,2,L24);
                code.visitLabel(L22);
                code.visitFieldStmt(IGET_OBJECT,2,8,new Field("Lorg/mortbay/util/ArrayQueue;","_elements","[Ljava/lang/Object;"));
                code.visitFieldStmt(IGET_OBJECT,3,8,new Field("Lorg/mortbay/util/ArrayQueue;","_elements","[Ljava/lang/Object;"));
                code.visitStmt2R1N(ADD_INT_LIT8,4,0,1);
                code.visitFieldStmt(IGET,5,8,new Field("Lorg/mortbay/util/ArrayQueue;","_nextSlot","I"));
                code.visitStmt2R(SUB_INT_2ADDR,5,0);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 2,0,3,4,5},new Method("Ljava/lang/System;","arraycopy",new String[]{ "Ljava/lang/Object;","I","Ljava/lang/Object;","I","I"},"V"));
                code.visitLabel(L23);
                code.visitFieldStmt(IGET_OBJECT,2,8,new Field("Lorg/mortbay/util/ArrayQueue;","_elements","[Ljava/lang/Object;"));
                code.visitStmt3R(APUT_OBJECT,10,2,0);
                code.visitJumpStmt(GOTO,-1,-1,L12);
                code.visitLabel(L24);
                code.visitFieldStmt(IGET,2,8,new Field("Lorg/mortbay/util/ArrayQueue;","_nextSlot","I"));
                code.visitJumpStmt(IF_LEZ,2,-1,L27);
                code.visitLabel(L25);
                code.visitFieldStmt(IGET_OBJECT,2,8,new Field("Lorg/mortbay/util/ArrayQueue;","_elements","[Ljava/lang/Object;"));
                code.visitConstStmt(CONST_4,3, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IGET_OBJECT,4,8,new Field("Lorg/mortbay/util/ArrayQueue;","_elements","[Ljava/lang/Object;"));
                code.visitConstStmt(CONST_4,5, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitFieldStmt(IGET,6,8,new Field("Lorg/mortbay/util/ArrayQueue;","_nextSlot","I"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 2,3,4,5,6},new Method("Ljava/lang/System;","arraycopy",new String[]{ "Ljava/lang/Object;","I","Ljava/lang/Object;","I","I"},"V"));
                code.visitLabel(L26);
                code.visitFieldStmt(IGET_OBJECT,2,8,new Field("Lorg/mortbay/util/ArrayQueue;","_elements","[Ljava/lang/Object;"));
                code.visitConstStmt(CONST_4,3, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IGET_OBJECT,4,8,new Field("Lorg/mortbay/util/ArrayQueue;","_elements","[Ljava/lang/Object;"));
                code.visitFieldStmt(IGET_OBJECT,5,8,new Field("Lorg/mortbay/util/ArrayQueue;","_elements","[Ljava/lang/Object;"));
                code.visitStmt2R(ARRAY_LENGTH,5,5);
                code.visitStmt2R(SUB_INT_2ADDR,5,7);
                code.visitStmt3R(AGET_OBJECT,4,4,5);
                code.visitStmt3R(APUT_OBJECT,4,2,3);
                code.visitLabel(L27);
                code.visitFieldStmt(IGET_OBJECT,2,8,new Field("Lorg/mortbay/util/ArrayQueue;","_elements","[Ljava/lang/Object;"));
                code.visitFieldStmt(IGET_OBJECT,3,8,new Field("Lorg/mortbay/util/ArrayQueue;","_elements","[Ljava/lang/Object;"));
                code.visitStmt2R1N(ADD_INT_LIT8,4,0,1);
                code.visitFieldStmt(IGET_OBJECT,5,8,new Field("Lorg/mortbay/util/ArrayQueue;","_elements","[Ljava/lang/Object;"));
                code.visitStmt2R(ARRAY_LENGTH,5,5);
                code.visitStmt2R(SUB_INT_2ADDR,5,0);
                code.visitStmt2R(SUB_INT_2ADDR,5,7);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 2,0,3,4,5},new Method("Ljava/lang/System;","arraycopy",new String[]{ "Ljava/lang/Object;","I","Ljava/lang/Object;","I","I"},"V"));
                code.visitLabel(L28);
                code.visitFieldStmt(IGET_OBJECT,2,8,new Field("Lorg/mortbay/util/ArrayQueue;","_elements","[Ljava/lang/Object;"));
                code.visitStmt3R(APUT_OBJECT,10,2,0);
                code.visitLabel(L4);
                code.visitJumpStmt(GOTO,-1,-1,L12);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m005_add(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/util/ArrayQueue;","add",new String[]{ "Ljava/lang/Object;"},"Z"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Signature;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, "(TE;)Z");
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitStartLocal(2,L0,"this","Lorg/mortbay/util/ArrayQueue;","Lorg/mortbay/util/ArrayQueue<TE;>;");
                ddv.visitStartLocal(3,L0,"e","Ljava/lang/Object;","TE;");
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(84,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(85,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(86,L2);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3},new Method("Lorg/mortbay/util/ArrayQueue;","offer",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_NEZ,0,-1,L2);
                code.visitLabel(L1);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/lang/IllegalStateException;");
                code.visitConstStmt(CONST_STRING,1,"Full");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1},new Method("Ljava/lang/IllegalStateException;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitStmt1R(THROW,0);
                code.visitLabel(L2);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m006_addUnsafe(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/util/ArrayQueue;","addUnsafe",new String[]{ "Ljava/lang/Object;"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Signature;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, "(TE;)V");
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitStartLocal(3,L0,"this","Lorg/mortbay/util/ArrayQueue;","Lorg/mortbay/util/ArrayQueue<TE;>;");
                ddv.visitStartLocal(4,L0,"e","Ljava/lang/Object;","TE;");
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(112,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(113,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(115,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(116,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(117,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(118,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(119,L6);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET,0,3,new Field("Lorg/mortbay/util/ArrayQueue;","_size","I"));
                code.visitFieldStmt(IGET_OBJECT,1,3,new Field("Lorg/mortbay/util/ArrayQueue;","_elements","[Ljava/lang/Object;"));
                code.visitStmt2R(ARRAY_LENGTH,1,1);
                code.visitJumpStmt(IF_NE,0,1,L2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Lorg/mortbay/util/ArrayQueue;","grow",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_NEZ,0,-1,L2);
                code.visitLabel(L1);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/lang/IllegalStateException;");
                code.visitConstStmt(CONST_STRING,1,"Full");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1},new Method("Ljava/lang/IllegalStateException;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitStmt1R(THROW,0);
                code.visitLabel(L2);
                code.visitFieldStmt(IGET,0,3,new Field("Lorg/mortbay/util/ArrayQueue;","_size","I"));
                code.visitStmt2R1N(ADD_INT_LIT8,0,0,1);
                code.visitFieldStmt(IPUT,0,3,new Field("Lorg/mortbay/util/ArrayQueue;","_size","I"));
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,0,3,new Field("Lorg/mortbay/util/ArrayQueue;","_elements","[Ljava/lang/Object;"));
                code.visitFieldStmt(IGET,1,3,new Field("Lorg/mortbay/util/ArrayQueue;","_nextSlot","I"));
                code.visitStmt2R1N(ADD_INT_LIT8,2,1,1);
                code.visitFieldStmt(IPUT,2,3,new Field("Lorg/mortbay/util/ArrayQueue;","_nextSlot","I"));
                code.visitStmt3R(APUT_OBJECT,4,0,1);
                code.visitLabel(L4);
                code.visitFieldStmt(IGET,0,3,new Field("Lorg/mortbay/util/ArrayQueue;","_nextSlot","I"));
                code.visitFieldStmt(IGET_OBJECT,1,3,new Field("Lorg/mortbay/util/ArrayQueue;","_elements","[Ljava/lang/Object;"));
                code.visitStmt2R(ARRAY_LENGTH,1,1);
                code.visitJumpStmt(IF_NE,0,1,L6);
                code.visitLabel(L5);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT,0,3,new Field("Lorg/mortbay/util/ArrayQueue;","_nextSlot","I"));
                code.visitLabel(L6);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m007_clear(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/util/ArrayQueue;","clear",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L3=new DexLabel();
                ddv.visitStartLocal(2,L3,"this","Lorg/mortbay/util/ArrayQueue;","Lorg/mortbay/util/ArrayQueue<TE;>;");
                ddv.visitPrologue(L3);
                ddv.visitLineNumber(179,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(181,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(182,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(183,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(184,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(185,L8);
                ddv.visitLineNumber(184,L2);
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/util/ArrayQueue;","_lock","Ljava/lang/Object;"));
                code.visitStmt1R(MONITOR_ENTER,0);
                code.visitLabel(L4);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT,1,2,new Field("Lorg/mortbay/util/ArrayQueue;","_size","I"));
                code.visitLabel(L5);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT,1,2,new Field("Lorg/mortbay/util/ArrayQueue;","_nextE","I"));
                code.visitLabel(L6);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT,1,2,new Field("Lorg/mortbay/util/ArrayQueue;","_nextSlot","I"));
                code.visitLabel(L7);
                code.visitStmt1R(MONITOR_EXIT,0);
                code.visitLabel(L8);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,1);
                code.visitStmt1R(MONITOR_EXIT,0);
                code.visitLabel(L1);
                code.visitStmt1R(THROW,1);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m008_element(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/util/ArrayQueue;","element",new String[]{ },"Ljava/lang/Object;"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Signature;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, "()TE;");
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexLabel L3=new DexLabel();
                DexLabel L4=new DexLabel();
                code.visitTryCatch(L3,L4,new DexLabel[]{L2},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L5=new DexLabel();
                ddv.visitStartLocal(3,L5,"this","Lorg/mortbay/util/ArrayQueue;","Lorg/mortbay/util/ArrayQueue<TE;>;");
                ddv.visitPrologue(L5);
                ddv.visitLineNumber(124,L5);
                ddv.visitLineNumber(126,L0);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(127,L6);
                ddv.visitLineNumber(129,L2);
                ddv.visitLineNumber(128,L3);
                code.visitLabel(L5);
                code.visitFieldStmt(IGET_OBJECT,0,3,new Field("Lorg/mortbay/util/ArrayQueue;","_lock","Ljava/lang/Object;"));
                code.visitStmt1R(MONITOR_ENTER,0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET,1,3,new Field("Lorg/mortbay/util/ArrayQueue;","_size","I"));
                code.visitJumpStmt(IF_NEZ,1,-1,L3);
                code.visitLabel(L6);
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Ljava/util/NoSuchElementException;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1},new Method("Ljava/util/NoSuchElementException;","<init>",new String[]{ },"V"));
                code.visitStmt1R(THROW,1);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,1);
                code.visitStmt1R(MONITOR_EXIT,0);
                code.visitLabel(L1);
                code.visitStmt1R(THROW,1);
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,1,3,new Field("Lorg/mortbay/util/ArrayQueue;","_elements","[Ljava/lang/Object;"));
                code.visitFieldStmt(IGET,2,3,new Field("Lorg/mortbay/util/ArrayQueue;","_nextE","I"));
                code.visitStmt3R(AGET_OBJECT,1,1,2);
                code.visitStmt1R(MONITOR_EXIT,0);
                code.visitLabel(L4);
                code.visitStmt1R(RETURN_OBJECT,1);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m009_get(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/util/ArrayQueue;","get",new String[]{ "I"},"Ljava/lang/Object;"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Signature;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, "(I)TE;");
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(7);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexLabel L3=new DexLabel();
                DexLabel L4=new DexLabel();
                code.visitTryCatch(L3,L4,new DexLabel[]{L2},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"index");
                DexLabel L5=new DexLabel();
                ddv.visitStartLocal(5,L5,"this","Lorg/mortbay/util/ArrayQueue;","Lorg/mortbay/util/ArrayQueue<TE;>;");
                ddv.visitPrologue(L5);
                ddv.visitLineNumber(208,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(210,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(211,L7);
                ddv.visitLineNumber(214,L2);
                ddv.visitLineNumber(212,L3);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(213,L8);
                ddv.visitStartLocal(0,L8,"i","I",null);
                code.visitLabel(L5);
                code.visitFieldStmt(IGET_OBJECT,1,5,new Field("Lorg/mortbay/util/ArrayQueue;","_lock","Ljava/lang/Object;"));
                code.visitStmt1R(MONITOR_ENTER,1);
                code.visitLabel(L6);
                code.visitJumpStmt(IF_LTZ,6,-1,L7);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET,2,5,new Field("Lorg/mortbay/util/ArrayQueue;","_size","I"));
                code.visitJumpStmt(IF_LT,6,2,L3);
                code.visitLabel(L7);
                code.visitTypeStmt(NEW_INSTANCE,2,-1,"Ljava/lang/IndexOutOfBoundsException;");
                code.visitTypeStmt(NEW_INSTANCE,3,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 3},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,4,"!(0<");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,4},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,6},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "I"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitConstStmt(CONST_STRING,4,"<=");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,4},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitFieldStmt(IGET,4,5,new Field("Lorg/mortbay/util/ArrayQueue;","_size","I"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,4},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "I"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitConstStmt(CONST_STRING,4,")");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,4},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2,3},new Method("Ljava/lang/IndexOutOfBoundsException;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitStmt1R(THROW,2);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,2);
                code.visitStmt1R(MONITOR_EXIT,1);
                code.visitLabel(L1);
                code.visitStmt1R(THROW,2);
                code.visitLabel(L3);
                code.visitFieldStmt(IGET,2,5,new Field("Lorg/mortbay/util/ArrayQueue;","_nextE","I"));
                code.visitStmt2R(ADD_INT_2ADDR,2,6);
                code.visitFieldStmt(IGET_OBJECT,3,5,new Field("Lorg/mortbay/util/ArrayQueue;","_elements","[Ljava/lang/Object;"));
                code.visitStmt2R(ARRAY_LENGTH,3,3);
                code.visitStmt3R(REM_INT,0,2,3);
                code.visitLabel(L8);
                code.visitFieldStmt(IGET_OBJECT,2,5,new Field("Lorg/mortbay/util/ArrayQueue;","_elements","[Ljava/lang/Object;"));
                code.visitStmt3R(AGET_OBJECT,2,2,0);
                code.visitStmt1R(MONITOR_EXIT,1);
                code.visitLabel(L4);
                code.visitStmt1R(RETURN_OBJECT,2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m010_getCapacity(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/util/ArrayQueue;","getCapacity",new String[]{ },"I"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitStartLocal(1,L0,"this","Lorg/mortbay/util/ArrayQueue;","Lorg/mortbay/util/ArrayQueue<TE;>;");
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(77,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/util/ArrayQueue;","_elements","[Ljava/lang/Object;"));
                code.visitStmt2R(ARRAY_LENGTH,0,0);
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m011_getUnsafe(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/util/ArrayQueue;","getUnsafe",new String[]{ "I"},"Ljava/lang/Object;"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Signature;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, "(I)TE;");
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"index");
                DexLabel L0=new DexLabel();
                ddv.visitStartLocal(3,L0,"this","Lorg/mortbay/util/ArrayQueue;","Lorg/mortbay/util/ArrayQueue<TE;>;");
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(224,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(225,L1);
                ddv.visitStartLocal(0,L1,"i","I",null);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET,1,3,new Field("Lorg/mortbay/util/ArrayQueue;","_nextE","I"));
                code.visitStmt2R(ADD_INT_2ADDR,1,4);
                code.visitFieldStmt(IGET_OBJECT,2,3,new Field("Lorg/mortbay/util/ArrayQueue;","_elements","[Ljava/lang/Object;"));
                code.visitStmt2R(ARRAY_LENGTH,2,2);
                code.visitStmt3R(REM_INT,0,1,2);
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,1,3,new Field("Lorg/mortbay/util/ArrayQueue;","_elements","[Ljava/lang/Object;"));
                code.visitStmt3R(AGET_OBJECT,1,1,0);
                code.visitStmt1R(RETURN_OBJECT,1);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m012_grow(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Lorg/mortbay/util/ArrayQueue;","grow",new String[]{ },"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(6);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitStartLocal(5,L0,"this","Lorg/mortbay/util/ArrayQueue;","Lorg/mortbay/util/ArrayQueue<TE;>;");
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(339,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(353,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(342,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(344,L4);
                ddv.visitStartLocal(0,L4,"elements","[Ljava/lang/Object;",null);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(345,L5);
                ddv.visitStartLocal(1,L5,"split","I",null);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(346,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(347,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(348,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(350,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(351,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(352,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(353,L12);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,4, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L1);
                code.visitFieldStmt(IGET,2,5,new Field("Lorg/mortbay/util/ArrayQueue;","_growCapacity","I"));
                code.visitJumpStmt(IF_GTZ,2,-1,L3);
                code.visitStmt2R(MOVE,2,4);
                code.visitLabel(L2);
                code.visitStmt1R(RETURN,2);
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,2,5,new Field("Lorg/mortbay/util/ArrayQueue;","_elements","[Ljava/lang/Object;"));
                code.visitStmt2R(ARRAY_LENGTH,2,2);
                code.visitFieldStmt(IGET,3,5,new Field("Lorg/mortbay/util/ArrayQueue;","_growCapacity","I"));
                code.visitStmt2R(ADD_INT_2ADDR,2,3);
                code.visitTypeStmt(NEW_ARRAY,0,2,"[Ljava/lang/Object;");
                code.visitLabel(L4);
                code.visitFieldStmt(IGET_OBJECT,2,5,new Field("Lorg/mortbay/util/ArrayQueue;","_elements","[Ljava/lang/Object;"));
                code.visitStmt2R(ARRAY_LENGTH,2,2);
                code.visitFieldStmt(IGET,3,5,new Field("Lorg/mortbay/util/ArrayQueue;","_nextE","I"));
                code.visitStmt3R(SUB_INT,1,2,3);
                code.visitLabel(L5);
                code.visitJumpStmt(IF_LEZ,1,-1,L7);
                code.visitLabel(L6);
                code.visitFieldStmt(IGET_OBJECT,2,5,new Field("Lorg/mortbay/util/ArrayQueue;","_elements","[Ljava/lang/Object;"));
                code.visitFieldStmt(IGET,3,5,new Field("Lorg/mortbay/util/ArrayQueue;","_nextE","I"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 2,3,0,4,1},new Method("Ljava/lang/System;","arraycopy",new String[]{ "Ljava/lang/Object;","I","Ljava/lang/Object;","I","I"},"V"));
                code.visitLabel(L7);
                code.visitFieldStmt(IGET,2,5,new Field("Lorg/mortbay/util/ArrayQueue;","_nextE","I"));
                code.visitJumpStmt(IF_EQZ,2,-1,L9);
                code.visitLabel(L8);
                code.visitFieldStmt(IGET_OBJECT,2,5,new Field("Lorg/mortbay/util/ArrayQueue;","_elements","[Ljava/lang/Object;"));
                code.visitFieldStmt(IGET,3,5,new Field("Lorg/mortbay/util/ArrayQueue;","_nextSlot","I"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 2,4,0,1,3},new Method("Ljava/lang/System;","arraycopy",new String[]{ "Ljava/lang/Object;","I","Ljava/lang/Object;","I","I"},"V"));
                code.visitLabel(L9);
                code.visitFieldStmt(IPUT_OBJECT,0,5,new Field("Lorg/mortbay/util/ArrayQueue;","_elements","[Ljava/lang/Object;"));
                code.visitLabel(L10);
                code.visitFieldStmt(IPUT,4,5,new Field("Lorg/mortbay/util/ArrayQueue;","_nextE","I"));
                code.visitLabel(L11);
                code.visitFieldStmt(IGET,2,5,new Field("Lorg/mortbay/util/ArrayQueue;","_size","I"));
                code.visitFieldStmt(IPUT,2,5,new Field("Lorg/mortbay/util/ArrayQueue;","_nextSlot","I"));
                code.visitLabel(L12);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m013_isEmpty(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/util/ArrayQueue;","isEmpty",new String[]{ },"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L3=new DexLabel();
                ddv.visitStartLocal(2,L3,"this","Lorg/mortbay/util/ArrayQueue;","Lorg/mortbay/util/ArrayQueue<TE;>;");
                ddv.visitPrologue(L3);
                ddv.visitLineNumber(190,L3);
                ddv.visitLineNumber(192,L0);
                ddv.visitLineNumber(193,L2);
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/util/ArrayQueue;","_lock","Ljava/lang/Object;"));
                code.visitStmt1R(MONITOR_ENTER,0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET,1,2,new Field("Lorg/mortbay/util/ArrayQueue;","_size","I"));
                DexLabel L4=new DexLabel();
                code.visitJumpStmt(IF_NEZ,1,-1,L4);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                DexLabel L5=new DexLabel();
                code.visitLabel(L5);
                code.visitStmt1R(MONITOR_EXIT,0);
                code.visitStmt1R(RETURN,1);
                code.visitLabel(L4);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L5);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,1);
                code.visitStmt1R(MONITOR_EXIT,0);
                code.visitLabel(L1);
                code.visitStmt1R(THROW,1);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m014_offer(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/util/ArrayQueue;","offer",new String[]{ "Ljava/lang/Object;"},"Z"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Signature;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, "(TE;)Z");
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(6);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L3=new DexLabel();
                ddv.visitStartLocal(4,L3,"this","Lorg/mortbay/util/ArrayQueue;","Lorg/mortbay/util/ArrayQueue<TE;>;");
                ddv.visitStartLocal(5,L3,"e","Ljava/lang/Object;","TE;");
                ddv.visitPrologue(L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(92,L4);
                ddv.visitLineNumber(94,L0);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(95,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(102,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(97,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(98,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(99,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(100,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(101,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(102,L12);
                ddv.visitLineNumber(101,L2);
                code.visitLabel(L3);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L4);
                code.visitFieldStmt(IGET_OBJECT,0,4,new Field("Lorg/mortbay/util/ArrayQueue;","_lock","Ljava/lang/Object;"));
                code.visitStmt1R(MONITOR_ENTER,0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET,1,4,new Field("Lorg/mortbay/util/ArrayQueue;","_size","I"));
                code.visitFieldStmt(IGET_OBJECT,2,4,new Field("Lorg/mortbay/util/ArrayQueue;","_elements","[Ljava/lang/Object;"));
                code.visitStmt2R(ARRAY_LENGTH,2,2);
                code.visitJumpStmt(IF_NE,1,2,L7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Lorg/mortbay/util/ArrayQueue;","grow",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitJumpStmt(IF_NEZ,1,-1,L7);
                code.visitLabel(L5);
                code.visitStmt1R(MONITOR_EXIT,0);
                code.visitStmt2R(MOVE,0,3);
                code.visitLabel(L6);
                code.visitStmt1R(RETURN,0);
                code.visitLabel(L7);
                code.visitFieldStmt(IGET,1,4,new Field("Lorg/mortbay/util/ArrayQueue;","_size","I"));
                code.visitStmt2R1N(ADD_INT_LIT8,1,1,1);
                code.visitFieldStmt(IPUT,1,4,new Field("Lorg/mortbay/util/ArrayQueue;","_size","I"));
                code.visitLabel(L8);
                code.visitFieldStmt(IGET_OBJECT,1,4,new Field("Lorg/mortbay/util/ArrayQueue;","_elements","[Ljava/lang/Object;"));
                code.visitFieldStmt(IGET,2,4,new Field("Lorg/mortbay/util/ArrayQueue;","_nextSlot","I"));
                code.visitStmt2R1N(ADD_INT_LIT8,3,2,1);
                code.visitFieldStmt(IPUT,3,4,new Field("Lorg/mortbay/util/ArrayQueue;","_nextSlot","I"));
                code.visitStmt3R(APUT_OBJECT,5,1,2);
                code.visitLabel(L9);
                code.visitFieldStmt(IGET,1,4,new Field("Lorg/mortbay/util/ArrayQueue;","_nextSlot","I"));
                code.visitFieldStmt(IGET_OBJECT,2,4,new Field("Lorg/mortbay/util/ArrayQueue;","_elements","[Ljava/lang/Object;"));
                code.visitStmt2R(ARRAY_LENGTH,2,2);
                code.visitJumpStmt(IF_NE,1,2,L11);
                code.visitLabel(L10);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT,1,4,new Field("Lorg/mortbay/util/ArrayQueue;","_nextSlot","I"));
                code.visitLabel(L11);
                code.visitStmt1R(MONITOR_EXIT,0);
                code.visitLabel(L12);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L6);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,1);
                code.visitStmt1R(MONITOR_EXIT,0);
                code.visitLabel(L1);
                code.visitStmt1R(THROW,1);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m015_peek(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/util/ArrayQueue;","peek",new String[]{ },"Ljava/lang/Object;"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Signature;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, "()TE;");
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L3=new DexLabel();
                ddv.visitStartLocal(3,L3,"this","Lorg/mortbay/util/ArrayQueue;","Lorg/mortbay/util/ArrayQueue<TE;>;");
                ddv.visitPrologue(L3);
                ddv.visitLineNumber(135,L3);
                ddv.visitLineNumber(137,L0);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(138,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(139,L5);
                ddv.visitLineNumber(140,L2);
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,0,3,new Field("Lorg/mortbay/util/ArrayQueue;","_lock","Ljava/lang/Object;"));
                code.visitStmt1R(MONITOR_ENTER,0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET,1,3,new Field("Lorg/mortbay/util/ArrayQueue;","_size","I"));
                DexLabel L6=new DexLabel();
                code.visitJumpStmt(IF_NEZ,1,-1,L6);
                code.visitLabel(L4);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitStmt1R(MONITOR_EXIT,0);
                code.visitStmt2R(MOVE_OBJECT,0,1);
                code.visitLabel(L5);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitLabel(L6);
                code.visitFieldStmt(IGET_OBJECT,1,3,new Field("Lorg/mortbay/util/ArrayQueue;","_elements","[Ljava/lang/Object;"));
                code.visitFieldStmt(IGET,2,3,new Field("Lorg/mortbay/util/ArrayQueue;","_nextE","I"));
                code.visitStmt3R(AGET_OBJECT,1,1,2);
                code.visitStmt1R(MONITOR_EXIT,0);
                code.visitStmt2R(MOVE_OBJECT,0,1);
                code.visitJumpStmt(GOTO,-1,-1,L5);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,1);
                code.visitStmt1R(MONITOR_EXIT,0);
                code.visitLabel(L1);
                code.visitStmt1R(THROW,1);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m016_poll(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/util/ArrayQueue;","poll",new String[]{ },"Ljava/lang/Object;"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Signature;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, "()TE;");
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(6);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L3=new DexLabel();
                ddv.visitStartLocal(5,L3,"this","Lorg/mortbay/util/ArrayQueue;","Lorg/mortbay/util/ArrayQueue<TE;>;");
                ddv.visitPrologue(L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(146,L4);
                ddv.visitLineNumber(148,L0);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(149,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(155,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(150,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(151,L8);
                ddv.visitStartLocal(0,L8,"e","Ljava/lang/Object;","TE;");
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(152,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(153,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(154,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(155,L12);
                ddv.visitLineNumber(156,L2);
                ddv.visitEndLocal(0,L2);
                code.visitLabel(L3);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L4);
                code.visitFieldStmt(IGET_OBJECT,1,5,new Field("Lorg/mortbay/util/ArrayQueue;","_lock","Ljava/lang/Object;"));
                code.visitStmt1R(MONITOR_ENTER,1);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET,2,5,new Field("Lorg/mortbay/util/ArrayQueue;","_size","I"));
                code.visitJumpStmt(IF_NEZ,2,-1,L7);
                code.visitLabel(L5);
                code.visitStmt1R(MONITOR_EXIT,1);
                code.visitStmt2R(MOVE_OBJECT,1,3);
                code.visitLabel(L6);
                code.visitStmt1R(RETURN_OBJECT,1);
                code.visitLabel(L7);
                code.visitFieldStmt(IGET_OBJECT,2,5,new Field("Lorg/mortbay/util/ArrayQueue;","_elements","[Ljava/lang/Object;"));
                code.visitFieldStmt(IGET,3,5,new Field("Lorg/mortbay/util/ArrayQueue;","_nextE","I"));
                code.visitStmt3R(AGET_OBJECT,0,2,3);
                code.visitLabel(L8);
                code.visitFieldStmt(IGET_OBJECT,2,5,new Field("Lorg/mortbay/util/ArrayQueue;","_elements","[Ljava/lang/Object;"));
                code.visitFieldStmt(IGET,3,5,new Field("Lorg/mortbay/util/ArrayQueue;","_nextE","I"));
                code.visitConstStmt(CONST_4,4, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitStmt3R(APUT_OBJECT,4,2,3);
                code.visitLabel(L9);
                code.visitFieldStmt(IGET,2,5,new Field("Lorg/mortbay/util/ArrayQueue;","_size","I"));
                code.visitConstStmt(CONST_4,3, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitStmt2R(SUB_INT_2ADDR,2,3);
                code.visitFieldStmt(IPUT,2,5,new Field("Lorg/mortbay/util/ArrayQueue;","_size","I"));
                code.visitLabel(L10);
                code.visitFieldStmt(IGET,2,5,new Field("Lorg/mortbay/util/ArrayQueue;","_nextE","I"));
                code.visitStmt2R1N(ADD_INT_LIT8,2,2,1);
                code.visitFieldStmt(IPUT,2,5,new Field("Lorg/mortbay/util/ArrayQueue;","_nextE","I"));
                code.visitFieldStmt(IGET_OBJECT,3,5,new Field("Lorg/mortbay/util/ArrayQueue;","_elements","[Ljava/lang/Object;"));
                code.visitStmt2R(ARRAY_LENGTH,3,3);
                code.visitJumpStmt(IF_NE,2,3,L12);
                code.visitLabel(L11);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT,2,5,new Field("Lorg/mortbay/util/ArrayQueue;","_nextE","I"));
                code.visitLabel(L12);
                code.visitStmt1R(MONITOR_EXIT,1);
                code.visitStmt2R(MOVE_OBJECT,1,0);
                code.visitJumpStmt(GOTO,-1,-1,L6);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,2);
                code.visitStmt1R(MONITOR_EXIT,1);
                code.visitLabel(L1);
                code.visitStmt1R(THROW,2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m017_remove(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/util/ArrayQueue;","remove",new String[]{ },"Ljava/lang/Object;"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Signature;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, "()TE;");
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(6);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexLabel L3=new DexLabel();
                DexLabel L4=new DexLabel();
                code.visitTryCatch(L3,L4,new DexLabel[]{L2},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L5=new DexLabel();
                ddv.visitStartLocal(5,L5,"this","Lorg/mortbay/util/ArrayQueue;","Lorg/mortbay/util/ArrayQueue<TE;>;");
                ddv.visitPrologue(L5);
                ddv.visitLineNumber(162,L5);
                ddv.visitLineNumber(164,L0);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(165,L6);
                ddv.visitLineNumber(172,L2);
                ddv.visitLineNumber(166,L3);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(167,L7);
                ddv.visitStartLocal(0,L7,"e","Ljava/lang/Object;","TE;");
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(168,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(169,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(170,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(171,L11);
                code.visitLabel(L5);
                code.visitFieldStmt(IGET_OBJECT,1,5,new Field("Lorg/mortbay/util/ArrayQueue;","_lock","Ljava/lang/Object;"));
                code.visitStmt1R(MONITOR_ENTER,1);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET,2,5,new Field("Lorg/mortbay/util/ArrayQueue;","_size","I"));
                code.visitJumpStmt(IF_NEZ,2,-1,L3);
                code.visitLabel(L6);
                code.visitTypeStmt(NEW_INSTANCE,2,-1,"Ljava/util/NoSuchElementException;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2},new Method("Ljava/util/NoSuchElementException;","<init>",new String[]{ },"V"));
                code.visitStmt1R(THROW,2);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,2);
                code.visitStmt1R(MONITOR_EXIT,1);
                code.visitLabel(L1);
                code.visitStmt1R(THROW,2);
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,2,5,new Field("Lorg/mortbay/util/ArrayQueue;","_elements","[Ljava/lang/Object;"));
                code.visitFieldStmt(IGET,3,5,new Field("Lorg/mortbay/util/ArrayQueue;","_nextE","I"));
                code.visitStmt3R(AGET_OBJECT,0,2,3);
                code.visitLabel(L7);
                code.visitFieldStmt(IGET_OBJECT,2,5,new Field("Lorg/mortbay/util/ArrayQueue;","_elements","[Ljava/lang/Object;"));
                code.visitFieldStmt(IGET,3,5,new Field("Lorg/mortbay/util/ArrayQueue;","_nextE","I"));
                code.visitConstStmt(CONST_4,4, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitStmt3R(APUT_OBJECT,4,2,3);
                code.visitLabel(L8);
                code.visitFieldStmt(IGET,2,5,new Field("Lorg/mortbay/util/ArrayQueue;","_size","I"));
                code.visitConstStmt(CONST_4,3, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitStmt2R(SUB_INT_2ADDR,2,3);
                code.visitFieldStmt(IPUT,2,5,new Field("Lorg/mortbay/util/ArrayQueue;","_size","I"));
                code.visitLabel(L9);
                code.visitFieldStmt(IGET,2,5,new Field("Lorg/mortbay/util/ArrayQueue;","_nextE","I"));
                code.visitStmt2R1N(ADD_INT_LIT8,2,2,1);
                code.visitFieldStmt(IPUT,2,5,new Field("Lorg/mortbay/util/ArrayQueue;","_nextE","I"));
                code.visitFieldStmt(IGET_OBJECT,3,5,new Field("Lorg/mortbay/util/ArrayQueue;","_elements","[Ljava/lang/Object;"));
                code.visitStmt2R(ARRAY_LENGTH,3,3);
                code.visitJumpStmt(IF_NE,2,3,L11);
                code.visitLabel(L10);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT,2,5,new Field("Lorg/mortbay/util/ArrayQueue;","_nextE","I"));
                code.visitLabel(L11);
                code.visitStmt1R(MONITOR_EXIT,1);
                code.visitLabel(L4);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m018_remove(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/util/ArrayQueue;","remove",new String[]{ "I"},"Ljava/lang/Object;"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Signature;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, "(I)TE;");
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(11);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexLabel L3=new DexLabel();
                DexLabel L4=new DexLabel();
                code.visitTryCatch(L3,L4,new DexLabel[]{L2},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"index");
                DexLabel L5=new DexLabel();
                ddv.visitStartLocal(9,L5,"this","Lorg/mortbay/util/ArrayQueue;","Lorg/mortbay/util/ArrayQueue<TE;>;");
                ddv.visitPrologue(L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(231,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(233,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(234,L8);
                ddv.visitLineNumber(265,L2);
                ddv.visitLineNumber(236,L3);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(237,L9);
                ddv.visitStartLocal(0,L9,"i","I",null);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(239,L10);
                ddv.visitStartLocal(1,L10,"old","Ljava/lang/Object;","TE;");
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(243,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(244,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(245,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(264,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(251,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(252,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(254,L17);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(255,L18);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(256,L19);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(261,L20);
                DexLabel L21=new DexLabel();
                ddv.visitLineNumber(259,L21);
                code.visitLabel(L5);
                code.visitConstStmt(CONST_4,8, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitLabel(L6);
                code.visitFieldStmt(IGET_OBJECT,2,9,new Field("Lorg/mortbay/util/ArrayQueue;","_lock","Ljava/lang/Object;"));
                code.visitStmt1R(MONITOR_ENTER,2);
                code.visitLabel(L7);
                code.visitJumpStmt(IF_LTZ,10,-1,L8);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET,3,9,new Field("Lorg/mortbay/util/ArrayQueue;","_size","I"));
                code.visitJumpStmt(IF_LT,10,3,L3);
                code.visitLabel(L8);
                code.visitTypeStmt(NEW_INSTANCE,3,-1,"Ljava/lang/IndexOutOfBoundsException;");
                code.visitTypeStmt(NEW_INSTANCE,4,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 4},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,5,"!(0<");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,5},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,10},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "I"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitConstStmt(CONST_STRING,5,"<=");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,5},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitFieldStmt(IGET,5,9,new Field("Lorg/mortbay/util/ArrayQueue;","_size","I"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,5},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "I"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitConstStmt(CONST_STRING,5,")");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,5},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 3,4},new Method("Ljava/lang/IndexOutOfBoundsException;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitStmt1R(THROW,3);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,3);
                code.visitStmt1R(MONITOR_EXIT,2);
                code.visitLabel(L1);
                code.visitStmt1R(THROW,3);
                code.visitLabel(L3);
                code.visitFieldStmt(IGET,3,9,new Field("Lorg/mortbay/util/ArrayQueue;","_nextE","I"));
                code.visitStmt2R(ADD_INT_2ADDR,3,10);
                code.visitFieldStmt(IGET_OBJECT,4,9,new Field("Lorg/mortbay/util/ArrayQueue;","_elements","[Ljava/lang/Object;"));
                code.visitStmt2R(ARRAY_LENGTH,4,4);
                code.visitStmt3R(REM_INT,0,3,4);
                code.visitLabel(L9);
                code.visitFieldStmt(IGET_OBJECT,3,9,new Field("Lorg/mortbay/util/ArrayQueue;","_elements","[Ljava/lang/Object;"));
                code.visitStmt3R(AGET_OBJECT,1,3,0);
                code.visitLabel(L10);
                code.visitFieldStmt(IGET,3,9,new Field("Lorg/mortbay/util/ArrayQueue;","_nextSlot","I"));
                code.visitJumpStmt(IF_GE,0,3,L15);
                code.visitLabel(L11);
                code.visitFieldStmt(IGET_OBJECT,3,9,new Field("Lorg/mortbay/util/ArrayQueue;","_elements","[Ljava/lang/Object;"));
                code.visitStmt2R1N(ADD_INT_LIT8,4,0,1);
                code.visitFieldStmt(IGET_OBJECT,5,9,new Field("Lorg/mortbay/util/ArrayQueue;","_elements","[Ljava/lang/Object;"));
                code.visitFieldStmt(IGET,6,9,new Field("Lorg/mortbay/util/ArrayQueue;","_nextSlot","I"));
                code.visitStmt2R(SUB_INT_2ADDR,6,0);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 3,4,5,0,6},new Method("Ljava/lang/System;","arraycopy",new String[]{ "Ljava/lang/Object;","I","Ljava/lang/Object;","I","I"},"V"));
                code.visitLabel(L12);
                code.visitFieldStmt(IGET,3,9,new Field("Lorg/mortbay/util/ArrayQueue;","_nextSlot","I"));
                code.visitStmt2R(SUB_INT_2ADDR,3,8);
                code.visitFieldStmt(IPUT,3,9,new Field("Lorg/mortbay/util/ArrayQueue;","_nextSlot","I"));
                code.visitLabel(L13);
                code.visitFieldStmt(IGET,3,9,new Field("Lorg/mortbay/util/ArrayQueue;","_size","I"));
                code.visitStmt2R(SUB_INT_2ADDR,3,8);
                code.visitFieldStmt(IPUT,3,9,new Field("Lorg/mortbay/util/ArrayQueue;","_size","I"));
                code.visitLabel(L14);
                code.visitStmt1R(MONITOR_EXIT,2);
                code.visitStmt1R(RETURN_OBJECT,1);
                code.visitLabel(L15);
                code.visitFieldStmt(IGET_OBJECT,3,9,new Field("Lorg/mortbay/util/ArrayQueue;","_elements","[Ljava/lang/Object;"));
                code.visitStmt2R1N(ADD_INT_LIT8,4,0,1);
                code.visitFieldStmt(IGET_OBJECT,5,9,new Field("Lorg/mortbay/util/ArrayQueue;","_elements","[Ljava/lang/Object;"));
                code.visitFieldStmt(IGET_OBJECT,6,9,new Field("Lorg/mortbay/util/ArrayQueue;","_elements","[Ljava/lang/Object;"));
                code.visitStmt2R(ARRAY_LENGTH,6,6);
                code.visitStmt2R(SUB_INT_2ADDR,6,0);
                code.visitStmt2R(SUB_INT_2ADDR,6,8);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 3,4,5,0,6},new Method("Ljava/lang/System;","arraycopy",new String[]{ "Ljava/lang/Object;","I","Ljava/lang/Object;","I","I"},"V"));
                code.visitLabel(L16);
                code.visitFieldStmt(IGET,3,9,new Field("Lorg/mortbay/util/ArrayQueue;","_nextSlot","I"));
                code.visitJumpStmt(IF_LEZ,3,-1,L21);
                code.visitLabel(L17);
                code.visitFieldStmt(IGET_OBJECT,3,9,new Field("Lorg/mortbay/util/ArrayQueue;","_elements","[Ljava/lang/Object;"));
                code.visitFieldStmt(IGET_OBJECT,4,9,new Field("Lorg/mortbay/util/ArrayQueue;","_elements","[Ljava/lang/Object;"));
                code.visitStmt2R(ARRAY_LENGTH,4,4);
                code.visitStmt2R(SUB_INT_2ADDR,4,8);
                code.visitFieldStmt(IGET_OBJECT,5,9,new Field("Lorg/mortbay/util/ArrayQueue;","_elements","[Ljava/lang/Object;"));
                code.visitConstStmt(CONST_4,6, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitStmt3R(AGET_OBJECT,5,5,6);
                code.visitStmt3R(APUT_OBJECT,5,3,4);
                code.visitLabel(L18);
                code.visitFieldStmt(IGET_OBJECT,3,9,new Field("Lorg/mortbay/util/ArrayQueue;","_elements","[Ljava/lang/Object;"));
                code.visitConstStmt(CONST_4,4, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitFieldStmt(IGET_OBJECT,5,9,new Field("Lorg/mortbay/util/ArrayQueue;","_elements","[Ljava/lang/Object;"));
                code.visitConstStmt(CONST_4,6, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IGET,7,9,new Field("Lorg/mortbay/util/ArrayQueue;","_nextSlot","I"));
                code.visitStmt2R(SUB_INT_2ADDR,7,8);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 3,4,5,6,7},new Method("Ljava/lang/System;","arraycopy",new String[]{ "Ljava/lang/Object;","I","Ljava/lang/Object;","I","I"},"V"));
                code.visitLabel(L19);
                code.visitFieldStmt(IGET,3,9,new Field("Lorg/mortbay/util/ArrayQueue;","_nextSlot","I"));
                code.visitStmt2R(SUB_INT_2ADDR,3,8);
                code.visitFieldStmt(IPUT,3,9,new Field("Lorg/mortbay/util/ArrayQueue;","_nextSlot","I"));
                code.visitLabel(L20);
                code.visitFieldStmt(IGET,3,9,new Field("Lorg/mortbay/util/ArrayQueue;","_size","I"));
                code.visitStmt2R(SUB_INT_2ADDR,3,8);
                code.visitFieldStmt(IPUT,3,9,new Field("Lorg/mortbay/util/ArrayQueue;","_size","I"));
                code.visitJumpStmt(GOTO,-1,-1,L14);
                code.visitLabel(L21);
                code.visitFieldStmt(IGET_OBJECT,3,9,new Field("Lorg/mortbay/util/ArrayQueue;","_elements","[Ljava/lang/Object;"));
                code.visitStmt2R(ARRAY_LENGTH,3,3);
                code.visitStmt2R(SUB_INT_2ADDR,3,8);
                code.visitFieldStmt(IPUT,3,9,new Field("Lorg/mortbay/util/ArrayQueue;","_nextSlot","I"));
                code.visitLabel(L4);
                code.visitJumpStmt(GOTO,-1,-1,L20);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m019_set(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/util/ArrayQueue;","set",new String[]{ "I","Ljava/lang/Object;"},"Ljava/lang/Object;"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Signature;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, "(ITE;)TE;");
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(9);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexLabel L3=new DexLabel();
                DexLabel L4=new DexLabel();
                code.visitTryCatch(L3,L4,new DexLabel[]{L2},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"index");
                DexLabel L5=new DexLabel();
                ddv.visitStartLocal(6,L5,"this","Lorg/mortbay/util/ArrayQueue;","Lorg/mortbay/util/ArrayQueue<TE;>;");
                ddv.visitStartLocal(8,L5,"element","Ljava/lang/Object;","TE;");
                ddv.visitPrologue(L5);
                ddv.visitLineNumber(271,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(273,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(274,L7);
                ddv.visitLineNumber(282,L2);
                ddv.visitLineNumber(276,L3);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(277,L8);
                ddv.visitStartLocal(0,L8,"i","I",null);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(278,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(279,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(280,L11);
                ddv.visitStartLocal(1,L11,"old","Ljava/lang/Object;","TE;");
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(281,L12);
                code.visitLabel(L5);
                code.visitFieldStmt(IGET_OBJECT,2,6,new Field("Lorg/mortbay/util/ArrayQueue;","_lock","Ljava/lang/Object;"));
                code.visitStmt1R(MONITOR_ENTER,2);
                code.visitLabel(L6);
                code.visitJumpStmt(IF_LTZ,7,-1,L7);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET,3,6,new Field("Lorg/mortbay/util/ArrayQueue;","_size","I"));
                code.visitJumpStmt(IF_LT,7,3,L3);
                code.visitLabel(L7);
                code.visitTypeStmt(NEW_INSTANCE,3,-1,"Ljava/lang/IndexOutOfBoundsException;");
                code.visitTypeStmt(NEW_INSTANCE,4,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 4},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,5,"!(0<");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,5},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,7},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "I"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitConstStmt(CONST_STRING,5,"<=");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,5},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitFieldStmt(IGET,5,6,new Field("Lorg/mortbay/util/ArrayQueue;","_size","I"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,5},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "I"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitConstStmt(CONST_STRING,5,")");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,5},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 3,4},new Method("Ljava/lang/IndexOutOfBoundsException;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitStmt1R(THROW,3);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,3);
                code.visitStmt1R(MONITOR_EXIT,2);
                code.visitLabel(L1);
                code.visitStmt1R(THROW,3);
                code.visitLabel(L3);
                code.visitFieldStmt(IGET,3,6,new Field("Lorg/mortbay/util/ArrayQueue;","_nextE","I"));
                code.visitStmt3R(ADD_INT,0,3,7);
                code.visitLabel(L8);
                code.visitFieldStmt(IGET_OBJECT,3,6,new Field("Lorg/mortbay/util/ArrayQueue;","_elements","[Ljava/lang/Object;"));
                code.visitStmt2R(ARRAY_LENGTH,3,3);
                code.visitJumpStmt(IF_LT,0,3,L10);
                code.visitLabel(L9);
                code.visitFieldStmt(IGET_OBJECT,3,6,new Field("Lorg/mortbay/util/ArrayQueue;","_elements","[Ljava/lang/Object;"));
                code.visitStmt2R(ARRAY_LENGTH,3,3);
                code.visitStmt2R(SUB_INT_2ADDR,0,3);
                code.visitLabel(L10);
                code.visitFieldStmt(IGET_OBJECT,3,6,new Field("Lorg/mortbay/util/ArrayQueue;","_elements","[Ljava/lang/Object;"));
                code.visitStmt3R(AGET_OBJECT,1,3,0);
                code.visitLabel(L11);
                code.visitFieldStmt(IGET_OBJECT,3,6,new Field("Lorg/mortbay/util/ArrayQueue;","_elements","[Ljava/lang/Object;"));
                code.visitStmt3R(APUT_OBJECT,8,3,0);
                code.visitLabel(L12);
                code.visitStmt1R(MONITOR_EXIT,2);
                code.visitLabel(L4);
                code.visitStmt1R(RETURN_OBJECT,1);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m020_size(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/util/ArrayQueue;","size",new String[]{ },"I"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitStartLocal(1,L0,"this","Lorg/mortbay/util/ArrayQueue;","Lorg/mortbay/util/ArrayQueue<TE;>;");
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(201,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET,0,1,new Field("Lorg/mortbay/util/ArrayQueue;","_size","I"));
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
