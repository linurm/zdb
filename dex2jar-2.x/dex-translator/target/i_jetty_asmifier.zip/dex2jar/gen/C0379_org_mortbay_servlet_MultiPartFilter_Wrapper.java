package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0379_org_mortbay_servlet_MultiPartFilter_Wrapper {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(0,"Lorg/mortbay/servlet/MultiPartFilter$Wrapper;","Ljavax/servlet/http/HttpServletRequestWrapper;",new String[]{ });
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("MultiPartFilter.java");
        if(cv!=null){
            DexAnnotationVisitor av00 = cv.visitAnnotation("Ldalvik/annotation/EnclosingClass;", Visibility.SYSTEM);
            if(av00 != null) {
                av00.visit("value", new DexType("Lorg/mortbay/servlet/MultiPartFilter;"));
                av00.visitEnd();
            }
        }
        if(cv!=null){
            DexAnnotationVisitor av00 = cv.visitAnnotation("Ldalvik/annotation/InnerClass;", Visibility.SYSTEM);
            if(av00 != null) {
                av00.visit("accessFlags",  Integer.valueOf(10));
                av00.visit("name", "Wrapper");
                av00.visitEnd();
            }
        }
        f000_encoding(cv);
        f001_map(cv);
        m000__init_(cv);
        m001_getContentLength(cv);
        m002_getParameter(cv);
        m003_getParameterMap(cv);
        m004_getParameterNames(cv);
        m005_getParameterValues(cv);
        m006_setCharacterEncoding(cv);
    }
    public static void f000_encoding(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(0, new Field("Lorg/mortbay/servlet/MultiPartFilter$Wrapper;","encoding","Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f001_map(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(0, new Field("Lorg/mortbay/servlet/MultiPartFilter$Wrapper;","map","Lorg/mortbay/util/MultiMap;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void m000__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/servlet/MultiPartFilter$Wrapper;","<init>",new String[]{ "Ljavax/servlet/http/HttpServletRequest;","Lorg/mortbay/util/MultiMap;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"request");
                ddv.visitParameterName(1,"map");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(358,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(349,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(359,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(360,L3);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1,2},new Method("Ljavax/servlet/http/HttpServletRequestWrapper;","<init>",new String[]{ "Ljavax/servlet/http/HttpServletRequest;"},"V"));
                code.visitLabel(L1);
                code.visitConstStmt(CONST_STRING,0,"UTF-8");
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/servlet/MultiPartFilter$Wrapper;","encoding","Ljava/lang/String;"));
                code.visitLabel(L2);
                code.visitFieldStmt(IPUT_OBJECT,3,1,new Field("Lorg/mortbay/servlet/MultiPartFilter$Wrapper;","map","Lorg/mortbay/util/MultiMap;"));
                code.visitLabel(L3);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001_getContentLength(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/servlet/MultiPartFilter$Wrapper;","getContentLength",new String[]{ },"I"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(368,L0);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m002_getParameter(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/servlet/MultiPartFilter$Wrapper;","getParameter",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(8);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ "Ljava/lang/Exception;"});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"name");
                DexLabel L3=new DexLabel();
                ddv.visitPrologue(L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(377,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(378,L5);
                ddv.visitStartLocal(2,L5,"o","Ljava/lang/Object;",null);
                ddv.visitLineNumber(382,L0);
                DexLabel L6=new DexLabel();
                ddv.visitEndLocal(2,L6);
                ddv.visitStartLocal(3,L1,"s","Ljava/lang/String;",null);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(397,L7);
                ddv.visitEndLocal(3,L7);
                ddv.visitLineNumber(385,L2);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(387,L8);
                ddv.visitStartLocal(1,L8,"e","Ljava/lang/Exception;",null);
                DexLabel L9=new DexLabel();
                ddv.visitEndLocal(1,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(397,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(390,L11);
                ddv.visitRestartLocal(2,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(391,L12);
                DexLabel L13=new DexLabel();
                ddv.visitEndLocal(2,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(392,L14);
                ddv.visitRestartLocal(2,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(394,L15);
                DexLabel L16=new DexLabel();
                ddv.visitEndLocal(2,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(395,L17);
                ddv.visitStartLocal(3,L17,"s","[Ljava/lang/String;",null);
                code.visitLabel(L3);
                code.visitConstStmt(CONST_4,5, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L4);
                code.visitFieldStmt(IGET_OBJECT,4,6,new Field("Lorg/mortbay/servlet/MultiPartFilter$Wrapper;","map","Lorg/mortbay/util/MultiMap;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,7},new Method("Lorg/mortbay/util/MultiMap;","get",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitLabel(L5);
                code.visitTypeStmt(INSTANCE_OF,4,2,"[B");
                code.visitJumpStmt(IF_EQZ,4,-1,L11);
                code.visitLabel(L0);
                code.visitTypeStmt(NEW_INSTANCE,3,-1,"Ljava/lang/String;");
                code.visitTypeStmt(CHECK_CAST,2,-1,"[B");
                code.visitLabel(L6);
                code.visitTypeStmt(CHECK_CAST,2,-1,"[B");
                code.visitFieldStmt(IGET_OBJECT,4,6,new Field("Lorg/mortbay/servlet/MultiPartFilter$Wrapper;","encoding","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 3,2,4},new Method("Ljava/lang/String;","<init>",new String[]{ "[B","Ljava/lang/String;"},"V"));
                code.visitLabel(L1);
                code.visitStmt2R(MOVE_OBJECT,4,3);
                code.visitLabel(L7);
                code.visitStmt1R(RETURN_OBJECT,4);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,4);
                code.visitStmt2R(MOVE_OBJECT,1,4);
                code.visitLabel(L8);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/lang/Exception;","printStackTrace",new String[]{ },"V"));
                code.visitLabel(L9);
                code.visitStmt2R(MOVE_OBJECT,4,5);
                code.visitLabel(L10);
                code.visitJumpStmt(GOTO,-1,-1,L7);
                code.visitLabel(L11);
                code.visitTypeStmt(INSTANCE_OF,4,2,"Ljava/lang/String;");
                code.visitJumpStmt(IF_EQZ,4,-1,L14);
                code.visitLabel(L12);
                code.visitTypeStmt(CHECK_CAST,2,-1,"Ljava/lang/String;");
                code.visitLabel(L13);
                code.visitStmt2R(MOVE_OBJECT,4,2);
                code.visitJumpStmt(GOTO,-1,-1,L7);
                code.visitLabel(L14);
                code.visitTypeStmt(INSTANCE_OF,4,2,"[Ljava/lang/String;");
                code.visitJumpStmt(IF_EQZ,4,-1,L9);
                code.visitLabel(L15);
                code.visitTypeStmt(CHECK_CAST,2,-1,"[Ljava/lang/String;");
                code.visitLabel(L16);
                code.visitStmt2R(MOVE_OBJECT,0,2);
                code.visitTypeStmt(CHECK_CAST,0,-1,"[Ljava/lang/String;");
                code.visitStmt2R(MOVE_OBJECT,3,0);
                code.visitLabel(L17);
                code.visitStmt2R(ARRAY_LENGTH,4,3);
                DexLabel L18=new DexLabel();
                code.visitJumpStmt(IF_LEZ,4,-1,L18);
                code.visitConstStmt(CONST_4,4, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitStmt3R(AGET_OBJECT,4,3,4);
                code.visitJumpStmt(GOTO,-1,-1,L7);
                code.visitLabel(L18);
                code.visitStmt2R(MOVE_OBJECT,4,5);
                code.visitJumpStmt(GOTO,-1,-1,L7);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m003_getParameterMap(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/servlet/MultiPartFilter$Wrapper;","getParameterMap",new String[]{ },"Ljava/util/Map;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(406,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/servlet/MultiPartFilter$Wrapper;","map","Lorg/mortbay/util/MultiMap;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m004_getParameterNames(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/servlet/MultiPartFilter$Wrapper;","getParameterNames",new String[]{ },"Ljava/util/Enumeration;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(415,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/servlet/MultiPartFilter$Wrapper;","map","Lorg/mortbay/util/MultiMap;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/util/MultiMap;","keySet",new String[]{ },"Ljava/util/Set;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0},new Method("Ljava/util/Collections;","enumeration",new String[]{ "Ljava/util/Collection;"},"Ljava/util/Enumeration;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m005_getParameterValues(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/servlet/MultiPartFilter$Wrapper;","getParameterValues",new String[]{ "Ljava/lang/String;"},"[Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(9);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ "Ljava/lang/Exception;"});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"name");
                DexLabel L3=new DexLabel();
                ddv.visitPrologue(L3);
                ddv.visitLineNumber(424,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(425,L4);
                ddv.visitStartLocal(2,L4,"l","Ljava/util/List;",null);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(426,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(445,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(427,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(428,L8);
                ddv.visitStartLocal(4,L8,"v","[Ljava/lang/String;",null);
                DexLabel L9=new DexLabel();
                ddv.visitStartLocal(1,L9,"i","I",null);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(430,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(431,L11);
                ddv.visitStartLocal(3,L11,"o","Ljava/lang/Object;",null);
                ddv.visitLineNumber(435,L0);
                DexLabel L12=new DexLabel();
                ddv.visitEndLocal(3,L12);
                ddv.visitLineNumber(428,L1);
                ddv.visitLineNumber(437,L2);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(439,L13);
                ddv.visitStartLocal(0,L13,"e","Ljava/lang/Exception;",null);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(442,L14);
                ddv.visitEndLocal(0,L14);
                ddv.visitRestartLocal(3,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(443,L15);
                DexLabel L16=new DexLabel();
                ddv.visitEndLocal(3,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(445,L17);
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,5,7,new Field("Lorg/mortbay/servlet/MultiPartFilter$Wrapper;","map","Lorg/mortbay/util/MultiMap;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,8},new Method("Lorg/mortbay/util/MultiMap;","getValues",new String[]{ "Ljava/lang/Object;"},"Ljava/util/List;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitLabel(L4);
                code.visitJumpStmt(IF_EQZ,2,-1,L5);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 2},new Method("Ljava/util/List;","size",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,5);
                code.visitJumpStmt(IF_NEZ,5,-1,L7);
                code.visitLabel(L5);
                code.visitConstStmt(CONST_4,5, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitTypeStmt(NEW_ARRAY,5,5,"[Ljava/lang/String;");
                code.visitLabel(L6);
                code.visitStmt1R(RETURN_OBJECT,5);
                code.visitLabel(L7);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 2},new Method("Ljava/util/List;","size",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,5);
                code.visitTypeStmt(NEW_ARRAY,4,5,"[Ljava/lang/String;");
                code.visitLabel(L8);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L9);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 2},new Method("Ljava/util/List;","size",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,5);
                DexLabel L18=new DexLabel();
                code.visitJumpStmt(IF_GE,1,5,L18);
                code.visitLabel(L10);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 2,1},new Method("Ljava/util/List;","get",new String[]{ "I"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitLabel(L11);
                code.visitTypeStmt(INSTANCE_OF,5,3,"[B");
                code.visitJumpStmt(IF_EQZ,5,-1,L14);
                code.visitLabel(L0);
                code.visitTypeStmt(NEW_INSTANCE,5,-1,"Ljava/lang/String;");
                code.visitTypeStmt(CHECK_CAST,3,-1,"[B");
                code.visitLabel(L12);
                code.visitTypeStmt(CHECK_CAST,3,-1,"[B");
                code.visitFieldStmt(IGET_OBJECT,6,7,new Field("Lorg/mortbay/servlet/MultiPartFilter$Wrapper;","encoding","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 5,3,6},new Method("Ljava/lang/String;","<init>",new String[]{ "[B","Ljava/lang/String;"},"V"));
                code.visitStmt3R(APUT_OBJECT,5,4,1);
                code.visitLabel(L1);
                code.visitStmt2R1N(ADD_INT_LIT8,1,1,1);
                code.visitJumpStmt(GOTO,-1,-1,L9);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,5);
                code.visitStmt2R(MOVE_OBJECT,0,5);
                code.visitLabel(L13);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/lang/Exception;","printStackTrace",new String[]{ },"V"));
                code.visitJumpStmt(GOTO,-1,-1,L1);
                code.visitLabel(L14);
                code.visitTypeStmt(INSTANCE_OF,5,3,"Ljava/lang/String;");
                code.visitJumpStmt(IF_EQZ,5,-1,L1);
                code.visitLabel(L15);
                code.visitTypeStmt(CHECK_CAST,3,-1,"Ljava/lang/String;");
                code.visitLabel(L16);
                code.visitStmt3R(APUT_OBJECT,3,4,1);
                code.visitJumpStmt(GOTO,-1,-1,L1);
                code.visitLabel(L18);
                code.visitStmt2R(MOVE_OBJECT,5,4);
                code.visitLabel(L17);
                code.visitJumpStmt(GOTO,-1,-1,L6);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m006_setCharacterEncoding(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/servlet/MultiPartFilter$Wrapper;","setCharacterEncoding",new String[]{ "Ljava/lang/String;"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/UnsupportedEncodingException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"enc");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(455,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(456,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_OBJECT,1,0,new Field("Lorg/mortbay/servlet/MultiPartFilter$Wrapper;","encoding","Ljava/lang/String;"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
