package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0364_org_mortbay_resource_URLResource {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(ACC_PUBLIC,"Lorg/mortbay/resource/URLResource;","Lorg/mortbay/resource/Resource;",new String[]{ });
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("URLResource.java");
        f000__connection(cv);
        f001__in(cv);
        f002__url(cv);
        f003__urlString(cv);
        f004__useCaches(cv);
        m000__init_(cv);
        m001__init_(cv);
        m002_addPath(cv);
        m003_checkConnection(cv);
        m004_delete(cv);
        m005_equals(cv);
        m006_exists(cv);
        m007_getFile(cv);
        m008_getInputStream(cv);
        m009_getName(cv);
        m010_getOutputStream(cv);
        m011_getURL(cv);
        m012_getUseCaches(cv);
        m013_hashCode(cv);
        m014_isDirectory(cv);
        m015_lastModified(cv);
        m016_length(cv);
        m017_list(cv);
        m018_release(cv);
        m019_renameTo(cv);
        m020_toString(cv);
    }
    public static void f000__connection(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PROTECTED|ACC_TRANSIENT, new Field("Lorg/mortbay/resource/URLResource;","_connection","Ljava/net/URLConnection;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f001__in(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PROTECTED|ACC_TRANSIENT, new Field("Lorg/mortbay/resource/URLResource;","_in","Ljava/io/InputStream;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f002__url(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PROTECTED, new Field("Lorg/mortbay/resource/URLResource;","_url","Ljava/net/URL;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f003__urlString(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PROTECTED, new Field("Lorg/mortbay/resource/URLResource;","_urlString","Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f004__useCaches(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_TRANSIENT, new Field("Lorg/mortbay/resource/URLResource;","_useCaches","Z"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void m000__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/resource/URLResource;","<init>",new String[]{ "Ljava/net/URL;","Ljava/net/URLConnection;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"url");
                ddv.visitParameterName(1,"connection");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(46,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(41,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(42,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(47,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(48,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(49,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(50,L6);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1},new Method("Lorg/mortbay/resource/Resource;","<init>",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/resource/URLResource;","_in","Ljava/io/InputStream;"));
                code.visitLabel(L2);
                code.visitFieldStmt(SGET_BOOLEAN,0,-1,new Field("Lorg/mortbay/resource/Resource;","__defaultUseCaches","Z"));
                code.visitFieldStmt(IPUT_BOOLEAN,0,1,new Field("Lorg/mortbay/resource/URLResource;","_useCaches","Z"));
                code.visitLabel(L3);
                code.visitFieldStmt(IPUT_OBJECT,2,1,new Field("Lorg/mortbay/resource/URLResource;","_url","Ljava/net/URL;"));
                code.visitLabel(L4);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/resource/URLResource;","_url","Ljava/net/URL;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/net/URL;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/resource/URLResource;","_urlString","Ljava/lang/String;"));
                code.visitLabel(L5);
                code.visitFieldStmt(IPUT_OBJECT,3,1,new Field("Lorg/mortbay/resource/URLResource;","_connection","Ljava/net/URLConnection;"));
                code.visitLabel(L6);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/resource/URLResource;","<init>",new String[]{ "Ljava/net/URL;","Ljava/net/URLConnection;","Z"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"url");
                ddv.visitParameterName(1,"connection");
                ddv.visitParameterName(2,"useCaches");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(54,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(55,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(56,L2);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1,2},new Method("Lorg/mortbay/resource/URLResource;","<init>",new String[]{ "Ljava/net/URL;","Ljava/net/URLConnection;"},"V"));
                code.visitLabel(L1);
                code.visitFieldStmt(IPUT_BOOLEAN,3,0,new Field("Lorg/mortbay/resource/URLResource;","_useCaches","Z"));
                code.visitLabel(L2);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m002_addPath(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/resource/URLResource;","addPath",new String[]{ "Ljava/lang/String;"},"Lorg/mortbay/resource/Resource;"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visit(null, new DexType("Ljava/net/MalformedURLException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"path");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(262,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(263,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(267,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(265,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(267,L4);
                code.visitLabel(L0);
                code.visitJumpStmt(IF_NEZ,2,-1,L3);
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L2);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 2},new Method("Lorg/mortbay/util/URIUtil;","canonicalPath",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitLabel(L4);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/resource/URLResource;","_url","Ljava/net/URL;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/net/URL;","toExternalForm",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0,2},new Method("Lorg/mortbay/util/URIUtil;","addPaths",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0},new Method("Lorg/mortbay/resource/URLResource;","newResource",new String[]{ "Ljava/lang/String;"},"Lorg/mortbay/resource/Resource;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m003_checkConnection(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Lorg/mortbay/resource/URLResource;","checkConnection",new String[]{ },"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexLabel L3=new DexLabel();
                DexLabel L4=new DexLabel();
                DexLabel L5=new DexLabel();
                code.visitTryCatch(L3,L4,new DexLabel[]{L5,L2},new String[]{ "Ljava/io/IOException;",null});
                DexLabel L6=new DexLabel();
                code.visitTryCatch(L4,L6,new DexLabel[]{L2},new String[]{ null});
                DexLabel L7=new DexLabel();
                DexLabel L8=new DexLabel();
                code.visitTryCatch(L7,L8,new DexLabel[]{L2},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L9=new DexLabel();
                ddv.visitPrologue(L9);
                ddv.visitLineNumber(61,L9);
                ddv.visitLineNumber(64,L3);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(65,L10);
                ddv.visitLineNumber(72,L4);
                ddv.visitLineNumber(67,L5);
                ddv.visitLineNumber(69,L7);
                ddv.visitStartLocal(0,L7,"e","Ljava/io/IOException;",null);
                ddv.visitLineNumber(61,L2);
                ddv.visitEndLocal(0,L2);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(72,L11);
                code.visitLabel(L9);
                code.visitStmt1R(MONITOR_ENTER,3);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,1,3,new Field("Lorg/mortbay/resource/URLResource;","_connection","Ljava/net/URLConnection;"));
                code.visitLabel(L1);
                code.visitJumpStmt(IF_NEZ,1,-1,L4);
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,1,3,new Field("Lorg/mortbay/resource/URLResource;","_url","Ljava/net/URL;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/net/URL;","openConnection",new String[]{ },"Ljava/net/URLConnection;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitFieldStmt(IPUT_OBJECT,1,3,new Field("Lorg/mortbay/resource/URLResource;","_connection","Ljava/net/URLConnection;"));
                code.visitLabel(L10);
                code.visitFieldStmt(IGET_OBJECT,1,3,new Field("Lorg/mortbay/resource/URLResource;","_connection","Ljava/net/URLConnection;"));
                code.visitFieldStmt(IGET_BOOLEAN,2,3,new Field("Lorg/mortbay/resource/URLResource;","_useCaches","Z"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2},new Method("Ljava/net/URLConnection;","setUseCaches",new String[]{ "Z"},"V"));
                code.visitLabel(L4);
                code.visitFieldStmt(IGET_OBJECT,1,3,new Field("Lorg/mortbay/resource/URLResource;","_connection","Ljava/net/URLConnection;"));
                code.visitLabel(L6);
                code.visitJumpStmt(IF_EQZ,1,-1,L11);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                DexLabel L12=new DexLabel();
                code.visitLabel(L12);
                code.visitStmt1R(MONITOR_EXIT,3);
                code.visitStmt1R(RETURN,1);
                code.visitLabel(L5);
                code.visitStmt1R(MOVE_EXCEPTION,1);
                code.visitStmt2R(MOVE_OBJECT,0,1);
                code.visitLabel(L7);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0},new Method("Lorg/mortbay/log/Log;","ignore",new String[]{ "Ljava/lang/Throwable;"},"V"));
                code.visitLabel(L8);
                code.visitJumpStmt(GOTO,-1,-1,L4);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,1);
                code.visitStmt1R(MONITOR_EXIT,3);
                code.visitStmt1R(THROW,1);
                code.visitLabel(L11);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L12);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m004_delete(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/resource/URLResource;","delete",new String[]{ },"Z"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/lang/SecurityException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(232,L0);
                code.visitLabel(L0);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/lang/SecurityException;");
                code.visitConstStmt(CONST_STRING,1,"Delete not supported");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1},new Method("Ljava/lang/SecurityException;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitStmt1R(THROW,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m005_equals(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/resource/URLResource;","equals",new String[]{ "Ljava/lang/Object;"},"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"o");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(285,L0);
                DexLabel L1=new DexLabel();
                ddv.visitEndLocal(3,L1);
                code.visitLabel(L0);
                code.visitTypeStmt(INSTANCE_OF,0,3,"Lorg/mortbay/resource/URLResource;");
                DexLabel L2=new DexLabel();
                code.visitJumpStmt(IF_EQZ,0,-1,L2);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/resource/URLResource;","_url","Ljava/net/URL;"));
                code.visitTypeStmt(CHECK_CAST,3,-1,"Lorg/mortbay/resource/URLResource;");
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,1,3,new Field("Lorg/mortbay/resource/URLResource;","_url","Ljava/net/URL;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/net/URL;","equals",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_EQZ,0,-1,L2);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                DexLabel L3=new DexLabel();
                code.visitLabel(L3);
                code.visitStmt1R(RETURN,0);
                code.visitLabel(L2);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L3);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m006_exists(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/resource/URLResource;","exists",new String[]{ },"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ "Ljava/io/IOException;"});
                DexLabel L3=new DexLabel();
                DexLabel L4=new DexLabel();
                code.visitTryCatch(L1,L3,new DexLabel[]{L4},new String[]{ null});
                DexLabel L5=new DexLabel();
                DexLabel L6=new DexLabel();
                code.visitTryCatch(L5,L6,new DexLabel[]{L4},new String[]{ null});
                code.visitTryCatch(L6,L2,new DexLabel[]{L2},new String[]{ "Ljava/io/IOException;"});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(98,L0);
                ddv.visitLineNumber(100,L1);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(101,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(102,L8);
                ddv.visitLineNumber(108,L3);
                ddv.visitLineNumber(102,L4);
                ddv.visitLineNumber(104,L2);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(106,L9);
                ddv.visitStartLocal(0,L9,"e","Ljava/io/IOException;",null);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(108,L10);
                ddv.visitEndLocal(0,L10);
                code.visitLabel(L0);
                code.visitStmt1R(MONITOR_ENTER,2);
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/resource/URLResource;","checkConnection",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitJumpStmt(IF_EQZ,1,-1,L8);
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/resource/URLResource;","_in","Ljava/io/InputStream;"));
                code.visitJumpStmt(IF_NEZ,1,-1,L8);
                code.visitLabel(L7);
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/resource/URLResource;","_connection","Ljava/net/URLConnection;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/net/URLConnection;","getInputStream",new String[]{ },"Ljava/io/InputStream;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitFieldStmt(IPUT_OBJECT,1,2,new Field("Lorg/mortbay/resource/URLResource;","_in","Ljava/io/InputStream;"));
                code.visitLabel(L8);
                code.visitStmt1R(MONITOR_EXIT,2);
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/resource/URLResource;","_in","Ljava/io/InputStream;"));
                code.visitJumpStmt(IF_EQZ,1,-1,L10);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                DexLabel L11=new DexLabel();
                code.visitLabel(L11);
                code.visitStmt1R(RETURN,1);
                code.visitLabel(L4);
                code.visitStmt1R(MOVE_EXCEPTION,1);
                code.visitLabel(L5);
                code.visitStmt1R(MONITOR_EXIT,2);
                code.visitLabel(L6);
                code.visitStmt1R(THROW,1);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,1);
                code.visitStmt2R(MOVE_OBJECT,0,1);
                code.visitLabel(L9);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0},new Method("Lorg/mortbay/log/Log;","ignore",new String[]{ "Ljava/lang/Throwable;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L3);
                code.visitLabel(L10);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L11);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m007_getFile(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/resource/URLResource;","getFile",new String[]{ },"Ljava/io/File;"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ "Ljava/lang/Exception;"});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L3=new DexLabel();
                ddv.visitPrologue(L3);
                ddv.visitLineNumber(164,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(166,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(167,L5);
                ddv.visitStartLocal(1,L5,"perm","Ljava/security/Permission;",null);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(168,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(176,L7);
                ddv.visitEndLocal(1,L7);
                ddv.visitLineNumber(172,L0);
                ddv.visitLineNumber(173,L2);
                DexLabel L8=new DexLabel();
                ddv.visitStartLocal(0,L8,"e","Ljava/lang/Exception;",null);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(176,L9);
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Lorg/mortbay/resource/URLResource;","checkConnection",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitJumpStmt(IF_EQZ,2,-1,L0);
                code.visitLabel(L4);
                code.visitFieldStmt(IGET_OBJECT,2,4,new Field("Lorg/mortbay/resource/URLResource;","_connection","Ljava/net/URLConnection;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Ljava/net/URLConnection;","getPermission",new String[]{ },"Ljava/security/Permission;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L5);
                code.visitTypeStmt(INSTANCE_OF,2,1,"Ljava/io/FilePermission;");
                code.visitJumpStmt(IF_EQZ,2,-1,L0);
                code.visitLabel(L6);
                code.visitTypeStmt(NEW_INSTANCE,2,-1,"Ljava/io/File;");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/security/Permission;","getName",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2,3},new Method("Ljava/io/File;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L7);
                code.visitStmt1R(RETURN_OBJECT,2);
                code.visitLabel(L0);
                code.visitTypeStmt(NEW_INSTANCE,2,-1,"Ljava/io/File;");
                code.visitFieldStmt(IGET_OBJECT,3,4,new Field("Lorg/mortbay/resource/URLResource;","_url","Ljava/net/URL;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Ljava/net/URL;","getFile",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2,3},new Method("Ljava/io/File;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L1);
                code.visitJumpStmt(GOTO,-1,-1,L7);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,2);
                code.visitStmt2R(MOVE_OBJECT,0,2);
                code.visitLabel(L8);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0},new Method("Lorg/mortbay/log/Log;","ignore",new String[]{ "Ljava/lang/Throwable;"},"V"));
                code.visitLabel(L9);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L7);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m008_getInputStream(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/resource/URLResource;","getInputStream",new String[]{ },"Ljava/io/InputStream;"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L1},new String[]{ null});
                DexLabel L2=new DexLabel();
                DexLabel L3=new DexLabel();
                DexLabel L4=new DexLabel();
                code.visitTryCatch(L2,L3,new DexLabel[]{L4},new String[]{ null});
                DexLabel L5=new DexLabel();
                DexLabel L6=new DexLabel();
                code.visitTryCatch(L5,L6,new DexLabel[]{L1},new String[]{ null});
                DexLabel L7=new DexLabel();
                DexLabel L8=new DexLabel();
                code.visitTryCatch(L7,L8,new DexLabel[]{L4},new String[]{ null});
                DexLabel L9=new DexLabel();
                DexLabel L10=new DexLabel();
                code.visitTryCatch(L9,L10,new DexLabel[]{L1},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L11=new DexLabel();
                ddv.visitPrologue(L11);
                ddv.visitLineNumber(195,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(196,L12);
                ddv.visitLineNumber(195,L1);
                ddv.visitLineNumber(200,L2);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(202,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(203,L14);
                ddv.visitStartLocal(0,L14,"in","Ljava/io/InputStream;",null);
                ddv.visitLineNumber(210,L3);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(206,L15);
                ddv.visitEndLocal(0,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(210,L16);
                code.visitLabel(L11);
                code.visitStmt1R(MONITOR_ENTER,3);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Lorg/mortbay/resource/URLResource;","checkConnection",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitJumpStmt(IF_NEZ,1,-1,L2);
                code.visitLabel(L12);
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Ljava/io/IOException;");
                code.visitConstStmt(CONST_STRING,2,"Invalid resource");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1,2},new Method("Ljava/io/IOException;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitStmt1R(THROW,1);
                code.visitLabel(L1);
                code.visitStmt1R(MOVE_EXCEPTION,1);
                code.visitStmt1R(MONITOR_EXIT,3);
                code.visitStmt1R(THROW,1);
                code.visitLabel(L2);
                code.visitFieldStmt(IGET_OBJECT,1,3,new Field("Lorg/mortbay/resource/URLResource;","_in","Ljava/io/InputStream;"));
                code.visitJumpStmt(IF_EQZ,1,-1,L7);
                code.visitLabel(L13);
                code.visitFieldStmt(IGET_OBJECT,0,3,new Field("Lorg/mortbay/resource/URLResource;","_in","Ljava/io/InputStream;"));
                code.visitLabel(L14);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT_OBJECT,1,3,new Field("Lorg/mortbay/resource/URLResource;","_in","Ljava/io/InputStream;"));
                code.visitLabel(L3);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L5);
                code.visitFieldStmt(IPUT_OBJECT,1,3,new Field("Lorg/mortbay/resource/URLResource;","_connection","Ljava/net/URLConnection;"));
                code.visitLabel(L6);
                code.visitStmt2R(MOVE_OBJECT,1,0);
                code.visitLabel(L15);
                code.visitStmt1R(MONITOR_EXIT,3);
                code.visitStmt1R(RETURN_OBJECT,1);
                code.visitLabel(L7);
                code.visitFieldStmt(IGET_OBJECT,1,3,new Field("Lorg/mortbay/resource/URLResource;","_connection","Ljava/net/URLConnection;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/net/URLConnection;","getInputStream",new String[]{ },"Ljava/io/InputStream;"));
                code.visitLabel(L8);
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L16);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L9);
                code.visitFieldStmt(IPUT_OBJECT,2,3,new Field("Lorg/mortbay/resource/URLResource;","_connection","Ljava/net/URLConnection;"));
                code.visitJumpStmt(GOTO,-1,-1,L15);
                code.visitLabel(L4);
                code.visitStmt1R(MOVE_EXCEPTION,1);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT_OBJECT,2,3,new Field("Lorg/mortbay/resource/URLResource;","_connection","Ljava/net/URLConnection;"));
                code.visitStmt1R(THROW,1);
                code.visitLabel(L10);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m009_getName(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/resource/URLResource;","getName",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(185,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/resource/URLResource;","_url","Ljava/net/URL;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/net/URL;","toExternalForm",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m010_getOutputStream(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/resource/URLResource;","getOutputStream",new String[]{ },"Ljava/io/OutputStream;"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visit(null, new DexType("Ljava/lang/SecurityException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(222,L0);
                code.visitLabel(L0);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/io/IOException;");
                code.visitConstStmt(CONST_STRING,1,"Output not supported");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1},new Method("Ljava/io/IOException;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitStmt1R(THROW,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m011_getURL(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/resource/URLResource;","getURL",new String[]{ },"Ljava/net/URL;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(152,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/resource/URLResource;","_url","Ljava/net/URL;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m012_getUseCaches(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/resource/URLResource;","getUseCaches",new String[]{ },"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(291,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_BOOLEAN,0,1,new Field("Lorg/mortbay/resource/URLResource;","_useCaches","Z"));
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m013_hashCode(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/resource/URLResource;","hashCode",new String[]{ },"I"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(279,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/resource/URLResource;","_url","Ljava/net/URL;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/net/URL;","hashCode",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m014_isDirectory(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/resource/URLResource;","isDirectory",new String[]{ },"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(119,L0);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/resource/URLResource;","exists",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                DexLabel L1=new DexLabel();
                code.visitJumpStmt(IF_EQZ,0,-1,L1);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/resource/URLResource;","_url","Ljava/net/URL;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/net/URL;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitConstStmt(CONST_STRING,1,"/");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/String;","endsWith",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_EQZ,0,-1,L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                DexLabel L2=new DexLabel();
                code.visitLabel(L2);
                code.visitStmt1R(RETURN,0);
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m015_lastModified(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/resource/URLResource;","lastModified",new String[]{ },"J"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(129,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(130,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(131,L2);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/resource/URLResource;","checkConnection",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                DexLabel L3=new DexLabel();
                code.visitJumpStmt(IF_EQZ,0,-1,L3);
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/resource/URLResource;","_connection","Ljava/net/URLConnection;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/net/URLConnection;","getLastModified",new String[]{ },"J"));
                code.visitStmt1R(MOVE_RESULT_WIDE,0);
                code.visitLabel(L2);
                code.visitStmt1R(RETURN_WIDE,0);
                code.visitLabel(L3);
                code.visitConstStmt(CONST_WIDE_16,0,Long.valueOf(-1L)); // long: 0xffffffffffffffff  double:NaN
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m016_length(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/resource/URLResource;","length",new String[]{ },"J"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(141,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(142,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(143,L2);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/resource/URLResource;","checkConnection",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                DexLabel L3=new DexLabel();
                code.visitJumpStmt(IF_EQZ,0,-1,L3);
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/resource/URLResource;","_connection","Ljava/net/URLConnection;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/net/URLConnection;","getContentLength",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitStmt2R(INT_TO_LONG,0,0);
                code.visitLabel(L2);
                code.visitStmt1R(RETURN_WIDE,0);
                code.visitLabel(L3);
                code.visitConstStmt(CONST_WIDE_16,0,Long.valueOf(-1L)); // long: 0xffffffffffffffff  double:NaN
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m017_list(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/resource/URLResource;","list",new String[]{ },"[Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(251,L0);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m018_release(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/resource/URLResource;","release",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexLabel L3=new DexLabel();
                DexLabel L4=new DexLabel();
                DexLabel L5=new DexLabel();
                code.visitTryCatch(L3,L4,new DexLabel[]{L5,L2},new String[]{ "Ljava/io/IOException;",null});
                DexLabel L6=new DexLabel();
                DexLabel L7=new DexLabel();
                code.visitTryCatch(L6,L7,new DexLabel[]{L2},new String[]{ null});
                DexLabel L8=new DexLabel();
                DexLabel L9=new DexLabel();
                code.visitTryCatch(L8,L9,new DexLabel[]{L2},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L10=new DexLabel();
                ddv.visitPrologue(L10);
                ddv.visitLineNumber(80,L10);
                ddv.visitLineNumber(82,L3);
                ddv.visitLineNumber(83,L4);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(86,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(87,L12);
                ddv.visitLineNumber(88,L7);
                ddv.visitLineNumber(82,L5);
                ddv.visitStartLocal(0,L8,"e","Ljava/io/IOException;",null);
                ddv.visitLineNumber(80,L2);
                ddv.visitEndLocal(0,L2);
                code.visitLabel(L10);
                code.visitStmt1R(MONITOR_ENTER,2);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/resource/URLResource;","_in","Ljava/io/InputStream;"));
                code.visitLabel(L1);
                code.visitJumpStmt(IF_EQZ,1,-1,L11);
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/resource/URLResource;","_in","Ljava/io/InputStream;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/io/InputStream;","close",new String[]{ },"V"));
                code.visitLabel(L4);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L6);
                code.visitFieldStmt(IPUT_OBJECT,1,2,new Field("Lorg/mortbay/resource/URLResource;","_in","Ljava/io/InputStream;"));
                code.visitLabel(L11);
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/resource/URLResource;","_connection","Ljava/net/URLConnection;"));
                code.visitJumpStmt(IF_EQZ,1,-1,L7);
                code.visitLabel(L12);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT_OBJECT,1,2,new Field("Lorg/mortbay/resource/URLResource;","_connection","Ljava/net/URLConnection;"));
                code.visitLabel(L7);
                code.visitStmt1R(MONITOR_EXIT,2);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L5);
                code.visitStmt1R(MOVE_EXCEPTION,1);
                code.visitStmt2R(MOVE_OBJECT,0,1);
                code.visitLabel(L8);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0},new Method("Lorg/mortbay/log/Log;","ignore",new String[]{ "Ljava/lang/Throwable;"},"V"));
                code.visitLabel(L9);
                code.visitJumpStmt(GOTO,-1,-1,L4);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,1);
                code.visitStmt1R(MONITOR_EXIT,2);
                code.visitStmt1R(THROW,1);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m019_renameTo(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/resource/URLResource;","renameTo",new String[]{ "Lorg/mortbay/resource/Resource;"},"Z"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/lang/SecurityException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"dest");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(242,L0);
                code.visitLabel(L0);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/lang/SecurityException;");
                code.visitConstStmt(CONST_STRING,1,"RenameTo not supported");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1},new Method("Ljava/lang/SecurityException;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitStmt1R(THROW,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m020_toString(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/resource/URLResource;","toString",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(273,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/resource/URLResource;","_urlString","Ljava/lang/String;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
