package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0177_org_mortbay_jetty_InclusiveByteRange {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(ACC_PUBLIC,"Lorg/mortbay/jetty/InclusiveByteRange;","Ljava/lang/Object;",new String[]{ });
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("InclusiveByteRange.java");
        f000_first(cv);
        f001_last(cv);
        m000__init_(cv);
        m001_satisfiableRanges(cv);
        m002_to416HeaderRangeString(cv);
        m003_getFirst(cv);
        m004_getFirst(cv);
        m005_getLast(cv);
        m006_getLast(cv);
        m007_getSize(cv);
        m008_toHeaderRangeString(cv);
        m009_toString(cv);
    }
    public static void f000_first(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(0, new Field("Lorg/mortbay/jetty/InclusiveByteRange;","first","J"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f001_last(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(0, new Field("Lorg/mortbay/jetty/InclusiveByteRange;","last","J"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void m000__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/jetty/InclusiveByteRange;","<init>",new String[]{ "J","J"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(7);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"first");
                ddv.visitParameterName(1,"last");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(51,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(47,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(48,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(52,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(53,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(54,L6);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_WIDE_16,0,Long.valueOf(0L)); // long: 0x0000000000000000  double:0.000000
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2},new Method("Ljava/lang/Object;","<init>",new String[]{ },"V"));
                code.visitLabel(L2);
                code.visitFieldStmt(IPUT_WIDE,0,2,new Field("Lorg/mortbay/jetty/InclusiveByteRange;","first","J"));
                code.visitLabel(L3);
                code.visitFieldStmt(IPUT_WIDE,0,2,new Field("Lorg/mortbay/jetty/InclusiveByteRange;","last","J"));
                code.visitLabel(L4);
                code.visitFieldStmt(IPUT_WIDE,3,2,new Field("Lorg/mortbay/jetty/InclusiveByteRange;","first","J"));
                code.visitLabel(L5);
                code.visitFieldStmt(IPUT_WIDE,5,2,new Field("Lorg/mortbay/jetty/InclusiveByteRange;","last","J"));
                code.visitLabel(L6);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001_satisfiableRanges(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Lorg/mortbay/jetty/InclusiveByteRange;","satisfiableRanges",new String[]{ "Ljava/util/Enumeration;","J"},"Ljava/util/List;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(17);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ "Ljava/lang/Exception;"});
                DexLabel L3=new DexLabel();
                DexLabel L4=new DexLabel();
                DexLabel L5=new DexLabel();
                code.visitTryCatch(L3,L4,new DexLabel[]{L5},new String[]{ "Ljava/lang/Exception;"});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"headers");
                ddv.visitParameterName(1,"size");
                DexLabel L6=new DexLabel();
                ddv.visitPrologue(L6);
                ddv.visitLineNumber(76,L6);
                DexLabel L7=new DexLabel();
                ddv.visitStartLocal(0,L7,"satRanges","Ljava/lang/Object;",null);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(80,L8);
                ddv.visitEndLocal(0,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(82,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(83,L10);
                ddv.visitStartLocal(0,L10,"header","Ljava/lang/String;",null);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(84,L11);
                ddv.visitStartLocal(6,L11,"tok","Ljava/util/StringTokenizer;",null);
                DexLabel L12=new DexLabel();
                ddv.visitStartLocal(0,L12,"t","Ljava/lang/String;",null);
                ddv.visitLineNumber(88,L0);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(90,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(92,L14);
                ddv.visitStartLocal(5,L14,"t","Ljava/lang/String;",null);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(93,L15);
                ddv.visitStartLocal(1,L15,"first","J",null);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(94,L16);
                ddv.visitStartLocal(3,L16,"last","J",null);
                DexLabel L17=new DexLabel();
                ddv.visitEndLocal(0,L17);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(95,L18);
                ddv.visitStartLocal(0,L18,"d","I",null);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(97,L19);
                DexLabel L20=new DexLabel();
                ddv.visitEndLocal(0,L20);
                DexLabel L21=new DexLabel();
                ddv.visitLineNumber(98,L21);
                ddv.visitStartLocal(0,L21,"t","Ljava/lang/String;",null);
                DexLabel L22=new DexLabel();
                ddv.visitLineNumber(99,L22);
                ddv.visitEndLocal(0,L22);
                DexLabel L23=new DexLabel();
                ddv.visitLineNumber(100,L23);
                DexLabel L24=new DexLabel();
                ddv.visitLineNumber(102,L24);
                ddv.visitStartLocal(0,L24,"d","I",null);
                DexLabel L25=new DexLabel();
                ddv.visitLineNumber(104,L25);
                DexLabel L26=new DexLabel();
                ddv.visitEndLocal(3,L26);
                DexLabel L27=new DexLabel();
                ddv.visitLineNumber(105,L27);
                DexLabel L28=new DexLabel();
                ddv.visitEndLocal(0,L28);
                DexLabel L29=new DexLabel();
                ddv.visitRestartLocal(3,L29);
                DexLabel L30=new DexLabel();
                ddv.visitStartLocal(10,L30,"last","J",null);
                DexLabel L31=new DexLabel();
                ddv.visitStartLocal(12,L31,"first","J",null);
                DexLabel L32=new DexLabel();
                ddv.visitStartLocal(0,L32,"first","J",null);
                DexLabel L33=new DexLabel();
                ddv.visitLineNumber(121,L33);
                ddv.visitEndLocal(10,L33);
                ddv.visitEndLocal(12,L33);
                ddv.visitStartLocal(2,L33,"last","J",null);
                DexLabel L34=new DexLabel();
                ddv.visitLineNumber(122,L34);
                DexLabel L35=new DexLabel();
                ddv.visitLineNumber(108,L35);
                ddv.visitEndLocal(2,L35);
                ddv.visitStartLocal(0,L35,"d","I",null);
                ddv.visitRestartLocal(1,L35);
                DexLabel L36=new DexLabel();
                ddv.visitEndLocal(0,L36);
                DexLabel L37=new DexLabel();
                ddv.visitLineNumber(109,L37);
                DexLabel L38=new DexLabel();
                ddv.visitLineNumber(112,L38);
                ddv.visitRestartLocal(0,L38);
                ddv.visitRestartLocal(3,L38);
                DexLabel L39=new DexLabel();
                ddv.visitEndLocal(1,L39);
                DexLabel L40=new DexLabel();
                ddv.visitLineNumber(114,L40);
                DexLabel L41=new DexLabel();
                ddv.visitLineNumber(115,L41);
                ddv.visitRestartLocal(1,L41);
                DexLabel L42=new DexLabel();
                ddv.visitEndLocal(0,L42);
                DexLabel L43=new DexLabel();
                ddv.visitRestartLocal(3,L43);
                DexLabel L44=new DexLabel();
                ddv.visitRestartLocal(10,L44);
                DexLabel L45=new DexLabel();
                ddv.visitRestartLocal(12,L45);
                DexLabel L46=new DexLabel();
                ddv.visitStartLocal(0,L46,"first","J",null);
                DexLabel L47=new DexLabel();
                ddv.visitRestartLocal(2,L47);
                DexLabel L48=new DexLabel();
                ddv.visitLineNumber(118,L48);
                ddv.visitEndLocal(10,L48);
                ddv.visitEndLocal(12,L48);
                ddv.visitEndLocal(2,L48);
                ddv.visitStartLocal(0,L48,"d","I",null);
                ddv.visitRestartLocal(3,L48);
                DexLabel L49=new DexLabel();
                ddv.visitEndLocal(0,L49);
                DexLabel L50=new DexLabel();
                ddv.visitStartLocal(0,L50,"first","J",null);
                DexLabel L51=new DexLabel();
                ddv.visitRestartLocal(2,L51);
                DexLabel L52=new DexLabel();
                ddv.visitLineNumber(124,L52);
                DexLabel L53=new DexLabel();
                ddv.visitLineNumber(125,L53);
                DexLabel L54=new DexLabel();
                ddv.visitLineNumber(127,L54);
                DexLabel L55=new DexLabel();
                ddv.visitLineNumber(129,L55);
                DexLabel L56=new DexLabel();
                ddv.visitLineNumber(131,L56);
                ddv.visitStartLocal(4,L56,"range","Lorg/mortbay/jetty/InclusiveByteRange;",null);
                DexLabel L57=new DexLabel();
                ddv.visitEndLocal(0,L57);
                ddv.visitEndLocal(4,L57);
                DexLabel L58=new DexLabel();
                ddv.visitLineNumber(133,L58);
                ddv.visitStartLocal(0,L58,"t","Ljava/lang/String;",null);
                ddv.visitLineNumber(135,L2);
                ddv.visitEndLocal(5,L2);
                ddv.visitEndLocal(2,L2);
                DexLabel L59=new DexLabel();
                ddv.visitStartLocal(1,L59,"t","Ljava/lang/String;",null);
                DexLabel L60=new DexLabel();
                ddv.visitLineNumber(137,L60);
                ddv.visitStartLocal(0,L60,"e","Ljava/lang/Exception;",null);
                DexLabel L61=new DexLabel();
                ddv.visitLineNumber(138,L61);
                DexLabel L62=new DexLabel();
                ddv.visitEndLocal(1,L62);
                ddv.visitStartLocal(0,L62,"t","Ljava/lang/String;",null);
                DexLabel L63=new DexLabel();
                ddv.visitLineNumber(140,L63);
                DexLabel L64=new DexLabel();
                ddv.visitLineNumber(141,L64);
                ddv.visitEndLocal(6,L64);
                ddv.visitEndLocal(0,L64);
                DexLabel L65=new DexLabel();
                ddv.visitEndLocal(14,L65);
                ddv.visitLineNumber(135,L5);
                ddv.visitRestartLocal(5,L5);
                ddv.visitRestartLocal(6,L5);
                ddv.visitRestartLocal(14,L5);
                DexLabel L66=new DexLabel();
                ddv.visitRestartLocal(1,L66);
                DexLabel L67=new DexLabel();
                ddv.visitEndLocal(1,L67);
                ddv.visitStartLocal(0,L67,"first","J",null);
                ddv.visitRestartLocal(2,L67);
                code.visitLabel(L6);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L7);
                code.visitStmt2R(MOVE_OBJECT,1,0);
                code.visitLabel(L8);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 14},new Method("Ljava/util/Enumeration;","hasMoreElements",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_EQZ,0,-1,L64);
                code.visitLabel(L9);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 14},new Method("Ljava/util/Enumeration;","nextElement",new String[]{ },"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitTypeStmt(CHECK_CAST,0,-1,"Ljava/lang/String;");
                code.visitLabel(L10);
                code.visitTypeStmt(NEW_INSTANCE,6,-1,"Ljava/util/StringTokenizer;");
                code.visitConstStmt(CONST_STRING,2,"=,");
                code.visitConstStmt(CONST_4,3, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 6,0,2,3},new Method("Ljava/util/StringTokenizer;","<init>",new String[]{ "Ljava/lang/String;","Ljava/lang/String;","Z"},"V"));
                code.visitLabel(L11);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L12);
                code.visitStmt2R(MOVE_OBJECT,7,1);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Ljava/util/StringTokenizer;","hasMoreTokens",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitJumpStmt(IF_EQZ,1,-1,L62);
                code.visitLabel(L13);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Ljava/util/StringTokenizer;","nextToken",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/lang/String;","trim",new String[]{ },"Ljava/lang/String;"));
                code.visitLabel(L1);
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitLabel(L14);
                code.visitConstStmt(CONST_WIDE_16,1,Long.valueOf(-1L)); // long: 0xffffffffffffffff  double:NaN
                code.visitLabel(L15);
                code.visitConstStmt(CONST_WIDE_16,3,Long.valueOf(-1L)); // long: 0xffffffffffffffff  double:NaN
                code.visitLabel(L16);
                code.visitConstStmt(CONST_16,0, Integer.valueOf(45)); // int: 0x0000002d  float:0.000000
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,0},new Method("Ljava/lang/String;","indexOf",new String[]{ "I"},"I"));
                code.visitLabel(L17);
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitLabel(L18);
                code.visitJumpStmt(IF_LTZ,0,-1,L19);
                code.visitConstStmt(CONST_STRING,8,"-");
                code.visitStmt2R1N(ADD_INT_LIT8,9,0,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,8,9},new Method("Ljava/lang/String;","indexOf",new String[]{ "Ljava/lang/String;","I"},"I"));
                code.visitStmt1R(MOVE_RESULT,8);
                code.visitJumpStmt(IF_LTZ,8,-1,L24);
                code.visitLabel(L19);
                code.visitConstStmt(CONST_STRING,0,"bytes");
                code.visitLabel(L20);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,5},new Method("Ljava/lang/String;","equals",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_EQZ,0,-1,L22);
                code.visitStmt2R(MOVE_OBJECT,0,5);
                code.visitLabel(L21);
                code.visitJumpStmt(GOTO,-1,-1,L0);
                code.visitLabel(L22);
                code.visitConstStmt(CONST_STRING,0,"Bad range format: {}");
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0,5},new Method("Lorg/mortbay/log/Log;","warn",new String[]{ "Ljava/lang/String;","Ljava/lang/Object;"},"V"));
                code.visitStmt2R(MOVE_OBJECT,1,7);
                code.visitLabel(L23);
                code.visitJumpStmt(GOTO,-1,-1,L8);
                code.visitLabel(L24);
                code.visitJumpStmt(IF_NEZ,0,-1,L38);
                code.visitLabel(L25);
                code.visitStmt2R1N(ADD_INT_LIT8,3,0,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Ljava/lang/String;","length",new String[]{ },"I"));
                code.visitLabel(L26);
                code.visitStmt1R(MOVE_RESULT,4);
                code.visitJumpStmt(IF_GE,3,4,L35);
                code.visitLabel(L27);
                code.visitStmt2R1N(ADD_INT_LIT8,0,0,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,0},new Method("Ljava/lang/String;","substring",new String[]{ "I"},"Ljava/lang/String;"));
                code.visitLabel(L28);
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/lang/String;","trim",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0},new Method("Ljava/lang/Long;","parseLong",new String[]{ "Ljava/lang/String;"},"J"));
                code.visitStmt1R(MOVE_RESULT_WIDE,3);
                code.visitLabel(L29);
                code.visitStmt2R(MOVE_WIDE,10,3);
                code.visitLabel(L30);
                code.visitStmt2R(MOVE_WIDE,12,1);
                code.visitLabel(L31);
                code.visitStmt2R(MOVE_WIDE,0,12);
                code.visitLabel(L32);
                code.visitStmt2R(MOVE_WIDE,2,10);
                code.visitLabel(L33);
                code.visitConstStmt(CONST_WIDE_16,8,Long.valueOf(-1L)); // long: 0xffffffffffffffff  double:NaN
                code.visitStmt3R(CMP_LONG,4,0,8);
                code.visitJumpStmt(IF_NEZ,4,-1,L52);
                code.visitConstStmt(CONST_WIDE_16,8,Long.valueOf(-1L)); // long: 0xffffffffffffffff  double:NaN
                code.visitStmt3R(CMP_LONG,4,2,8);
                code.visitJumpStmt(IF_NEZ,4,-1,L52);
                code.visitStmt2R(MOVE_OBJECT,1,7);
                code.visitLabel(L34);
                code.visitJumpStmt(GOTO,-1,-1,L8);
                code.visitLabel(L35);
                code.visitConstStmt(CONST_STRING,0,"Bad range format: {}");
                code.visitLabel(L36);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0,5},new Method("Lorg/mortbay/log/Log;","warn",new String[]{ "Ljava/lang/String;","Ljava/lang/Object;"},"V"));
                code.visitStmt2R(MOVE_OBJECT,1,7);
                code.visitLabel(L37);
                code.visitJumpStmt(GOTO,-1,-1,L8);
                code.visitLabel(L38);
                code.visitStmt2R1N(ADD_INT_LIT8,1,0,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Ljava/lang/String;","length",new String[]{ },"I"));
                code.visitLabel(L39);
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitJumpStmt(IF_GE,1,2,L48);
                code.visitLabel(L40);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,1,0},new Method("Ljava/lang/String;","substring",new String[]{ "I","I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/lang/String;","trim",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1},new Method("Ljava/lang/Long;","parseLong",new String[]{ "Ljava/lang/String;"},"J"));
                code.visitStmt1R(MOVE_RESULT_WIDE,1);
                code.visitLabel(L41);
                code.visitStmt2R1N(ADD_INT_LIT8,0,0,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,0},new Method("Ljava/lang/String;","substring",new String[]{ "I"},"Ljava/lang/String;"));
                code.visitLabel(L42);
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/lang/String;","trim",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0},new Method("Ljava/lang/Long;","parseLong",new String[]{ "Ljava/lang/String;"},"J"));
                code.visitStmt1R(MOVE_RESULT_WIDE,3);
                code.visitLabel(L43);
                code.visitStmt2R(MOVE_WIDE,10,3);
                code.visitLabel(L44);
                code.visitStmt2R(MOVE_WIDE,12,1);
                code.visitLabel(L45);
                code.visitStmt2R(MOVE_WIDE,0,12);
                code.visitLabel(L46);
                code.visitStmt2R(MOVE_WIDE,2,10);
                code.visitLabel(L47);
                code.visitJumpStmt(GOTO,-1,-1,L33);
                code.visitLabel(L48);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,1,0},new Method("Ljava/lang/String;","substring",new String[]{ "I","I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L49);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/lang/String;","trim",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0},new Method("Ljava/lang/Long;","parseLong",new String[]{ "Ljava/lang/String;"},"J"));
                code.visitStmt1R(MOVE_RESULT_WIDE,0);
                code.visitLabel(L50);
                code.visitStmt2R(MOVE_WIDE,2,3);
                code.visitLabel(L51);
                code.visitJumpStmt(GOTO,-1,-1,L33);
                code.visitLabel(L52);
                code.visitConstStmt(CONST_WIDE_16,8,Long.valueOf(-1L)); // long: 0xffffffffffffffff  double:NaN
                code.visitStmt3R(CMP_LONG,4,0,8);
                code.visitJumpStmt(IF_EQZ,4,-1,L54);
                code.visitConstStmt(CONST_WIDE_16,8,Long.valueOf(-1L)); // long: 0xffffffffffffffff  double:NaN
                code.visitStmt3R(CMP_LONG,4,2,8);
                code.visitJumpStmt(IF_EQZ,4,-1,L54);
                code.visitStmt3R(CMP_LONG,4,0,2);
                code.visitJumpStmt(IF_LEZ,4,-1,L54);
                code.visitStmt2R(MOVE_OBJECT,1,7);
                code.visitLabel(L53);
                code.visitJumpStmt(GOTO_16,-1,-1,L8);
                code.visitLabel(L54);
                code.visitStmt3R(CMP_LONG,4,0,15);
                code.visitJumpStmt(IF_GEZ,4,-1,L67);
                code.visitLabel(L55);
                code.visitTypeStmt(NEW_INSTANCE,4,-1,"Lorg/mortbay/jetty/InclusiveByteRange;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 4,0,1,2,3},new Method("Lorg/mortbay/jetty/InclusiveByteRange;","<init>",new String[]{ "J","J"},"V"));
                code.visitLabel(L56);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 7,4},new Method("Lorg/mortbay/util/LazyList;","add",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitLabel(L4);
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L57);
                code.visitStmt2R(MOVE_OBJECT,7,0);
                code.visitStmt2R(MOVE_OBJECT,0,5);
                code.visitLabel(L58);
                code.visitJumpStmt(GOTO_16,-1,-1,L0);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,1);
                code.visitStmt2R(MOVE_OBJECT,10,1);
                code.visitStmt2R(MOVE_OBJECT,1,0);
                code.visitLabel(L59);
                code.visitStmt2R(MOVE_OBJECT,0,10);
                code.visitLabel(L60);
                code.visitTypeStmt(NEW_INSTANCE,2,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,3,"Bad range format: ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 2},new Method("Lorg/mortbay/log/Log;","warn",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L61);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0},new Method("Lorg/mortbay/log/Log;","ignore",new String[]{ "Ljava/lang/Throwable;"},"V"));
                code.visitStmt2R(MOVE_OBJECT,0,1);
                code.visitLabel(L62);
                code.visitStmt2R(MOVE_OBJECT,1,7);
                code.visitLabel(L63);
                code.visitJumpStmt(GOTO_16,-1,-1,L8);
                code.visitLabel(L64);
                code.visitConstStmt(CONST_4,14, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1,14},new Method("Lorg/mortbay/util/LazyList;","getList",new String[]{ "Ljava/lang/Object;","Z"},"Ljava/util/List;"));
                code.visitLabel(L65);
                code.visitStmt1R(MOVE_RESULT_OBJECT,14);
                code.visitStmt1R(RETURN_OBJECT,14);
                code.visitLabel(L5);
                code.visitStmt1R(MOVE_EXCEPTION,0);
                code.visitStmt2R(MOVE_OBJECT,1,5);
                code.visitLabel(L66);
                code.visitJumpStmt(GOTO,-1,-1,L60);
                code.visitLabel(L67);
                code.visitStmt2R(MOVE_OBJECT,0,7);
                code.visitJumpStmt(GOTO,-1,-1,L57);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m002_to416HeaderRangeString(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Lorg/mortbay/jetty/InclusiveByteRange;","to416HeaderRangeString",new String[]{ "J"},"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"size");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(191,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(192,L1);
                ddv.visitStartLocal(0,L1,"sb","Ljava/lang/StringBuffer;",null);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(193,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(194,L3);
                code.visitLabel(L0);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/lang/StringBuffer;");
                code.visitConstStmt(CONST_16,1, Integer.valueOf(40)); // int: 0x00000028  float:0.000000
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1},new Method("Ljava/lang/StringBuffer;","<init>",new String[]{ "I"},"V"));
                code.visitLabel(L1);
                code.visitConstStmt(CONST_STRING,1,"bytes */");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,2,3},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "J"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/lang/StringBuffer;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitStmt1R(RETURN_OBJECT,1);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m003_getFirst(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/InclusiveByteRange;","getFirst",new String[]{ },"J"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(58,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_WIDE,0,2,new Field("Lorg/mortbay/jetty/InclusiveByteRange;","first","J"));
                code.visitStmt1R(RETURN_WIDE,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m004_getFirst(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/InclusiveByteRange;","getFirst",new String[]{ "J"},"J"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(9);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"size");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(147,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(149,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(150,L3);
                ddv.visitStartLocal(0,L3,"tf","J",null);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(151,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(154,L5);
                ddv.visitEndLocal(0,L5);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_WIDE_16,4,Long.valueOf(0L)); // long: 0x0000000000000000  double:0.000000
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_WIDE,2,6,new Field("Lorg/mortbay/jetty/InclusiveByteRange;","first","J"));
                code.visitStmt3R(CMP_LONG,2,2,4);
                DexLabel L6=new DexLabel();
                code.visitJumpStmt(IF_GEZ,2,-1,L6);
                code.visitLabel(L2);
                code.visitFieldStmt(IGET_WIDE,2,6,new Field("Lorg/mortbay/jetty/InclusiveByteRange;","last","J"));
                code.visitStmt3R(SUB_LONG,0,7,2);
                code.visitLabel(L3);
                code.visitStmt3R(CMP_LONG,2,0,4);
                DexLabel L7=new DexLabel();
                code.visitJumpStmt(IF_GEZ,2,-1,L7);
                code.visitLabel(L4);
                code.visitConstStmt(CONST_WIDE_16,0,Long.valueOf(0L)); // long: 0x0000000000000000  double:0.000000
                code.visitLabel(L7);
                code.visitStmt2R(MOVE_WIDE,2,0);
                code.visitLabel(L5);
                code.visitStmt1R(RETURN_WIDE,2);
                code.visitLabel(L6);
                code.visitFieldStmt(IGET_WIDE,2,6,new Field("Lorg/mortbay/jetty/InclusiveByteRange;","first","J"));
                code.visitJumpStmt(GOTO,-1,-1,L5);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m005_getLast(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/InclusiveByteRange;","getLast",new String[]{ },"J"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(63,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_WIDE,0,2,new Field("Lorg/mortbay/jetty/InclusiveByteRange;","last","J"));
                code.visitStmt1R(RETURN_WIDE,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m006_getLast(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/InclusiveByteRange;","getLast",new String[]{ "J"},"J"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(9);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"size");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(160,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(161,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(165,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(163,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(164,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(165,L6);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_WIDE_16,4,Long.valueOf(1L)); // long: 0x0000000000000001  double:0.000000
                code.visitConstStmt(CONST_WIDE_16,2,Long.valueOf(0L)); // long: 0x0000000000000000  double:0.000000
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_WIDE,0,6,new Field("Lorg/mortbay/jetty/InclusiveByteRange;","first","J"));
                code.visitStmt3R(CMP_LONG,0,0,2);
                code.visitJumpStmt(IF_GEZ,0,-1,L4);
                code.visitLabel(L2);
                code.visitStmt3R(SUB_LONG,0,7,4);
                code.visitLabel(L3);
                code.visitStmt1R(RETURN_WIDE,0);
                code.visitLabel(L4);
                code.visitFieldStmt(IGET_WIDE,0,6,new Field("Lorg/mortbay/jetty/InclusiveByteRange;","last","J"));
                code.visitStmt3R(CMP_LONG,0,0,2);
                code.visitJumpStmt(IF_LTZ,0,-1,L5);
                code.visitFieldStmt(IGET_WIDE,0,6,new Field("Lorg/mortbay/jetty/InclusiveByteRange;","last","J"));
                code.visitStmt3R(CMP_LONG,0,0,7);
                code.visitJumpStmt(IF_LTZ,0,-1,L6);
                code.visitLabel(L5);
                code.visitStmt3R(SUB_LONG,0,7,4);
                code.visitJumpStmt(GOTO,-1,-1,L3);
                code.visitLabel(L6);
                code.visitFieldStmt(IGET_WIDE,0,6,new Field("Lorg/mortbay/jetty/InclusiveByteRange;","last","J"));
                code.visitJumpStmt(GOTO,-1,-1,L3);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m007_getSize(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/InclusiveByteRange;","getSize",new String[]{ "J"},"J"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(7);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"size");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(171,L0);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,5,6},new Method("Lorg/mortbay/jetty/InclusiveByteRange;","getLast",new String[]{ "J"},"J"));
                code.visitStmt1R(MOVE_RESULT_WIDE,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,5,6},new Method("Lorg/mortbay/jetty/InclusiveByteRange;","getFirst",new String[]{ "J"},"J"));
                code.visitStmt1R(MOVE_RESULT_WIDE,2);
                code.visitStmt2R(SUB_LONG_2ADDR,0,2);
                code.visitConstStmt(CONST_WIDE_16,2,Long.valueOf(1L)); // long: 0x0000000000000001  double:0.000000
                code.visitStmt2R(ADD_LONG_2ADDR,0,2);
                code.visitStmt1R(RETURN_WIDE,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m008_toHeaderRangeString(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/InclusiveByteRange;","toHeaderRangeString",new String[]{ "J"},"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(6);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"size");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(178,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(179,L1);
                ddv.visitStartLocal(0,L1,"sb","Ljava/lang/StringBuffer;",null);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(180,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(181,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(182,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(183,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(184,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(185,L7);
                code.visitLabel(L0);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/lang/StringBuffer;");
                code.visitConstStmt(CONST_16,1, Integer.valueOf(40)); // int: 0x00000028  float:0.000000
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1},new Method("Ljava/lang/StringBuffer;","<init>",new String[]{ "I"},"V"));
                code.visitLabel(L1);
                code.visitConstStmt(CONST_STRING,1,"bytes ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,4,5},new Method("Lorg/mortbay/jetty/InclusiveByteRange;","getFirst",new String[]{ "J"},"J"));
                code.visitStmt1R(MOVE_RESULT_WIDE,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1,2},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "J"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L3);
                code.visitConstStmt(CONST_16,1, Integer.valueOf(45)); // int: 0x0000002d  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "C"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,4,5},new Method("Lorg/mortbay/jetty/InclusiveByteRange;","getLast",new String[]{ "J"},"J"));
                code.visitStmt1R(MOVE_RESULT_WIDE,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1,2},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "J"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L5);
                code.visitConstStmt(CONST_STRING,1,"/");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,4,5},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "J"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/lang/StringBuffer;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitStmt1R(RETURN_OBJECT,1);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m009_toString(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/InclusiveByteRange;","toString",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(201,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(202,L1);
                ddv.visitStartLocal(0,L1,"sb","Ljava/lang/StringBuffer;",null);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(203,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(204,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(205,L4);
                code.visitLabel(L0);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/lang/StringBuffer;");
                code.visitConstStmt(CONST_16,1, Integer.valueOf(60)); // int: 0x0000003c  float:0.000000
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1},new Method("Ljava/lang/StringBuffer;","<init>",new String[]{ "I"},"V"));
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_WIDE,1,3,new Field("Lorg/mortbay/jetty/InclusiveByteRange;","first","J"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1,2},new Method("Ljava/lang/Long;","toString",new String[]{ "J"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L2);
                code.visitConstStmt(CONST_STRING,1,":");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_WIDE,1,3,new Field("Lorg/mortbay/jetty/InclusiveByteRange;","last","J"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1,2},new Method("Ljava/lang/Long;","toString",new String[]{ "J"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/lang/StringBuffer;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitStmt1R(RETURN_OBJECT,1);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
