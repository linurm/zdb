package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0337_org_mortbay_jetty_servlet_HashSessionManager_Session {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(ACC_PUBLIC,"Lorg/mortbay/jetty/servlet/HashSessionManager$Session;","Lorg/mortbay/jetty/servlet/AbstractSessionManager$Session;",new String[]{ });
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("HashSessionManager.java");
        if(cv!=null){
            DexAnnotationVisitor av00 = cv.visitAnnotation("Ldalvik/annotation/EnclosingClass;", Visibility.SYSTEM);
            if(av00 != null) {
                av00.visit("value", new DexType("Lorg/mortbay/jetty/servlet/HashSessionManager;"));
                av00.visitEnd();
            }
        }
        if(cv!=null){
            DexAnnotationVisitor av00 = cv.visitAnnotation("Ldalvik/annotation/InnerClass;", Visibility.SYSTEM);
            if(av00 != null) {
                av00.visit("accessFlags",  Integer.valueOf(4));
                av00.visit("name", "Session");
                av00.visitEnd();
            }
        }
        f000_serialVersionUID(cv);
        f001_this$0(cv);
        m000__init_(cv);
        m001__init_(cv);
        m002_invalidate(cv);
        m003_newAttributeMap(cv);
        m004_remove(cv);
        m005_save(cv);
        m006_setMaxInactiveInterval(cv);
    }
    public static void f000_serialVersionUID(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/servlet/HashSessionManager$Session;","serialVersionUID","J"), Long.valueOf(-2134521374206116367L));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f001_this$0(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_FINAL|ACC_SYNTHETIC, new Field("Lorg/mortbay/jetty/servlet/HashSessionManager$Session;","this$0","Lorg/mortbay/jetty/servlet/HashSessionManager;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void m000__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/jetty/servlet/HashSessionManager$Session;","<init>",new String[]{ "Lorg/mortbay/jetty/servlet/HashSessionManager;","J","Ljava/lang/String;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(1,"created");
                ddv.visitParameterName(2,"clusterId");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(515,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(516,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(517,L2);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_OBJECT,1,0,new Field("Lorg/mortbay/jetty/servlet/HashSessionManager$Session;","this$0","Lorg/mortbay/jetty/servlet/HashSessionManager;"));
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1,2,3,4},new Method("Lorg/mortbay/jetty/servlet/AbstractSessionManager$Session;","<init>",new String[]{ "Lorg/mortbay/jetty/servlet/AbstractSessionManager;","J","Ljava/lang/String;"},"V"));
                code.visitLabel(L2);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/jetty/servlet/HashSessionManager$Session;","<init>",new String[]{ "Lorg/mortbay/jetty/servlet/HashSessionManager;","Ljavax/servlet/http/HttpServletRequest;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(1,"request");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(510,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(511,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(512,L2);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_OBJECT,1,0,new Field("Lorg/mortbay/jetty/servlet/HashSessionManager$Session;","this$0","Lorg/mortbay/jetty/servlet/HashSessionManager;"));
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1,2},new Method("Lorg/mortbay/jetty/servlet/AbstractSessionManager$Session;","<init>",new String[]{ "Lorg/mortbay/jetty/servlet/AbstractSessionManager;","Ljavax/servlet/http/HttpServletRequest;"},"V"));
                code.visitLabel(L2);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m002_invalidate(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/servlet/HashSessionManager$Session;","invalidate",new String[]{ },"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/lang/IllegalStateException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(536,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(537,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(538,L2);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_SUPER,new int[]{ 1},new Method("Lorg/mortbay/jetty/servlet/AbstractSessionManager$Session;","invalidate",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Lorg/mortbay/jetty/servlet/HashSessionManager$Session;","getId",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,0},new Method("Lorg/mortbay/jetty/servlet/HashSessionManager$Session;","remove",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L2);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m003_newAttributeMap(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Lorg/mortbay/jetty/servlet/HashSessionManager$Session;","newAttributeMap",new String[]{ },"Ljava/util/Map;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(529,L0);
                code.visitLabel(L0);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/util/HashMap;");
                code.visitConstStmt(CONST_4,1, Integer.valueOf(3)); // int: 0x00000003  float:0.000000
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1},new Method("Ljava/util/HashMap;","<init>",new String[]{ "I"},"V"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m004_remove(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/servlet/HashSessionManager$Session;","remove",new String[]{ "Ljava/lang/String;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"id");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(542,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(557,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(547,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(550,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(555,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(556,L5);
                ddv.visitStartLocal(0,L5,"f","Ljava/io/File;",null);
                code.visitLabel(L0);
                code.visitJumpStmt(IF_NEZ,3,-1,L2);
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L2);
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/jetty/servlet/HashSessionManager$Session;","this$0","Lorg/mortbay/jetty/servlet/HashSessionManager;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Lorg/mortbay/jetty/servlet/HashSessionManager;","isStopping",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitJumpStmt(IF_NEZ,1,-1,L1);
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/jetty/servlet/HashSessionManager$Session;","this$0","Lorg/mortbay/jetty/servlet/HashSessionManager;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Lorg/mortbay/jetty/servlet/HashSessionManager;","isStopped",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitJumpStmt(IF_NEZ,1,-1,L1);
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/jetty/servlet/HashSessionManager$Session;","this$0","Lorg/mortbay/jetty/servlet/HashSessionManager;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1},new Method("Lorg/mortbay/jetty/servlet/HashSessionManager;","access$200",new String[]{ "Lorg/mortbay/jetty/servlet/HashSessionManager;"},"Ljava/io/File;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitJumpStmt(IF_EQZ,1,-1,L1);
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/jetty/servlet/HashSessionManager$Session;","this$0","Lorg/mortbay/jetty/servlet/HashSessionManager;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1},new Method("Lorg/mortbay/jetty/servlet/HashSessionManager;","access$200",new String[]{ "Lorg/mortbay/jetty/servlet/HashSessionManager;"},"Ljava/io/File;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/io/File;","exists",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitJumpStmt(IF_EQZ,1,-1,L1);
                code.visitLabel(L4);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/io/File;");
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/jetty/servlet/HashSessionManager$Session;","this$0","Lorg/mortbay/jetty/servlet/HashSessionManager;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1},new Method("Lorg/mortbay/jetty/servlet/HashSessionManager;","access$200",new String[]{ "Lorg/mortbay/jetty/servlet/HashSessionManager;"},"Ljava/io/File;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1,3},new Method("Ljava/io/File;","<init>",new String[]{ "Ljava/io/File;","Ljava/lang/String;"},"V"));
                code.visitLabel(L5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/io/File;","delete",new String[]{ },"Z"));
                code.visitJumpStmt(GOTO,-1,-1,L1);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m005_save(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/servlet/HashSessionManager$Session;","save",new String[]{ "Ljava/io/FileOutputStream;"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(8);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"fos");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(561,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(562,L1);
                ddv.visitStartLocal(3,L1,"out","Ljava/io/DataOutputStream;",null);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(563,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(564,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(565,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(566,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(567,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(568,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(577,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(578,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(580,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(581,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(582,L12);
                ddv.visitStartLocal(0,L12,"itor","Ljava/util/Iterator;",null);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(584,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(585,L14);
                ddv.visitStartLocal(1,L14,"key","Ljava/lang/String;",null);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(587,L15);
                ddv.visitEndLocal(1,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(588,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(589,L17);
                ddv.visitStartLocal(2,L17,"oos","Ljava/io/ObjectOutputStream;",null);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(591,L18);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(593,L19);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(597,L20);
                ddv.visitEndLocal(0,L20);
                ddv.visitEndLocal(2,L20);
                DexLabel L21=new DexLabel();
                ddv.visitLineNumber(598,L21);
                DexLabel L22=new DexLabel();
                ddv.visitLineNumber(596,L22);
                code.visitLabel(L0);
                code.visitTypeStmt(NEW_INSTANCE,3,-1,"Ljava/io/DataOutputStream;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 3,7},new Method("Ljava/io/DataOutputStream;","<init>",new String[]{ "Ljava/io/OutputStream;"},"V"));
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,4,6,new Field("Lorg/mortbay/jetty/servlet/HashSessionManager$Session;","_clusterId","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,4},new Method("Ljava/io/DataOutputStream;","writeUTF",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L2);
                code.visitFieldStmt(IGET_OBJECT,4,6,new Field("Lorg/mortbay/jetty/servlet/HashSessionManager$Session;","_nodeId","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,4},new Method("Ljava/io/DataOutputStream;","writeUTF",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_BOOLEAN,4,6,new Field("Lorg/mortbay/jetty/servlet/HashSessionManager$Session;","_idChanged","Z"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,4},new Method("Ljava/io/DataOutputStream;","writeBoolean",new String[]{ "Z"},"V"));
                code.visitLabel(L4);
                code.visitFieldStmt(IGET_WIDE,4,6,new Field("Lorg/mortbay/jetty/servlet/HashSessionManager$Session;","_created","J"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,4,5},new Method("Ljava/io/DataOutputStream;","writeLong",new String[]{ "J"},"V"));
                code.visitLabel(L5);
                code.visitFieldStmt(IGET_WIDE,4,6,new Field("Lorg/mortbay/jetty/servlet/HashSessionManager$Session;","_cookieSet","J"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,4,5},new Method("Ljava/io/DataOutputStream;","writeLong",new String[]{ "J"},"V"));
                code.visitLabel(L6);
                code.visitFieldStmt(IGET_WIDE,4,6,new Field("Lorg/mortbay/jetty/servlet/HashSessionManager$Session;","_accessed","J"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,4,5},new Method("Ljava/io/DataOutputStream;","writeLong",new String[]{ "J"},"V"));
                code.visitLabel(L7);
                code.visitFieldStmt(IGET_WIDE,4,6,new Field("Lorg/mortbay/jetty/servlet/HashSessionManager$Session;","_lastAccessed","J"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,4,5},new Method("Ljava/io/DataOutputStream;","writeLong",new String[]{ "J"},"V"));
                code.visitLabel(L8);
                code.visitFieldStmt(IGET,4,6,new Field("Lorg/mortbay/jetty/servlet/HashSessionManager$Session;","_requests","I"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,4},new Method("Ljava/io/DataOutputStream;","writeInt",new String[]{ "I"},"V"));
                code.visitLabel(L9);
                code.visitFieldStmt(IGET_OBJECT,4,6,new Field("Lorg/mortbay/jetty/servlet/HashSessionManager$Session;","_values","Ljava/util/Map;"));
                code.visitJumpStmt(IF_EQZ,4,-1,L22);
                code.visitLabel(L10);
                code.visitFieldStmt(IGET_OBJECT,4,6,new Field("Lorg/mortbay/jetty/servlet/HashSessionManager$Session;","_values","Ljava/util/Map;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 4},new Method("Ljava/util/Map;","size",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,4},new Method("Ljava/io/DataOutputStream;","writeInt",new String[]{ "I"},"V"));
                code.visitLabel(L11);
                code.visitFieldStmt(IGET_OBJECT,4,6,new Field("Lorg/mortbay/jetty/servlet/HashSessionManager$Session;","_values","Ljava/util/Map;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 4},new Method("Ljava/util/Map;","keySet",new String[]{ },"Ljava/util/Set;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 4},new Method("Ljava/util/Set;","iterator",new String[]{ },"Ljava/util/Iterator;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L12);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0},new Method("Ljava/util/Iterator;","hasNext",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,4);
                code.visitJumpStmt(IF_EQZ,4,-1,L15);
                code.visitLabel(L13);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0},new Method("Ljava/util/Iterator;","next",new String[]{ },"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitTypeStmt(CHECK_CAST,1,-1,"Ljava/lang/String;");
                code.visitLabel(L14);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,1},new Method("Ljava/io/DataOutputStream;","writeUTF",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L12);
                code.visitLabel(L15);
                code.visitFieldStmt(IGET_OBJECT,4,6,new Field("Lorg/mortbay/jetty/servlet/HashSessionManager$Session;","_values","Ljava/util/Map;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 4},new Method("Ljava/util/Map;","values",new String[]{ },"Ljava/util/Collection;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 4},new Method("Ljava/util/Collection;","iterator",new String[]{ },"Ljava/util/Iterator;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L16);
                code.visitTypeStmt(NEW_INSTANCE,2,-1,"Ljava/io/ObjectOutputStream;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2,3},new Method("Ljava/io/ObjectOutputStream;","<init>",new String[]{ "Ljava/io/OutputStream;"},"V"));
                code.visitLabel(L17);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0},new Method("Ljava/util/Iterator;","hasNext",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,4);
                code.visitJumpStmt(IF_EQZ,4,-1,L19);
                code.visitLabel(L18);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0},new Method("Ljava/util/Iterator;","next",new String[]{ },"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,4},new Method("Ljava/io/ObjectOutputStream;","writeObject",new String[]{ "Ljava/lang/Object;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L17);
                code.visitLabel(L19);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Ljava/io/ObjectOutputStream;","close",new String[]{ },"V"));
                code.visitLabel(L20);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Ljava/io/DataOutputStream;","close",new String[]{ },"V"));
                code.visitLabel(L21);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L22);
                code.visitConstStmt(CONST_4,4, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,4},new Method("Ljava/io/DataOutputStream;","writeInt",new String[]{ "I"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L20);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m006_setMaxInactiveInterval(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/servlet/HashSessionManager$Session;","setMaxInactiveInterval",new String[]{ "I"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(6);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"secs");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(521,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(522,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(523,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(524,L3);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_SUPER,new int[]{ 4,5},new Method("Lorg/mortbay/jetty/servlet/AbstractSessionManager$Session;","setMaxInactiveInterval",new String[]{ "I"},"V"));
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_WIDE,0,4,new Field("Lorg/mortbay/jetty/servlet/HashSessionManager$Session;","_maxIdleMs","J"));
                code.visitConstStmt(CONST_WIDE_16,2,Long.valueOf(0L)); // long: 0x0000000000000000  double:0.000000
                code.visitStmt3R(CMP_LONG,0,0,2);
                code.visitJumpStmt(IF_LEZ,0,-1,L3);
                code.visitFieldStmt(IGET_WIDE,0,4,new Field("Lorg/mortbay/jetty/servlet/HashSessionManager$Session;","_maxIdleMs","J"));
                code.visitConstStmt(CONST_WIDE_16,2,Long.valueOf(10L)); // long: 0x000000000000000a  double:0.000000
                code.visitStmt2R(DIV_LONG_2ADDR,0,2);
                code.visitFieldStmt(IGET_OBJECT,2,4,new Field("Lorg/mortbay/jetty/servlet/HashSessionManager$Session;","this$0","Lorg/mortbay/jetty/servlet/HashSessionManager;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 2},new Method("Lorg/mortbay/jetty/servlet/HashSessionManager;","access$100",new String[]{ "Lorg/mortbay/jetty/servlet/HashSessionManager;"},"I"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitStmt2R(INT_TO_LONG,2,2);
                code.visitStmt3R(CMP_LONG,0,0,2);
                code.visitJumpStmt(IF_GEZ,0,-1,L3);
                code.visitLabel(L2);
                code.visitFieldStmt(IGET_OBJECT,0,4,new Field("Lorg/mortbay/jetty/servlet/HashSessionManager$Session;","this$0","Lorg/mortbay/jetty/servlet/HashSessionManager;"));
                code.visitStmt2R1N(ADD_INT_LIT8,1,5,9);
                code.visitStmt2R1N(DIV_INT_LIT8,1,1,10);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Lorg/mortbay/jetty/servlet/HashSessionManager;","setScavengePeriod",new String[]{ "I"},"V"));
                code.visitLabel(L3);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
