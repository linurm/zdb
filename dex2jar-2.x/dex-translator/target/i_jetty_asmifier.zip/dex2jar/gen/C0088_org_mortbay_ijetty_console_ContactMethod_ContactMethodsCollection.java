package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0088_org_mortbay_ijetty_console_ContactMethod_ContactMethodsCollection {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(ACC_PUBLIC,"Lorg/mortbay/ijetty/console/ContactMethod$ContactMethodsCollection;","Lorg/mortbay/ijetty/console/DatabaseCollection;",new String[]{ });
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("ContactMethod.java");
        if(cv!=null){
            DexAnnotationVisitor av00 = cv.visitAnnotation("Ldalvik/annotation/EnclosingClass;", Visibility.SYSTEM);
            if(av00 != null) {
                av00.visit("value", new DexType("Lorg/mortbay/ijetty/console/ContactMethod;"));
                av00.visitEnd();
            }
        }
        if(cv!=null){
            DexAnnotationVisitor av00 = cv.visitAnnotation("Ldalvik/annotation/InnerClass;", Visibility.SYSTEM);
            if(av00 != null) {
                av00.visit("accessFlags",  Integer.valueOf(9));
                av00.visit("name", "ContactMethodsCollection");
                av00.visitEnd();
            }
        }
        m000__init_(cv);
        m001_cursorToValues(cv);
    }
    public static void m000__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/ijetty/console/ContactMethod$ContactMethodsCollection;","<init>",new String[]{ "Landroid/database/Cursor;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"cursor");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(43,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(44,L1);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1},new Method("Lorg/mortbay/ijetty/console/DatabaseCollection;","<init>",new String[]{ "Landroid/database/Cursor;"},"V"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001_cursorToValues(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/ijetty/console/ContactMethod$ContactMethodsCollection;","cursorToValues",new String[]{ "Landroid/database/Cursor;"},"Landroid/content/ContentValues;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(11);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"cursor");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(47,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(48,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(66,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(50,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(52,L5);
                ddv.visitStartLocal(2,L5,"values","Landroid/content/ContentValues;",null);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(53,L6);
                ddv.visitStartLocal(1,L6,"val","Ljava/lang/String;",null);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(54,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(55,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(56,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(57,L10);
                ddv.visitRestartLocal(1,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(58,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(59,L12);
                ddv.visitRestartLocal(1,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(60,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(61,L14);
                ddv.visitStartLocal(0,L14,"intVal","Ljava/lang/Integer;",null);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(62,L15);
                DexLabel L16=new DexLabel();
                ddv.visitEndLocal(0,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(63,L17);
                ddv.visitRestartLocal(0,L17);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(64,L18);
                DexLabel L19=new DexLabel();
                ddv.visitEndLocal(0,L19);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(65,L20);
                ddv.visitRestartLocal(0,L20);
                DexLabel L21=new DexLabel();
                ddv.visitLineNumber(66,L21);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_STRING,8,"kind");
                code.visitConstStmt(CONST_STRING,7,"isprimary");
                code.visitConstStmt(CONST_STRING,6,"data");
                code.visitConstStmt(CONST_STRING,5,"aux_data");
                code.visitConstStmt(CONST_STRING,4,"_id");
                code.visitLabel(L1);
                code.visitJumpStmt(IF_NEZ,10,-1,L4);
                code.visitLabel(L2);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L3);
                code.visitStmt1R(RETURN_OBJECT,3);
                code.visitLabel(L4);
                code.visitTypeStmt(NEW_INSTANCE,2,-1,"Landroid/content/ContentValues;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2},new Method("Landroid/content/ContentValues;","<init>",new String[]{ },"V"));
                code.visitLabel(L5);
                code.visitConstStmt(CONST_STRING,3,"_id");
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 10,4},new Method("Landroid/database/Cursor;","getColumnIndex",new String[]{ "Ljava/lang/String;"},"I"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 10,3},new Method("Landroid/database/Cursor;","getString",new String[]{ "I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L6);
                code.visitConstStmt(CONST_STRING,3,"_id");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,4,1},new Method("Landroid/content/ContentValues;","put",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"V"));
                code.visitLabel(L7);
                code.visitConstStmt(CONST_STRING,3,"data");
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 10,6},new Method("Landroid/database/Cursor;","getColumnIndex",new String[]{ "Ljava/lang/String;"},"I"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 10,3},new Method("Landroid/database/Cursor;","getString",new String[]{ "I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L8);
                code.visitConstStmt(CONST_STRING,3,"data");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,6,1},new Method("Landroid/content/ContentValues;","put",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"V"));
                code.visitLabel(L9);
                code.visitConstStmt(CONST_STRING,3,"aux_data");
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 10,5},new Method("Landroid/database/Cursor;","getColumnIndex",new String[]{ "Ljava/lang/String;"},"I"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 10,3},new Method("Landroid/database/Cursor;","getString",new String[]{ "I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L10);
                code.visitConstStmt(CONST_STRING,3,"aux_data");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,5,1},new Method("Landroid/content/ContentValues;","put",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"V"));
                code.visitLabel(L11);
                code.visitConstStmt(CONST_STRING,3,"label");
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 10,3},new Method("Landroid/database/Cursor;","getColumnIndex",new String[]{ "Ljava/lang/String;"},"I"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 10,3},new Method("Landroid/database/Cursor;","getString",new String[]{ "I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L12);
                code.visitConstStmt(CONST_STRING,3,"label");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3,1},new Method("Landroid/content/ContentValues;","put",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"V"));
                code.visitLabel(L13);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/lang/Integer;");
                code.visitConstStmt(CONST_STRING,3,"isprimary");
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 10,7},new Method("Landroid/database/Cursor;","getColumnIndex",new String[]{ "Ljava/lang/String;"},"I"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 10,3},new Method("Landroid/database/Cursor;","getInt",new String[]{ "I"},"I"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,3},new Method("Ljava/lang/Integer;","<init>",new String[]{ "I"},"V"));
                code.visitLabel(L14);
                code.visitConstStmt(CONST_STRING,3,"isprimary");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,7,0},new Method("Landroid/content/ContentValues;","put",new String[]{ "Ljava/lang/String;","Ljava/lang/Integer;"},"V"));
                code.visitLabel(L15);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/lang/Integer;");
                code.visitLabel(L16);
                code.visitConstStmt(CONST_STRING,3,"kind");
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 10,8},new Method("Landroid/database/Cursor;","getColumnIndex",new String[]{ "Ljava/lang/String;"},"I"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 10,3},new Method("Landroid/database/Cursor;","getString",new String[]{ "I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,3},new Method("Ljava/lang/Integer;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L17);
                code.visitConstStmt(CONST_STRING,3,"kind");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,8,0},new Method("Landroid/content/ContentValues;","put",new String[]{ "Ljava/lang/String;","Ljava/lang/Integer;"},"V"));
                code.visitLabel(L18);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/lang/Integer;");
                code.visitLabel(L19);
                code.visitConstStmt(CONST_STRING,3,"type");
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 10,3},new Method("Landroid/database/Cursor;","getColumnIndex",new String[]{ "Ljava/lang/String;"},"I"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 10,3},new Method("Landroid/database/Cursor;","getString",new String[]{ "I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,3},new Method("Ljava/lang/Integer;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L20);
                code.visitConstStmt(CONST_STRING,3,"type");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3,0},new Method("Landroid/content/ContentValues;","put",new String[]{ "Ljava/lang/String;","Ljava/lang/Integer;"},"V"));
                code.visitStmt2R(MOVE_OBJECT,3,2);
                code.visitLabel(L21);
                code.visitJumpStmt(GOTO,-1,-1,L3);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
