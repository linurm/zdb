package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0236_org_mortbay_jetty_client_webdav_WebdavSupportedExchange {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(ACC_PUBLIC,"Lorg/mortbay/jetty/client/webdav/WebdavSupportedExchange;","Lorg/mortbay/jetty/client/HttpExchange;",new String[]{ });
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("WebdavSupportedExchange.java");
        f000__isComplete(cv);
        f001__webdavSupported(cv);
        m000__init_(cv);
        m001_isWebdavSupported(cv);
        m002_onResponseComplete(cv);
        m003_onResponseHeader(cv);
        m004_waitTilCompletion(cv);
    }
    public static void f000__isComplete(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/client/webdav/WebdavSupportedExchange;","_isComplete","Z"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f001__webdavSupported(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/client/webdav/WebdavSupportedExchange;","_webdavSupported","Z"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void m000__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/jetty/client/webdav/WebdavSupportedExchange;","<init>",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(24,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(26,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(27,L3);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1},new Method("Lorg/mortbay/jetty/client/HttpExchange;","<init>",new String[]{ },"V"));
                code.visitLabel(L2);
                code.visitFieldStmt(IPUT_BOOLEAN,0,1,new Field("Lorg/mortbay/jetty/client/webdav/WebdavSupportedExchange;","_webdavSupported","Z"));
                code.visitLabel(L3);
                code.visitFieldStmt(IPUT_BOOLEAN,0,1,new Field("Lorg/mortbay/jetty/client/webdav/WebdavSupportedExchange;","_isComplete","Z"));
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001_isWebdavSupported(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/client/webdav/WebdavSupportedExchange;","isWebdavSupported",new String[]{ },"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(64,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_BOOLEAN,0,1,new Field("Lorg/mortbay/jetty/client/webdav/WebdavSupportedExchange;","_webdavSupported","Z"));
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m002_onResponseComplete(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Lorg/mortbay/jetty/client/webdav/WebdavSupportedExchange;","onResponseComplete",new String[]{ },"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(57,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(59,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(60,L2);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitFieldStmt(IPUT_BOOLEAN,0,1,new Field("Lorg/mortbay/jetty/client/webdav/WebdavSupportedExchange;","_isComplete","Z"));
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_SUPER,new int[]{ 1},new Method("Lorg/mortbay/jetty/client/HttpExchange;","onResponseComplete",new String[]{ },"V"));
                code.visitLabel(L2);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m003_onResponseHeader(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Lorg/mortbay/jetty/client/webdav/WebdavSupportedExchange;","onResponseHeader",new String[]{ "Lorg/mortbay/io/Buffer;","Lorg/mortbay/io/Buffer;"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"name");
                ddv.visitParameterName(1,"value");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(31,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(32,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(33,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(35,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(37,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(41,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(42,L6);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Lorg/mortbay/log/Log;","isDebugEnabled",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_EQZ,0,-1,L2);
                code.visitLabel(L1);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,1,"WebdavSupportedExchange:Header:");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Ljava/lang/Object;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitConstStmt(CONST_STRING,1," / ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Ljava/lang/Object;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0},new Method("Lorg/mortbay/log/Log;","debug",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L2);
                code.visitConstStmt(CONST_STRING,0,"DAV");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Ljava/lang/Object;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/String;","equals",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_EQZ,0,-1,L5);
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Ljava/lang/Object;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitConstStmt(CONST_STRING,1,"1");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/String;","indexOf",new String[]{ "Ljava/lang/String;"},"I"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_GEZ,0,-1,L4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Ljava/lang/Object;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitConstStmt(CONST_STRING,1,"2");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/String;","indexOf",new String[]{ "Ljava/lang/String;"},"I"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_LTZ,0,-1,L5);
                code.visitLabel(L4);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitFieldStmt(IPUT_BOOLEAN,0,2,new Field("Lorg/mortbay/jetty/client/webdav/WebdavSupportedExchange;","_webdavSupported","Z"));
                code.visitLabel(L5);
                code.visitMethodStmt(INVOKE_SUPER,new int[]{ 2,3,4},new Method("Lorg/mortbay/jetty/client/HttpExchange;","onResponseHeader",new String[]{ "Lorg/mortbay/io/Buffer;","Lorg/mortbay/io/Buffer;"},"V"));
                code.visitLabel(L6);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m004_waitTilCompletion(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/client/webdav/WebdavSupportedExchange;","waitTilCompletion",new String[]{ },"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/lang/InterruptedException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexLabel L3=new DexLabel();
                DexLabel L4=new DexLabel();
                code.visitTryCatch(L3,L4,new DexLabel[]{L2},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L5=new DexLabel();
                ddv.visitPrologue(L5);
                ddv.visitLineNumber(46,L5);
                ddv.visitLineNumber(48,L0);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(50,L6);
                ddv.visitLineNumber(52,L2);
                ddv.visitLineNumber(53,L4);
                code.visitLabel(L5);
                code.visitStmt1R(MONITOR_ENTER,1);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_BOOLEAN,0,1,new Field("Lorg/mortbay/jetty/client/webdav/WebdavSupportedExchange;","_isComplete","Z"));
                code.visitJumpStmt(IF_NEZ,0,-1,L3);
                code.visitLabel(L6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/lang/Object;","wait",new String[]{ },"V"));
                code.visitJumpStmt(GOTO,-1,-1,L0);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,0);
                code.visitStmt1R(MONITOR_EXIT,1);
                code.visitLabel(L1);
                code.visitStmt1R(THROW,0);
                code.visitLabel(L3);
                code.visitStmt1R(MONITOR_EXIT,1);
                code.visitLabel(L4);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
