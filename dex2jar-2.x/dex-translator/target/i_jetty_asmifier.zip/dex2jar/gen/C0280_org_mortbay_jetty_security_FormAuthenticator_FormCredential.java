package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0280_org_mortbay_jetty_security_FormAuthenticator_FormCredential {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(0,"Lorg/mortbay/jetty/security/FormAuthenticator$FormCredential;","Ljava/lang/Object;",new String[]{ "Ljava/io/Serializable;","Ljavax/servlet/http/HttpSessionBindingListener;"});
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("FormAuthenticator.java");
        if(cv!=null){
            DexAnnotationVisitor av00 = cv.visitAnnotation("Ldalvik/annotation/EnclosingClass;", Visibility.SYSTEM);
            if(av00 != null) {
                av00.visit("value", new DexType("Lorg/mortbay/jetty/security/FormAuthenticator;"));
                av00.visitEnd();
            }
        }
        if(cv!=null){
            DexAnnotationVisitor av00 = cv.visitAnnotation("Ldalvik/annotation/InnerClass;", Visibility.SYSTEM);
            if(av00 != null) {
                av00.visit("accessFlags",  Integer.valueOf(10));
                av00.visit("name", "FormCredential");
                av00.visitEnd();
            }
        }
        f000__jPassword(cv);
        f001__jUserName(cv);
        f002__realm(cv);
        f003__userPrincipal(cv);
        m000__init_(cv);
        m001__init_(cv);
        m002_authenticate(cv);
        m003_authenticate(cv);
        m004_equals(cv);
        m005_hashCode(cv);
        m006_toString(cv);
        m007_valueBound(cv);
        m008_valueUnbound(cv);
    }
    public static void f000__jPassword(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(0, new Field("Lorg/mortbay/jetty/security/FormAuthenticator$FormCredential;","_jPassword","Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f001__jUserName(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(0, new Field("Lorg/mortbay/jetty/security/FormAuthenticator$FormCredential;","_jUserName","Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f002__realm(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_TRANSIENT, new Field("Lorg/mortbay/jetty/security/FormAuthenticator$FormCredential;","_realm","Lorg/mortbay/jetty/security/UserRealm;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f003__userPrincipal(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_TRANSIENT, new Field("Lorg/mortbay/jetty/security/FormAuthenticator$FormCredential;","_userPrincipal","Ljava/security/Principal;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void m000__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PRIVATE|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/jetty/security/FormAuthenticator$FormCredential;","<init>",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(1);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(273,L0);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/lang/Object;","<init>",new String[]{ },"V"));
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_SYNTHETIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/jetty/security/FormAuthenticator$FormCredential;","<init>",new String[]{ "Lorg/mortbay/jetty/security/FormAuthenticator$1;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"x0");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(273,L0);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Lorg/mortbay/jetty/security/FormAuthenticator$FormCredential;","<init>",new String[]{ },"V"));
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m002_authenticate(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(0, new Method("Lorg/mortbay/jetty/security/FormAuthenticator$FormCredential;","authenticate",new String[]{ "Lorg/mortbay/jetty/security/UserRealm;","Ljava/lang/String;","Ljava/lang/String;","Lorg/mortbay/jetty/Request;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(7);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"realm");
                ddv.visitParameterName(1,"user");
                ddv.visitParameterName(2,"password");
                ddv.visitParameterName(3,"request");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(282,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(283,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(284,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(285,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(286,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(292,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(289,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(290,L7);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_OBJECT,4,2,new Field("Lorg/mortbay/jetty/security/FormAuthenticator$FormCredential;","_jUserName","Ljava/lang/String;"));
                code.visitLabel(L1);
                code.visitFieldStmt(IPUT_OBJECT,5,2,new Field("Lorg/mortbay/jetty/security/FormAuthenticator$FormCredential;","_jPassword","Ljava/lang/String;"));
                code.visitLabel(L2);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 3,4,5,6},new Method("Lorg/mortbay/jetty/security/UserRealm;","authenticate",new String[]{ "Ljava/lang/String;","Ljava/lang/Object;","Lorg/mortbay/jetty/Request;"},"Ljava/security/Principal;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(IPUT_OBJECT,0,2,new Field("Lorg/mortbay/jetty/security/FormAuthenticator$FormCredential;","_userPrincipal","Ljava/security/Principal;"));
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/jetty/security/FormAuthenticator$FormCredential;","_userPrincipal","Ljava/security/Principal;"));
                code.visitJumpStmt(IF_EQZ,0,-1,L6);
                code.visitLabel(L4);
                code.visitFieldStmt(IPUT_OBJECT,3,2,new Field("Lorg/mortbay/jetty/security/FormAuthenticator$FormCredential;","_realm","Lorg/mortbay/jetty/security/UserRealm;"));
                code.visitLabel(L5);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L6);
                code.visitConstStmt(CONST_STRING,0,"AUTH FAILURE: user {}");
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 4},new Method("Lorg/mortbay/util/StringUtil;","printable",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0,1},new Method("Lorg/mortbay/log/Log;","warn",new String[]{ "Ljava/lang/String;","Ljava/lang/Object;"},"V"));
                code.visitLabel(L7);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,0},new Method("Lorg/mortbay/jetty/Request;","setUserPrincipal",new String[]{ "Ljava/security/Principal;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L5);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m003_authenticate(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(0, new Method("Lorg/mortbay/jetty/security/FormAuthenticator$FormCredential;","authenticate",new String[]{ "Lorg/mortbay/jetty/security/UserRealm;","Lorg/mortbay/jetty/Request;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"realm");
                ddv.visitParameterName(1,"request");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(296,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(297,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(298,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(304,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(301,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(302,L5);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/jetty/security/FormAuthenticator$FormCredential;","_jUserName","Ljava/lang/String;"));
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/jetty/security/FormAuthenticator$FormCredential;","_jPassword","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 3,0,1,4},new Method("Lorg/mortbay/jetty/security/UserRealm;","authenticate",new String[]{ "Ljava/lang/String;","Ljava/lang/Object;","Lorg/mortbay/jetty/Request;"},"Ljava/security/Principal;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(IPUT_OBJECT,0,2,new Field("Lorg/mortbay/jetty/security/FormAuthenticator$FormCredential;","_userPrincipal","Ljava/security/Principal;"));
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/jetty/security/FormAuthenticator$FormCredential;","_userPrincipal","Ljava/security/Principal;"));
                code.visitJumpStmt(IF_EQZ,0,-1,L4);
                code.visitLabel(L2);
                code.visitFieldStmt(IPUT_OBJECT,3,2,new Field("Lorg/mortbay/jetty/security/FormAuthenticator$FormCredential;","_realm","Lorg/mortbay/jetty/security/UserRealm;"));
                code.visitLabel(L3);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L4);
                code.visitConstStmt(CONST_STRING,0,"AUTH FAILURE: user {}");
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/jetty/security/FormAuthenticator$FormCredential;","_jUserName","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1},new Method("Lorg/mortbay/util/StringUtil;","printable",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0,1},new Method("Lorg/mortbay/log/Log;","warn",new String[]{ "Ljava/lang/String;","Ljava/lang/Object;"},"V"));
                code.visitLabel(L5);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,0},new Method("Lorg/mortbay/jetty/Request;","setUserPrincipal",new String[]{ "Ljava/security/Principal;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L3);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m004_equals(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/security/FormAuthenticator$FormCredential;","equals",new String[]{ "Ljava/lang/Object;"},"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(7);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"o");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(327,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(330,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(329,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(330,L4);
                ddv.visitStartLocal(1,L4,"fc","Lorg/mortbay/jetty/security/FormAuthenticator$FormCredential;",null);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,4, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L1);
                code.visitTypeStmt(INSTANCE_OF,2,6,"Lorg/mortbay/jetty/security/FormAuthenticator$FormCredential;");
                code.visitJumpStmt(IF_NEZ,2,-1,L3);
                code.visitStmt2R(MOVE,2,4);
                code.visitLabel(L2);
                code.visitStmt1R(RETURN,2);
                code.visitLabel(L3);
                code.visitStmt2R(MOVE_OBJECT,0,6);
                code.visitTypeStmt(CHECK_CAST,0,-1,"Lorg/mortbay/jetty/security/FormAuthenticator$FormCredential;");
                code.visitStmt2R(MOVE_OBJECT,1,0);
                code.visitLabel(L4);
                code.visitFieldStmt(IGET_OBJECT,2,5,new Field("Lorg/mortbay/jetty/security/FormAuthenticator$FormCredential;","_jUserName","Ljava/lang/String;"));
                code.visitFieldStmt(IGET_OBJECT,3,1,new Field("Lorg/mortbay/jetty/security/FormAuthenticator$FormCredential;","_jUserName","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3},new Method("Ljava/lang/String;","equals",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,2);
                DexLabel L5=new DexLabel();
                code.visitJumpStmt(IF_EQZ,2,-1,L5);
                code.visitFieldStmt(IGET_OBJECT,2,5,new Field("Lorg/mortbay/jetty/security/FormAuthenticator$FormCredential;","_jPassword","Ljava/lang/String;"));
                code.visitFieldStmt(IGET_OBJECT,3,1,new Field("Lorg/mortbay/jetty/security/FormAuthenticator$FormCredential;","_jPassword","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3},new Method("Ljava/lang/String;","equals",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitJumpStmt(IF_EQZ,2,-1,L5);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitLabel(L5);
                code.visitStmt2R(MOVE,2,4);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m005_hashCode(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/security/FormAuthenticator$FormCredential;","hashCode",new String[]{ },"I"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(322,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/jetty/security/FormAuthenticator$FormCredential;","_jUserName","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/lang/String;","hashCode",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/jetty/security/FormAuthenticator$FormCredential;","_jPassword","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/lang/String;","hashCode",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitStmt2R(ADD_INT_2ADDR,0,1);
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m006_toString(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/security/FormAuthenticator$FormCredential;","toString",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(337,L0);
                code.visitLabel(L0);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,1,"Cred[");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/jetty/security/FormAuthenticator$FormCredential;","_jUserName","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitConstStmt(CONST_STRING,1,"]");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m007_valueBound(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/security/FormAuthenticator$FormCredential;","valueBound",new String[]{ "Ljavax/servlet/http/HttpSessionBindingEvent;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"event");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(307,L0);
                code.visitLabel(L0);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m008_valueUnbound(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/security/FormAuthenticator$FormCredential;","valueUnbound",new String[]{ "Ljavax/servlet/http/HttpSessionBindingEvent;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"event");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(311,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(313,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(314,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(316,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(317,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(318,L5);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Lorg/mortbay/log/Log;","isDebugEnabled",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_EQZ,0,-1,L1);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,1,"Logout ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/jetty/security/FormAuthenticator$FormCredential;","_jUserName","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0},new Method("Lorg/mortbay/log/Log;","debug",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/jetty/security/FormAuthenticator$FormCredential;","_realm","Lorg/mortbay/jetty/security/UserRealm;"));
                code.visitTypeStmt(INSTANCE_OF,0,0,"Lorg/mortbay/jetty/security/SSORealm;");
                code.visitJumpStmt(IF_EQZ,0,-1,L3);
                code.visitLabel(L2);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/jetty/security/FormAuthenticator$FormCredential;","_realm","Lorg/mortbay/jetty/security/UserRealm;"));
                code.visitTypeStmt(CHECK_CAST,0,-1,"Lorg/mortbay/jetty/security/SSORealm;");
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/jetty/security/FormAuthenticator$FormCredential;","_jUserName","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,1},new Method("Lorg/mortbay/jetty/security/SSORealm;","clearSingleSignOn",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/jetty/security/FormAuthenticator$FormCredential;","_realm","Lorg/mortbay/jetty/security/UserRealm;"));
                code.visitJumpStmt(IF_EQZ,0,-1,L5);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/jetty/security/FormAuthenticator$FormCredential;","_userPrincipal","Ljava/security/Principal;"));
                code.visitJumpStmt(IF_EQZ,0,-1,L5);
                code.visitLabel(L4);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/jetty/security/FormAuthenticator$FormCredential;","_realm","Lorg/mortbay/jetty/security/UserRealm;"));
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/jetty/security/FormAuthenticator$FormCredential;","_userPrincipal","Ljava/security/Principal;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,1},new Method("Lorg/mortbay/jetty/security/UserRealm;","logout",new String[]{ "Ljava/security/Principal;"},"V"));
                code.visitLabel(L5);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
