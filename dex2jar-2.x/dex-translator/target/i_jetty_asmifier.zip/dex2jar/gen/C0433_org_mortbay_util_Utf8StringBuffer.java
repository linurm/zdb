package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0433_org_mortbay_util_Utf8StringBuffer {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(ACC_PUBLIC,"Lorg/mortbay/util/Utf8StringBuffer;","Ljava/lang/Object;",new String[]{ });
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("Utf8StringBuffer.java");
        f000__bits(cv);
        f001__buffer(cv);
        f002__errors(cv);
        f003__more(cv);
        m000__init_(cv);
        m001__init_(cv);
        m002_append(cv);
        m003_append(cv);
        m004_getStringBuffer(cv);
        m005_isError(cv);
        m006_length(cv);
        m007_reset(cv);
        m008_toString(cv);
    }
    public static void f000__bits(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(0, new Field("Lorg/mortbay/util/Utf8StringBuffer;","_bits","I"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f001__buffer(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(0, new Field("Lorg/mortbay/util/Utf8StringBuffer;","_buffer","Ljava/lang/StringBuffer;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f002__errors(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(0, new Field("Lorg/mortbay/util/Utf8StringBuffer;","_errors","Z"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f003__more(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(0, new Field("Lorg/mortbay/util/Utf8StringBuffer;","_more","I"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void m000__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/util/Utf8StringBuffer;","<init>",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(38,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(39,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(40,L2);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1},new Method("Ljava/lang/Object;","<init>",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/lang/StringBuffer;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/lang/StringBuffer;","<init>",new String[]{ },"V"));
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/util/Utf8StringBuffer;","_buffer","Ljava/lang/StringBuffer;"));
                code.visitLabel(L2);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/util/Utf8StringBuffer;","<init>",new String[]{ "I"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"capacity");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(43,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(44,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(45,L2);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1},new Method("Ljava/lang/Object;","<init>",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/lang/StringBuffer;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,2},new Method("Ljava/lang/StringBuffer;","<init>",new String[]{ "I"},"V"));
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/util/Utf8StringBuffer;","_buffer","Ljava/lang/StringBuffer;"));
                code.visitLabel(L2);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m002_append(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/util/Utf8StringBuffer;","append",new String[]{ "B"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(7);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"b");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(56,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(58,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(60,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(61,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(62,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(124,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(65,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(67,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(69,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(72,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(73,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(74,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(76,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(79,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(80,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(82,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(85,L17);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(86,L18);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(88,L19);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(91,L20);
                DexLabel L21=new DexLabel();
                ddv.visitLineNumber(92,L21);
                DexLabel L22=new DexLabel();
                ddv.visitLineNumber(94,L22);
                DexLabel L23=new DexLabel();
                ddv.visitLineNumber(97,L23);
                DexLabel L24=new DexLabel();
                ddv.visitLineNumber(98,L24);
                DexLabel L25=new DexLabel();
                ddv.visitLineNumber(100,L25);
                DexLabel L26=new DexLabel();
                ddv.visitLineNumber(103,L26);
                DexLabel L27=new DexLabel();
                ddv.visitLineNumber(104,L27);
                DexLabel L28=new DexLabel();
                ddv.visitLineNumber(109,L28);
                DexLabel L29=new DexLabel();
                ddv.visitLineNumber(111,L29);
                DexLabel L30=new DexLabel();
                ddv.visitLineNumber(112,L30);
                DexLabel L31=new DexLabel();
                ddv.visitLineNumber(113,L31);
                DexLabel L32=new DexLabel();
                ddv.visitLineNumber(114,L32);
                DexLabel L33=new DexLabel();
                ddv.visitLineNumber(119,L33);
                DexLabel L34=new DexLabel();
                ddv.visitLineNumber(120,L34);
                DexLabel L35=new DexLabel();
                ddv.visitLineNumber(121,L35);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_16,4, Integer.valueOf(192)); // int: 0x000000c0  float:0.000000
                code.visitConstStmt(CONST_16,3, Integer.valueOf(63)); // int: 0x0000003f  float:0.000000
                code.visitConstStmt(CONST_4,2, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L1);
                code.visitJumpStmt(IF_LTZ,6,-1,L8);
                code.visitLabel(L2);
                code.visitFieldStmt(IGET,0,5,new Field("Lorg/mortbay/util/Utf8StringBuffer;","_more","I"));
                code.visitJumpStmt(IF_LEZ,0,-1,L7);
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,0,5,new Field("Lorg/mortbay/util/Utf8StringBuffer;","_buffer","Ljava/lang/StringBuffer;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,3},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "C"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L4);
                code.visitFieldStmt(IPUT,1,5,new Field("Lorg/mortbay/util/Utf8StringBuffer;","_more","I"));
                code.visitLabel(L5);
                code.visitFieldStmt(IPUT,1,5,new Field("Lorg/mortbay/util/Utf8StringBuffer;","_bits","I"));
                code.visitLabel(L6);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L7);
                code.visitFieldStmt(IGET_OBJECT,0,5,new Field("Lorg/mortbay/util/Utf8StringBuffer;","_buffer","Ljava/lang/StringBuffer;"));
                code.visitStmt2R1N(AND_INT_LIT8,1,6,127);
                code.visitStmt2R(INT_TO_CHAR,1,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "C"},"Ljava/lang/StringBuffer;"));
                code.visitJumpStmt(GOTO,-1,-1,L6);
                code.visitLabel(L8);
                code.visitFieldStmt(IGET,0,5,new Field("Lorg/mortbay/util/Utf8StringBuffer;","_more","I"));
                code.visitJumpStmt(IF_NEZ,0,-1,L28);
                code.visitLabel(L9);
                code.visitStmt2R1N(AND_INT_LIT16,0,6,192);
                code.visitJumpStmt(IF_EQ,0,4,L13);
                code.visitLabel(L10);
                code.visitFieldStmt(IGET_OBJECT,0,5,new Field("Lorg/mortbay/util/Utf8StringBuffer;","_buffer","Ljava/lang/StringBuffer;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,3},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "C"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L11);
                code.visitFieldStmt(IPUT,1,5,new Field("Lorg/mortbay/util/Utf8StringBuffer;","_more","I"));
                code.visitLabel(L12);
                code.visitFieldStmt(IPUT,1,5,new Field("Lorg/mortbay/util/Utf8StringBuffer;","_bits","I"));
                code.visitJumpStmt(GOTO,-1,-1,L6);
                code.visitLabel(L13);
                code.visitStmt2R1N(AND_INT_LIT16,0,6,224);
                code.visitJumpStmt(IF_NE,0,4,L16);
                code.visitLabel(L14);
                code.visitFieldStmt(IPUT,2,5,new Field("Lorg/mortbay/util/Utf8StringBuffer;","_more","I"));
                code.visitLabel(L15);
                code.visitStmt2R1N(AND_INT_LIT8,0,6,31);
                code.visitFieldStmt(IPUT,0,5,new Field("Lorg/mortbay/util/Utf8StringBuffer;","_bits","I"));
                code.visitJumpStmt(GOTO,-1,-1,L6);
                code.visitLabel(L16);
                code.visitStmt2R1N(AND_INT_LIT16,0,6,240);
                code.visitConstStmt(CONST_16,1, Integer.valueOf(224)); // int: 0x000000e0  float:0.000000
                code.visitJumpStmt(IF_NE,0,1,L19);
                code.visitLabel(L17);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(2)); // int: 0x00000002  float:0.000000
                code.visitFieldStmt(IPUT,0,5,new Field("Lorg/mortbay/util/Utf8StringBuffer;","_more","I"));
                code.visitLabel(L18);
                code.visitStmt2R1N(AND_INT_LIT8,0,6,15);
                code.visitFieldStmt(IPUT,0,5,new Field("Lorg/mortbay/util/Utf8StringBuffer;","_bits","I"));
                code.visitJumpStmt(GOTO,-1,-1,L6);
                code.visitLabel(L19);
                code.visitStmt2R1N(AND_INT_LIT16,0,6,248);
                code.visitConstStmt(CONST_16,1, Integer.valueOf(240)); // int: 0x000000f0  float:0.000000
                code.visitJumpStmt(IF_NE,0,1,L22);
                code.visitLabel(L20);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(3)); // int: 0x00000003  float:0.000000
                code.visitFieldStmt(IPUT,0,5,new Field("Lorg/mortbay/util/Utf8StringBuffer;","_more","I"));
                code.visitLabel(L21);
                code.visitStmt2R1N(AND_INT_LIT8,0,6,7);
                code.visitFieldStmt(IPUT,0,5,new Field("Lorg/mortbay/util/Utf8StringBuffer;","_bits","I"));
                code.visitJumpStmt(GOTO,-1,-1,L6);
                code.visitLabel(L22);
                code.visitStmt2R1N(AND_INT_LIT16,0,6,252);
                code.visitConstStmt(CONST_16,1, Integer.valueOf(248)); // int: 0x000000f8  float:0.000000
                code.visitJumpStmt(IF_NE,0,1,L25);
                code.visitLabel(L23);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(4)); // int: 0x00000004  float:0.000000
                code.visitFieldStmt(IPUT,0,5,new Field("Lorg/mortbay/util/Utf8StringBuffer;","_more","I"));
                code.visitLabel(L24);
                code.visitStmt2R1N(AND_INT_LIT8,0,6,3);
                code.visitFieldStmt(IPUT,0,5,new Field("Lorg/mortbay/util/Utf8StringBuffer;","_bits","I"));
                code.visitJumpStmt(GOTO,-1,-1,L6);
                code.visitLabel(L25);
                code.visitStmt2R1N(AND_INT_LIT16,0,6,254);
                code.visitConstStmt(CONST_16,1, Integer.valueOf(252)); // int: 0x000000fc  float:0.000000
                code.visitJumpStmt(IF_NE,0,1,L6);
                code.visitLabel(L26);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(5)); // int: 0x00000005  float:0.000000
                code.visitFieldStmt(IPUT,0,5,new Field("Lorg/mortbay/util/Utf8StringBuffer;","_more","I"));
                code.visitLabel(L27);
                code.visitStmt2R1N(AND_INT_LIT8,0,6,1);
                code.visitFieldStmt(IPUT,0,5,new Field("Lorg/mortbay/util/Utf8StringBuffer;","_bits","I"));
                code.visitJumpStmt(GOTO,-1,-1,L6);
                code.visitLabel(L28);
                code.visitStmt2R1N(AND_INT_LIT16,0,6,192);
                code.visitJumpStmt(IF_NE,0,4,L33);
                code.visitLabel(L29);
                code.visitFieldStmt(IGET_OBJECT,0,5,new Field("Lorg/mortbay/util/Utf8StringBuffer;","_buffer","Ljava/lang/StringBuffer;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,3},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "C"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L30);
                code.visitFieldStmt(IPUT,1,5,new Field("Lorg/mortbay/util/Utf8StringBuffer;","_more","I"));
                code.visitLabel(L31);
                code.visitFieldStmt(IPUT,1,5,new Field("Lorg/mortbay/util/Utf8StringBuffer;","_bits","I"));
                code.visitLabel(L32);
                code.visitFieldStmt(IPUT_BOOLEAN,2,5,new Field("Lorg/mortbay/util/Utf8StringBuffer;","_errors","Z"));
                code.visitJumpStmt(GOTO,-1,-1,L6);
                code.visitLabel(L33);
                code.visitFieldStmt(IGET,0,5,new Field("Lorg/mortbay/util/Utf8StringBuffer;","_bits","I"));
                code.visitStmt2R1N(SHL_INT_LIT8,0,0,6);
                code.visitStmt2R1N(AND_INT_LIT8,1,6,63);
                code.visitStmt2R(OR_INT_2ADDR,0,1);
                code.visitFieldStmt(IPUT,0,5,new Field("Lorg/mortbay/util/Utf8StringBuffer;","_bits","I"));
                code.visitLabel(L34);
                code.visitFieldStmt(IGET,0,5,new Field("Lorg/mortbay/util/Utf8StringBuffer;","_more","I"));
                code.visitStmt2R(SUB_INT_2ADDR,0,2);
                code.visitFieldStmt(IPUT,0,5,new Field("Lorg/mortbay/util/Utf8StringBuffer;","_more","I"));
                code.visitJumpStmt(IF_NEZ,0,-1,L6);
                code.visitLabel(L35);
                code.visitFieldStmt(IGET_OBJECT,0,5,new Field("Lorg/mortbay/util/Utf8StringBuffer;","_buffer","Ljava/lang/StringBuffer;"));
                code.visitFieldStmt(IGET,1,5,new Field("Lorg/mortbay/util/Utf8StringBuffer;","_bits","I"));
                code.visitStmt2R(INT_TO_CHAR,1,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "C"},"Ljava/lang/StringBuffer;"));
                code.visitJumpStmt(GOTO_16,-1,-1,L6);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m003_append(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/util/Utf8StringBuffer;","append",new String[]{ "[B","I","I"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(7);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"b");
                ddv.visitParameterName(1,"offset");
                ddv.visitParameterName(2,"length");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(49,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(50,L1);
                ddv.visitStartLocal(0,L1,"end","I",null);
                DexLabel L2=new DexLabel();
                ddv.visitStartLocal(1,L2,"i","I",null);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(51,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(50,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(52,L5);
                code.visitLabel(L0);
                code.visitStmt3R(ADD_INT,0,5,6);
                code.visitLabel(L1);
                code.visitStmt2R(MOVE,1,5);
                code.visitLabel(L2);
                code.visitJumpStmt(IF_GE,1,0,L5);
                code.visitLabel(L3);
                code.visitStmt3R(AGET_BYTE,2,4,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,2},new Method("Lorg/mortbay/util/Utf8StringBuffer;","append",new String[]{ "B"},"V"));
                code.visitLabel(L4);
                code.visitStmt2R1N(ADD_INT_LIT8,1,1,1);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitLabel(L5);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m004_getStringBuffer(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/util/Utf8StringBuffer;","getStringBuffer",new String[]{ },"Ljava/lang/StringBuffer;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(141,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/util/Utf8StringBuffer;","_buffer","Ljava/lang/StringBuffer;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m005_isError(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/util/Utf8StringBuffer;","isError",new String[]{ },"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(155,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_BOOLEAN,0,1,new Field("Lorg/mortbay/util/Utf8StringBuffer;","_errors","Z"));
                DexLabel L1=new DexLabel();
                code.visitJumpStmt(IF_NEZ,0,-1,L1);
                code.visitFieldStmt(IGET,0,1,new Field("Lorg/mortbay/util/Utf8StringBuffer;","_more","I"));
                DexLabel L2=new DexLabel();
                code.visitJumpStmt(IF_LEZ,0,-1,L2);
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                DexLabel L3=new DexLabel();
                code.visitLabel(L3);
                code.visitStmt1R(RETURN,0);
                code.visitLabel(L2);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L3);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m006_length(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/util/Utf8StringBuffer;","length",new String[]{ },"I"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(128,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/util/Utf8StringBuffer;","_buffer","Ljava/lang/StringBuffer;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/lang/StringBuffer;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m007_reset(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/util/Utf8StringBuffer;","reset",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(133,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(134,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(135,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(136,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(137,L5);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/util/Utf8StringBuffer;","_buffer","Ljava/lang/StringBuffer;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuffer;","setLength",new String[]{ "I"},"V"));
                code.visitLabel(L2);
                code.visitFieldStmt(IPUT,1,2,new Field("Lorg/mortbay/util/Utf8StringBuffer;","_more","I"));
                code.visitLabel(L3);
                code.visitFieldStmt(IPUT,1,2,new Field("Lorg/mortbay/util/Utf8StringBuffer;","_bits","I"));
                code.visitLabel(L4);
                code.visitFieldStmt(IPUT_BOOLEAN,1,2,new Field("Lorg/mortbay/util/Utf8StringBuffer;","_errors","Z"));
                code.visitLabel(L5);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m008_toString(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/util/Utf8StringBuffer;","toString",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(146,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/util/Utf8StringBuffer;","_buffer","Ljava/lang/StringBuffer;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/lang/StringBuffer;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
