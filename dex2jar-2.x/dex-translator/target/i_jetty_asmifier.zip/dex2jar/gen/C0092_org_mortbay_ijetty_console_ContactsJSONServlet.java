package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0092_org_mortbay_ijetty_console_ContactsJSONServlet {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(ACC_PUBLIC,"Lorg/mortbay/ijetty/console/ContactsJSONServlet;","Lorg/mortbay/ijetty/console/AbstractContactsServlet;",new String[]{ });
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("ContactsJSONServlet.java");
        m000__init_(cv);
        m001_getContactMethods(cv);
        m002_getPhones(cv);
        m003_getSummary(cv);
        m004_getUsers(cv);
        m005_deleteUser(cv);
        m006_getUser(cv);
        m007_handleAddUser(cv);
        m008_handleDefault(cv);
        m009_handleDeleteUser(cv);
        m010_handleEditUser(cv);
        m011_handleGetUser(cv);
        m012_handleGetUsers(cv);
        m013_handleSaveUser(cv);
    }
    public static void m000__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/ijetty/console/ContactsJSONServlet;","<init>",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(1);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(29,L0);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Lorg/mortbay/ijetty/console/AbstractContactsServlet;","<init>",new String[]{ },"V"));
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001_getContactMethods(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PRIVATE, new Method("Lorg/mortbay/ijetty/console/ContactsJSONServlet;","getContactMethods",new String[]{ "Ljava/lang/String;","Lorg/mortbay/ijetty/console/ContactMethod$ContactMethodsCollection;","Ljava/io/PrintWriter;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(16);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"who");
                ddv.visitParameterName(1,"contactMethods");
                ddv.visitParameterName(2,"writer");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(157,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(159,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(160,L2);
                ddv.visitStartLocal(1,L2,"buff","Ljava/lang/StringBuffer;",null);
                DexLabel L3=new DexLabel();
                ddv.visitStartLocal(2,L3,"contactMethod","Landroid/content/ContentValues;",null);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(162,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(163,L5);
                ddv.visitStartLocal(4,L5,"id","Ljava/lang/String;",null);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(164,L6);
                ddv.visitStartLocal(3,L6,"data","Ljava/lang/String;",null);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(165,L7);
                ddv.visitStartLocal(0,L7,"auxData","Ljava/lang/String;",null);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(166,L8);
                ddv.visitStartLocal(7,L8,"label","Ljava/lang/String;",null);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(167,L9);
                ddv.visitStartLocal(5,L9,"isPrimary","I",null);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(168,L10);
                ddv.visitStartLocal(6,L10,"kind","I",null);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(169,L11);
                ddv.visitStartLocal(8,L11,"type","I",null);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(170,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(171,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(169,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(173,L15);
                ddv.visitEndLocal(4,L15);
                ddv.visitEndLocal(3,L15);
                ddv.visitEndLocal(0,L15);
                ddv.visitEndLocal(7,L15);
                ddv.visitEndLocal(5,L15);
                ddv.visitEndLocal(6,L15);
                ddv.visitEndLocal(8,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(174,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(175,L17);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_STRING,9,"[");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 15,9},new Method("Ljava/io/PrintWriter;","print",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L1);
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Ljava/lang/StringBuffer;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1},new Method("Ljava/lang/StringBuffer;","<init>",new String[]{ },"V"));
                code.visitLabel(L2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 14},new Method("Lorg/mortbay/ijetty/console/ContactMethod$ContactMethodsCollection;","next",new String[]{ },"Landroid/content/ContentValues;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitLabel(L3);
                code.visitJumpStmt(IF_EQZ,2,-1,L15);
                code.visitLabel(L4);
                code.visitConstStmt(CONST_STRING,9,"_id");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,9},new Method("Landroid/content/ContentValues;","getAsString",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitLabel(L5);
                code.visitConstStmt(CONST_STRING,9,"data");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,9},new Method("Landroid/content/ContentValues;","getAsString",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitLabel(L6);
                code.visitConstStmt(CONST_STRING,9,"aux_data");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,9},new Method("Landroid/content/ContentValues;","getAsString",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L7);
                code.visitConstStmt(CONST_STRING,9,"label");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,9},new Method("Landroid/content/ContentValues;","getAsString",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitLabel(L8);
                code.visitConstStmt(CONST_STRING,9,"isprimary");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,9},new Method("Landroid/content/ContentValues;","getAsInteger",new String[]{ "Ljava/lang/String;"},"Ljava/lang/Integer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,9);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9},new Method("Ljava/lang/Integer;","intValue",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,5);
                code.visitLabel(L9);
                code.visitConstStmt(CONST_STRING,9,"kind");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,9},new Method("Landroid/content/ContentValues;","getAsInteger",new String[]{ "Ljava/lang/String;"},"Ljava/lang/Integer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,9);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9},new Method("Ljava/lang/Integer;","intValue",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,6);
                code.visitLabel(L10);
                code.visitConstStmt(CONST_STRING,9,"type");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,9},new Method("Landroid/content/ContentValues;","getAsInteger",new String[]{ "Ljava/lang/String;"},"Ljava/lang/Integer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,9);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9},new Method("Ljava/lang/Integer;","intValue",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,8);
                code.visitLabel(L11);
                code.visitTypeStmt(NEW_INSTANCE,9,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 9},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,10,"{ \"data\": \"");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9,10},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,9);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9,3},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,9);
                code.visitConstStmt(CONST_STRING,10,"\", \"aux\": \"");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9,10},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,9);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9,0},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,9);
                code.visitConstStmt(CONST_STRING,10,"\",  \"label\": \"");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9,10},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,9);
                code.visitJumpStmt(IF_NEZ,7,-1,L14);
                code.visitConstStmt(CONST_STRING,10,"\"");
                DexLabel L18=new DexLabel();
                code.visitLabel(L18);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9,10},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,9);
                code.visitConstStmt(CONST_STRING,10,", \"primary\": ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9,10},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,9);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9,5},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "I"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,9);
                code.visitConstStmt(CONST_STRING,10,", \"kind\": ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9,10},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,9);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9,6},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "I"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,9);
                code.visitConstStmt(CONST_STRING,10,", \"type\": ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9,10},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,9);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9,8},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "I"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,9);
                code.visitConstStmt(CONST_STRING,10,", \"id\": \"");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9,10},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,9);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9,4},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,9);
                code.visitConstStmt(CONST_STRING,10,"\"}");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9,10},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,9);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,9);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,9},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L12);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 14},new Method("Lorg/mortbay/ijetty/console/ContactMethod$ContactMethodsCollection;","hasNext",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,9);
                code.visitJumpStmt(IF_EQZ,9,-1,L2);
                code.visitLabel(L13);
                code.visitConstStmt(CONST_STRING,9,",");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,9},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuffer;"));
                code.visitJumpStmt(GOTO_16,-1,-1,L2);
                code.visitLabel(L14);
                code.visitTypeStmt(NEW_INSTANCE,10,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 10},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10,7},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,10);
                code.visitConstStmt(CONST_STRING,11,"\"");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10,11},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,10);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,10);
                code.visitJumpStmt(GOTO,-1,-1,L18);
                code.visitLabel(L15);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/lang/StringBuffer;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,9);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 15,9},new Method("Ljava/io/PrintWriter;","print",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L16);
                code.visitConstStmt(CONST_STRING,9,"]");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 15,9},new Method("Ljava/io/PrintWriter;","print",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L17);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m002_getPhones(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PRIVATE, new Method("Lorg/mortbay/ijetty/console/ContactsJSONServlet;","getPhones",new String[]{ "Ljava/lang/String;","Lorg/mortbay/ijetty/console/Phone$PhoneCollection;","Ljava/io/PrintWriter;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(13);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"who");
                ddv.visitParameterName(1,"phones");
                ddv.visitParameterName(2,"writer");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(139,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(140,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(141,L2);
                ddv.visitStartLocal(0,L2,"buff","Ljava/lang/StringBuffer;",null);
                DexLabel L3=new DexLabel();
                ddv.visitStartLocal(4,L3,"phone","Landroid/content/ContentValues;",null);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(143,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(144,L5);
                ddv.visitStartLocal(1,L5,"id","Ljava/lang/String;",null);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(145,L6);
                ddv.visitStartLocal(2,L6,"label","Ljava/lang/String;",null);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(146,L7);
                ddv.visitStartLocal(3,L7,"number","Ljava/lang/String;",null);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(147,L8);
                ddv.visitStartLocal(5,L8,"type","I",null);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(148,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(149,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(147,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(151,L12);
                ddv.visitEndLocal(1,L12);
                ddv.visitEndLocal(2,L12);
                ddv.visitEndLocal(3,L12);
                ddv.visitEndLocal(5,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(152,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(153,L14);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_STRING,6,"[ ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 12,6},new Method("Ljava/io/PrintWriter;","print",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L1);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/lang/StringBuffer;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/lang/StringBuffer;","<init>",new String[]{ },"V"));
                code.visitLabel(L2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 11},new Method("Lorg/mortbay/ijetty/console/Phone$PhoneCollection;","next",new String[]{ },"Landroid/content/ContentValues;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitLabel(L3);
                code.visitJumpStmt(IF_EQZ,4,-1,L12);
                code.visitLabel(L4);
                code.visitConstStmt(CONST_STRING,6,"_id");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,6},new Method("Landroid/content/ContentValues;","getAsString",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L5);
                code.visitConstStmt(CONST_STRING,6,"label");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,6},new Method("Landroid/content/ContentValues;","getAsString",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitLabel(L6);
                code.visitConstStmt(CONST_STRING,6,"number");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,6},new Method("Landroid/content/ContentValues;","getAsString",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitLabel(L7);
                code.visitConstStmt(CONST_STRING,6,"type");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,6},new Method("Landroid/content/ContentValues;","getAsInteger",new String[]{ "Ljava/lang/String;"},"Ljava/lang/Integer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Ljava/lang/Integer;","intValue",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,5);
                code.visitLabel(L8);
                code.visitTypeStmt(NEW_INSTANCE,6,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 6},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,7,"{\"number\": \"");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,7},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,3},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitConstStmt(CONST_STRING,7,"\", \"label\" : \"");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,7},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitJumpStmt(IF_NEZ,2,-1,L11);
                code.visitConstStmt(CONST_STRING,7,"");
                DexLabel L15=new DexLabel();
                code.visitLabel(L15);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,7},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitConstStmt(CONST_STRING,7,"\", \"type\" : ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,7},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,5},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "I"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitConstStmt(CONST_STRING,7,", \"id\": \"");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,7},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitConstStmt(CONST_STRING,7,"\" }");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,7},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,6},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L9);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 11},new Method("Lorg/mortbay/ijetty/console/Phone$PhoneCollection;","hasNext",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,6);
                code.visitJumpStmt(IF_EQZ,6,-1,L2);
                code.visitLabel(L10);
                code.visitConstStmt(CONST_STRING,6,", ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,6},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuffer;"));
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitLabel(L11);
                code.visitConstStmt(CONST_STRING,7,"\'");
                code.visitConstStmt(CONST_STRING,8,"\\\'");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,7,8},new Method("Ljava/lang/String;","replace",new String[]{ "Ljava/lang/CharSequence;","Ljava/lang/CharSequence;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitJumpStmt(GOTO,-1,-1,L15);
                code.visitLabel(L12);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/lang/StringBuffer;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 12,6},new Method("Ljava/io/PrintWriter;","print",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L13);
                code.visitConstStmt(CONST_STRING,6," ]");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 12,6},new Method("Ljava/io/PrintWriter;","print",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L14);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m003_getSummary(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PRIVATE, new Method("Lorg/mortbay/ijetty/console/ContactsJSONServlet;","getSummary",new String[]{ "Landroid/content/ContentValues;","Ljava/io/PrintWriter;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(14);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"values");
                ddv.visitParameterName(1,"writer");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(110,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(112,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(113,L2);
                ddv.visitStartLocal(2,L2,"id","Ljava/lang/String;",null);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(114,L3);
                ddv.visitStartLocal(3,L3,"name","Ljava/lang/String;",null);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(115,L4);
                ddv.visitStartLocal(6,L4,"title","Ljava/lang/String;",null);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(116,L5);
                ddv.visitStartLocal(0,L5,"company","Ljava/lang/String;",null);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(117,L6);
                ddv.visitStartLocal(4,L6,"notes","Ljava/lang/String;",null);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(118,L7);
                ddv.visitStartLocal(1,L7,"i","Ljava/lang/Integer;",null);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(119,L8);
                ddv.visitStartLocal(5,L8,"starred","Z",null);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(120,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(122,L10);
                ddv.visitStartLocal(7,L10,"voicemail","Z",null);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(123,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(124,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(125,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(126,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(127,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(129,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(130,L17);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(132,L18);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(134,L19);
                ddv.visitEndLocal(2,L19);
                ddv.visitEndLocal(3,L19);
                ddv.visitEndLocal(6,L19);
                ddv.visitEndLocal(0,L19);
                ddv.visitEndLocal(4,L19);
                ddv.visitEndLocal(5,L19);
                ddv.visitEndLocal(1,L19);
                ddv.visitEndLocal(7,L19);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(118,L20);
                ddv.visitRestartLocal(0,L20);
                ddv.visitRestartLocal(1,L20);
                ddv.visitRestartLocal(2,L20);
                ddv.visitRestartLocal(3,L20);
                ddv.visitRestartLocal(4,L20);
                ddv.visitRestartLocal(6,L20);
                DexLabel L21=new DexLabel();
                ddv.visitLineNumber(120,L21);
                ddv.visitRestartLocal(5,L21);
                code.visitLabel(L0);
                code.visitJumpStmt(IF_EQZ,12,-1,L19);
                code.visitJumpStmt(IF_EQZ,13,-1,L19);
                code.visitLabel(L1);
                code.visitConstStmt(CONST_STRING,8,"_id");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 12,8},new Method("Landroid/content/ContentValues;","getAsString",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitLabel(L2);
                code.visitConstStmt(CONST_STRING,8,"display_name");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 12,8},new Method("Landroid/content/ContentValues;","getAsString",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitLabel(L3);
                code.visitConstStmt(CONST_4,6, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L4);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L5);
                code.visitConstStmt(CONST_STRING,8,"notes");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 12,8},new Method("Landroid/content/ContentValues;","getAsString",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitLabel(L6);
                code.visitConstStmt(CONST_STRING,8,"starred");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 12,8},new Method("Landroid/content/ContentValues;","getAsInteger",new String[]{ "Ljava/lang/String;"},"Ljava/lang/Integer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L7);
                code.visitJumpStmt(IF_NEZ,1,-1,L20);
                code.visitConstStmt(CONST_4,8, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitStmt2R(MOVE,5,8);
                code.visitLabel(L8);
                code.visitConstStmt(CONST_STRING,8,"send_to_voicemail");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 12,8},new Method("Landroid/content/ContentValues;","getAsInteger",new String[]{ "Ljava/lang/String;"},"Ljava/lang/Integer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L9);
                code.visitJumpStmt(IF_NEZ,1,-1,L21);
                code.visitConstStmt(CONST_4,8, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitStmt2R(MOVE,7,8);
                code.visitLabel(L10);
                code.visitTypeStmt(NEW_INSTANCE,8,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 8},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,9,"{\"name\": \"");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8,9},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitConstStmt(CONST_STRING,9,"\'");
                code.visitConstStmt(CONST_STRING,10,"\\\'");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,9,10},new Method("Ljava/lang/String;","replace",new String[]{ "Ljava/lang/CharSequence;","Ljava/lang/CharSequence;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,9);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8,9},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitConstStmt(CONST_STRING,9,"\", ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8,9},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 13,8},new Method("Ljava/io/PrintWriter;","print",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L11);
                code.visitTypeStmt(NEW_INSTANCE,8,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 8},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,9,"\"id\": \"");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8,9},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8,2},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitConstStmt(CONST_STRING,9,"\", ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8,9},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 13,8},new Method("Ljava/io/PrintWriter;","print",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L12);
                code.visitTypeStmt(NEW_INSTANCE,8,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 8},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,9,"\"starred\": ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8,9},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 5},new Method("Ljava/lang/Boolean;","toString",new String[]{ "Z"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,9);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8,9},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitConstStmt(CONST_STRING,9,", ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8,9},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 13,8},new Method("Ljava/io/PrintWriter;","print",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L13);
                code.visitTypeStmt(NEW_INSTANCE,8,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 8},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,9,"\"voicemail\": ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8,9},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 7},new Method("Ljava/lang/Boolean;","toString",new String[]{ "Z"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,9);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8,9},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 13,8},new Method("Ljava/io/PrintWriter;","print",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L14);
                code.visitJumpStmt(IF_EQZ,0,-1,L16);
                code.visitLabel(L15);
                code.visitTypeStmt(NEW_INSTANCE,8,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 8},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,9,", \"company\": \"");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8,9},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitConstStmt(CONST_STRING,9,"\'");
                code.visitConstStmt(CONST_STRING,10,"\\\'");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,9,10},new Method("Ljava/lang/String;","replace",new String[]{ "Ljava/lang/CharSequence;","Ljava/lang/CharSequence;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,9);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8,9},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitConstStmt(CONST_STRING,9,"\"");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8,9},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 13,8},new Method("Ljava/io/PrintWriter;","print",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L16);
                code.visitJumpStmt(IF_EQZ,4,-1,L18);
                code.visitLabel(L17);
                code.visitTypeStmt(NEW_INSTANCE,8,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 8},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,9,", \"notes\": \"");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8,9},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitConstStmt(CONST_STRING,9,"\'");
                code.visitConstStmt(CONST_STRING,10,"\\\'");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,9,10},new Method("Ljava/lang/String;","replace",new String[]{ "Ljava/lang/CharSequence;","Ljava/lang/CharSequence;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,9);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8,9},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitConstStmt(CONST_STRING,9,"\"");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8,9},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 13,8},new Method("Ljava/io/PrintWriter;","print",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L18);
                code.visitConstStmt(CONST_STRING,8," }");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 13,8},new Method("Ljava/io/PrintWriter;","print",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L19);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L20);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/lang/Integer;","intValue",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,8);
                DexLabel L22=new DexLabel();
                code.visitJumpStmt(IF_LEZ,8,-1,L22);
                code.visitConstStmt(CONST_4,8, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitStmt2R(MOVE,5,8);
                code.visitJumpStmt(GOTO_16,-1,-1,L8);
                code.visitLabel(L22);
                code.visitConstStmt(CONST_4,8, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitStmt2R(MOVE,5,8);
                code.visitJumpStmt(GOTO_16,-1,-1,L8);
                code.visitLabel(L21);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/lang/Integer;","intValue",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,8);
                DexLabel L23=new DexLabel();
                code.visitJumpStmt(IF_LEZ,8,-1,L23);
                code.visitConstStmt(CONST_4,8, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitStmt2R(MOVE,7,8);
                code.visitJumpStmt(GOTO_16,-1,-1,L10);
                code.visitLabel(L23);
                code.visitConstStmt(CONST_4,8, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitStmt2R(MOVE,7,8);
                code.visitJumpStmt(GOTO_16,-1,-1,L10);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m004_getUsers(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PRIVATE, new Method("Lorg/mortbay/ijetty/console/ContactsJSONServlet;","getUsers",new String[]{ "Lorg/mortbay/ijetty/console/User$UserCollection;","Ljava/io/PrintWriter;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(14);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"users");
                ddv.visitParameterName(1,"writer");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(179,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(180,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(181,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(182,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(184,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(185,L6);
                ddv.visitStartLocal(3,L6,"row","I",null);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(186,L7);
                ddv.visitStartLocal(5,L7,"user","Landroid/content/ContentValues;",null);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(188,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(189,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(190,L10);
                ddv.visitStartLocal(1,L10,"id","Ljava/lang/String;",null);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(191,L11);
                ddv.visitStartLocal(2,L11,"name","Ljava/lang/String;",null);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(192,L12);
                ddv.visitStartLocal(0,L12,"i","Ljava/lang/Integer;",null);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(193,L13);
                ddv.visitStartLocal(4,L13,"starred","Z",null);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(194,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(195,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(196,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(197,L17);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(198,L18);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(192,L19);
                ddv.visitEndLocal(4,L19);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(201,L20);
                ddv.visitEndLocal(3,L20);
                ddv.visitEndLocal(5,L20);
                ddv.visitEndLocal(1,L20);
                ddv.visitEndLocal(2,L20);
                ddv.visitEndLocal(0,L20);
                DexLabel L21=new DexLabel();
                ddv.visitLineNumber(202,L21);
                DexLabel L22=new DexLabel();
                ddv.visitLineNumber(203,L22);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,8, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitConstStmt(CONST_STRING,10,"}");
                code.visitConstStmt(CONST_STRING,9,"\", ");
                code.visitLabel(L1);
                code.visitTypeStmt(NEW_INSTANCE,6,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 6},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,7,"{\"version\": ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,7},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitFieldStmt(SGET,7,-1,new Field("Lorg/mortbay/ijetty/console/ContactsJSONServlet;","__VERSION","I"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,7},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "I"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 13,6},new Method("Ljava/io/PrintWriter;","println",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L2);
                code.visitConstStmt(CONST_STRING,6,", \"users\": ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 13,6},new Method("Ljava/io/PrintWriter;","println",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L3);
                code.visitConstStmt(CONST_STRING,6,"[");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 13,6},new Method("Ljava/io/PrintWriter;","println",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L4);
                code.visitJumpStmt(IF_EQZ,12,-1,L20);
                code.visitLabel(L5);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L6);
                code.visitConstStmt(CONST_4,5, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 12},new Method("Lorg/mortbay/ijetty/console/User$UserCollection;","next",new String[]{ },"Landroid/content/ContentValues;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitJumpStmt(IF_EQZ,5,-1,L20);
                code.visitLabel(L8);
                code.visitConstStmt(CONST_STRING,6,"{");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 13,6},new Method("Ljava/io/PrintWriter;","println",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L9);
                code.visitConstStmt(CONST_STRING,6,"_id");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,6},new Method("Landroid/content/ContentValues;","getAsString",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L10);
                code.visitConstStmt(CONST_STRING,6,"display_name");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,6},new Method("Landroid/content/ContentValues;","getAsString",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitLabel(L11);
                code.visitConstStmt(CONST_STRING,6,"starred");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,6},new Method("Landroid/content/ContentValues;","getAsInteger",new String[]{ "Ljava/lang/String;"},"Ljava/lang/Integer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L12);
                code.visitJumpStmt(IF_NEZ,0,-1,L19);
                code.visitStmt2R(MOVE,4,8);
                code.visitLabel(L13);
                code.visitTypeStmt(NEW_INSTANCE,6,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 6},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,7,"\"id\" : \"");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,7},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitConstStmt(CONST_STRING,7,"\", ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,9},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 13,6},new Method("Ljava/io/PrintWriter;","println",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L14);
                code.visitTypeStmt(NEW_INSTANCE,6,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 6},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,7,"\"name\" : \"");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,7},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,2},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitConstStmt(CONST_STRING,7,"\", ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,9},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 13,6},new Method("Ljava/io/PrintWriter;","println",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L15);
                code.visitTypeStmt(NEW_INSTANCE,6,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 6},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,7,"\"starred\": ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,7},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,4},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Z"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 13,6},new Method("Ljava/io/PrintWriter;","println",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L16);
                code.visitConstStmt(CONST_STRING,6,"}");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 13,10},new Method("Ljava/io/PrintWriter;","println",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L17);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 12},new Method("Lorg/mortbay/ijetty/console/User$UserCollection;","hasNext",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,6);
                code.visitJumpStmt(IF_EQZ,6,-1,L7);
                code.visitLabel(L18);
                code.visitConstStmt(CONST_STRING,6,",");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 13,6},new Method("Ljava/io/PrintWriter;","println",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L7);
                code.visitLabel(L19);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/lang/Integer;","intValue",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,6);
                DexLabel L23=new DexLabel();
                code.visitJumpStmt(IF_LEZ,6,-1,L23);
                code.visitConstStmt(CONST_4,6, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitStmt2R(MOVE,4,6);
                code.visitJumpStmt(GOTO,-1,-1,L13);
                code.visitLabel(L23);
                code.visitStmt2R(MOVE,4,8);
                code.visitJumpStmt(GOTO,-1,-1,L13);
                code.visitLabel(L20);
                code.visitConstStmt(CONST_STRING,6,"]");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 13,6},new Method("Ljava/io/PrintWriter;","println",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L21);
                code.visitConstStmt(CONST_STRING,6,"}");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 13,10},new Method("Ljava/io/PrintWriter;","println",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L22);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m005_deleteUser(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Lorg/mortbay/ijetty/console/ContactsJSONServlet;","deleteUser",new String[]{ "Ljava/io/PrintWriter;","Ljavax/servlet/http/HttpServletRequest;","Ljavax/servlet/http/HttpServletResponse;","Ljava/lang/String;"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljavax/servlet/ServletException;"));
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(7);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ "Ljava/lang/Exception;"});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"writer");
                ddv.visitParameterName(1,"request");
                ddv.visitParameterName(2,"response");
                ddv.visitParameterName(3,"id");
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(211,L0);
                ddv.visitLineNumber(220,L1);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(221,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(222,L4);
                ddv.visitLineNumber(213,L2);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(216,L5);
                ddv.visitStartLocal(0,L5,"e","Ljava/lang/Exception;",null);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/ijetty/console/ContactsJSONServlet;","getContentResolver",new String[]{ },"Landroid/content/ContentResolver;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1,6},new Method("Lorg/mortbay/ijetty/console/User;","delete",new String[]{ "Landroid/content/ContentResolver;","Ljava/lang/String;"},"V"));
                code.visitLabel(L1);
                code.visitConstStmt(CONST_16,1, Integer.valueOf(200)); // int: 0x000000c8  float:0.000000
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 5,1},new Method("Ljavax/servlet/http/HttpServletResponse;","setStatus",new String[]{ "I"},"V"));
                code.visitLabel(L3);
                code.visitConstStmt(CONST_STRING,1,"{ \"status\": \"OK\" }");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,1},new Method("Ljava/io/PrintWriter;","println",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L4);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,1);
                code.visitStmt2R(MOVE_OBJECT,0,1);
                code.visitLabel(L5);
                code.visitConstStmt(CONST_16,1, Integer.valueOf(404)); // int: 0x00000194  float:0.000000
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 5,1},new Method("Ljavax/servlet/http/HttpServletResponse;","setStatus",new String[]{ "I"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L4);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m006_getUser(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Lorg/mortbay/ijetty/console/ContactsJSONServlet;","getUser",new String[]{ "Ljava/io/PrintWriter;","Ljavax/servlet/http/HttpServletRequest;","Ljavax/servlet/http/HttpServletResponse;","Ljava/lang/String;"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljavax/servlet/ServletException;"));
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(10);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"writer");
                ddv.visitParameterName(1,"request");
                ddv.visitParameterName(2,"response");
                ddv.visitParameterName(3,"who");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(85,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(86,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(87,L2);
                ddv.visitStartLocal(2,L2,"values","Landroid/content/ContentValues;",null);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(89,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(92,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(93,L5);
                ddv.visitStartLocal(1,L5,"phones","Lorg/mortbay/ijetty/console/Phone$PhoneCollection;",null);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(94,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(96,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(99,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(100,L9);
                ddv.visitStartLocal(0,L9,"contactMethods","Lorg/mortbay/ijetty/console/ContactMethod$ContactMethodsCollection;",null);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(101,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(103,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(105,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(106,L13);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_STRING,3,"{ \"summary\" : ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,3},new Method("Ljava/io/PrintWriter;","print",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Lorg/mortbay/ijetty/console/ContactsJSONServlet;","getContentResolver",new String[]{ },"Landroid/content/ContentResolver;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 3,9},new Method("Lorg/mortbay/ijetty/console/User;","get",new String[]{ "Landroid/content/ContentResolver;","Ljava/lang/String;"},"Landroid/content/ContentValues;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitLabel(L2);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 5,2,6},new Method("Lorg/mortbay/ijetty/console/ContactsJSONServlet;","getSummary",new String[]{ "Landroid/content/ContentValues;","Ljava/io/PrintWriter;"},"V"));
                code.visitLabel(L3);
                code.visitConstStmt(CONST_STRING,3,", \"phones\" : ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,3},new Method("Ljava/io/PrintWriter;","print",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Lorg/mortbay/ijetty/console/ContactsJSONServlet;","getContentResolver",new String[]{ },"Landroid/content/ContentResolver;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 3,9},new Method("Lorg/mortbay/ijetty/console/Phone;","getPhones",new String[]{ "Landroid/content/ContentResolver;","Ljava/lang/String;"},"Lorg/mortbay/ijetty/console/Phone$PhoneCollection;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L5);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 5,9,1,6},new Method("Lorg/mortbay/ijetty/console/ContactsJSONServlet;","getPhones",new String[]{ "Ljava/lang/String;","Lorg/mortbay/ijetty/console/Phone$PhoneCollection;","Ljava/io/PrintWriter;"},"V"));
                code.visitLabel(L6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Lorg/mortbay/ijetty/console/Phone$PhoneCollection;","close",new String[]{ },"V"));
                code.visitLabel(L7);
                code.visitConstStmt(CONST_STRING,3,", \"contacts\" : ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,3},new Method("Ljava/io/PrintWriter;","print",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L8);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Lorg/mortbay/ijetty/console/ContactsJSONServlet;","getContentResolver",new String[]{ },"Landroid/content/ContentResolver;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 3,9},new Method("Lorg/mortbay/ijetty/console/ContactMethod;","getContactMethods",new String[]{ "Landroid/content/ContentResolver;","Ljava/lang/String;"},"Lorg/mortbay/ijetty/console/ContactMethod$ContactMethodsCollection;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L9);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 5,9,0,6},new Method("Lorg/mortbay/ijetty/console/ContactsJSONServlet;","getContactMethods",new String[]{ "Ljava/lang/String;","Lorg/mortbay/ijetty/console/ContactMethod$ContactMethodsCollection;","Ljava/io/PrintWriter;"},"V"));
                code.visitLabel(L10);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/ijetty/console/ContactMethod$ContactMethodsCollection;","close",new String[]{ },"V"));
                code.visitLabel(L11);
                code.visitTypeStmt(NEW_INSTANCE,3,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 3},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,4,", \"version\": ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,4},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitFieldStmt(SGET,4,-1,new Field("Lorg/mortbay/ijetty/console/ContactsJSONServlet;","__VERSION","I"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,4},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "I"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,3},new Method("Ljava/io/PrintWriter;","print",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L12);
                code.visitConstStmt(CONST_STRING,3," }");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,3},new Method("Ljava/io/PrintWriter;","print",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L13);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m007_handleAddUser(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/ijetty/console/ContactsJSONServlet;","handleAddUser",new String[]{ "Ljavax/servlet/http/HttpServletRequest;","Ljavax/servlet/http/HttpServletResponse;"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljavax/servlet/ServletException;"));
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"request");
                ddv.visitParameterName(1,"response");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(229,L0);
                code.visitLabel(L0);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m008_handleDefault(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/ijetty/console/ContactsJSONServlet;","handleDefault",new String[]{ "Ljavax/servlet/http/HttpServletRequest;","Ljavax/servlet/http/HttpServletResponse;"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljavax/servlet/ServletException;"));
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"request");
                ddv.visitParameterName(1,"response");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(243,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(244,L1);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1,2},new Method("Lorg/mortbay/ijetty/console/ContactsJSONServlet;","handleGetUsers",new String[]{ "Ljavax/servlet/http/HttpServletRequest;","Ljavax/servlet/http/HttpServletResponse;"},"V"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m009_handleDeleteUser(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/ijetty/console/ContactsJSONServlet;","handleDeleteUser",new String[]{ "Ljavax/servlet/http/HttpServletRequest;","Ljavax/servlet/http/HttpServletResponse;","Ljava/lang/String;"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljavax/servlet/ServletException;"));
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(6);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"request");
                ddv.visitParameterName(1,"response");
                ddv.visitParameterName(2,"who");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(251,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(252,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(253,L2);
                ddv.visitStartLocal(0,L2,"writer","Ljava/io/PrintWriter;",null);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(254,L3);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_STRING,1,"text/json; charset=utf-8");
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 4,1},new Method("Ljavax/servlet/http/HttpServletResponse;","setContentType",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 4},new Method("Ljavax/servlet/http/HttpServletResponse;","getWriter",new String[]{ },"Ljava/io/PrintWriter;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,0,3,4,5},new Method("Lorg/mortbay/ijetty/console/ContactsJSONServlet;","deleteUser",new String[]{ "Ljava/io/PrintWriter;","Ljavax/servlet/http/HttpServletRequest;","Ljavax/servlet/http/HttpServletResponse;","Ljava/lang/String;"},"V"));
                code.visitLabel(L3);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m010_handleEditUser(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/ijetty/console/ContactsJSONServlet;","handleEditUser",new String[]{ "Ljavax/servlet/http/HttpServletRequest;","Ljavax/servlet/http/HttpServletResponse;","Ljava/lang/String;"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljavax/servlet/ServletException;"));
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"request");
                ddv.visitParameterName(1,"response");
                ddv.visitParameterName(2,"who");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(237,L0);
                code.visitLabel(L0);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m011_handleGetUser(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/ijetty/console/ContactsJSONServlet;","handleGetUser",new String[]{ "Ljavax/servlet/http/HttpServletRequest;","Ljavax/servlet/http/HttpServletResponse;","Ljava/lang/String;"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljavax/servlet/ServletException;"));
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(6);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"request");
                ddv.visitParameterName(1,"response");
                ddv.visitParameterName(2,"who");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(262,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(263,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(264,L2);
                ddv.visitStartLocal(0,L2,"writer","Ljava/io/PrintWriter;",null);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(265,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(266,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(267,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(268,L6);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_STRING,1,"text/json; charset=utf-8");
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 4,1},new Method("Ljavax/servlet/http/HttpServletResponse;","setContentType",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 4},new Method("Ljavax/servlet/http/HttpServletResponse;","getWriter",new String[]{ },"Ljava/io/PrintWriter;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,0,3,4,5},new Method("Lorg/mortbay/ijetty/console/ContactsJSONServlet;","getUser",new String[]{ "Ljava/io/PrintWriter;","Ljavax/servlet/http/HttpServletRequest;","Ljavax/servlet/http/HttpServletResponse;","Ljava/lang/String;"},"V"));
                code.visitLabel(L3);
                code.visitConstStmt(CONST_16,1, Integer.valueOf(200)); // int: 0x000000c8  float:0.000000
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 4,1},new Method("Ljavax/servlet/http/HttpServletResponse;","setStatus",new String[]{ "I"},"V"));
                code.visitLabel(L4);
                code.visitConstStmt(CONST_STRING,1,"\r\n");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/io/PrintWriter;","write",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/io/PrintWriter;","close",new String[]{ },"V"));
                code.visitLabel(L6);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m012_handleGetUsers(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/ijetty/console/ContactsJSONServlet;","handleGetUsers",new String[]{ "Ljavax/servlet/http/HttpServletRequest;","Ljavax/servlet/http/HttpServletResponse;"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljavax/servlet/ServletException;"));
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(6);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"request");
                ddv.visitParameterName(1,"response");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(274,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(275,L1);
                ddv.visitStartLocal(1,L1,"writer","Ljava/io/PrintWriter;",null);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(276,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(277,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(279,L4);
                ddv.visitStartLocal(0,L4,"users","Lorg/mortbay/ijetty/console/User$UserCollection;",null);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(280,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(281,L6);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 5},new Method("Ljavax/servlet/http/HttpServletResponse;","getWriter",new String[]{ },"Ljava/io/PrintWriter;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L1);
                code.visitConstStmt(CONST_STRING,2,"text/json; charset=utf-8");
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 5,2},new Method("Ljavax/servlet/http/HttpServletResponse;","setContentType",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L2);
                code.visitConstStmt(CONST_16,2, Integer.valueOf(200)); // int: 0x000000c8  float:0.000000
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 5,2},new Method("Ljavax/servlet/http/HttpServletResponse;","setStatus",new String[]{ "I"},"V"));
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Lorg/mortbay/ijetty/console/ContactsJSONServlet;","getContentResolver",new String[]{ },"Landroid/content/ContentResolver;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 2},new Method("Lorg/mortbay/ijetty/console/User;","getAll",new String[]{ "Landroid/content/ContentResolver;"},"Lorg/mortbay/ijetty/console/User$UserCollection;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L4);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 3,0,1},new Method("Lorg/mortbay/ijetty/console/ContactsJSONServlet;","getUsers",new String[]{ "Lorg/mortbay/ijetty/console/User$UserCollection;","Ljava/io/PrintWriter;"},"V"));
                code.visitLabel(L5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/ijetty/console/User$UserCollection;","close",new String[]{ },"V"));
                code.visitLabel(L6);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m013_handleSaveUser(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/ijetty/console/ContactsJSONServlet;","handleSaveUser",new String[]{ "Ljavax/servlet/http/HttpServletRequest;","Ljavax/servlet/http/HttpServletResponse;","Ljava/lang/String;"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljavax/servlet/ServletException;"));
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"request");
                ddv.visitParameterName(1,"response");
                ddv.visitParameterName(2,"who");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(292,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(293,L1);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_STRING,0,"id");
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 2,0},new Method("Ljavax/servlet/http/HttpServletRequest;","getParameter",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2,3,0},new Method("Lorg/mortbay/ijetty/console/ContactsJSONServlet;","saveUserFormData",new String[]{ "Ljavax/servlet/http/HttpServletRequest;","Ljavax/servlet/http/HttpServletResponse;","Ljava/lang/String;"},"V"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
