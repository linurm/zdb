package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0090_org_mortbay_ijetty_console_ContactsHTMLServlet___INFO_TYPE {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(ACC_FINAL|ACC_ENUM,"Lorg/mortbay/ijetty/console/ContactsHTMLServlet$__INFO_TYPE;","Ljava/lang/Enum;",new String[]{ });
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("ContactsHTMLServlet.java");
        if(cv!=null){
            DexAnnotationVisitor av00 = cv.visitAnnotation("Ldalvik/annotation/EnclosingClass;", Visibility.SYSTEM);
            if(av00 != null) {
                av00.visit("value", new DexType("Lorg/mortbay/ijetty/console/ContactsHTMLServlet;"));
                av00.visitEnd();
            }
        }
        if(cv!=null){
            DexAnnotationVisitor av00 = cv.visitAnnotation("Ldalvik/annotation/InnerClass;", Visibility.SYSTEM);
            if(av00 != null) {
                av00.visit("accessFlags",  Integer.valueOf(16410));
                av00.visit("name", "__INFO_TYPE");
                av00.visitEnd();
            }
        }
        if(cv!=null){
            DexAnnotationVisitor av00 = cv.visitAnnotation("Ldalvik/annotation/Signature;", Visibility.SYSTEM);
            if(av00 != null) {
                {
                    DexAnnotationVisitor av01 = av00.visitArray("value");
                    if(av01 != null) {
                        av01.visit(null, "Ljava/lang/Enum");
                        av01.visit(null, "<");
                        av01.visit(null, "Lorg/mortbay/ijetty/console/ContactsHTMLServlet$__INFO_TYPE;");
                        av01.visit(null, ">;");
                        av01.visitEnd();
                    }
                }
                av00.visitEnd();
            }
        }
        f000_$VALUES(cv);
        f001_Custom(cv);
        f002_Email(cv);
        f003_Home(cv);
        f004_HomeFax(cv);
        f005_IM(cv);
        f006_Mobile(cv);
        f007_Organization(cv);
        f008_Other(cv);
        f009_Pager(cv);
        f010_Phone(cv);
        f011_Postal(cv);
        f012_Work(cv);
        f013_WorkFax(cv);
        m000__clinit_(cv);
        m001__init_(cv);
        m002_valueOf(cv);
        m003_values(cv);
    }
    public static void f000_$VALUES(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE|ACC_STATIC|ACC_FINAL|ACC_SYNTHETIC, new Field("Lorg/mortbay/ijetty/console/ContactsHTMLServlet$__INFO_TYPE;","$VALUES","[Lorg/mortbay/ijetty/console/ContactsHTMLServlet$__INFO_TYPE;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f001_Custom(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL|ACC_ENUM, new Field("Lorg/mortbay/ijetty/console/ContactsHTMLServlet$__INFO_TYPE;","Custom","Lorg/mortbay/ijetty/console/ContactsHTMLServlet$__INFO_TYPE;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f002_Email(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL|ACC_ENUM, new Field("Lorg/mortbay/ijetty/console/ContactsHTMLServlet$__INFO_TYPE;","Email","Lorg/mortbay/ijetty/console/ContactsHTMLServlet$__INFO_TYPE;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f003_Home(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL|ACC_ENUM, new Field("Lorg/mortbay/ijetty/console/ContactsHTMLServlet$__INFO_TYPE;","Home","Lorg/mortbay/ijetty/console/ContactsHTMLServlet$__INFO_TYPE;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f004_HomeFax(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL|ACC_ENUM, new Field("Lorg/mortbay/ijetty/console/ContactsHTMLServlet$__INFO_TYPE;","HomeFax","Lorg/mortbay/ijetty/console/ContactsHTMLServlet$__INFO_TYPE;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f005_IM(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL|ACC_ENUM, new Field("Lorg/mortbay/ijetty/console/ContactsHTMLServlet$__INFO_TYPE;","IM","Lorg/mortbay/ijetty/console/ContactsHTMLServlet$__INFO_TYPE;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f006_Mobile(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL|ACC_ENUM, new Field("Lorg/mortbay/ijetty/console/ContactsHTMLServlet$__INFO_TYPE;","Mobile","Lorg/mortbay/ijetty/console/ContactsHTMLServlet$__INFO_TYPE;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f007_Organization(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL|ACC_ENUM, new Field("Lorg/mortbay/ijetty/console/ContactsHTMLServlet$__INFO_TYPE;","Organization","Lorg/mortbay/ijetty/console/ContactsHTMLServlet$__INFO_TYPE;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f008_Other(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL|ACC_ENUM, new Field("Lorg/mortbay/ijetty/console/ContactsHTMLServlet$__INFO_TYPE;","Other","Lorg/mortbay/ijetty/console/ContactsHTMLServlet$__INFO_TYPE;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f009_Pager(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL|ACC_ENUM, new Field("Lorg/mortbay/ijetty/console/ContactsHTMLServlet$__INFO_TYPE;","Pager","Lorg/mortbay/ijetty/console/ContactsHTMLServlet$__INFO_TYPE;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f010_Phone(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL|ACC_ENUM, new Field("Lorg/mortbay/ijetty/console/ContactsHTMLServlet$__INFO_TYPE;","Phone","Lorg/mortbay/ijetty/console/ContactsHTMLServlet$__INFO_TYPE;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f011_Postal(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL|ACC_ENUM, new Field("Lorg/mortbay/ijetty/console/ContactsHTMLServlet$__INFO_TYPE;","Postal","Lorg/mortbay/ijetty/console/ContactsHTMLServlet$__INFO_TYPE;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f012_Work(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL|ACC_ENUM, new Field("Lorg/mortbay/ijetty/console/ContactsHTMLServlet$__INFO_TYPE;","Work","Lorg/mortbay/ijetty/console/ContactsHTMLServlet$__INFO_TYPE;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f013_WorkFax(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL|ACC_ENUM, new Field("Lorg/mortbay/ijetty/console/ContactsHTMLServlet$__INFO_TYPE;","WorkFax","Lorg/mortbay/ijetty/console/ContactsHTMLServlet$__INFO_TYPE;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void m000__clinit_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_STATIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/ijetty/console/ContactsHTMLServlet$__INFO_TYPE;","<clinit>",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(8);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(35,L1);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,7, Integer.valueOf(4)); // int: 0x00000004  float:0.000000
                code.visitConstStmt(CONST_4,6, Integer.valueOf(3)); // int: 0x00000003  float:0.000000
                code.visitConstStmt(CONST_4,5, Integer.valueOf(2)); // int: 0x00000002  float:0.000000
                code.visitConstStmt(CONST_4,4, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitConstStmt(CONST_4,3, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L1);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Lorg/mortbay/ijetty/console/ContactsHTMLServlet$__INFO_TYPE;");
                code.visitConstStmt(CONST_STRING,1,"Mobile");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1,3},new Method("Lorg/mortbay/ijetty/console/ContactsHTMLServlet$__INFO_TYPE;","<init>",new String[]{ "Ljava/lang/String;","I"},"V"));
                code.visitFieldStmt(SPUT_OBJECT,0,-1,new Field("Lorg/mortbay/ijetty/console/ContactsHTMLServlet$__INFO_TYPE;","Mobile","Lorg/mortbay/ijetty/console/ContactsHTMLServlet$__INFO_TYPE;"));
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Lorg/mortbay/ijetty/console/ContactsHTMLServlet$__INFO_TYPE;");
                code.visitConstStmt(CONST_STRING,1,"Home");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1,4},new Method("Lorg/mortbay/ijetty/console/ContactsHTMLServlet$__INFO_TYPE;","<init>",new String[]{ "Ljava/lang/String;","I"},"V"));
                code.visitFieldStmt(SPUT_OBJECT,0,-1,new Field("Lorg/mortbay/ijetty/console/ContactsHTMLServlet$__INFO_TYPE;","Home","Lorg/mortbay/ijetty/console/ContactsHTMLServlet$__INFO_TYPE;"));
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Lorg/mortbay/ijetty/console/ContactsHTMLServlet$__INFO_TYPE;");
                code.visitConstStmt(CONST_STRING,1,"Work");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1,5},new Method("Lorg/mortbay/ijetty/console/ContactsHTMLServlet$__INFO_TYPE;","<init>",new String[]{ "Ljava/lang/String;","I"},"V"));
                code.visitFieldStmt(SPUT_OBJECT,0,-1,new Field("Lorg/mortbay/ijetty/console/ContactsHTMLServlet$__INFO_TYPE;","Work","Lorg/mortbay/ijetty/console/ContactsHTMLServlet$__INFO_TYPE;"));
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Lorg/mortbay/ijetty/console/ContactsHTMLServlet$__INFO_TYPE;");
                code.visitConstStmt(CONST_STRING,1,"WorkFax");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1,6},new Method("Lorg/mortbay/ijetty/console/ContactsHTMLServlet$__INFO_TYPE;","<init>",new String[]{ "Ljava/lang/String;","I"},"V"));
                code.visitFieldStmt(SPUT_OBJECT,0,-1,new Field("Lorg/mortbay/ijetty/console/ContactsHTMLServlet$__INFO_TYPE;","WorkFax","Lorg/mortbay/ijetty/console/ContactsHTMLServlet$__INFO_TYPE;"));
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Lorg/mortbay/ijetty/console/ContactsHTMLServlet$__INFO_TYPE;");
                code.visitConstStmt(CONST_STRING,1,"HomeFax");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1,7},new Method("Lorg/mortbay/ijetty/console/ContactsHTMLServlet$__INFO_TYPE;","<init>",new String[]{ "Ljava/lang/String;","I"},"V"));
                code.visitFieldStmt(SPUT_OBJECT,0,-1,new Field("Lorg/mortbay/ijetty/console/ContactsHTMLServlet$__INFO_TYPE;","HomeFax","Lorg/mortbay/ijetty/console/ContactsHTMLServlet$__INFO_TYPE;"));
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Lorg/mortbay/ijetty/console/ContactsHTMLServlet$__INFO_TYPE;");
                code.visitConstStmt(CONST_STRING,1,"Pager");
                code.visitConstStmt(CONST_4,2, Integer.valueOf(5)); // int: 0x00000005  float:0.000000
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1,2},new Method("Lorg/mortbay/ijetty/console/ContactsHTMLServlet$__INFO_TYPE;","<init>",new String[]{ "Ljava/lang/String;","I"},"V"));
                code.visitFieldStmt(SPUT_OBJECT,0,-1,new Field("Lorg/mortbay/ijetty/console/ContactsHTMLServlet$__INFO_TYPE;","Pager","Lorg/mortbay/ijetty/console/ContactsHTMLServlet$__INFO_TYPE;"));
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Lorg/mortbay/ijetty/console/ContactsHTMLServlet$__INFO_TYPE;");
                code.visitConstStmt(CONST_STRING,1,"Other");
                code.visitConstStmt(CONST_4,2, Integer.valueOf(6)); // int: 0x00000006  float:0.000000
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1,2},new Method("Lorg/mortbay/ijetty/console/ContactsHTMLServlet$__INFO_TYPE;","<init>",new String[]{ "Ljava/lang/String;","I"},"V"));
                code.visitFieldStmt(SPUT_OBJECT,0,-1,new Field("Lorg/mortbay/ijetty/console/ContactsHTMLServlet$__INFO_TYPE;","Other","Lorg/mortbay/ijetty/console/ContactsHTMLServlet$__INFO_TYPE;"));
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Lorg/mortbay/ijetty/console/ContactsHTMLServlet$__INFO_TYPE;");
                code.visitConstStmt(CONST_STRING,1,"Custom");
                code.visitConstStmt(CONST_4,2, Integer.valueOf(7)); // int: 0x00000007  float:0.000000
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1,2},new Method("Lorg/mortbay/ijetty/console/ContactsHTMLServlet$__INFO_TYPE;","<init>",new String[]{ "Ljava/lang/String;","I"},"V"));
                code.visitFieldStmt(SPUT_OBJECT,0,-1,new Field("Lorg/mortbay/ijetty/console/ContactsHTMLServlet$__INFO_TYPE;","Custom","Lorg/mortbay/ijetty/console/ContactsHTMLServlet$__INFO_TYPE;"));
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Lorg/mortbay/ijetty/console/ContactsHTMLServlet$__INFO_TYPE;");
                code.visitConstStmt(CONST_STRING,1,"Email");
                code.visitConstStmt(CONST_16,2, Integer.valueOf(8)); // int: 0x00000008  float:0.000000
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1,2},new Method("Lorg/mortbay/ijetty/console/ContactsHTMLServlet$__INFO_TYPE;","<init>",new String[]{ "Ljava/lang/String;","I"},"V"));
                code.visitFieldStmt(SPUT_OBJECT,0,-1,new Field("Lorg/mortbay/ijetty/console/ContactsHTMLServlet$__INFO_TYPE;","Email","Lorg/mortbay/ijetty/console/ContactsHTMLServlet$__INFO_TYPE;"));
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Lorg/mortbay/ijetty/console/ContactsHTMLServlet$__INFO_TYPE;");
                code.visitConstStmt(CONST_STRING,1,"IM");
                code.visitConstStmt(CONST_16,2, Integer.valueOf(9)); // int: 0x00000009  float:0.000000
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1,2},new Method("Lorg/mortbay/ijetty/console/ContactsHTMLServlet$__INFO_TYPE;","<init>",new String[]{ "Ljava/lang/String;","I"},"V"));
                code.visitFieldStmt(SPUT_OBJECT,0,-1,new Field("Lorg/mortbay/ijetty/console/ContactsHTMLServlet$__INFO_TYPE;","IM","Lorg/mortbay/ijetty/console/ContactsHTMLServlet$__INFO_TYPE;"));
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Lorg/mortbay/ijetty/console/ContactsHTMLServlet$__INFO_TYPE;");
                code.visitConstStmt(CONST_STRING,1,"Postal");
                code.visitConstStmt(CONST_16,2, Integer.valueOf(10)); // int: 0x0000000a  float:0.000000
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1,2},new Method("Lorg/mortbay/ijetty/console/ContactsHTMLServlet$__INFO_TYPE;","<init>",new String[]{ "Ljava/lang/String;","I"},"V"));
                code.visitFieldStmt(SPUT_OBJECT,0,-1,new Field("Lorg/mortbay/ijetty/console/ContactsHTMLServlet$__INFO_TYPE;","Postal","Lorg/mortbay/ijetty/console/ContactsHTMLServlet$__INFO_TYPE;"));
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Lorg/mortbay/ijetty/console/ContactsHTMLServlet$__INFO_TYPE;");
                code.visitConstStmt(CONST_STRING,1,"Phone");
                code.visitConstStmt(CONST_16,2, Integer.valueOf(11)); // int: 0x0000000b  float:0.000000
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1,2},new Method("Lorg/mortbay/ijetty/console/ContactsHTMLServlet$__INFO_TYPE;","<init>",new String[]{ "Ljava/lang/String;","I"},"V"));
                code.visitFieldStmt(SPUT_OBJECT,0,-1,new Field("Lorg/mortbay/ijetty/console/ContactsHTMLServlet$__INFO_TYPE;","Phone","Lorg/mortbay/ijetty/console/ContactsHTMLServlet$__INFO_TYPE;"));
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Lorg/mortbay/ijetty/console/ContactsHTMLServlet$__INFO_TYPE;");
                code.visitConstStmt(CONST_STRING,1,"Organization");
                code.visitConstStmt(CONST_16,2, Integer.valueOf(12)); // int: 0x0000000c  float:0.000000
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1,2},new Method("Lorg/mortbay/ijetty/console/ContactsHTMLServlet$__INFO_TYPE;","<init>",new String[]{ "Ljava/lang/String;","I"},"V"));
                code.visitFieldStmt(SPUT_OBJECT,0,-1,new Field("Lorg/mortbay/ijetty/console/ContactsHTMLServlet$__INFO_TYPE;","Organization","Lorg/mortbay/ijetty/console/ContactsHTMLServlet$__INFO_TYPE;"));
                code.visitConstStmt(CONST_16,0, Integer.valueOf(13)); // int: 0x0000000d  float:0.000000
                code.visitTypeStmt(NEW_ARRAY,0,0,"[Lorg/mortbay/ijetty/console/ContactsHTMLServlet$__INFO_TYPE;");
                code.visitFieldStmt(SGET_OBJECT,1,-1,new Field("Lorg/mortbay/ijetty/console/ContactsHTMLServlet$__INFO_TYPE;","Mobile","Lorg/mortbay/ijetty/console/ContactsHTMLServlet$__INFO_TYPE;"));
                code.visitStmt3R(APUT_OBJECT,1,0,3);
                code.visitFieldStmt(SGET_OBJECT,1,-1,new Field("Lorg/mortbay/ijetty/console/ContactsHTMLServlet$__INFO_TYPE;","Home","Lorg/mortbay/ijetty/console/ContactsHTMLServlet$__INFO_TYPE;"));
                code.visitStmt3R(APUT_OBJECT,1,0,4);
                code.visitFieldStmt(SGET_OBJECT,1,-1,new Field("Lorg/mortbay/ijetty/console/ContactsHTMLServlet$__INFO_TYPE;","Work","Lorg/mortbay/ijetty/console/ContactsHTMLServlet$__INFO_TYPE;"));
                code.visitStmt3R(APUT_OBJECT,1,0,5);
                code.visitFieldStmt(SGET_OBJECT,1,-1,new Field("Lorg/mortbay/ijetty/console/ContactsHTMLServlet$__INFO_TYPE;","WorkFax","Lorg/mortbay/ijetty/console/ContactsHTMLServlet$__INFO_TYPE;"));
                code.visitStmt3R(APUT_OBJECT,1,0,6);
                code.visitFieldStmt(SGET_OBJECT,1,-1,new Field("Lorg/mortbay/ijetty/console/ContactsHTMLServlet$__INFO_TYPE;","HomeFax","Lorg/mortbay/ijetty/console/ContactsHTMLServlet$__INFO_TYPE;"));
                code.visitStmt3R(APUT_OBJECT,1,0,7);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(5)); // int: 0x00000005  float:0.000000
                code.visitFieldStmt(SGET_OBJECT,2,-1,new Field("Lorg/mortbay/ijetty/console/ContactsHTMLServlet$__INFO_TYPE;","Pager","Lorg/mortbay/ijetty/console/ContactsHTMLServlet$__INFO_TYPE;"));
                code.visitStmt3R(APUT_OBJECT,2,0,1);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(6)); // int: 0x00000006  float:0.000000
                code.visitFieldStmt(SGET_OBJECT,2,-1,new Field("Lorg/mortbay/ijetty/console/ContactsHTMLServlet$__INFO_TYPE;","Other","Lorg/mortbay/ijetty/console/ContactsHTMLServlet$__INFO_TYPE;"));
                code.visitStmt3R(APUT_OBJECT,2,0,1);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(7)); // int: 0x00000007  float:0.000000
                code.visitFieldStmt(SGET_OBJECT,2,-1,new Field("Lorg/mortbay/ijetty/console/ContactsHTMLServlet$__INFO_TYPE;","Custom","Lorg/mortbay/ijetty/console/ContactsHTMLServlet$__INFO_TYPE;"));
                code.visitStmt3R(APUT_OBJECT,2,0,1);
                code.visitConstStmt(CONST_16,1, Integer.valueOf(8)); // int: 0x00000008  float:0.000000
                code.visitFieldStmt(SGET_OBJECT,2,-1,new Field("Lorg/mortbay/ijetty/console/ContactsHTMLServlet$__INFO_TYPE;","Email","Lorg/mortbay/ijetty/console/ContactsHTMLServlet$__INFO_TYPE;"));
                code.visitStmt3R(APUT_OBJECT,2,0,1);
                code.visitConstStmt(CONST_16,1, Integer.valueOf(9)); // int: 0x00000009  float:0.000000
                code.visitFieldStmt(SGET_OBJECT,2,-1,new Field("Lorg/mortbay/ijetty/console/ContactsHTMLServlet$__INFO_TYPE;","IM","Lorg/mortbay/ijetty/console/ContactsHTMLServlet$__INFO_TYPE;"));
                code.visitStmt3R(APUT_OBJECT,2,0,1);
                code.visitConstStmt(CONST_16,1, Integer.valueOf(10)); // int: 0x0000000a  float:0.000000
                code.visitFieldStmt(SGET_OBJECT,2,-1,new Field("Lorg/mortbay/ijetty/console/ContactsHTMLServlet$__INFO_TYPE;","Postal","Lorg/mortbay/ijetty/console/ContactsHTMLServlet$__INFO_TYPE;"));
                code.visitStmt3R(APUT_OBJECT,2,0,1);
                code.visitConstStmt(CONST_16,1, Integer.valueOf(11)); // int: 0x0000000b  float:0.000000
                code.visitFieldStmt(SGET_OBJECT,2,-1,new Field("Lorg/mortbay/ijetty/console/ContactsHTMLServlet$__INFO_TYPE;","Phone","Lorg/mortbay/ijetty/console/ContactsHTMLServlet$__INFO_TYPE;"));
                code.visitStmt3R(APUT_OBJECT,2,0,1);
                code.visitConstStmt(CONST_16,1, Integer.valueOf(12)); // int: 0x0000000c  float:0.000000
                code.visitFieldStmt(SGET_OBJECT,2,-1,new Field("Lorg/mortbay/ijetty/console/ContactsHTMLServlet$__INFO_TYPE;","Organization","Lorg/mortbay/ijetty/console/ContactsHTMLServlet$__INFO_TYPE;"));
                code.visitStmt3R(APUT_OBJECT,2,0,1);
                code.visitFieldStmt(SPUT_OBJECT,0,-1,new Field("Lorg/mortbay/ijetty/console/ContactsHTMLServlet$__INFO_TYPE;","$VALUES","[Lorg/mortbay/ijetty/console/ContactsHTMLServlet$__INFO_TYPE;"));
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PRIVATE|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/ijetty/console/ContactsHTMLServlet$__INFO_TYPE;","<init>",new String[]{ "Ljava/lang/String;","I"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Signature;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, "()V");
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(35,L0);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1,2},new Method("Ljava/lang/Enum;","<init>",new String[]{ "Ljava/lang/String;","I"},"V"));
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m002_valueOf(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Lorg/mortbay/ijetty/console/ContactsHTMLServlet$__INFO_TYPE;","valueOf",new String[]{ "Ljava/lang/String;"},"Lorg/mortbay/ijetty/console/ContactsHTMLServlet$__INFO_TYPE;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"name");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(35,L0);
                DexLabel L1=new DexLabel();
                ddv.visitEndLocal(1,L1);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_CLASS,0,new DexType("Lorg/mortbay/ijetty/console/ContactsHTMLServlet$__INFO_TYPE;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0,1},new Method("Ljava/lang/Enum;","valueOf",new String[]{ "Ljava/lang/Class;","Ljava/lang/String;"},"Ljava/lang/Enum;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L1);
                code.visitTypeStmt(CHECK_CAST,1,-1,"Lorg/mortbay/ijetty/console/ContactsHTMLServlet$__INFO_TYPE;");
                code.visitStmt1R(RETURN_OBJECT,1);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m003_values(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Method("Lorg/mortbay/ijetty/console/ContactsHTMLServlet$__INFO_TYPE;","values",new String[]{ },"[Lorg/mortbay/ijetty/console/ContactsHTMLServlet$__INFO_TYPE;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(1);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(35,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(SGET_OBJECT,0,-1,new Field("Lorg/mortbay/ijetty/console/ContactsHTMLServlet$__INFO_TYPE;","$VALUES","[Lorg/mortbay/ijetty/console/ContactsHTMLServlet$__INFO_TYPE;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("[Lorg/mortbay/ijetty/console/ContactsHTMLServlet$__INFO_TYPE;","clone",new String[]{ },"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitTypeStmt(CHECK_CAST,0,-1,"[Lorg/mortbay/ijetty/console/ContactsHTMLServlet$__INFO_TYPE;");
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
