package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0065_org_mortbay_ijetty_IJettyDownloader_2 {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(0,"Lorg/mortbay/ijetty/IJettyDownloader$2;","Ljava/lang/Object;",new String[]{ "Landroid/view/View$OnClickListener;"});
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("IJettyDownloader.java");
        if(cv!=null){
            DexAnnotationVisitor av00 = cv.visitAnnotation("Ldalvik/annotation/EnclosingMethod;", Visibility.SYSTEM);
            if(av00 != null) {
                av00.visit("value", new Method("Lorg/mortbay/ijetty/IJettyDownloader;","onCreate",new String[]{ "Landroid/os/Bundle;"},"V"));
                av00.visitEnd();
            }
        }
        if(cv!=null){
            DexAnnotationVisitor av00 = cv.visitAnnotation("Ldalvik/annotation/InnerClass;", Visibility.SYSTEM);
            if(av00 != null) {
                av00.visit("accessFlags",  Integer.valueOf(0));
                av00.visit("name", null);
                av00.visitEnd();
            }
        }
        f000_this$0(cv);
        m000__init_(cv);
        m001_onClick(cv);
    }
    public static void f000_this$0(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_FINAL|ACC_SYNTHETIC, new Field("Lorg/mortbay/ijetty/IJettyDownloader$2;","this$0","Lorg/mortbay/ijetty/IJettyDownloader;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void m000__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_CONSTRUCTOR, new Method("Lorg/mortbay/ijetty/IJettyDownloader$2;","<init>",new String[]{ "Lorg/mortbay/ijetty/IJettyDownloader;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(134,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_OBJECT,1,0,new Field("Lorg/mortbay/ijetty/IJettyDownloader$2;","this$0","Lorg/mortbay/ijetty/IJettyDownloader;"));
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/lang/Object;","<init>",new String[]{ },"V"));
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001_onClick(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/ijetty/IJettyDownloader$2;","onClick",new String[]{ "Landroid/view/View;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(7);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"v");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(136,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(137,L1);
                ddv.visitStartLocal(1,L1,"text","Landroid/widget/EditText;",null);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(138,L2);
                ddv.visitStartLocal(2,L2,"url","Ljava/lang/String;",null);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(146,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(140,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(143,L5);
                DexLabel L6=new DexLabel();
                ddv.visitEndLocal(1,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(144,L7);
                ddv.visitRestartLocal(1,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(145,L8);
                ddv.visitStartLocal(0,L8,"path","Ljava/lang/String;",null);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,3,5,new Field("Lorg/mortbay/ijetty/IJettyDownloader$2;","this$0","Lorg/mortbay/ijetty/IJettyDownloader;"));
                code.visitConstStmt(CONST,4, Integer.valueOf(2131165190)); // int: 0x7f070006  float:179445901125421260000000000000000000000.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,4},new Method("Lorg/mortbay/ijetty/IJettyDownloader;","findViewById",new String[]{ "I"},"Landroid/view/View;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitTypeStmt(CHECK_CAST,1,-1,"Landroid/widget/EditText;");
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Landroid/widget/EditText;","getText",new String[]{ },"Landroid/text/Editable;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Ljava/lang/Object;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitLabel(L2);
                code.visitJumpStmt(IF_NEZ,2,-1,L4);
                code.visitLabel(L3);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L4);
                code.visitConstStmt(CONST_STRING,3,"");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Ljava/lang/String;","trim",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,4},new Method("Ljava/lang/String;","equals",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitJumpStmt(IF_NEZ,3,-1,L3);
                code.visitLabel(L5);
                code.visitFieldStmt(IGET_OBJECT,3,5,new Field("Lorg/mortbay/ijetty/IJettyDownloader$2;","this$0","Lorg/mortbay/ijetty/IJettyDownloader;"));
                code.visitConstStmt(CONST,4, Integer.valueOf(2131165191)); // int: 0x7f070007  float:179445921407830870000000000000000000000.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,4},new Method("Lorg/mortbay/ijetty/IJettyDownloader;","findViewById",new String[]{ "I"},"Landroid/view/View;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L6);
                code.visitTypeStmt(CHECK_CAST,1,-1,"Landroid/widget/EditText;");
                code.visitLabel(L7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Landroid/widget/EditText;","getText",new String[]{ },"Landroid/text/Editable;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Ljava/lang/Object;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L8);
                code.visitFieldStmt(IGET_OBJECT,3,5,new Field("Lorg/mortbay/ijetty/IJettyDownloader$2;","this$0","Lorg/mortbay/ijetty/IJettyDownloader;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,2,0},new Method("Lorg/mortbay/ijetty/IJettyDownloader;","startDownload",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L3);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
