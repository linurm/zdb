package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0254_org_mortbay_jetty_handler_RequestLogHandler {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(ACC_PUBLIC,"Lorg/mortbay/jetty/handler/RequestLogHandler;","Lorg/mortbay/jetty/handler/HandlerWrapper;",new String[]{ });
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("RequestLogHandler.java");
        f000__requestLog(cv);
        m000__init_(cv);
        m001_doStart(cv);
        m002_doStop(cv);
        m003_getRequestLog(cv);
        m004_handle(cv);
        m005_setRequestLog(cv);
        m006_setServer(cv);
    }
    public static void f000__requestLog(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/handler/RequestLogHandler;","_requestLog","Lorg/mortbay/jetty/RequestLog;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void m000__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/jetty/handler/RequestLogHandler;","<init>",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(1);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(38,L0);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Lorg/mortbay/jetty/handler/HandlerWrapper;","<init>",new String[]{ },"V"));
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001_doStart(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Lorg/mortbay/jetty/handler/RequestLogHandler;","doStart",new String[]{ },"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/lang/Exception;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(115,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(116,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(117,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(118,L3);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_SUPER,new int[]{ 1},new Method("Lorg/mortbay/jetty/handler/HandlerWrapper;","doStart",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/handler/RequestLogHandler;","_requestLog","Lorg/mortbay/jetty/RequestLog;"));
                code.visitJumpStmt(IF_EQZ,0,-1,L3);
                code.visitLabel(L2);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/handler/RequestLogHandler;","_requestLog","Lorg/mortbay/jetty/RequestLog;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0},new Method("Lorg/mortbay/jetty/RequestLog;","start",new String[]{ },"V"));
                code.visitLabel(L3);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m002_doStop(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Lorg/mortbay/jetty/handler/RequestLogHandler;","doStop",new String[]{ },"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/lang/Exception;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(126,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(127,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(128,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(129,L3);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_SUPER,new int[]{ 1},new Method("Lorg/mortbay/jetty/handler/HandlerWrapper;","doStop",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/handler/RequestLogHandler;","_requestLog","Lorg/mortbay/jetty/RequestLog;"));
                code.visitJumpStmt(IF_EQZ,0,-1,L3);
                code.visitLabel(L2);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/handler/RequestLogHandler;","_requestLog","Lorg/mortbay/jetty/RequestLog;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0},new Method("Lorg/mortbay/jetty/RequestLog;","stop",new String[]{ },"V"));
                code.visitLabel(L3);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m003_getRequestLog(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/handler/RequestLogHandler;","getRequestLog",new String[]{ },"Lorg/mortbay/jetty/RequestLog;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(106,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/handler/RequestLogHandler;","_requestLog","Lorg/mortbay/jetty/RequestLog;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m004_handle(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/handler/RequestLogHandler;","handle",new String[]{ "Ljava/lang/String;","Ljavax/servlet/http/HttpServletRequest;","Ljavax/servlet/http/HttpServletResponse;","I"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visit(null, new DexType("Ljavax/servlet/ServletException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(6);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"target");
                ddv.visitParameterName(1,"request");
                ddv.visitParameterName(2,"response");
                ddv.visitParameterName(3,"dispatch");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(49,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(50,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(51,L2);
                DexLabel L3=new DexLabel();
                ddv.visitEndLocal(3,L3);
                DexLabel L4=new DexLabel();
                ddv.visitEndLocal(4,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(52,L5);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_SUPER,new int[]{ 1,2,3,4,5},new Method("Lorg/mortbay/jetty/handler/HandlerWrapper;","handle",new String[]{ "Ljava/lang/String;","Ljavax/servlet/http/HttpServletRequest;","Ljavax/servlet/http/HttpServletResponse;","I"},"V"));
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitJumpStmt(IF_NE,5,0,L5);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/handler/RequestLogHandler;","_requestLog","Lorg/mortbay/jetty/RequestLog;"));
                code.visitJumpStmt(IF_EQZ,0,-1,L5);
                code.visitLabel(L2);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/handler/RequestLogHandler;","_requestLog","Lorg/mortbay/jetty/RequestLog;"));
                code.visitTypeStmt(CHECK_CAST,3,-1,"Lorg/mortbay/jetty/Request;");
                code.visitLabel(L3);
                code.visitTypeStmt(CHECK_CAST,4,-1,"Lorg/mortbay/jetty/Response;");
                code.visitLabel(L4);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,3,4},new Method("Lorg/mortbay/jetty/RequestLog;","log",new String[]{ "Lorg/mortbay/jetty/Request;","Lorg/mortbay/jetty/Response;"},"V"));
                code.visitLabel(L5);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m005_setRequestLog(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/handler/RequestLogHandler;","setRequestLog",new String[]{ "Lorg/mortbay/jetty/RequestLog;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(9);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ "Ljava/lang/Exception;"});
                DexLabel L3=new DexLabel();
                DexLabel L4=new DexLabel();
                DexLabel L5=new DexLabel();
                code.visitTryCatch(L3,L4,new DexLabel[]{L5},new String[]{ "Ljava/lang/Exception;"});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"requestLog");
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(60,L0);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(61,L6);
                ddv.visitLineNumber(68,L1);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(69,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(71,L8);
                ddv.visitLineNumber(76,L3);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(77,L9);
                ddv.visitLineNumber(83,L4);
                ddv.visitLineNumber(63,L2);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(65,L10);
                ddv.visitStartLocal(6,L10,"e","Ljava/lang/Exception;",null);
                ddv.visitLineNumber(79,L5);
                ddv.visitEndLocal(6,L5);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(81,L11);
                ddv.visitRestartLocal(6,L11);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,7,new Field("Lorg/mortbay/jetty/handler/RequestLogHandler;","_requestLog","Lorg/mortbay/jetty/RequestLog;"));
                code.visitJumpStmt(IF_EQZ,0,-1,L1);
                code.visitLabel(L6);
                code.visitFieldStmt(IGET_OBJECT,0,7,new Field("Lorg/mortbay/jetty/handler/RequestLogHandler;","_requestLog","Lorg/mortbay/jetty/RequestLog;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0},new Method("Lorg/mortbay/jetty/RequestLog;","stop",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7},new Method("Lorg/mortbay/jetty/handler/RequestLogHandler;","getServer",new String[]{ },"Lorg/mortbay/jetty/Server;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitJumpStmt(IF_EQZ,0,-1,L8);
                code.visitLabel(L7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7},new Method("Lorg/mortbay/jetty/handler/RequestLogHandler;","getServer",new String[]{ },"Lorg/mortbay/jetty/Server;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/jetty/Server;","getContainer",new String[]{ },"Lorg/mortbay/component/Container;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(IGET_OBJECT,2,7,new Field("Lorg/mortbay/jetty/handler/RequestLogHandler;","_requestLog","Lorg/mortbay/jetty/RequestLog;"));
                code.visitConstStmt(CONST_STRING,4,"logimpl");
                code.visitConstStmt(CONST_4,5, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitStmt2R(MOVE_OBJECT,1,7);
                code.visitStmt2R(MOVE_OBJECT,3,8);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 0,1,2,3,4,5},new Method("Lorg/mortbay/component/Container;","update",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;","Ljava/lang/Object;","Ljava/lang/String;","Z"},"V"));
                code.visitLabel(L8);
                code.visitFieldStmt(IPUT_OBJECT,8,7,new Field("Lorg/mortbay/jetty/handler/RequestLogHandler;","_requestLog","Lorg/mortbay/jetty/RequestLog;"));
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7},new Method("Lorg/mortbay/jetty/handler/RequestLogHandler;","isStarted",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_EQZ,0,-1,L4);
                code.visitFieldStmt(IGET_OBJECT,0,7,new Field("Lorg/mortbay/jetty/handler/RequestLogHandler;","_requestLog","Lorg/mortbay/jetty/RequestLog;"));
                code.visitJumpStmt(IF_EQZ,0,-1,L4);
                code.visitLabel(L9);
                code.visitFieldStmt(IGET_OBJECT,0,7,new Field("Lorg/mortbay/jetty/handler/RequestLogHandler;","_requestLog","Lorg/mortbay/jetty/RequestLog;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0},new Method("Lorg/mortbay/jetty/RequestLog;","start",new String[]{ },"V"));
                code.visitLabel(L4);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,0);
                code.visitStmt2R(MOVE_OBJECT,6,0);
                code.visitLabel(L10);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 6},new Method("Lorg/mortbay/log/Log;","warn",new String[]{ "Ljava/lang/Throwable;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L1);
                code.visitLabel(L5);
                code.visitStmt1R(MOVE_EXCEPTION,0);
                code.visitStmt2R(MOVE_OBJECT,6,0);
                code.visitLabel(L11);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/lang/RuntimeException;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,6},new Method("Ljava/lang/RuntimeException;","<init>",new String[]{ "Ljava/lang/Throwable;"},"V"));
                code.visitStmt1R(THROW,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m006_setServer(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/handler/RequestLogHandler;","setServer",new String[]{ "Lorg/mortbay/jetty/Server;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(14);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"server");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(91,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(93,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(94,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(95,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(96,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(97,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(101,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(100,L8);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitConstStmt(CONST_4,5, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitConstStmt(CONST_STRING,4,"logimpl");
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,0,12,new Field("Lorg/mortbay/jetty/handler/RequestLogHandler;","_requestLog","Lorg/mortbay/jetty/RequestLog;"));
                code.visitJumpStmt(IF_EQZ,0,-1,L8);
                code.visitLabel(L2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 12},new Method("Lorg/mortbay/jetty/handler/RequestLogHandler;","getServer",new String[]{ },"Lorg/mortbay/jetty/Server;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitJumpStmt(IF_EQZ,0,-1,L4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 12},new Method("Lorg/mortbay/jetty/handler/RequestLogHandler;","getServer",new String[]{ },"Lorg/mortbay/jetty/Server;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitJumpStmt(IF_EQ,0,13,L4);
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 12},new Method("Lorg/mortbay/jetty/handler/RequestLogHandler;","getServer",new String[]{ },"Lorg/mortbay/jetty/Server;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/jetty/Server;","getContainer",new String[]{ },"Lorg/mortbay/component/Container;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(IGET_OBJECT,2,12,new Field("Lorg/mortbay/jetty/handler/RequestLogHandler;","_requestLog","Lorg/mortbay/jetty/RequestLog;"));
                code.visitConstStmt(CONST_STRING,1,"logimpl");
                code.visitStmt2R(MOVE_OBJECT,1,12);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 0,1,2,3,4,5},new Method("Lorg/mortbay/component/Container;","update",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;","Ljava/lang/Object;","Ljava/lang/String;","Z"},"V"));
                code.visitLabel(L4);
                code.visitMethodStmt(INVOKE_SUPER,new int[]{ 12,13},new Method("Lorg/mortbay/jetty/handler/HandlerWrapper;","setServer",new String[]{ "Lorg/mortbay/jetty/Server;"},"V"));
                code.visitLabel(L5);
                code.visitJumpStmt(IF_EQZ,13,-1,L7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 12},new Method("Lorg/mortbay/jetty/handler/RequestLogHandler;","getServer",new String[]{ },"Lorg/mortbay/jetty/Server;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitJumpStmt(IF_EQ,13,0,L7);
                code.visitLabel(L6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 13},new Method("Lorg/mortbay/jetty/Server;","getContainer",new String[]{ },"Lorg/mortbay/component/Container;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitFieldStmt(IGET_OBJECT,9,12,new Field("Lorg/mortbay/jetty/handler/RequestLogHandler;","_requestLog","Lorg/mortbay/jetty/RequestLog;"));
                code.visitConstStmt(CONST_STRING,0,"logimpl");
                code.visitStmt2R(MOVE_OBJECT,7,12);
                code.visitStmt2R(MOVE_OBJECT,8,3);
                code.visitStmt2R(MOVE_OBJECT,10,4);
                code.visitStmt2R(MOVE,11,5);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 6,7,8,9,10,11},new Method("Lorg/mortbay/component/Container;","update",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;","Ljava/lang/Object;","Ljava/lang/String;","Z"},"V"));
                code.visitLabel(L7);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L8);
                code.visitMethodStmt(INVOKE_SUPER,new int[]{ 12,13},new Method("Lorg/mortbay/jetty/handler/HandlerWrapper;","setServer",new String[]{ "Lorg/mortbay/jetty/Server;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L7);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
