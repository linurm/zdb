package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0189_org_mortbay_jetty_Response {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(ACC_PUBLIC,"Lorg/mortbay/jetty/Response;","Ljava/lang/Object;",new String[]{ "Ljavax/servlet/http/HttpServletResponse;"});
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("Response.java");
        if(cv!=null){
            DexAnnotationVisitor av00 = cv.visitAnnotation("Ldalvik/annotation/MemberClasses;", Visibility.SYSTEM);
            if(av00 != null) {
                {
                    DexAnnotationVisitor av01 = av00.visitArray("value");
                    if(av01 != null) {
                        av01.visit(null, new DexType("Lorg/mortbay/jetty/Response$1;"));
                        av01.visit(null, new DexType("Lorg/mortbay/jetty/Response$NullOutput;"));
                        av01.visitEnd();
                    }
                }
                av00.visitEnd();
            }
        }
        f000_DISABLED(cv);
        f001_NONE(cv);
        f002_STREAM(cv);
        f003_WRITER(cv);
        f004___nullPrintWriter(cv);
        f005___nullServletOut(cv);
        f006__cachedMimeType(cv);
        f007__characterEncoding(cv);
        f008__connection(cv);
        f009__contentType(cv);
        f010__explicitEncoding(cv);
        f011__locale(cv);
        f012__mimeType(cv);
        f013__outputState(cv);
        f014__reason(cv);
        f015__status(cv);
        f016__writer(cv);
        m000__clinit_(cv);
        m001__init_(cv);
        m002_addCookie(cv);
        m003_addDateHeader(cv);
        m004_addHeader(cv);
        m005_addIntHeader(cv);
        m006_complete(cv);
        m007_containsHeader(cv);
        m008_encodeRedirectURL(cv);
        m009_encodeRedirectUrl(cv);
        m010_encodeURL(cv);
        m011_encodeUrl(cv);
        m012_flushBuffer(cv);
        m013_getBufferSize(cv);
        m014_getCharacterEncoding(cv);
        m015_getContentCount(cv);
        m016_getContentType(cv);
        m017_getHeader(cv);
        m018_getHeaders(cv);
        m019_getHttpFields(cv);
        m020_getLocale(cv);
        m021_getOutputStream(cv);
        m022_getReason(cv);
        m023_getSetCharacterEncoding(cv);
        m024_getStatus(cv);
        m025_getWriter(cv);
        m026_isCommitted(cv);
        m027_isWriting(cv);
        m028_recycle(cv);
        m029_reset(cv);
        m030_resetBuffer(cv);
        m031_sendError(cv);
        m032_sendError(cv);
        m033_sendProcessing(cv);
        m034_sendRedirect(cv);
        m035_setBufferSize(cv);
        m036_setCharacterEncoding(cv);
        m037_setContentLength(cv);
        m038_setContentType(cv);
        m039_setDateHeader(cv);
        m040_setHeader(cv);
        m041_setIntHeader(cv);
        m042_setLocale(cv);
        m043_setLongContentLength(cv);
        m044_setStatus(cv);
        m045_setStatus(cv);
        m046_toString(cv);
    }
    public static void f000_DISABLED(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/Response;","DISABLED","I"),  Integer.valueOf(-1));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f001_NONE(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/Response;","NONE","I"),  Integer.valueOf(0));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f002_STREAM(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/Response;","STREAM","I"),  Integer.valueOf(1));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f003_WRITER(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/Response;","WRITER","I"),  Integer.valueOf(2));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f004___nullPrintWriter(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE|ACC_STATIC, new Field("Lorg/mortbay/jetty/Response;","__nullPrintWriter","Ljava/io/PrintWriter;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f005___nullServletOut(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE|ACC_STATIC, new Field("Lorg/mortbay/jetty/Response;","__nullServletOut","Ljavax/servlet/ServletOutputStream;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f006__cachedMimeType(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/Response;","_cachedMimeType","Lorg/mortbay/io/BufferCache$CachedBuffer;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f007__characterEncoding(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/Response;","_characterEncoding","Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f008__connection(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/Response;","_connection","Lorg/mortbay/jetty/HttpConnection;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f009__contentType(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/Response;","_contentType","Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f010__explicitEncoding(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/Response;","_explicitEncoding","Z"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f011__locale(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/Response;","_locale","Ljava/util/Locale;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f012__mimeType(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/Response;","_mimeType","Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f013__outputState(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/Response;","_outputState","I"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f014__reason(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/Response;","_reason","Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f015__status(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/Response;","_status","I"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f016__writer(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/Response;","_writer","Ljava/io/PrintWriter;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void m000__clinit_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_STATIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/jetty/Response;","<clinit>",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ "Ljava/lang/Exception;"});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(63,L0);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(64,L3);
                ddv.visitLineNumber(70,L1);
                ddv.visitLineNumber(66,L2);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(68,L4);
                ddv.visitStartLocal(0,L4,"e","Ljava/lang/Exception;",null);
                code.visitLabel(L0);
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Ljava/io/PrintWriter;");
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Lorg/mortbay/util/IO;","getNullWriter",new String[]{ },"Ljava/io/Writer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1,2},new Method("Ljava/io/PrintWriter;","<init>",new String[]{ "Ljava/io/Writer;"},"V"));
                code.visitFieldStmt(SPUT_OBJECT,1,-1,new Field("Lorg/mortbay/jetty/Response;","__nullPrintWriter","Ljava/io/PrintWriter;"));
                code.visitLabel(L3);
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Lorg/mortbay/jetty/Response$NullOutput;");
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1,2},new Method("Lorg/mortbay/jetty/Response$NullOutput;","<init>",new String[]{ "Lorg/mortbay/jetty/Response$1;"},"V"));
                code.visitFieldStmt(SPUT_OBJECT,1,-1,new Field("Lorg/mortbay/jetty/Response;","__nullServletOut","Ljavax/servlet/ServletOutputStream;"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,1);
                code.visitStmt2R(MOVE_OBJECT,0,1);
                code.visitLabel(L4);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0},new Method("Lorg/mortbay/log/Log;","warn",new String[]{ "Ljava/lang/Throwable;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L1);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/jetty/Response;","<init>",new String[]{ "Lorg/mortbay/jetty/HttpConnection;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"connection");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(89,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(73,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(90,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(91,L3);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1},new Method("Ljava/lang/Object;","<init>",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitConstStmt(CONST_16,0, Integer.valueOf(200)); // int: 0x000000c8  float:0.000000
                code.visitFieldStmt(IPUT,0,1,new Field("Lorg/mortbay/jetty/Response;","_status","I"));
                code.visitLabel(L2);
                code.visitFieldStmt(IPUT_OBJECT,2,1,new Field("Lorg/mortbay/jetty/Response;","_connection","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitLabel(L3);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m002_addCookie(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/Response;","addCookie",new String[]{ "Ljavax/servlet/http/Cookie;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"cookie");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(118,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(119,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/Response;","_connection","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/jetty/HttpConnection;","getResponseFields",new String[]{ },"Lorg/mortbay/jetty/HttpFields;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,2},new Method("Lorg/mortbay/jetty/HttpFields;","addSetCookie",new String[]{ "Ljavax/servlet/http/Cookie;"},"V"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m003_addDateHeader(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/Response;","addDateHeader",new String[]{ "Ljava/lang/String;","J"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"name");
                ddv.visitParameterName(1,"date");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(431,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(432,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(433,L2);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/Response;","_connection","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/jetty/HttpConnection;","isIncluding",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_NEZ,0,-1,L2);
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/Response;","_connection","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/jetty/HttpConnection;","getResponseFields",new String[]{ },"Lorg/mortbay/jetty/HttpFields;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,2,3,4},new Method("Lorg/mortbay/jetty/HttpFields;","addDateField",new String[]{ "Ljava/lang/String;","J"},"V"));
                code.visitLabel(L2);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m004_addHeader(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/Response;","addHeader",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(6);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"name");
                ddv.visitParameterName(1,"value");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(479,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(481,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(482,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(483,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(485,L4);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,3,new Field("Lorg/mortbay/jetty/Response;","_connection","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/jetty/HttpConnection;","isIncluding",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_NEZ,0,-1,L4);
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,0,3,new Field("Lorg/mortbay/jetty/Response;","_connection","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/jetty/HttpConnection;","getResponseFields",new String[]{ },"Lorg/mortbay/jetty/HttpFields;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,4,5},new Method("Lorg/mortbay/jetty/HttpFields;","add",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"V"));
                code.visitLabel(L2);
                code.visitConstStmt(CONST_STRING,0,"Content-Length");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,4},new Method("Ljava/lang/String;","equalsIgnoreCase",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_EQZ,0,-1,L4);
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,0,3,new Field("Lorg/mortbay/jetty/Response;","_connection","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpConnection;","_generator","Lorg/mortbay/jetty/Generator;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 5},new Method("Ljava/lang/Long;","parseLong",new String[]{ "Ljava/lang/String;"},"J"));
                code.visitStmt1R(MOVE_RESULT_WIDE,1);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,1,2},new Method("Lorg/mortbay/jetty/Generator;","setContentLength",new String[]{ "J"},"V"));
                code.visitLabel(L4);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m005_addIntHeader(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/Response;","addIntHeader",new String[]{ "Ljava/lang/String;","I"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(6);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"name");
                ddv.visitParameterName(1,"value");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(507,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(509,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(510,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(511,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(513,L4);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,3,new Field("Lorg/mortbay/jetty/Response;","_connection","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/jetty/HttpConnection;","isIncluding",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_NEZ,0,-1,L4);
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,0,3,new Field("Lorg/mortbay/jetty/Response;","_connection","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/jetty/HttpConnection;","getResponseFields",new String[]{ },"Lorg/mortbay/jetty/HttpFields;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitStmt2R(INT_TO_LONG,1,5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,4,1,2},new Method("Lorg/mortbay/jetty/HttpFields;","addLongField",new String[]{ "Ljava/lang/String;","J"},"V"));
                code.visitLabel(L2);
                code.visitConstStmt(CONST_STRING,0,"Content-Length");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,4},new Method("Ljava/lang/String;","equalsIgnoreCase",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_EQZ,0,-1,L4);
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,0,3,new Field("Lorg/mortbay/jetty/Response;","_connection","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpConnection;","_generator","Lorg/mortbay/jetty/Generator;"));
                code.visitStmt2R(INT_TO_LONG,1,5);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,1,2},new Method("Lorg/mortbay/jetty/Generator;","setContentLength",new String[]{ "J"},"V"));
                code.visitLabel(L4);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m006_complete(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/Response;","complete",new String[]{ },"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(1105,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(1106,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/Response;","_connection","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/jetty/HttpConnection;","completeResponse",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m007_containsHeader(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/Response;","containsHeader",new String[]{ "Ljava/lang/String;"},"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"name");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(127,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/Response;","_connection","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/jetty/HttpConnection;","getResponseFields",new String[]{ },"Lorg/mortbay/jetty/HttpFields;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,2},new Method("Lorg/mortbay/jetty/HttpFields;","containsKey",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m008_encodeRedirectURL(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/Response;","encodeRedirectURL",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"url");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(207,L0);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2},new Method("Lorg/mortbay/jetty/Response;","encodeURL",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m009_encodeRedirectUrl(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/Response;","encodeRedirectUrl",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"url");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(225,L0);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2},new Method("Lorg/mortbay/jetty/Response;","encodeURL",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m010_encodeURL(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/Response;","encodeURL",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(14);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"url");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(136,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(137,L2);
                ddv.visitStartLocal(2,L2,"request","Lorg/mortbay/jetty/Request;",null);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(138,L3);
                ddv.visitStartLocal(4,L3,"sessionManager","Lorg/mortbay/jetty/SessionManager;",null);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(197,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(140,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(141,L6);
                ddv.visitStartLocal(5,L6,"sessionURLPrefix","Ljava/lang/String;",null);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(142,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(145,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(147,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(148,L10);
                ddv.visitStartLocal(1,L10,"prefix","I",null);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(150,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(151,L12);
                ddv.visitStartLocal(6,L12,"suffix","I",null);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(152,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(154,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(155,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(156,L16);
                DexLabel L17=new DexLabel();
                ddv.visitEndLocal(6,L17);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(158,L18);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(162,L19);
                ddv.visitEndLocal(1,L19);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(165,L20);
                ddv.visitStartLocal(3,L20,"session","Ljavax/servlet/http/HttpSession;",null);
                DexLabel L21=new DexLabel();
                ddv.visitLineNumber(166,L21);
                DexLabel L22=new DexLabel();
                ddv.visitLineNumber(170,L22);
                DexLabel L23=new DexLabel();
                ddv.visitLineNumber(171,L23);
                DexLabel L24=new DexLabel();
                ddv.visitLineNumber(173,L24);
                DexLabel L25=new DexLabel();
                ddv.visitLineNumber(178,L25);
                ddv.visitStartLocal(0,L25,"id","Ljava/lang/String;",null);
                DexLabel L26=new DexLabel();
                ddv.visitLineNumber(179,L26);
                ddv.visitRestartLocal(1,L26);
                DexLabel L27=new DexLabel();
                ddv.visitLineNumber(181,L27);
                DexLabel L28=new DexLabel();
                ddv.visitLineNumber(182,L28);
                ddv.visitRestartLocal(6,L28);
                DexLabel L29=new DexLabel();
                ddv.visitLineNumber(183,L29);
                DexLabel L30=new DexLabel();
                ddv.visitLineNumber(185,L30);
                ddv.visitRestartLocal(6,L30);
                DexLabel L31=new DexLabel();
                ddv.visitLineNumber(186,L31);
                DexLabel L32=new DexLabel();
                ddv.visitLineNumber(187,L32);
                DexLabel L33=new DexLabel();
                ddv.visitLineNumber(192,L33);
                ddv.visitEndLocal(6,L33);
                DexLabel L34=new DexLabel();
                ddv.visitLineNumber(193,L34);
                ddv.visitRestartLocal(6,L34);
                DexLabel L35=new DexLabel();
                ddv.visitLineNumber(194,L35);
                DexLabel L36=new DexLabel();
                ddv.visitLineNumber(195,L36);
                ddv.visitRestartLocal(6,L36);
                DexLabel L37=new DexLabel();
                ddv.visitLineNumber(196,L37);
                DexLabel L38=new DexLabel();
                ddv.visitLineNumber(197,L38);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,8, Integer.valueOf(-1)); // int: 0xffffffff  float:NaN
                code.visitConstStmt(CONST_4,9, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitConstStmt(CONST_STRING,11,"?");
                code.visitConstStmt(CONST_STRING,10,"#");
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,7,12,new Field("Lorg/mortbay/jetty/Response;","_connection","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7},new Method("Lorg/mortbay/jetty/HttpConnection;","getRequest",new String[]{ },"Lorg/mortbay/jetty/Request;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitLabel(L2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/jetty/Request;","getSessionManager",new String[]{ },"Lorg/mortbay/jetty/SessionManager;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitLabel(L3);
                code.visitJumpStmt(IF_NEZ,4,-1,L5);
                code.visitStmt2R(MOVE_OBJECT,7,13);
                code.visitLabel(L4);
                code.visitStmt1R(RETURN_OBJECT,7);
                code.visitLabel(L5);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 4},new Method("Lorg/mortbay/jetty/SessionManager;","getSessionURLPrefix",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitLabel(L6);
                code.visitJumpStmt(IF_NEZ,5,-1,L8);
                code.visitStmt2R(MOVE_OBJECT,7,13);
                code.visitLabel(L7);
                code.visitJumpStmt(GOTO,-1,-1,L4);
                code.visitLabel(L8);
                code.visitJumpStmt(IF_EQZ,13,-1,L9);
                code.visitJumpStmt(IF_EQZ,2,-1,L9);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/jetty/Request;","isRequestedSessionIdFromCookie",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,7);
                code.visitJumpStmt(IF_EQZ,7,-1,L19);
                code.visitLabel(L9);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 13,5},new Method("Ljava/lang/String;","indexOf",new String[]{ "Ljava/lang/String;"},"I"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitLabel(L10);
                code.visitJumpStmt(IF_EQ,1,8,L17);
                code.visitLabel(L11);
                code.visitConstStmt(CONST_STRING,7,"?");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 13,11,1},new Method("Ljava/lang/String;","indexOf",new String[]{ "Ljava/lang/String;","I"},"I"));
                code.visitStmt1R(MOVE_RESULT,6);
                code.visitLabel(L12);
                code.visitJumpStmt(IF_GEZ,6,-1,L14);
                code.visitLabel(L13);
                code.visitConstStmt(CONST_STRING,7,"#");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 13,10,1},new Method("Ljava/lang/String;","indexOf",new String[]{ "Ljava/lang/String;","I"},"I"));
                code.visitStmt1R(MOVE_RESULT,6);
                code.visitLabel(L14);
                code.visitJumpStmt(IF_GT,6,1,L16);
                code.visitLabel(L15);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 13,9,1},new Method("Ljava/lang/String;","substring",new String[]{ "I","I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitJumpStmt(GOTO,-1,-1,L4);
                code.visitLabel(L16);
                code.visitTypeStmt(NEW_INSTANCE,7,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 7},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 13,9,1},new Method("Ljava/lang/String;","substring",new String[]{ "I","I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7,8},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 13,6},new Method("Ljava/lang/String;","substring",new String[]{ "I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7,8},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitJumpStmt(GOTO,-1,-1,L4);
                code.visitLabel(L17);
                code.visitStmt2R(MOVE_OBJECT,7,13);
                code.visitLabel(L18);
                code.visitJumpStmt(GOTO,-1,-1,L4);
                code.visitLabel(L19);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,9},new Method("Lorg/mortbay/jetty/Request;","getSession",new String[]{ "Z"},"Ljavax/servlet/http/HttpSession;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitLabel(L20);
                code.visitJumpStmt(IF_NEZ,3,-1,L22);
                code.visitStmt2R(MOVE_OBJECT,7,13);
                code.visitLabel(L21);
                code.visitJumpStmt(GOTO,-1,-1,L4);
                code.visitLabel(L22);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 4,3},new Method("Lorg/mortbay/jetty/SessionManager;","isValid",new String[]{ "Ljavax/servlet/http/HttpSession;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,7);
                code.visitJumpStmt(IF_NEZ,7,-1,L24);
                code.visitStmt2R(MOVE_OBJECT,7,13);
                code.visitLabel(L23);
                code.visitJumpStmt(GOTO,-1,-1,L4);
                code.visitLabel(L24);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 4,3},new Method("Lorg/mortbay/jetty/SessionManager;","getNodeId",new String[]{ "Ljavax/servlet/http/HttpSession;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L25);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 13,5},new Method("Ljava/lang/String;","indexOf",new String[]{ "Ljava/lang/String;"},"I"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitLabel(L26);
                code.visitJumpStmt(IF_EQ,1,8,L33);
                code.visitLabel(L27);
                code.visitConstStmt(CONST_STRING,7,"?");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 13,11,1},new Method("Ljava/lang/String;","indexOf",new String[]{ "Ljava/lang/String;","I"},"I"));
                code.visitStmt1R(MOVE_RESULT,6);
                code.visitLabel(L28);
                code.visitJumpStmt(IF_GEZ,6,-1,L30);
                code.visitLabel(L29);
                code.visitConstStmt(CONST_STRING,7,"#");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 13,10,1},new Method("Ljava/lang/String;","indexOf",new String[]{ "Ljava/lang/String;","I"},"I"));
                code.visitStmt1R(MOVE_RESULT,6);
                code.visitLabel(L30);
                code.visitJumpStmt(IF_GT,6,1,L32);
                code.visitLabel(L31);
                code.visitTypeStmt(NEW_INSTANCE,7,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 7},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Ljava/lang/String;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,8);
                code.visitStmt2R(ADD_INT_2ADDR,8,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 13,9,8},new Method("Ljava/lang/String;","substring",new String[]{ "I","I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7,8},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7,0},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitJumpStmt(GOTO_16,-1,-1,L4);
                code.visitLabel(L32);
                code.visitTypeStmt(NEW_INSTANCE,7,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 7},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Ljava/lang/String;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,8);
                code.visitStmt2R(ADD_INT_2ADDR,8,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 13,9,8},new Method("Ljava/lang/String;","substring",new String[]{ "I","I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7,8},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7,0},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 13,6},new Method("Ljava/lang/String;","substring",new String[]{ "I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7,8},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitJumpStmt(GOTO_16,-1,-1,L4);
                code.visitLabel(L33);
                code.visitConstStmt(CONST_16,7, Integer.valueOf(63)); // int: 0x0000003f  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 13,7},new Method("Ljava/lang/String;","indexOf",new String[]{ "I"},"I"));
                code.visitStmt1R(MOVE_RESULT,6);
                code.visitLabel(L34);
                code.visitJumpStmt(IF_GEZ,6,-1,L36);
                code.visitLabel(L35);
                code.visitConstStmt(CONST_16,7, Integer.valueOf(35)); // int: 0x00000023  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 13,7},new Method("Ljava/lang/String;","indexOf",new String[]{ "I"},"I"));
                code.visitStmt1R(MOVE_RESULT,6);
                code.visitLabel(L36);
                code.visitJumpStmt(IF_GEZ,6,-1,L38);
                code.visitLabel(L37);
                code.visitTypeStmt(NEW_INSTANCE,7,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 7},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7,13},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7,5},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7,0},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitJumpStmt(GOTO_16,-1,-1,L4);
                code.visitLabel(L38);
                code.visitTypeStmt(NEW_INSTANCE,7,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 7},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 13,9,6},new Method("Ljava/lang/String;","substring",new String[]{ "I","I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7,8},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7,5},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7,0},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 13,6},new Method("Ljava/lang/String;","substring",new String[]{ "I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7,8},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitJumpStmt(GOTO_16,-1,-1,L4);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m011_encodeUrl(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/Response;","encodeUrl",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"url");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(216,L0);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2},new Method("Lorg/mortbay/jetty/Response;","encodeURL",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m012_flushBuffer(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/Response;","flushBuffer",new String[]{ },"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(937,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(938,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/Response;","_connection","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/jetty/HttpConnection;","flushResponse",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m013_getBufferSize(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/Response;","getBufferSize",new String[]{ },"I"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(928,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/Response;","_connection","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/jetty/HttpConnection;","getGenerator",new String[]{ },"Lorg/mortbay/jetty/Generator;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0},new Method("Lorg/mortbay/jetty/Generator;","getContentBufferSize",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m014_getCharacterEncoding(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/Response;","getCharacterEncoding",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(543,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(544,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(545,L2);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/Response;","_characterEncoding","Ljava/lang/String;"));
                code.visitJumpStmt(IF_NEZ,0,-1,L2);
                code.visitLabel(L1);
                code.visitFieldStmt(SGET_OBJECT,0,-1,new Field("Lorg/mortbay/util/StringUtil;","__ISO_8859_1","Ljava/lang/String;"));
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/jetty/Response;","_characterEncoding","Ljava/lang/String;"));
                code.visitLabel(L2);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/Response;","_characterEncoding","Ljava/lang/String;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m015_getContentCount(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/Response;","getContentCount",new String[]{ },"J"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(1114,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(1115,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(1116,L2);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/jetty/Response;","_connection","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitJumpStmt(IF_EQZ,0,-1,L1);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/jetty/Response;","_connection","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/jetty/HttpConnection;","getGenerator",new String[]{ },"Lorg/mortbay/jetty/Generator;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                DexLabel L3=new DexLabel();
                code.visitJumpStmt(IF_NEZ,0,-1,L3);
                code.visitLabel(L1);
                code.visitConstStmt(CONST_WIDE_16,0,Long.valueOf(-1L)); // long: 0xffffffffffffffff  double:NaN
                code.visitLabel(L2);
                code.visitStmt1R(RETURN_WIDE,0);
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/jetty/Response;","_connection","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/jetty/HttpConnection;","getGenerator",new String[]{ },"Lorg/mortbay/jetty/Generator;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0},new Method("Lorg/mortbay/jetty/Generator;","getContentWritten",new String[]{ },"J"));
                code.visitStmt1R(MOVE_RESULT_WIDE,0);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m016_getContentType(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/Response;","getContentType",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(560,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/Response;","_contentType","Ljava/lang/String;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m017_getHeader(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/Response;","getHeader",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"name");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(459,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/Response;","_connection","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/jetty/HttpConnection;","getResponseFields",new String[]{ },"Lorg/mortbay/jetty/HttpFields;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,2},new Method("Lorg/mortbay/jetty/HttpFields;","getStringField",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m018_getHeaders(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/Response;","getHeaders",new String[]{ "Ljava/lang/String;"},"Ljava/util/Enumeration;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"name");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(467,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(468,L1);
                ddv.visitStartLocal(0,L1,"e","Ljava/util/Enumeration;",null);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(469,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(470,L3);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/jetty/Response;","_connection","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Lorg/mortbay/jetty/HttpConnection;","getResponseFields",new String[]{ },"Lorg/mortbay/jetty/HttpFields;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,3},new Method("Lorg/mortbay/jetty/HttpFields;","getValues",new String[]{ "Ljava/lang/String;"},"Ljava/util/Enumeration;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L1);
                DexLabel L4=new DexLabel();
                code.visitJumpStmt(IF_NEZ,0,-1,L4);
                code.visitLabel(L2);
                code.visitFieldStmt(SGET_OBJECT,1,-1,new Field("Ljava/util/Collections;","EMPTY_LIST","Ljava/util/List;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1},new Method("Ljava/util/Collections;","enumeration",new String[]{ "Ljava/util/Collection;"},"Ljava/util/Enumeration;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L3);
                code.visitStmt1R(RETURN_OBJECT,1);
                code.visitLabel(L4);
                code.visitStmt2R(MOVE_OBJECT,1,0);
                code.visitJumpStmt(GOTO,-1,-1,L3);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m019_getHttpFields(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/Response;","getHttpFields",new String[]{ },"Lorg/mortbay/jetty/HttpFields;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(1122,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/Response;","_connection","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/jetty/HttpConnection;","getResponseFields",new String[]{ },"Lorg/mortbay/jetty/HttpFields;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m020_getLocale(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/Response;","getLocale",new String[]{ },"Ljava/util/Locale;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(1070,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(1071,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(1072,L2);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/Response;","_locale","Ljava/util/Locale;"));
                DexLabel L3=new DexLabel();
                code.visitJumpStmt(IF_NEZ,0,-1,L3);
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Ljava/util/Locale;","getDefault",new String[]{ },"Ljava/util/Locale;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L2);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/Response;","_locale","Ljava/util/Locale;"));
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m021_getOutputStream(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/Response;","getOutputStream",new String[]{ },"Ljavax/servlet/ServletOutputStream;"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(569,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(570,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(576,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(572,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(573,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(575,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(576,L7);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitLabel(L1);
                code.visitFieldStmt(IGET,0,3,new Field("Lorg/mortbay/jetty/Response;","_outputState","I"));
                code.visitConstStmt(CONST_4,1, Integer.valueOf(-1)); // int: 0xffffffff  float:NaN
                code.visitJumpStmt(IF_NE,0,1,L4);
                code.visitLabel(L2);
                code.visitFieldStmt(SGET_OBJECT,0,-1,new Field("Lorg/mortbay/jetty/Response;","__nullServletOut","Ljavax/servlet/ServletOutputStream;"));
                code.visitLabel(L3);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitLabel(L4);
                code.visitFieldStmt(IGET,0,3,new Field("Lorg/mortbay/jetty/Response;","_outputState","I"));
                code.visitJumpStmt(IF_EQZ,0,-1,L6);
                code.visitFieldStmt(IGET,0,3,new Field("Lorg/mortbay/jetty/Response;","_outputState","I"));
                code.visitJumpStmt(IF_EQ,0,2,L6);
                code.visitLabel(L5);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/lang/IllegalStateException;");
                code.visitConstStmt(CONST_STRING,1,"WRITER");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1},new Method("Ljava/lang/IllegalStateException;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitStmt1R(THROW,0);
                code.visitLabel(L6);
                code.visitFieldStmt(IPUT,2,3,new Field("Lorg/mortbay/jetty/Response;","_outputState","I"));
                code.visitLabel(L7);
                code.visitFieldStmt(IGET_OBJECT,0,3,new Field("Lorg/mortbay/jetty/Response;","_connection","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/jetty/HttpConnection;","getOutputStream",new String[]{ },"Ljavax/servlet/ServletOutputStream;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitJumpStmt(GOTO,-1,-1,L3);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m022_getReason(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/Response;","getReason",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(1092,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/Response;","_reason","Ljava/lang/String;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m023_getSetCharacterEncoding(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(0, new Method("Lorg/mortbay/jetty/Response;","getSetCharacterEncoding",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(551,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/Response;","_characterEncoding","Ljava/lang/String;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m024_getStatus(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/Response;","getStatus",new String[]{ },"I"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(1082,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET,0,1,new Field("Lorg/mortbay/jetty/Response;","_status","I"));
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m025_getWriter(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/Response;","getWriter",new String[]{ },"Ljava/io/PrintWriter;"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(591,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(592,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(619,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(594,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(595,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(598,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(601,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(603,L8);
                ddv.visitStartLocal(0,L8,"encoding","Ljava/lang/String;",null);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(606,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(607,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(609,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(610,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(612,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(616,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(618,L15);
                ddv.visitEndLocal(0,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(619,L16);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(2)); // int: 0x00000002  float:0.000000
                code.visitLabel(L1);
                code.visitFieldStmt(IGET,1,4,new Field("Lorg/mortbay/jetty/Response;","_outputState","I"));
                code.visitConstStmt(CONST_4,2, Integer.valueOf(-1)); // int: 0xffffffff  float:NaN
                code.visitJumpStmt(IF_NE,1,2,L4);
                code.visitLabel(L2);
                code.visitFieldStmt(SGET_OBJECT,1,-1,new Field("Lorg/mortbay/jetty/Response;","__nullPrintWriter","Ljava/io/PrintWriter;"));
                code.visitLabel(L3);
                code.visitStmt1R(RETURN_OBJECT,1);
                code.visitLabel(L4);
                code.visitFieldStmt(IGET,1,4,new Field("Lorg/mortbay/jetty/Response;","_outputState","I"));
                code.visitJumpStmt(IF_EQZ,1,-1,L6);
                code.visitFieldStmt(IGET,1,4,new Field("Lorg/mortbay/jetty/Response;","_outputState","I"));
                code.visitJumpStmt(IF_EQ,1,3,L6);
                code.visitLabel(L5);
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Ljava/lang/IllegalStateException;");
                code.visitConstStmt(CONST_STRING,2,"STREAM");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1,2},new Method("Ljava/lang/IllegalStateException;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitStmt1R(THROW,1);
                code.visitLabel(L6);
                code.visitFieldStmt(IGET_OBJECT,1,4,new Field("Lorg/mortbay/jetty/Response;","_writer","Ljava/io/PrintWriter;"));
                code.visitJumpStmt(IF_NEZ,1,-1,L15);
                code.visitLabel(L7);
                code.visitFieldStmt(IGET_OBJECT,0,4,new Field("Lorg/mortbay/jetty/Response;","_characterEncoding","Ljava/lang/String;"));
                code.visitLabel(L8);
                code.visitJumpStmt(IF_NEZ,0,-1,L14);
                code.visitLabel(L9);
                code.visitFieldStmt(IGET_OBJECT,1,4,new Field("Lorg/mortbay/jetty/Response;","_mimeType","Ljava/lang/String;"));
                code.visitJumpStmt(IF_EQZ,1,-1,L11);
                code.visitLabel(L10);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L11);
                code.visitJumpStmt(IF_NEZ,0,-1,L13);
                code.visitLabel(L12);
                code.visitFieldStmt(SGET_OBJECT,0,-1,new Field("Lorg/mortbay/util/StringUtil;","__ISO_8859_1","Ljava/lang/String;"));
                code.visitLabel(L13);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,0},new Method("Lorg/mortbay/jetty/Response;","setCharacterEncoding",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L14);
                code.visitFieldStmt(IGET_OBJECT,1,4,new Field("Lorg/mortbay/jetty/Response;","_connection","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,0},new Method("Lorg/mortbay/jetty/HttpConnection;","getPrintWriter",new String[]{ "Ljava/lang/String;"},"Ljava/io/PrintWriter;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitFieldStmt(IPUT_OBJECT,1,4,new Field("Lorg/mortbay/jetty/Response;","_writer","Ljava/io/PrintWriter;"));
                code.visitLabel(L15);
                code.visitFieldStmt(IPUT,3,4,new Field("Lorg/mortbay/jetty/Response;","_outputState","I"));
                code.visitLabel(L16);
                code.visitFieldStmt(IGET_OBJECT,1,4,new Field("Lorg/mortbay/jetty/Response;","_writer","Ljava/io/PrintWriter;"));
                code.visitJumpStmt(GOTO,-1,-1,L3);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m026_isCommitted(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/Response;","isCommitted",new String[]{ },"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(1013,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/Response;","_connection","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/jetty/HttpConnection;","isResponseCommitted",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m027_isWriting(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/Response;","isWriting",new String[]{ },"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(582,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET,0,2,new Field("Lorg/mortbay/jetty/Response;","_outputState","I"));
                code.visitConstStmt(CONST_4,1, Integer.valueOf(2)); // int: 0x00000002  float:0.000000
                DexLabel L1=new DexLabel();
                code.visitJumpStmt(IF_NE,0,1,L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                DexLabel L2=new DexLabel();
                code.visitLabel(L2);
                code.visitStmt1R(RETURN,0);
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m028_recycle(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Lorg/mortbay/jetty/Response;","recycle",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(100,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(101,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(102,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(103,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(104,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(105,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(106,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(107,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(108,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(109,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(110,L11);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L1);
                code.visitConstStmt(CONST_16,0, Integer.valueOf(200)); // int: 0x000000c8  float:0.000000
                code.visitFieldStmt(IPUT,0,3,new Field("Lorg/mortbay/jetty/Response;","_status","I"));
                code.visitLabel(L2);
                code.visitFieldStmt(IPUT_OBJECT,1,3,new Field("Lorg/mortbay/jetty/Response;","_reason","Ljava/lang/String;"));
                code.visitLabel(L3);
                code.visitFieldStmt(IPUT_OBJECT,1,3,new Field("Lorg/mortbay/jetty/Response;","_locale","Ljava/util/Locale;"));
                code.visitLabel(L4);
                code.visitFieldStmt(IPUT_OBJECT,1,3,new Field("Lorg/mortbay/jetty/Response;","_mimeType","Ljava/lang/String;"));
                code.visitLabel(L5);
                code.visitFieldStmt(IPUT_OBJECT,1,3,new Field("Lorg/mortbay/jetty/Response;","_cachedMimeType","Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitLabel(L6);
                code.visitFieldStmt(IPUT_OBJECT,1,3,new Field("Lorg/mortbay/jetty/Response;","_characterEncoding","Ljava/lang/String;"));
                code.visitLabel(L7);
                code.visitFieldStmt(IPUT_BOOLEAN,2,3,new Field("Lorg/mortbay/jetty/Response;","_explicitEncoding","Z"));
                code.visitLabel(L8);
                code.visitFieldStmt(IPUT_OBJECT,1,3,new Field("Lorg/mortbay/jetty/Response;","_contentType","Ljava/lang/String;"));
                code.visitLabel(L9);
                code.visitFieldStmt(IPUT,2,3,new Field("Lorg/mortbay/jetty/Response;","_outputState","I"));
                code.visitLabel(L10);
                code.visitFieldStmt(IPUT_OBJECT,1,3,new Field("Lorg/mortbay/jetty/Response;","_writer","Ljava/io/PrintWriter;"));
                code.visitLabel(L11);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m029_reset(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/Response;","reset",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(13);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(946,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(948,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(949,L3);
                ddv.visitStartLocal(4,L3,"response_fields","Lorg/mortbay/jetty/HttpFields;",null);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(950,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(951,L5);
                ddv.visitStartLocal(1,L5,"connection","Ljava/lang/String;",null);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(953,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(954,L7);
                ddv.visitStartLocal(5,L7,"values","[Ljava/lang/String;",null);
                DexLabel L8=new DexLabel();
                ddv.visitStartLocal(2,L8,"i","I",null);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(956,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(958,L10);
                ddv.visitStartLocal(0,L10,"cb","Lorg/mortbay/io/BufferCache$CachedBuffer;",null);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(960,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(954,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(963,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(967,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(968,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(971,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(978,L17);
                ddv.visitEndLocal(5,L17);
                ddv.visitEndLocal(2,L17);
                ddv.visitEndLocal(0,L17);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(980,L18);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(981,L19);
                ddv.visitStartLocal(3,L19,"request","Lorg/mortbay/jetty/Request;",null);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(984,L20);
                ddv.visitEndLocal(3,L20);
                DexLabel L21=new DexLabel();
                ddv.visitLineNumber(985,L21);
                DexLabel L22=new DexLabel();
                ddv.visitLineNumber(986,L22);
                DexLabel L23=new DexLabel();
                ddv.visitLineNumber(987,L23);
                DexLabel L24=new DexLabel();
                ddv.visitLineNumber(988,L24);
                DexLabel L25=new DexLabel();
                ddv.visitLineNumber(989,L25);
                DexLabel L26=new DexLabel();
                ddv.visitLineNumber(990,L26);
                DexLabel L27=new DexLabel();
                ddv.visitLineNumber(991,L27);
                DexLabel L28=new DexLabel();
                ddv.visitLineNumber(992,L28);
                DexLabel L29=new DexLabel();
                ddv.visitLineNumber(993,L29);
                DexLabel L30=new DexLabel();
                ddv.visitLineNumber(994,L30);
                DexLabel L31=new DexLabel();
                ddv.visitLineNumber(960,L31);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,11, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitConstStmt(CONST_4,10, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 12},new Method("Lorg/mortbay/jetty/Response;","resetBuffer",new String[]{ },"V"));
                code.visitLabel(L2);
                code.visitFieldStmt(IGET_OBJECT,6,12,new Field("Lorg/mortbay/jetty/Response;","_connection","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Lorg/mortbay/jetty/HttpConnection;","getResponseFields",new String[]{ },"Lorg/mortbay/jetty/HttpFields;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Lorg/mortbay/jetty/HttpFields;","clear",new String[]{ },"V"));
                code.visitLabel(L4);
                code.visitFieldStmt(IGET_OBJECT,6,12,new Field("Lorg/mortbay/jetty/Response;","_connection","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Lorg/mortbay/jetty/HttpConnection;","getRequestFields",new String[]{ },"Lorg/mortbay/jetty/HttpFields;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitFieldStmt(SGET_OBJECT,7,-1,new Field("Lorg/mortbay/jetty/HttpHeaders;","CONNECTION_BUFFER","Lorg/mortbay/io/Buffer;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,7},new Method("Lorg/mortbay/jetty/HttpFields;","getStringField",new String[]{ "Lorg/mortbay/io/Buffer;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L5);
                code.visitJumpStmt(IF_EQZ,1,-1,L17);
                code.visitLabel(L6);
                code.visitConstStmt(CONST_STRING,6,",");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,6},new Method("Ljava/lang/String;","split",new String[]{ "Ljava/lang/String;"},"[Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitLabel(L7);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L8);
                code.visitJumpStmt(IF_EQZ,5,-1,L17);
                code.visitStmt2R(ARRAY_LENGTH,6,5);
                code.visitJumpStmt(IF_GE,2,6,L17);
                code.visitLabel(L9);
                code.visitFieldStmt(SGET_OBJECT,6,-1,new Field("Lorg/mortbay/jetty/HttpHeaderValues;","CACHE","Lorg/mortbay/jetty/HttpHeaderValues;"));
                code.visitStmt3R(AGET_OBJECT,7,5,11);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7},new Method("Ljava/lang/String;","trim",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,7},new Method("Lorg/mortbay/jetty/HttpHeaderValues;","get",new String[]{ "Ljava/lang/String;"},"Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L10);
                code.visitJumpStmt(IF_EQZ,0,-1,L12);
                code.visitLabel(L11);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/io/BufferCache$CachedBuffer;","getOrdinal",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,6);
                code.visitSparseSwitchStmt(SPARSE_SWITCH,6,new int[]{ 1,5,8},new DexLabel[]{L13,L14,L16});
                code.visitLabel(L12);
                code.visitStmt2R1N(ADD_INT_LIT8,2,2,1);
                code.visitJumpStmt(GOTO,-1,-1,L8);
                code.visitLabel(L13);
                code.visitFieldStmt(SGET_OBJECT,6,-1,new Field("Lorg/mortbay/jetty/HttpHeaders;","CONNECTION_BUFFER","Lorg/mortbay/io/Buffer;"));
                code.visitFieldStmt(SGET_OBJECT,7,-1,new Field("Lorg/mortbay/jetty/HttpHeaderValues;","CLOSE_BUFFER","Lorg/mortbay/io/Buffer;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,6,7},new Method("Lorg/mortbay/jetty/HttpFields;","put",new String[]{ "Lorg/mortbay/io/Buffer;","Lorg/mortbay/io/Buffer;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L12);
                code.visitLabel(L14);
                code.visitConstStmt(CONST_STRING,6,"HTTP/1.0");
                code.visitFieldStmt(IGET_OBJECT,7,12,new Field("Lorg/mortbay/jetty/Response;","_connection","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7},new Method("Lorg/mortbay/jetty/HttpConnection;","getRequest",new String[]{ },"Lorg/mortbay/jetty/Request;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7},new Method("Lorg/mortbay/jetty/Request;","getProtocol",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,7},new Method("Ljava/lang/String;","equalsIgnoreCase",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,6);
                code.visitJumpStmt(IF_EQZ,6,-1,L12);
                code.visitLabel(L15);
                code.visitFieldStmt(SGET_OBJECT,6,-1,new Field("Lorg/mortbay/jetty/HttpHeaders;","CONNECTION_BUFFER","Lorg/mortbay/io/Buffer;"));
                code.visitConstStmt(CONST_STRING,7,"keep-alive");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,6,7},new Method("Lorg/mortbay/jetty/HttpFields;","put",new String[]{ "Lorg/mortbay/io/Buffer;","Ljava/lang/String;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L12);
                code.visitLabel(L16);
                code.visitFieldStmt(SGET_OBJECT,6,-1,new Field("Lorg/mortbay/jetty/HttpHeaders;","CONNECTION_BUFFER","Lorg/mortbay/io/Buffer;"));
                code.visitConstStmt(CONST_STRING,7,"TE");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,6,7},new Method("Lorg/mortbay/jetty/HttpFields;","put",new String[]{ "Lorg/mortbay/io/Buffer;","Ljava/lang/String;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L12);
                code.visitLabel(L17);
                code.visitFieldStmt(IGET_OBJECT,6,12,new Field("Lorg/mortbay/jetty/Response;","_connection","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Lorg/mortbay/jetty/HttpConnection;","getConnector",new String[]{ },"Lorg/mortbay/jetty/Connector;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 6},new Method("Lorg/mortbay/jetty/Connector;","getServer",new String[]{ },"Lorg/mortbay/jetty/Server;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Lorg/mortbay/jetty/Server;","getSendDateHeader",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,6);
                code.visitJumpStmt(IF_EQZ,6,-1,L20);
                code.visitLabel(L18);
                code.visitFieldStmt(IGET_OBJECT,6,12,new Field("Lorg/mortbay/jetty/Response;","_connection","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Lorg/mortbay/jetty/HttpConnection;","getRequest",new String[]{ },"Lorg/mortbay/jetty/Request;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitLabel(L19);
                code.visitFieldStmt(SGET_OBJECT,6,-1,new Field("Lorg/mortbay/jetty/HttpHeaders;","DATE_BUFFER","Lorg/mortbay/io/Buffer;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Lorg/mortbay/jetty/Request;","getTimeStampBuffer",new String[]{ },"Lorg/mortbay/io/Buffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Lorg/mortbay/jetty/Request;","getTimeStamp",new String[]{ },"J"));
                code.visitStmt1R(MOVE_RESULT_WIDE,8);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,6,7,8,9},new Method("Lorg/mortbay/jetty/HttpFields;","put",new String[]{ "Lorg/mortbay/io/Buffer;","Lorg/mortbay/io/Buffer;","J"},"V"));
                code.visitLabel(L20);
                code.visitConstStmt(CONST_16,6, Integer.valueOf(200)); // int: 0x000000c8  float:0.000000
                code.visitFieldStmt(IPUT,6,12,new Field("Lorg/mortbay/jetty/Response;","_status","I"));
                code.visitLabel(L21);
                code.visitFieldStmt(IPUT_OBJECT,10,12,new Field("Lorg/mortbay/jetty/Response;","_reason","Ljava/lang/String;"));
                code.visitLabel(L22);
                code.visitFieldStmt(IPUT_OBJECT,10,12,new Field("Lorg/mortbay/jetty/Response;","_mimeType","Ljava/lang/String;"));
                code.visitLabel(L23);
                code.visitFieldStmt(IPUT_OBJECT,10,12,new Field("Lorg/mortbay/jetty/Response;","_cachedMimeType","Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitLabel(L24);
                code.visitFieldStmt(IPUT_OBJECT,10,12,new Field("Lorg/mortbay/jetty/Response;","_contentType","Ljava/lang/String;"));
                code.visitLabel(L25);
                code.visitFieldStmt(IPUT_OBJECT,10,12,new Field("Lorg/mortbay/jetty/Response;","_characterEncoding","Ljava/lang/String;"));
                code.visitLabel(L26);
                code.visitFieldStmt(IPUT_BOOLEAN,11,12,new Field("Lorg/mortbay/jetty/Response;","_explicitEncoding","Z"));
                code.visitLabel(L27);
                code.visitFieldStmt(IPUT_OBJECT,10,12,new Field("Lorg/mortbay/jetty/Response;","_locale","Ljava/util/Locale;"));
                code.visitLabel(L28);
                code.visitFieldStmt(IPUT,11,12,new Field("Lorg/mortbay/jetty/Response;","_outputState","I"));
                code.visitLabel(L29);
                code.visitFieldStmt(IPUT_OBJECT,10,12,new Field("Lorg/mortbay/jetty/Response;","_writer","Ljava/io/PrintWriter;"));
                code.visitLabel(L30);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L31);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m030_resetBuffer(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/Response;","resetBuffer",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(1002,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(1003,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(1004,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(1005,L3);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/jetty/Response;","isCommitted",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_EQZ,0,-1,L2);
                code.visitLabel(L1);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/lang/IllegalStateException;");
                code.visitConstStmt(CONST_STRING,1,"Committed");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1},new Method("Ljava/lang/IllegalStateException;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitStmt1R(THROW,0);
                code.visitLabel(L2);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/jetty/Response;","_connection","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/jetty/HttpConnection;","getGenerator",new String[]{ },"Lorg/mortbay/jetty/Generator;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0},new Method("Lorg/mortbay/jetty/Generator;","resetBuffer",new String[]{ },"V"));
                code.visitLabel(L3);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m031_sendError(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/Response;","sendError",new String[]{ "I"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"sc");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(339,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(340,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(343,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(342,L3);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_16,0, Integer.valueOf(102)); // int: 0x00000066  float:0.000000
                code.visitJumpStmt(IF_NE,2,0,L3);
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Lorg/mortbay/jetty/Response;","sendProcessing",new String[]{ },"V"));
                code.visitLabel(L2);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L3);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2,0},new Method("Lorg/mortbay/jetty/Response;","sendError",new String[]{ "I","Ljava/lang/String;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m032_sendError(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/Response;","sendError",new String[]{ "I","Ljava/lang/String;"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(16);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"code");
                ddv.visitParameterName(1,"message");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(234,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(331,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(237,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(238,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(240,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(241,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(242,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(243,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(244,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(245,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(246,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(248,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(249,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(251,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(252,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(255,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(260,L17);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(262,L18);
                ddv.visitStartLocal(3,L18,"request","Lorg/mortbay/jetty/Request;",null);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(263,L19);
                ddv.visitStartLocal(1,L19,"error_handler","Lorg/mortbay/jetty/handler/ErrorHandler;",null);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(264,L20);
                ddv.visitStartLocal(0,L20,"context","Lorg/mortbay/jetty/handler/ContextHandler$SContext;",null);
                DexLabel L21=new DexLabel();
                ddv.visitLineNumber(265,L21);
                DexLabel L22=new DexLabel();
                ddv.visitLineNumber(266,L22);
                DexLabel L23=new DexLabel();
                ddv.visitLineNumber(269,L23);
                DexLabel L24=new DexLabel();
                ddv.visitLineNumber(270,L24);
                DexLabel L25=new DexLabel();
                ddv.visitLineNumber(271,L25);
                DexLabel L26=new DexLabel();
                ddv.visitLineNumber(272,L26);
                DexLabel L27=new DexLabel();
                ddv.visitLineNumber(274,L27);
                DexLabel L28=new DexLabel();
                ddv.visitLineNumber(330,L28);
                ddv.visitEndLocal(3,L28);
                ddv.visitEndLocal(0,L28);
                ddv.visitEndLocal(1,L28);
                DexLabel L29=new DexLabel();
                ddv.visitLineNumber(278,L29);
                ddv.visitRestartLocal(0,L29);
                ddv.visitRestartLocal(1,L29);
                ddv.visitRestartLocal(3,L29);
                DexLabel L30=new DexLabel();
                ddv.visitLineNumber(279,L30);
                DexLabel L31=new DexLabel();
                ddv.visitLineNumber(280,L31);
                DexLabel L32=new DexLabel();
                ddv.visitLineNumber(281,L32);
                ddv.visitStartLocal(5,L32,"writer","Lorg/mortbay/util/ByteArrayISO8859Writer;",null);
                DexLabel L33=new DexLabel();
                ddv.visitLineNumber(283,L33);
                DexLabel L34=new DexLabel();
                ddv.visitLineNumber(284,L34);
                ddv.visitRestartLocal(15,L34);
                DexLabel L35=new DexLabel();
                ddv.visitLineNumber(285,L35);
                ddv.visitRestartLocal(15,L35);
                DexLabel L36=new DexLabel();
                ddv.visitLineNumber(287,L36);
                ddv.visitRestartLocal(15,L36);
                DexLabel L37=new DexLabel();
                ddv.visitLineNumber(288,L37);
                ddv.visitStartLocal(4,L37,"uri","Ljava/lang/String;",null);
                DexLabel L38=new DexLabel();
                ddv.visitLineNumber(290,L38);
                DexLabel L39=new DexLabel();
                ddv.visitLineNumber(291,L39);
                DexLabel L40=new DexLabel();
                ddv.visitLineNumber(292,L40);
                ddv.visitRestartLocal(4,L40);
                DexLabel L41=new DexLabel();
                ddv.visitLineNumber(295,L41);
                ddv.visitRestartLocal(4,L41);
                DexLabel L42=new DexLabel();
                ddv.visitLineNumber(296,L42);
                DexLabel L43=new DexLabel();
                ddv.visitLineNumber(297,L43);
                DexLabel L44=new DexLabel();
                ddv.visitLineNumber(298,L44);
                DexLabel L45=new DexLabel();
                ddv.visitLineNumber(299,L45);
                DexLabel L46=new DexLabel();
                ddv.visitLineNumber(300,L46);
                DexLabel L47=new DexLabel();
                ddv.visitLineNumber(301,L47);
                ddv.visitRestartLocal(15,L47);
                DexLabel L48=new DexLabel();
                ddv.visitLineNumber(302,L48);
                DexLabel L49=new DexLabel();
                ddv.visitLineNumber(303,L49);
                DexLabel L50=new DexLabel();
                ddv.visitLineNumber(304,L50);
                DexLabel L51=new DexLabel();
                ddv.visitLineNumber(305,L51);
                DexLabel L52=new DexLabel();
                ddv.visitLineNumber(306,L52);
                DexLabel L53=new DexLabel();
                ddv.visitLineNumber(307,L53);
                DexLabel L54=new DexLabel();
                ddv.visitLineNumber(308,L54);
                DexLabel L55=new DexLabel();
                ddv.visitLineNumber(309,L55);
                DexLabel L56=new DexLabel();
                ddv.visitLineNumber(311,L56);
                DexLabel L57=new DexLabel();
                ddv.visitStartLocal(2,L57,"i","I",null);
                DexLabel L58=new DexLabel();
                ddv.visitLineNumber(312,L58);
                DexLabel L59=new DexLabel();
                ddv.visitLineNumber(311,L59);
                DexLabel L60=new DexLabel();
                ddv.visitLineNumber(313,L60);
                DexLabel L61=new DexLabel();
                ddv.visitLineNumber(315,L61);
                DexLabel L62=new DexLabel();
                ddv.visitLineNumber(316,L62);
                DexLabel L63=new DexLabel();
                ddv.visitLineNumber(317,L63);
                DexLabel L64=new DexLabel();
                ddv.visitLineNumber(318,L64);
                DexLabel L65=new DexLabel();
                ddv.visitLineNumber(321,L65);
                ddv.visitEndLocal(0,L65);
                ddv.visitEndLocal(1,L65);
                ddv.visitEndLocal(3,L65);
                ddv.visitEndLocal(5,L65);
                ddv.visitEndLocal(4,L65);
                ddv.visitEndLocal(2,L65);
                DexLabel L66=new DexLabel();
                ddv.visitLineNumber(323,L66);
                DexLabel L67=new DexLabel();
                ddv.visitLineNumber(324,L67);
                DexLabel L68=new DexLabel();
                ddv.visitLineNumber(325,L68);
                DexLabel L69=new DexLabel();
                ddv.visitLineNumber(326,L69);
                DexLabel L70=new DexLabel();
                ddv.visitLineNumber(327,L70);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_16,9, Integer.valueOf(206)); // int: 0x000000ce  float:0.000000
                code.visitConstStmt(CONST_4,8, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitConstStmt(CONST_STRING,12,"&gt;");
                code.visitConstStmt(CONST_STRING,11,"&amp;");
                code.visitConstStmt(CONST_STRING,10,"&");
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,6,13,new Field("Lorg/mortbay/jetty/Response;","_connection","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Lorg/mortbay/jetty/HttpConnection;","isIncluding",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,6);
                code.visitJumpStmt(IF_EQZ,6,-1,L3);
                code.visitLabel(L2);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 13},new Method("Lorg/mortbay/jetty/Response;","isCommitted",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,6);
                code.visitJumpStmt(IF_EQZ,6,-1,L5);
                code.visitLabel(L4);
                code.visitTypeStmt(NEW_INSTANCE,6,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 6},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,7,"Committed before ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,7},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,14},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "I"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitConstStmt(CONST_STRING,7," ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,7},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,15},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 6},new Method("Lorg/mortbay/log/Log;","warn",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 13},new Method("Lorg/mortbay/jetty/Response;","resetBuffer",new String[]{ },"V"));
                code.visitLabel(L6);
                code.visitFieldStmt(IPUT_OBJECT,8,13,new Field("Lorg/mortbay/jetty/Response;","_characterEncoding","Ljava/lang/String;"));
                code.visitLabel(L7);
                code.visitConstStmt(CONST_STRING,6,"Expires");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 13,6,8},new Method("Lorg/mortbay/jetty/Response;","setHeader",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"V"));
                code.visitLabel(L8);
                code.visitConstStmt(CONST_STRING,6,"Last-Modified");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 13,6,8},new Method("Lorg/mortbay/jetty/Response;","setHeader",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"V"));
                code.visitLabel(L9);
                code.visitConstStmt(CONST_STRING,6,"Cache-Control");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 13,6,8},new Method("Lorg/mortbay/jetty/Response;","setHeader",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"V"));
                code.visitLabel(L10);
                code.visitConstStmt(CONST_STRING,6,"Content-Type");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 13,6,8},new Method("Lorg/mortbay/jetty/Response;","setHeader",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"V"));
                code.visitLabel(L11);
                code.visitConstStmt(CONST_STRING,6,"Content-Length");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 13,6,8},new Method("Lorg/mortbay/jetty/Response;","setHeader",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"V"));
                code.visitLabel(L12);
                code.visitConstStmt(CONST_4,6, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT,6,13,new Field("Lorg/mortbay/jetty/Response;","_outputState","I"));
                code.visitLabel(L13);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 13,14,15},new Method("Lorg/mortbay/jetty/Response;","setStatus",new String[]{ "I","Ljava/lang/String;"},"V"));
                code.visitLabel(L14);
                code.visitJumpStmt(IF_NEZ,15,-1,L16);
                code.visitLabel(L15);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 14},new Method("Lorg/mortbay/jetty/HttpGenerator;","getReason",new String[]{ "I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,15);
                code.visitLabel(L16);
                code.visitConstStmt(CONST_16,6, Integer.valueOf(204)); // int: 0x000000cc  float:0.000000
                code.visitJumpStmt(IF_EQ,14,6,L65);
                code.visitConstStmt(CONST_16,6, Integer.valueOf(304)); // int: 0x00000130  float:0.000000
                code.visitJumpStmt(IF_EQ,14,6,L65);
                code.visitJumpStmt(IF_EQ,14,9,L65);
                code.visitConstStmt(CONST_16,6, Integer.valueOf(200)); // int: 0x000000c8  float:0.000000
                code.visitJumpStmt(IF_LT,14,6,L65);
                code.visitLabel(L17);
                code.visitFieldStmt(IGET_OBJECT,6,13,new Field("Lorg/mortbay/jetty/Response;","_connection","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Lorg/mortbay/jetty/HttpConnection;","getRequest",new String[]{ },"Lorg/mortbay/jetty/Request;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitLabel(L18);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L19);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Lorg/mortbay/jetty/Request;","getContext",new String[]{ },"Lorg/mortbay/jetty/handler/ContextHandler$SContext;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L20);
                code.visitJumpStmt(IF_EQZ,0,-1,L22);
                code.visitLabel(L21);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/jetty/handler/ContextHandler$SContext;","getContextHandler",new String[]{ },"Lorg/mortbay/jetty/handler/ContextHandler;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Lorg/mortbay/jetty/handler/ContextHandler;","getErrorHandler",new String[]{ },"Lorg/mortbay/jetty/handler/ErrorHandler;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L22);
                code.visitJumpStmt(IF_EQZ,1,-1,L29);
                code.visitLabel(L23);
                code.visitConstStmt(CONST_STRING,6,"javax.servlet.error.status_code");
                code.visitTypeStmt(NEW_INSTANCE,7,-1,"Ljava/lang/Integer;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 7,14},new Method("Ljava/lang/Integer;","<init>",new String[]{ "I"},"V"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,6,7},new Method("Lorg/mortbay/jetty/Request;","setAttribute",new String[]{ "Ljava/lang/String;","Ljava/lang/Object;"},"V"));
                code.visitLabel(L24);
                code.visitConstStmt(CONST_STRING,6,"javax.servlet.error.message");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,6,15},new Method("Lorg/mortbay/jetty/Request;","setAttribute",new String[]{ "Ljava/lang/String;","Ljava/lang/Object;"},"V"));
                code.visitLabel(L25);
                code.visitConstStmt(CONST_STRING,6,"javax.servlet.error.request_uri");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Lorg/mortbay/jetty/Request;","getRequestURI",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,6,7},new Method("Lorg/mortbay/jetty/Request;","setAttribute",new String[]{ "Ljava/lang/String;","Ljava/lang/Object;"},"V"));
                code.visitLabel(L26);
                code.visitConstStmt(CONST_STRING,6,"javax.servlet.error.servlet_name");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Lorg/mortbay/jetty/Request;","getServletName",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,6,7},new Method("Lorg/mortbay/jetty/Request;","setAttribute",new String[]{ "Ljava/lang/String;","Ljava/lang/Object;"},"V"));
                code.visitLabel(L27);
                code.visitFieldStmt(IGET_OBJECT,6,13,new Field("Lorg/mortbay/jetty/Response;","_connection","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Lorg/mortbay/jetty/HttpConnection;","getRequest",new String[]{ },"Lorg/mortbay/jetty/Request;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitConstStmt(CONST_16,7, Integer.valueOf(8)); // int: 0x00000008  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,8,6,13,7},new Method("Lorg/mortbay/jetty/handler/ErrorHandler;","handle",new String[]{ "Ljava/lang/String;","Ljavax/servlet/http/HttpServletRequest;","Ljavax/servlet/http/HttpServletResponse;","I"},"V"));
                code.visitLabel(L28);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 13},new Method("Lorg/mortbay/jetty/Response;","complete",new String[]{ },"V"));
                code.visitJumpStmt(GOTO_16,-1,-1,L2);
                code.visitLabel(L29);
                code.visitConstStmt(CONST_STRING,6,"Cache-Control");
                code.visitConstStmt(CONST_STRING,7,"must-revalidate,no-cache,no-store");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 13,6,7},new Method("Lorg/mortbay/jetty/Response;","setHeader",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"V"));
                code.visitLabel(L30);
                code.visitConstStmt(CONST_STRING,6,"text/html; charset=iso-8859-1");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 13,6},new Method("Lorg/mortbay/jetty/Response;","setContentType",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L31);
                code.visitTypeStmt(NEW_INSTANCE,5,-1,"Lorg/mortbay/util/ByteArrayISO8859Writer;");
                code.visitConstStmt(CONST_16,6, Integer.valueOf(2048)); // int: 0x00000800  float:0.000000
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 5,6},new Method("Lorg/mortbay/util/ByteArrayISO8859Writer;","<init>",new String[]{ "I"},"V"));
                code.visitLabel(L32);
                code.visitJumpStmt(IF_EQZ,15,-1,L36);
                code.visitLabel(L33);
                code.visitConstStmt(CONST_STRING,6,"&");
                code.visitConstStmt(CONST_STRING,6,"&amp;");
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 15,10,11},new Method("Lorg/mortbay/util/StringUtil;","replace",new String[]{ "Ljava/lang/String;","Ljava/lang/String;","Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,15);
                code.visitLabel(L34);
                code.visitConstStmt(CONST_STRING,6,"<");
                code.visitConstStmt(CONST_STRING,7,"&lt;");
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 15,6,7},new Method("Lorg/mortbay/util/StringUtil;","replace",new String[]{ "Ljava/lang/String;","Ljava/lang/String;","Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,15);
                code.visitLabel(L35);
                code.visitConstStmt(CONST_STRING,6,">");
                code.visitConstStmt(CONST_STRING,7,"&gt;");
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 15,6,12},new Method("Lorg/mortbay/util/StringUtil;","replace",new String[]{ "Ljava/lang/String;","Ljava/lang/String;","Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,15);
                code.visitLabel(L36);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Lorg/mortbay/jetty/Request;","getRequestURI",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitLabel(L37);
                code.visitJumpStmt(IF_EQZ,4,-1,L41);
                code.visitLabel(L38);
                code.visitConstStmt(CONST_STRING,6,"&");
                code.visitConstStmt(CONST_STRING,6,"&amp;");
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 4,10,11},new Method("Lorg/mortbay/util/StringUtil;","replace",new String[]{ "Ljava/lang/String;","Ljava/lang/String;","Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitLabel(L39);
                code.visitConstStmt(CONST_STRING,6,"<");
                code.visitConstStmt(CONST_STRING,7,"&lt;");
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 4,6,7},new Method("Lorg/mortbay/util/StringUtil;","replace",new String[]{ "Ljava/lang/String;","Ljava/lang/String;","Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitLabel(L40);
                code.visitConstStmt(CONST_STRING,6,">");
                code.visitConstStmt(CONST_STRING,7,"&gt;");
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 4,6,12},new Method("Lorg/mortbay/util/StringUtil;","replace",new String[]{ "Ljava/lang/String;","Ljava/lang/String;","Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitLabel(L41);
                code.visitConstStmt(CONST_STRING,6,"<html>\n<head>\n<meta http-equiv=\"Content-Type\" content=\"text/html; charset=ISO-8859-1\"/>\n");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,6},new Method("Lorg/mortbay/util/ByteArrayISO8859Writer;","write",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L42);
                code.visitConstStmt(CONST_STRING,6,"<title>Error ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,6},new Method("Lorg/mortbay/util/ByteArrayISO8859Writer;","write",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L43);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 14},new Method("Ljava/lang/Integer;","toString",new String[]{ "I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,6},new Method("Lorg/mortbay/util/ByteArrayISO8859Writer;","write",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L44);
                code.visitConstStmt(CONST_16,6, Integer.valueOf(32)); // int: 0x00000020  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,6},new Method("Lorg/mortbay/util/ByteArrayISO8859Writer;","write",new String[]{ "C"},"V"));
                code.visitLabel(L45);
                code.visitJumpStmt(IF_NEZ,15,-1,L47);
                code.visitLabel(L46);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 14},new Method("Lorg/mortbay/jetty/HttpGenerator;","getReason",new String[]{ "I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,15);
                code.visitLabel(L47);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,15},new Method("Lorg/mortbay/util/ByteArrayISO8859Writer;","write",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L48);
                code.visitConstStmt(CONST_STRING,6,"</title>\n</head>\n<body>\n<h2>HTTP ERROR: ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,6},new Method("Lorg/mortbay/util/ByteArrayISO8859Writer;","write",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L49);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 14},new Method("Ljava/lang/Integer;","toString",new String[]{ "I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,6},new Method("Lorg/mortbay/util/ByteArrayISO8859Writer;","write",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L50);
                code.visitConstStmt(CONST_STRING,6,"</h2>\n<p>Problem accessing ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,6},new Method("Lorg/mortbay/util/ByteArrayISO8859Writer;","write",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L51);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,4},new Method("Lorg/mortbay/util/ByteArrayISO8859Writer;","write",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L52);
                code.visitConstStmt(CONST_STRING,6,". Reason:\n<pre>    ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,6},new Method("Lorg/mortbay/util/ByteArrayISO8859Writer;","write",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L53);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,15},new Method("Lorg/mortbay/util/ByteArrayISO8859Writer;","write",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L54);
                code.visitConstStmt(CONST_STRING,6,"</pre>");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,6},new Method("Lorg/mortbay/util/ByteArrayISO8859Writer;","write",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L55);
                code.visitConstStmt(CONST_STRING,6,"</p>\n<hr /><i><small>Powered by Jetty://</small></i>");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,6},new Method("Lorg/mortbay/util/ByteArrayISO8859Writer;","write",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L56);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L57);
                code.visitConstStmt(CONST_16,6, Integer.valueOf(20)); // int: 0x00000014  float:0.000000
                code.visitJumpStmt(IF_GE,2,6,L60);
                code.visitLabel(L58);
                code.visitConstStmt(CONST_STRING,6,"\n                                                ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,6},new Method("Lorg/mortbay/util/ByteArrayISO8859Writer;","write",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L59);
                code.visitStmt2R1N(ADD_INT_LIT8,2,2,1);
                code.visitJumpStmt(GOTO,-1,-1,L57);
                code.visitLabel(L60);
                code.visitConstStmt(CONST_STRING,6,"\n</body>\n</html>\n");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,6},new Method("Lorg/mortbay/util/ByteArrayISO8859Writer;","write",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L61);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Lorg/mortbay/util/ByteArrayISO8859Writer;","flush",new String[]{ },"V"));
                code.visitLabel(L62);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Lorg/mortbay/util/ByteArrayISO8859Writer;","size",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 13,6},new Method("Lorg/mortbay/jetty/Response;","setContentLength",new String[]{ "I"},"V"));
                code.visitLabel(L63);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 13},new Method("Lorg/mortbay/jetty/Response;","getOutputStream",new String[]{ },"Ljavax/servlet/ServletOutputStream;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,6},new Method("Lorg/mortbay/util/ByteArrayISO8859Writer;","writeTo",new String[]{ "Ljava/io/OutputStream;"},"V"));
                code.visitLabel(L64);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Lorg/mortbay/util/ByteArrayISO8859Writer;","destroy",new String[]{ },"V"));
                code.visitJumpStmt(GOTO_16,-1,-1,L28);
                code.visitLabel(L65);
                code.visitJumpStmt(IF_EQ,14,9,L28);
                code.visitLabel(L66);
                code.visitFieldStmt(IGET_OBJECT,6,13,new Field("Lorg/mortbay/jetty/Response;","_connection","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Lorg/mortbay/jetty/HttpConnection;","getRequestFields",new String[]{ },"Lorg/mortbay/jetty/HttpFields;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitFieldStmt(SGET_OBJECT,7,-1,new Field("Lorg/mortbay/jetty/HttpHeaders;","CONTENT_TYPE_BUFFER","Lorg/mortbay/io/Buffer;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,7},new Method("Lorg/mortbay/jetty/HttpFields;","remove",new String[]{ "Lorg/mortbay/io/Buffer;"},"V"));
                code.visitLabel(L67);
                code.visitFieldStmt(IGET_OBJECT,6,13,new Field("Lorg/mortbay/jetty/Response;","_connection","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Lorg/mortbay/jetty/HttpConnection;","getRequestFields",new String[]{ },"Lorg/mortbay/jetty/HttpFields;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitFieldStmt(SGET_OBJECT,7,-1,new Field("Lorg/mortbay/jetty/HttpHeaders;","CONTENT_LENGTH_BUFFER","Lorg/mortbay/io/Buffer;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,7},new Method("Lorg/mortbay/jetty/HttpFields;","remove",new String[]{ "Lorg/mortbay/io/Buffer;"},"V"));
                code.visitLabel(L68);
                code.visitFieldStmt(IPUT_OBJECT,8,13,new Field("Lorg/mortbay/jetty/Response;","_characterEncoding","Ljava/lang/String;"));
                code.visitLabel(L69);
                code.visitFieldStmt(IPUT_OBJECT,8,13,new Field("Lorg/mortbay/jetty/Response;","_mimeType","Ljava/lang/String;"));
                code.visitLabel(L70);
                code.visitFieldStmt(IPUT_OBJECT,8,13,new Field("Lorg/mortbay/jetty/Response;","_cachedMimeType","Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitJumpStmt(GOTO_16,-1,-1,L28);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m033_sendProcessing(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/Response;","sendProcessing",new String[]{ },"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(10);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(355,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(356,L2);
                ddv.visitStartLocal(2,L2,"g","Lorg/mortbay/jetty/Generator;",null);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(358,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(360,L4);
                ddv.visitStartLocal(3,L4,"generator","Lorg/mortbay/jetty/HttpGenerator;",null);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(362,L5);
                ddv.visitStartLocal(1,L5,"expect","Ljava/lang/String;",null);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(364,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(365,L7);
                ddv.visitStartLocal(4,L7,"was_persistent","Z",null);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(366,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(367,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(368,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(369,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(370,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(371,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(374,L14);
                ddv.visitEndLocal(3,L14);
                ddv.visitEndLocal(1,L14);
                ddv.visitEndLocal(4,L14);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,8, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitConstStmt(CONST_4,7, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,5,9,new Field("Lorg/mortbay/jetty/Response;","_connection","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Lorg/mortbay/jetty/HttpConnection;","getGenerator",new String[]{ },"Lorg/mortbay/jetty/Generator;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitLabel(L2);
                code.visitTypeStmt(INSTANCE_OF,5,2,"Lorg/mortbay/jetty/HttpGenerator;");
                code.visitJumpStmt(IF_EQZ,5,-1,L14);
                code.visitLabel(L3);
                code.visitStmt2R(MOVE_OBJECT,0,2);
                code.visitTypeStmt(CHECK_CAST,0,-1,"Lorg/mortbay/jetty/HttpGenerator;");
                code.visitStmt2R(MOVE_OBJECT,3,0);
                code.visitLabel(L4);
                code.visitFieldStmt(IGET_OBJECT,5,9,new Field("Lorg/mortbay/jetty/Response;","_connection","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Lorg/mortbay/jetty/HttpConnection;","getRequest",new String[]{ },"Lorg/mortbay/jetty/Request;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitConstStmt(CONST_STRING,6,"Expect");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,6},new Method("Lorg/mortbay/jetty/Request;","getHeader",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L5);
                code.visitJumpStmt(IF_EQZ,1,-1,L14);
                code.visitConstStmt(CONST_STRING,5,"102");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,5},new Method("Ljava/lang/String;","startsWith",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,5);
                code.visitJumpStmt(IF_EQZ,5,-1,L14);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Lorg/mortbay/jetty/HttpGenerator;","getVersion",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,5);
                code.visitConstStmt(CONST_16,6, Integer.valueOf(11)); // int: 0x0000000b  float:0.000000
                code.visitJumpStmt(IF_LT,5,6,L14);
                code.visitLabel(L6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Lorg/mortbay/jetty/HttpGenerator;","isPersistent",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,4);
                code.visitLabel(L7);
                code.visitConstStmt(CONST_16,5, Integer.valueOf(102)); // int: 0x00000066  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,5,8},new Method("Lorg/mortbay/jetty/HttpGenerator;","setResponse",new String[]{ "I","Ljava/lang/String;"},"V"));
                code.visitLabel(L8);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,8,7},new Method("Lorg/mortbay/jetty/HttpGenerator;","completeHeader",new String[]{ "Lorg/mortbay/jetty/HttpFields;","Z"},"V"));
                code.visitLabel(L9);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,7},new Method("Lorg/mortbay/jetty/HttpGenerator;","setPersistent",new String[]{ "Z"},"V"));
                code.visitLabel(L10);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Lorg/mortbay/jetty/HttpGenerator;","complete",new String[]{ },"V"));
                code.visitLabel(L11);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Lorg/mortbay/jetty/HttpGenerator;","flush",new String[]{ },"J"));
                code.visitLabel(L12);
                code.visitConstStmt(CONST_4,5, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,5},new Method("Lorg/mortbay/jetty/HttpGenerator;","reset",new String[]{ "Z"},"V"));
                code.visitLabel(L13);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,4},new Method("Lorg/mortbay/jetty/HttpGenerator;","setPersistent",new String[]{ "Z"},"V"));
                code.visitLabel(L14);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m034_sendRedirect(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/Response;","sendRedirect",new String[]{ "Ljava/lang/String;"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(7);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"location");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(382,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(413,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(385,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(386,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(388,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(390,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(391,L7);
                ddv.visitStartLocal(0,L7,"buf","Ljava/lang/StringBuffer;",null);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(392,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(405,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(407,L10);
                ddv.visitEndLocal(0,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(409,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(410,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(411,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(395,L14);
                ddv.visitRestartLocal(0,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(396,L15);
                ddv.visitStartLocal(2,L15,"path","Ljava/lang/String;",null);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(397,L16);
                ddv.visitStartLocal(1,L16,"parent","Ljava/lang/String;",null);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(398,L17);
                ddv.visitRestartLocal(6,L17);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(399,L18);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(396,L19);
                ddv.visitEndLocal(1,L19);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(400,L20);
                ddv.visitRestartLocal(1,L20);
                DexLabel L21=new DexLabel();
                ddv.visitLineNumber(401,L21);
                DexLabel L22=new DexLabel();
                ddv.visitLineNumber(402,L22);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_STRING,4,"/");
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,3,5,new Field("Lorg/mortbay/jetty/Response;","_connection","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Lorg/mortbay/jetty/HttpConnection;","isIncluding",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitJumpStmt(IF_EQZ,3,-1,L3);
                code.visitLabel(L2);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L3);
                code.visitJumpStmt(IF_NEZ,6,-1,L5);
                code.visitLabel(L4);
                code.visitTypeStmt(NEW_INSTANCE,3,-1,"Ljava/lang/IllegalArgumentException;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 3},new Method("Ljava/lang/IllegalArgumentException;","<init>",new String[]{ },"V"));
                code.visitStmt1R(THROW,3);
                code.visitLabel(L5);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 6},new Method("Lorg/mortbay/util/URIUtil;","hasScheme",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitJumpStmt(IF_NEZ,3,-1,L10);
                code.visitLabel(L6);
                code.visitFieldStmt(IGET_OBJECT,3,5,new Field("Lorg/mortbay/jetty/Response;","_connection","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Lorg/mortbay/jetty/HttpConnection;","getRequest",new String[]{ },"Lorg/mortbay/jetty/Request;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Lorg/mortbay/jetty/Request;","getRootURL",new String[]{ },"Ljava/lang/StringBuffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L7);
                code.visitConstStmt(CONST_STRING,3,"/");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,4},new Method("Ljava/lang/String;","startsWith",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitJumpStmt(IF_EQZ,3,-1,L14);
                code.visitLabel(L8);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 6},new Method("Lorg/mortbay/util/URIUtil;","canonicalPath",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,3},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L9);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/lang/StringBuffer;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitLabel(L10);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Lorg/mortbay/jetty/Response;","resetBuffer",new String[]{ },"V"));
                code.visitLabel(L11);
                code.visitConstStmt(CONST_STRING,3,"Location");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,3,6},new Method("Lorg/mortbay/jetty/Response;","setHeader",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"V"));
                code.visitLabel(L12);
                code.visitConstStmt(CONST_16,3, Integer.valueOf(302)); // int: 0x0000012e  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,3},new Method("Lorg/mortbay/jetty/Response;","setStatus",new String[]{ "I"},"V"));
                code.visitLabel(L13);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Lorg/mortbay/jetty/Response;","complete",new String[]{ },"V"));
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitLabel(L14);
                code.visitFieldStmt(IGET_OBJECT,3,5,new Field("Lorg/mortbay/jetty/Response;","_connection","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Lorg/mortbay/jetty/HttpConnection;","getRequest",new String[]{ },"Lorg/mortbay/jetty/Request;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Lorg/mortbay/jetty/Request;","getRequestURI",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitLabel(L15);
                code.visitConstStmt(CONST_STRING,3,"/");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,4},new Method("Ljava/lang/String;","endsWith",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitJumpStmt(IF_EQZ,3,-1,L19);
                code.visitStmt2R(MOVE_OBJECT,1,2);
                code.visitLabel(L16);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1,6},new Method("Lorg/mortbay/util/URIUtil;","addPaths",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 3},new Method("Lorg/mortbay/util/URIUtil;","canonicalPath",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitLabel(L17);
                code.visitJumpStmt(IF_NEZ,6,-1,L20);
                code.visitLabel(L18);
                code.visitTypeStmt(NEW_INSTANCE,3,-1,"Ljava/lang/IllegalStateException;");
                code.visitConstStmt(CONST_STRING,4,"path cannot be above root");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 3,4},new Method("Ljava/lang/IllegalStateException;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitStmt1R(THROW,3);
                code.visitLabel(L19);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 2},new Method("Lorg/mortbay/util/URIUtil;","parentPath",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitStmt2R(MOVE_OBJECT,1,3);
                code.visitJumpStmt(GOTO,-1,-1,L16);
                code.visitLabel(L20);
                code.visitConstStmt(CONST_STRING,3,"/");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,4},new Method("Ljava/lang/String;","startsWith",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitJumpStmt(IF_NEZ,3,-1,L22);
                code.visitLabel(L21);
                code.visitConstStmt(CONST_16,3, Integer.valueOf(47)); // int: 0x0000002f  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,3},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "C"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L22);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,6},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuffer;"));
                code.visitJumpStmt(GOTO,-1,-1,L9);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m035_setBufferSize(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/Response;","setBufferSize",new String[]{ "I"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(6);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"size");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(917,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(918,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(919,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(920,L3);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Lorg/mortbay/jetty/Response;","isCommitted",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_NEZ,0,-1,L1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Lorg/mortbay/jetty/Response;","getContentCount",new String[]{ },"J"));
                code.visitStmt1R(MOVE_RESULT_WIDE,0);
                code.visitConstStmt(CONST_WIDE_16,2,Long.valueOf(0L)); // long: 0x0000000000000000  double:0.000000
                code.visitStmt3R(CMP_LONG,0,0,2);
                code.visitJumpStmt(IF_LEZ,0,-1,L2);
                code.visitLabel(L1);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/lang/IllegalStateException;");
                code.visitConstStmt(CONST_STRING,1,"Committed or content written");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1},new Method("Ljava/lang/IllegalStateException;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitStmt1R(THROW,0);
                code.visitLabel(L2);
                code.visitFieldStmt(IGET_OBJECT,0,4,new Field("Lorg/mortbay/jetty/Response;","_connection","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/jetty/HttpConnection;","getGenerator",new String[]{ },"Lorg/mortbay/jetty/Generator;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,5},new Method("Lorg/mortbay/jetty/Generator;","increaseContentBufferSize",new String[]{ "I"},"V"));
                code.visitLabel(L3);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m036_setCharacterEncoding(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/Response;","setCharacterEncoding",new String[]{ "Ljava/lang/String;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(12);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"encoding");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(628,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(694,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(631,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(633,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(635,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(638,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(640,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(641,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(642,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(644,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(650,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(651,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(653,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(654,L14);
                ddv.visitStartLocal(1,L14,"i0","I",null);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(656,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(657,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(659,L17);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(660,L18);
                ddv.visitStartLocal(0,L18,"content_type","Lorg/mortbay/io/BufferCache$CachedBuffer;",null);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(662,L19);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(663,L20);
                DexLabel L21=new DexLabel();
                ddv.visitLineNumber(667,L21);
                ddv.visitEndLocal(0,L21);
                DexLabel L22=new DexLabel();
                ddv.visitLineNumber(669,L22);
                DexLabel L23=new DexLabel();
                ddv.visitLineNumber(670,L23);
                DexLabel L24=new DexLabel();
                ddv.visitLineNumber(675,L24);
                DexLabel L25=new DexLabel();
                ddv.visitLineNumber(676,L25);
                ddv.visitStartLocal(2,L25,"i1","I",null);
                DexLabel L26=new DexLabel();
                ddv.visitLineNumber(678,L26);
                DexLabel L27=new DexLabel();
                ddv.visitLineNumber(689,L27);
                DexLabel L28=new DexLabel();
                ddv.visitLineNumber(682,L28);
                DexLabel L29=new DexLabel();
                ddv.visitLineNumber(683,L29);
                ddv.visitStartLocal(4,L29,"i8","I",null);
                DexLabel L30=new DexLabel();
                ddv.visitLineNumber(684,L30);
                ddv.visitStartLocal(3,L30,"i2","I",null);
                DexLabel L31=new DexLabel();
                ddv.visitLineNumber(685,L31);
                DexLabel L32=new DexLabel();
                ddv.visitLineNumber(687,L32);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,9, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitConstStmt(CONST_4,7, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitConstStmt(CONST_STRING,8,";= ");
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,5,10,new Field("Lorg/mortbay/jetty/Response;","_connection","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Lorg/mortbay/jetty/HttpConnection;","isIncluding",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,5);
                code.visitJumpStmt(IF_EQZ,5,-1,L3);
                code.visitLabel(L2);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L3);
                code.visitFieldStmt(IGET,5,10,new Field("Lorg/mortbay/jetty/Response;","_outputState","I"));
                code.visitJumpStmt(IF_NEZ,5,-1,L2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10},new Method("Lorg/mortbay/jetty/Response;","isCommitted",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,5);
                code.visitJumpStmt(IF_NEZ,5,-1,L2);
                code.visitLabel(L4);
                code.visitConstStmt(CONST_4,5, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitFieldStmt(IPUT_BOOLEAN,5,10,new Field("Lorg/mortbay/jetty/Response;","_explicitEncoding","Z"));
                code.visitLabel(L5);
                code.visitJumpStmt(IF_NEZ,11,-1,L11);
                code.visitLabel(L6);
                code.visitFieldStmt(IGET_OBJECT,5,10,new Field("Lorg/mortbay/jetty/Response;","_characterEncoding","Ljava/lang/String;"));
                code.visitJumpStmt(IF_EQZ,5,-1,L2);
                code.visitLabel(L7);
                code.visitFieldStmt(IPUT_OBJECT,9,10,new Field("Lorg/mortbay/jetty/Response;","_characterEncoding","Ljava/lang/String;"));
                code.visitLabel(L8);
                code.visitFieldStmt(IGET_OBJECT,5,10,new Field("Lorg/mortbay/jetty/Response;","_cachedMimeType","Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitJumpStmt(IF_EQZ,5,-1,L10);
                code.visitLabel(L9);
                code.visitFieldStmt(IGET_OBJECT,5,10,new Field("Lorg/mortbay/jetty/Response;","_connection","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Lorg/mortbay/jetty/HttpConnection;","getResponseFields",new String[]{ },"Lorg/mortbay/jetty/HttpFields;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitFieldStmt(SGET_OBJECT,6,-1,new Field("Lorg/mortbay/jetty/HttpHeaders;","CONTENT_TYPE_BUFFER","Lorg/mortbay/io/Buffer;"));
                code.visitFieldStmt(IGET_OBJECT,7,10,new Field("Lorg/mortbay/jetty/Response;","_cachedMimeType","Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,6,7},new Method("Lorg/mortbay/jetty/HttpFields;","put",new String[]{ "Lorg/mortbay/io/Buffer;","Lorg/mortbay/io/Buffer;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitLabel(L10);
                code.visitFieldStmt(IGET_OBJECT,5,10,new Field("Lorg/mortbay/jetty/Response;","_connection","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Lorg/mortbay/jetty/HttpConnection;","getResponseFields",new String[]{ },"Lorg/mortbay/jetty/HttpFields;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitFieldStmt(SGET_OBJECT,6,-1,new Field("Lorg/mortbay/jetty/HttpHeaders;","CONTENT_TYPE_BUFFER","Lorg/mortbay/io/Buffer;"));
                code.visitFieldStmt(IGET_OBJECT,7,10,new Field("Lorg/mortbay/jetty/Response;","_mimeType","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,6,7},new Method("Lorg/mortbay/jetty/HttpFields;","put",new String[]{ "Lorg/mortbay/io/Buffer;","Ljava/lang/String;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitLabel(L11);
                code.visitFieldStmt(IPUT_OBJECT,11,10,new Field("Lorg/mortbay/jetty/Response;","_characterEncoding","Ljava/lang/String;"));
                code.visitLabel(L12);
                code.visitFieldStmt(IGET_OBJECT,5,10,new Field("Lorg/mortbay/jetty/Response;","_contentType","Ljava/lang/String;"));
                code.visitJumpStmt(IF_EQZ,5,-1,L2);
                code.visitLabel(L13);
                code.visitFieldStmt(IGET_OBJECT,5,10,new Field("Lorg/mortbay/jetty/Response;","_contentType","Ljava/lang/String;"));
                code.visitConstStmt(CONST_16,6, Integer.valueOf(59)); // int: 0x0000003b  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,6},new Method("Ljava/lang/String;","indexOf",new String[]{ "I"},"I"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitLabel(L14);
                code.visitJumpStmt(IF_GEZ,1,-1,L24);
                code.visitLabel(L15);
                code.visitFieldStmt(IPUT_OBJECT,9,10,new Field("Lorg/mortbay/jetty/Response;","_contentType","Ljava/lang/String;"));
                code.visitLabel(L16);
                code.visitFieldStmt(IGET_OBJECT,5,10,new Field("Lorg/mortbay/jetty/Response;","_cachedMimeType","Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitJumpStmt(IF_EQZ,5,-1,L21);
                code.visitLabel(L17);
                code.visitFieldStmt(IGET_OBJECT,5,10,new Field("Lorg/mortbay/jetty/Response;","_cachedMimeType","Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitFieldStmt(IGET_OBJECT,6,10,new Field("Lorg/mortbay/jetty/Response;","_characterEncoding","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,6},new Method("Lorg/mortbay/io/BufferCache$CachedBuffer;","getAssociate",new String[]{ "Ljava/lang/Object;"},"Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L18);
                code.visitJumpStmt(IF_EQZ,0,-1,L21);
                code.visitLabel(L19);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/io/BufferCache$CachedBuffer;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitFieldStmt(IPUT_OBJECT,5,10,new Field("Lorg/mortbay/jetty/Response;","_contentType","Ljava/lang/String;"));
                code.visitLabel(L20);
                code.visitFieldStmt(IGET_OBJECT,5,10,new Field("Lorg/mortbay/jetty/Response;","_connection","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Lorg/mortbay/jetty/HttpConnection;","getResponseFields",new String[]{ },"Lorg/mortbay/jetty/HttpFields;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitFieldStmt(SGET_OBJECT,6,-1,new Field("Lorg/mortbay/jetty/HttpHeaders;","CONTENT_TYPE_BUFFER","Lorg/mortbay/io/Buffer;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,6,0},new Method("Lorg/mortbay/jetty/HttpFields;","put",new String[]{ "Lorg/mortbay/io/Buffer;","Lorg/mortbay/io/Buffer;"},"V"));
                code.visitLabel(L21);
                code.visitFieldStmt(IGET_OBJECT,5,10,new Field("Lorg/mortbay/jetty/Response;","_contentType","Ljava/lang/String;"));
                code.visitJumpStmt(IF_NEZ,5,-1,L2);
                code.visitLabel(L22);
                code.visitTypeStmt(NEW_INSTANCE,5,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 5},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitFieldStmt(IGET_OBJECT,6,10,new Field("Lorg/mortbay/jetty/Response;","_mimeType","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,6},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitConstStmt(CONST_STRING,6,"; charset=");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,6},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitFieldStmt(IGET_OBJECT,6,10,new Field("Lorg/mortbay/jetty/Response;","_characterEncoding","Ljava/lang/String;"));
                code.visitConstStmt(CONST_STRING,7,";= ");
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 6,8},new Method("Lorg/mortbay/util/QuotedStringTokenizer;","quote",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,6},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitFieldStmt(IPUT_OBJECT,5,10,new Field("Lorg/mortbay/jetty/Response;","_contentType","Ljava/lang/String;"));
                code.visitLabel(L23);
                code.visitFieldStmt(IGET_OBJECT,5,10,new Field("Lorg/mortbay/jetty/Response;","_connection","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Lorg/mortbay/jetty/HttpConnection;","getResponseFields",new String[]{ },"Lorg/mortbay/jetty/HttpFields;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitFieldStmt(SGET_OBJECT,6,-1,new Field("Lorg/mortbay/jetty/HttpHeaders;","CONTENT_TYPE_BUFFER","Lorg/mortbay/io/Buffer;"));
                code.visitFieldStmt(IGET_OBJECT,7,10,new Field("Lorg/mortbay/jetty/Response;","_contentType","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,6,7},new Method("Lorg/mortbay/jetty/HttpFields;","put",new String[]{ "Lorg/mortbay/io/Buffer;","Ljava/lang/String;"},"V"));
                code.visitJumpStmt(GOTO_16,-1,-1,L2);
                code.visitLabel(L24);
                code.visitFieldStmt(IGET_OBJECT,5,10,new Field("Lorg/mortbay/jetty/Response;","_contentType","Ljava/lang/String;"));
                code.visitConstStmt(CONST_STRING,6,"charset=");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,6,1},new Method("Ljava/lang/String;","indexOf",new String[]{ "Ljava/lang/String;","I"},"I"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitLabel(L25);
                code.visitJumpStmt(IF_GEZ,2,-1,L28);
                code.visitLabel(L26);
                code.visitTypeStmt(NEW_INSTANCE,5,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 5},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitFieldStmt(IGET_OBJECT,6,10,new Field("Lorg/mortbay/jetty/Response;","_contentType","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,6},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitConstStmt(CONST_STRING,6," charset=");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,6},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitFieldStmt(IGET_OBJECT,6,10,new Field("Lorg/mortbay/jetty/Response;","_characterEncoding","Ljava/lang/String;"));
                code.visitConstStmt(CONST_STRING,7,";= ");
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 6,8},new Method("Lorg/mortbay/util/QuotedStringTokenizer;","quote",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,6},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitFieldStmt(IPUT_OBJECT,5,10,new Field("Lorg/mortbay/jetty/Response;","_contentType","Ljava/lang/String;"));
                code.visitLabel(L27);
                code.visitFieldStmt(IGET_OBJECT,5,10,new Field("Lorg/mortbay/jetty/Response;","_connection","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Lorg/mortbay/jetty/HttpConnection;","getResponseFields",new String[]{ },"Lorg/mortbay/jetty/HttpFields;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitFieldStmt(SGET_OBJECT,6,-1,new Field("Lorg/mortbay/jetty/HttpHeaders;","CONTENT_TYPE_BUFFER","Lorg/mortbay/io/Buffer;"));
                code.visitFieldStmt(IGET_OBJECT,7,10,new Field("Lorg/mortbay/jetty/Response;","_contentType","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,6,7},new Method("Lorg/mortbay/jetty/HttpFields;","put",new String[]{ "Lorg/mortbay/io/Buffer;","Ljava/lang/String;"},"V"));
                code.visitJumpStmt(GOTO_16,-1,-1,L2);
                code.visitLabel(L28);
                code.visitStmt2R1N(ADD_INT_LIT8,4,2,8);
                code.visitLabel(L29);
                code.visitFieldStmt(IGET_OBJECT,5,10,new Field("Lorg/mortbay/jetty/Response;","_contentType","Ljava/lang/String;"));
                code.visitConstStmt(CONST_STRING,6," ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,6,4},new Method("Ljava/lang/String;","indexOf",new String[]{ "Ljava/lang/String;","I"},"I"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitLabel(L30);
                code.visitJumpStmt(IF_GEZ,3,-1,L32);
                code.visitLabel(L31);
                code.visitTypeStmt(NEW_INSTANCE,5,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 5},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitFieldStmt(IGET_OBJECT,6,10,new Field("Lorg/mortbay/jetty/Response;","_contentType","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,7,4},new Method("Ljava/lang/String;","substring",new String[]{ "I","I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,6},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitFieldStmt(IGET_OBJECT,6,10,new Field("Lorg/mortbay/jetty/Response;","_characterEncoding","Ljava/lang/String;"));
                code.visitConstStmt(CONST_STRING,7,";= ");
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 6,8},new Method("Lorg/mortbay/util/QuotedStringTokenizer;","quote",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,6},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitFieldStmt(IPUT_OBJECT,5,10,new Field("Lorg/mortbay/jetty/Response;","_contentType","Ljava/lang/String;"));
                code.visitJumpStmt(GOTO,-1,-1,L27);
                code.visitLabel(L32);
                code.visitTypeStmt(NEW_INSTANCE,5,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 5},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitFieldStmt(IGET_OBJECT,6,10,new Field("Lorg/mortbay/jetty/Response;","_contentType","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,7,4},new Method("Ljava/lang/String;","substring",new String[]{ "I","I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,6},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitFieldStmt(IGET_OBJECT,6,10,new Field("Lorg/mortbay/jetty/Response;","_characterEncoding","Ljava/lang/String;"));
                code.visitConstStmt(CONST_STRING,7,";= ");
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 6,8},new Method("Lorg/mortbay/util/QuotedStringTokenizer;","quote",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,6},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitFieldStmt(IGET_OBJECT,6,10,new Field("Lorg/mortbay/jetty/Response;","_contentType","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,3},new Method("Ljava/lang/String;","substring",new String[]{ "I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,6},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitFieldStmt(IPUT_OBJECT,5,10,new Field("Lorg/mortbay/jetty/Response;","_contentType","Ljava/lang/String;"));
                code.visitJumpStmt(GOTO,-1,-1,L27);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m037_setContentLength(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/Response;","setContentLength",new String[]{ "I"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(7);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ "Ljava/io/IOException;"});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"len");
                DexLabel L3=new DexLabel();
                ddv.visitPrologue(L3);
                ddv.visitLineNumber(705,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(728,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(707,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(708,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(710,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(711,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(713,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(714,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(715,L11);
                ddv.visitLineNumber(719,L0);
                ddv.visitLineNumber(721,L2);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(723,L12);
                ddv.visitStartLocal(0,L12,"e","Ljava/io/IOException;",null);
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Lorg/mortbay/jetty/Response;","isCommitted",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitJumpStmt(IF_NEZ,1,-1,L4);
                code.visitFieldStmt(IGET_OBJECT,1,5,new Field("Lorg/mortbay/jetty/Response;","_connection","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Lorg/mortbay/jetty/HttpConnection;","isIncluding",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitJumpStmt(IF_EQZ,1,-1,L5);
                code.visitLabel(L4);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L5);
                code.visitFieldStmt(IGET_OBJECT,1,5,new Field("Lorg/mortbay/jetty/Response;","_connection","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitFieldStmt(IGET_OBJECT,1,1,new Field("Lorg/mortbay/jetty/HttpConnection;","_generator","Lorg/mortbay/jetty/Generator;"));
                code.visitStmt2R(INT_TO_LONG,2,6);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 1,2,3},new Method("Lorg/mortbay/jetty/Generator;","setContentLength",new String[]{ "J"},"V"));
                code.visitLabel(L6);
                code.visitJumpStmt(IF_LTZ,6,-1,L4);
                code.visitLabel(L7);
                code.visitFieldStmt(IGET_OBJECT,1,5,new Field("Lorg/mortbay/jetty/Response;","_connection","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Lorg/mortbay/jetty/HttpConnection;","getResponseFields",new String[]{ },"Lorg/mortbay/jetty/HttpFields;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitConstStmt(CONST_STRING,2,"Content-Length");
                code.visitStmt2R(INT_TO_LONG,3,6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2,3,4},new Method("Lorg/mortbay/jetty/HttpFields;","putLongField",new String[]{ "Ljava/lang/String;","J"},"V"));
                code.visitLabel(L8);
                code.visitFieldStmt(IGET_OBJECT,1,5,new Field("Lorg/mortbay/jetty/Response;","_connection","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitFieldStmt(IGET_OBJECT,1,1,new Field("Lorg/mortbay/jetty/HttpConnection;","_generator","Lorg/mortbay/jetty/Generator;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 1},new Method("Lorg/mortbay/jetty/Generator;","isContentWritten",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitJumpStmt(IF_EQZ,1,-1,L4);
                code.visitLabel(L9);
                code.visitFieldStmt(IGET,1,5,new Field("Lorg/mortbay/jetty/Response;","_outputState","I"));
                code.visitConstStmt(CONST_4,2, Integer.valueOf(2)); // int: 0x00000002  float:0.000000
                code.visitJumpStmt(IF_NE,1,2,L11);
                code.visitLabel(L10);
                code.visitFieldStmt(IGET_OBJECT,1,5,new Field("Lorg/mortbay/jetty/Response;","_writer","Ljava/io/PrintWriter;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/io/PrintWriter;","close",new String[]{ },"V"));
                code.visitJumpStmt(GOTO,-1,-1,L4);
                code.visitLabel(L11);
                code.visitFieldStmt(IGET,1,5,new Field("Lorg/mortbay/jetty/Response;","_outputState","I"));
                code.visitConstStmt(CONST_4,2, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitJumpStmt(IF_NE,1,2,L4);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Lorg/mortbay/jetty/Response;","getOutputStream",new String[]{ },"Ljavax/servlet/ServletOutputStream;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljavax/servlet/ServletOutputStream;","close",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitJumpStmt(GOTO,-1,-1,L4);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,1);
                code.visitStmt2R(MOVE_OBJECT,0,1);
                code.visitLabel(L12);
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Ljava/lang/RuntimeException;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1,0},new Method("Ljava/lang/RuntimeException;","<init>",new String[]{ "Ljava/lang/Throwable;"},"V"));
                code.visitStmt1R(THROW,1);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m038_setContentType(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/Response;","setContentType",new String[]{ "Ljava/lang/String;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(14);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"contentType");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(751,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(909,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(758,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(760,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(761,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(762,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(763,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(764,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(765,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(770,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(772,L11);
                ddv.visitStartLocal(1,L11,"i0","I",null);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(777,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(778,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(781,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(782,L15);
                ddv.visitStartLocal(2,L15,"i1","I",null);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(784,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(785,L17);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(786,L18);
                ddv.visitStartLocal(4,L18,"i8","I",null);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(788,L19);
                ddv.visitStartLocal(3,L19,"i2","I",null);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(791,L20);
                DexLabel L21=new DexLabel();
                ddv.visitLineNumber(793,L21);
                DexLabel L22=new DexLabel();
                ddv.visitLineNumber(795,L22);
                DexLabel L23=new DexLabel();
                ddv.visitLineNumber(796,L23);
                ddv.visitStartLocal(0,L23,"content_type","Lorg/mortbay/io/BufferCache$CachedBuffer;",null);
                DexLabel L24=new DexLabel();
                ddv.visitLineNumber(798,L24);
                DexLabel L25=new DexLabel();
                ddv.visitLineNumber(799,L25);
                DexLabel L26=new DexLabel();
                ddv.visitLineNumber(803,L26);
                DexLabel L27=new DexLabel();
                ddv.visitLineNumber(804,L27);
                DexLabel L28=new DexLabel();
                ddv.visitLineNumber(809,L28);
                ddv.visitEndLocal(0,L28);
                DexLabel L29=new DexLabel();
                ddv.visitLineNumber(810,L29);
                DexLabel L30=new DexLabel();
                ddv.visitLineNumber(813,L30);
                DexLabel L31=new DexLabel();
                ddv.visitLineNumber(815,L31);
                DexLabel L32=new DexLabel();
                ddv.visitLineNumber(816,L32);
                DexLabel L33=new DexLabel();
                ddv.visitLineNumber(820,L33);
                DexLabel L34=new DexLabel();
                ddv.visitLineNumber(821,L34);
                DexLabel L35=new DexLabel();
                ddv.visitLineNumber(824,L35);
                DexLabel L36=new DexLabel();
                ddv.visitLineNumber(827,L36);
                DexLabel L37=new DexLabel();
                ddv.visitLineNumber(828,L37);
                DexLabel L38=new DexLabel();
                ddv.visitLineNumber(830,L38);
                DexLabel L39=new DexLabel();
                ddv.visitLineNumber(832,L39);
                DexLabel L40=new DexLabel();
                ddv.visitLineNumber(833,L40);
                ddv.visitRestartLocal(0,L40);
                DexLabel L41=new DexLabel();
                ddv.visitLineNumber(835,L41);
                DexLabel L42=new DexLabel();
                ddv.visitLineNumber(836,L42);
                DexLabel L43=new DexLabel();
                ddv.visitLineNumber(840,L43);
                DexLabel L44=new DexLabel();
                ddv.visitLineNumber(841,L44);
                DexLabel L45=new DexLabel();
                ddv.visitLineNumber(846,L45);
                ddv.visitEndLocal(0,L45);
                DexLabel L46=new DexLabel();
                ddv.visitLineNumber(847,L46);
                DexLabel L47=new DexLabel();
                ddv.visitLineNumber(850,L47);
                DexLabel L48=new DexLabel();
                ddv.visitLineNumber(852,L48);
                DexLabel L49=new DexLabel();
                ddv.visitLineNumber(853,L49);
                DexLabel L50=new DexLabel();
                ddv.visitLineNumber(854,L50);
                DexLabel L51=new DexLabel();
                ddv.visitLineNumber(858,L51);
                DexLabel L52=new DexLabel();
                ddv.visitLineNumber(859,L52);
                DexLabel L53=new DexLabel();
                ddv.visitLineNumber(860,L53);
                DexLabel L54=new DexLabel();
                ddv.visitLineNumber(865,L54);
                ddv.visitEndLocal(4,L54);
                ddv.visitEndLocal(3,L54);
                DexLabel L55=new DexLabel();
                ddv.visitLineNumber(866,L55);
                DexLabel L56=new DexLabel();
                ddv.visitLineNumber(867,L56);
                DexLabel L57=new DexLabel();
                ddv.visitLineNumber(866,L57);
                DexLabel L58=new DexLabel();
                ddv.visitLineNumber(872,L58);
                ddv.visitEndLocal(2,L58);
                DexLabel L59=new DexLabel();
                ddv.visitLineNumber(873,L59);
                DexLabel L60=new DexLabel();
                ddv.visitLineNumber(875,L60);
                DexLabel L61=new DexLabel();
                ddv.visitLineNumber(877,L61);
                DexLabel L62=new DexLabel();
                ddv.visitLineNumber(879,L62);
                DexLabel L63=new DexLabel();
                ddv.visitLineNumber(880,L63);
                ddv.visitRestartLocal(0,L63);
                DexLabel L64=new DexLabel();
                ddv.visitLineNumber(882,L64);
                DexLabel L65=new DexLabel();
                ddv.visitLineNumber(883,L65);
                DexLabel L66=new DexLabel();
                ddv.visitLineNumber(887,L66);
                DexLabel L67=new DexLabel();
                ddv.visitLineNumber(888,L67);
                DexLabel L68=new DexLabel();
                ddv.visitLineNumber(893,L68);
                ddv.visitEndLocal(0,L68);
                DexLabel L69=new DexLabel();
                ddv.visitLineNumber(894,L69);
                DexLabel L70=new DexLabel();
                ddv.visitLineNumber(897,L70);
                DexLabel L71=new DexLabel();
                ddv.visitLineNumber(899,L71);
                DexLabel L72=new DexLabel();
                ddv.visitLineNumber(900,L72);
                DexLabel L73=new DexLabel();
                ddv.visitLineNumber(904,L73);
                DexLabel L74=new DexLabel();
                ddv.visitLineNumber(905,L74);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_16,11, Integer.valueOf(32)); // int: 0x00000020  float:0.000000
                code.visitConstStmt(CONST_4,10, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitConstStmt(CONST_4,7, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitConstStmt(CONST_STRING,9,"; charset=");
                code.visitConstStmt(CONST_STRING,8,";= ");
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 12},new Method("Lorg/mortbay/jetty/Response;","isCommitted",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,5);
                code.visitJumpStmt(IF_NEZ,5,-1,L2);
                code.visitFieldStmt(IGET_OBJECT,5,12,new Field("Lorg/mortbay/jetty/Response;","_connection","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Lorg/mortbay/jetty/HttpConnection;","isIncluding",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,5);
                code.visitJumpStmt(IF_EQZ,5,-1,L3);
                code.visitLabel(L2);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L3);
                code.visitJumpStmt(IF_NEZ,13,-1,L10);
                code.visitLabel(L4);
                code.visitFieldStmt(IGET_OBJECT,5,12,new Field("Lorg/mortbay/jetty/Response;","_locale","Ljava/util/Locale;"));
                code.visitJumpStmt(IF_NEZ,5,-1,L6);
                code.visitLabel(L5);
                code.visitFieldStmt(IPUT_OBJECT,7,12,new Field("Lorg/mortbay/jetty/Response;","_characterEncoding","Ljava/lang/String;"));
                code.visitLabel(L6);
                code.visitFieldStmt(IPUT_OBJECT,7,12,new Field("Lorg/mortbay/jetty/Response;","_mimeType","Ljava/lang/String;"));
                code.visitLabel(L7);
                code.visitFieldStmt(IPUT_OBJECT,7,12,new Field("Lorg/mortbay/jetty/Response;","_cachedMimeType","Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitLabel(L8);
                code.visitFieldStmt(IPUT_OBJECT,7,12,new Field("Lorg/mortbay/jetty/Response;","_contentType","Ljava/lang/String;"));
                code.visitLabel(L9);
                code.visitFieldStmt(IGET_OBJECT,5,12,new Field("Lorg/mortbay/jetty/Response;","_connection","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Lorg/mortbay/jetty/HttpConnection;","getResponseFields",new String[]{ },"Lorg/mortbay/jetty/HttpFields;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitFieldStmt(SGET_OBJECT,6,-1,new Field("Lorg/mortbay/jetty/HttpHeaders;","CONTENT_TYPE_BUFFER","Lorg/mortbay/io/Buffer;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,6},new Method("Lorg/mortbay/jetty/HttpFields;","remove",new String[]{ "Lorg/mortbay/io/Buffer;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitLabel(L10);
                code.visitConstStmt(CONST_16,5, Integer.valueOf(59)); // int: 0x0000003b  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 13,5},new Method("Ljava/lang/String;","indexOf",new String[]{ "I"},"I"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitLabel(L11);
                code.visitJumpStmt(IF_LEZ,1,-1,L58);
                code.visitLabel(L12);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 13,10,1},new Method("Ljava/lang/String;","substring",new String[]{ "I","I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Ljava/lang/String;","trim",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitFieldStmt(IPUT_OBJECT,5,12,new Field("Lorg/mortbay/jetty/Response;","_mimeType","Ljava/lang/String;"));
                code.visitLabel(L13);
                code.visitFieldStmt(SGET_OBJECT,5,-1,new Field("Lorg/mortbay/jetty/MimeTypes;","CACHE","Lorg/mortbay/io/BufferCache;"));
                code.visitFieldStmt(IGET_OBJECT,6,12,new Field("Lorg/mortbay/jetty/Response;","_mimeType","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,6},new Method("Lorg/mortbay/io/BufferCache;","get",new String[]{ "Ljava/lang/String;"},"Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitFieldStmt(IPUT_OBJECT,5,12,new Field("Lorg/mortbay/jetty/Response;","_cachedMimeType","Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitLabel(L14);
                code.visitConstStmt(CONST_STRING,5,"charset=");
                code.visitStmt2R1N(ADD_INT_LIT8,6,1,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 13,5,6},new Method("Ljava/lang/String;","indexOf",new String[]{ "Ljava/lang/String;","I"},"I"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitLabel(L15);
                code.visitJumpStmt(IF_LTZ,2,-1,L54);
                code.visitLabel(L16);
                code.visitConstStmt(CONST_4,5, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitFieldStmt(IPUT_BOOLEAN,5,12,new Field("Lorg/mortbay/jetty/Response;","_explicitEncoding","Z"));
                code.visitLabel(L17);
                code.visitStmt2R1N(ADD_INT_LIT8,4,2,8);
                code.visitLabel(L18);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 13,11,4},new Method("Ljava/lang/String;","indexOf",new String[]{ "I","I"},"I"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitLabel(L19);
                code.visitFieldStmt(IGET,5,12,new Field("Lorg/mortbay/jetty/Response;","_outputState","I"));
                code.visitConstStmt(CONST_4,6, Integer.valueOf(2)); // int: 0x00000002  float:0.000000
                code.visitJumpStmt(IF_NE,5,6,L35);
                code.visitLabel(L20);
                code.visitStmt2R1N(ADD_INT_LIT8,5,1,1);
                DexLabel L75=new DexLabel();
                code.visitJumpStmt(IF_NE,2,5,L75);
                code.visitJumpStmt(IF_LTZ,3,-1,L21);
                code.visitLabel(L75);
                code.visitStmt2R1N(ADD_INT_LIT8,5,1,2);
                code.visitJumpStmt(IF_NE,2,5,L30);
                code.visitJumpStmt(IF_GEZ,3,-1,L30);
                code.visitStmt2R1N(ADD_INT_LIT8,5,1,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 13,5},new Method("Ljava/lang/String;","charAt",new String[]{ "I"},"C"));
                code.visitStmt1R(MOVE_RESULT,5);
                code.visitJumpStmt(IF_NE,5,11,L30);
                code.visitLabel(L21);
                code.visitFieldStmt(IGET_OBJECT,5,12,new Field("Lorg/mortbay/jetty/Response;","_cachedMimeType","Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitJumpStmt(IF_EQZ,5,-1,L28);
                code.visitLabel(L22);
                code.visitFieldStmt(IGET_OBJECT,5,12,new Field("Lorg/mortbay/jetty/Response;","_cachedMimeType","Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitFieldStmt(IGET_OBJECT,6,12,new Field("Lorg/mortbay/jetty/Response;","_characterEncoding","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,6},new Method("Lorg/mortbay/io/BufferCache$CachedBuffer;","getAssociate",new String[]{ "Ljava/lang/Object;"},"Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L23);
                code.visitJumpStmt(IF_EQZ,0,-1,L26);
                code.visitLabel(L24);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/io/BufferCache$CachedBuffer;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitFieldStmt(IPUT_OBJECT,5,12,new Field("Lorg/mortbay/jetty/Response;","_contentType","Ljava/lang/String;"));
                code.visitLabel(L25);
                code.visitFieldStmt(IGET_OBJECT,5,12,new Field("Lorg/mortbay/jetty/Response;","_connection","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Lorg/mortbay/jetty/HttpConnection;","getResponseFields",new String[]{ },"Lorg/mortbay/jetty/HttpFields;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitFieldStmt(SGET_OBJECT,6,-1,new Field("Lorg/mortbay/jetty/HttpHeaders;","CONTENT_TYPE_BUFFER","Lorg/mortbay/io/Buffer;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,6,0},new Method("Lorg/mortbay/jetty/HttpFields;","put",new String[]{ "Lorg/mortbay/io/Buffer;","Lorg/mortbay/io/Buffer;"},"V"));
                code.visitJumpStmt(GOTO_16,-1,-1,L2);
                code.visitLabel(L26);
                code.visitTypeStmt(NEW_INSTANCE,5,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 5},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitFieldStmt(IGET_OBJECT,6,12,new Field("Lorg/mortbay/jetty/Response;","_mimeType","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,6},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitConstStmt(CONST_STRING,6,"; charset=");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,9},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitFieldStmt(IGET_OBJECT,6,12,new Field("Lorg/mortbay/jetty/Response;","_characterEncoding","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,6},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitFieldStmt(IPUT_OBJECT,5,12,new Field("Lorg/mortbay/jetty/Response;","_contentType","Ljava/lang/String;"));
                code.visitLabel(L27);
                code.visitFieldStmt(IGET_OBJECT,5,12,new Field("Lorg/mortbay/jetty/Response;","_connection","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Lorg/mortbay/jetty/HttpConnection;","getResponseFields",new String[]{ },"Lorg/mortbay/jetty/HttpFields;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitFieldStmt(SGET_OBJECT,6,-1,new Field("Lorg/mortbay/jetty/HttpHeaders;","CONTENT_TYPE_BUFFER","Lorg/mortbay/io/Buffer;"));
                code.visitFieldStmt(IGET_OBJECT,7,12,new Field("Lorg/mortbay/jetty/Response;","_contentType","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,6,7},new Method("Lorg/mortbay/jetty/HttpFields;","put",new String[]{ "Lorg/mortbay/io/Buffer;","Ljava/lang/String;"},"V"));
                code.visitJumpStmt(GOTO_16,-1,-1,L2);
                code.visitLabel(L28);
                code.visitTypeStmt(NEW_INSTANCE,5,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 5},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitFieldStmt(IGET_OBJECT,6,12,new Field("Lorg/mortbay/jetty/Response;","_mimeType","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,6},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitConstStmt(CONST_STRING,6,"; charset=");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,9},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitFieldStmt(IGET_OBJECT,6,12,new Field("Lorg/mortbay/jetty/Response;","_characterEncoding","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,6},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitFieldStmt(IPUT_OBJECT,5,12,new Field("Lorg/mortbay/jetty/Response;","_contentType","Ljava/lang/String;"));
                code.visitLabel(L29);
                code.visitFieldStmt(IGET_OBJECT,5,12,new Field("Lorg/mortbay/jetty/Response;","_connection","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Lorg/mortbay/jetty/HttpConnection;","getResponseFields",new String[]{ },"Lorg/mortbay/jetty/HttpFields;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitFieldStmt(SGET_OBJECT,6,-1,new Field("Lorg/mortbay/jetty/HttpHeaders;","CONTENT_TYPE_BUFFER","Lorg/mortbay/io/Buffer;"));
                code.visitFieldStmt(IGET_OBJECT,7,12,new Field("Lorg/mortbay/jetty/Response;","_contentType","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,6,7},new Method("Lorg/mortbay/jetty/HttpFields;","put",new String[]{ "Lorg/mortbay/io/Buffer;","Ljava/lang/String;"},"V"));
                code.visitJumpStmt(GOTO_16,-1,-1,L2);
                code.visitLabel(L30);
                code.visitJumpStmt(IF_GEZ,3,-1,L33);
                code.visitLabel(L31);
                code.visitTypeStmt(NEW_INSTANCE,5,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 5},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 13,10,2},new Method("Ljava/lang/String;","substring",new String[]{ "I","I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,6},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitConstStmt(CONST_STRING,6," charset=");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,6},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitFieldStmt(IGET_OBJECT,6,12,new Field("Lorg/mortbay/jetty/Response;","_characterEncoding","Ljava/lang/String;"));
                code.visitConstStmt(CONST_STRING,7,";= ");
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 6,8},new Method("Lorg/mortbay/util/QuotedStringTokenizer;","quote",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,6},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitFieldStmt(IPUT_OBJECT,5,12,new Field("Lorg/mortbay/jetty/Response;","_contentType","Ljava/lang/String;"));
                code.visitLabel(L32);
                code.visitFieldStmt(IGET_OBJECT,5,12,new Field("Lorg/mortbay/jetty/Response;","_connection","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Lorg/mortbay/jetty/HttpConnection;","getResponseFields",new String[]{ },"Lorg/mortbay/jetty/HttpFields;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitFieldStmt(SGET_OBJECT,6,-1,new Field("Lorg/mortbay/jetty/HttpHeaders;","CONTENT_TYPE_BUFFER","Lorg/mortbay/io/Buffer;"));
                code.visitFieldStmt(IGET_OBJECT,7,12,new Field("Lorg/mortbay/jetty/Response;","_contentType","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,6,7},new Method("Lorg/mortbay/jetty/HttpFields;","put",new String[]{ "Lorg/mortbay/io/Buffer;","Ljava/lang/String;"},"V"));
                code.visitJumpStmt(GOTO_16,-1,-1,L2);
                code.visitLabel(L33);
                code.visitTypeStmt(NEW_INSTANCE,5,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 5},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 13,10,2},new Method("Ljava/lang/String;","substring",new String[]{ "I","I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,6},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 13,3},new Method("Ljava/lang/String;","substring",new String[]{ "I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,6},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitConstStmt(CONST_STRING,6," charset=");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,6},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitFieldStmt(IGET_OBJECT,6,12,new Field("Lorg/mortbay/jetty/Response;","_characterEncoding","Ljava/lang/String;"));
                code.visitConstStmt(CONST_STRING,7,";= ");
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 6,8},new Method("Lorg/mortbay/util/QuotedStringTokenizer;","quote",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,6},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitFieldStmt(IPUT_OBJECT,5,12,new Field("Lorg/mortbay/jetty/Response;","_contentType","Ljava/lang/String;"));
                code.visitLabel(L34);
                code.visitFieldStmt(IGET_OBJECT,5,12,new Field("Lorg/mortbay/jetty/Response;","_connection","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Lorg/mortbay/jetty/HttpConnection;","getResponseFields",new String[]{ },"Lorg/mortbay/jetty/HttpFields;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitFieldStmt(SGET_OBJECT,6,-1,new Field("Lorg/mortbay/jetty/HttpHeaders;","CONTENT_TYPE_BUFFER","Lorg/mortbay/io/Buffer;"));
                code.visitFieldStmt(IGET_OBJECT,7,12,new Field("Lorg/mortbay/jetty/Response;","_contentType","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,6,7},new Method("Lorg/mortbay/jetty/HttpFields;","put",new String[]{ "Lorg/mortbay/io/Buffer;","Ljava/lang/String;"},"V"));
                code.visitJumpStmt(GOTO_16,-1,-1,L2);
                code.visitLabel(L35);
                code.visitStmt2R1N(ADD_INT_LIT8,5,1,1);
                DexLabel L76=new DexLabel();
                code.visitJumpStmt(IF_NE,2,5,L76);
                code.visitJumpStmt(IF_LTZ,3,-1,L36);
                code.visitLabel(L76);
                code.visitStmt2R1N(ADD_INT_LIT8,5,1,2);
                code.visitJumpStmt(IF_NE,2,5,L47);
                code.visitJumpStmt(IF_GEZ,3,-1,L47);
                code.visitStmt2R1N(ADD_INT_LIT8,5,1,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 13,5},new Method("Ljava/lang/String;","charAt",new String[]{ "I"},"C"));
                code.visitStmt1R(MOVE_RESULT,5);
                code.visitJumpStmt(IF_NE,5,11,L47);
                code.visitLabel(L36);
                code.visitFieldStmt(SGET_OBJECT,5,-1,new Field("Lorg/mortbay/jetty/MimeTypes;","CACHE","Lorg/mortbay/io/BufferCache;"));
                code.visitFieldStmt(IGET_OBJECT,6,12,new Field("Lorg/mortbay/jetty/Response;","_mimeType","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,6},new Method("Lorg/mortbay/io/BufferCache;","get",new String[]{ "Ljava/lang/String;"},"Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitFieldStmt(IPUT_OBJECT,5,12,new Field("Lorg/mortbay/jetty/Response;","_cachedMimeType","Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitLabel(L37);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 13,4},new Method("Ljava/lang/String;","substring",new String[]{ "I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 5},new Method("Lorg/mortbay/util/QuotedStringTokenizer;","unquote",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitFieldStmt(IPUT_OBJECT,5,12,new Field("Lorg/mortbay/jetty/Response;","_characterEncoding","Ljava/lang/String;"));
                code.visitLabel(L38);
                code.visitFieldStmt(IGET_OBJECT,5,12,new Field("Lorg/mortbay/jetty/Response;","_cachedMimeType","Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitJumpStmt(IF_EQZ,5,-1,L45);
                code.visitLabel(L39);
                code.visitFieldStmt(IGET_OBJECT,5,12,new Field("Lorg/mortbay/jetty/Response;","_cachedMimeType","Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitFieldStmt(IGET_OBJECT,6,12,new Field("Lorg/mortbay/jetty/Response;","_characterEncoding","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,6},new Method("Lorg/mortbay/io/BufferCache$CachedBuffer;","getAssociate",new String[]{ "Ljava/lang/Object;"},"Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L40);
                code.visitJumpStmt(IF_EQZ,0,-1,L43);
                code.visitLabel(L41);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/io/BufferCache$CachedBuffer;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitFieldStmt(IPUT_OBJECT,5,12,new Field("Lorg/mortbay/jetty/Response;","_contentType","Ljava/lang/String;"));
                code.visitLabel(L42);
                code.visitFieldStmt(IGET_OBJECT,5,12,new Field("Lorg/mortbay/jetty/Response;","_connection","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Lorg/mortbay/jetty/HttpConnection;","getResponseFields",new String[]{ },"Lorg/mortbay/jetty/HttpFields;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitFieldStmt(SGET_OBJECT,6,-1,new Field("Lorg/mortbay/jetty/HttpHeaders;","CONTENT_TYPE_BUFFER","Lorg/mortbay/io/Buffer;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,6,0},new Method("Lorg/mortbay/jetty/HttpFields;","put",new String[]{ "Lorg/mortbay/io/Buffer;","Lorg/mortbay/io/Buffer;"},"V"));
                code.visitJumpStmt(GOTO_16,-1,-1,L2);
                code.visitLabel(L43);
                code.visitFieldStmt(IPUT_OBJECT,13,12,new Field("Lorg/mortbay/jetty/Response;","_contentType","Ljava/lang/String;"));
                code.visitLabel(L44);
                code.visitFieldStmt(IGET_OBJECT,5,12,new Field("Lorg/mortbay/jetty/Response;","_connection","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Lorg/mortbay/jetty/HttpConnection;","getResponseFields",new String[]{ },"Lorg/mortbay/jetty/HttpFields;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitFieldStmt(SGET_OBJECT,6,-1,new Field("Lorg/mortbay/jetty/HttpHeaders;","CONTENT_TYPE_BUFFER","Lorg/mortbay/io/Buffer;"));
                code.visitFieldStmt(IGET_OBJECT,7,12,new Field("Lorg/mortbay/jetty/Response;","_contentType","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,6,7},new Method("Lorg/mortbay/jetty/HttpFields;","put",new String[]{ "Lorg/mortbay/io/Buffer;","Ljava/lang/String;"},"V"));
                code.visitJumpStmt(GOTO_16,-1,-1,L2);
                code.visitLabel(L45);
                code.visitFieldStmt(IPUT_OBJECT,13,12,new Field("Lorg/mortbay/jetty/Response;","_contentType","Ljava/lang/String;"));
                code.visitLabel(L46);
                code.visitFieldStmt(IGET_OBJECT,5,12,new Field("Lorg/mortbay/jetty/Response;","_connection","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Lorg/mortbay/jetty/HttpConnection;","getResponseFields",new String[]{ },"Lorg/mortbay/jetty/HttpFields;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitFieldStmt(SGET_OBJECT,6,-1,new Field("Lorg/mortbay/jetty/HttpHeaders;","CONTENT_TYPE_BUFFER","Lorg/mortbay/io/Buffer;"));
                code.visitFieldStmt(IGET_OBJECT,7,12,new Field("Lorg/mortbay/jetty/Response;","_contentType","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,6,7},new Method("Lorg/mortbay/jetty/HttpFields;","put",new String[]{ "Lorg/mortbay/io/Buffer;","Ljava/lang/String;"},"V"));
                code.visitJumpStmt(GOTO_16,-1,-1,L2);
                code.visitLabel(L47);
                code.visitJumpStmt(IF_LEZ,3,-1,L51);
                code.visitLabel(L48);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 13,4,3},new Method("Ljava/lang/String;","substring",new String[]{ "I","I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 5},new Method("Lorg/mortbay/util/QuotedStringTokenizer;","unquote",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitFieldStmt(IPUT_OBJECT,5,12,new Field("Lorg/mortbay/jetty/Response;","_characterEncoding","Ljava/lang/String;"));
                code.visitLabel(L49);
                code.visitFieldStmt(IPUT_OBJECT,13,12,new Field("Lorg/mortbay/jetty/Response;","_contentType","Ljava/lang/String;"));
                code.visitLabel(L50);
                code.visitFieldStmt(IGET_OBJECT,5,12,new Field("Lorg/mortbay/jetty/Response;","_connection","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Lorg/mortbay/jetty/HttpConnection;","getResponseFields",new String[]{ },"Lorg/mortbay/jetty/HttpFields;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitFieldStmt(SGET_OBJECT,6,-1,new Field("Lorg/mortbay/jetty/HttpHeaders;","CONTENT_TYPE_BUFFER","Lorg/mortbay/io/Buffer;"));
                code.visitFieldStmt(IGET_OBJECT,7,12,new Field("Lorg/mortbay/jetty/Response;","_contentType","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,6,7},new Method("Lorg/mortbay/jetty/HttpFields;","put",new String[]{ "Lorg/mortbay/io/Buffer;","Ljava/lang/String;"},"V"));
                code.visitJumpStmt(GOTO_16,-1,-1,L2);
                code.visitLabel(L51);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 13,4},new Method("Ljava/lang/String;","substring",new String[]{ "I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 5},new Method("Lorg/mortbay/util/QuotedStringTokenizer;","unquote",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitFieldStmt(IPUT_OBJECT,5,12,new Field("Lorg/mortbay/jetty/Response;","_characterEncoding","Ljava/lang/String;"));
                code.visitLabel(L52);
                code.visitFieldStmt(IPUT_OBJECT,13,12,new Field("Lorg/mortbay/jetty/Response;","_contentType","Ljava/lang/String;"));
                code.visitLabel(L53);
                code.visitFieldStmt(IGET_OBJECT,5,12,new Field("Lorg/mortbay/jetty/Response;","_connection","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Lorg/mortbay/jetty/HttpConnection;","getResponseFields",new String[]{ },"Lorg/mortbay/jetty/HttpFields;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitFieldStmt(SGET_OBJECT,6,-1,new Field("Lorg/mortbay/jetty/HttpHeaders;","CONTENT_TYPE_BUFFER","Lorg/mortbay/io/Buffer;"));
                code.visitFieldStmt(IGET_OBJECT,7,12,new Field("Lorg/mortbay/jetty/Response;","_contentType","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,6,7},new Method("Lorg/mortbay/jetty/HttpFields;","put",new String[]{ "Lorg/mortbay/io/Buffer;","Ljava/lang/String;"},"V"));
                code.visitJumpStmt(GOTO_16,-1,-1,L2);
                code.visitLabel(L54);
                code.visitFieldStmt(IPUT_OBJECT,7,12,new Field("Lorg/mortbay/jetty/Response;","_cachedMimeType","Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitLabel(L55);
                code.visitFieldStmt(IGET_OBJECT,5,12,new Field("Lorg/mortbay/jetty/Response;","_characterEncoding","Ljava/lang/String;"));
                code.visitJumpStmt(IF_NEZ,5,-1,L57);
                code.visitStmt2R(MOVE_OBJECT,5,13);
                DexLabel L77=new DexLabel();
                code.visitLabel(L77);
                code.visitFieldStmt(IPUT_OBJECT,5,12,new Field("Lorg/mortbay/jetty/Response;","_contentType","Ljava/lang/String;"));
                code.visitLabel(L56);
                code.visitFieldStmt(IGET_OBJECT,5,12,new Field("Lorg/mortbay/jetty/Response;","_connection","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Lorg/mortbay/jetty/HttpConnection;","getResponseFields",new String[]{ },"Lorg/mortbay/jetty/HttpFields;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitFieldStmt(SGET_OBJECT,6,-1,new Field("Lorg/mortbay/jetty/HttpHeaders;","CONTENT_TYPE_BUFFER","Lorg/mortbay/io/Buffer;"));
                code.visitFieldStmt(IGET_OBJECT,7,12,new Field("Lorg/mortbay/jetty/Response;","_contentType","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,6,7},new Method("Lorg/mortbay/jetty/HttpFields;","put",new String[]{ "Lorg/mortbay/io/Buffer;","Ljava/lang/String;"},"V"));
                code.visitJumpStmt(GOTO_16,-1,-1,L2);
                code.visitLabel(L57);
                code.visitTypeStmt(NEW_INSTANCE,5,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 5},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,13},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitConstStmt(CONST_STRING,6," charset=");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,6},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitFieldStmt(IGET_OBJECT,6,12,new Field("Lorg/mortbay/jetty/Response;","_characterEncoding","Ljava/lang/String;"));
                code.visitConstStmt(CONST_STRING,7,";= ");
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 6,8},new Method("Lorg/mortbay/util/QuotedStringTokenizer;","quote",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,6},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitJumpStmt(GOTO,-1,-1,L77);
                code.visitLabel(L58);
                code.visitFieldStmt(IPUT_OBJECT,13,12,new Field("Lorg/mortbay/jetty/Response;","_mimeType","Ljava/lang/String;"));
                code.visitLabel(L59);
                code.visitFieldStmt(SGET_OBJECT,5,-1,new Field("Lorg/mortbay/jetty/MimeTypes;","CACHE","Lorg/mortbay/io/BufferCache;"));
                code.visitFieldStmt(IGET_OBJECT,6,12,new Field("Lorg/mortbay/jetty/Response;","_mimeType","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,6},new Method("Lorg/mortbay/io/BufferCache;","get",new String[]{ "Ljava/lang/String;"},"Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitFieldStmt(IPUT_OBJECT,5,12,new Field("Lorg/mortbay/jetty/Response;","_cachedMimeType","Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitLabel(L60);
                code.visitFieldStmt(IGET_OBJECT,5,12,new Field("Lorg/mortbay/jetty/Response;","_characterEncoding","Ljava/lang/String;"));
                code.visitJumpStmt(IF_EQZ,5,-1,L70);
                code.visitLabel(L61);
                code.visitFieldStmt(IGET_OBJECT,5,12,new Field("Lorg/mortbay/jetty/Response;","_cachedMimeType","Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitJumpStmt(IF_EQZ,5,-1,L68);
                code.visitLabel(L62);
                code.visitFieldStmt(IGET_OBJECT,5,12,new Field("Lorg/mortbay/jetty/Response;","_cachedMimeType","Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitFieldStmt(IGET_OBJECT,6,12,new Field("Lorg/mortbay/jetty/Response;","_characterEncoding","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,6},new Method("Lorg/mortbay/io/BufferCache$CachedBuffer;","getAssociate",new String[]{ "Ljava/lang/Object;"},"Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L63);
                code.visitJumpStmt(IF_EQZ,0,-1,L66);
                code.visitLabel(L64);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/io/BufferCache$CachedBuffer;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitFieldStmt(IPUT_OBJECT,5,12,new Field("Lorg/mortbay/jetty/Response;","_contentType","Ljava/lang/String;"));
                code.visitLabel(L65);
                code.visitFieldStmt(IGET_OBJECT,5,12,new Field("Lorg/mortbay/jetty/Response;","_connection","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Lorg/mortbay/jetty/HttpConnection;","getResponseFields",new String[]{ },"Lorg/mortbay/jetty/HttpFields;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitFieldStmt(SGET_OBJECT,6,-1,new Field("Lorg/mortbay/jetty/HttpHeaders;","CONTENT_TYPE_BUFFER","Lorg/mortbay/io/Buffer;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,6,0},new Method("Lorg/mortbay/jetty/HttpFields;","put",new String[]{ "Lorg/mortbay/io/Buffer;","Lorg/mortbay/io/Buffer;"},"V"));
                code.visitJumpStmt(GOTO_16,-1,-1,L2);
                code.visitLabel(L66);
                code.visitTypeStmt(NEW_INSTANCE,5,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 5},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitFieldStmt(IGET_OBJECT,6,12,new Field("Lorg/mortbay/jetty/Response;","_mimeType","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,6},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitConstStmt(CONST_STRING,6,"; charset=");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,9},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitFieldStmt(IGET_OBJECT,6,12,new Field("Lorg/mortbay/jetty/Response;","_characterEncoding","Ljava/lang/String;"));
                code.visitConstStmt(CONST_STRING,7,";= ");
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 6,8},new Method("Lorg/mortbay/util/QuotedStringTokenizer;","quote",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,6},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitFieldStmt(IPUT_OBJECT,5,12,new Field("Lorg/mortbay/jetty/Response;","_contentType","Ljava/lang/String;"));
                code.visitLabel(L67);
                code.visitFieldStmt(IGET_OBJECT,5,12,new Field("Lorg/mortbay/jetty/Response;","_connection","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Lorg/mortbay/jetty/HttpConnection;","getResponseFields",new String[]{ },"Lorg/mortbay/jetty/HttpFields;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitFieldStmt(SGET_OBJECT,6,-1,new Field("Lorg/mortbay/jetty/HttpHeaders;","CONTENT_TYPE_BUFFER","Lorg/mortbay/io/Buffer;"));
                code.visitFieldStmt(IGET_OBJECT,7,12,new Field("Lorg/mortbay/jetty/Response;","_contentType","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,6,7},new Method("Lorg/mortbay/jetty/HttpFields;","put",new String[]{ "Lorg/mortbay/io/Buffer;","Ljava/lang/String;"},"V"));
                code.visitJumpStmt(GOTO_16,-1,-1,L2);
                code.visitLabel(L68);
                code.visitTypeStmt(NEW_INSTANCE,5,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 5},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,13},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitConstStmt(CONST_STRING,6,"; charset=");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,9},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitFieldStmt(IGET_OBJECT,6,12,new Field("Lorg/mortbay/jetty/Response;","_characterEncoding","Ljava/lang/String;"));
                code.visitConstStmt(CONST_STRING,7,";= ");
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 6,8},new Method("Lorg/mortbay/util/QuotedStringTokenizer;","quote",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,6},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitFieldStmt(IPUT_OBJECT,5,12,new Field("Lorg/mortbay/jetty/Response;","_contentType","Ljava/lang/String;"));
                code.visitLabel(L69);
                code.visitFieldStmt(IGET_OBJECT,5,12,new Field("Lorg/mortbay/jetty/Response;","_connection","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Lorg/mortbay/jetty/HttpConnection;","getResponseFields",new String[]{ },"Lorg/mortbay/jetty/HttpFields;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitFieldStmt(SGET_OBJECT,6,-1,new Field("Lorg/mortbay/jetty/HttpHeaders;","CONTENT_TYPE_BUFFER","Lorg/mortbay/io/Buffer;"));
                code.visitFieldStmt(IGET_OBJECT,7,12,new Field("Lorg/mortbay/jetty/Response;","_contentType","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,6,7},new Method("Lorg/mortbay/jetty/HttpFields;","put",new String[]{ "Lorg/mortbay/io/Buffer;","Ljava/lang/String;"},"V"));
                code.visitJumpStmt(GOTO_16,-1,-1,L2);
                code.visitLabel(L70);
                code.visitFieldStmt(IGET_OBJECT,5,12,new Field("Lorg/mortbay/jetty/Response;","_cachedMimeType","Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitJumpStmt(IF_EQZ,5,-1,L73);
                code.visitLabel(L71);
                code.visitFieldStmt(IGET_OBJECT,5,12,new Field("Lorg/mortbay/jetty/Response;","_cachedMimeType","Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Lorg/mortbay/io/BufferCache$CachedBuffer;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitFieldStmt(IPUT_OBJECT,5,12,new Field("Lorg/mortbay/jetty/Response;","_contentType","Ljava/lang/String;"));
                code.visitLabel(L72);
                code.visitFieldStmt(IGET_OBJECT,5,12,new Field("Lorg/mortbay/jetty/Response;","_connection","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Lorg/mortbay/jetty/HttpConnection;","getResponseFields",new String[]{ },"Lorg/mortbay/jetty/HttpFields;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitFieldStmt(SGET_OBJECT,6,-1,new Field("Lorg/mortbay/jetty/HttpHeaders;","CONTENT_TYPE_BUFFER","Lorg/mortbay/io/Buffer;"));
                code.visitFieldStmt(IGET_OBJECT,7,12,new Field("Lorg/mortbay/jetty/Response;","_cachedMimeType","Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,6,7},new Method("Lorg/mortbay/jetty/HttpFields;","put",new String[]{ "Lorg/mortbay/io/Buffer;","Lorg/mortbay/io/Buffer;"},"V"));
                code.visitJumpStmt(GOTO_16,-1,-1,L2);
                code.visitLabel(L73);
                code.visitFieldStmt(IPUT_OBJECT,13,12,new Field("Lorg/mortbay/jetty/Response;","_contentType","Ljava/lang/String;"));
                code.visitLabel(L74);
                code.visitFieldStmt(IGET_OBJECT,5,12,new Field("Lorg/mortbay/jetty/Response;","_connection","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Lorg/mortbay/jetty/HttpConnection;","getResponseFields",new String[]{ },"Lorg/mortbay/jetty/HttpFields;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitFieldStmt(SGET_OBJECT,6,-1,new Field("Lorg/mortbay/jetty/HttpHeaders;","CONTENT_TYPE_BUFFER","Lorg/mortbay/io/Buffer;"));
                code.visitFieldStmt(IGET_OBJECT,7,12,new Field("Lorg/mortbay/jetty/Response;","_contentType","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,6,7},new Method("Lorg/mortbay/jetty/HttpFields;","put",new String[]{ "Lorg/mortbay/io/Buffer;","Ljava/lang/String;"},"V"));
                code.visitJumpStmt(GOTO_16,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m039_setDateHeader(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/Response;","setDateHeader",new String[]{ "Ljava/lang/String;","J"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"name");
                ddv.visitParameterName(1,"date");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(421,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(422,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(423,L2);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/Response;","_connection","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/jetty/HttpConnection;","isIncluding",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_NEZ,0,-1,L2);
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/Response;","_connection","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/jetty/HttpConnection;","getResponseFields",new String[]{ },"Lorg/mortbay/jetty/HttpFields;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,2,3,4},new Method("Lorg/mortbay/jetty/HttpFields;","putDateField",new String[]{ "Ljava/lang/String;","J"},"V"));
                code.visitLabel(L2);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m040_setHeader(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/Response;","setHeader",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(6);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"name");
                ddv.visitParameterName(1,"value");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(441,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(443,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(444,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(446,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(447,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(452,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(449,L6);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,3,new Field("Lorg/mortbay/jetty/Response;","_connection","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/jetty/HttpConnection;","isIncluding",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_NEZ,0,-1,L5);
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,0,3,new Field("Lorg/mortbay/jetty/Response;","_connection","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/jetty/HttpConnection;","getResponseFields",new String[]{ },"Lorg/mortbay/jetty/HttpFields;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,4,5},new Method("Lorg/mortbay/jetty/HttpFields;","put",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"V"));
                code.visitLabel(L2);
                code.visitConstStmt(CONST_STRING,0,"Content-Length");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,4},new Method("Ljava/lang/String;","equalsIgnoreCase",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_EQZ,0,-1,L5);
                code.visitLabel(L3);
                code.visitJumpStmt(IF_NEZ,5,-1,L6);
                code.visitLabel(L4);
                code.visitFieldStmt(IGET_OBJECT,0,3,new Field("Lorg/mortbay/jetty/Response;","_connection","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpConnection;","_generator","Lorg/mortbay/jetty/Generator;"));
                code.visitConstStmt(CONST_WIDE_16,1,Long.valueOf(-1L)); // long: 0xffffffffffffffff  double:NaN
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,1,2},new Method("Lorg/mortbay/jetty/Generator;","setContentLength",new String[]{ "J"},"V"));
                code.visitLabel(L5);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L6);
                code.visitFieldStmt(IGET_OBJECT,0,3,new Field("Lorg/mortbay/jetty/Response;","_connection","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpConnection;","_generator","Lorg/mortbay/jetty/Generator;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 5},new Method("Ljava/lang/Long;","parseLong",new String[]{ "Ljava/lang/String;"},"J"));
                code.visitStmt1R(MOVE_RESULT_WIDE,1);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,1,2},new Method("Lorg/mortbay/jetty/Generator;","setContentLength",new String[]{ "J"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L5);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m041_setIntHeader(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/Response;","setIntHeader",new String[]{ "Ljava/lang/String;","I"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(6);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"name");
                ddv.visitParameterName(1,"value");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(493,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(495,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(496,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(497,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(499,L4);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,3,new Field("Lorg/mortbay/jetty/Response;","_connection","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/jetty/HttpConnection;","isIncluding",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_NEZ,0,-1,L4);
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,0,3,new Field("Lorg/mortbay/jetty/Response;","_connection","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/jetty/HttpConnection;","getResponseFields",new String[]{ },"Lorg/mortbay/jetty/HttpFields;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitStmt2R(INT_TO_LONG,1,5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,4,1,2},new Method("Lorg/mortbay/jetty/HttpFields;","putLongField",new String[]{ "Ljava/lang/String;","J"},"V"));
                code.visitLabel(L2);
                code.visitConstStmt(CONST_STRING,0,"Content-Length");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,4},new Method("Ljava/lang/String;","equalsIgnoreCase",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_EQZ,0,-1,L4);
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,0,3,new Field("Lorg/mortbay/jetty/Response;","_connection","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpConnection;","_generator","Lorg/mortbay/jetty/Generator;"));
                code.visitStmt2R(INT_TO_LONG,1,5);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,1,2},new Method("Lorg/mortbay/jetty/Generator;","setContentLength",new String[]{ "J"},"V"));
                code.visitLabel(L4);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m042_setLocale(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/Response;","setLocale",new String[]{ "Ljava/util/Locale;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(11);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"locale");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(1023,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(1062,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(1026,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(1027,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(1029,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(1032,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(1035,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(1037,L8);
                ddv.visitStartLocal(0,L8,"charset","Ljava/lang/String;",null);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(1039,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(1042,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(1043,L11);
                ddv.visitStartLocal(2,L11,"type","Ljava/lang/String;",null);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(1045,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(1046,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(1047,L14);
                ddv.visitStartLocal(1,L14,"semi","I",null);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(1049,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(1050,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(1058,L17);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(1059,L18);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(1054,L19);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(1055,L20);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_STRING,8,"; charset=");
                code.visitLabel(L1);
                code.visitJumpStmt(IF_EQZ,10,-1,L2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9},new Method("Lorg/mortbay/jetty/Response;","isCommitted",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitJumpStmt(IF_NEZ,3,-1,L2);
                code.visitFieldStmt(IGET_OBJECT,3,9,new Field("Lorg/mortbay/jetty/Response;","_connection","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Lorg/mortbay/jetty/HttpConnection;","isIncluding",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitJumpStmt(IF_EQZ,3,-1,L3);
                code.visitLabel(L2);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L3);
                code.visitFieldStmt(IPUT_OBJECT,10,9,new Field("Lorg/mortbay/jetty/Response;","_locale","Ljava/util/Locale;"));
                code.visitLabel(L4);
                code.visitFieldStmt(IGET_OBJECT,3,9,new Field("Lorg/mortbay/jetty/Response;","_connection","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Lorg/mortbay/jetty/HttpConnection;","getResponseFields",new String[]{ },"Lorg/mortbay/jetty/HttpFields;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitFieldStmt(SGET_OBJECT,4,-1,new Field("Lorg/mortbay/jetty/HttpHeaders;","CONTENT_LANGUAGE_BUFFER","Lorg/mortbay/io/Buffer;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10},new Method("Ljava/util/Locale;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitConstStmt(CONST_16,6, Integer.valueOf(95)); // int: 0x0000005f  float:0.000000
                code.visitConstStmt(CONST_16,7, Integer.valueOf(45)); // int: 0x0000002d  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,6,7},new Method("Ljava/lang/String;","replace",new String[]{ "C","C"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,4,5},new Method("Lorg/mortbay/jetty/HttpFields;","put",new String[]{ "Lorg/mortbay/io/Buffer;","Ljava/lang/String;"},"V"));
                code.visitLabel(L5);
                code.visitFieldStmt(IGET_BOOLEAN,3,9,new Field("Lorg/mortbay/jetty/Response;","_explicitEncoding","Z"));
                code.visitJumpStmt(IF_NEZ,3,-1,L2);
                code.visitFieldStmt(IGET,3,9,new Field("Lorg/mortbay/jetty/Response;","_outputState","I"));
                code.visitJumpStmt(IF_NEZ,3,-1,L2);
                code.visitLabel(L6);
                code.visitFieldStmt(IGET_OBJECT,3,9,new Field("Lorg/mortbay/jetty/Response;","_connection","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Lorg/mortbay/jetty/HttpConnection;","getRequest",new String[]{ },"Lorg/mortbay/jetty/Request;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Lorg/mortbay/jetty/Request;","getContext",new String[]{ },"Lorg/mortbay/jetty/handler/ContextHandler$SContext;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitJumpStmt(IF_EQZ,3,-1,L2);
                code.visitLabel(L7);
                code.visitFieldStmt(IGET_OBJECT,3,9,new Field("Lorg/mortbay/jetty/Response;","_connection","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Lorg/mortbay/jetty/HttpConnection;","getRequest",new String[]{ },"Lorg/mortbay/jetty/Request;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Lorg/mortbay/jetty/Request;","getContext",new String[]{ },"Lorg/mortbay/jetty/handler/ContextHandler$SContext;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Lorg/mortbay/jetty/handler/ContextHandler$SContext;","getContextHandler",new String[]{ },"Lorg/mortbay/jetty/handler/ContextHandler;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,10},new Method("Lorg/mortbay/jetty/handler/ContextHandler;","getLocaleEncoding",new String[]{ "Ljava/util/Locale;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L8);
                code.visitJumpStmt(IF_EQZ,0,-1,L2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/lang/String;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitJumpStmt(IF_LEZ,3,-1,L2);
                code.visitLabel(L9);
                code.visitFieldStmt(IPUT_OBJECT,0,9,new Field("Lorg/mortbay/jetty/Response;","_characterEncoding","Ljava/lang/String;"));
                code.visitLabel(L10);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9},new Method("Lorg/mortbay/jetty/Response;","getContentType",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitLabel(L11);
                code.visitJumpStmt(IF_EQZ,2,-1,L2);
                code.visitLabel(L12);
                code.visitFieldStmt(IPUT_OBJECT,0,9,new Field("Lorg/mortbay/jetty/Response;","_characterEncoding","Ljava/lang/String;"));
                code.visitLabel(L13);
                code.visitConstStmt(CONST_16,3, Integer.valueOf(59)); // int: 0x0000003b  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3},new Method("Ljava/lang/String;","indexOf",new String[]{ "I"},"I"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitLabel(L14);
                code.visitJumpStmt(IF_GEZ,1,-1,L19);
                code.visitLabel(L15);
                code.visitFieldStmt(IPUT_OBJECT,2,9,new Field("Lorg/mortbay/jetty/Response;","_mimeType","Ljava/lang/String;"));
                code.visitLabel(L16);
                code.visitTypeStmt(NEW_INSTANCE,3,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 3},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,2},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitConstStmt(CONST_STRING,4,"; charset=");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,8},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,0},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitFieldStmt(IPUT_OBJECT,2,9,new Field("Lorg/mortbay/jetty/Response;","_contentType","Ljava/lang/String;"));
                code.visitLabel(L17);
                code.visitFieldStmt(SGET_OBJECT,3,-1,new Field("Lorg/mortbay/jetty/MimeTypes;","CACHE","Lorg/mortbay/io/BufferCache;"));
                code.visitFieldStmt(IGET_OBJECT,4,9,new Field("Lorg/mortbay/jetty/Response;","_mimeType","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,4},new Method("Lorg/mortbay/io/BufferCache;","get",new String[]{ "Ljava/lang/String;"},"Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitFieldStmt(IPUT_OBJECT,3,9,new Field("Lorg/mortbay/jetty/Response;","_cachedMimeType","Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitLabel(L18);
                code.visitFieldStmt(IGET_OBJECT,3,9,new Field("Lorg/mortbay/jetty/Response;","_connection","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Lorg/mortbay/jetty/HttpConnection;","getResponseFields",new String[]{ },"Lorg/mortbay/jetty/HttpFields;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitFieldStmt(SGET_OBJECT,4,-1,new Field("Lorg/mortbay/jetty/HttpHeaders;","CONTENT_TYPE_BUFFER","Lorg/mortbay/io/Buffer;"));
                code.visitFieldStmt(IGET_OBJECT,5,9,new Field("Lorg/mortbay/jetty/Response;","_contentType","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,4,5},new Method("Lorg/mortbay/jetty/HttpFields;","put",new String[]{ "Lorg/mortbay/io/Buffer;","Ljava/lang/String;"},"V"));
                code.visitJumpStmt(GOTO_16,-1,-1,L2);
                code.visitLabel(L19);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3,1},new Method("Ljava/lang/String;","substring",new String[]{ "I","I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitFieldStmt(IPUT_OBJECT,3,9,new Field("Lorg/mortbay/jetty/Response;","_mimeType","Ljava/lang/String;"));
                code.visitLabel(L20);
                code.visitTypeStmt(NEW_INSTANCE,3,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 3},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitFieldStmt(IGET_OBJECT,4,9,new Field("Lorg/mortbay/jetty/Response;","_mimeType","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,4},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitConstStmt(CONST_STRING,4,"; charset=");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,8},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,0},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitFieldStmt(IPUT_OBJECT,3,9,new Field("Lorg/mortbay/jetty/Response;","_mimeType","Ljava/lang/String;"));
                code.visitFieldStmt(IPUT_OBJECT,3,9,new Field("Lorg/mortbay/jetty/Response;","_contentType","Ljava/lang/String;"));
                code.visitJumpStmt(GOTO,-1,-1,L17);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m043_setLongContentLength(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/Response;","setLongContentLength",new String[]{ "J"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"len");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(739,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(743,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(741,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(742,L3);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/jetty/Response;","isCommitted",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_NEZ,0,-1,L1);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/jetty/Response;","_connection","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/jetty/HttpConnection;","isIncluding",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_EQZ,0,-1,L2);
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L2);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/jetty/Response;","_connection","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpConnection;","_generator","Lorg/mortbay/jetty/Generator;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,3,4},new Method("Lorg/mortbay/jetty/Generator;","setContentLength",new String[]{ "J"},"V"));
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/jetty/Response;","_connection","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/jetty/HttpConnection;","getResponseFields",new String[]{ },"Lorg/mortbay/jetty/HttpFields;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitConstStmt(CONST_STRING,1,"Content-Length");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1,3,4},new Method("Lorg/mortbay/jetty/HttpFields;","putLongField",new String[]{ "Ljava/lang/String;","J"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L1);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m044_setStatus(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/Response;","setStatus",new String[]{ "I"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"sc");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(521,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(522,L1);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2,0},new Method("Lorg/mortbay/jetty/Response;","setStatus",new String[]{ "I","Ljava/lang/String;"},"V"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m045_setStatus(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/Response;","setStatus",new String[]{ "I","Ljava/lang/String;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"sc");
                ddv.visitParameterName(1,"sm");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(530,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(532,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(533,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(535,L3);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/Response;","_connection","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/jetty/HttpConnection;","isIncluding",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_NEZ,0,-1,L3);
                code.visitLabel(L1);
                code.visitFieldStmt(IPUT,2,1,new Field("Lorg/mortbay/jetty/Response;","_status","I"));
                code.visitLabel(L2);
                code.visitFieldStmt(IPUT_OBJECT,3,1,new Field("Lorg/mortbay/jetty/Response;","_reason","Ljava/lang/String;"));
                code.visitLabel(L3);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m046_toString(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/Response;","toString",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(1128,L0);
                code.visitLabel(L0);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,1,"HTTP/1.1 ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(IGET,1,2,new Field("Lorg/mortbay/jetty/Response;","_status","I"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "I"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitConstStmt(CONST_STRING,1," ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/jetty/Response;","_reason","Ljava/lang/String;"));
                DexLabel L1=new DexLabel();
                code.visitJumpStmt(IF_NEZ,1,-1,L1);
                code.visitConstStmt(CONST_STRING,1,"");
                DexLabel L2=new DexLabel();
                code.visitLabel(L2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitConstStmt(CONST_STRING,1,"line.separator");
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1},new Method("Ljava/lang/System;","getProperty",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/jetty/Response;","_connection","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Lorg/mortbay/jetty/HttpConnection;","getResponseFields",new String[]{ },"Lorg/mortbay/jetty/HttpFields;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Lorg/mortbay/jetty/HttpFields;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/jetty/Response;","_reason","Ljava/lang/String;"));
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
