package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0378_org_mortbay_servlet_GzipFilter {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(ACC_PUBLIC,"Lorg/mortbay/servlet/GzipFilter;","Lorg/mortbay/servlet/UserAgentFilter;",new String[]{ });
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("GzipFilter.java");
        if(cv!=null){
            DexAnnotationVisitor av00 = cv.visitAnnotation("Ldalvik/annotation/MemberClasses;", Visibility.SYSTEM);
            if(av00 != null) {
                {
                    DexAnnotationVisitor av01 = av00.visitArray("value");
                    if(av01 != null) {
                        av01.visit(null, new DexType("Lorg/mortbay/servlet/GzipFilter$GzipStream;"));
                        av01.visit(null, new DexType("Lorg/mortbay/servlet/GzipFilter$GZIPResponseWrapper;"));
                        av01.visitEnd();
                    }
                }
                av00.visitEnd();
            }
        }
        f000__bufferSize(cv);
        f001__excluded(cv);
        f002__mimeTypes(cv);
        f003__minGzipSize(cv);
        m000__init_(cv);
        m001_destroy(cv);
        m002_doFilter(cv);
        m003_init(cv);
        m004_newGZIPResponseWrapper(cv);
    }
    public static void f000__bufferSize(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PROTECTED, new Field("Lorg/mortbay/servlet/GzipFilter;","_bufferSize","I"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f001__excluded(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PROTECTED, new Field("Lorg/mortbay/servlet/GzipFilter;","_excluded","Ljava/util/Set;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f002__mimeTypes(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PROTECTED, new Field("Lorg/mortbay/servlet/GzipFilter;","_mimeTypes","Ljava/util/Set;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f003__minGzipSize(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PROTECTED, new Field("Lorg/mortbay/servlet/GzipFilter;","_minGzipSize","I"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void m000__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/servlet/GzipFilter;","<init>",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(63,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(66,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(67,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(353,L3);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1},new Method("Lorg/mortbay/servlet/UserAgentFilter;","<init>",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitConstStmt(CONST_16,0, Integer.valueOf(8192)); // int: 0x00002000  float:0.000000
                code.visitFieldStmt(IPUT,0,1,new Field("Lorg/mortbay/servlet/GzipFilter;","_bufferSize","I"));
                code.visitLabel(L2);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT,0,1,new Field("Lorg/mortbay/servlet/GzipFilter;","_minGzipSize","I"));
                code.visitLabel(L3);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001_destroy(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/servlet/GzipFilter;","destroy",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(1);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(103,L0);
                code.visitLabel(L0);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m002_doFilter(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/servlet/GzipFilter;","doFilter",new String[]{ "Ljavax/servlet/ServletRequest;","Ljavax/servlet/ServletResponse;","Ljavax/servlet/FilterChain;"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visit(null, new DexType("Ljavax/servlet/ServletException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(13);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"req");
                ddv.visitParameterName(1,"res");
                ddv.visitParameterName(2,"chain");
                DexLabel L3=new DexLabel();
                ddv.visitPrologue(L3);
                ddv.visitLineNumber(108,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(109,L4);
                ddv.visitStartLocal(3,L4,"request","Ljavax/servlet/http/HttpServletRequest;",null);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(111,L5);
                ddv.visitStartLocal(4,L5,"response","Ljavax/servlet/http/HttpServletResponse;",null);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(112,L6);
                ddv.visitStartLocal(1,L6,"ae","Ljava/lang/String;",null);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(114,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(116,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(117,L9);
                ddv.visitStartLocal(5,L9,"ua","Ljava/lang/String;",null);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(119,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(147,L11);
                ddv.visitEndLocal(5,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(124,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(126,L13);
                ddv.visitStartLocal(6,L13,"wrappedResponse","Lorg/mortbay/servlet/GzipFilter$GZIPResponseWrapper;",null);
                ddv.visitLineNumber(129,L0);
                ddv.visitStartLocal(2,L0,"exceptional","Z",null);
                ddv.visitLineNumber(130,L1);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(134,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(136,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(137,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(140,L17);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(134,L18);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(145,L19);
                ddv.visitEndLocal(6,L19);
                ddv.visitEndLocal(2,L19);
                ddv.visitLineNumber(134,L2);
                ddv.visitRestartLocal(2,L2);
                ddv.visitRestartLocal(6,L2);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(136,L20);
                DexLabel L21=new DexLabel();
                ddv.visitLineNumber(137,L21);
                DexLabel L22=new DexLabel();
                ddv.visitLineNumber(140,L22);
                code.visitLabel(L3);
                code.visitStmt2R(MOVE_OBJECT,0,10);
                code.visitTypeStmt(CHECK_CAST,0,-1,"Ljavax/servlet/http/HttpServletRequest;");
                code.visitStmt2R(MOVE_OBJECT,3,0);
                code.visitLabel(L4);
                code.visitStmt2R(MOVE_OBJECT,0,11);
                code.visitTypeStmt(CHECK_CAST,0,-1,"Ljavax/servlet/http/HttpServletResponse;");
                code.visitStmt2R(MOVE_OBJECT,4,0);
                code.visitLabel(L5);
                code.visitConstStmt(CONST_STRING,7,"accept-encoding");
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 3,7},new Method("Ljavax/servlet/http/HttpServletRequest;","getHeader",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L6);
                code.visitJumpStmt(IF_EQZ,1,-1,L19);
                code.visitConstStmt(CONST_STRING,7,"gzip");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,7},new Method("Ljava/lang/String;","indexOf",new String[]{ "Ljava/lang/String;"},"I"));
                code.visitStmt1R(MOVE_RESULT,7);
                code.visitJumpStmt(IF_LTZ,7,-1,L19);
                code.visitConstStmt(CONST_STRING,7,"Content-Encoding");
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 4,7},new Method("Ljavax/servlet/http/HttpServletResponse;","containsHeader",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,7);
                code.visitJumpStmt(IF_NEZ,7,-1,L19);
                code.visitLabel(L7);
                code.visitFieldStmt(IGET_OBJECT,7,9,new Field("Lorg/mortbay/servlet/GzipFilter;","_excluded","Ljava/util/Set;"));
                code.visitJumpStmt(IF_EQZ,7,-1,L12);
                code.visitLabel(L8);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9,3},new Method("Lorg/mortbay/servlet/GzipFilter;","getUserAgent",new String[]{ "Ljavax/servlet/ServletRequest;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitLabel(L9);
                code.visitFieldStmt(IGET_OBJECT,7,9,new Field("Lorg/mortbay/servlet/GzipFilter;","_excluded","Ljava/util/Set;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 7,5},new Method("Ljava/util/Set;","contains",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,7);
                code.visitJumpStmt(IF_EQZ,7,-1,L12);
                code.visitLabel(L10);
                code.visitMethodStmt(INVOKE_SUPER,new int[]{ 9,3,4,12},new Method("Lorg/mortbay/servlet/UserAgentFilter;","doFilter",new String[]{ "Ljavax/servlet/ServletRequest;","Ljavax/servlet/ServletResponse;","Ljavax/servlet/FilterChain;"},"V"));
                code.visitLabel(L11);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L12);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9,3,4},new Method("Lorg/mortbay/servlet/GzipFilter;","newGZIPResponseWrapper",new String[]{ "Ljavax/servlet/http/HttpServletRequest;","Ljavax/servlet/http/HttpServletResponse;"},"Lorg/mortbay/servlet/GzipFilter$GZIPResponseWrapper;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitLabel(L13);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_SUPER,new int[]{ 9,3,6,12},new Method("Lorg/mortbay/servlet/UserAgentFilter;","doFilter",new String[]{ "Ljavax/servlet/ServletRequest;","Ljavax/servlet/ServletResponse;","Ljavax/servlet/FilterChain;"},"V"));
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L14);
                code.visitJumpStmt(IF_EQZ,2,-1,L22);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 4},new Method("Ljavax/servlet/http/HttpServletResponse;","isCommitted",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,7);
                code.visitJumpStmt(IF_NEZ,7,-1,L22);
                code.visitLabel(L15);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Lorg/mortbay/servlet/GzipFilter$GZIPResponseWrapper;","resetBuffer",new String[]{ },"V"));
                code.visitLabel(L16);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Lorg/mortbay/servlet/GzipFilter$GZIPResponseWrapper;","noGzip",new String[]{ },"V"));
                code.visitJumpStmt(GOTO,-1,-1,L11);
                code.visitLabel(L17);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Lorg/mortbay/servlet/GzipFilter$GZIPResponseWrapper;","finish",new String[]{ },"V"));
                code.visitLabel(L18);
                code.visitStmt1R(THROW,7);
                code.visitLabel(L19);
                code.visitMethodStmt(INVOKE_SUPER,new int[]{ 9,3,4,12},new Method("Lorg/mortbay/servlet/UserAgentFilter;","doFilter",new String[]{ "Ljavax/servlet/ServletRequest;","Ljavax/servlet/ServletResponse;","Ljavax/servlet/FilterChain;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L11);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,7);
                code.visitJumpStmt(IF_EQZ,2,-1,L17);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 4},new Method("Ljavax/servlet/http/HttpServletResponse;","isCommitted",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,8);
                code.visitJumpStmt(IF_NEZ,8,-1,L17);
                code.visitLabel(L20);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Lorg/mortbay/servlet/GzipFilter$GZIPResponseWrapper;","resetBuffer",new String[]{ },"V"));
                code.visitLabel(L21);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Lorg/mortbay/servlet/GzipFilter$GZIPResponseWrapper;","noGzip",new String[]{ },"V"));
                code.visitJumpStmt(GOTO,-1,-1,L18);
                code.visitLabel(L22);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Lorg/mortbay/servlet/GzipFilter$GZIPResponseWrapper;","finish",new String[]{ },"V"));
                code.visitJumpStmt(GOTO,-1,-1,L11);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m003_init(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/servlet/GzipFilter;","init",new String[]{ "Ljavax/servlet/FilterConfig;"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljavax/servlet/ServletException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(8);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"filterConfig");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(72,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(74,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(75,L3);
                ddv.visitStartLocal(0,L3,"tmp","Ljava/lang/String;",null);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(76,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(78,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(79,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(80,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(82,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(83,L9);
                ddv.visitRestartLocal(0,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(85,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(86,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(87,L12);
                ddv.visitStartLocal(1,L12,"tok","Ljava/util/StringTokenizer;",null);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(88,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(91,L14);
                ddv.visitEndLocal(1,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(92,L15);
                ddv.visitRestartLocal(0,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(94,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(95,L17);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(96,L18);
                ddv.visitRestartLocal(1,L18);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(97,L19);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(99,L20);
                ddv.visitEndLocal(1,L20);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,4, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitConstStmt(CONST_STRING,5,",");
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_SUPER,new int[]{ 6,7},new Method("Lorg/mortbay/servlet/UserAgentFilter;","init",new String[]{ "Ljavax/servlet/FilterConfig;"},"V"));
                code.visitLabel(L2);
                code.visitConstStmt(CONST_STRING,2,"bufferSize");
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 7,2},new Method("Ljavax/servlet/FilterConfig;","getInitParameter",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L3);
                code.visitJumpStmt(IF_EQZ,0,-1,L5);
                code.visitLabel(L4);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0},new Method("Ljava/lang/Integer;","parseInt",new String[]{ "Ljava/lang/String;"},"I"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitFieldStmt(IPUT,2,6,new Field("Lorg/mortbay/servlet/GzipFilter;","_bufferSize","I"));
                code.visitLabel(L5);
                code.visitConstStmt(CONST_STRING,2,"minGzipSize");
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 7,2},new Method("Ljavax/servlet/FilterConfig;","getInitParameter",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L6);
                code.visitJumpStmt(IF_EQZ,0,-1,L8);
                code.visitLabel(L7);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0},new Method("Ljava/lang/Integer;","parseInt",new String[]{ "Ljava/lang/String;"},"I"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitFieldStmt(IPUT,2,6,new Field("Lorg/mortbay/servlet/GzipFilter;","_minGzipSize","I"));
                code.visitLabel(L8);
                code.visitConstStmt(CONST_STRING,2,"mimeTypes");
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 7,2},new Method("Ljavax/servlet/FilterConfig;","getInitParameter",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L9);
                code.visitJumpStmt(IF_EQZ,0,-1,L14);
                code.visitLabel(L10);
                code.visitTypeStmt(NEW_INSTANCE,2,-1,"Ljava/util/HashSet;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2},new Method("Ljava/util/HashSet;","<init>",new String[]{ },"V"));
                code.visitFieldStmt(IPUT_OBJECT,2,6,new Field("Lorg/mortbay/servlet/GzipFilter;","_mimeTypes","Ljava/util/Set;"));
                code.visitLabel(L11);
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Ljava/util/StringTokenizer;");
                code.visitConstStmt(CONST_STRING,2,",");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1,0,5,4},new Method("Ljava/util/StringTokenizer;","<init>",new String[]{ "Ljava/lang/String;","Ljava/lang/String;","Z"},"V"));
                code.visitLabel(L12);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/util/StringTokenizer;","hasMoreTokens",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitJumpStmt(IF_EQZ,2,-1,L14);
                code.visitLabel(L13);
                code.visitFieldStmt(IGET_OBJECT,2,6,new Field("Lorg/mortbay/servlet/GzipFilter;","_mimeTypes","Ljava/util/Set;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/util/StringTokenizer;","nextToken",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 2,3},new Method("Ljava/util/Set;","add",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitJumpStmt(GOTO,-1,-1,L12);
                code.visitLabel(L14);
                code.visitConstStmt(CONST_STRING,2,"excludedAgents");
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 7,2},new Method("Ljavax/servlet/FilterConfig;","getInitParameter",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L15);
                code.visitJumpStmt(IF_EQZ,0,-1,L20);
                code.visitLabel(L16);
                code.visitTypeStmt(NEW_INSTANCE,2,-1,"Ljava/util/HashSet;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2},new Method("Ljava/util/HashSet;","<init>",new String[]{ },"V"));
                code.visitFieldStmt(IPUT_OBJECT,2,6,new Field("Lorg/mortbay/servlet/GzipFilter;","_excluded","Ljava/util/Set;"));
                code.visitLabel(L17);
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Ljava/util/StringTokenizer;");
                code.visitConstStmt(CONST_STRING,2,",");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1,0,5,4},new Method("Ljava/util/StringTokenizer;","<init>",new String[]{ "Ljava/lang/String;","Ljava/lang/String;","Z"},"V"));
                code.visitLabel(L18);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/util/StringTokenizer;","hasMoreTokens",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitJumpStmt(IF_EQZ,2,-1,L20);
                code.visitLabel(L19);
                code.visitFieldStmt(IGET_OBJECT,2,6,new Field("Lorg/mortbay/servlet/GzipFilter;","_excluded","Ljava/util/Set;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/util/StringTokenizer;","nextToken",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 2,3},new Method("Ljava/util/Set;","add",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitJumpStmt(GOTO,-1,-1,L18);
                code.visitLabel(L20);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m004_newGZIPResponseWrapper(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Lorg/mortbay/servlet/GzipFilter;","newGZIPResponseWrapper",new String[]{ "Ljavax/servlet/http/HttpServletRequest;","Ljavax/servlet/http/HttpServletResponse;"},"Lorg/mortbay/servlet/GzipFilter$GZIPResponseWrapper;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"request");
                ddv.visitParameterName(1,"response");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(151,L0);
                code.visitLabel(L0);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Lorg/mortbay/servlet/GzipFilter$GZIPResponseWrapper;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1,2,3},new Method("Lorg/mortbay/servlet/GzipFilter$GZIPResponseWrapper;","<init>",new String[]{ "Lorg/mortbay/servlet/GzipFilter;","Ljavax/servlet/http/HttpServletRequest;","Ljavax/servlet/http/HttpServletResponse;"},"V"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
