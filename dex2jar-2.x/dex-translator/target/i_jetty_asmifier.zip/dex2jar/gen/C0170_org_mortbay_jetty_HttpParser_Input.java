package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0170_org_mortbay_jetty_HttpParser_Input {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(ACC_PUBLIC,"Lorg/mortbay/jetty/HttpParser$Input;","Ljavax/servlet/ServletInputStream;",new String[]{ });
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("HttpParser.java");
        if(cv!=null){
            DexAnnotationVisitor av00 = cv.visitAnnotation("Ldalvik/annotation/EnclosingClass;", Visibility.SYSTEM);
            if(av00 != null) {
                av00.visit("value", new DexType("Lorg/mortbay/jetty/HttpParser;"));
                av00.visitEnd();
            }
        }
        if(cv!=null){
            DexAnnotationVisitor av00 = cv.visitAnnotation("Ldalvik/annotation/InnerClass;", Visibility.SYSTEM);
            if(av00 != null) {
                av00.visit("accessFlags",  Integer.valueOf(9));
                av00.visit("name", "Input");
                av00.visitEnd();
            }
        }
        f000__contentView(cv);
        f001__endp(cv);
        f002__maxIdleTime(cv);
        f003__parser(cv);
        m000__init_(cv);
        m001_blockForContent(cv);
        m002_available(cv);
        m003_read(cv);
        m004_read(cv);
    }
    public static void f000__contentView(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PROTECTED, new Field("Lorg/mortbay/jetty/HttpParser$Input;","_contentView","Lorg/mortbay/io/Buffer;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f001__endp(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PROTECTED, new Field("Lorg/mortbay/jetty/HttpParser$Input;","_endp","Lorg/mortbay/io/EndPoint;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f002__maxIdleTime(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PROTECTED, new Field("Lorg/mortbay/jetty/HttpParser$Input;","_maxIdleTime","J"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f003__parser(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PROTECTED, new Field("Lorg/mortbay/jetty/HttpParser$Input;","_parser","Lorg/mortbay/jetty/HttpParser;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void m000__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/jetty/HttpParser$Input;","<init>",new String[]{ "Lorg/mortbay/jetty/HttpParser;","J"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"parser");
                ddv.visitParameterName(1,"maxIdleTime");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(1082,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(1083,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(1084,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(1085,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(1086,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(1087,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(1088,L6);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1},new Method("Ljavax/servlet/ServletInputStream;","<init>",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitFieldStmt(IPUT_OBJECT,2,1,new Field("Lorg/mortbay/jetty/HttpParser$Input;","_parser","Lorg/mortbay/jetty/HttpParser;"));
                code.visitLabel(L2);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 2},new Method("Lorg/mortbay/jetty/HttpParser;","access$000",new String[]{ "Lorg/mortbay/jetty/HttpParser;"},"Lorg/mortbay/io/EndPoint;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/jetty/HttpParser$Input;","_endp","Lorg/mortbay/io/EndPoint;"));
                code.visitLabel(L3);
                code.visitFieldStmt(IPUT_WIDE,3,1,new Field("Lorg/mortbay/jetty/HttpParser$Input;","_maxIdleTime","J"));
                code.visitLabel(L4);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/HttpParser$Input;","_parser","Lorg/mortbay/jetty/HttpParser;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0},new Method("Lorg/mortbay/jetty/HttpParser;","access$100",new String[]{ "Lorg/mortbay/jetty/HttpParser;"},"Lorg/mortbay/io/View;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/jetty/HttpParser$Input;","_contentView","Lorg/mortbay/io/Buffer;"));
                code.visitLabel(L5);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/HttpParser$Input;","_parser","Lorg/mortbay/jetty/HttpParser;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0,1},new Method("Lorg/mortbay/jetty/HttpParser;","access$202",new String[]{ "Lorg/mortbay/jetty/HttpParser;","Lorg/mortbay/jetty/HttpParser$Input;"},"Lorg/mortbay/jetty/HttpParser$Input;"));
                code.visitLabel(L6);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001_blockForContent(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PRIVATE, new Method("Lorg/mortbay/jetty/HttpParser$Input;","blockForContent",new String[]{ },"Z"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(7);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ "Ljava/io/IOException;"});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L3=new DexLabel();
                ddv.visitPrologue(L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(1117,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(1164,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(1119,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(1120,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(1123,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(1124,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(1164,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(1127,L11);
                ddv.visitLineNumber(1131,L0);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(1134,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(1137,L13);
                ddv.visitLineNumber(1140,L2);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(1142,L14);
                ddv.visitStartLocal(0,L14,"e","Ljava/io/IOException;",null);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(1143,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(1148,L16);
                ddv.visitEndLocal(0,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(1151,L17);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(1153,L18);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(1155,L19);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(1156,L20);
                DexLabel L21=new DexLabel();
                ddv.visitLineNumber(1160,L21);
                DexLabel L22=new DexLabel();
                ddv.visitLineNumber(1164,L22);
                code.visitLabel(L3);
                code.visitConstStmt(CONST_4,5, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitConstStmt(CONST_4,4, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L4);
                code.visitFieldStmt(IGET_OBJECT,1,6,new Field("Lorg/mortbay/jetty/HttpParser$Input;","_contentView","Lorg/mortbay/io/Buffer;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 1},new Method("Lorg/mortbay/io/Buffer;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitJumpStmt(IF_LEZ,1,-1,L6);
                code.visitStmt2R(MOVE,1,5);
                code.visitLabel(L5);
                code.visitStmt1R(RETURN,1);
                code.visitLabel(L6);
                code.visitFieldStmt(IGET_OBJECT,1,6,new Field("Lorg/mortbay/jetty/HttpParser$Input;","_parser","Lorg/mortbay/jetty/HttpParser;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Lorg/mortbay/jetty/HttpParser;","getState",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitJumpStmt(IF_GTZ,1,-1,L8);
                code.visitStmt2R(MOVE,1,4);
                code.visitLabel(L7);
                code.visitJumpStmt(GOTO,-1,-1,L5);
                code.visitLabel(L8);
                code.visitFieldStmt(IGET_OBJECT,1,6,new Field("Lorg/mortbay/jetty/HttpParser$Input;","_endp","Lorg/mortbay/io/EndPoint;"));
                code.visitJumpStmt(IF_NEZ,1,-1,L11);
                code.visitLabel(L9);
                code.visitFieldStmt(IGET_OBJECT,1,6,new Field("Lorg/mortbay/jetty/HttpParser$Input;","_parser","Lorg/mortbay/jetty/HttpParser;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Lorg/mortbay/jetty/HttpParser;","parseNext",new String[]{ },"J"));
                code.visitLabel(L10);
                code.visitFieldStmt(IGET_OBJECT,1,6,new Field("Lorg/mortbay/jetty/HttpParser$Input;","_contentView","Lorg/mortbay/io/Buffer;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 1},new Method("Lorg/mortbay/io/Buffer;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,1);
                DexLabel L23=new DexLabel();
                code.visitJumpStmt(IF_LEZ,1,-1,L23);
                code.visitStmt2R(MOVE,1,5);
                code.visitJumpStmt(GOTO,-1,-1,L5);
                code.visitLabel(L11);
                code.visitFieldStmt(IGET_OBJECT,1,6,new Field("Lorg/mortbay/jetty/HttpParser$Input;","_endp","Lorg/mortbay/io/EndPoint;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 1},new Method("Lorg/mortbay/io/EndPoint;","isBlocking",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitJumpStmt(IF_EQZ,1,-1,L16);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,1,6,new Field("Lorg/mortbay/jetty/HttpParser$Input;","_parser","Lorg/mortbay/jetty/HttpParser;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Lorg/mortbay/jetty/HttpParser;","parseNext",new String[]{ },"J"));
                code.visitLabel(L12);
                code.visitFieldStmt(IGET_OBJECT,1,6,new Field("Lorg/mortbay/jetty/HttpParser$Input;","_contentView","Lorg/mortbay/io/Buffer;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 1},new Method("Lorg/mortbay/io/Buffer;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitJumpStmt(IF_NEZ,1,-1,L10);
                code.visitFieldStmt(IGET_OBJECT,1,6,new Field("Lorg/mortbay/jetty/HttpParser$Input;","_parser","Lorg/mortbay/jetty/HttpParser;"));
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2},new Method("Lorg/mortbay/jetty/HttpParser;","isState",new String[]{ "I"},"Z"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitJumpStmt(IF_NEZ,1,-1,L10);
                code.visitLabel(L13);
                code.visitFieldStmt(IGET_OBJECT,1,6,new Field("Lorg/mortbay/jetty/HttpParser$Input;","_parser","Lorg/mortbay/jetty/HttpParser;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Lorg/mortbay/jetty/HttpParser;","parseNext",new String[]{ },"J"));
                code.visitLabel(L1);
                code.visitJumpStmt(GOTO,-1,-1,L12);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,1);
                code.visitStmt2R(MOVE_OBJECT,0,1);
                code.visitLabel(L14);
                code.visitFieldStmt(IGET_OBJECT,1,6,new Field("Lorg/mortbay/jetty/HttpParser$Input;","_endp","Lorg/mortbay/io/EndPoint;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 1},new Method("Lorg/mortbay/io/EndPoint;","close",new String[]{ },"V"));
                code.visitLabel(L15);
                code.visitStmt1R(THROW,0);
                code.visitLabel(L16);
                code.visitFieldStmt(IGET_OBJECT,1,6,new Field("Lorg/mortbay/jetty/HttpParser$Input;","_parser","Lorg/mortbay/jetty/HttpParser;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Lorg/mortbay/jetty/HttpParser;","parseNext",new String[]{ },"J"));
                code.visitLabel(L17);
                code.visitFieldStmt(IGET_OBJECT,1,6,new Field("Lorg/mortbay/jetty/HttpParser$Input;","_contentView","Lorg/mortbay/io/Buffer;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 1},new Method("Lorg/mortbay/io/Buffer;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitJumpStmt(IF_NEZ,1,-1,L10);
                code.visitFieldStmt(IGET_OBJECT,1,6,new Field("Lorg/mortbay/jetty/HttpParser$Input;","_parser","Lorg/mortbay/jetty/HttpParser;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,4},new Method("Lorg/mortbay/jetty/HttpParser;","isState",new String[]{ "I"},"Z"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitJumpStmt(IF_NEZ,1,-1,L10);
                code.visitLabel(L18);
                code.visitFieldStmt(IGET_OBJECT,1,6,new Field("Lorg/mortbay/jetty/HttpParser$Input;","_endp","Lorg/mortbay/io/EndPoint;"));
                code.visitFieldStmt(IGET_WIDE,2,6,new Field("Lorg/mortbay/jetty/HttpParser$Input;","_maxIdleTime","J"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 1,2,3},new Method("Lorg/mortbay/io/EndPoint;","blockReadable",new String[]{ "J"},"Z"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitJumpStmt(IF_NEZ,1,-1,L21);
                code.visitLabel(L19);
                code.visitFieldStmt(IGET_OBJECT,1,6,new Field("Lorg/mortbay/jetty/HttpParser$Input;","_endp","Lorg/mortbay/io/EndPoint;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 1},new Method("Lorg/mortbay/io/EndPoint;","close",new String[]{ },"V"));
                code.visitLabel(L20);
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Lorg/mortbay/jetty/EofException;");
                code.visitConstStmt(CONST_STRING,2,"timeout");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1,2},new Method("Lorg/mortbay/jetty/EofException;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitStmt1R(THROW,1);
                code.visitLabel(L21);
                code.visitFieldStmt(IGET_OBJECT,1,6,new Field("Lorg/mortbay/jetty/HttpParser$Input;","_parser","Lorg/mortbay/jetty/HttpParser;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Lorg/mortbay/jetty/HttpParser;","parseNext",new String[]{ },"J"));
                code.visitJumpStmt(GOTO,-1,-1,L17);
                code.visitLabel(L23);
                code.visitStmt2R(MOVE,1,4);
                code.visitLabel(L22);
                code.visitJumpStmt(GOTO,-1,-1,L5);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m002_available(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/HttpParser$Input;","available",new String[]{ },"I"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(1173,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(1174,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(1178,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(1175,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(1176,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(1178,L5);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/HttpParser$Input;","_contentView","Lorg/mortbay/io/Buffer;"));
                code.visitJumpStmt(IF_EQZ,0,-1,L3);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/HttpParser$Input;","_contentView","Lorg/mortbay/io/Buffer;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0},new Method("Lorg/mortbay/io/Buffer;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_LEZ,0,-1,L3);
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/HttpParser$Input;","_contentView","Lorg/mortbay/io/Buffer;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0},new Method("Lorg/mortbay/io/Buffer;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitLabel(L2);
                code.visitStmt1R(RETURN,0);
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/HttpParser$Input;","_endp","Lorg/mortbay/io/EndPoint;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0},new Method("Lorg/mortbay/io/EndPoint;","isBlocking",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_NEZ,0,-1,L5);
                code.visitLabel(L4);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/HttpParser$Input;","_parser","Lorg/mortbay/jetty/HttpParser;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/jetty/HttpParser;","parseNext",new String[]{ },"J"));
                code.visitLabel(L5);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/HttpParser$Input;","_contentView","Lorg/mortbay/io/Buffer;"));
                DexLabel L6=new DexLabel();
                code.visitJumpStmt(IF_NEZ,0,-1,L6);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitLabel(L6);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/HttpParser$Input;","_contentView","Lorg/mortbay/io/Buffer;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0},new Method("Lorg/mortbay/io/Buffer;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m003_read(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/HttpParser$Input;","read",new String[]{ },"I"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(1096,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(1097,L1);
                ddv.visitStartLocal(0,L1,"c","I",null);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(1098,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(1099,L3);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(-1)); // int: 0xffffffff  float:NaN
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2},new Method("Lorg/mortbay/jetty/HttpParser$Input;","blockForContent",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitJumpStmt(IF_EQZ,1,-1,L3);
                code.visitLabel(L2);
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/jetty/HttpParser$Input;","_contentView","Lorg/mortbay/io/Buffer;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 1},new Method("Lorg/mortbay/io/Buffer;","get",new String[]{ },"B"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitStmt2R1N(AND_INT_LIT16,0,1,255);
                code.visitLabel(L3);
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m004_read(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/HttpParser$Input;","read",new String[]{ "[B","I","I"},"I"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(6);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"b");
                ddv.visitParameterName(1,"off");
                ddv.visitParameterName(2,"len");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(1108,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(1109,L1);
                ddv.visitStartLocal(0,L1,"l","I",null);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(1110,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(1111,L3);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(-1)); // int: 0xffffffff  float:NaN
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2},new Method("Lorg/mortbay/jetty/HttpParser$Input;","blockForContent",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitJumpStmt(IF_EQZ,1,-1,L3);
                code.visitLabel(L2);
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/jetty/HttpParser$Input;","_contentView","Lorg/mortbay/io/Buffer;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 1,3,4,5},new Method("Lorg/mortbay/io/Buffer;","get",new String[]{ "[B","I","I"},"I"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitLabel(L3);
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
