package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0145_org_mortbay_jetty_HttpURI {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(ACC_PUBLIC,"Lorg/mortbay/jetty/HttpURI;","Ljava/lang/Object;",new String[]{ });
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("HttpURI.java");
        f000_ASTERISK(cv);
        f001_AUTH(cv);
        f002_AUTH_OR_PATH(cv);
        f003_IPV6(cv);
        f004_PARAM(cv);
        f005_PATH(cv);
        f006_PORT(cv);
        f007_QUERY(cv);
        f008_SCHEME_OR_PATH(cv);
        f009_START(cv);
        f010___empty(cv);
        f011__authority(cv);
        f012__end(cv);
        f013__fragment(cv);
        f014__host(cv);
        f015__param(cv);
        f016__partial(cv);
        f017__path(cv);
        f018__port(cv);
        f019__query(cv);
        f020__raw(cv);
        f021__rawString(cv);
        f022__scheme(cv);
        f023__utf8b(cv);
        m000__clinit_(cv);
        m001__init_(cv);
        m002__init_(cv);
        m003__init_(cv);
        m004__init_(cv);
        m005_parse2(cv);
        m006_toUtf8String(cv);
        m007_clear(cv);
        m008_decodeQueryTo(cv);
        m009_decodeQueryTo(cv);
        m010_getAuthority(cv);
        m011_getCompletePath(cv);
        m012_getDecodedPath(cv);
        m013_getFragment(cv);
        m014_getHost(cv);
        m015_getParam(cv);
        m016_getPath(cv);
        m017_getPathAndParam(cv);
        m018_getPort(cv);
        m019_getQuery(cv);
        m020_getQuery(cv);
        m021_getScheme(cv);
        m022_hasQuery(cv);
        m023_parse(cv);
        m024_parse(cv);
        m025_toString(cv);
        m026_writeTo(cv);
    }
    public static void f000_ASTERISK(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpURI;","ASTERISK","I"),  Integer.valueOf(10));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f001_AUTH(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpURI;","AUTH","I"),  Integer.valueOf(4));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f002_AUTH_OR_PATH(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpURI;","AUTH_OR_PATH","I"),  Integer.valueOf(1));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f003_IPV6(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpURI;","IPV6","I"),  Integer.valueOf(5));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f004_PARAM(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpURI;","PARAM","I"),  Integer.valueOf(8));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f005_PATH(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpURI;","PATH","I"),  Integer.valueOf(7));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f006_PORT(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpURI;","PORT","I"),  Integer.valueOf(6));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f007_QUERY(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpURI;","QUERY","I"),  Integer.valueOf(9));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f008_SCHEME_OR_PATH(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpURI;","SCHEME_OR_PATH","I"),  Integer.valueOf(2));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f009_START(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpURI;","START","I"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f010___empty(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE|ACC_STATIC, new Field("Lorg/mortbay/jetty/HttpURI;","__empty","[B"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f011__authority(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(0, new Field("Lorg/mortbay/jetty/HttpURI;","_authority","I"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f012__end(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(0, new Field("Lorg/mortbay/jetty/HttpURI;","_end","I"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f013__fragment(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(0, new Field("Lorg/mortbay/jetty/HttpURI;","_fragment","I"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f014__host(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(0, new Field("Lorg/mortbay/jetty/HttpURI;","_host","I"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f015__param(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(0, new Field("Lorg/mortbay/jetty/HttpURI;","_param","I"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f016__partial(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(0, new Field("Lorg/mortbay/jetty/HttpURI;","_partial","Z"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f017__path(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(0, new Field("Lorg/mortbay/jetty/HttpURI;","_path","I"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f018__port(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(0, new Field("Lorg/mortbay/jetty/HttpURI;","_port","I"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f019__query(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(0, new Field("Lorg/mortbay/jetty/HttpURI;","_query","I"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f020__raw(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(0, new Field("Lorg/mortbay/jetty/HttpURI;","_raw","[B"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f021__rawString(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(0, new Field("Lorg/mortbay/jetty/HttpURI;","_rawString","Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f022__scheme(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(0, new Field("Lorg/mortbay/jetty/HttpURI;","_scheme","I"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f023__utf8b(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(0, new Field("Lorg/mortbay/jetty/HttpURI;","_utf8b","Lorg/mortbay/util/Utf8StringBuffer;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void m000__clinit_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_STATIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/jetty/HttpURI;","<clinit>",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(1);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(45,L0);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitTypeStmt(NEW_ARRAY,0,0,"[B");
                code.visitFieldStmt(SPUT_OBJECT,0,-1,new Field("Lorg/mortbay/jetty/HttpURI;","__empty","[B"));
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/jetty/HttpURI;","<init>",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(74,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(58,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(59,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(71,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(76,L4);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2},new Method("Ljava/lang/Object;","<init>",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT_BOOLEAN,0,2,new Field("Lorg/mortbay/jetty/HttpURI;","_partial","Z"));
                code.visitLabel(L2);
                code.visitFieldStmt(SGET_OBJECT,0,-1,new Field("Lorg/mortbay/jetty/HttpURI;","__empty","[B"));
                code.visitFieldStmt(IPUT_OBJECT,0,2,new Field("Lorg/mortbay/jetty/HttpURI;","_raw","[B"));
                code.visitLabel(L3);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Lorg/mortbay/util/Utf8StringBuffer;");
                code.visitConstStmt(CONST_16,1, Integer.valueOf(64)); // int: 0x00000040  float:0.000000
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1},new Method("Lorg/mortbay/util/Utf8StringBuffer;","<init>",new String[]{ "I"},"V"));
                code.visitFieldStmt(IPUT_OBJECT,0,2,new Field("Lorg/mortbay/jetty/HttpURI;","_utf8b","Lorg/mortbay/util/Utf8StringBuffer;"));
                code.visitLabel(L4);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m002__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/jetty/HttpURI;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(6);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"raw");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(88,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(58,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(59,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(71,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(89,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(90,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(91,L7);
                ddv.visitStartLocal(0,L7,"b","[B",null);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(92,L8);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 4},new Method("Ljava/lang/Object;","<init>",new String[]{ },"V"));
                code.visitLabel(L2);
                code.visitFieldStmt(IPUT_BOOLEAN,3,4,new Field("Lorg/mortbay/jetty/HttpURI;","_partial","Z"));
                code.visitLabel(L3);
                code.visitFieldStmt(SGET_OBJECT,1,-1,new Field("Lorg/mortbay/jetty/HttpURI;","__empty","[B"));
                code.visitFieldStmt(IPUT_OBJECT,1,4,new Field("Lorg/mortbay/jetty/HttpURI;","_raw","[B"));
                code.visitLabel(L4);
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Lorg/mortbay/util/Utf8StringBuffer;");
                code.visitConstStmt(CONST_16,2, Integer.valueOf(64)); // int: 0x00000040  float:0.000000
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1,2},new Method("Lorg/mortbay/util/Utf8StringBuffer;","<init>",new String[]{ "I"},"V"));
                code.visitFieldStmt(IPUT_OBJECT,1,4,new Field("Lorg/mortbay/jetty/HttpURI;","_utf8b","Lorg/mortbay/util/Utf8StringBuffer;"));
                code.visitLabel(L5);
                code.visitFieldStmt(IPUT_OBJECT,5,4,new Field("Lorg/mortbay/jetty/HttpURI;","_rawString","Ljava/lang/String;"));
                code.visitLabel(L6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Ljava/lang/String;","getBytes",new String[]{ },"[B"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L7);
                code.visitStmt2R(ARRAY_LENGTH,1,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,0,3,1},new Method("Lorg/mortbay/jetty/HttpURI;","parse",new String[]{ "[B","I","I"},"V"));
                code.visitLabel(L8);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m003__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/jetty/HttpURI;","<init>",new String[]{ "Z"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"parsePartialAuth");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(83,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(58,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(59,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(71,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(84,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(85,L5);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2},new Method("Ljava/lang/Object;","<init>",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT_BOOLEAN,0,2,new Field("Lorg/mortbay/jetty/HttpURI;","_partial","Z"));
                code.visitLabel(L2);
                code.visitFieldStmt(SGET_OBJECT,0,-1,new Field("Lorg/mortbay/jetty/HttpURI;","__empty","[B"));
                code.visitFieldStmt(IPUT_OBJECT,0,2,new Field("Lorg/mortbay/jetty/HttpURI;","_raw","[B"));
                code.visitLabel(L3);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Lorg/mortbay/util/Utf8StringBuffer;");
                code.visitConstStmt(CONST_16,1, Integer.valueOf(64)); // int: 0x00000040  float:0.000000
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1},new Method("Lorg/mortbay/util/Utf8StringBuffer;","<init>",new String[]{ "I"},"V"));
                code.visitFieldStmt(IPUT_OBJECT,0,2,new Field("Lorg/mortbay/jetty/HttpURI;","_utf8b","Lorg/mortbay/util/Utf8StringBuffer;"));
                code.visitLabel(L4);
                code.visitFieldStmt(IPUT_BOOLEAN,3,2,new Field("Lorg/mortbay/jetty/HttpURI;","_partial","Z"));
                code.visitLabel(L5);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m004__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/jetty/HttpURI;","<init>",new String[]{ "[B","I","I"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(6);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"raw");
                ddv.visitParameterName(1,"offset");
                ddv.visitParameterName(2,"length");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(95,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(58,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(59,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(71,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(96,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(97,L5);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2},new Method("Ljava/lang/Object;","<init>",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT_BOOLEAN,0,2,new Field("Lorg/mortbay/jetty/HttpURI;","_partial","Z"));
                code.visitLabel(L2);
                code.visitFieldStmt(SGET_OBJECT,0,-1,new Field("Lorg/mortbay/jetty/HttpURI;","__empty","[B"));
                code.visitFieldStmt(IPUT_OBJECT,0,2,new Field("Lorg/mortbay/jetty/HttpURI;","_raw","[B"));
                code.visitLabel(L3);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Lorg/mortbay/util/Utf8StringBuffer;");
                code.visitConstStmt(CONST_16,1, Integer.valueOf(64)); // int: 0x00000040  float:0.000000
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1},new Method("Lorg/mortbay/util/Utf8StringBuffer;","<init>",new String[]{ "I"},"V"));
                code.visitFieldStmt(IPUT_OBJECT,0,2,new Field("Lorg/mortbay/jetty/HttpURI;","_utf8b","Lorg/mortbay/util/Utf8StringBuffer;"));
                code.visitLabel(L4);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2,3,4,5},new Method("Lorg/mortbay/jetty/HttpURI;","parse2",new String[]{ "[B","I","I"},"V"));
                code.visitLabel(L5);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m005_parse2(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PRIVATE, new Method("Lorg/mortbay/jetty/HttpURI;","parse2",new String[]{ "[B","I","I"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(16);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"raw");
                ddv.visitParameterName(1,"offset");
                ddv.visitParameterName(2,"length");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(114,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(115,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(116,L3);
                ddv.visitStartLocal(2,L3,"i","I",null);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(117,L4);
                ddv.visitStartLocal(1,L4,"e","I",null);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(118,L5);
                ddv.visitStartLocal(6,L5,"state","I",null);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(119,L6);
                ddv.visitStartLocal(4,L6,"m","I",null);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(120,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(121,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(122,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(123,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(124,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(125,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(126,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(127,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(128,L15);
                ddv.visitEndLocal(2,L15);
                ddv.visitStartLocal(3,L15,"i","I",null);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(130,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(131,L17);
                ddv.visitStartLocal(0,L17,"c","C",null);
                DexLabel L18=new DexLabel();
                ddv.visitRestartLocal(2,L18);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(133,L19);
                ddv.visitStartLocal(5,L19,"s","I",null);
                DexLabel L20=new DexLabel();
                ddv.visitEndLocal(3,L20);
                DexLabel L21=new DexLabel();
                ddv.visitLineNumber(398,L21);
                ddv.visitRestartLocal(3,L21);
                DexLabel L22=new DexLabel();
                ddv.visitLineNumber(137,L22);
                ddv.visitEndLocal(3,L22);
                DexLabel L23=new DexLabel();
                ddv.visitLineNumber(138,L23);
                DexLabel L24=new DexLabel();
                ddv.visitLineNumber(163,L24);
                DexLabel L25=new DexLabel();
                ddv.visitLineNumber(164,L25);
                DexLabel L26=new DexLabel();
                ddv.visitRestartLocal(3,L26);
                DexLabel L27=new DexLabel();
                ddv.visitLineNumber(141,L27);
                ddv.visitEndLocal(3,L27);
                DexLabel L28=new DexLabel();
                ddv.visitLineNumber(142,L28);
                ddv.visitRestartLocal(3,L28);
                DexLabel L29=new DexLabel();
                ddv.visitLineNumber(144,L29);
                ddv.visitEndLocal(3,L29);
                DexLabel L30=new DexLabel();
                ddv.visitLineNumber(145,L30);
                DexLabel L31=new DexLabel();
                ddv.visitLineNumber(146,L31);
                ddv.visitRestartLocal(3,L31);
                DexLabel L32=new DexLabel();
                ddv.visitLineNumber(148,L32);
                ddv.visitEndLocal(3,L32);
                DexLabel L33=new DexLabel();
                ddv.visitLineNumber(149,L33);
                DexLabel L34=new DexLabel();
                ddv.visitLineNumber(150,L34);
                DexLabel L35=new DexLabel();
                ddv.visitLineNumber(151,L35);
                ddv.visitRestartLocal(3,L35);
                DexLabel L36=new DexLabel();
                ddv.visitLineNumber(153,L36);
                ddv.visitEndLocal(3,L36);
                DexLabel L37=new DexLabel();
                ddv.visitLineNumber(154,L37);
                DexLabel L38=new DexLabel();
                ddv.visitLineNumber(155,L38);
                DexLabel L39=new DexLabel();
                ddv.visitLineNumber(156,L39);
                ddv.visitRestartLocal(3,L39);
                DexLabel L40=new DexLabel();
                ddv.visitLineNumber(158,L40);
                ddv.visitEndLocal(3,L40);
                DexLabel L41=new DexLabel();
                ddv.visitLineNumber(159,L41);
                DexLabel L42=new DexLabel();
                ddv.visitLineNumber(160,L42);
                ddv.visitRestartLocal(3,L42);
                DexLabel L43=new DexLabel();
                ddv.visitLineNumber(166,L43);
                ddv.visitEndLocal(3,L43);
                DexLabel L44=new DexLabel();
                ddv.visitLineNumber(174,L44);
                DexLabel L45=new DexLabel();
                ddv.visitLineNumber(176,L45);
                DexLabel L46=new DexLabel();
                ddv.visitLineNumber(177,L46);
                DexLabel L47=new DexLabel();
                ddv.visitLineNumber(178,L47);
                DexLabel L48=new DexLabel();
                ddv.visitLineNumber(179,L48);
                DexLabel L49=new DexLabel();
                ddv.visitRestartLocal(3,L49);
                DexLabel L50=new DexLabel();
                ddv.visitLineNumber(181,L50);
                ddv.visitEndLocal(3,L50);
                DexLabel L51=new DexLabel();
                ddv.visitLineNumber(183,L51);
                DexLabel L52=new DexLabel();
                ddv.visitLineNumber(184,L52);
                DexLabel L53=new DexLabel();
                ddv.visitRestartLocal(3,L53);
                DexLabel L54=new DexLabel();
                ddv.visitLineNumber(188,L54);
                ddv.visitEndLocal(3,L54);
                DexLabel L55=new DexLabel();
                ddv.visitLineNumber(189,L55);
                DexLabel L56=new DexLabel();
                ddv.visitLineNumber(190,L56);
                DexLabel L57=new DexLabel();
                ddv.visitLineNumber(192,L57);
                ddv.visitRestartLocal(3,L57);
                DexLabel L58=new DexLabel();
                ddv.visitLineNumber(198,L58);
                ddv.visitEndLocal(3,L58);
                DexLabel L59=new DexLabel();
                ddv.visitLineNumber(200,L59);
                DexLabel L60=new DexLabel();
                ddv.visitLineNumber(202,L60);
                DexLabel L61=new DexLabel();
                ddv.visitLineNumber(203,L61);
                DexLabel L62=new DexLabel();
                ddv.visitLineNumber(204,L62);
                DexLabel L63=new DexLabel();
                ddv.visitLineNumber(220,L63);
                ddv.visitEndLocal(2,L63);
                ddv.visitRestartLocal(3,L63);
                DexLabel L64=new DexLabel();
                ddv.visitEndLocal(3,L64);
                ddv.visitRestartLocal(2,L64);
                DexLabel L65=new DexLabel();
                ddv.visitLineNumber(268,L65);
                ddv.visitRestartLocal(3,L65);
                DexLabel L66=new DexLabel();
                ddv.visitLineNumber(206,L66);
                ddv.visitEndLocal(3,L66);
                DexLabel L67=new DexLabel();
                ddv.visitLineNumber(208,L67);
                DexLabel L68=new DexLabel();
                ddv.visitLineNumber(209,L68);
                DexLabel L69=new DexLabel();
                ddv.visitLineNumber(210,L69);
                DexLabel L70=new DexLabel();
                ddv.visitRestartLocal(3,L70);
                DexLabel L71=new DexLabel();
                ddv.visitLineNumber(212,L71);
                ddv.visitEndLocal(3,L71);
                DexLabel L72=new DexLabel();
                ddv.visitLineNumber(214,L72);
                DexLabel L73=new DexLabel();
                ddv.visitLineNumber(215,L73);
                DexLabel L74=new DexLabel();
                ddv.visitLineNumber(216,L74);
                DexLabel L75=new DexLabel();
                ddv.visitRestartLocal(3,L75);
                DexLabel L76=new DexLabel();
                ddv.visitLineNumber(224,L76);
                ddv.visitEndLocal(2,L76);
                DexLabel L77=new DexLabel();
                ddv.visitRestartLocal(2,L77);
                DexLabel L78=new DexLabel();
                ddv.visitLineNumber(225,L78);
                DexLabel L79=new DexLabel();
                ddv.visitLineNumber(226,L79);
                ddv.visitEndLocal(3,L79);
                DexLabel L80=new DexLabel();
                ddv.visitLineNumber(227,L80);
                DexLabel L81=new DexLabel();
                ddv.visitLineNumber(228,L81);
                DexLabel L82=new DexLabel();
                ddv.visitLineNumber(229,L82);
                DexLabel L83=new DexLabel();
                ddv.visitLineNumber(232,L83);
                DexLabel L84=new DexLabel();
                ddv.visitLineNumber(233,L84);
                DexLabel L85=new DexLabel();
                ddv.visitLineNumber(234,L85);
                DexLabel L86=new DexLabel();
                ddv.visitLineNumber(236,L86);
                DexLabel L87=new DexLabel();
                ddv.visitLineNumber(241,L87);
                ddv.visitEndLocal(2,L87);
                ddv.visitRestartLocal(3,L87);
                DexLabel L88=new DexLabel();
                ddv.visitLineNumber(242,L88);
                ddv.visitRestartLocal(2,L88);
                DexLabel L89=new DexLabel();
                ddv.visitLineNumber(247,L89);
                ddv.visitEndLocal(2,L89);
                DexLabel L90=new DexLabel();
                ddv.visitLineNumber(248,L90);
                DexLabel L91=new DexLabel();
                ddv.visitLineNumber(249,L91);
                ddv.visitRestartLocal(2,L91);
                DexLabel L92=new DexLabel();
                ddv.visitLineNumber(254,L92);
                ddv.visitEndLocal(2,L92);
                DexLabel L93=new DexLabel();
                ddv.visitLineNumber(255,L93);
                DexLabel L94=new DexLabel();
                ddv.visitLineNumber(256,L94);
                DexLabel L95=new DexLabel();
                ddv.visitLineNumber(257,L95);
                ddv.visitRestartLocal(2,L95);
                DexLabel L96=new DexLabel();
                ddv.visitLineNumber(262,L96);
                ddv.visitEndLocal(2,L96);
                DexLabel L97=new DexLabel();
                ddv.visitLineNumber(263,L97);
                DexLabel L98=new DexLabel();
                ddv.visitLineNumber(264,L98);
                DexLabel L99=new DexLabel();
                ddv.visitLineNumber(273,L99);
                ddv.visitEndLocal(3,L99);
                ddv.visitRestartLocal(2,L99);
                DexLabel L100=new DexLabel();
                ddv.visitLineNumber(301,L100);
                ddv.visitRestartLocal(3,L100);
                DexLabel L101=new DexLabel();
                ddv.visitLineNumber(278,L101);
                ddv.visitEndLocal(3,L101);
                DexLabel L102=new DexLabel();
                ddv.visitLineNumber(279,L102);
                DexLabel L103=new DexLabel();
                ddv.visitLineNumber(280,L103);
                DexLabel L104=new DexLabel();
                ddv.visitLineNumber(281,L104);
                DexLabel L105=new DexLabel();
                ddv.visitLineNumber(282,L105);
                DexLabel L106=new DexLabel();
                ddv.visitLineNumber(286,L106);
                DexLabel L107=new DexLabel();
                ddv.visitLineNumber(291,L107);
                DexLabel L108=new DexLabel();
                ddv.visitLineNumber(292,L108);
                DexLabel L109=new DexLabel();
                ddv.visitLineNumber(293,L109);
                DexLabel L110=new DexLabel();
                ddv.visitLineNumber(297,L110);
                DexLabel L111=new DexLabel();
                ddv.visitLineNumber(306,L111);
                DexLabel L112=new DexLabel();
                ddv.visitLineNumber(319,L112);
                ddv.visitRestartLocal(3,L112);
                DexLabel L113=new DexLabel();
                ddv.visitLineNumber(310,L113);
                ddv.visitEndLocal(3,L113);
                DexLabel L114=new DexLabel();
                ddv.visitLineNumber(314,L114);
                DexLabel L115=new DexLabel();
                ddv.visitLineNumber(324,L115);
                DexLabel L116=new DexLabel();
                ddv.visitLineNumber(326,L116);
                DexLabel L117=new DexLabel();
                ddv.visitLineNumber(327,L117);
                DexLabel L118=new DexLabel();
                ddv.visitLineNumber(328,L118);
                DexLabel L119=new DexLabel();
                ddv.visitLineNumber(329,L119);
                DexLabel L120=new DexLabel();
                ddv.visitLineNumber(330,L120);
                DexLabel L121=new DexLabel();
                ddv.visitRestartLocal(3,L121);
                DexLabel L122=new DexLabel();
                ddv.visitLineNumber(337,L122);
                ddv.visitEndLocal(3,L122);
                DexLabel L123=new DexLabel();
                ddv.visitLineNumber(360,L123);
                ddv.visitRestartLocal(3,L123);
                DexLabel L124=new DexLabel();
                ddv.visitLineNumber(341,L124);
                ddv.visitEndLocal(3,L124);
                DexLabel L125=new DexLabel();
                ddv.visitLineNumber(342,L125);
                DexLabel L126=new DexLabel();
                ddv.visitLineNumber(343,L126);
                DexLabel L127=new DexLabel();
                ddv.visitLineNumber(347,L127);
                DexLabel L128=new DexLabel();
                ddv.visitLineNumber(348,L128);
                DexLabel L129=new DexLabel();
                ddv.visitLineNumber(349,L129);
                DexLabel L130=new DexLabel();
                ddv.visitLineNumber(350,L130);
                DexLabel L131=new DexLabel();
                ddv.visitLineNumber(354,L131);
                DexLabel L132=new DexLabel();
                ddv.visitLineNumber(355,L132);
                DexLabel L133=new DexLabel();
                ddv.visitLineNumber(356,L133);
                DexLabel L134=new DexLabel();
                ddv.visitLineNumber(365,L134);
                DexLabel L135=new DexLabel();
                ddv.visitLineNumber(380,L135);
                ddv.visitRestartLocal(3,L135);
                DexLabel L136=new DexLabel();
                ddv.visitLineNumber(369,L136);
                ddv.visitEndLocal(3,L136);
                DexLabel L137=new DexLabel();
                ddv.visitLineNumber(370,L137);
                DexLabel L138=new DexLabel();
                ddv.visitLineNumber(371,L138);
                DexLabel L139=new DexLabel();
                ddv.visitLineNumber(375,L139);
                DexLabel L140=new DexLabel();
                ddv.visitLineNumber(376,L140);
                DexLabel L141=new DexLabel();
                ddv.visitLineNumber(385,L141);
                DexLabel L142=new DexLabel();
                ddv.visitLineNumber(387,L142);
                DexLabel L143=new DexLabel();
                ddv.visitLineNumber(395,L143);
                DexLabel L144=new DexLabel();
                ddv.visitLineNumber(399,L144);
                ddv.visitEndLocal(0,L144);
                ddv.visitEndLocal(5,L144);
                ddv.visitEndLocal(2,L144);
                ddv.visitRestartLocal(3,L144);
                DexLabel L145=new DexLabel();
                ddv.visitEndLocal(3,L145);
                ddv.visitRestartLocal(0,L145);
                ddv.visitRestartLocal(2,L145);
                ddv.visitRestartLocal(5,L145);
                DexLabel L146=new DexLabel();
                ddv.visitRestartLocal(3,L146);
                DexLabel L147=new DexLabel();
                ddv.visitLineNumber(133,L147);
                DexLabel L148=new DexLabel();
                ddv.visitLineNumber(138,L148);
                DexLabel L149=new DexLabel();
                ddv.visitLineNumber(220,L149);
                DexLabel L150=new DexLabel();
                ddv.visitLineNumber(273,L150);
                DexLabel L151=new DexLabel();
                ddv.visitLineNumber(306,L151);
                DexLabel L152=new DexLabel();
                ddv.visitLineNumber(337,L152);
                DexLabel L153=new DexLabel();
                ddv.visitLineNumber(365,L153);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_16,11, Integer.valueOf(35)); // int: 0x00000023  float:0.000000
                code.visitConstStmt(CONST_16,10, Integer.valueOf(58)); // int: 0x0000003a  float:0.000000
                code.visitConstStmt(CONST_16,9, Integer.valueOf(47)); // int: 0x0000002f  float:0.000000
                code.visitLabel(L1);
                code.visitFieldStmt(IPUT_OBJECT,13,12,new Field("Lorg/mortbay/jetty/HttpURI;","_raw","[B"));
                code.visitLabel(L2);
                code.visitStmt2R(MOVE,2,14);
                code.visitLabel(L3);
                code.visitStmt3R(ADD_INT,1,14,15);
                code.visitLabel(L4);
                code.visitConstStmt(CONST_4,6, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L5);
                code.visitStmt2R(MOVE,4,14);
                code.visitLabel(L6);
                code.visitStmt3R(ADD_INT,7,14,15);
                code.visitFieldStmt(IPUT,7,12,new Field("Lorg/mortbay/jetty/HttpURI;","_end","I"));
                code.visitLabel(L7);
                code.visitFieldStmt(IPUT,14,12,new Field("Lorg/mortbay/jetty/HttpURI;","_scheme","I"));
                code.visitLabel(L8);
                code.visitFieldStmt(IPUT,14,12,new Field("Lorg/mortbay/jetty/HttpURI;","_authority","I"));
                code.visitLabel(L9);
                code.visitFieldStmt(IPUT,14,12,new Field("Lorg/mortbay/jetty/HttpURI;","_host","I"));
                code.visitLabel(L10);
                code.visitFieldStmt(IPUT,14,12,new Field("Lorg/mortbay/jetty/HttpURI;","_port","I"));
                code.visitLabel(L11);
                code.visitFieldStmt(IPUT,14,12,new Field("Lorg/mortbay/jetty/HttpURI;","_path","I"));
                code.visitLabel(L12);
                code.visitFieldStmt(IGET,7,12,new Field("Lorg/mortbay/jetty/HttpURI;","_end","I"));
                code.visitFieldStmt(IPUT,7,12,new Field("Lorg/mortbay/jetty/HttpURI;","_param","I"));
                code.visitLabel(L13);
                code.visitFieldStmt(IGET,7,12,new Field("Lorg/mortbay/jetty/HttpURI;","_end","I"));
                code.visitFieldStmt(IPUT,7,12,new Field("Lorg/mortbay/jetty/HttpURI;","_query","I"));
                code.visitLabel(L14);
                code.visitFieldStmt(IGET,7,12,new Field("Lorg/mortbay/jetty/HttpURI;","_end","I"));
                code.visitFieldStmt(IPUT,7,12,new Field("Lorg/mortbay/jetty/HttpURI;","_fragment","I"));
                DexLabel L154=new DexLabel();
                code.visitLabel(L154);
                code.visitStmt2R(MOVE,3,2);
                code.visitLabel(L15);
                code.visitJumpStmt(IF_GE,3,1,L144);
                code.visitLabel(L16);
                code.visitFieldStmt(IGET_OBJECT,7,12,new Field("Lorg/mortbay/jetty/HttpURI;","_raw","[B"));
                code.visitStmt3R(AGET_BYTE,7,7,3);
                code.visitStmt2R1N(AND_INT_LIT16,7,7,255);
                code.visitStmt2R(INT_TO_CHAR,0,7);
                code.visitLabel(L17);
                code.visitStmt2R1N(ADD_INT_LIT8,2,3,1);
                code.visitLabel(L18);
                code.visitStmt2R(MOVE,5,3);
                code.visitLabel(L19);
                code.visitSparseSwitchStmt(PACKED_SWITCH,6,0,new DexLabel[]{L22,L44,L58,L20,L99,L111,L115,L122,L134,L141,L143});
                code.visitLabel(L20);
                code.visitStmt2R(MOVE,3,2);
                code.visitLabel(L21);
                code.visitJumpStmt(GOTO,-1,-1,L15);
                code.visitLabel(L22);
                code.visitStmt2R(MOVE,4,5);
                code.visitLabel(L23);
                code.visitSparseSwitchStmt(SPARSE_SWITCH,0,new int[]{ 35,42,47,59,63},new DexLabel[]{L36,L40,L27,L29,L32});
                code.visitLabel(L24);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0},new Method("Ljava/lang/Character;","isLetterOrDigit",new String[]{ "C"},"Z"));
                code.visitStmt1R(MOVE_RESULT,7);
                code.visitJumpStmt(IF_EQZ,7,-1,L43);
                code.visitLabel(L25);
                code.visitConstStmt(CONST_4,6, Integer.valueOf(2)); // int: 0x00000002  float:0.000000
                code.visitStmt2R(MOVE,3,2);
                code.visitLabel(L26);
                code.visitJumpStmt(GOTO,-1,-1,L15);
                code.visitLabel(L27);
                code.visitConstStmt(CONST_4,6, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitStmt2R(MOVE,3,2);
                code.visitLabel(L28);
                code.visitJumpStmt(GOTO,-1,-1,L15);
                code.visitLabel(L29);
                code.visitFieldStmt(IPUT,5,12,new Field("Lorg/mortbay/jetty/HttpURI;","_param","I"));
                code.visitLabel(L30);
                code.visitConstStmt(CONST_16,6, Integer.valueOf(8)); // int: 0x00000008  float:0.000000
                code.visitStmt2R(MOVE,3,2);
                code.visitLabel(L31);
                code.visitJumpStmt(GOTO,-1,-1,L15);
                code.visitLabel(L32);
                code.visitFieldStmt(IPUT,5,12,new Field("Lorg/mortbay/jetty/HttpURI;","_param","I"));
                code.visitLabel(L33);
                code.visitFieldStmt(IPUT,5,12,new Field("Lorg/mortbay/jetty/HttpURI;","_query","I"));
                code.visitLabel(L34);
                code.visitConstStmt(CONST_16,6, Integer.valueOf(9)); // int: 0x00000009  float:0.000000
                code.visitStmt2R(MOVE,3,2);
                code.visitLabel(L35);
                code.visitJumpStmt(GOTO,-1,-1,L15);
                code.visitLabel(L36);
                code.visitFieldStmt(IPUT,5,12,new Field("Lorg/mortbay/jetty/HttpURI;","_param","I"));
                code.visitLabel(L37);
                code.visitFieldStmt(IPUT,5,12,new Field("Lorg/mortbay/jetty/HttpURI;","_query","I"));
                code.visitLabel(L38);
                code.visitFieldStmt(IPUT,5,12,new Field("Lorg/mortbay/jetty/HttpURI;","_fragment","I"));
                code.visitStmt2R(MOVE,3,2);
                code.visitLabel(L39);
                code.visitJumpStmt(GOTO,-1,-1,L15);
                code.visitLabel(L40);
                code.visitFieldStmt(IPUT,5,12,new Field("Lorg/mortbay/jetty/HttpURI;","_path","I"));
                code.visitLabel(L41);
                code.visitConstStmt(CONST_16,6, Integer.valueOf(10)); // int: 0x0000000a  float:0.000000
                code.visitStmt2R(MOVE,3,2);
                code.visitLabel(L42);
                code.visitJumpStmt(GOTO,-1,-1,L15);
                code.visitLabel(L43);
                code.visitTypeStmt(NEW_INSTANCE,7,-1,"Ljava/lang/IllegalArgumentException;");
                code.visitFieldStmt(IGET_OBJECT,8,12,new Field("Lorg/mortbay/jetty/HttpURI;","_raw","[B"));
                code.visitFieldStmt(SGET_OBJECT,9,-1,new Field("Lorg/mortbay/util/URIUtil;","__CHARSET","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 8,14,15,9},new Method("Lorg/mortbay/util/StringUtil;","toString",new String[]{ "[B","I","I","Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 7,8},new Method("Ljava/lang/IllegalArgumentException;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitStmt1R(THROW,7);
                code.visitLabel(L44);
                code.visitFieldStmt(IGET_BOOLEAN,7,12,new Field("Lorg/mortbay/jetty/HttpURI;","_partial","Z"));
                DexLabel L155=new DexLabel();
                code.visitJumpStmt(IF_NEZ,7,-1,L155);
                code.visitFieldStmt(IGET,7,12,new Field("Lorg/mortbay/jetty/HttpURI;","_scheme","I"));
                code.visitFieldStmt(IGET,8,12,new Field("Lorg/mortbay/jetty/HttpURI;","_authority","I"));
                code.visitJumpStmt(IF_EQ,7,8,L50);
                code.visitLabel(L155);
                code.visitJumpStmt(IF_NE,0,9,L50);
                code.visitLabel(L45);
                code.visitFieldStmt(IPUT,2,12,new Field("Lorg/mortbay/jetty/HttpURI;","_host","I"));
                code.visitLabel(L46);
                code.visitFieldStmt(IGET,7,12,new Field("Lorg/mortbay/jetty/HttpURI;","_end","I"));
                code.visitFieldStmt(IPUT,7,12,new Field("Lorg/mortbay/jetty/HttpURI;","_port","I"));
                code.visitLabel(L47);
                code.visitFieldStmt(IGET,7,12,new Field("Lorg/mortbay/jetty/HttpURI;","_end","I"));
                code.visitFieldStmt(IPUT,7,12,new Field("Lorg/mortbay/jetty/HttpURI;","_path","I"));
                code.visitLabel(L48);
                code.visitConstStmt(CONST_4,6, Integer.valueOf(4)); // int: 0x00000004  float:0.000000
                code.visitStmt2R(MOVE,3,2);
                code.visitLabel(L49);
                code.visitJumpStmt(GOTO,-1,-1,L15);
                code.visitLabel(L50);
                code.visitConstStmt(CONST_16,7, Integer.valueOf(59)); // int: 0x0000003b  float:0.000000
                code.visitJumpStmt(IF_EQ,0,7,L51);
                code.visitConstStmt(CONST_16,7, Integer.valueOf(63)); // int: 0x0000003f  float:0.000000
                code.visitJumpStmt(IF_EQ,0,7,L51);
                code.visitJumpStmt(IF_NE,0,11,L54);
                code.visitLabel(L51);
                code.visitStmt2R1N(ADD_INT_LIT8,2,2,-1);
                code.visitLabel(L52);
                code.visitConstStmt(CONST_4,6, Integer.valueOf(7)); // int: 0x00000007  float:0.000000
                code.visitStmt2R(MOVE,3,2);
                code.visitLabel(L53);
                code.visitJumpStmt(GOTO,-1,-1,L15);
                code.visitLabel(L54);
                code.visitFieldStmt(IPUT,4,12,new Field("Lorg/mortbay/jetty/HttpURI;","_host","I"));
                code.visitLabel(L55);
                code.visitFieldStmt(IPUT,4,12,new Field("Lorg/mortbay/jetty/HttpURI;","_port","I"));
                code.visitLabel(L56);
                code.visitConstStmt(CONST_4,6, Integer.valueOf(7)); // int: 0x00000007  float:0.000000
                code.visitStmt2R(MOVE,3,2);
                code.visitLabel(L57);
                code.visitJumpStmt(GOTO,-1,-1,L15);
                code.visitLabel(L58);
                code.visitConstStmt(CONST_4,7, Integer.valueOf(6)); // int: 0x00000006  float:0.000000
                code.visitJumpStmt(IF_LE,15,7,L145);
                code.visitConstStmt(CONST_16,7, Integer.valueOf(116)); // int: 0x00000074  float:0.000000
                code.visitJumpStmt(IF_NE,0,7,L145);
                code.visitLabel(L59);
                code.visitFieldStmt(IGET_OBJECT,7,12,new Field("Lorg/mortbay/jetty/HttpURI;","_raw","[B"));
                code.visitStmt2R1N(ADD_INT_LIT8,8,14,3);
                code.visitStmt3R(AGET_BYTE,7,7,8);
                code.visitJumpStmt(IF_NE,7,10,L66);
                code.visitLabel(L60);
                code.visitStmt2R1N(ADD_INT_LIT8,5,14,3);
                code.visitLabel(L61);
                code.visitStmt2R1N(ADD_INT_LIT8,2,14,4);
                code.visitLabel(L62);
                code.visitConstStmt(CONST_16,0, Integer.valueOf(58)); // int: 0x0000003a  float:0.000000
                code.visitStmt2R(MOVE,3,2);
                code.visitLabel(L63);
                code.visitSparseSwitchStmt(SPARSE_SWITCH,0,new int[]{ 35,47,58,59,63},new DexLabel[]{L96,L87,L76,L89,L92});
                DexLabel L156=new DexLabel();
                code.visitLabel(L156);
                code.visitStmt2R(MOVE,2,3);
                code.visitLabel(L64);
                code.visitStmt2R(MOVE,3,2);
                code.visitLabel(L65);
                code.visitJumpStmt(GOTO_16,-1,-1,L15);
                code.visitLabel(L66);
                code.visitFieldStmt(IGET_OBJECT,7,12,new Field("Lorg/mortbay/jetty/HttpURI;","_raw","[B"));
                code.visitStmt2R1N(ADD_INT_LIT8,8,14,4);
                code.visitStmt3R(AGET_BYTE,7,7,8);
                code.visitJumpStmt(IF_NE,7,10,L71);
                code.visitLabel(L67);
                code.visitStmt2R1N(ADD_INT_LIT8,5,14,4);
                code.visitLabel(L68);
                code.visitStmt2R1N(ADD_INT_LIT8,2,14,5);
                code.visitLabel(L69);
                code.visitConstStmt(CONST_16,0, Integer.valueOf(58)); // int: 0x0000003a  float:0.000000
                code.visitStmt2R(MOVE,3,2);
                code.visitLabel(L70);
                code.visitJumpStmt(GOTO,-1,-1,L63);
                code.visitLabel(L71);
                code.visitFieldStmt(IGET_OBJECT,7,12,new Field("Lorg/mortbay/jetty/HttpURI;","_raw","[B"));
                code.visitStmt2R1N(ADD_INT_LIT8,8,14,5);
                code.visitStmt3R(AGET_BYTE,7,7,8);
                code.visitJumpStmt(IF_NE,7,10,L145);
                code.visitLabel(L72);
                code.visitStmt2R1N(ADD_INT_LIT8,5,14,5);
                code.visitLabel(L73);
                code.visitStmt2R1N(ADD_INT_LIT8,2,14,6);
                code.visitLabel(L74);
                code.visitConstStmt(CONST_16,0, Integer.valueOf(58)); // int: 0x0000003a  float:0.000000
                code.visitStmt2R(MOVE,3,2);
                code.visitLabel(L75);
                code.visitJumpStmt(GOTO,-1,-1,L63);
                code.visitLabel(L76);
                code.visitStmt2R1N(ADD_INT_LIT8,2,3,1);
                code.visitLabel(L77);
                code.visitStmt2R(MOVE,4,3);
                code.visitLabel(L78);
                code.visitFieldStmt(IPUT,4,12,new Field("Lorg/mortbay/jetty/HttpURI;","_authority","I"));
                code.visitLabel(L79);
                code.visitFieldStmt(IPUT,4,12,new Field("Lorg/mortbay/jetty/HttpURI;","_path","I"));
                code.visitLabel(L80);
                code.visitFieldStmt(IGET_OBJECT,7,12,new Field("Lorg/mortbay/jetty/HttpURI;","_raw","[B"));
                code.visitStmt3R(AGET_BYTE,7,7,2);
                code.visitStmt2R1N(AND_INT_LIT16,7,7,255);
                code.visitStmt2R(INT_TO_CHAR,0,7);
                code.visitLabel(L81);
                code.visitJumpStmt(IF_NE,0,9,L83);
                code.visitLabel(L82);
                code.visitConstStmt(CONST_4,6, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L64);
                code.visitLabel(L83);
                code.visitFieldStmt(IPUT,4,12,new Field("Lorg/mortbay/jetty/HttpURI;","_host","I"));
                code.visitLabel(L84);
                code.visitFieldStmt(IPUT,4,12,new Field("Lorg/mortbay/jetty/HttpURI;","_port","I"));
                code.visitLabel(L85);
                code.visitConstStmt(CONST_4,6, Integer.valueOf(7)); // int: 0x00000007  float:0.000000
                code.visitLabel(L86);
                code.visitJumpStmt(GOTO,-1,-1,L64);
                code.visitLabel(L87);
                code.visitConstStmt(CONST_4,6, Integer.valueOf(7)); // int: 0x00000007  float:0.000000
                code.visitStmt2R(MOVE,2,3);
                code.visitLabel(L88);
                code.visitJumpStmt(GOTO,-1,-1,L64);
                code.visitLabel(L89);
                code.visitFieldStmt(IPUT,5,12,new Field("Lorg/mortbay/jetty/HttpURI;","_param","I"));
                code.visitLabel(L90);
                code.visitConstStmt(CONST_16,6, Integer.valueOf(8)); // int: 0x00000008  float:0.000000
                code.visitStmt2R(MOVE,2,3);
                code.visitLabel(L91);
                code.visitJumpStmt(GOTO,-1,-1,L64);
                code.visitLabel(L92);
                code.visitFieldStmt(IPUT,5,12,new Field("Lorg/mortbay/jetty/HttpURI;","_param","I"));
                code.visitLabel(L93);
                code.visitFieldStmt(IPUT,5,12,new Field("Lorg/mortbay/jetty/HttpURI;","_query","I"));
                code.visitLabel(L94);
                code.visitConstStmt(CONST_16,6, Integer.valueOf(9)); // int: 0x00000009  float:0.000000
                code.visitStmt2R(MOVE,2,3);
                code.visitLabel(L95);
                code.visitJumpStmt(GOTO,-1,-1,L64);
                code.visitLabel(L96);
                code.visitFieldStmt(IPUT,5,12,new Field("Lorg/mortbay/jetty/HttpURI;","_param","I"));
                code.visitLabel(L97);
                code.visitFieldStmt(IPUT,5,12,new Field("Lorg/mortbay/jetty/HttpURI;","_query","I"));
                code.visitLabel(L98);
                code.visitFieldStmt(IPUT,5,12,new Field("Lorg/mortbay/jetty/HttpURI;","_fragment","I"));
                code.visitJumpStmt(GOTO,-1,-1,L156);
                code.visitLabel(L99);
                code.visitSparseSwitchStmt(SPARSE_SWITCH,0,new int[]{ 47,58,64,91},new DexLabel[]{L101,L107,L106,L110});
                DexLabel L157=new DexLabel();
                code.visitLabel(L157);
                code.visitStmt2R(MOVE,3,2);
                code.visitLabel(L100);
                code.visitJumpStmt(GOTO_16,-1,-1,L15);
                code.visitLabel(L101);
                code.visitStmt2R(MOVE,4,5);
                code.visitLabel(L102);
                code.visitFieldStmt(IPUT,4,12,new Field("Lorg/mortbay/jetty/HttpURI;","_path","I"));
                code.visitLabel(L103);
                code.visitFieldStmt(IGET,7,12,new Field("Lorg/mortbay/jetty/HttpURI;","_path","I"));
                code.visitFieldStmt(IPUT,7,12,new Field("Lorg/mortbay/jetty/HttpURI;","_port","I"));
                code.visitLabel(L104);
                code.visitConstStmt(CONST_4,6, Integer.valueOf(7)); // int: 0x00000007  float:0.000000
                code.visitLabel(L105);
                code.visitJumpStmt(GOTO,-1,-1,L157);
                code.visitLabel(L106);
                code.visitFieldStmt(IPUT,2,12,new Field("Lorg/mortbay/jetty/HttpURI;","_host","I"));
                code.visitJumpStmt(GOTO,-1,-1,L157);
                code.visitLabel(L107);
                code.visitFieldStmt(IPUT,5,12,new Field("Lorg/mortbay/jetty/HttpURI;","_port","I"));
                code.visitLabel(L108);
                code.visitConstStmt(CONST_4,6, Integer.valueOf(6)); // int: 0x00000006  float:0.000000
                code.visitLabel(L109);
                code.visitJumpStmt(GOTO,-1,-1,L157);
                code.visitLabel(L110);
                code.visitConstStmt(CONST_4,6, Integer.valueOf(5)); // int: 0x00000005  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L157);
                code.visitLabel(L111);
                code.visitSparseSwitchStmt(SPARSE_SWITCH,0,new int[]{ 47,93},new DexLabel[]{L113,L114});
                DexLabel L158=new DexLabel();
                code.visitLabel(L158);
                code.visitStmt2R(MOVE,3,2);
                code.visitLabel(L112);
                code.visitJumpStmt(GOTO_16,-1,-1,L15);
                code.visitLabel(L113);
                code.visitTypeStmt(NEW_INSTANCE,7,-1,"Ljava/lang/IllegalArgumentException;");
                code.visitTypeStmt(NEW_INSTANCE,8,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 8},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,9,"No closing \']\' for ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8,9},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitFieldStmt(IGET_OBJECT,9,12,new Field("Lorg/mortbay/jetty/HttpURI;","_raw","[B"));
                code.visitFieldStmt(SGET_OBJECT,10,-1,new Field("Lorg/mortbay/util/URIUtil;","__CHARSET","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 9,14,15,10},new Method("Lorg/mortbay/util/StringUtil;","toString",new String[]{ "[B","I","I","Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,9);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8,9},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 7,8},new Method("Ljava/lang/IllegalArgumentException;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitStmt1R(THROW,7);
                code.visitLabel(L114);
                code.visitConstStmt(CONST_4,6, Integer.valueOf(4)); // int: 0x00000004  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L158);
                code.visitLabel(L115);
                code.visitJumpStmt(IF_NE,0,9,L154);
                code.visitLabel(L116);
                code.visitStmt2R(MOVE,4,5);
                code.visitLabel(L117);
                code.visitFieldStmt(IPUT,4,12,new Field("Lorg/mortbay/jetty/HttpURI;","_path","I"));
                code.visitLabel(L118);
                code.visitFieldStmt(IGET,7,12,new Field("Lorg/mortbay/jetty/HttpURI;","_port","I"));
                code.visitFieldStmt(IGET,8,12,new Field("Lorg/mortbay/jetty/HttpURI;","_authority","I"));
                code.visitJumpStmt(IF_GT,7,8,L120);
                code.visitLabel(L119);
                code.visitFieldStmt(IGET,7,12,new Field("Lorg/mortbay/jetty/HttpURI;","_path","I"));
                code.visitFieldStmt(IPUT,7,12,new Field("Lorg/mortbay/jetty/HttpURI;","_port","I"));
                code.visitLabel(L120);
                code.visitConstStmt(CONST_4,6, Integer.valueOf(7)); // int: 0x00000007  float:0.000000
                code.visitStmt2R(MOVE,3,2);
                code.visitLabel(L121);
                code.visitJumpStmt(GOTO_16,-1,-1,L15);
                code.visitLabel(L122);
                code.visitSparseSwitchStmt(SPARSE_SWITCH,0,new int[]{ 35,59,63},new DexLabel[]{L131,L124,L127});
                DexLabel L159=new DexLabel();
                code.visitLabel(L159);
                code.visitStmt2R(MOVE,3,2);
                code.visitLabel(L123);
                code.visitJumpStmt(GOTO_16,-1,-1,L15);
                code.visitLabel(L124);
                code.visitFieldStmt(IPUT,5,12,new Field("Lorg/mortbay/jetty/HttpURI;","_param","I"));
                code.visitLabel(L125);
                code.visitConstStmt(CONST_16,6, Integer.valueOf(8)); // int: 0x00000008  float:0.000000
                code.visitLabel(L126);
                code.visitJumpStmt(GOTO,-1,-1,L159);
                code.visitLabel(L127);
                code.visitFieldStmt(IPUT,5,12,new Field("Lorg/mortbay/jetty/HttpURI;","_param","I"));
                code.visitLabel(L128);
                code.visitFieldStmt(IPUT,5,12,new Field("Lorg/mortbay/jetty/HttpURI;","_query","I"));
                code.visitLabel(L129);
                code.visitConstStmt(CONST_16,6, Integer.valueOf(9)); // int: 0x00000009  float:0.000000
                code.visitLabel(L130);
                code.visitJumpStmt(GOTO,-1,-1,L159);
                code.visitLabel(L131);
                code.visitFieldStmt(IPUT,5,12,new Field("Lorg/mortbay/jetty/HttpURI;","_param","I"));
                code.visitLabel(L132);
                code.visitFieldStmt(IPUT,5,12,new Field("Lorg/mortbay/jetty/HttpURI;","_query","I"));
                code.visitLabel(L133);
                code.visitFieldStmt(IPUT,5,12,new Field("Lorg/mortbay/jetty/HttpURI;","_fragment","I"));
                code.visitJumpStmt(GOTO_16,-1,-1,L20);
                code.visitLabel(L134);
                code.visitSparseSwitchStmt(SPARSE_SWITCH,0,new int[]{ 35,63},new DexLabel[]{L139,L136});
                DexLabel L160=new DexLabel();
                code.visitLabel(L160);
                code.visitStmt2R(MOVE,3,2);
                code.visitLabel(L135);
                code.visitJumpStmt(GOTO_16,-1,-1,L15);
                code.visitLabel(L136);
                code.visitFieldStmt(IPUT,5,12,new Field("Lorg/mortbay/jetty/HttpURI;","_query","I"));
                code.visitLabel(L137);
                code.visitConstStmt(CONST_16,6, Integer.valueOf(9)); // int: 0x00000009  float:0.000000
                code.visitLabel(L138);
                code.visitJumpStmt(GOTO,-1,-1,L160);
                code.visitLabel(L139);
                code.visitFieldStmt(IPUT,5,12,new Field("Lorg/mortbay/jetty/HttpURI;","_query","I"));
                code.visitLabel(L140);
                code.visitFieldStmt(IPUT,5,12,new Field("Lorg/mortbay/jetty/HttpURI;","_fragment","I"));
                code.visitJumpStmt(GOTO_16,-1,-1,L20);
                code.visitLabel(L141);
                code.visitJumpStmt(IF_NE,0,11,L154);
                code.visitLabel(L142);
                code.visitFieldStmt(IPUT,5,12,new Field("Lorg/mortbay/jetty/HttpURI;","_fragment","I"));
                code.visitJumpStmt(GOTO_16,-1,-1,L20);
                code.visitLabel(L143);
                code.visitTypeStmt(NEW_INSTANCE,7,-1,"Ljava/lang/IllegalArgumentException;");
                code.visitConstStmt(CONST_STRING,8,"only \'*\'");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 7,8},new Method("Ljava/lang/IllegalArgumentException;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitStmt1R(THROW,7);
                code.visitLabel(L144);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L145);
                code.visitStmt2R(MOVE,3,2);
                code.visitLabel(L146);
                code.visitJumpStmt(GOTO_16,-1,-1,L63);
                code.visitLabel(L147);
                code.visitLabel(L148);
                code.visitLabel(L149);
                code.visitLabel(L150);
                code.visitLabel(L151);
                code.visitLabel(L152);
                code.visitLabel(L153);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m006_toUtf8String(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PRIVATE, new Method("Lorg/mortbay/jetty/HttpURI;","toUtf8String",new String[]{ "I","I"},"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"offset");
                ddv.visitParameterName(1,"length");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(403,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(404,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(405,L2);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/jetty/HttpURI;","_utf8b","Lorg/mortbay/util/Utf8StringBuffer;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/util/Utf8StringBuffer;","reset",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/jetty/HttpURI;","_utf8b","Lorg/mortbay/util/Utf8StringBuffer;"));
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/jetty/HttpURI;","_raw","[B"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1,3,4},new Method("Lorg/mortbay/util/Utf8StringBuffer;","append",new String[]{ "[B","I","I"},"V"));
                code.visitLabel(L2);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/jetty/HttpURI;","_utf8b","Lorg/mortbay/util/Utf8StringBuffer;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/util/Utf8StringBuffer;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m007_clear(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/HttpURI;","clear",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(569,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(570,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(571,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(572,L3);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT,0,1,new Field("Lorg/mortbay/jetty/HttpURI;","_end","I"));
                code.visitFieldStmt(IPUT,0,1,new Field("Lorg/mortbay/jetty/HttpURI;","_fragment","I"));
                code.visitFieldStmt(IPUT,0,1,new Field("Lorg/mortbay/jetty/HttpURI;","_query","I"));
                code.visitFieldStmt(IPUT,0,1,new Field("Lorg/mortbay/jetty/HttpURI;","_param","I"));
                code.visitFieldStmt(IPUT,0,1,new Field("Lorg/mortbay/jetty/HttpURI;","_path","I"));
                code.visitFieldStmt(IPUT,0,1,new Field("Lorg/mortbay/jetty/HttpURI;","_port","I"));
                code.visitFieldStmt(IPUT,0,1,new Field("Lorg/mortbay/jetty/HttpURI;","_host","I"));
                code.visitFieldStmt(IPUT,0,1,new Field("Lorg/mortbay/jetty/HttpURI;","_authority","I"));
                code.visitFieldStmt(IPUT,0,1,new Field("Lorg/mortbay/jetty/HttpURI;","_scheme","I"));
                code.visitLabel(L1);
                code.visitFieldStmt(SGET_OBJECT,0,-1,new Field("Lorg/mortbay/jetty/HttpURI;","__empty","[B"));
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/jetty/HttpURI;","_raw","[B"));
                code.visitLabel(L2);
                code.visitConstStmt(CONST_STRING,0,"");
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/jetty/HttpURI;","_rawString","Ljava/lang/String;"));
                code.visitLabel(L3);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m008_decodeQueryTo(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/HttpURI;","decodeQueryTo",new String[]{ "Lorg/mortbay/util/MultiMap;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(6);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"parameters");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(549,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(553,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(551,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(552,L3);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET,0,4,new Field("Lorg/mortbay/jetty/HttpURI;","_query","I"));
                code.visitFieldStmt(IGET,1,4,new Field("Lorg/mortbay/jetty/HttpURI;","_fragment","I"));
                code.visitJumpStmt(IF_NE,0,1,L2);
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L2);
                code.visitFieldStmt(IGET_OBJECT,0,4,new Field("Lorg/mortbay/jetty/HttpURI;","_utf8b","Lorg/mortbay/util/Utf8StringBuffer;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/util/Utf8StringBuffer;","reset",new String[]{ },"V"));
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,0,4,new Field("Lorg/mortbay/jetty/HttpURI;","_raw","[B"));
                code.visitFieldStmt(IGET,1,4,new Field("Lorg/mortbay/jetty/HttpURI;","_query","I"));
                code.visitStmt2R1N(ADD_INT_LIT8,1,1,1);
                code.visitFieldStmt(IGET,2,4,new Field("Lorg/mortbay/jetty/HttpURI;","_fragment","I"));
                code.visitFieldStmt(IGET,3,4,new Field("Lorg/mortbay/jetty/HttpURI;","_query","I"));
                code.visitStmt2R(SUB_INT_2ADDR,2,3);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitStmt2R(SUB_INT_2ADDR,2,3);
                code.visitFieldStmt(IGET_OBJECT,3,4,new Field("Lorg/mortbay/jetty/HttpURI;","_utf8b","Lorg/mortbay/util/Utf8StringBuffer;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0,1,2,5,3},new Method("Lorg/mortbay/util/UrlEncoded;","decodeUtf8To",new String[]{ "[B","I","I","Lorg/mortbay/util/MultiMap;","Lorg/mortbay/util/Utf8StringBuffer;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L1);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m009_decodeQueryTo(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/HttpURI;","decodeQueryTo",new String[]{ "Lorg/mortbay/util/MultiMap;","Ljava/lang/String;"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/UnsupportedEncodingException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(8);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"parameters");
                ddv.visitParameterName(1,"encoding");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(558,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(565,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(561,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(562,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(564,L5);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,4, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitLabel(L1);
                code.visitFieldStmt(IGET,0,5,new Field("Lorg/mortbay/jetty/HttpURI;","_query","I"));
                code.visitFieldStmt(IGET,1,5,new Field("Lorg/mortbay/jetty/HttpURI;","_fragment","I"));
                code.visitJumpStmt(IF_NE,0,1,L3);
                code.visitLabel(L2);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L3);
                code.visitJumpStmt(IF_EQZ,7,-1,L4);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 7},new Method("Lorg/mortbay/util/StringUtil;","isUTF8",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_EQZ,0,-1,L5);
                code.visitLabel(L4);
                code.visitFieldStmt(IGET_OBJECT,0,5,new Field("Lorg/mortbay/jetty/HttpURI;","_raw","[B"));
                code.visitFieldStmt(IGET,1,5,new Field("Lorg/mortbay/jetty/HttpURI;","_query","I"));
                code.visitStmt2R1N(ADD_INT_LIT8,1,1,1);
                code.visitFieldStmt(IGET,2,5,new Field("Lorg/mortbay/jetty/HttpURI;","_fragment","I"));
                code.visitFieldStmt(IGET,3,5,new Field("Lorg/mortbay/jetty/HttpURI;","_query","I"));
                code.visitStmt2R(SUB_INT_2ADDR,2,3);
                code.visitStmt2R(SUB_INT_2ADDR,2,4);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0,1,2,6},new Method("Lorg/mortbay/util/UrlEncoded;","decodeUtf8To",new String[]{ "[B","I","I","Lorg/mortbay/util/MultiMap;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitLabel(L5);
                code.visitFieldStmt(IGET,0,5,new Field("Lorg/mortbay/jetty/HttpURI;","_query","I"));
                code.visitStmt2R1N(ADD_INT_LIT8,0,0,1);
                code.visitFieldStmt(IGET,1,5,new Field("Lorg/mortbay/jetty/HttpURI;","_fragment","I"));
                code.visitFieldStmt(IGET,2,5,new Field("Lorg/mortbay/jetty/HttpURI;","_query","I"));
                code.visitStmt2R(SUB_INT_2ADDR,1,2);
                code.visitStmt2R(SUB_INT_2ADDR,1,4);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 5,0,1},new Method("Lorg/mortbay/jetty/HttpURI;","toUtf8String",new String[]{ "I","I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0,6,7},new Method("Lorg/mortbay/util/UrlEncoded;","decodeTo",new String[]{ "Ljava/lang/String;","Lorg/mortbay/util/MultiMap;","Ljava/lang/String;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m010_getAuthority(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/HttpURI;","getAuthority",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(432,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(433,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(434,L2);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET,0,3,new Field("Lorg/mortbay/jetty/HttpURI;","_authority","I"));
                code.visitFieldStmt(IGET,1,3,new Field("Lorg/mortbay/jetty/HttpURI;","_path","I"));
                DexLabel L3=new DexLabel();
                code.visitJumpStmt(IF_NE,0,1,L3);
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L2);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitLabel(L3);
                code.visitFieldStmt(IGET,0,3,new Field("Lorg/mortbay/jetty/HttpURI;","_authority","I"));
                code.visitFieldStmt(IGET,1,3,new Field("Lorg/mortbay/jetty/HttpURI;","_path","I"));
                code.visitFieldStmt(IGET,2,3,new Field("Lorg/mortbay/jetty/HttpURI;","_authority","I"));
                code.visitStmt2R(SUB_INT_2ADDR,1,2);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 3,0,1},new Method("Lorg/mortbay/jetty/HttpURI;","toUtf8String",new String[]{ "I","I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m011_getCompletePath(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/HttpURI;","getCompletePath",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(509,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(510,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(511,L2);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET,0,3,new Field("Lorg/mortbay/jetty/HttpURI;","_path","I"));
                code.visitFieldStmt(IGET,1,3,new Field("Lorg/mortbay/jetty/HttpURI;","_end","I"));
                DexLabel L3=new DexLabel();
                code.visitJumpStmt(IF_NE,0,1,L3);
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L2);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitLabel(L3);
                code.visitFieldStmt(IGET,0,3,new Field("Lorg/mortbay/jetty/HttpURI;","_path","I"));
                code.visitFieldStmt(IGET,1,3,new Field("Lorg/mortbay/jetty/HttpURI;","_end","I"));
                code.visitFieldStmt(IGET,2,3,new Field("Lorg/mortbay/jetty/HttpURI;","_path","I"));
                code.visitStmt2R(SUB_INT_2ADDR,1,2);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 3,0,1},new Method("Lorg/mortbay/jetty/HttpURI;","toUtf8String",new String[]{ "I","I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m012_getDecodedPath(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/HttpURI;","getDecodedPath",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(12);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(460,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(461,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(497,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(463,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(464,L4);
                ddv.visitStartLocal(4,L4,"length","I",null);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(465,L5);
                ddv.visitStartLocal(1,L5,"bytes","[B",null);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(467,L6);
                ddv.visitStartLocal(5,L6,"n","I",null);
                DexLabel L7=new DexLabel();
                ddv.visitStartLocal(2,L7,"i","I",null);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(469,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(471,L9);
                ddv.visitStartLocal(0,L9,"b","B",null);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(473,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(474,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(482,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(484,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(485,L14);
                DexLabel L15=new DexLabel();
                ddv.visitStartLocal(3,L15,"j","I",null);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(486,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(485,L17);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(476,L18);
                ddv.visitEndLocal(3,L18);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(478,L19);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(467,L20);
                DexLabel L21=new DexLabel();
                ddv.visitLineNumber(489,L21);
                DexLabel L22=new DexLabel();
                ddv.visitStartLocal(6,L22,"n","I",null);
                DexLabel L23=new DexLabel();
                ddv.visitEndLocal(5,L23);
                DexLabel L24=new DexLabel();
                ddv.visitRestartLocal(5,L24);
                DexLabel L25=new DexLabel();
                ddv.visitLineNumber(492,L25);
                ddv.visitEndLocal(0,L25);
                ddv.visitEndLocal(6,L25);
                DexLabel L26=new DexLabel();
                ddv.visitLineNumber(493,L26);
                DexLabel L27=new DexLabel();
                ddv.visitLineNumber(495,L27);
                DexLabel L28=new DexLabel();
                ddv.visitLineNumber(496,L28);
                DexLabel L29=new DexLabel();
                ddv.visitLineNumber(497,L29);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET,7,11,new Field("Lorg/mortbay/jetty/HttpURI;","_path","I"));
                code.visitFieldStmt(IGET,8,11,new Field("Lorg/mortbay/jetty/HttpURI;","_param","I"));
                code.visitJumpStmt(IF_NE,7,8,L3);
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,7, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L2);
                code.visitStmt1R(RETURN_OBJECT,7);
                code.visitLabel(L3);
                code.visitFieldStmt(IGET,7,11,new Field("Lorg/mortbay/jetty/HttpURI;","_param","I"));
                code.visitFieldStmt(IGET,8,11,new Field("Lorg/mortbay/jetty/HttpURI;","_path","I"));
                code.visitStmt3R(SUB_INT,4,7,8);
                code.visitLabel(L4);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L5);
                code.visitConstStmt(CONST_4,5, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L6);
                code.visitFieldStmt(IGET,2,11,new Field("Lorg/mortbay/jetty/HttpURI;","_path","I"));
                code.visitLabel(L7);
                code.visitFieldStmt(IGET,7,11,new Field("Lorg/mortbay/jetty/HttpURI;","_param","I"));
                code.visitJumpStmt(IF_GE,2,7,L25);
                code.visitLabel(L8);
                code.visitFieldStmt(IGET_OBJECT,7,11,new Field("Lorg/mortbay/jetty/HttpURI;","_raw","[B"));
                code.visitStmt3R(AGET_BYTE,0,7,2);
                code.visitLabel(L9);
                code.visitConstStmt(CONST_16,7, Integer.valueOf(37)); // int: 0x00000025  float:0.000000
                code.visitJumpStmt(IF_NE,0,7,L18);
                code.visitStmt2R1N(ADD_INT_LIT8,7,2,2);
                code.visitFieldStmt(IGET,8,11,new Field("Lorg/mortbay/jetty/HttpURI;","_param","I"));
                code.visitJumpStmt(IF_GE,7,8,L18);
                code.visitLabel(L10);
                code.visitFieldStmt(IGET_OBJECT,7,11,new Field("Lorg/mortbay/jetty/HttpURI;","_raw","[B"));
                code.visitStmt2R1N(ADD_INT_LIT8,8,2,1);
                code.visitConstStmt(CONST_4,9, Integer.valueOf(2)); // int: 0x00000002  float:0.000000
                code.visitConstStmt(CONST_16,10, Integer.valueOf(16)); // int: 0x00000010  float:0.000000
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 7,8,9,10},new Method("Lorg/mortbay/util/TypeUtil;","parseInt",new String[]{ "[B","I","I","I"},"I"));
                code.visitStmt1R(MOVE_RESULT,7);
                code.visitStmt2R1N(AND_INT_LIT16,7,7,255);
                code.visitStmt2R(INT_TO_BYTE,0,7);
                code.visitLabel(L11);
                code.visitStmt2R1N(ADD_INT_LIT8,2,2,2);
                code.visitLabel(L12);
                code.visitJumpStmt(IF_NEZ,1,-1,L21);
                code.visitLabel(L13);
                code.visitTypeStmt(NEW_ARRAY,1,4,"[B");
                code.visitLabel(L14);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L15);
                code.visitJumpStmt(IF_GE,3,5,L21);
                code.visitLabel(L16);
                code.visitFieldStmt(IGET_OBJECT,7,11,new Field("Lorg/mortbay/jetty/HttpURI;","_raw","[B"));
                code.visitFieldStmt(IGET,8,11,new Field("Lorg/mortbay/jetty/HttpURI;","_path","I"));
                code.visitStmt2R(ADD_INT_2ADDR,8,3);
                code.visitStmt3R(AGET_BYTE,7,7,8);
                code.visitStmt3R(APUT_BYTE,7,1,3);
                code.visitLabel(L17);
                code.visitStmt2R1N(ADD_INT_LIT8,3,3,1);
                code.visitJumpStmt(GOTO,-1,-1,L15);
                code.visitLabel(L18);
                code.visitJumpStmt(IF_NEZ,1,-1,L12);
                code.visitLabel(L19);
                code.visitStmt2R1N(ADD_INT_LIT8,5,5,1);
                code.visitLabel(L20);
                code.visitStmt2R1N(ADD_INT_LIT8,2,2,1);
                code.visitJumpStmt(GOTO,-1,-1,L7);
                code.visitLabel(L21);
                code.visitStmt2R1N(ADD_INT_LIT8,6,5,1);
                code.visitLabel(L22);
                code.visitStmt3R(APUT_BYTE,0,1,5);
                code.visitLabel(L23);
                code.visitStmt2R(MOVE,5,6);
                code.visitLabel(L24);
                code.visitJumpStmt(GOTO,-1,-1,L20);
                code.visitLabel(L25);
                code.visitJumpStmt(IF_NEZ,1,-1,L27);
                code.visitLabel(L26);
                code.visitFieldStmt(IGET,7,11,new Field("Lorg/mortbay/jetty/HttpURI;","_path","I"));
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 11,7,4},new Method("Lorg/mortbay/jetty/HttpURI;","toUtf8String",new String[]{ "I","I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitLabel(L27);
                code.visitFieldStmt(IGET_OBJECT,7,11,new Field("Lorg/mortbay/jetty/HttpURI;","_utf8b","Lorg/mortbay/util/Utf8StringBuffer;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7},new Method("Lorg/mortbay/util/Utf8StringBuffer;","reset",new String[]{ },"V"));
                code.visitLabel(L28);
                code.visitFieldStmt(IGET_OBJECT,7,11,new Field("Lorg/mortbay/jetty/HttpURI;","_utf8b","Lorg/mortbay/util/Utf8StringBuffer;"));
                code.visitConstStmt(CONST_4,8, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7,1,8,5},new Method("Lorg/mortbay/util/Utf8StringBuffer;","append",new String[]{ "[B","I","I"},"V"));
                code.visitLabel(L29);
                code.visitFieldStmt(IGET_OBJECT,7,11,new Field("Lorg/mortbay/jetty/HttpURI;","_utf8b","Lorg/mortbay/util/Utf8StringBuffer;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7},new Method("Lorg/mortbay/util/Utf8StringBuffer;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m013_getFragment(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/HttpURI;","getFragment",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(542,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(543,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(544,L2);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET,0,3,new Field("Lorg/mortbay/jetty/HttpURI;","_fragment","I"));
                code.visitFieldStmt(IGET,1,3,new Field("Lorg/mortbay/jetty/HttpURI;","_end","I"));
                DexLabel L3=new DexLabel();
                code.visitJumpStmt(IF_NE,0,1,L3);
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L2);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitLabel(L3);
                code.visitFieldStmt(IGET,0,3,new Field("Lorg/mortbay/jetty/HttpURI;","_fragment","I"));
                code.visitStmt2R1N(ADD_INT_LIT8,0,0,1);
                code.visitFieldStmt(IGET,1,3,new Field("Lorg/mortbay/jetty/HttpURI;","_end","I"));
                code.visitFieldStmt(IGET,2,3,new Field("Lorg/mortbay/jetty/HttpURI;","_fragment","I"));
                code.visitStmt2R(SUB_INT_2ADDR,1,2);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitStmt2R(SUB_INT_2ADDR,1,2);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 3,0,1},new Method("Lorg/mortbay/jetty/HttpURI;","toUtf8String",new String[]{ "I","I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m014_getHost(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/HttpURI;","getHost",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(439,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(440,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(441,L2);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET,0,3,new Field("Lorg/mortbay/jetty/HttpURI;","_host","I"));
                code.visitFieldStmt(IGET,1,3,new Field("Lorg/mortbay/jetty/HttpURI;","_port","I"));
                DexLabel L3=new DexLabel();
                code.visitJumpStmt(IF_NE,0,1,L3);
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L2);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitLabel(L3);
                code.visitFieldStmt(IGET,0,3,new Field("Lorg/mortbay/jetty/HttpURI;","_host","I"));
                code.visitFieldStmt(IGET,1,3,new Field("Lorg/mortbay/jetty/HttpURI;","_port","I"));
                code.visitFieldStmt(IGET,2,3,new Field("Lorg/mortbay/jetty/HttpURI;","_host","I"));
                code.visitStmt2R(SUB_INT_2ADDR,1,2);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 3,0,1},new Method("Lorg/mortbay/jetty/HttpURI;","toUtf8String",new String[]{ "I","I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m015_getParam(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/HttpURI;","getParam",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(516,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(517,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(518,L2);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET,0,3,new Field("Lorg/mortbay/jetty/HttpURI;","_param","I"));
                code.visitFieldStmt(IGET,1,3,new Field("Lorg/mortbay/jetty/HttpURI;","_query","I"));
                DexLabel L3=new DexLabel();
                code.visitJumpStmt(IF_NE,0,1,L3);
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L2);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitLabel(L3);
                code.visitFieldStmt(IGET,0,3,new Field("Lorg/mortbay/jetty/HttpURI;","_param","I"));
                code.visitStmt2R1N(ADD_INT_LIT8,0,0,1);
                code.visitFieldStmt(IGET,1,3,new Field("Lorg/mortbay/jetty/HttpURI;","_query","I"));
                code.visitFieldStmt(IGET,2,3,new Field("Lorg/mortbay/jetty/HttpURI;","_param","I"));
                code.visitStmt2R(SUB_INT_2ADDR,1,2);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitStmt2R(SUB_INT_2ADDR,1,2);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 3,0,1},new Method("Lorg/mortbay/jetty/HttpURI;","toUtf8String",new String[]{ "I","I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m016_getPath(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/HttpURI;","getPath",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(453,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(454,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(455,L2);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET,0,3,new Field("Lorg/mortbay/jetty/HttpURI;","_path","I"));
                code.visitFieldStmt(IGET,1,3,new Field("Lorg/mortbay/jetty/HttpURI;","_param","I"));
                DexLabel L3=new DexLabel();
                code.visitJumpStmt(IF_NE,0,1,L3);
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L2);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitLabel(L3);
                code.visitFieldStmt(IGET,0,3,new Field("Lorg/mortbay/jetty/HttpURI;","_path","I"));
                code.visitFieldStmt(IGET,1,3,new Field("Lorg/mortbay/jetty/HttpURI;","_param","I"));
                code.visitFieldStmt(IGET,2,3,new Field("Lorg/mortbay/jetty/HttpURI;","_path","I"));
                code.visitStmt2R(SUB_INT_2ADDR,1,2);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 3,0,1},new Method("Lorg/mortbay/jetty/HttpURI;","toUtf8String",new String[]{ "I","I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m017_getPathAndParam(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/HttpURI;","getPathAndParam",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(502,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(503,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(504,L2);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET,0,3,new Field("Lorg/mortbay/jetty/HttpURI;","_path","I"));
                code.visitFieldStmt(IGET,1,3,new Field("Lorg/mortbay/jetty/HttpURI;","_query","I"));
                DexLabel L3=new DexLabel();
                code.visitJumpStmt(IF_NE,0,1,L3);
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L2);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitLabel(L3);
                code.visitFieldStmt(IGET,0,3,new Field("Lorg/mortbay/jetty/HttpURI;","_path","I"));
                code.visitFieldStmt(IGET,1,3,new Field("Lorg/mortbay/jetty/HttpURI;","_query","I"));
                code.visitFieldStmt(IGET,2,3,new Field("Lorg/mortbay/jetty/HttpURI;","_path","I"));
                code.visitStmt2R(SUB_INT_2ADDR,1,2);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 3,0,1},new Method("Lorg/mortbay/jetty/HttpURI;","toUtf8String",new String[]{ "I","I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m018_getPort(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/HttpURI;","getPort",new String[]{ },"I"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(446,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(447,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(448,L2);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET,0,4,new Field("Lorg/mortbay/jetty/HttpURI;","_port","I"));
                code.visitFieldStmt(IGET,1,4,new Field("Lorg/mortbay/jetty/HttpURI;","_path","I"));
                DexLabel L3=new DexLabel();
                code.visitJumpStmt(IF_NE,0,1,L3);
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(-1)); // int: 0xffffffff  float:NaN
                code.visitLabel(L2);
                code.visitStmt1R(RETURN,0);
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,0,4,new Field("Lorg/mortbay/jetty/HttpURI;","_raw","[B"));
                code.visitFieldStmt(IGET,1,4,new Field("Lorg/mortbay/jetty/HttpURI;","_port","I"));
                code.visitStmt2R1N(ADD_INT_LIT8,1,1,1);
                code.visitFieldStmt(IGET,2,4,new Field("Lorg/mortbay/jetty/HttpURI;","_path","I"));
                code.visitFieldStmt(IGET,3,4,new Field("Lorg/mortbay/jetty/HttpURI;","_port","I"));
                code.visitStmt2R(SUB_INT_2ADDR,2,3);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitStmt2R(SUB_INT_2ADDR,2,3);
                code.visitConstStmt(CONST_16,3, Integer.valueOf(10)); // int: 0x0000000a  float:0.000000
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0,1,2,3},new Method("Lorg/mortbay/util/TypeUtil;","parseInt",new String[]{ "[B","I","I","I"},"I"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m019_getQuery(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/HttpURI;","getQuery",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(523,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(524,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(525,L2);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET,0,3,new Field("Lorg/mortbay/jetty/HttpURI;","_query","I"));
                code.visitFieldStmt(IGET,1,3,new Field("Lorg/mortbay/jetty/HttpURI;","_fragment","I"));
                DexLabel L3=new DexLabel();
                code.visitJumpStmt(IF_NE,0,1,L3);
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L2);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitLabel(L3);
                code.visitFieldStmt(IGET,0,3,new Field("Lorg/mortbay/jetty/HttpURI;","_query","I"));
                code.visitStmt2R1N(ADD_INT_LIT8,0,0,1);
                code.visitFieldStmt(IGET,1,3,new Field("Lorg/mortbay/jetty/HttpURI;","_fragment","I"));
                code.visitFieldStmt(IGET,2,3,new Field("Lorg/mortbay/jetty/HttpURI;","_query","I"));
                code.visitStmt2R(SUB_INT_2ADDR,1,2);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitStmt2R(SUB_INT_2ADDR,1,2);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 3,0,1},new Method("Lorg/mortbay/jetty/HttpURI;","toUtf8String",new String[]{ "I","I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m020_getQuery(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/HttpURI;","getQuery",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(6);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"encoding");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(530,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(531,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(532,L2);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET,0,4,new Field("Lorg/mortbay/jetty/HttpURI;","_query","I"));
                code.visitFieldStmt(IGET,1,4,new Field("Lorg/mortbay/jetty/HttpURI;","_fragment","I"));
                DexLabel L3=new DexLabel();
                code.visitJumpStmt(IF_NE,0,1,L3);
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L2);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,0,4,new Field("Lorg/mortbay/jetty/HttpURI;","_raw","[B"));
                code.visitFieldStmt(IGET,1,4,new Field("Lorg/mortbay/jetty/HttpURI;","_query","I"));
                code.visitStmt2R1N(ADD_INT_LIT8,1,1,1);
                code.visitFieldStmt(IGET,2,4,new Field("Lorg/mortbay/jetty/HttpURI;","_fragment","I"));
                code.visitFieldStmt(IGET,3,4,new Field("Lorg/mortbay/jetty/HttpURI;","_query","I"));
                code.visitStmt2R(SUB_INT_2ADDR,2,3);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitStmt2R(SUB_INT_2ADDR,2,3);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0,1,2,5},new Method("Lorg/mortbay/util/StringUtil;","toString",new String[]{ "[B","I","I","Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m021_getScheme(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/HttpURI;","getScheme",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(7);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(410,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(411,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(427,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(412,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(413,L5);
                ddv.visitStartLocal(0,L5,"l","I",null);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(418,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(419,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(425,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(427,L9);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_16,5, Integer.valueOf(112)); // int: 0x00000070  float:0.000000
                code.visitConstStmt(CONST_16,4, Integer.valueOf(104)); // int: 0x00000068  float:0.000000
                code.visitConstStmt(CONST_16,3, Integer.valueOf(116)); // int: 0x00000074  float:0.000000
                code.visitLabel(L1);
                code.visitFieldStmt(IGET,1,6,new Field("Lorg/mortbay/jetty/HttpURI;","_scheme","I"));
                code.visitFieldStmt(IGET,2,6,new Field("Lorg/mortbay/jetty/HttpURI;","_authority","I"));
                code.visitJumpStmt(IF_NE,1,2,L4);
                code.visitLabel(L2);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L3);
                code.visitStmt1R(RETURN_OBJECT,1);
                code.visitLabel(L4);
                code.visitFieldStmt(IGET,1,6,new Field("Lorg/mortbay/jetty/HttpURI;","_authority","I"));
                code.visitFieldStmt(IGET,2,6,new Field("Lorg/mortbay/jetty/HttpURI;","_scheme","I"));
                code.visitStmt3R(SUB_INT,0,1,2);
                code.visitLabel(L5);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(5)); // int: 0x00000005  float:0.000000
                code.visitJumpStmt(IF_NE,0,1,L7);
                code.visitFieldStmt(IGET_OBJECT,1,6,new Field("Lorg/mortbay/jetty/HttpURI;","_raw","[B"));
                code.visitFieldStmt(IGET,2,6,new Field("Lorg/mortbay/jetty/HttpURI;","_scheme","I"));
                code.visitStmt3R(AGET_BYTE,1,1,2);
                code.visitJumpStmt(IF_NE,1,4,L7);
                code.visitFieldStmt(IGET_OBJECT,1,6,new Field("Lorg/mortbay/jetty/HttpURI;","_raw","[B"));
                code.visitFieldStmt(IGET,2,6,new Field("Lorg/mortbay/jetty/HttpURI;","_scheme","I"));
                code.visitStmt2R1N(ADD_INT_LIT8,2,2,1);
                code.visitStmt3R(AGET_BYTE,1,1,2);
                code.visitJumpStmt(IF_NE,1,3,L7);
                code.visitFieldStmt(IGET_OBJECT,1,6,new Field("Lorg/mortbay/jetty/HttpURI;","_raw","[B"));
                code.visitFieldStmt(IGET,2,6,new Field("Lorg/mortbay/jetty/HttpURI;","_scheme","I"));
                code.visitStmt2R1N(ADD_INT_LIT8,2,2,2);
                code.visitStmt3R(AGET_BYTE,1,1,2);
                code.visitJumpStmt(IF_NE,1,3,L7);
                code.visitFieldStmt(IGET_OBJECT,1,6,new Field("Lorg/mortbay/jetty/HttpURI;","_raw","[B"));
                code.visitFieldStmt(IGET,2,6,new Field("Lorg/mortbay/jetty/HttpURI;","_scheme","I"));
                code.visitStmt2R1N(ADD_INT_LIT8,2,2,3);
                code.visitStmt3R(AGET_BYTE,1,1,2);
                code.visitJumpStmt(IF_NE,1,5,L7);
                code.visitLabel(L6);
                code.visitConstStmt(CONST_STRING,1,"http");
                code.visitJumpStmt(GOTO,-1,-1,L3);
                code.visitLabel(L7);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(6)); // int: 0x00000006  float:0.000000
                code.visitJumpStmt(IF_NE,0,1,L9);
                code.visitFieldStmt(IGET_OBJECT,1,6,new Field("Lorg/mortbay/jetty/HttpURI;","_raw","[B"));
                code.visitFieldStmt(IGET,2,6,new Field("Lorg/mortbay/jetty/HttpURI;","_scheme","I"));
                code.visitStmt3R(AGET_BYTE,1,1,2);
                code.visitJumpStmt(IF_NE,1,4,L9);
                code.visitFieldStmt(IGET_OBJECT,1,6,new Field("Lorg/mortbay/jetty/HttpURI;","_raw","[B"));
                code.visitFieldStmt(IGET,2,6,new Field("Lorg/mortbay/jetty/HttpURI;","_scheme","I"));
                code.visitStmt2R1N(ADD_INT_LIT8,2,2,1);
                code.visitStmt3R(AGET_BYTE,1,1,2);
                code.visitJumpStmt(IF_NE,1,3,L9);
                code.visitFieldStmt(IGET_OBJECT,1,6,new Field("Lorg/mortbay/jetty/HttpURI;","_raw","[B"));
                code.visitFieldStmt(IGET,2,6,new Field("Lorg/mortbay/jetty/HttpURI;","_scheme","I"));
                code.visitStmt2R1N(ADD_INT_LIT8,2,2,2);
                code.visitStmt3R(AGET_BYTE,1,1,2);
                code.visitJumpStmt(IF_NE,1,3,L9);
                code.visitFieldStmt(IGET_OBJECT,1,6,new Field("Lorg/mortbay/jetty/HttpURI;","_raw","[B"));
                code.visitFieldStmt(IGET,2,6,new Field("Lorg/mortbay/jetty/HttpURI;","_scheme","I"));
                code.visitStmt2R1N(ADD_INT_LIT8,2,2,3);
                code.visitStmt3R(AGET_BYTE,1,1,2);
                code.visitJumpStmt(IF_NE,1,5,L9);
                code.visitFieldStmt(IGET_OBJECT,1,6,new Field("Lorg/mortbay/jetty/HttpURI;","_raw","[B"));
                code.visitFieldStmt(IGET,2,6,new Field("Lorg/mortbay/jetty/HttpURI;","_scheme","I"));
                code.visitStmt2R1N(ADD_INT_LIT8,2,2,4);
                code.visitStmt3R(AGET_BYTE,1,1,2);
                code.visitConstStmt(CONST_16,2, Integer.valueOf(115)); // int: 0x00000073  float:0.000000
                code.visitJumpStmt(IF_NE,1,2,L9);
                code.visitLabel(L8);
                code.visitConstStmt(CONST_STRING,1,"https");
                code.visitJumpStmt(GOTO,-1,-1,L3);
                code.visitLabel(L9);
                code.visitFieldStmt(IGET,1,6,new Field("Lorg/mortbay/jetty/HttpURI;","_scheme","I"));
                code.visitFieldStmt(IGET,2,6,new Field("Lorg/mortbay/jetty/HttpURI;","_authority","I"));
                code.visitFieldStmt(IGET,3,6,new Field("Lorg/mortbay/jetty/HttpURI;","_scheme","I"));
                code.visitStmt2R(SUB_INT_2ADDR,2,3);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitStmt2R(SUB_INT_2ADDR,2,3);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 6,1,2},new Method("Lorg/mortbay/jetty/HttpURI;","toUtf8String",new String[]{ "I","I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitJumpStmt(GOTO,-1,-1,L3);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m022_hasQuery(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/HttpURI;","hasQuery",new String[]{ },"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(537,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET,0,2,new Field("Lorg/mortbay/jetty/HttpURI;","_fragment","I"));
                code.visitFieldStmt(IGET,1,2,new Field("Lorg/mortbay/jetty/HttpURI;","_query","I"));
                DexLabel L1=new DexLabel();
                code.visitJumpStmt(IF_LE,0,1,L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                DexLabel L2=new DexLabel();
                code.visitLabel(L2);
                code.visitStmt1R(RETURN,0);
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m023_parse(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/HttpURI;","parse",new String[]{ "Ljava/lang/String;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"raw");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(101,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(102,L1);
                ddv.visitStartLocal(0,L1,"b","[B",null);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(103,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(104,L3);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Ljava/lang/String;","getBytes",new String[]{ },"[B"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitStmt2R(ARRAY_LENGTH,2,0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 3,0,1,2},new Method("Lorg/mortbay/jetty/HttpURI;","parse2",new String[]{ "[B","I","I"},"V"));
                code.visitLabel(L2);
                code.visitFieldStmt(IPUT_OBJECT,4,3,new Field("Lorg/mortbay/jetty/HttpURI;","_rawString","Ljava/lang/String;"));
                code.visitLabel(L3);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m024_parse(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/HttpURI;","parse",new String[]{ "[B","I","I"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"raw");
                ddv.visitParameterName(1,"offset");
                ddv.visitParameterName(2,"length");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(108,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(109,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(110,L2);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/jetty/HttpURI;","_rawString","Ljava/lang/String;"));
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1,2,3,4},new Method("Lorg/mortbay/jetty/HttpURI;","parse2",new String[]{ "[B","I","I"},"V"));
                code.visitLabel(L2);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m025_toString(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/HttpURI;","toString",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(576,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(577,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(578,L2);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,3,new Field("Lorg/mortbay/jetty/HttpURI;","_rawString","Ljava/lang/String;"));
                code.visitJumpStmt(IF_NEZ,0,-1,L2);
                code.visitLabel(L1);
                code.visitFieldStmt(IGET,0,3,new Field("Lorg/mortbay/jetty/HttpURI;","_scheme","I"));
                code.visitFieldStmt(IGET,1,3,new Field("Lorg/mortbay/jetty/HttpURI;","_end","I"));
                code.visitFieldStmt(IGET,2,3,new Field("Lorg/mortbay/jetty/HttpURI;","_scheme","I"));
                code.visitStmt2R(SUB_INT_2ADDR,1,2);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 3,0,1},new Method("Lorg/mortbay/jetty/HttpURI;","toUtf8String",new String[]{ "I","I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(IPUT_OBJECT,0,3,new Field("Lorg/mortbay/jetty/HttpURI;","_rawString","Ljava/lang/String;"));
                code.visitLabel(L2);
                code.visitFieldStmt(IGET_OBJECT,0,3,new Field("Lorg/mortbay/jetty/HttpURI;","_rawString","Ljava/lang/String;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m026_writeTo(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/HttpURI;","writeTo",new String[]{ "Lorg/mortbay/util/Utf8StringBuffer;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(6);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"buf");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(583,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(584,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,4,new Field("Lorg/mortbay/jetty/HttpURI;","_raw","[B"));
                code.visitFieldStmt(IGET,1,4,new Field("Lorg/mortbay/jetty/HttpURI;","_scheme","I"));
                code.visitFieldStmt(IGET,2,4,new Field("Lorg/mortbay/jetty/HttpURI;","_end","I"));
                code.visitFieldStmt(IGET,3,4,new Field("Lorg/mortbay/jetty/HttpURI;","_scheme","I"));
                code.visitStmt2R(SUB_INT_2ADDR,2,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,0,1,2},new Method("Lorg/mortbay/util/Utf8StringBuffer;","append",new String[]{ "[B","I","I"},"V"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
