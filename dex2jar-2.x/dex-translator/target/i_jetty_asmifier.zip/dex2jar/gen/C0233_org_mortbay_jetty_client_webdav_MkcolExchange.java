package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0233_org_mortbay_jetty_client_webdav_MkcolExchange {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(ACC_PUBLIC,"Lorg/mortbay/jetty/client/webdav/MkcolExchange;","Lorg/mortbay/jetty/client/CachedExchange;",new String[]{ });
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("MkcolExchange.java");
        f000_exists(cv);
        m000__init_(cv);
        m001_exists(cv);
        m002_onResponseStatus(cv);
    }
    public static void f000_exists(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(0, new Field("Lorg/mortbay/jetty/client/webdav/MkcolExchange;","exists","Z"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void m000__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/jetty/client/webdav/MkcolExchange;","<init>",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(32,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(28,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(33,L2);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1,0},new Method("Lorg/mortbay/jetty/client/CachedExchange;","<init>",new String[]{ "Z"},"V"));
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT_BOOLEAN,0,1,new Field("Lorg/mortbay/jetty/client/webdav/MkcolExchange;","exists","Z"));
                code.visitLabel(L2);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001_exists(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/client/webdav/MkcolExchange;","exists",new String[]{ },"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(55,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_BOOLEAN,0,1,new Field("Lorg/mortbay/jetty/client/webdav/MkcolExchange;","exists","Z"));
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m002_onResponseStatus(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Lorg/mortbay/jetty/client/webdav/MkcolExchange;","onResponseStatus",new String[]{ "Lorg/mortbay/io/Buffer;","I","Lorg/mortbay/io/Buffer;"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(6);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"version");
                ddv.visitParameterName(1,"status");
                ddv.visitParameterName(2,"reason");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(38,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(40,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(41,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(44,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(46,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(47,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(50,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(51,L8);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitLabel(L1);
                code.visitConstStmt(CONST_16,0, Integer.valueOf(201)); // int: 0x000000c9  float:0.000000
                code.visitJumpStmt(IF_NE,4,0,L4);
                code.visitLabel(L2);
                code.visitConstStmt(CONST_STRING,0,"MkcolExchange:Status: Successfully created resource");
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0},new Method("Lorg/mortbay/log/Log;","debug",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L3);
                code.visitFieldStmt(IPUT_BOOLEAN,1,2,new Field("Lorg/mortbay/jetty/client/webdav/MkcolExchange;","exists","Z"));
                code.visitLabel(L4);
                code.visitConstStmt(CONST_16,0, Integer.valueOf(405)); // int: 0x00000195  float:0.000000
                code.visitJumpStmt(IF_NE,4,0,L7);
                code.visitLabel(L5);
                code.visitConstStmt(CONST_STRING,0,"MkcolExchange:Status: Resource must exist");
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0},new Method("Lorg/mortbay/log/Log;","debug",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L6);
                code.visitFieldStmt(IPUT_BOOLEAN,1,2,new Field("Lorg/mortbay/jetty/client/webdav/MkcolExchange;","exists","Z"));
                code.visitLabel(L7);
                code.visitMethodStmt(INVOKE_SUPER,new int[]{ 2,3,4,5},new Method("Lorg/mortbay/jetty/client/CachedExchange;","onResponseStatus",new String[]{ "Lorg/mortbay/io/Buffer;","I","Lorg/mortbay/io/Buffer;"},"V"));
                code.visitLabel(L8);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
