package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0296_org_mortbay_jetty_security_JDBCUserRealm {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(ACC_PUBLIC,"Lorg/mortbay/jetty/security/JDBCUserRealm;","Lorg/mortbay/jetty/security/HashUserRealm;",new String[]{ "Lorg/mortbay/jetty/security/UserRealm;"});
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("JDBCUserRealm.java");
        f000__cacheTime(cv);
        f001__con(cv);
        f002__jdbcDriver(cv);
        f003__lastHashPurge(cv);
        f004__password(cv);
        f005__roleSql(cv);
        f006__roleTable(cv);
        f007__roleTableKey(cv);
        f008__roleTableRoleField(cv);
        f009__url(cv);
        f010__userName(cv);
        f011__userRoleTable(cv);
        f012__userRoleTableRoleKey(cv);
        f013__userRoleTableUserKey(cv);
        f014__userSql(cv);
        f015__userTable(cv);
        f016__userTableKey(cv);
        f017__userTablePasswordField(cv);
        f018__userTableUserField(cv);
        m000__init_(cv);
        m001__init_(cv);
        m002__init_(cv);
        m003_loadUser(cv);
        m004_authenticate(cv);
        m005_connectDatabase(cv);
        m006_isUserInRole(cv);
        m007_loadConfig(cv);
        m008_logout(cv);
    }
    public static void f000__cacheTime(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/security/JDBCUserRealm;","_cacheTime","I"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f001__con(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/security/JDBCUserRealm;","_con","Ljava/sql/Connection;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f002__jdbcDriver(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/security/JDBCUserRealm;","_jdbcDriver","Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f003__lastHashPurge(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/security/JDBCUserRealm;","_lastHashPurge","J"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f004__password(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/security/JDBCUserRealm;","_password","Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f005__roleSql(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/security/JDBCUserRealm;","_roleSql","Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f006__roleTable(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/security/JDBCUserRealm;","_roleTable","Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f007__roleTableKey(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/security/JDBCUserRealm;","_roleTableKey","Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f008__roleTableRoleField(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/security/JDBCUserRealm;","_roleTableRoleField","Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f009__url(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/security/JDBCUserRealm;","_url","Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f010__userName(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/security/JDBCUserRealm;","_userName","Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f011__userRoleTable(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/security/JDBCUserRealm;","_userRoleTable","Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f012__userRoleTableRoleKey(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/security/JDBCUserRealm;","_userRoleTableRoleKey","Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f013__userRoleTableUserKey(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/security/JDBCUserRealm;","_userRoleTableUserKey","Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f014__userSql(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/security/JDBCUserRealm;","_userSql","Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f015__userTable(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/security/JDBCUserRealm;","_userTable","Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f016__userTableKey(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/security/JDBCUserRealm;","_userTableKey","Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f017__userTablePasswordField(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/security/JDBCUserRealm;","_userTablePasswordField","Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f018__userTableUserField(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/security/JDBCUserRealm;","_userTableUserField","Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void m000__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/jetty/security/JDBCUserRealm;","<init>",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(1);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(85,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(86,L1);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Lorg/mortbay/jetty/security/HashUserRealm;","<init>",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/jetty/security/JDBCUserRealm;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"name");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(94,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(95,L1);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1},new Method("Lorg/mortbay/jetty/security/HashUserRealm;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m002__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/jetty/security/JDBCUserRealm;","<init>",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visit(null, new DexType("Ljava/lang/ClassNotFoundException;"));
                            av01.visit(null, new DexType("Ljava/lang/InstantiationException;"));
                            av01.visit(null, new DexType("Ljava/lang/IllegalAccessException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"name");
                ddv.visitParameterName(1,"config");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(110,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(111,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(112,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(113,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(114,L4);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2,3},new Method("Lorg/mortbay/jetty/security/HashUserRealm;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,4},new Method("Lorg/mortbay/jetty/security/JDBCUserRealm;","setConfig",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Ljava/lang/Object;","getClass",new String[]{ },"Ljava/lang/Class;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/jetty/security/JDBCUserRealm;","_jdbcDriver","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0,1},new Method("Lorg/mortbay/util/Loader;","loadClass",new String[]{ "Ljava/lang/Class;","Ljava/lang/String;"},"Ljava/lang/Class;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/lang/Class;","newInstance",new String[]{ },"Ljava/lang/Object;"));
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/jetty/security/JDBCUserRealm;","connectDatabase",new String[]{ },"V"));
                code.visitLabel(L4);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m003_loadUser(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PRIVATE, new Method("Lorg/mortbay/jetty/security/JDBCUserRealm;","loadUser",new String[]{ "Ljava/lang/String;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(8);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L1},new String[]{ "Ljava/sql/SQLException;"});
                DexLabel L2=new DexLabel();
                DexLabel L3=new DexLabel();
                code.visitTryCatch(L2,L3,new DexLabel[]{L1},new String[]{ "Ljava/sql/SQLException;"});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"username");
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(240,L0);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(241,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(243,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(244,L6);
                ddv.visitLineNumber(266,L1);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(268,L7);
                ddv.visitStartLocal(0,L7,"e","Ljava/sql/SQLException;",null);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(270,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(272,L9);
                ddv.visitEndLocal(0,L9);
                ddv.visitLineNumber(246,L2);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(247,L10);
                ddv.visitStartLocal(3,L10,"stat","Ljava/sql/PreparedStatement;",null);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(248,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(250,L12);
                ddv.visitStartLocal(2,L12,"rs","Ljava/sql/ResultSet;",null);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(252,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(253,L14);
                ddv.visitStartLocal(1,L14,"key","I",null);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(254,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(256,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(257,L17);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(258,L18);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(260,L19);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(261,L20);
                DexLabel L21=new DexLabel();
                ddv.visitLineNumber(263,L21);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,4,6,new Field("Lorg/mortbay/jetty/security/JDBCUserRealm;","_con","Ljava/sql/Connection;"));
                code.visitJumpStmt(IF_NEZ,4,-1,L5);
                code.visitLabel(L4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Lorg/mortbay/jetty/security/JDBCUserRealm;","connectDatabase",new String[]{ },"V"));
                code.visitLabel(L5);
                code.visitFieldStmt(IGET_OBJECT,4,6,new Field("Lorg/mortbay/jetty/security/JDBCUserRealm;","_con","Ljava/sql/Connection;"));
                code.visitJumpStmt(IF_NEZ,4,-1,L2);
                code.visitLabel(L6);
                code.visitTypeStmt(NEW_INSTANCE,4,-1,"Ljava/sql/SQLException;");
                code.visitConstStmt(CONST_STRING,5,"Can\'t connect to database");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 4,5},new Method("Ljava/sql/SQLException;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitStmt1R(THROW,4);
                code.visitLabel(L1);
                code.visitStmt1R(MOVE_EXCEPTION,4);
                code.visitStmt2R(MOVE_OBJECT,0,4);
                code.visitLabel(L7);
                code.visitTypeStmt(NEW_INSTANCE,4,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 4},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,5,"UserRealm ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,5},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Lorg/mortbay/jetty/security/JDBCUserRealm;","getName",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,5},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitConstStmt(CONST_STRING,5," could not load user information from database");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,5},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 4,0},new Method("Lorg/mortbay/log/Log;","warn",new String[]{ "Ljava/lang/String;","Ljava/lang/Throwable;"},"V"));
                code.visitLabel(L8);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Lorg/mortbay/jetty/security/JDBCUserRealm;","connectDatabase",new String[]{ },"V"));
                code.visitLabel(L9);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L2);
                code.visitFieldStmt(IGET_OBJECT,4,6,new Field("Lorg/mortbay/jetty/security/JDBCUserRealm;","_con","Ljava/sql/Connection;"));
                code.visitFieldStmt(IGET_OBJECT,5,6,new Field("Lorg/mortbay/jetty/security/JDBCUserRealm;","_userSql","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 4,5},new Method("Ljava/sql/Connection;","prepareStatement",new String[]{ "Ljava/lang/String;"},"Ljava/sql/PreparedStatement;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitLabel(L10);
                code.visitConstStmt(CONST_4,4, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 3,4,7},new Method("Ljava/sql/PreparedStatement;","setObject",new String[]{ "I","Ljava/lang/Object;"},"V"));
                code.visitLabel(L11);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 3},new Method("Ljava/sql/PreparedStatement;","executeQuery",new String[]{ },"Ljava/sql/ResultSet;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitLabel(L12);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 2},new Method("Ljava/sql/ResultSet;","next",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,4);
                code.visitJumpStmt(IF_EQZ,4,-1,L9);
                code.visitLabel(L13);
                code.visitFieldStmt(IGET_OBJECT,4,6,new Field("Lorg/mortbay/jetty/security/JDBCUserRealm;","_userTableKey","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 2,4},new Method("Ljava/sql/ResultSet;","getInt",new String[]{ "Ljava/lang/String;"},"I"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitLabel(L14);
                code.visitFieldStmt(IGET_OBJECT,4,6,new Field("Lorg/mortbay/jetty/security/JDBCUserRealm;","_userTablePasswordField","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 2,4},new Method("Ljava/sql/ResultSet;","getString",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,7,4},new Method("Lorg/mortbay/jetty/security/JDBCUserRealm;","put",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitLabel(L15);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 3},new Method("Ljava/sql/PreparedStatement;","close",new String[]{ },"V"));
                code.visitLabel(L16);
                code.visitFieldStmt(IGET_OBJECT,4,6,new Field("Lorg/mortbay/jetty/security/JDBCUserRealm;","_con","Ljava/sql/Connection;"));
                code.visitFieldStmt(IGET_OBJECT,5,6,new Field("Lorg/mortbay/jetty/security/JDBCUserRealm;","_roleSql","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 4,5},new Method("Ljava/sql/Connection;","prepareStatement",new String[]{ "Ljava/lang/String;"},"Ljava/sql/PreparedStatement;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitLabel(L17);
                code.visitConstStmt(CONST_4,4, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 3,4,1},new Method("Ljava/sql/PreparedStatement;","setInt",new String[]{ "I","I"},"V"));
                code.visitLabel(L18);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 3},new Method("Ljava/sql/PreparedStatement;","executeQuery",new String[]{ },"Ljava/sql/ResultSet;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitLabel(L19);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 2},new Method("Ljava/sql/ResultSet;","next",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,4);
                code.visitJumpStmt(IF_EQZ,4,-1,L21);
                code.visitLabel(L20);
                code.visitFieldStmt(IGET_OBJECT,4,6,new Field("Lorg/mortbay/jetty/security/JDBCUserRealm;","_roleTableRoleField","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 2,4},new Method("Ljava/sql/ResultSet;","getString",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,7,4},new Method("Lorg/mortbay/jetty/security/JDBCUserRealm;","addUserToRole",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L19);
                code.visitLabel(L21);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 3},new Method("Ljava/sql/PreparedStatement;","close",new String[]{ },"V"));
                code.visitLabel(L3);
                code.visitJumpStmt(GOTO,-1,-1,L9);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m004_authenticate(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/security/JDBCUserRealm;","authenticate",new String[]{ "Ljava/lang/String;","Ljava/lang/Object;","Lorg/mortbay/jetty/Request;"},"Ljava/security/Principal;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(11);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexLabel L3=new DexLabel();
                DexLabel L4=new DexLabel();
                code.visitTryCatch(L3,L4,new DexLabel[]{L2},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"username");
                ddv.visitParameterName(1,"credentials");
                ddv.visitParameterName(2,"request");
                DexLabel L5=new DexLabel();
                ddv.visitPrologue(L5);
                ddv.visitLineNumber(200,L5);
                ddv.visitLineNumber(202,L0);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(203,L6);
                ddv.visitStartLocal(0,L6,"now","J",null);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(205,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(206,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(207,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(209,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(210,L11);
                ddv.visitStartLocal(2,L11,"user","Ljava/security/Principal;",null);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(212,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(213,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(215,L14);
                ddv.visitLineNumber(216,L1);
                ddv.visitLineNumber(215,L2);
                ddv.visitEndLocal(0,L2);
                ddv.visitEndLocal(2,L2);
                code.visitLabel(L5);
                code.visitStmt1R(MONITOR_ENTER,7);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Ljava/lang/System;","currentTimeMillis",new String[]{ },"J"));
                code.visitStmt1R(MOVE_RESULT_WIDE,0);
                code.visitLabel(L6);
                code.visitFieldStmt(IGET_WIDE,3,7,new Field("Lorg/mortbay/jetty/security/JDBCUserRealm;","_lastHashPurge","J"));
                code.visitStmt3R(SUB_LONG,3,0,3);
                code.visitFieldStmt(IGET,5,7,new Field("Lorg/mortbay/jetty/security/JDBCUserRealm;","_cacheTime","I"));
                code.visitStmt2R(INT_TO_LONG,5,5);
                code.visitStmt3R(CMP_LONG,3,3,5);
                code.visitJumpStmt(IF_GTZ,3,-1,L7);
                code.visitFieldStmt(IGET,3,7,new Field("Lorg/mortbay/jetty/security/JDBCUserRealm;","_cacheTime","I"));
                code.visitJumpStmt(IF_NEZ,3,-1,L10);
                code.visitLabel(L7);
                code.visitFieldStmt(IGET_OBJECT,3,7,new Field("Lorg/mortbay/jetty/security/JDBCUserRealm;","_users","Ljava/util/HashMap;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Ljava/util/HashMap;","clear",new String[]{ },"V"));
                code.visitLabel(L8);
                code.visitFieldStmt(IGET_OBJECT,3,7,new Field("Lorg/mortbay/jetty/security/JDBCUserRealm;","_roles","Ljava/util/HashMap;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Ljava/util/HashMap;","clear",new String[]{ },"V"));
                code.visitLabel(L9);
                code.visitFieldStmt(IPUT_WIDE,0,7,new Field("Lorg/mortbay/jetty/security/JDBCUserRealm;","_lastHashPurge","J"));
                code.visitLabel(L10);
                code.visitMethodStmt(INVOKE_SUPER,new int[]{ 7,8},new Method("Lorg/mortbay/jetty/security/HashUserRealm;","getPrincipal",new String[]{ "Ljava/lang/String;"},"Ljava/security/Principal;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitLabel(L11);
                code.visitJumpStmt(IF_NEZ,2,-1,L14);
                code.visitLabel(L12);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 7,8},new Method("Lorg/mortbay/jetty/security/JDBCUserRealm;","loadUser",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L13);
                code.visitMethodStmt(INVOKE_SUPER,new int[]{ 7,8},new Method("Lorg/mortbay/jetty/security/HashUserRealm;","getPrincipal",new String[]{ "Ljava/lang/String;"},"Ljava/security/Principal;"));
                code.visitLabel(L14);
                code.visitStmt1R(MONITOR_EXIT,7);
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_SUPER,new int[]{ 7,8,9,10},new Method("Lorg/mortbay/jetty/security/HashUserRealm;","authenticate",new String[]{ "Ljava/lang/String;","Ljava/lang/Object;","Lorg/mortbay/jetty/Request;"},"Ljava/security/Principal;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitStmt1R(RETURN_OBJECT,3);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,3);
                code.visitLabel(L3);
                code.visitStmt1R(MONITOR_EXIT,7);
                code.visitLabel(L4);
                code.visitStmt1R(THROW,3);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m005_connectDatabase(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/security/JDBCUserRealm;","connectDatabase",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(7);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                DexLabel L3=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2,L3},new String[]{ "Ljava/sql/SQLException;","Ljava/lang/ClassNotFoundException;"});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L4=new DexLabel();
                ddv.visitPrologue(L4);
                ddv.visitLineNumber(180,L0);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(181,L5);
                ddv.visitLineNumber(193,L1);
                ddv.visitLineNumber(183,L2);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(185,L6);
                ddv.visitStartLocal(0,L6,"e","Ljava/sql/SQLException;",null);
                ddv.visitLineNumber(188,L3);
                ddv.visitEndLocal(0,L3);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(190,L7);
                ddv.visitStartLocal(0,L7,"e","Ljava/lang/ClassNotFoundException;",null);
                code.visitLabel(L4);
                code.visitConstStmt(CONST_STRING,5,"UserRealm ");
                code.visitConstStmt(CONST_STRING,4," could not connect to database; will try later");
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,1,6,new Field("Lorg/mortbay/jetty/security/JDBCUserRealm;","_jdbcDriver","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1},new Method("Ljava/lang/Class;","forName",new String[]{ "Ljava/lang/String;"},"Ljava/lang/Class;"));
                code.visitLabel(L5);
                code.visitFieldStmt(IGET_OBJECT,1,6,new Field("Lorg/mortbay/jetty/security/JDBCUserRealm;","_url","Ljava/lang/String;"));
                code.visitFieldStmt(IGET_OBJECT,2,6,new Field("Lorg/mortbay/jetty/security/JDBCUserRealm;","_userName","Ljava/lang/String;"));
                code.visitFieldStmt(IGET_OBJECT,3,6,new Field("Lorg/mortbay/jetty/security/JDBCUserRealm;","_password","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1,2,3},new Method("Ljava/sql/DriverManager;","getConnection",new String[]{ "Ljava/lang/String;","Ljava/lang/String;","Ljava/lang/String;"},"Ljava/sql/Connection;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitFieldStmt(IPUT_OBJECT,1,6,new Field("Lorg/mortbay/jetty/security/JDBCUserRealm;","_con","Ljava/sql/Connection;"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,1);
                code.visitStmt2R(MOVE_OBJECT,0,1);
                code.visitLabel(L6);
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,2,"UserRealm ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,5},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Lorg/mortbay/jetty/security/JDBCUserRealm;","getName",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitConstStmt(CONST_STRING,2," could not connect to database; will try later");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,4},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1,0},new Method("Lorg/mortbay/log/Log;","warn",new String[]{ "Ljava/lang/String;","Ljava/lang/Throwable;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L1);
                code.visitLabel(L3);
                code.visitStmt1R(MOVE_EXCEPTION,1);
                code.visitStmt2R(MOVE_OBJECT,0,1);
                code.visitLabel(L7);
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,2,"UserRealm ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,5},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Lorg/mortbay/jetty/security/JDBCUserRealm;","getName",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitConstStmt(CONST_STRING,2," could not connect to database; will try later");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,4},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1,0},new Method("Lorg/mortbay/log/Log;","warn",new String[]{ "Ljava/lang/String;","Ljava/lang/Throwable;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L1);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m006_isUserInRole(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/security/JDBCUserRealm;","isUserInRole",new String[]{ "Ljava/security/Principal;","Ljava/lang/String;"},"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"user");
                ddv.visitParameterName(1,"roleName");
                DexLabel L3=new DexLabel();
                ddv.visitPrologue(L3);
                ddv.visitLineNumber(227,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(228,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(229,L5);
                ddv.visitLineNumber(227,L2);
                code.visitLabel(L3);
                code.visitStmt1R(MONITOR_ENTER,1);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 2},new Method("Ljava/security/Principal;","getName",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_SUPER,new int[]{ 1,0},new Method("Lorg/mortbay/jetty/security/HashUserRealm;","getPrincipal",new String[]{ "Ljava/lang/String;"},"Ljava/security/Principal;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitJumpStmt(IF_NEZ,0,-1,L5);
                code.visitLabel(L4);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 2},new Method("Ljava/security/Principal;","getName",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1,0},new Method("Lorg/mortbay/jetty/security/JDBCUserRealm;","loadUser",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L5);
                code.visitMethodStmt(INVOKE_SUPER,new int[]{ 1,2,3},new Method("Lorg/mortbay/jetty/security/HashUserRealm;","isUserInRole",new String[]{ "Ljava/security/Principal;","Ljava/lang/String;"},"Z"));
                code.visitLabel(L1);
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitStmt1R(MONITOR_EXIT,1);
                code.visitStmt1R(RETURN,0);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,0);
                code.visitStmt1R(MONITOR_EXIT,1);
                code.visitStmt1R(THROW,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m007_loadConfig(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Lorg/mortbay/jetty/security/JDBCUserRealm;","loadConfig",new String[]{ },"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(8);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(124,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(126,L2);
                ddv.visitStartLocal(1,L2,"properties","Ljava/util/Properties;",null);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(128,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(129,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(130,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(131,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(132,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(133,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(134,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(135,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(136,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(137,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(138,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(139,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(140,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(141,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(143,L17);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(144,L18);
                ddv.visitStartLocal(0,L18,"cachetime","Ljava/lang/String;",null);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(146,L19);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(152,L20);
                DexLabel L21=new DexLabel();
                ddv.visitLineNumber(155,L21);
                DexLabel L22=new DexLabel();
                ddv.visitLineNumber(156,L22);
                DexLabel L23=new DexLabel();
                ddv.visitLineNumber(157,L23);
                DexLabel L24=new DexLabel();
                ddv.visitLineNumber(161,L24);
                DexLabel L25=new DexLabel();
                ddv.visitLineNumber(167,L25);
                DexLabel L26=new DexLabel();
                ddv.visitLineNumber(144,L26);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_STRING,6," from ");
                code.visitConstStmt(CONST_STRING,5," = ?");
                code.visitConstStmt(CONST_STRING,4,"");
                code.visitLabel(L1);
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Ljava/util/Properties;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1},new Method("Ljava/util/Properties;","<init>",new String[]{ },"V"));
                code.visitLabel(L2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7},new Method("Lorg/mortbay/jetty/security/JDBCUserRealm;","getConfigResource",new String[]{ },"Lorg/mortbay/resource/Resource;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/resource/Resource;","getInputStream",new String[]{ },"Ljava/io/InputStream;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2},new Method("Ljava/util/Properties;","load",new String[]{ "Ljava/io/InputStream;"},"V"));
                code.visitLabel(L3);
                code.visitConstStmt(CONST_STRING,2,"jdbcdriver");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2},new Method("Ljava/util/Properties;","getProperty",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitFieldStmt(IPUT_OBJECT,2,7,new Field("Lorg/mortbay/jetty/security/JDBCUserRealm;","_jdbcDriver","Ljava/lang/String;"));
                code.visitLabel(L4);
                code.visitConstStmt(CONST_STRING,2,"url");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2},new Method("Ljava/util/Properties;","getProperty",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitFieldStmt(IPUT_OBJECT,2,7,new Field("Lorg/mortbay/jetty/security/JDBCUserRealm;","_url","Ljava/lang/String;"));
                code.visitLabel(L5);
                code.visitConstStmt(CONST_STRING,2,"username");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2},new Method("Ljava/util/Properties;","getProperty",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitFieldStmt(IPUT_OBJECT,2,7,new Field("Lorg/mortbay/jetty/security/JDBCUserRealm;","_userName","Ljava/lang/String;"));
                code.visitLabel(L6);
                code.visitConstStmt(CONST_STRING,2,"password");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2},new Method("Ljava/util/Properties;","getProperty",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitFieldStmt(IPUT_OBJECT,2,7,new Field("Lorg/mortbay/jetty/security/JDBCUserRealm;","_password","Ljava/lang/String;"));
                code.visitLabel(L7);
                code.visitConstStmt(CONST_STRING,2,"usertable");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2},new Method("Ljava/util/Properties;","getProperty",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitFieldStmt(IPUT_OBJECT,2,7,new Field("Lorg/mortbay/jetty/security/JDBCUserRealm;","_userTable","Ljava/lang/String;"));
                code.visitLabel(L8);
                code.visitConstStmt(CONST_STRING,2,"usertablekey");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2},new Method("Ljava/util/Properties;","getProperty",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitFieldStmt(IPUT_OBJECT,2,7,new Field("Lorg/mortbay/jetty/security/JDBCUserRealm;","_userTableKey","Ljava/lang/String;"));
                code.visitLabel(L9);
                code.visitConstStmt(CONST_STRING,2,"usertableuserfield");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2},new Method("Ljava/util/Properties;","getProperty",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitFieldStmt(IPUT_OBJECT,2,7,new Field("Lorg/mortbay/jetty/security/JDBCUserRealm;","_userTableUserField","Ljava/lang/String;"));
                code.visitLabel(L10);
                code.visitConstStmt(CONST_STRING,2,"usertablepasswordfield");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2},new Method("Ljava/util/Properties;","getProperty",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitFieldStmt(IPUT_OBJECT,2,7,new Field("Lorg/mortbay/jetty/security/JDBCUserRealm;","_userTablePasswordField","Ljava/lang/String;"));
                code.visitLabel(L11);
                code.visitConstStmt(CONST_STRING,2,"roletable");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2},new Method("Ljava/util/Properties;","getProperty",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitFieldStmt(IPUT_OBJECT,2,7,new Field("Lorg/mortbay/jetty/security/JDBCUserRealm;","_roleTable","Ljava/lang/String;"));
                code.visitLabel(L12);
                code.visitConstStmt(CONST_STRING,2,"roletablekey");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2},new Method("Ljava/util/Properties;","getProperty",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitFieldStmt(IPUT_OBJECT,2,7,new Field("Lorg/mortbay/jetty/security/JDBCUserRealm;","_roleTableKey","Ljava/lang/String;"));
                code.visitLabel(L13);
                code.visitConstStmt(CONST_STRING,2,"roletablerolefield");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2},new Method("Ljava/util/Properties;","getProperty",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitFieldStmt(IPUT_OBJECT,2,7,new Field("Lorg/mortbay/jetty/security/JDBCUserRealm;","_roleTableRoleField","Ljava/lang/String;"));
                code.visitLabel(L14);
                code.visitConstStmt(CONST_STRING,2,"userroletable");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2},new Method("Ljava/util/Properties;","getProperty",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitFieldStmt(IPUT_OBJECT,2,7,new Field("Lorg/mortbay/jetty/security/JDBCUserRealm;","_userRoleTable","Ljava/lang/String;"));
                code.visitLabel(L15);
                code.visitConstStmt(CONST_STRING,2,"userroletableuserkey");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2},new Method("Ljava/util/Properties;","getProperty",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitFieldStmt(IPUT_OBJECT,2,7,new Field("Lorg/mortbay/jetty/security/JDBCUserRealm;","_userRoleTableUserKey","Ljava/lang/String;"));
                code.visitLabel(L16);
                code.visitConstStmt(CONST_STRING,2,"userroletablerolekey");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2},new Method("Ljava/util/Properties;","getProperty",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitFieldStmt(IPUT_OBJECT,2,7,new Field("Lorg/mortbay/jetty/security/JDBCUserRealm;","_userRoleTableRoleKey","Ljava/lang/String;"));
                code.visitLabel(L17);
                code.visitConstStmt(CONST_STRING,2,"cachetime");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2},new Method("Ljava/util/Properties;","getProperty",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L18);
                code.visitJumpStmt(IF_EQZ,0,-1,L26);
                code.visitTypeStmt(NEW_INSTANCE,2,-1,"Ljava/lang/Integer;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2,0},new Method("Ljava/lang/Integer;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Ljava/lang/Integer;","intValue",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,2);
                DexLabel L27=new DexLabel();
                code.visitLabel(L27);
                code.visitFieldStmt(IPUT,2,7,new Field("Lorg/mortbay/jetty/security/JDBCUserRealm;","_cacheTime","I"));
                code.visitLabel(L19);
                code.visitFieldStmt(IGET_OBJECT,2,7,new Field("Lorg/mortbay/jetty/security/JDBCUserRealm;","_jdbcDriver","Ljava/lang/String;"));
                code.visitJumpStmt(IF_EQZ,2,-1,L20);
                code.visitFieldStmt(IGET_OBJECT,2,7,new Field("Lorg/mortbay/jetty/security/JDBCUserRealm;","_jdbcDriver","Ljava/lang/String;"));
                code.visitConstStmt(CONST_STRING,3,"");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,4},new Method("Ljava/lang/String;","equals",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitJumpStmt(IF_NEZ,2,-1,L20);
                code.visitFieldStmt(IGET_OBJECT,2,7,new Field("Lorg/mortbay/jetty/security/JDBCUserRealm;","_url","Ljava/lang/String;"));
                code.visitJumpStmt(IF_EQZ,2,-1,L20);
                code.visitFieldStmt(IGET_OBJECT,2,7,new Field("Lorg/mortbay/jetty/security/JDBCUserRealm;","_url","Ljava/lang/String;"));
                code.visitConstStmt(CONST_STRING,3,"");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,4},new Method("Ljava/lang/String;","equals",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitJumpStmt(IF_NEZ,2,-1,L20);
                code.visitFieldStmt(IGET_OBJECT,2,7,new Field("Lorg/mortbay/jetty/security/JDBCUserRealm;","_userName","Ljava/lang/String;"));
                code.visitJumpStmt(IF_EQZ,2,-1,L20);
                code.visitFieldStmt(IGET_OBJECT,2,7,new Field("Lorg/mortbay/jetty/security/JDBCUserRealm;","_userName","Ljava/lang/String;"));
                code.visitConstStmt(CONST_STRING,3,"");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,4},new Method("Ljava/lang/String;","equals",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitJumpStmt(IF_NEZ,2,-1,L20);
                code.visitFieldStmt(IGET_OBJECT,2,7,new Field("Lorg/mortbay/jetty/security/JDBCUserRealm;","_password","Ljava/lang/String;"));
                code.visitJumpStmt(IF_EQZ,2,-1,L20);
                code.visitFieldStmt(IGET,2,7,new Field("Lorg/mortbay/jetty/security/JDBCUserRealm;","_cacheTime","I"));
                code.visitJumpStmt(IF_GEZ,2,-1,L21);
                code.visitLabel(L20);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Lorg/mortbay/log/Log;","isDebugEnabled",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitJumpStmt(IF_EQZ,2,-1,L21);
                code.visitTypeStmt(NEW_INSTANCE,2,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,3,"UserRealm ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7},new Method("Lorg/mortbay/jetty/security/JDBCUserRealm;","getName",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitConstStmt(CONST_STRING,3," has not been properly configured");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 2},new Method("Lorg/mortbay/log/Log;","debug",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L21);
                code.visitFieldStmt(IGET,2,7,new Field("Lorg/mortbay/jetty/security/JDBCUserRealm;","_cacheTime","I"));
                code.visitStmt2R1N(MUL_INT_LIT16,2,2,1000);
                code.visitFieldStmt(IPUT,2,7,new Field("Lorg/mortbay/jetty/security/JDBCUserRealm;","_cacheTime","I"));
                code.visitLabel(L22);
                code.visitConstStmt(CONST_WIDE_16,2,Long.valueOf(0L)); // long: 0x0000000000000000  double:0.000000
                code.visitFieldStmt(IPUT_WIDE,2,7,new Field("Lorg/mortbay/jetty/security/JDBCUserRealm;","_lastHashPurge","J"));
                code.visitLabel(L23);
                code.visitTypeStmt(NEW_INSTANCE,2,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,3,"select ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitFieldStmt(IGET_OBJECT,3,7,new Field("Lorg/mortbay/jetty/security/JDBCUserRealm;","_userTableKey","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitConstStmt(CONST_STRING,3,",");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitFieldStmt(IGET_OBJECT,3,7,new Field("Lorg/mortbay/jetty/security/JDBCUserRealm;","_userTablePasswordField","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitConstStmt(CONST_STRING,3," from ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,6},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitFieldStmt(IGET_OBJECT,3,7,new Field("Lorg/mortbay/jetty/security/JDBCUserRealm;","_userTable","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitConstStmt(CONST_STRING,3," where ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitFieldStmt(IGET_OBJECT,3,7,new Field("Lorg/mortbay/jetty/security/JDBCUserRealm;","_userTableUserField","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitConstStmt(CONST_STRING,3," = ?");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,5},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitFieldStmt(IPUT_OBJECT,2,7,new Field("Lorg/mortbay/jetty/security/JDBCUserRealm;","_userSql","Ljava/lang/String;"));
                code.visitLabel(L24);
                code.visitTypeStmt(NEW_INSTANCE,2,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,3,"select r.");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitFieldStmt(IGET_OBJECT,3,7,new Field("Lorg/mortbay/jetty/security/JDBCUserRealm;","_roleTableRoleField","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitConstStmt(CONST_STRING,3," from ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,6},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitFieldStmt(IGET_OBJECT,3,7,new Field("Lorg/mortbay/jetty/security/JDBCUserRealm;","_roleTable","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitConstStmt(CONST_STRING,3," r, ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitFieldStmt(IGET_OBJECT,3,7,new Field("Lorg/mortbay/jetty/security/JDBCUserRealm;","_userRoleTable","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitConstStmt(CONST_STRING,3," u where u.");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitFieldStmt(IGET_OBJECT,3,7,new Field("Lorg/mortbay/jetty/security/JDBCUserRealm;","_userRoleTableUserKey","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitConstStmt(CONST_STRING,3," = ?");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,5},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitConstStmt(CONST_STRING,3," and r.");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitFieldStmt(IGET_OBJECT,3,7,new Field("Lorg/mortbay/jetty/security/JDBCUserRealm;","_roleTableKey","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitConstStmt(CONST_STRING,3," = u.");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitFieldStmt(IGET_OBJECT,3,7,new Field("Lorg/mortbay/jetty/security/JDBCUserRealm;","_userRoleTableRoleKey","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitFieldStmt(IPUT_OBJECT,2,7,new Field("Lorg/mortbay/jetty/security/JDBCUserRealm;","_roleSql","Ljava/lang/String;"));
                code.visitLabel(L25);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L26);
                code.visitConstStmt(CONST_16,2, Integer.valueOf(30)); // int: 0x0000001e  float:0.000000
                code.visitJumpStmt(GOTO_16,-1,-1,L27);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m008_logout(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/security/JDBCUserRealm;","logout",new String[]{ "Ljava/security/Principal;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"user");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(171,L0);
                code.visitLabel(L0);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
