package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0085_org_mortbay_ijetty_console_AbstractContactsServlet {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(ACC_PUBLIC|ACC_ABSTRACT,"Lorg/mortbay/ijetty/console/AbstractContactsServlet;","Ljavax/servlet/http/HttpServlet;",new String[]{ });
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("AbstractContactsServlet.java");
        f000___ACTION_ADD(cv);
        f001___ACTION_CALL(cv);
        f002___ACTION_DEL(cv);
        f003___ACTION_EDIT(cv);
        f004___ACTION_NONE(cv);
        f005___ACTION_SAVE(cv);
        f006___VERSION(cv);
        f007_resolver(cv);
        m000__clinit_(cv);
        m001__init_(cv);
        m002_doGet(cv);
        m003_doPost(cv);
        m004_getContentResolver(cv);
        m005_handleAddUser(cv);
        m006_handleDefault(cv);
        m007_handleDeleteUser(cv);
        m008_handleEditUser(cv);
        m009_handleGetImage(cv);
        m010_handleGetUser(cv);
        m011_handleGetUsers(cv);
        m012_handleSaveUser(cv);
        m013_init(cv);
        m014_saveUserFormData(cv);
    }
    public static void f000___ACTION_ADD(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/ijetty/console/AbstractContactsServlet;","__ACTION_ADD","I"),  Integer.valueOf(2));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f001___ACTION_CALL(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/ijetty/console/AbstractContactsServlet;","__ACTION_CALL","I"),  Integer.valueOf(0));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f002___ACTION_DEL(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/ijetty/console/AbstractContactsServlet;","__ACTION_DEL","I"),  Integer.valueOf(3));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f003___ACTION_EDIT(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/ijetty/console/AbstractContactsServlet;","__ACTION_EDIT","I"),  Integer.valueOf(1));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f004___ACTION_NONE(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/ijetty/console/AbstractContactsServlet;","__ACTION_NONE","I"),  Integer.valueOf(-1));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f005___ACTION_SAVE(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/ijetty/console/AbstractContactsServlet;","__ACTION_SAVE","I"),  Integer.valueOf(4));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f006___VERSION(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC, new Field("Lorg/mortbay/ijetty/console/AbstractContactsServlet;","__VERSION","I"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f007_resolver(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/ijetty/console/AbstractContactsServlet;","resolver","Landroid/content/ContentResolver;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void m000__clinit_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_STATIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/ijetty/console/AbstractContactsServlet;","<clinit>",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(1);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(49,L0);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(SPUT,0,-1,new Field("Lorg/mortbay/ijetty/console/AbstractContactsServlet;","__VERSION","I"));
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/ijetty/console/AbstractContactsServlet;","<init>",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(1);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(47,L0);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljavax/servlet/http/HttpServlet;","<init>",new String[]{ },"V"));
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m002_doGet(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Lorg/mortbay/ijetty/console/AbstractContactsServlet;","doGet",new String[]{ "Ljavax/servlet/http/HttpServletRequest;","Ljavax/servlet/http/HttpServletResponse;"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljavax/servlet/ServletException;"));
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(16);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"request");
                ddv.visitParameterName(1,"response");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(92,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(93,L1);
                ddv.visitStartLocal(4,L1,"pathInfo","Ljava/lang/String;",null);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(94,L2);
                ddv.visitStartLocal(5,L2,"servletPath","Ljava/lang/String;",null);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(96,L3);
                ddv.visitStartLocal(3,L3,"pathInContext","Ljava/lang/String;",null);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(99,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(100,L5);
                ddv.visitStartLocal(1,L5,"dispatcher","Ljavax/servlet/RequestDispatcher;",null);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(201,L6);
                ddv.visitEndLocal(1,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(104,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(105,L8);
                ddv.visitStartLocal(9,L8,"who","Ljava/lang/String;",null);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(106,L9);
                ddv.visitStartLocal(8,L9,"what","Ljava/lang/String;",null);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(108,L10);
                ddv.visitStartLocal(2,L10,"json","Z",null);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(109,L11);
                ddv.visitStartLocal(7,L11,"strtok","Ljava/util/StringTokenizer;",null);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(110,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(112,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(113,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(115,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(116,L16);
                ddv.visitStartLocal(6,L16,"str","Ljava/lang/String;",null);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(118,L17);
                ddv.visitStartLocal(0,L17,"action","I",null);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(119,L18);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(121,L19);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(123,L20);
                DexLabel L21=new DexLabel();
                ddv.visitLineNumber(197,L21);
                DexLabel L22=new DexLabel();
                ddv.visitLineNumber(116,L22);
                ddv.visitEndLocal(0,L22);
                DexLabel L23=new DexLabel();
                ddv.visitLineNumber(119,L23);
                ddv.visitRestartLocal(0,L23);
                DexLabel L24=new DexLabel();
                ddv.visitLineNumber(127,L24);
                DexLabel L25=new DexLabel();
                ddv.visitLineNumber(132,L25);
                DexLabel L26=new DexLabel();
                ddv.visitLineNumber(134,L26);
                DexLabel L27=new DexLabel();
                ddv.visitLineNumber(139,L27);
                DexLabel L28=new DexLabel();
                ddv.visitLineNumber(141,L28);
                DexLabel L29=new DexLabel();
                ddv.visitLineNumber(146,L29);
                DexLabel L30=new DexLabel();
                ddv.visitLineNumber(164,L30);
                DexLabel L31=new DexLabel();
                ddv.visitLineNumber(173,L31);
                DexLabel L32=new DexLabel();
                ddv.visitLineNumber(182,L32);
                DexLabel L33=new DexLabel();
                ddv.visitLineNumber(191,L33);
                DexLabel L34=new DexLabel();
                ddv.visitLineNumber(123,L34);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 14},new Method("Ljavax/servlet/http/HttpServletRequest;","getPathInfo",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 14},new Method("Ljavax/servlet/http/HttpServletRequest;","getServletPath",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitLabel(L2);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 5,4},new Method("Lorg/mortbay/util/URIUtil;","addPaths",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitLabel(L3);
                code.visitJumpStmt(IF_NEZ,4,-1,L7);
                code.visitLabel(L4);
                code.visitTypeStmt(NEW_INSTANCE,10,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 10},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10,3},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,10);
                code.visitConstStmt(CONST_STRING,11,"/");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10,11},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,10);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,10);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 14,10},new Method("Ljavax/servlet/http/HttpServletRequest;","getRequestDispatcher",new String[]{ "Ljava/lang/String;"},"Ljavax/servlet/RequestDispatcher;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L5);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 1,14,15},new Method("Ljavax/servlet/RequestDispatcher;","forward",new String[]{ "Ljavax/servlet/ServletRequest;","Ljavax/servlet/ServletResponse;"},"V"));
                code.visitLabel(L6);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L7);
                code.visitConstStmt(CONST_4,9, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L8);
                code.visitConstStmt(CONST_4,8, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L9);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L10);
                code.visitTypeStmt(NEW_INSTANCE,7,-1,"Ljava/util/StringTokenizer;");
                code.visitConstStmt(CONST_STRING,10,"/");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 7,4,10},new Method("Ljava/util/StringTokenizer;","<init>",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"V"));
                code.visitLabel(L11);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7},new Method("Ljava/util/StringTokenizer;","hasMoreElements",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,10);
                code.visitJumpStmt(IF_EQZ,10,-1,L13);
                code.visitLabel(L12);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7},new Method("Ljava/util/StringTokenizer;","nextToken",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,9);
                code.visitLabel(L13);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7},new Method("Ljava/util/StringTokenizer;","hasMoreElements",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,10);
                code.visitJumpStmt(IF_EQZ,10,-1,L15);
                code.visitLabel(L14);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7},new Method("Ljava/util/StringTokenizer;","nextToken",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitLabel(L15);
                code.visitConstStmt(CONST_STRING,10,"action");
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 14,10},new Method("Ljavax/servlet/http/HttpServletRequest;","getParameter",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitLabel(L16);
                code.visitJumpStmt(IF_NEZ,6,-1,L22);
                code.visitConstStmt(CONST_4,10, Integer.valueOf(-1)); // int: 0xffffffff  float:NaN
                code.visitStmt2R(MOVE,0,10);
                code.visitLabel(L17);
                code.visitConstStmt(CONST_STRING,10,"json");
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 14,10},new Method("Ljavax/servlet/http/HttpServletRequest;","getParameter",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitLabel(L18);
                code.visitJumpStmt(IF_NEZ,6,-1,L23);
                code.visitConstStmt(CONST_4,10, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitStmt2R(MOVE,2,10);
                code.visitLabel(L19);
                code.visitConstStmt(CONST_STRING,10,"Jetty");
                code.visitTypeStmt(NEW_INSTANCE,11,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 11},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,12,"who=");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 11,12},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,11);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 11,9},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,11);
                code.visitConstStmt(CONST_STRING,12," what=");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 11,12},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,11);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 11,8},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,11);
                code.visitConstStmt(CONST_STRING,12," action=");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 11,12},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,11);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 11,0},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "I"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,11);
                code.visitConstStmt(CONST_STRING,12," json=");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 11,12},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,11);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 11,2},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Z"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,11);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 11},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,11);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 10,11},new Method("Landroid/util/Log;","d",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"I"));
                code.visitLabel(L20);
                code.visitSparseSwitchStmt(PACKED_SWITCH,0,-1,new DexLabel[]{L24,L6,L31,L30,L33,L32});
                code.visitLabel(L21);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 13,14,15},new Method("Lorg/mortbay/ijetty/console/AbstractContactsServlet;","handleDefault",new String[]{ "Ljavax/servlet/http/HttpServletRequest;","Ljavax/servlet/http/HttpServletResponse;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L6);
                code.visitLabel(L22);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Ljava/lang/String;","trim",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,10);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 10},new Method("Ljava/lang/Integer;","parseInt",new String[]{ "Ljava/lang/String;"},"I"));
                code.visitStmt1R(MOVE_RESULT,10);
                code.visitStmt2R(MOVE,0,10);
                code.visitJumpStmt(GOTO,-1,-1,L17);
                code.visitLabel(L23);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Ljava/lang/String;","trim",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,10);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 10},new Method("Ljava/lang/Integer;","parseInt",new String[]{ "Ljava/lang/String;"},"I"));
                code.visitStmt1R(MOVE_RESULT,10);
                code.visitConstStmt(CONST_4,11, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                DexLabel L35=new DexLabel();
                code.visitJumpStmt(IF_NE,10,11,L35);
                code.visitConstStmt(CONST_4,10, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitStmt2R(MOVE,2,10);
                code.visitJumpStmt(GOTO,-1,-1,L19);
                code.visitLabel(L35);
                code.visitConstStmt(CONST_4,10, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitStmt2R(MOVE,2,10);
                code.visitJumpStmt(GOTO,-1,-1,L19);
                code.visitLabel(L24);
                code.visitJumpStmt(IF_NEZ,8,-1,L26);
                code.visitJumpStmt(IF_EQZ,9,-1,L26);
                code.visitLabel(L25);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 13,14,15,9},new Method("Lorg/mortbay/ijetty/console/AbstractContactsServlet;","handleGetUser",new String[]{ "Ljavax/servlet/http/HttpServletRequest;","Ljavax/servlet/http/HttpServletResponse;","Ljava/lang/String;"},"V"));
                code.visitJumpStmt(GOTO_16,-1,-1,L6);
                code.visitLabel(L26);
                code.visitJumpStmt(IF_NEZ,8,-1,L28);
                code.visitJumpStmt(IF_NEZ,9,-1,L28);
                code.visitLabel(L27);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 13,14,15},new Method("Lorg/mortbay/ijetty/console/AbstractContactsServlet;","handleGetUsers",new String[]{ "Ljavax/servlet/http/HttpServletRequest;","Ljavax/servlet/http/HttpServletResponse;"},"V"));
                code.visitJumpStmt(GOTO_16,-1,-1,L6);
                code.visitLabel(L28);
                code.visitConstStmt(CONST_STRING,10,"photo");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8},new Method("Ljava/lang/String;","trim",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,11);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10,11},new Method("Ljava/lang/String;","equals",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,10);
                code.visitJumpStmt(IF_EQZ,10,-1,L6);
                code.visitLabel(L29);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 13,14,15,9},new Method("Lorg/mortbay/ijetty/console/AbstractContactsServlet;","handleGetImage",new String[]{ "Ljavax/servlet/http/HttpServletRequest;","Ljavax/servlet/http/HttpServletResponse;","Ljava/lang/String;"},"V"));
                code.visitJumpStmt(GOTO_16,-1,-1,L6);
                code.visitLabel(L30);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 13,14,15},new Method("Lorg/mortbay/ijetty/console/AbstractContactsServlet;","handleAddUser",new String[]{ "Ljavax/servlet/http/HttpServletRequest;","Ljavax/servlet/http/HttpServletResponse;"},"V"));
                code.visitJumpStmt(GOTO_16,-1,-1,L6);
                code.visitLabel(L31);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 13,14,15,9},new Method("Lorg/mortbay/ijetty/console/AbstractContactsServlet;","handleEditUser",new String[]{ "Ljavax/servlet/http/HttpServletRequest;","Ljavax/servlet/http/HttpServletResponse;","Ljava/lang/String;"},"V"));
                code.visitJumpStmt(GOTO_16,-1,-1,L6);
                code.visitLabel(L32);
                code.visitConstStmt(CONST_STRING,10,"id");
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 14,10},new Method("Ljavax/servlet/http/HttpServletRequest;","getParameter",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,10);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 13,14,15,10},new Method("Lorg/mortbay/ijetty/console/AbstractContactsServlet;","handleSaveUser",new String[]{ "Ljavax/servlet/http/HttpServletRequest;","Ljavax/servlet/http/HttpServletResponse;","Ljava/lang/String;"},"V"));
                code.visitJumpStmt(GOTO_16,-1,-1,L6);
                code.visitLabel(L33);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 13,14,15,9},new Method("Lorg/mortbay/ijetty/console/AbstractContactsServlet;","handleDeleteUser",new String[]{ "Ljavax/servlet/http/HttpServletRequest;","Ljavax/servlet/http/HttpServletResponse;","Ljava/lang/String;"},"V"));
                code.visitJumpStmt(GOTO_16,-1,-1,L6);
                code.visitLabel(L34);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m003_doPost(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Lorg/mortbay/ijetty/console/AbstractContactsServlet;","doPost",new String[]{ "Ljavax/servlet/http/HttpServletRequest;","Ljavax/servlet/http/HttpServletResponse;"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljavax/servlet/ServletException;"));
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"request");
                ddv.visitParameterName(1,"response");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(86,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(87,L1);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1,2},new Method("Lorg/mortbay/ijetty/console/AbstractContactsServlet;","doGet",new String[]{ "Ljavax/servlet/http/HttpServletRequest;","Ljavax/servlet/http/HttpServletResponse;"},"V"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m004_getContentResolver(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/ijetty/console/AbstractContactsServlet;","getContentResolver",new String[]{ },"Landroid/content/ContentResolver;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(79,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/ijetty/console/AbstractContactsServlet;","resolver","Landroid/content/ContentResolver;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m005_handleAddUser(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Lorg/mortbay/ijetty/console/AbstractContactsServlet;","handleAddUser",new String[]{ "Ljavax/servlet/http/HttpServletRequest;","Ljavax/servlet/http/HttpServletResponse;"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljavax/servlet/ServletException;"));
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            mv.visitEnd();
        }
    }
    public static void m006_handleDefault(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Lorg/mortbay/ijetty/console/AbstractContactsServlet;","handleDefault",new String[]{ "Ljavax/servlet/http/HttpServletRequest;","Ljavax/servlet/http/HttpServletResponse;"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljavax/servlet/ServletException;"));
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            mv.visitEnd();
        }
    }
    public static void m007_handleDeleteUser(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Lorg/mortbay/ijetty/console/AbstractContactsServlet;","handleDeleteUser",new String[]{ "Ljavax/servlet/http/HttpServletRequest;","Ljavax/servlet/http/HttpServletResponse;","Ljava/lang/String;"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljavax/servlet/ServletException;"));
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            mv.visitEnd();
        }
    }
    public static void m008_handleEditUser(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Lorg/mortbay/ijetty/console/AbstractContactsServlet;","handleEditUser",new String[]{ "Ljavax/servlet/http/HttpServletRequest;","Ljavax/servlet/http/HttpServletResponse;","Ljava/lang/String;"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljavax/servlet/ServletException;"));
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            mv.visitEnd();
        }
    }
    public static void m009_handleGetImage(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/ijetty/console/AbstractContactsServlet;","handleGetImage",new String[]{ "Ljavax/servlet/http/HttpServletRequest;","Ljavax/servlet/http/HttpServletResponse;","Ljava/lang/String;"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(10);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"request");
                ddv.visitParameterName(1,"response");
                ddv.visitParameterName(2,"who");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(206,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(207,L1);
                ddv.visitStartLocal(2,L1,"personUri","Landroid/net/Uri;",null);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(208,L2);
                ddv.visitStartLocal(0,L2,"is","Ljava/io/InputStream;",null);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(210,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(211,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(212,L5);
                ddv.visitStartLocal(1,L5,"os","Ljava/io/OutputStream;",null);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(213,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(221,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(217,L8);
                ddv.visitEndLocal(1,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(218,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(219,L10);
                ddv.visitRestartLocal(1,L10);
                code.visitLabel(L0);
                code.visitFieldStmt(SGET_OBJECT,3,-1,new Field("Landroid/provider/Contacts$People;","CONTENT_URI","Landroid/net/Uri;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9},new Method("Ljava/lang/String;","trim",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 4},new Method("Ljava/lang/Long;","valueOf",new String[]{ "Ljava/lang/String;"},"Ljava/lang/Long;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Ljava/lang/Long;","longValue",new String[]{ },"J"));
                code.visitStmt1R(MOVE_RESULT_WIDE,4);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 3,4,5},new Method("Landroid/content/ContentUris;","withAppendedId",new String[]{ "Landroid/net/Uri;","J"},"Landroid/net/Uri;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Lorg/mortbay/ijetty/console/AbstractContactsServlet;","getContentResolver",new String[]{ },"Landroid/content/ContentResolver;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 3,2},new Method("Landroid/provider/Contacts$People;","openContactPhotoInputStream",new String[]{ "Landroid/content/ContentResolver;","Landroid/net/Uri;"},"Ljava/io/InputStream;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L2);
                code.visitJumpStmt(IF_NEZ,0,-1,L8);
                code.visitLabel(L3);
                code.visitConstStmt(CONST_STRING,3,"image/jpeg");
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 8,3},new Method("Ljavax/servlet/http/HttpServletResponse;","setContentType",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L4);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 8},new Method("Ljavax/servlet/http/HttpServletResponse;","getOutputStream",new String[]{ },"Ljavax/servlet/ServletOutputStream;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Lorg/mortbay/ijetty/console/AbstractContactsServlet;","getServletContext",new String[]{ },"Ljavax/servlet/ServletContext;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitConstStmt(CONST_STRING,4,"/android.jpg");
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 3,4},new Method("Ljavax/servlet/ServletContext;","getResourceAsStream",new String[]{ "Ljava/lang/String;"},"Ljava/io/InputStream;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L6);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0,1},new Method("Lorg/mortbay/util/IO;","copy",new String[]{ "Ljava/io/InputStream;","Ljava/io/OutputStream;"},"V"));
                code.visitLabel(L7);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L8);
                code.visitConstStmt(CONST_STRING,3,"image/png");
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 8,3},new Method("Ljavax/servlet/http/HttpServletResponse;","setContentType",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L9);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 8},new Method("Ljavax/servlet/http/HttpServletResponse;","getOutputStream",new String[]{ },"Ljavax/servlet/ServletOutputStream;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L10);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0,1},new Method("Lorg/mortbay/util/IO;","copy",new String[]{ "Ljava/io/InputStream;","Ljava/io/OutputStream;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L7);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m010_handleGetUser(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Lorg/mortbay/ijetty/console/AbstractContactsServlet;","handleGetUser",new String[]{ "Ljavax/servlet/http/HttpServletRequest;","Ljavax/servlet/http/HttpServletResponse;","Ljava/lang/String;"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljavax/servlet/ServletException;"));
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            mv.visitEnd();
        }
    }
    public static void m011_handleGetUsers(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Lorg/mortbay/ijetty/console/AbstractContactsServlet;","handleGetUsers",new String[]{ "Ljavax/servlet/http/HttpServletRequest;","Ljavax/servlet/http/HttpServletResponse;"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljavax/servlet/ServletException;"));
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            mv.visitEnd();
        }
    }
    public static void m012_handleSaveUser(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Lorg/mortbay/ijetty/console/AbstractContactsServlet;","handleSaveUser",new String[]{ "Ljavax/servlet/http/HttpServletRequest;","Ljavax/servlet/http/HttpServletResponse;","Ljava/lang/String;"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljavax/servlet/ServletException;"));
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            mv.visitEnd();
        }
    }
    public static void m013_init(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/ijetty/console/AbstractContactsServlet;","init",new String[]{ "Ljavax/servlet/ServletConfig;"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljavax/servlet/ServletException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"config");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(72,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(73,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(74,L2);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_SUPER,new int[]{ 2,3},new Method("Ljavax/servlet/http/HttpServlet;","init",new String[]{ "Ljavax/servlet/ServletConfig;"},"V"));
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/ijetty/console/AbstractContactsServlet;","getServletContext",new String[]{ },"Ljavax/servlet/ServletContext;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitConstStmt(CONST_STRING,1,"contentResolver");
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,1},new Method("Ljavax/servlet/ServletContext;","getAttribute",new String[]{ "Ljava/lang/String;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitTypeStmt(CHECK_CAST,0,-1,"Landroid/content/ContentResolver;");
                code.visitFieldStmt(IPUT_OBJECT,0,2,new Field("Lorg/mortbay/ijetty/console/AbstractContactsServlet;","resolver","Landroid/content/ContentResolver;"));
                code.visitLabel(L2);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m014_saveUserFormData(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/ijetty/console/AbstractContactsServlet;","saveUserFormData",new String[]{ "Ljavax/servlet/http/HttpServletRequest;","Ljavax/servlet/http/HttpServletResponse;","Ljava/lang/String;"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljavax/servlet/ServletException;"));
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(32);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"request");
                ddv.visitParameterName(1,"response");
                ddv.visitParameterName(2,"id");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(226,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(227,L1);
                ddv.visitStartLocal(18,L1,"person","Landroid/content/ContentValues;",null);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(228,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(229,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(230,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(232,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(233,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(235,L7);
                ddv.visitRestartLocal(31,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(236,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(238,L9);
                ddv.visitStartLocal(5,L9,"created","Z",null);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(240,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(241,L11);
                ddv.visitRestartLocal(31,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(242,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(245,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(246,L14);
                ddv.visitStartLocal(21,L14,"photo","Ljava/io/File;",null);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(249,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(251,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(252,L17);
                ddv.visitStartLocal(8,L17,"deletedPhones","Ljava/util/List;","Ljava/util/List<Ljava/lang/String;>;");
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(253,L18);
                ddv.visitStartLocal(15,L18,"modifiedPhones","Ljava/util/Map;","Ljava/util/Map<Ljava/lang/String;Landroid/content/ContentValues;>;");
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(254,L19);
                ddv.visitStartLocal(7,L19,"deletedContacts","Ljava/util/List;","Ljava/util/List<Ljava/lang/String;>;");
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(255,L20);
                ddv.visitStartLocal(14,L20,"modifiedContacts","Ljava/util/Map;","Ljava/util/Map<Ljava/lang/String;Landroid/content/ContentValues;>;");
                DexLabel L21=new DexLabel();
                ddv.visitLineNumber(256,L21);
                ddv.visitStartLocal(9,L21,"enumeration","Ljava/util/Enumeration;",null);
                DexLabel L22=new DexLabel();
                ddv.visitLineNumber(258,L22);
                DexLabel L23=new DexLabel();
                ddv.visitLineNumber(259,L23);
                ddv.visitStartLocal(16,L23,"name","Ljava/lang/String;",null);
                DexLabel L24=new DexLabel();
                ddv.visitLineNumber(262,L24);
                DexLabel L25=new DexLabel();
                ddv.visitLineNumber(263,L25);
                ddv.visitStartLocal(19,L25,"phId","Ljava/lang/String;",null);
                DexLabel L26=new DexLabel();
                ddv.visitLineNumber(264,L26);
                DexLabel L27=new DexLabel();
                ddv.visitLineNumber(265,L27);
                ddv.visitStartLocal(24,L27,"val","Ljava/lang/String;",null);
                DexLabel L28=new DexLabel();
                ddv.visitLineNumber(266,L28);
                DexLabel L29=new DexLabel();
                ddv.visitLineNumber(229,L29);
                ddv.visitEndLocal(5,L29);
                ddv.visitEndLocal(21,L29);
                ddv.visitEndLocal(8,L29);
                ddv.visitEndLocal(15,L29);
                ddv.visitEndLocal(7,L29);
                ddv.visitEndLocal(14,L29);
                ddv.visitEndLocal(9,L29);
                ddv.visitEndLocal(16,L29);
                ddv.visitEndLocal(19,L29);
                ddv.visitEndLocal(24,L29);
                DexLabel L30=new DexLabel();
                ddv.visitLineNumber(230,L30);
                DexLabel L31=new DexLabel();
                ddv.visitLineNumber(232,L31);
                DexLabel L32=new DexLabel();
                ddv.visitLineNumber(233,L32);
                DexLabel L33=new DexLabel();
                ddv.visitLineNumber(268,L33);
                ddv.visitRestartLocal(5,L33);
                ddv.visitRestartLocal(7,L33);
                ddv.visitRestartLocal(8,L33);
                ddv.visitRestartLocal(9,L33);
                ddv.visitRestartLocal(14,L33);
                ddv.visitRestartLocal(15,L33);
                ddv.visitRestartLocal(16,L33);
                ddv.visitRestartLocal(21,L33);
                DexLabel L34=new DexLabel();
                ddv.visitLineNumber(270,L34);
                DexLabel L35=new DexLabel();
                ddv.visitLineNumber(271,L35);
                ddv.visitStartLocal(13,L35,"methodId","Ljava/lang/String;",null);
                DexLabel L36=new DexLabel();
                ddv.visitLineNumber(272,L36);
                DexLabel L37=new DexLabel();
                ddv.visitLineNumber(273,L37);
                ddv.visitRestartLocal(24,L37);
                DexLabel L38=new DexLabel();
                ddv.visitLineNumber(274,L38);
                DexLabel L39=new DexLabel();
                ddv.visitLineNumber(276,L39);
                ddv.visitEndLocal(13,L39);
                ddv.visitEndLocal(24,L39);
                DexLabel L40=new DexLabel();
                ddv.visitLineNumber(278,L40);
                DexLabel L41=new DexLabel();
                ddv.visitLineNumber(279,L41);
                ddv.visitRestartLocal(19,L41);
                DexLabel L42=new DexLabel();
                ddv.visitLineNumber(281,L42);
                DexLabel L43=new DexLabel();
                ddv.visitLineNumber(282,L43);
                DexLabel L44=new DexLabel();
                ddv.visitLineNumber(283,L44);
                ddv.visitStartLocal(23,L44,"typeStr","Ljava/lang/String;",null);
                DexLabel L45=new DexLabel();
                ddv.visitLineNumber(284,L45);
                ddv.visitStartLocal(17,L45,"number","Ljava/lang/String;",null);
                DexLabel L46=new DexLabel();
                ddv.visitLineNumber(285,L46);
                ddv.visitStartLocal(20,L46,"phone","Landroid/content/ContentValues;",null);
                DexLabel L47=new DexLabel();
                ddv.visitLineNumber(286,L47);
                DexLabel L48=new DexLabel();
                ddv.visitLineNumber(287,L48);
                DexLabel L49=new DexLabel();
                ddv.visitLineNumber(290,L49);
                ddv.visitEndLocal(19,L49);
                ddv.visitEndLocal(23,L49);
                ddv.visitEndLocal(17,L49);
                ddv.visitEndLocal(20,L49);
                DexLabel L50=new DexLabel();
                ddv.visitLineNumber(292,L50);
                DexLabel L51=new DexLabel();
                ddv.visitLineNumber(293,L51);
                ddv.visitRestartLocal(13,L51);
                DexLabel L52=new DexLabel();
                ddv.visitLineNumber(294,L52);
                DexLabel L53=new DexLabel();
                ddv.visitLineNumber(296,L53);
                DexLabel L54=new DexLabel();
                ddv.visitLineNumber(297,L54);
                ddv.visitStartLocal(12,L54,"kind","Ljava/lang/String;",null);
                DexLabel L55=new DexLabel();
                ddv.visitLineNumber(298,L55);
                ddv.visitStartLocal(22,L55,"type","Ljava/lang/String;",null);
                DexLabel L56=new DexLabel();
                ddv.visitLineNumber(299,L56);
                ddv.visitRestartLocal(24,L56);
                DexLabel L57=new DexLabel();
                ddv.visitLineNumber(300,L57);
                ddv.visitStartLocal(4,L57,"contactMethod","Landroid/content/ContentValues;",null);
                DexLabel L58=new DexLabel();
                ddv.visitLineNumber(301,L58);
                DexLabel L59=new DexLabel();
                ddv.visitLineNumber(302,L59);
                DexLabel L60=new DexLabel();
                ddv.visitLineNumber(303,L60);
                DexLabel L61=new DexLabel();
                ddv.visitLineNumber(304,L61);
                DexLabel L62=new DexLabel();
                ddv.visitLineNumber(310,L62);
                ddv.visitEndLocal(16,L62);
                ddv.visitEndLocal(13,L62);
                ddv.visitEndLocal(12,L62);
                ddv.visitEndLocal(22,L62);
                ddv.visitEndLocal(24,L62);
                ddv.visitEndLocal(4,L62);
                DexLabel L63=new DexLabel();
                ddv.visitStartLocal(10,L63,"i$","Ljava/util/Iterator;",null);
                DexLabel L64=new DexLabel();
                ddv.visitLineNumber(312,L64);
                ddv.visitStartLocal(11,L64,"key","Ljava/lang/String;",null);
                DexLabel L65=new DexLabel();
                ddv.visitLineNumber(313,L65);
                ddv.visitRestartLocal(20,L65);
                DexLabel L66=new DexLabel();
                ddv.visitLineNumber(316,L66);
                DexLabel L67=new DexLabel();
                ddv.visitLineNumber(317,L67);
                ddv.visitRestartLocal(17,L67);
                DexLabel L68=new DexLabel();
                ddv.visitLineNumber(319,L68);
                DexLabel L69=new DexLabel();
                ddv.visitLineNumber(320,L69);
                DexLabel L70=new DexLabel();
                ddv.visitLineNumber(326,L70);
                ddv.visitEndLocal(17,L70);
                DexLabel L71=new DexLabel();
                ddv.visitLineNumber(327,L71);
                DexLabel L72=new DexLabel();
                ddv.visitLineNumber(331,L72);
                ddv.visitEndLocal(11,L72);
                ddv.visitEndLocal(20,L72);
                DexLabel L73=new DexLabel();
                ddv.visitLineNumber(333,L73);
                ddv.visitRestartLocal(19,L73);
                DexLabel L74=new DexLabel();
                ddv.visitLineNumber(334,L74);
                DexLabel L75=new DexLabel();
                ddv.visitLineNumber(339,L75);
                ddv.visitEndLocal(19,L75);
                DexLabel L76=new DexLabel();
                ddv.visitRestartLocal(10,L76);
                DexLabel L77=new DexLabel();
                ddv.visitLineNumber(341,L77);
                ddv.visitRestartLocal(11,L77);
                DexLabel L78=new DexLabel();
                ddv.visitLineNumber(342,L78);
                ddv.visitRestartLocal(4,L78);
                DexLabel L79=new DexLabel();
                ddv.visitLineNumber(345,L79);
                DexLabel L80=new DexLabel();
                ddv.visitLineNumber(346,L80);
                ddv.visitStartLocal(6,L80,"data","Ljava/lang/String;",null);
                DexLabel L81=new DexLabel();
                ddv.visitLineNumber(347,L81);
                DexLabel L82=new DexLabel();
                ddv.visitLineNumber(349,L82);
                DexLabel L83=new DexLabel();
                ddv.visitLineNumber(350,L83);
                DexLabel L84=new DexLabel();
                ddv.visitLineNumber(356,L84);
                ddv.visitEndLocal(6,L84);
                DexLabel L85=new DexLabel();
                ddv.visitLineNumber(357,L85);
                DexLabel L86=new DexLabel();
                ddv.visitLineNumber(362,L86);
                ddv.visitEndLocal(11,L86);
                ddv.visitEndLocal(4,L86);
                DexLabel L87=new DexLabel();
                ddv.visitRestartLocal(10,L87);
                DexLabel L88=new DexLabel();
                ddv.visitLineNumber(364,L88);
                ddv.visitRestartLocal(13,L88);
                DexLabel L89=new DexLabel();
                ddv.visitLineNumber(368,L89);
                ddv.visitEndLocal(13,L89);
                DexLabel L90=new DexLabel();
                ddv.visitLineNumber(369,L90);
                DexLabel L91=new DexLabel();
                ddv.visitLineNumber(370,L91);
                DexLabel L92=new DexLabel();
                ddv.visitLineNumber(371,L92);
                code.visitLabel(L0);
                code.visitTypeStmt(NEW_INSTANCE,18,-1,"Landroid/content/ContentValues;");
                code.visitMethodStmt(INVOKE_DIRECT_RANGE,new int[]{ 18},new Method("Landroid/content/ContentValues;","<init>",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitConstStmt(CONST_STRING,25,"name");
                code.visitConstStmt(CONST_STRING,26,"name");
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,29);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,26);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,1},new Method("Ljavax/servlet/http/HttpServletRequest;","getParameter",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,26);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,18);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,25);
                code.visitStmt2R(MOVE_OBJECT_FROM16,2,26);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1,2},new Method("Landroid/content/ContentValues;","put",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"V"));
                code.visitLabel(L2);
                code.visitConstStmt(CONST_STRING,25,"notes");
                code.visitConstStmt(CONST_STRING,26,"notes");
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,29);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,26);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,1},new Method("Ljavax/servlet/http/HttpServletRequest;","getParameter",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,26);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,18);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,25);
                code.visitStmt2R(MOVE_OBJECT_FROM16,2,26);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1,2},new Method("Landroid/content/ContentValues;","put",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"V"));
                code.visitLabel(L3);
                code.visitConstStmt(CONST_STRING,25,"starred");
                code.visitConstStmt(CONST_STRING,26,"starred");
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,29);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,26);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,1},new Method("Ljavax/servlet/http/HttpServletRequest;","getParameter",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,26);
                code.visitJumpStmt(IF_EQZ,26,-1,L29);
                code.visitConstStmt(CONST_16,26, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                DexLabel L93=new DexLabel();
                code.visitLabel(L93);
                code.visitMethodStmt(INVOKE_STATIC_RANGE,new int[]{ 26},new Method("Ljava/lang/Integer;","valueOf",new String[]{ "I"},"Ljava/lang/Integer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,26);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,18);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,25);
                code.visitStmt2R(MOVE_OBJECT_FROM16,2,26);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1,2},new Method("Landroid/content/ContentValues;","put",new String[]{ "Ljava/lang/String;","Ljava/lang/Integer;"},"V"));
                code.visitLabel(L4);
                code.visitConstStmt(CONST_STRING,25,"send_to_voicemail");
                code.visitConstStmt(CONST_STRING,26,"voicemail");
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,29);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,26);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,1},new Method("Ljavax/servlet/http/HttpServletRequest;","getParameter",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,26);
                code.visitJumpStmt(IF_EQZ,26,-1,L30);
                code.visitConstStmt(CONST_16,26, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                DexLabel L94=new DexLabel();
                code.visitLabel(L94);
                code.visitMethodStmt(INVOKE_STATIC_RANGE,new int[]{ 26},new Method("Ljava/lang/Integer;","valueOf",new String[]{ "I"},"Ljava/lang/Integer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,26);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,18);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,25);
                code.visitStmt2R(MOVE_OBJECT_FROM16,2,26);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1,2},new Method("Landroid/content/ContentValues;","put",new String[]{ "Ljava/lang/String;","Ljava/lang/Integer;"},"V"));
                code.visitLabel(L5);
                code.visitJumpStmt(IF_NEZ,31,-1,L31);
                code.visitLabel(L6);
                code.visitJumpStmt(IF_NEZ,31,-1,L32);
                code.visitLabel(L7);
                code.visitConstStmt(CONST_STRING,25,"Jetty");
                code.visitTypeStmt(NEW_INSTANCE,26,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT_RANGE,new int[]{ 26},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,27,"Saving: name=");
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 26,27},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,26);
                code.visitConstStmt(CONST_STRING,27,"name");
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,29);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,27);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,1},new Method("Ljavax/servlet/http/HttpServletRequest;","getParameter",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,27);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 26,27},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,26);
                code.visitConstStmt(CONST_STRING,27," notes=");
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 26,27},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,26);
                code.visitConstStmt(CONST_STRING,27,"notes");
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,29);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,27);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,1},new Method("Ljavax/servlet/http/HttpServletRequest;","getParameter",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,27);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 26,27},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,26);
                code.visitConstStmt(CONST_STRING,27," id=");
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 26,27},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,26);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,26);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,31);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,26);
                code.visitConstStmt(CONST_STRING,27," starred=");
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 26,27},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,26);
                code.visitConstStmt(CONST_STRING,27,"starred");
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,29);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,27);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,1},new Method("Ljavax/servlet/http/HttpServletRequest;","getParameter",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,27);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 26,27},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,26);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 26},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,26);
                code.visitMethodStmt(INVOKE_STATIC_RANGE,new int[]{ 25,26},new Method("Landroid/util/Log;","d",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"I"));
                code.visitLabel(L8);
                code.visitConstStmt(CONST_4,5, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L9);
                code.visitJumpStmt(IF_NEZ,31,-1,L13);
                code.visitLabel(L10);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 28},new Method("Lorg/mortbay/ijetty/console/AbstractContactsServlet;","getContentResolver",new String[]{ },"Landroid/content/ContentResolver;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,25);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,25);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,18);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0,1},new Method("Lorg/mortbay/ijetty/console/User;","create",new String[]{ "Landroid/content/ContentResolver;","Landroid/content/ContentValues;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,31);
                code.visitLabel(L11);
                code.visitConstStmt(CONST_STRING,25,"Jetty");
                code.visitTypeStmt(NEW_INSTANCE,26,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT_RANGE,new int[]{ 26},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,27,"Inserted new user id ");
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 26,27},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,26);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,26);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,31);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,26);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 26},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,26);
                code.visitMethodStmt(INVOKE_STATIC_RANGE,new int[]{ 25,26},new Method("Landroid/util/Log;","d",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"I"));
                code.visitLabel(L12);
                code.visitConstStmt(CONST_4,5, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitLabel(L13);
                code.visitConstStmt(CONST_STRING,25,"new-pic");
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,29);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,25);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,1},new Method("Ljavax/servlet/http/HttpServletRequest;","getAttribute",new String[]{ "Ljava/lang/String;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,21);
                code.visitTypeStmt(CHECK_CAST,21,-1,"Ljava/io/File;");
                code.visitLabel(L14);
                code.visitJumpStmt(IF_EQZ,21,-1,L16);
                code.visitLabel(L15);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 28},new Method("Lorg/mortbay/ijetty/console/AbstractContactsServlet;","getContentResolver",new String[]{ },"Landroid/content/ContentResolver;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,25);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,25);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,31);
                code.visitStmt2R(MOVE_OBJECT_FROM16,2,21);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0,1,2},new Method("Lorg/mortbay/ijetty/console/User;","savePhoto",new String[]{ "Landroid/content/ContentResolver;","Ljava/lang/String;","Ljava/io/File;"},"V"));
                code.visitLabel(L16);
                code.visitTypeStmt(NEW_INSTANCE,8,-1,"Ljava/util/ArrayList;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 8},new Method("Ljava/util/ArrayList;","<init>",new String[]{ },"V"));
                code.visitLabel(L17);
                code.visitTypeStmt(NEW_INSTANCE,15,-1,"Ljava/util/HashMap;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 15},new Method("Ljava/util/HashMap;","<init>",new String[]{ },"V"));
                code.visitLabel(L18);
                code.visitTypeStmt(NEW_INSTANCE,7,-1,"Ljava/util/ArrayList;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 7},new Method("Ljava/util/ArrayList;","<init>",new String[]{ },"V"));
                code.visitLabel(L19);
                code.visitTypeStmt(NEW_INSTANCE,14,-1,"Ljava/util/HashMap;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 14},new Method("Ljava/util/HashMap;","<init>",new String[]{ },"V"));
                code.visitLabel(L20);
                code.visitMethodStmt(INVOKE_INTERFACE_RANGE,new int[]{ 29},new Method("Ljavax/servlet/http/HttpServletRequest;","getParameterNames",new String[]{ },"Ljava/util/Enumeration;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,9);
                code.visitLabel(L21);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 9},new Method("Ljava/util/Enumeration;","hasMoreElements",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,25);
                code.visitJumpStmt(IF_EQZ,25,-1,L62);
                code.visitLabel(L22);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 9},new Method("Ljava/util/Enumeration;","nextElement",new String[]{ },"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,16);
                code.visitTypeStmt(CHECK_CAST,16,-1,"Ljava/lang/String;");
                code.visitLabel(L23);
                code.visitConstStmt(CONST_STRING,25,"phone-del-");
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,16);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,25);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/String;","startsWith",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,25);
                code.visitJumpStmt(IF_EQZ,25,-1,L33);
                code.visitLabel(L24);
                code.visitConstStmt(CONST_16,25, Integer.valueOf(10)); // int: 0x0000000a  float:0.000000
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,16);
                code.visitStmt2R(MOVE_FROM16,1,25);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/String;","substring",new String[]{ "I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,19);
                code.visitLabel(L25);
                code.visitConstStmt(CONST_STRING,25,"Jetty");
                code.visitTypeStmt(NEW_INSTANCE,26,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT_RANGE,new int[]{ 26},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,27,"Phone to delete: ");
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 26,27},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,26);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,26);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,19);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,26);
                code.visitConstStmt(CONST_STRING,27," from ");
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 26,27},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,26);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,26);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,16);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,26);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 26},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,26);
                code.visitMethodStmt(INVOKE_STATIC_RANGE,new int[]{ 25,26},new Method("Landroid/util/Log;","d",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"I"));
                code.visitLabel(L26);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,29);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,16);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,1},new Method("Ljavax/servlet/http/HttpServletRequest;","getParameter",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,24);
                code.visitLabel(L27);
                code.visitConstStmt(CONST_STRING,25,"del");
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,25);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,24);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/String;","equals",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,25);
                code.visitJumpStmt(IF_EQZ,25,-1,L21);
                code.visitLabel(L28);
                code.visitStmt2R(MOVE_OBJECT,0,8);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,19);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,1},new Method("Ljava/util/List;","add",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitJumpStmt(GOTO,-1,-1,L21);
                code.visitLabel(L29);
                code.visitConstStmt(CONST_16,26, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitJumpStmt(GOTO_16,-1,-1,L93);
                code.visitLabel(L30);
                code.visitConstStmt(CONST_16,26, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitJumpStmt(GOTO_16,-1,-1,L94);
                code.visitLabel(L31);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 31},new Method("Ljava/lang/String;","trim",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,25);
                code.visitStmt2R(MOVE_OBJECT_FROM16,31,25);
                code.visitJumpStmt(GOTO_16,-1,-1,L6);
                code.visitLabel(L32);
                code.visitConstStmt(CONST_STRING,25,"");
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,25);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,31);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/String;","equals",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,25);
                code.visitJumpStmt(IF_EQZ,25,-1,L7);
                code.visitConstStmt(CONST_16,25, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitStmt2R(MOVE_OBJECT_FROM16,31,25);
                code.visitJumpStmt(GOTO_16,-1,-1,L7);
                code.visitLabel(L33);
                code.visitConstStmt(CONST_STRING,25,"contact-del-");
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,16);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,25);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/String;","startsWith",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,25);
                code.visitJumpStmt(IF_EQZ,25,-1,L39);
                code.visitLabel(L34);
                code.visitConstStmt(CONST_16,25, Integer.valueOf(12)); // int: 0x0000000c  float:0.000000
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,16);
                code.visitStmt2R(MOVE_FROM16,1,25);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/String;","substring",new String[]{ "I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,13);
                code.visitLabel(L35);
                code.visitConstStmt(CONST_STRING,25,"Jetty");
                code.visitTypeStmt(NEW_INSTANCE,26,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT_RANGE,new int[]{ 26},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,27,"Contact method to delete: ");
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 26,27},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,26);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,26);
                code.visitStmt2R(MOVE_OBJECT,1,13);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,26);
                code.visitConstStmt(CONST_STRING,27," from ");
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 26,27},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,26);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,26);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,16);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,26);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 26},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,26);
                code.visitMethodStmt(INVOKE_STATIC_RANGE,new int[]{ 25,26},new Method("Landroid/util/Log;","d",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"I"));
                code.visitLabel(L36);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,29);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,16);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,1},new Method("Ljavax/servlet/http/HttpServletRequest;","getParameter",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,24);
                code.visitLabel(L37);
                code.visitConstStmt(CONST_STRING,25,"del");
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,25);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,24);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/String;","equals",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,25);
                code.visitJumpStmt(IF_EQZ,25,-1,L21);
                code.visitLabel(L38);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 7,13},new Method("Ljava/util/List;","add",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitJumpStmt(GOTO_16,-1,-1,L21);
                code.visitLabel(L39);
                code.visitConstStmt(CONST_STRING,25,"phone-type-");
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,16);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,25);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/String;","startsWith",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,25);
                code.visitJumpStmt(IF_EQZ,25,-1,L49);
                code.visitLabel(L40);
                code.visitConstStmt(CONST_16,25, Integer.valueOf(11)); // int: 0x0000000b  float:0.000000
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,16);
                code.visitStmt2R(MOVE_FROM16,1,25);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/String;","substring",new String[]{ "I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,19);
                code.visitLabel(L41);
                code.visitTypeStmt(NEW_INSTANCE,25,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT_RANGE,new int[]{ 25},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,26,"phone-del-");
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 25,26},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,25);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,25);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,19);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,25);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 25},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,25);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,29);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,25);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,1},new Method("Ljavax/servlet/http/HttpServletRequest;","getParameter",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,25);
                code.visitJumpStmt(IF_NEZ,25,-1,L21);
                code.visitLabel(L42);
                code.visitConstStmt(CONST_STRING,25,"Jetty");
                code.visitTypeStmt(NEW_INSTANCE,26,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT_RANGE,new int[]{ 26},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,27,"Modified phone ");
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 26,27},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,26);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,26);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,19);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,26);
                code.visitConstStmt(CONST_STRING,27," from ");
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 26,27},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,26);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,26);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,16);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,26);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 26},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,26);
                code.visitMethodStmt(INVOKE_STATIC_RANGE,new int[]{ 25,26},new Method("Landroid/util/Log;","d",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"I"));
                code.visitLabel(L43);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,29);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,16);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,1},new Method("Ljavax/servlet/http/HttpServletRequest;","getParameter",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,23);
                code.visitLabel(L44);
                code.visitTypeStmt(NEW_INSTANCE,25,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT_RANGE,new int[]{ 25},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,26,"phone-number-");
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 25,26},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,25);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,25);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,19);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,25);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 25},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,25);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,29);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,25);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,1},new Method("Ljavax/servlet/http/HttpServletRequest;","getParameter",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,17);
                code.visitLabel(L45);
                code.visitTypeStmt(NEW_INSTANCE,20,-1,"Landroid/content/ContentValues;");
                code.visitMethodStmt(INVOKE_DIRECT_RANGE,new int[]{ 20},new Method("Landroid/content/ContentValues;","<init>",new String[]{ },"V"));
                code.visitLabel(L46);
                code.visitConstStmt(CONST_STRING,25,"number");
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,20);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,25);
                code.visitStmt2R(MOVE_OBJECT_FROM16,2,17);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1,2},new Method("Landroid/content/ContentValues;","put",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"V"));
                code.visitLabel(L47);
                code.visitConstStmt(CONST_STRING,25,"type");
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,20);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,25);
                code.visitStmt2R(MOVE_OBJECT_FROM16,2,23);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1,2},new Method("Landroid/content/ContentValues;","put",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"V"));
                code.visitLabel(L48);
                code.visitStmt2R(MOVE_OBJECT,0,15);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,19);
                code.visitStmt2R(MOVE_OBJECT_FROM16,2,20);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,1,2},new Method("Ljava/util/Map;","put",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitJumpStmt(GOTO_16,-1,-1,L21);
                code.visitLabel(L49);
                code.visitConstStmt(CONST_STRING,25,"contact-kind-");
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,16);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,25);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/String;","startsWith",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,25);
                code.visitJumpStmt(IF_EQZ,25,-1,L21);
                code.visitLabel(L50);
                code.visitConstStmt(CONST_16,25, Integer.valueOf(13)); // int: 0x0000000d  float:0.000000
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,16);
                code.visitStmt2R(MOVE_FROM16,1,25);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/String;","substring",new String[]{ "I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,13);
                code.visitLabel(L51);
                code.visitConstStmt(CONST_STRING,25,"Jetty");
                code.visitTypeStmt(NEW_INSTANCE,26,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT_RANGE,new int[]{ 26},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,27,"Possible contact modification: ");
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 26,27},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,26);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,26);
                code.visitStmt2R(MOVE_OBJECT,1,13);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,26);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 26},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,26);
                code.visitMethodStmt(INVOKE_STATIC_RANGE,new int[]{ 25,26},new Method("Landroid/util/Log;","d",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"I"));
                code.visitLabel(L52);
                code.visitTypeStmt(NEW_INSTANCE,25,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT_RANGE,new int[]{ 25},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,26,"contact-del-");
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 25,26},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,25);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,25);
                code.visitStmt2R(MOVE_OBJECT,1,13);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,25);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 25},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,25);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,29);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,25);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,1},new Method("Ljavax/servlet/http/HttpServletRequest;","getParameter",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,25);
                code.visitJumpStmt(IF_NEZ,25,-1,L21);
                code.visitLabel(L53);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,29);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,16);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,1},new Method("Ljavax/servlet/http/HttpServletRequest;","getParameter",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,12);
                code.visitLabel(L54);
                code.visitTypeStmt(NEW_INSTANCE,25,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT_RANGE,new int[]{ 25},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,26,"contact-type-");
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 25,26},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,25);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,25);
                code.visitStmt2R(MOVE_OBJECT,1,13);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,25);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 25},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,25);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,29);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,25);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,1},new Method("Ljavax/servlet/http/HttpServletRequest;","getParameter",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,22);
                code.visitLabel(L55);
                code.visitTypeStmt(NEW_INSTANCE,25,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT_RANGE,new int[]{ 25},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,26,"contact-val-");
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 25,26},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,25);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,25);
                code.visitStmt2R(MOVE_OBJECT,1,13);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,25);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 25},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,25);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,29);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,25);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,1},new Method("Ljavax/servlet/http/HttpServletRequest;","getParameter",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,24);
                code.visitLabel(L56);
                code.visitTypeStmt(NEW_INSTANCE,4,-1,"Landroid/content/ContentValues;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 4},new Method("Landroid/content/ContentValues;","<init>",new String[]{ },"V"));
                code.visitLabel(L57);
                code.visitConstStmt(CONST_STRING,25,"kind");
                code.visitStmt2R(MOVE_OBJECT,0,4);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,25);
                code.visitStmt2R(MOVE_OBJECT,2,12);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1,2},new Method("Landroid/content/ContentValues;","put",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"V"));
                code.visitLabel(L58);
                code.visitConstStmt(CONST_STRING,25,"type");
                code.visitStmt2R(MOVE_OBJECT,0,4);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,25);
                code.visitStmt2R(MOVE_OBJECT_FROM16,2,22);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1,2},new Method("Landroid/content/ContentValues;","put",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"V"));
                code.visitLabel(L59);
                code.visitConstStmt(CONST_STRING,25,"data");
                code.visitStmt2R(MOVE_OBJECT,0,4);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,25);
                code.visitStmt2R(MOVE_OBJECT_FROM16,2,24);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1,2},new Method("Landroid/content/ContentValues;","put",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"V"));
                code.visitLabel(L60);
                code.visitConstStmt(CONST_STRING,25,"Jetty");
                code.visitTypeStmt(NEW_INSTANCE,26,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT_RANGE,new int[]{ 26},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,27,"Modified contact ");
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 26,27},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,26);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,26);
                code.visitStmt2R(MOVE_OBJECT,1,13);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,26);
                code.visitConstStmt(CONST_STRING,27," kind=");
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 26,27},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,26);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,26);
                code.visitStmt2R(MOVE_OBJECT,1,12);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,26);
                code.visitConstStmt(CONST_STRING,27," type=");
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 26,27},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,26);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,26);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,22);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,26);
                code.visitConstStmt(CONST_STRING,27," val=");
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 26,27},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,26);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,26);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,24);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,26);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 26},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,26);
                code.visitMethodStmt(INVOKE_STATIC_RANGE,new int[]{ 25,26},new Method("Landroid/util/Log;","d",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"I"));
                code.visitLabel(L61);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 14,13,4},new Method("Ljava/util/Map;","put",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitJumpStmt(GOTO_16,-1,-1,L21);
                code.visitLabel(L62);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 15},new Method("Ljava/util/Map;","keySet",new String[]{ },"Ljava/util/Set;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,25);
                code.visitMethodStmt(INVOKE_INTERFACE_RANGE,new int[]{ 25},new Method("Ljava/util/Set;","iterator",new String[]{ },"Ljava/util/Iterator;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,10);
                code.visitLabel(L63);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 10},new Method("Ljava/util/Iterator;","hasNext",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,25);
                code.visitJumpStmt(IF_EQZ,25,-1,L72);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 10},new Method("Ljava/util/Iterator;","next",new String[]{ },"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,11);
                code.visitTypeStmt(CHECK_CAST,11,-1,"Ljava/lang/String;");
                code.visitLabel(L64);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 15,11},new Method("Ljava/util/Map;","get",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,20);
                code.visitTypeStmt(CHECK_CAST,20,-1,"Landroid/content/ContentValues;");
                code.visitLabel(L65);
                code.visitConstStmt(CONST_STRING,25,"x");
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,25);
                code.visitStmt2R(MOVE_OBJECT,1,11);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/String;","equals",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,25);
                code.visitJumpStmt(IF_EQZ,25,-1,L70);
                code.visitLabel(L66);
                code.visitConstStmt(CONST_STRING,25,"number");
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,20);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,25);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Landroid/content/ContentValues;","getAsString",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,17);
                code.visitLabel(L67);
                code.visitJumpStmt(IF_EQZ,17,-1,L63);
                code.visitConstStmt(CONST_STRING,25,"");
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,25);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,17);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/String;","equals",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,25);
                code.visitJumpStmt(IF_NEZ,25,-1,L63);
                code.visitLabel(L68);
                code.visitConstStmt(CONST_STRING,25,"Jetty");
                code.visitTypeStmt(NEW_INSTANCE,26,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT_RANGE,new int[]{ 26},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,27,"Adding new phone with number ");
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 26,27},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,26);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,26);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,17);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,26);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 26},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,26);
                code.visitMethodStmt(INVOKE_STATIC_RANGE,new int[]{ 25,26},new Method("Landroid/util/Log;","d",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"I"));
                code.visitLabel(L69);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 28},new Method("Lorg/mortbay/ijetty/console/AbstractContactsServlet;","getContentResolver",new String[]{ },"Landroid/content/ContentResolver;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,25);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,25);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,20);
                code.visitStmt2R(MOVE_OBJECT_FROM16,2,31);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0,1,2},new Method("Lorg/mortbay/ijetty/console/Phone;","addPhone",new String[]{ "Landroid/content/ContentResolver;","Landroid/content/ContentValues;","Ljava/lang/String;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L63);
                code.visitLabel(L70);
                code.visitConstStmt(CONST_STRING,25,"Jetty");
                code.visitTypeStmt(NEW_INSTANCE,26,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT_RANGE,new int[]{ 26},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,27,"Saving phone id=");
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 26,27},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,26);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,26);
                code.visitStmt2R(MOVE_OBJECT,1,11);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,26);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 26},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,26);
                code.visitMethodStmt(INVOKE_STATIC_RANGE,new int[]{ 25,26},new Method("Landroid/util/Log;","d",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"I"));
                code.visitLabel(L71);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 28},new Method("Lorg/mortbay/ijetty/console/AbstractContactsServlet;","getContentResolver",new String[]{ },"Landroid/content/ContentResolver;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,25);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,25);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,20);
                code.visitStmt2R(MOVE_OBJECT,2,11);
                code.visitStmt2R(MOVE_OBJECT_FROM16,3,31);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0,1,2,3},new Method("Lorg/mortbay/ijetty/console/Phone;","savePhone",new String[]{ "Landroid/content/ContentResolver;","Landroid/content/ContentValues;","Ljava/lang/String;","Ljava/lang/String;"},"V"));
                code.visitJumpStmt(GOTO_16,-1,-1,L63);
                code.visitLabel(L72);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 8},new Method("Ljava/util/List;","iterator",new String[]{ },"Ljava/util/Iterator;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,10);
                DexLabel L95=new DexLabel();
                code.visitLabel(L95);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 10},new Method("Ljava/util/Iterator;","hasNext",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,25);
                code.visitJumpStmt(IF_EQZ,25,-1,L75);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 10},new Method("Ljava/util/Iterator;","next",new String[]{ },"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,19);
                code.visitTypeStmt(CHECK_CAST,19,-1,"Ljava/lang/String;");
                code.visitLabel(L73);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 28},new Method("Lorg/mortbay/ijetty/console/AbstractContactsServlet;","getContentResolver",new String[]{ },"Landroid/content/ContentResolver;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,25);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,25);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,19);
                code.visitStmt2R(MOVE_OBJECT_FROM16,2,31);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0,1,2},new Method("Lorg/mortbay/ijetty/console/Phone;","deletePhone",new String[]{ "Landroid/content/ContentResolver;","Ljava/lang/String;","Ljava/lang/String;"},"V"));
                code.visitLabel(L74);
                code.visitConstStmt(CONST_STRING,25,"Jetty");
                code.visitTypeStmt(NEW_INSTANCE,26,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT_RANGE,new int[]{ 26},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,27,"Deleted phone ");
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 26,27},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,26);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,26);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,19);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,26);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 26},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,26);
                code.visitMethodStmt(INVOKE_STATIC_RANGE,new int[]{ 25,26},new Method("Landroid/util/Log;","d",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"I"));
                code.visitJumpStmt(GOTO,-1,-1,L95);
                code.visitLabel(L75);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 14},new Method("Ljava/util/Map;","keySet",new String[]{ },"Ljava/util/Set;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,25);
                code.visitMethodStmt(INVOKE_INTERFACE_RANGE,new int[]{ 25},new Method("Ljava/util/Set;","iterator",new String[]{ },"Ljava/util/Iterator;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,10);
                code.visitLabel(L76);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 10},new Method("Ljava/util/Iterator;","hasNext",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,25);
                code.visitJumpStmt(IF_EQZ,25,-1,L86);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 10},new Method("Ljava/util/Iterator;","next",new String[]{ },"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,11);
                code.visitTypeStmt(CHECK_CAST,11,-1,"Ljava/lang/String;");
                code.visitLabel(L77);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 14,11},new Method("Ljava/util/Map;","get",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitTypeStmt(CHECK_CAST,4,-1,"Landroid/content/ContentValues;");
                code.visitLabel(L78);
                code.visitConstStmt(CONST_STRING,25,"x");
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,25);
                code.visitStmt2R(MOVE_OBJECT,1,11);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/String;","equals",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,25);
                code.visitJumpStmt(IF_EQZ,25,-1,L84);
                code.visitLabel(L79);
                code.visitConstStmt(CONST_STRING,25,"data");
                code.visitStmt2R(MOVE_OBJECT,0,4);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,25);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Landroid/content/ContentValues;","getAsString",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitLabel(L80);
                code.visitConstStmt(CONST_STRING,25,"Jetty");
                code.visitTypeStmt(NEW_INSTANCE,26,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT_RANGE,new int[]{ 26},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,27,"Data for new contact method : ");
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 26,27},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,26);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,26);
                code.visitStmt2R(MOVE_OBJECT,1,6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,26);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 26},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,26);
                code.visitMethodStmt(INVOKE_STATIC_RANGE,new int[]{ 25,26},new Method("Landroid/util/Log;","d",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"I"));
                code.visitLabel(L81);
                code.visitJumpStmt(IF_EQZ,6,-1,L76);
                code.visitConstStmt(CONST_STRING,25,"");
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,25);
                code.visitStmt2R(MOVE_OBJECT,1,6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/String;","equals",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,25);
                code.visitJumpStmt(IF_NEZ,25,-1,L76);
                code.visitLabel(L82);
                code.visitConstStmt(CONST_STRING,25,"Jetty");
                code.visitTypeStmt(NEW_INSTANCE,26,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT_RANGE,new int[]{ 26},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,27,"Adding new contact method with data ");
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 26,27},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,26);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,26);
                code.visitStmt2R(MOVE_OBJECT,1,6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,26);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 26},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,26);
                code.visitMethodStmt(INVOKE_STATIC_RANGE,new int[]{ 25,26},new Method("Landroid/util/Log;","d",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"I"));
                code.visitLabel(L83);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 28},new Method("Lorg/mortbay/ijetty/console/AbstractContactsServlet;","getContentResolver",new String[]{ },"Landroid/content/ContentResolver;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,25);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,25);
                code.visitStmt2R(MOVE_OBJECT,1,4);
                code.visitStmt2R(MOVE_OBJECT_FROM16,2,31);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0,1,2},new Method("Lorg/mortbay/ijetty/console/ContactMethod;","addContactMethod",new String[]{ "Landroid/content/ContentResolver;","Landroid/content/ContentValues;","Ljava/lang/String;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L76);
                code.visitLabel(L84);
                code.visitConstStmt(CONST_STRING,25,"Jetty");
                code.visitTypeStmt(NEW_INSTANCE,26,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT_RANGE,new int[]{ 26},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,27,"Saving contact method ");
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 26,27},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,26);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,26);
                code.visitStmt2R(MOVE_OBJECT,1,11);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,26);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 26},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,26);
                code.visitMethodStmt(INVOKE_STATIC_RANGE,new int[]{ 25,26},new Method("Landroid/util/Log;","d",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"I"));
                code.visitLabel(L85);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 28},new Method("Lorg/mortbay/ijetty/console/AbstractContactsServlet;","getContentResolver",new String[]{ },"Landroid/content/ContentResolver;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,25);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,25);
                code.visitStmt2R(MOVE_OBJECT,1,4);
                code.visitStmt2R(MOVE_OBJECT,2,11);
                code.visitStmt2R(MOVE_OBJECT_FROM16,3,31);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0,1,2,3},new Method("Lorg/mortbay/ijetty/console/ContactMethod;","saveContactMethod",new String[]{ "Landroid/content/ContentResolver;","Landroid/content/ContentValues;","Ljava/lang/String;","Ljava/lang/String;"},"V"));
                code.visitJumpStmt(GOTO_16,-1,-1,L76);
                code.visitLabel(L86);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 7},new Method("Ljava/util/List;","iterator",new String[]{ },"Ljava/util/Iterator;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,10);
                code.visitLabel(L87);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 10},new Method("Ljava/util/Iterator;","hasNext",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,25);
                code.visitJumpStmt(IF_EQZ,25,-1,L89);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 10},new Method("Ljava/util/Iterator;","next",new String[]{ },"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,13);
                code.visitTypeStmt(CHECK_CAST,13,-1,"Ljava/lang/String;");
                code.visitLabel(L88);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 28},new Method("Lorg/mortbay/ijetty/console/AbstractContactsServlet;","getContentResolver",new String[]{ },"Landroid/content/ContentResolver;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,25);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,25);
                code.visitStmt2R(MOVE_OBJECT,1,13);
                code.visitStmt2R(MOVE_OBJECT_FROM16,2,31);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0,1,2},new Method("Lorg/mortbay/ijetty/console/ContactMethod;","deleteContactMethod",new String[]{ "Landroid/content/ContentResolver;","Ljava/lang/String;","Ljava/lang/String;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L87);
                code.visitLabel(L89);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 28},new Method("Lorg/mortbay/ijetty/console/AbstractContactsServlet;","getContentResolver",new String[]{ },"Landroid/content/ContentResolver;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,25);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,25);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,18);
                code.visitStmt2R(MOVE_OBJECT_FROM16,2,31);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0,1,2},new Method("Lorg/mortbay/ijetty/console/User;","save",new String[]{ "Landroid/content/ContentResolver;","Landroid/content/ContentValues;","Ljava/lang/String;"},"V"));
                code.visitLabel(L90);
                code.visitFieldStmt(SGET,25,-1,new Field("Lorg/mortbay/ijetty/console/AbstractContactsServlet;","__VERSION","I"));
                code.visitStmt2R1N(ADD_INT_LIT8,25,25,1);
                code.visitFieldStmt(SPUT,25,-1,new Field("Lorg/mortbay/ijetty/console/AbstractContactsServlet;","__VERSION","I"));
                code.visitLabel(L91);
                code.visitConstStmt(CONST_STRING,25,"Jetty");
                code.visitTypeStmt(NEW_INSTANCE,26,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT_RANGE,new int[]{ 26},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,27,"Updating user id ");
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 26,27},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,26);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,26);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,31);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,26);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 26},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,26);
                code.visitMethodStmt(INVOKE_STATIC_RANGE,new int[]{ 25,26},new Method("Landroid/util/Log;","d",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"I"));
                code.visitLabel(L92);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
