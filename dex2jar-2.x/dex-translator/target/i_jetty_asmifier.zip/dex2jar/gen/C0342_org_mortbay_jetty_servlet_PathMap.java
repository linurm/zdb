package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0342_org_mortbay_jetty_servlet_PathMap {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(ACC_PUBLIC,"Lorg/mortbay/jetty/servlet/PathMap;","Ljava/util/HashMap;",new String[]{ "Ljava/io/Externalizable;"});
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("PathMap.java");
        if(cv!=null){
            DexAnnotationVisitor av00 = cv.visitAnnotation("Ldalvik/annotation/MemberClasses;", Visibility.SYSTEM);
            if(av00 != null) {
                {
                    DexAnnotationVisitor av01 = av00.visitArray("value");
                    if(av01 != null) {
                        av01.visit(null, new DexType("Lorg/mortbay/jetty/servlet/PathMap$Entry;"));
                        av01.visitEnd();
                    }
                }
                av00.visitEnd();
            }
        }
        f000___pathSpecSeparators(cv);
        f001__default(cv);
        f002__defaultSingletonList(cv);
        f003__entrySet(cv);
        f004__exactMap(cv);
        f005__nodefault(cv);
        f006__prefixDefault(cv);
        f007__prefixMap(cv);
        f008__suffixMap(cv);
        m000__clinit_(cv);
        m001__init_(cv);
        m002__init_(cv);
        m003__init_(cv);
        m004__init_(cv);
        m005_isPathWildcardMatch(cv);
        m006_match(cv);
        m007_match(cv);
        m008_pathInfo(cv);
        m009_pathMatch(cv);
        m010_relativePath(cv);
        m011_setPathSpecSeparators(cv);
        m012_clear(cv);
        m013_containsMatch(cv);
        m014_getLazyMatches(cv);
        m015_getMatch(cv);
        m016_getMatches(cv);
        m017_match(cv);
        m018_put(cv);
        m019_readExternal(cv);
        m020_remove(cv);
        m021_writeExternal(cv);
    }
    public static void f000___pathSpecSeparators(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE|ACC_STATIC, new Field("Lorg/mortbay/jetty/servlet/PathMap;","__pathSpecSeparators","Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f001__default(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(0, new Field("Lorg/mortbay/jetty/servlet/PathMap;","_default","Lorg/mortbay/jetty/servlet/PathMap$Entry;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f002__defaultSingletonList(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(0, new Field("Lorg/mortbay/jetty/servlet/PathMap;","_defaultSingletonList","Ljava/util/List;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f003__entrySet(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(0, new Field("Lorg/mortbay/jetty/servlet/PathMap;","_entrySet","Ljava/util/Set;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f004__exactMap(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(0, new Field("Lorg/mortbay/jetty/servlet/PathMap;","_exactMap","Lorg/mortbay/util/StringMap;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f005__nodefault(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(0, new Field("Lorg/mortbay/jetty/servlet/PathMap;","_nodefault","Z"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f006__prefixDefault(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(0, new Field("Lorg/mortbay/jetty/servlet/PathMap;","_prefixDefault","Lorg/mortbay/jetty/servlet/PathMap$Entry;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f007__prefixMap(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(0, new Field("Lorg/mortbay/jetty/servlet/PathMap;","_prefixMap","Lorg/mortbay/util/StringMap;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f008__suffixMap(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(0, new Field("Lorg/mortbay/jetty/servlet/PathMap;","_suffixMap","Lorg/mortbay/util/StringMap;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void m000__clinit_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_STATIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/jetty/servlet/PathMap;","<clinit>",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(63,L0);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_STRING,0,"org.mortbay.http.PathMap.separators");
                code.visitConstStmt(CONST_STRING,1,":,");
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0,1},new Method("Ljava/lang/System;","getProperty",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(SPUT_OBJECT,0,-1,new Field("Lorg/mortbay/jetty/servlet/PathMap;","__pathSpecSeparators","Ljava/lang/String;"));
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/jetty/servlet/PathMap;","<init>",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(95,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(80,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(81,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(82,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(84,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(85,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(86,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(88,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(96,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(97,L10);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L1);
                code.visitConstStmt(CONST_16,0, Integer.valueOf(11)); // int: 0x0000000b  float:0.000000
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2,0},new Method("Ljava/util/HashMap;","<init>",new String[]{ "I"},"V"));
                code.visitLabel(L2);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Lorg/mortbay/util/StringMap;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Lorg/mortbay/util/StringMap;","<init>",new String[]{ },"V"));
                code.visitFieldStmt(IPUT_OBJECT,0,2,new Field("Lorg/mortbay/jetty/servlet/PathMap;","_prefixMap","Lorg/mortbay/util/StringMap;"));
                code.visitLabel(L3);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Lorg/mortbay/util/StringMap;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Lorg/mortbay/util/StringMap;","<init>",new String[]{ },"V"));
                code.visitFieldStmt(IPUT_OBJECT,0,2,new Field("Lorg/mortbay/jetty/servlet/PathMap;","_suffixMap","Lorg/mortbay/util/StringMap;"));
                code.visitLabel(L4);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Lorg/mortbay/util/StringMap;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Lorg/mortbay/util/StringMap;","<init>",new String[]{ },"V"));
                code.visitFieldStmt(IPUT_OBJECT,0,2,new Field("Lorg/mortbay/jetty/servlet/PathMap;","_exactMap","Lorg/mortbay/util/StringMap;"));
                code.visitLabel(L5);
                code.visitFieldStmt(IPUT_OBJECT,1,2,new Field("Lorg/mortbay/jetty/servlet/PathMap;","_defaultSingletonList","Ljava/util/List;"));
                code.visitLabel(L6);
                code.visitFieldStmt(IPUT_OBJECT,1,2,new Field("Lorg/mortbay/jetty/servlet/PathMap;","_prefixDefault","Lorg/mortbay/jetty/servlet/PathMap$Entry;"));
                code.visitLabel(L7);
                code.visitFieldStmt(IPUT_OBJECT,1,2,new Field("Lorg/mortbay/jetty/servlet/PathMap;","_default","Lorg/mortbay/jetty/servlet/PathMap$Entry;"));
                code.visitLabel(L8);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT_BOOLEAN,0,2,new Field("Lorg/mortbay/jetty/servlet/PathMap;","_nodefault","Z"));
                code.visitLabel(L9);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/jetty/servlet/PathMap;","entrySet",new String[]{ },"Ljava/util/Set;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(IPUT_OBJECT,0,2,new Field("Lorg/mortbay/jetty/servlet/PathMap;","_entrySet","Ljava/util/Set;"));
                code.visitLabel(L10);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m002__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/jetty/servlet/PathMap;","<init>",new String[]{ "I"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"capacity");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(114,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(80,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(81,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(82,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(84,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(85,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(86,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(88,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(115,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(116,L10);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2,3},new Method("Ljava/util/HashMap;","<init>",new String[]{ "I"},"V"));
                code.visitLabel(L2);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Lorg/mortbay/util/StringMap;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Lorg/mortbay/util/StringMap;","<init>",new String[]{ },"V"));
                code.visitFieldStmt(IPUT_OBJECT,0,2,new Field("Lorg/mortbay/jetty/servlet/PathMap;","_prefixMap","Lorg/mortbay/util/StringMap;"));
                code.visitLabel(L3);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Lorg/mortbay/util/StringMap;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Lorg/mortbay/util/StringMap;","<init>",new String[]{ },"V"));
                code.visitFieldStmt(IPUT_OBJECT,0,2,new Field("Lorg/mortbay/jetty/servlet/PathMap;","_suffixMap","Lorg/mortbay/util/StringMap;"));
                code.visitLabel(L4);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Lorg/mortbay/util/StringMap;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Lorg/mortbay/util/StringMap;","<init>",new String[]{ },"V"));
                code.visitFieldStmt(IPUT_OBJECT,0,2,new Field("Lorg/mortbay/jetty/servlet/PathMap;","_exactMap","Lorg/mortbay/util/StringMap;"));
                code.visitLabel(L5);
                code.visitFieldStmt(IPUT_OBJECT,1,2,new Field("Lorg/mortbay/jetty/servlet/PathMap;","_defaultSingletonList","Ljava/util/List;"));
                code.visitLabel(L6);
                code.visitFieldStmt(IPUT_OBJECT,1,2,new Field("Lorg/mortbay/jetty/servlet/PathMap;","_prefixDefault","Lorg/mortbay/jetty/servlet/PathMap$Entry;"));
                code.visitLabel(L7);
                code.visitFieldStmt(IPUT_OBJECT,1,2,new Field("Lorg/mortbay/jetty/servlet/PathMap;","_default","Lorg/mortbay/jetty/servlet/PathMap$Entry;"));
                code.visitLabel(L8);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT_BOOLEAN,0,2,new Field("Lorg/mortbay/jetty/servlet/PathMap;","_nodefault","Z"));
                code.visitLabel(L9);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/jetty/servlet/PathMap;","entrySet",new String[]{ },"Ljava/util/Set;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(IPUT_OBJECT,0,2,new Field("Lorg/mortbay/jetty/servlet/PathMap;","_entrySet","Ljava/util/Set;"));
                code.visitLabel(L10);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m003__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/jetty/servlet/PathMap;","<init>",new String[]{ "Ljava/util/Map;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"m");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(122,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(80,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(81,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(82,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(84,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(85,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(86,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(88,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(123,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(124,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(125,L11);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2},new Method("Ljava/util/HashMap;","<init>",new String[]{ },"V"));
                code.visitLabel(L2);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Lorg/mortbay/util/StringMap;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Lorg/mortbay/util/StringMap;","<init>",new String[]{ },"V"));
                code.visitFieldStmt(IPUT_OBJECT,0,2,new Field("Lorg/mortbay/jetty/servlet/PathMap;","_prefixMap","Lorg/mortbay/util/StringMap;"));
                code.visitLabel(L3);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Lorg/mortbay/util/StringMap;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Lorg/mortbay/util/StringMap;","<init>",new String[]{ },"V"));
                code.visitFieldStmt(IPUT_OBJECT,0,2,new Field("Lorg/mortbay/jetty/servlet/PathMap;","_suffixMap","Lorg/mortbay/util/StringMap;"));
                code.visitLabel(L4);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Lorg/mortbay/util/StringMap;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Lorg/mortbay/util/StringMap;","<init>",new String[]{ },"V"));
                code.visitFieldStmt(IPUT_OBJECT,0,2,new Field("Lorg/mortbay/jetty/servlet/PathMap;","_exactMap","Lorg/mortbay/util/StringMap;"));
                code.visitLabel(L5);
                code.visitFieldStmt(IPUT_OBJECT,1,2,new Field("Lorg/mortbay/jetty/servlet/PathMap;","_defaultSingletonList","Ljava/util/List;"));
                code.visitLabel(L6);
                code.visitFieldStmt(IPUT_OBJECT,1,2,new Field("Lorg/mortbay/jetty/servlet/PathMap;","_prefixDefault","Lorg/mortbay/jetty/servlet/PathMap$Entry;"));
                code.visitLabel(L7);
                code.visitFieldStmt(IPUT_OBJECT,1,2,new Field("Lorg/mortbay/jetty/servlet/PathMap;","_default","Lorg/mortbay/jetty/servlet/PathMap$Entry;"));
                code.visitLabel(L8);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT_BOOLEAN,0,2,new Field("Lorg/mortbay/jetty/servlet/PathMap;","_nodefault","Z"));
                code.visitLabel(L9);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3},new Method("Lorg/mortbay/jetty/servlet/PathMap;","putAll",new String[]{ "Ljava/util/Map;"},"V"));
                code.visitLabel(L10);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/jetty/servlet/PathMap;","entrySet",new String[]{ },"Ljava/util/Set;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(IPUT_OBJECT,0,2,new Field("Lorg/mortbay/jetty/servlet/PathMap;","_entrySet","Ljava/util/Set;"));
                code.visitLabel(L11);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m004__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/jetty/servlet/PathMap;","<init>",new String[]{ "Z"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"nodefault");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(104,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(80,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(81,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(82,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(84,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(85,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(86,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(88,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(105,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(106,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(107,L11);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L1);
                code.visitConstStmt(CONST_16,0, Integer.valueOf(11)); // int: 0x0000000b  float:0.000000
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2,0},new Method("Ljava/util/HashMap;","<init>",new String[]{ "I"},"V"));
                code.visitLabel(L2);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Lorg/mortbay/util/StringMap;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Lorg/mortbay/util/StringMap;","<init>",new String[]{ },"V"));
                code.visitFieldStmt(IPUT_OBJECT,0,2,new Field("Lorg/mortbay/jetty/servlet/PathMap;","_prefixMap","Lorg/mortbay/util/StringMap;"));
                code.visitLabel(L3);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Lorg/mortbay/util/StringMap;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Lorg/mortbay/util/StringMap;","<init>",new String[]{ },"V"));
                code.visitFieldStmt(IPUT_OBJECT,0,2,new Field("Lorg/mortbay/jetty/servlet/PathMap;","_suffixMap","Lorg/mortbay/util/StringMap;"));
                code.visitLabel(L4);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Lorg/mortbay/util/StringMap;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Lorg/mortbay/util/StringMap;","<init>",new String[]{ },"V"));
                code.visitFieldStmt(IPUT_OBJECT,0,2,new Field("Lorg/mortbay/jetty/servlet/PathMap;","_exactMap","Lorg/mortbay/util/StringMap;"));
                code.visitLabel(L5);
                code.visitFieldStmt(IPUT_OBJECT,1,2,new Field("Lorg/mortbay/jetty/servlet/PathMap;","_defaultSingletonList","Ljava/util/List;"));
                code.visitLabel(L6);
                code.visitFieldStmt(IPUT_OBJECT,1,2,new Field("Lorg/mortbay/jetty/servlet/PathMap;","_prefixDefault","Lorg/mortbay/jetty/servlet/PathMap$Entry;"));
                code.visitLabel(L7);
                code.visitFieldStmt(IPUT_OBJECT,1,2,new Field("Lorg/mortbay/jetty/servlet/PathMap;","_default","Lorg/mortbay/jetty/servlet/PathMap$Entry;"));
                code.visitLabel(L8);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT_BOOLEAN,0,2,new Field("Lorg/mortbay/jetty/servlet/PathMap;","_nodefault","Z"));
                code.visitLabel(L9);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/jetty/servlet/PathMap;","entrySet",new String[]{ },"Ljava/util/Set;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(IPUT_OBJECT,0,2,new Field("Lorg/mortbay/jetty/servlet/PathMap;","_entrySet","Ljava/util/Set;"));
                code.visitLabel(L10);
                code.visitFieldStmt(IPUT_BOOLEAN,3,2,new Field("Lorg/mortbay/jetty/servlet/PathMap;","_nodefault","Z"));
                code.visitLabel(L11);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m005_isPathWildcardMatch(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PRIVATE|ACC_STATIC, new Method("Lorg/mortbay/jetty/servlet/PathMap;","isPathWildcardMatch",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(6);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"pathSpec");
                ddv.visitParameterName(1,"path");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(416,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(417,L2);
                ddv.visitStartLocal(0,L2,"cpl","I",null);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(419,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(420,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(422,L5);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Ljava/lang/String;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(2)); // int: 0x00000002  float:0.000000
                code.visitStmt3R(SUB_INT,0,1,2);
                code.visitLabel(L2);
                code.visitConstStmt(CONST_STRING,1,"/*");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,1},new Method("Ljava/lang/String;","endsWith",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,1);
                DexLabel L6=new DexLabel();
                code.visitJumpStmt(IF_EQZ,1,-1,L6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,3,4,3,0},new Method("Ljava/lang/String;","regionMatches",new String[]{ "I","Ljava/lang/String;","I","I"},"Z"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitJumpStmt(IF_EQZ,1,-1,L6);
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Ljava/lang/String;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitJumpStmt(IF_EQ,1,0,L4);
                code.visitConstStmt(CONST_16,1, Integer.valueOf(47)); // int: 0x0000002f  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,0},new Method("Ljava/lang/String;","charAt",new String[]{ "I"},"C"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitJumpStmt(IF_NE,1,2,L6);
                code.visitLabel(L4);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitLabel(L5);
                code.visitStmt1R(RETURN,1);
                code.visitLabel(L6);
                code.visitStmt2R(MOVE,1,3);
                code.visitJumpStmt(GOTO,-1,-1,L5);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m006_match(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Lorg/mortbay/jetty/servlet/PathMap;","match",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"Z"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/lang/IllegalArgumentException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"pathSpec");
                ddv.visitParameterName(1,"path");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(387,L0);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1,2,0},new Method("Lorg/mortbay/jetty/servlet/PathMap;","match",new String[]{ "Ljava/lang/String;","Ljava/lang/String;","Z"},"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m007_match(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Lorg/mortbay/jetty/servlet/PathMap;","match",new String[]{ "Ljava/lang/String;","Ljava/lang/String;","Z"},"Z"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/lang/IllegalArgumentException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(7);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"pathSpec");
                ddv.visitParameterName(1,"path");
                ddv.visitParameterName(2,"noDefault");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(397,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(398,L2);
                ddv.visitStartLocal(0,L2,"c","C",null);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(400,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(409,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(403,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(404,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(406,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(407,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(409,L9);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitConstStmt(CONST_4,3, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,2},new Method("Ljava/lang/String;","charAt",new String[]{ "I"},"C"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitLabel(L2);
                code.visitConstStmt(CONST_16,1, Integer.valueOf(47)); // int: 0x0000002f  float:0.000000
                code.visitJumpStmt(IF_NE,0,1,L7);
                code.visitLabel(L3);
                DexLabel L10=new DexLabel();
                code.visitJumpStmt(IF_NEZ,6,-1,L10);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Ljava/lang/String;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,1);
                DexLabel L11=new DexLabel();
                code.visitJumpStmt(IF_EQ,1,3,L11);
                code.visitLabel(L10);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,5},new Method("Ljava/lang/String;","equals",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitJumpStmt(IF_EQZ,1,-1,L5);
                code.visitLabel(L11);
                code.visitStmt2R(MOVE,1,3);
                code.visitLabel(L4);
                code.visitStmt1R(RETURN,1);
                code.visitLabel(L5);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 4,5},new Method("Lorg/mortbay/jetty/servlet/PathMap;","isPathWildcardMatch",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,1);
                DexLabel L12=new DexLabel();
                code.visitJumpStmt(IF_EQZ,1,-1,L12);
                code.visitStmt2R(MOVE,1,3);
                code.visitLabel(L6);
                code.visitJumpStmt(GOTO,-1,-1,L4);
                code.visitLabel(L7);
                code.visitConstStmt(CONST_16,1, Integer.valueOf(42)); // int: 0x0000002a  float:0.000000
                code.visitJumpStmt(IF_NE,0,1,L12);
                code.visitLabel(L8);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Ljava/lang/String;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Ljava/lang/String;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitStmt2R(SUB_INT_2ADDR,1,2);
                code.visitStmt2R1N(ADD_INT_LIT8,1,1,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Ljava/lang/String;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitStmt2R(SUB_INT_2ADDR,2,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,1,4,3,2},new Method("Ljava/lang/String;","regionMatches",new String[]{ "I","Ljava/lang/String;","I","I"},"Z"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitJumpStmt(GOTO,-1,-1,L4);
                code.visitLabel(L12);
                code.visitStmt2R(MOVE,1,2);
                code.visitLabel(L9);
                code.visitJumpStmt(GOTO,-1,-1,L4);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m008_pathInfo(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Lorg/mortbay/jetty/servlet/PathMap;","pathInfo",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(7);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"pathSpec");
                ddv.visitParameterName(1,"path");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(460,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(462,L2);
                ddv.visitStartLocal(0,L2,"c","C",null);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(464,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(477,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(467,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(468,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(470,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(472,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(473,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(474,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(477,L11);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,4, Integer.valueOf(2)); // int: 0x00000002  float:0.000000
                code.visitConstStmt(CONST_4,3, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,1},new Method("Ljava/lang/String;","charAt",new String[]{ "I"},"C"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitLabel(L2);
                code.visitConstStmt(CONST_16,1, Integer.valueOf(47)); // int: 0x0000002f  float:0.000000
                DexLabel L12=new DexLabel();
                code.visitJumpStmt(IF_NE,0,1,L12);
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Ljava/lang/String;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitJumpStmt(IF_NE,1,2,L5);
                code.visitStmt2R(MOVE_OBJECT,1,3);
                code.visitLabel(L4);
                code.visitStmt1R(RETURN_OBJECT,1);
                code.visitLabel(L5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,6},new Method("Ljava/lang/String;","equals",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitJumpStmt(IF_EQZ,1,-1,L7);
                code.visitStmt2R(MOVE_OBJECT,1,3);
                code.visitLabel(L6);
                code.visitJumpStmt(GOTO,-1,-1,L4);
                code.visitLabel(L7);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 5,6},new Method("Lorg/mortbay/jetty/servlet/PathMap;","isPathWildcardMatch",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitJumpStmt(IF_EQZ,1,-1,L12);
                code.visitLabel(L8);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Ljava/lang/String;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Ljava/lang/String;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitStmt2R(SUB_INT_2ADDR,2,4);
                code.visitJumpStmt(IF_NE,1,2,L10);
                code.visitStmt2R(MOVE_OBJECT,1,3);
                code.visitLabel(L9);
                code.visitJumpStmt(GOTO,-1,-1,L4);
                code.visitLabel(L10);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Ljava/lang/String;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitStmt2R(SUB_INT_2ADDR,1,4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,1},new Method("Ljava/lang/String;","substring",new String[]{ "I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitJumpStmt(GOTO,-1,-1,L4);
                code.visitLabel(L12);
                code.visitStmt2R(MOVE_OBJECT,1,3);
                code.visitLabel(L11);
                code.visitJumpStmt(GOTO,-1,-1,L4);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m009_pathMatch(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Lorg/mortbay/jetty/servlet/PathMap;","pathMatch",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(7);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"pathSpec");
                ddv.visitParameterName(1,"path");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(432,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(434,L2);
                ddv.visitStartLocal(0,L2,"c","C",null);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(436,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(451,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(439,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(440,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(442,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(443,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(445,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(447,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(449,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(451,L12);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,4, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitConstStmt(CONST_4,3, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,4},new Method("Ljava/lang/String;","charAt",new String[]{ "I"},"C"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitLabel(L2);
                code.visitConstStmt(CONST_16,1, Integer.valueOf(47)); // int: 0x0000002f  float:0.000000
                code.visitJumpStmt(IF_NE,0,1,L9);
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Ljava/lang/String;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitJumpStmt(IF_NE,1,3,L5);
                code.visitStmt2R(MOVE_OBJECT,1,6);
                code.visitLabel(L4);
                code.visitStmt1R(RETURN_OBJECT,1);
                code.visitLabel(L5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,6},new Method("Ljava/lang/String;","equals",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitJumpStmt(IF_EQZ,1,-1,L7);
                code.visitStmt2R(MOVE_OBJECT,1,6);
                code.visitLabel(L6);
                code.visitJumpStmt(GOTO,-1,-1,L4);
                code.visitLabel(L7);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 5,6},new Method("Lorg/mortbay/jetty/servlet/PathMap;","isPathWildcardMatch",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitJumpStmt(IF_EQZ,1,-1,L12);
                code.visitLabel(L8);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Ljava/lang/String;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(2)); // int: 0x00000002  float:0.000000
                code.visitStmt2R(SUB_INT_2ADDR,1,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,4,1},new Method("Ljava/lang/String;","substring",new String[]{ "I","I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitJumpStmt(GOTO,-1,-1,L4);
                code.visitLabel(L9);
                code.visitConstStmt(CONST_16,1, Integer.valueOf(42)); // int: 0x0000002a  float:0.000000
                code.visitJumpStmt(IF_NE,0,1,L12);
                code.visitLabel(L10);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Ljava/lang/String;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Ljava/lang/String;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitStmt2R(SUB_INT_2ADDR,2,3);
                code.visitStmt2R(SUB_INT_2ADDR,1,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Ljava/lang/String;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitStmt2R(SUB_INT_2ADDR,2,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,1,5,3,2},new Method("Ljava/lang/String;","regionMatches",new String[]{ "I","Ljava/lang/String;","I","I"},"Z"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitJumpStmt(IF_EQZ,1,-1,L12);
                code.visitStmt2R(MOVE_OBJECT,1,6);
                code.visitLabel(L11);
                code.visitJumpStmt(GOTO,-1,-1,L4);
                code.visitLabel(L12);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L4);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m010_relativePath(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Lorg/mortbay/jetty/servlet/PathMap;","relativePath",new String[]{ "Ljava/lang/String;","Ljava/lang/String;","Ljava/lang/String;"},"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(7);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"base");
                ddv.visitParameterName(1,"pathSpec");
                ddv.visitParameterName(2,"path");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(492,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(493,L2);
                ddv.visitStartLocal(0,L2,"info","Ljava/lang/String;",null);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(494,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(496,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(497,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(498,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(499,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(500,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(508,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(502,L10);
                DexLabel L11=new DexLabel();
                ddv.visitRestartLocal(6,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(504,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(505,L13);
                DexLabel L14=new DexLabel();
                ddv.visitRestartLocal(6,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(507,L15);
                DexLabel L16=new DexLabel();
                ddv.visitRestartLocal(6,L16);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_STRING,3,"/");
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 5,6},new Method("Lorg/mortbay/jetty/servlet/PathMap;","pathInfo",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L2);
                code.visitJumpStmt(IF_NEZ,0,-1,L4);
                code.visitLabel(L3);
                code.visitStmt2R(MOVE_OBJECT,0,6);
                code.visitLabel(L4);
                code.visitConstStmt(CONST_STRING,1,"./");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/String;","startsWith",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitJumpStmt(IF_EQZ,1,-1,L6);
                code.visitLabel(L5);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(2)); // int: 0x00000002  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/String;","substring",new String[]{ "I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L6);
                code.visitConstStmt(CONST_STRING,1,"/");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,3},new Method("Ljava/lang/String;","endsWith",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitJumpStmt(IF_EQZ,1,-1,L12);
                code.visitLabel(L7);
                code.visitConstStmt(CONST_STRING,1,"/");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,3},new Method("Ljava/lang/String;","startsWith",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitJumpStmt(IF_EQZ,1,-1,L10);
                code.visitLabel(L8);
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,4},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,2},new Method("Ljava/lang/String;","substring",new String[]{ "I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitLabel(L9);
                code.visitStmt1R(RETURN_OBJECT,6);
                code.visitLabel(L10);
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,4},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,0},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitLabel(L11);
                code.visitJumpStmt(GOTO,-1,-1,L9);
                code.visitLabel(L12);
                code.visitConstStmt(CONST_STRING,1,"/");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,3},new Method("Ljava/lang/String;","startsWith",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitJumpStmt(IF_EQZ,1,-1,L15);
                code.visitLabel(L13);
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,4},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,0},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitLabel(L14);
                code.visitJumpStmt(GOTO,-1,-1,L9);
                code.visitLabel(L15);
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,4},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitConstStmt(CONST_STRING,2,"/");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,3},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,0},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitLabel(L16);
                code.visitJumpStmt(GOTO,-1,-1,L9);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m011_setPathSpecSeparators(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Lorg/mortbay/jetty/servlet/PathMap;","setPathSpecSeparators",new String[]{ "Ljava/lang/String;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(1);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"s");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(76,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(77,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(SPUT_OBJECT,0,-1,new Field("Lorg/mortbay/jetty/servlet/PathMap;","__pathSpecSeparators","Ljava/lang/String;"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m012_clear(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/servlet/PathMap;","clear",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(372,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(373,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(374,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(375,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(376,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(377,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(378,L7);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L1);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Lorg/mortbay/util/StringMap;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Lorg/mortbay/util/StringMap;","<init>",new String[]{ },"V"));
                code.visitFieldStmt(IPUT_OBJECT,0,2,new Field("Lorg/mortbay/jetty/servlet/PathMap;","_exactMap","Lorg/mortbay/util/StringMap;"));
                code.visitLabel(L2);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Lorg/mortbay/util/StringMap;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Lorg/mortbay/util/StringMap;","<init>",new String[]{ },"V"));
                code.visitFieldStmt(IPUT_OBJECT,0,2,new Field("Lorg/mortbay/jetty/servlet/PathMap;","_prefixMap","Lorg/mortbay/util/StringMap;"));
                code.visitLabel(L3);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Lorg/mortbay/util/StringMap;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Lorg/mortbay/util/StringMap;","<init>",new String[]{ },"V"));
                code.visitFieldStmt(IPUT_OBJECT,0,2,new Field("Lorg/mortbay/jetty/servlet/PathMap;","_suffixMap","Lorg/mortbay/util/StringMap;"));
                code.visitLabel(L4);
                code.visitFieldStmt(IPUT_OBJECT,1,2,new Field("Lorg/mortbay/jetty/servlet/PathMap;","_default","Lorg/mortbay/jetty/servlet/PathMap$Entry;"));
                code.visitLabel(L5);
                code.visitFieldStmt(IPUT_OBJECT,1,2,new Field("Lorg/mortbay/jetty/servlet/PathMap;","_defaultSingletonList","Ljava/util/List;"));
                code.visitLabel(L6);
                code.visitMethodStmt(INVOKE_SUPER,new int[]{ 2},new Method("Ljava/util/HashMap;","clear",new String[]{ },"V"));
                code.visitLabel(L7);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m013_containsMatch(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/servlet/PathMap;","containsMatch",new String[]{ "Ljava/lang/String;"},"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"path");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(336,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(337,L1);
                ddv.visitStartLocal(0,L1,"match","Lorg/mortbay/jetty/servlet/PathMap$Entry;",null);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3},new Method("Lorg/mortbay/jetty/servlet/PathMap;","getMatch",new String[]{ "Ljava/lang/String;"},"Lorg/mortbay/jetty/servlet/PathMap$Entry;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L1);
                DexLabel L2=new DexLabel();
                code.visitJumpStmt(IF_EQZ,0,-1,L2);
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/jetty/servlet/PathMap;","_default","Lorg/mortbay/jetty/servlet/PathMap$Entry;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/Object;","equals",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitJumpStmt(IF_NEZ,1,-1,L2);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                DexLabel L3=new DexLabel();
                code.visitLabel(L3);
                code.visitStmt1R(RETURN,1);
                code.visitLabel(L2);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L3);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m014_getLazyMatches(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/servlet/PathMap;","getLazyMatches",new String[]{ "Ljava/lang/String;"},"Ljava/lang/Object;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(11);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"path");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(270,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(272,L2);
                ddv.visitStartLocal(0,L2,"entries","Ljava/lang/Object;",null);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(273,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(314,L4);
                ddv.visitEndLocal(0,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(275,L5);
                ddv.visitRestartLocal(0,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(278,L6);
                ddv.visitStartLocal(3,L6,"l","I",null);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(279,L7);
                ddv.visitStartLocal(1,L7,"entry","Ljava/util/Map$Entry;",null);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(280,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(283,L9);
                ddv.visitEndLocal(0,L9);
                DexLabel L10=new DexLabel();
                ddv.visitStartLocal(2,L10,"i","I",null);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(284,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(286,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(287,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(288,L14);
                DexLabel L15=new DexLabel();
                ddv.visitStartLocal(0,L15,"entries","Ljava/lang/Object;",null);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(292,L16);
                ddv.visitEndLocal(0,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(293,L17);
                DexLabel L18=new DexLabel();
                ddv.visitRestartLocal(0,L18);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(296,L19);
                ddv.visitEndLocal(0,L19);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(297,L20);
                DexLabel L21=new DexLabel();
                ddv.visitRestartLocal(2,L21);
                DexLabel L22=new DexLabel();
                ddv.visitLineNumber(299,L22);
                DexLabel L23=new DexLabel();
                ddv.visitLineNumber(300,L23);
                ddv.visitRestartLocal(1,L23);
                DexLabel L24=new DexLabel();
                ddv.visitLineNumber(301,L24);
                DexLabel L25=new DexLabel();
                ddv.visitRestartLocal(0,L25);
                DexLabel L26=new DexLabel();
                ddv.visitLineNumber(305,L26);
                ddv.visitEndLocal(0,L26);
                DexLabel L27=new DexLabel();
                ddv.visitLineNumber(308,L27);
                DexLabel L28=new DexLabel();
                ddv.visitLineNumber(309,L28);
                DexLabel L29=new DexLabel();
                ddv.visitLineNumber(311,L29);
                DexLabel L30=new DexLabel();
                ddv.visitRestartLocal(0,L30);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,7, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitConstStmt(CONST_4,8, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L2);
                code.visitJumpStmt(IF_NEZ,10,-1,L5);
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0},new Method("Lorg/mortbay/util/LazyList;","getList",new String[]{ "Ljava/lang/Object;"},"Ljava/util/List;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitLabel(L4);
                code.visitStmt1R(RETURN_OBJECT,4);
                code.visitLabel(L5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10},new Method("Ljava/lang/String;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitLabel(L6);
                code.visitFieldStmt(IGET_OBJECT,4,9,new Field("Lorg/mortbay/jetty/servlet/PathMap;","_exactMap","Lorg/mortbay/util/StringMap;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,10,7,3},new Method("Lorg/mortbay/util/StringMap;","getEntry",new String[]{ "Ljava/lang/String;","I","I"},"Ljava/util/Map$Entry;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L7);
                code.visitJumpStmt(IF_EQZ,1,-1,L9);
                code.visitLabel(L8);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 1},new Method("Ljava/util/Map$Entry;","getValue",new String[]{ },"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0,4},new Method("Lorg/mortbay/util/LazyList;","add",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L9);
                code.visitStmt3R(SUB_INT,2,3,8);
                code.visitLabel(L10);
                code.visitStmt2R(MOVE_OBJECT,4,0);
                code.visitLabel(L11);
                code.visitConstStmt(CONST_16,5, Integer.valueOf(47)); // int: 0x0000002f  float:0.000000
                code.visitStmt3R(SUB_INT,6,2,8);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10,5,6},new Method("Ljava/lang/String;","lastIndexOf",new String[]{ "I","I"},"I"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitJumpStmt(IF_LTZ,2,-1,L16);
                code.visitLabel(L12);
                code.visitFieldStmt(IGET_OBJECT,5,9,new Field("Lorg/mortbay/jetty/servlet/PathMap;","_prefixMap","Lorg/mortbay/util/StringMap;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,10,7,2},new Method("Lorg/mortbay/util/StringMap;","getEntry",new String[]{ "Ljava/lang/String;","I","I"},"Ljava/util/Map$Entry;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L13);
                code.visitJumpStmt(IF_EQZ,1,-1,L11);
                code.visitLabel(L14);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 1},new Method("Ljava/util/Map$Entry;","getValue",new String[]{ },"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 4,5},new Method("Lorg/mortbay/util/LazyList;","add",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L15);
                code.visitStmt2R(MOVE_OBJECT,4,0);
                code.visitJumpStmt(GOTO,-1,-1,L11);
                code.visitLabel(L16);
                code.visitFieldStmt(IGET_OBJECT,5,9,new Field("Lorg/mortbay/jetty/servlet/PathMap;","_prefixDefault","Lorg/mortbay/jetty/servlet/PathMap$Entry;"));
                code.visitJumpStmt(IF_EQZ,5,-1,L19);
                code.visitLabel(L17);
                code.visitFieldStmt(IGET_OBJECT,5,9,new Field("Lorg/mortbay/jetty/servlet/PathMap;","_prefixDefault","Lorg/mortbay/jetty/servlet/PathMap$Entry;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 4,5},new Method("Lorg/mortbay/util/LazyList;","add",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L18);
                code.visitStmt2R(MOVE_OBJECT,4,0);
                code.visitLabel(L19);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L20);
                code.visitConstStmt(CONST_16,5, Integer.valueOf(46)); // int: 0x0000002e  float:0.000000
                code.visitStmt2R1N(ADD_INT_LIT8,6,2,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10,5,6},new Method("Ljava/lang/String;","indexOf",new String[]{ "I","I"},"I"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitLabel(L21);
                code.visitJumpStmt(IF_LEZ,2,-1,L26);
                code.visitLabel(L22);
                code.visitFieldStmt(IGET_OBJECT,5,9,new Field("Lorg/mortbay/jetty/servlet/PathMap;","_suffixMap","Lorg/mortbay/util/StringMap;"));
                code.visitStmt2R1N(ADD_INT_LIT8,6,2,1);
                code.visitStmt3R(SUB_INT,7,3,2);
                code.visitStmt2R(SUB_INT_2ADDR,7,8);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,10,6,7},new Method("Lorg/mortbay/util/StringMap;","getEntry",new String[]{ "Ljava/lang/String;","I","I"},"Ljava/util/Map$Entry;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L23);
                code.visitJumpStmt(IF_EQZ,1,-1,L20);
                code.visitLabel(L24);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 1},new Method("Ljava/util/Map$Entry;","getValue",new String[]{ },"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 4,5},new Method("Lorg/mortbay/util/LazyList;","add",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L25);
                code.visitStmt2R(MOVE_OBJECT,4,0);
                code.visitJumpStmt(GOTO,-1,-1,L20);
                code.visitLabel(L26);
                code.visitFieldStmt(IGET_OBJECT,5,9,new Field("Lorg/mortbay/jetty/servlet/PathMap;","_default","Lorg/mortbay/jetty/servlet/PathMap$Entry;"));
                code.visitJumpStmt(IF_EQZ,5,-1,L4);
                code.visitLabel(L27);
                code.visitJumpStmt(IF_NEZ,4,-1,L29);
                code.visitLabel(L28);
                code.visitFieldStmt(IGET_OBJECT,4,9,new Field("Lorg/mortbay/jetty/servlet/PathMap;","_defaultSingletonList","Ljava/util/List;"));
                code.visitJumpStmt(GOTO,-1,-1,L4);
                code.visitLabel(L29);
                code.visitFieldStmt(IGET_OBJECT,5,9,new Field("Lorg/mortbay/jetty/servlet/PathMap;","_default","Lorg/mortbay/jetty/servlet/PathMap$Entry;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 4,5},new Method("Lorg/mortbay/util/LazyList;","add",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L30);
                code.visitStmt2R(MOVE_OBJECT,4,0);
                code.visitJumpStmt(GOTO,-1,-1,L4);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m015_getMatch(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/servlet/PathMap;","getMatch",new String[]{ "Ljava/lang/String;"},"Lorg/mortbay/jetty/servlet/PathMap$Entry;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(9);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"path");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(225,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(226,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(258,L3);
                ddv.visitEndLocal(7,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(228,L4);
                ddv.visitRestartLocal(7,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(231,L5);
                ddv.visitStartLocal(2,L5,"l","I",null);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(232,L6);
                ddv.visitStartLocal(0,L6,"entry","Ljava/util/Map$Entry;",null);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(233,L7);
                DexLabel L8=new DexLabel();
                ddv.visitEndLocal(7,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(236,L9);
                ddv.visitRestartLocal(7,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(237,L10);
                ddv.visitStartLocal(1,L10,"i","I",null);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(239,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(240,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(241,L13);
                DexLabel L14=new DexLabel();
                ddv.visitEndLocal(7,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(245,L15);
                ddv.visitRestartLocal(7,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(246,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(249,L17);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(250,L18);
                DexLabel L19=new DexLabel();
                ddv.visitRestartLocal(1,L19);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(252,L20);
                DexLabel L21=new DexLabel();
                ddv.visitLineNumber(253,L21);
                ddv.visitRestartLocal(0,L21);
                DexLabel L22=new DexLabel();
                ddv.visitLineNumber(254,L22);
                DexLabel L23=new DexLabel();
                ddv.visitEndLocal(7,L23);
                DexLabel L24=new DexLabel();
                ddv.visitLineNumber(258,L24);
                ddv.visitRestartLocal(7,L24);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,6, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitConstStmt(CONST_4,5, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L1);
                code.visitJumpStmt(IF_NEZ,8,-1,L4);
                code.visitLabel(L2);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L3);
                code.visitStmt1R(RETURN_OBJECT,3);
                code.visitLabel(L4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8},new Method("Ljava/lang/String;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitLabel(L5);
                code.visitFieldStmt(IGET_OBJECT,3,7,new Field("Lorg/mortbay/jetty/servlet/PathMap;","_exactMap","Lorg/mortbay/util/StringMap;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,8,5,2},new Method("Lorg/mortbay/util/StringMap;","getEntry",new String[]{ "Ljava/lang/String;","I","I"},"Ljava/util/Map$Entry;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L6);
                code.visitJumpStmt(IF_EQZ,0,-1,L9);
                code.visitLabel(L7);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0},new Method("Ljava/util/Map$Entry;","getValue",new String[]{ },"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitLabel(L8);
                code.visitTypeStmt(CHECK_CAST,7,-1,"Lorg/mortbay/jetty/servlet/PathMap$Entry;");
                code.visitStmt2R(MOVE_OBJECT,3,7);
                code.visitJumpStmt(GOTO,-1,-1,L3);
                code.visitLabel(L9);
                code.visitStmt2R(MOVE,1,2);
                code.visitLabel(L10);
                code.visitConstStmt(CONST_16,3, Integer.valueOf(47)); // int: 0x0000002f  float:0.000000
                code.visitStmt3R(SUB_INT,4,1,6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8,3,4},new Method("Ljava/lang/String;","lastIndexOf",new String[]{ "I","I"},"I"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitJumpStmt(IF_LTZ,1,-1,L15);
                code.visitLabel(L11);
                code.visitFieldStmt(IGET_OBJECT,3,7,new Field("Lorg/mortbay/jetty/servlet/PathMap;","_prefixMap","Lorg/mortbay/util/StringMap;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,8,5,1},new Method("Lorg/mortbay/util/StringMap;","getEntry",new String[]{ "Ljava/lang/String;","I","I"},"Ljava/util/Map$Entry;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L12);
                code.visitJumpStmt(IF_EQZ,0,-1,L10);
                code.visitLabel(L13);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0},new Method("Ljava/util/Map$Entry;","getValue",new String[]{ },"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitLabel(L14);
                code.visitTypeStmt(CHECK_CAST,7,-1,"Lorg/mortbay/jetty/servlet/PathMap$Entry;");
                code.visitStmt2R(MOVE_OBJECT,3,7);
                code.visitJumpStmt(GOTO,-1,-1,L3);
                code.visitLabel(L15);
                code.visitFieldStmt(IGET_OBJECT,3,7,new Field("Lorg/mortbay/jetty/servlet/PathMap;","_prefixDefault","Lorg/mortbay/jetty/servlet/PathMap$Entry;"));
                code.visitJumpStmt(IF_EQZ,3,-1,L17);
                code.visitLabel(L16);
                code.visitFieldStmt(IGET_OBJECT,3,7,new Field("Lorg/mortbay/jetty/servlet/PathMap;","_prefixDefault","Lorg/mortbay/jetty/servlet/PathMap$Entry;"));
                code.visitJumpStmt(GOTO,-1,-1,L3);
                code.visitLabel(L17);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L18);
                code.visitConstStmt(CONST_16,3, Integer.valueOf(46)); // int: 0x0000002e  float:0.000000
                code.visitStmt2R1N(ADD_INT_LIT8,4,1,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8,3,4},new Method("Ljava/lang/String;","indexOf",new String[]{ "I","I"},"I"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitLabel(L19);
                code.visitJumpStmt(IF_LEZ,1,-1,L24);
                code.visitLabel(L20);
                code.visitFieldStmt(IGET_OBJECT,3,7,new Field("Lorg/mortbay/jetty/servlet/PathMap;","_suffixMap","Lorg/mortbay/util/StringMap;"));
                code.visitStmt2R1N(ADD_INT_LIT8,4,1,1);
                code.visitStmt3R(SUB_INT,5,2,1);
                code.visitStmt2R(SUB_INT_2ADDR,5,6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,8,4,5},new Method("Lorg/mortbay/util/StringMap;","getEntry",new String[]{ "Ljava/lang/String;","I","I"},"Ljava/util/Map$Entry;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L21);
                code.visitJumpStmt(IF_EQZ,0,-1,L18);
                code.visitLabel(L22);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0},new Method("Ljava/util/Map$Entry;","getValue",new String[]{ },"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitLabel(L23);
                code.visitTypeStmt(CHECK_CAST,7,-1,"Lorg/mortbay/jetty/servlet/PathMap$Entry;");
                code.visitStmt2R(MOVE_OBJECT,3,7);
                code.visitJumpStmt(GOTO,-1,-1,L3);
                code.visitLabel(L24);
                code.visitFieldStmt(IGET_OBJECT,3,7,new Field("Lorg/mortbay/jetty/servlet/PathMap;","_default","Lorg/mortbay/jetty/servlet/PathMap$Entry;"));
                code.visitJumpStmt(GOTO,-1,-1,L3);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m016_getMatches(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/servlet/PathMap;","getMatches",new String[]{ "Ljava/lang/String;"},"Ljava/util/List;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"path");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(325,L0);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2},new Method("Lorg/mortbay/jetty/servlet/PathMap;","getLazyMatches",new String[]{ "Ljava/lang/String;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0},new Method("Lorg/mortbay/util/LazyList;","getList",new String[]{ "Ljava/lang/Object;"},"Ljava/util/List;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m017_match(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/servlet/PathMap;","match",new String[]{ "Ljava/lang/String;"},"Ljava/lang/Object;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"path");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(209,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(210,L1);
                ddv.visitStartLocal(0,L1,"entry","Ljava/util/Map$Entry;",null);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(211,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(212,L3);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3},new Method("Lorg/mortbay/jetty/servlet/PathMap;","getMatch",new String[]{ "Ljava/lang/String;"},"Lorg/mortbay/jetty/servlet/PathMap$Entry;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L1);
                DexLabel L4=new DexLabel();
                code.visitJumpStmt(IF_EQZ,0,-1,L4);
                code.visitLabel(L2);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0},new Method("Ljava/util/Map$Entry;","getValue",new String[]{ },"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L3);
                code.visitStmt1R(RETURN_OBJECT,1);
                code.visitLabel(L4);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L3);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m018_put(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/servlet/PathMap;","put",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(13);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L1},new String[]{ null});
                DexLabel L2=new DexLabel();
                DexLabel L3=new DexLabel();
                code.visitTryCatch(L2,L3,new DexLabel[]{L1},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"pathSpec");
                ddv.visitParameterName(1,"object");
                DexLabel L4=new DexLabel();
                ddv.visitPrologue(L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(151,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(152,L6);
                ddv.visitStartLocal(4,L6,"tok","Ljava/util/StringTokenizer;",null);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(154,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(156,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(158,L9);
                ddv.visitStartLocal(3,L9,"spec","Ljava/lang/String;",null);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(159,L10);
                ddv.visitLineNumber(151,L1);
                ddv.visitEndLocal(4,L1);
                ddv.visitEndLocal(3,L1);
                ddv.visitLineNumber(161,L2);
                ddv.visitRestartLocal(3,L2);
                ddv.visitRestartLocal(4,L2);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(164,L11);
                ddv.visitStartLocal(2,L11,"old","Ljava/lang/Object;",null);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(166,L12);
                ddv.visitStartLocal(0,L12,"entry","Lorg/mortbay/jetty/servlet/PathMap$Entry;",null);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(168,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(169,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(170,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(172,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(173,L17);
                ddv.visitStartLocal(1,L17,"mapped","Ljava/lang/String;",null);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(174,L18);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(175,L19);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(176,L20);
                DexLabel L21=new DexLabel();
                ddv.visitLineNumber(178,L21);
                ddv.visitEndLocal(1,L21);
                DexLabel L22=new DexLabel();
                ddv.visitLineNumber(179,L22);
                DexLabel L23=new DexLabel();
                ddv.visitLineNumber(180,L23);
                DexLabel L24=new DexLabel();
                ddv.visitLineNumber(182,L24);
                DexLabel L25=new DexLabel();
                ddv.visitLineNumber(183,L25);
                DexLabel L26=new DexLabel();
                ddv.visitLineNumber(186,L26);
                DexLabel L27=new DexLabel();
                ddv.visitLineNumber(187,L27);
                DexLabel L28=new DexLabel();
                ddv.visitLineNumber(193,L28);
                DexLabel L29=new DexLabel();
                ddv.visitLineNumber(194,L29);
                DexLabel L30=new DexLabel();
                ddv.visitLineNumber(199,L30);
                ddv.visitEndLocal(3,L30);
                ddv.visitEndLocal(2,L30);
                ddv.visitEndLocal(0,L30);
                code.visitLabel(L4);
                code.visitConstStmt(CONST_4,9, Integer.valueOf(2)); // int: 0x00000002  float:0.000000
                code.visitConstStmt(CONST_STRING,5,"/*");
                code.visitConstStmt(CONST_STRING,5,"/");
                code.visitConstStmt(CONST_STRING,5,"*.");
                code.visitLabel(L5);
                code.visitStmt1R(MONITOR_ENTER,10);
                code.visitLabel(L0);
                code.visitTypeStmt(NEW_INSTANCE,4,-1,"Ljava/util/StringTokenizer;");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 11},new Method("Ljava/lang/Object;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitFieldStmt(SGET_OBJECT,6,-1,new Field("Lorg/mortbay/jetty/servlet/PathMap;","__pathSpecSeparators","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 4,5,6},new Method("Ljava/util/StringTokenizer;","<init>",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"V"));
                code.visitLabel(L6);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Ljava/util/StringTokenizer;","hasMoreTokens",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,5);
                code.visitJumpStmt(IF_EQZ,5,-1,L30);
                code.visitLabel(L8);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Ljava/util/StringTokenizer;","nextToken",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitLabel(L9);
                code.visitConstStmt(CONST_STRING,5,"/");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,5},new Method("Ljava/lang/String;","startsWith",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,5);
                code.visitJumpStmt(IF_NEZ,5,-1,L2);
                code.visitConstStmt(CONST_STRING,5,"*.");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,5},new Method("Ljava/lang/String;","startsWith",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,5);
                code.visitJumpStmt(IF_NEZ,5,-1,L2);
                code.visitLabel(L10);
                code.visitTypeStmt(NEW_INSTANCE,5,-1,"Ljava/lang/IllegalArgumentException;");
                code.visitTypeStmt(NEW_INSTANCE,6,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 6},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,7,"PathSpec ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,7},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,3},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitConstStmt(CONST_STRING,7,". must start with \'/\' or \'*.\'");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,7},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 5,6},new Method("Ljava/lang/IllegalArgumentException;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitStmt1R(THROW,5);
                code.visitLabel(L1);
                code.visitStmt1R(MOVE_EXCEPTION,5);
                code.visitStmt1R(MONITOR_EXIT,10);
                code.visitStmt1R(THROW,5);
                code.visitLabel(L2);
                code.visitMethodStmt(INVOKE_SUPER,new int[]{ 10,3,12},new Method("Ljava/util/HashMap;","put",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitLabel(L11);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Lorg/mortbay/jetty/servlet/PathMap$Entry;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,3,12},new Method("Lorg/mortbay/jetty/servlet/PathMap$Entry;","<init>",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;"},"V"));
                code.visitLabel(L12);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/jetty/servlet/PathMap$Entry;","getKey",new String[]{ },"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,3},new Method("Ljava/lang/Object;","equals",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,5);
                code.visitJumpStmt(IF_EQZ,5,-1,L7);
                code.visitLabel(L13);
                code.visitConstStmt(CONST_STRING,5,"/*");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,5},new Method("Ljava/lang/String;","equals",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,5);
                code.visitJumpStmt(IF_EQZ,5,-1,L15);
                code.visitLabel(L14);
                code.visitFieldStmt(IPUT_OBJECT,0,10,new Field("Lorg/mortbay/jetty/servlet/PathMap;","_prefixDefault","Lorg/mortbay/jetty/servlet/PathMap$Entry;"));
                code.visitJumpStmt(GOTO,-1,-1,L7);
                code.visitLabel(L15);
                code.visitConstStmt(CONST_STRING,5,"/*");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,5},new Method("Ljava/lang/String;","endsWith",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,5);
                code.visitJumpStmt(IF_EQZ,5,-1,L21);
                code.visitLabel(L16);
                code.visitConstStmt(CONST_4,5, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Ljava/lang/String;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,6);
                code.visitStmt2R(SUB_INT_2ADDR,6,9);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,5,6},new Method("Ljava/lang/String;","substring",new String[]{ "I","I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L17);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Lorg/mortbay/jetty/servlet/PathMap$Entry;","setMapped",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L18);
                code.visitFieldStmt(IGET_OBJECT,5,10,new Field("Lorg/mortbay/jetty/servlet/PathMap;","_prefixMap","Lorg/mortbay/util/StringMap;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,1,0},new Method("Lorg/mortbay/util/StringMap;","put",new String[]{ "Ljava/lang/String;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitLabel(L19);
                code.visitFieldStmt(IGET_OBJECT,5,10,new Field("Lorg/mortbay/jetty/servlet/PathMap;","_exactMap","Lorg/mortbay/util/StringMap;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,1,0},new Method("Lorg/mortbay/util/StringMap;","put",new String[]{ "Ljava/lang/String;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitLabel(L20);
                code.visitFieldStmt(IGET_OBJECT,5,10,new Field("Lorg/mortbay/jetty/servlet/PathMap;","_exactMap","Lorg/mortbay/util/StringMap;"));
                code.visitConstStmt(CONST_4,6, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Ljava/lang/String;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,7);
                code.visitConstStmt(CONST_4,8, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitStmt2R(SUB_INT_2ADDR,7,8);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,6,7},new Method("Ljava/lang/String;","substring",new String[]{ "I","I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,6,0},new Method("Lorg/mortbay/util/StringMap;","put",new String[]{ "Ljava/lang/String;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitJumpStmt(GOTO_16,-1,-1,L7);
                code.visitLabel(L21);
                code.visitConstStmt(CONST_STRING,5,"*.");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,5},new Method("Ljava/lang/String;","startsWith",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,5);
                code.visitJumpStmt(IF_EQZ,5,-1,L23);
                code.visitLabel(L22);
                code.visitFieldStmt(IGET_OBJECT,5,10,new Field("Lorg/mortbay/jetty/servlet/PathMap;","_suffixMap","Lorg/mortbay/util/StringMap;"));
                code.visitConstStmt(CONST_4,6, Integer.valueOf(2)); // int: 0x00000002  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,6},new Method("Ljava/lang/String;","substring",new String[]{ "I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,6,0},new Method("Lorg/mortbay/util/StringMap;","put",new String[]{ "Ljava/lang/String;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitJumpStmt(GOTO_16,-1,-1,L7);
                code.visitLabel(L23);
                code.visitConstStmt(CONST_STRING,5,"/");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,5},new Method("Ljava/lang/String;","equals",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,5);
                code.visitJumpStmt(IF_EQZ,5,-1,L28);
                code.visitLabel(L24);
                code.visitFieldStmt(IGET_BOOLEAN,5,10,new Field("Lorg/mortbay/jetty/servlet/PathMap;","_nodefault","Z"));
                code.visitJumpStmt(IF_EQZ,5,-1,L26);
                code.visitLabel(L25);
                code.visitFieldStmt(IGET_OBJECT,5,10,new Field("Lorg/mortbay/jetty/servlet/PathMap;","_exactMap","Lorg/mortbay/util/StringMap;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,3,0},new Method("Lorg/mortbay/util/StringMap;","put",new String[]{ "Ljava/lang/String;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitJumpStmt(GOTO_16,-1,-1,L7);
                code.visitLabel(L26);
                code.visitFieldStmt(IPUT_OBJECT,0,10,new Field("Lorg/mortbay/jetty/servlet/PathMap;","_default","Lorg/mortbay/jetty/servlet/PathMap$Entry;"));
                code.visitLabel(L27);
                code.visitFieldStmt(IGET_OBJECT,5,10,new Field("Lorg/mortbay/jetty/servlet/PathMap;","_default","Lorg/mortbay/jetty/servlet/PathMap$Entry;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 5},new Method("Lorg/mortbay/util/SingletonList;","newSingletonList",new String[]{ "Ljava/lang/Object;"},"Lorg/mortbay/util/SingletonList;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitFieldStmt(IPUT_OBJECT,5,10,new Field("Lorg/mortbay/jetty/servlet/PathMap;","_defaultSingletonList","Ljava/util/List;"));
                code.visitJumpStmt(GOTO_16,-1,-1,L7);
                code.visitLabel(L28);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,3},new Method("Lorg/mortbay/jetty/servlet/PathMap$Entry;","setMapped",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L29);
                code.visitFieldStmt(IGET_OBJECT,5,10,new Field("Lorg/mortbay/jetty/servlet/PathMap;","_exactMap","Lorg/mortbay/util/StringMap;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,3,0},new Method("Lorg/mortbay/util/StringMap;","put",new String[]{ "Ljava/lang/String;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitLabel(L3);
                code.visitJumpStmt(GOTO_16,-1,-1,L7);
                code.visitLabel(L30);
                code.visitStmt1R(MONITOR_EXIT,10);
                code.visitStmt1R(RETURN_OBJECT,2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m019_readExternal(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/servlet/PathMap;","readExternal",new String[]{ "Ljava/io/ObjectInput;"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visit(null, new DexType("Ljava/lang/ClassNotFoundException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"in");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(139,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(140,L1);
                ddv.visitStartLocal(0,L1,"map","Ljava/util/HashMap;",null);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(141,L2);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 2},new Method("Ljava/io/ObjectInput;","readObject",new String[]{ },"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitTypeStmt(CHECK_CAST,0,-1,"Ljava/util/HashMap;");
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,0},new Method("Lorg/mortbay/jetty/servlet/PathMap;","putAll",new String[]{ "Ljava/util/Map;"},"V"));
                code.visitLabel(L2);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m020_remove(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/servlet/PathMap;","remove",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/Object;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(9);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexLabel L3=new DexLabel();
                DexLabel L4=new DexLabel();
                code.visitTryCatch(L3,L4,new DexLabel[]{L2},new String[]{ null});
                DexLabel L5=new DexLabel();
                DexLabel L6=new DexLabel();
                code.visitTryCatch(L5,L6,new DexLabel[]{L2},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"pathSpec");
                DexLabel L7=new DexLabel();
                ddv.visitPrologue(L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(345,L8);
                ddv.visitLineNumber(347,L0);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(348,L9);
                ddv.visitStartLocal(1,L9,"spec","Ljava/lang/String;",null);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(349,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(366,L11);
                ddv.visitEndLocal(1,L11);
                ddv.visitLineNumber(350,L3);
                ddv.visitRestartLocal(1,L3);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(352,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(353,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(354,L14);
                ddv.visitLineNumber(345,L2);
                ddv.visitEndLocal(1,L2);
                ddv.visitLineNumber(356,L5);
                ddv.visitRestartLocal(1,L5);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(357,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(358,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(360,L17);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(361,L18);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(364,L19);
                code.visitLabel(L7);
                code.visitConstStmt(CONST_4,6, Integer.valueOf(2)); // int: 0x00000002  float:0.000000
                code.visitConstStmt(CONST_STRING,2,"/*");
                code.visitLabel(L8);
                code.visitStmt1R(MONITOR_ENTER,7);
                code.visitJumpStmt(IF_EQZ,8,-1,L11);
                code.visitLabel(L0);
                code.visitStmt2R(MOVE_OBJECT,0,8);
                code.visitTypeStmt(CHECK_CAST,0,-1,"Ljava/lang/String;");
                code.visitStmt2R(MOVE_OBJECT,1,0);
                code.visitLabel(L9);
                code.visitConstStmt(CONST_STRING,2,"/*");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2},new Method("Ljava/lang/String;","equals",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitJumpStmt(IF_EQZ,2,-1,L3);
                code.visitLabel(L10);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT_OBJECT,2,7,new Field("Lorg/mortbay/jetty/servlet/PathMap;","_prefixDefault","Lorg/mortbay/jetty/servlet/PathMap$Entry;"));
                code.visitLabel(L11);
                code.visitMethodStmt(INVOKE_SUPER,new int[]{ 7,8},new Method("Ljava/util/HashMap;","remove",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitLabel(L1);
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitStmt1R(MONITOR_EXIT,7);
                code.visitStmt1R(RETURN_OBJECT,2);
                code.visitLabel(L3);
                code.visitConstStmt(CONST_STRING,2,"/*");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2},new Method("Ljava/lang/String;","endsWith",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitJumpStmt(IF_EQZ,2,-1,L5);
                code.visitLabel(L12);
                code.visitFieldStmt(IGET_OBJECT,2,7,new Field("Lorg/mortbay/jetty/servlet/PathMap;","_prefixMap","Lorg/mortbay/util/StringMap;"));
                code.visitConstStmt(CONST_4,3, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/lang/String;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,4);
                code.visitStmt2R(SUB_INT_2ADDR,4,6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,3,4},new Method("Ljava/lang/String;","substring",new String[]{ "I","I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3},new Method("Lorg/mortbay/util/StringMap;","remove",new String[]{ "Ljava/lang/String;"},"Ljava/lang/Object;"));
                code.visitLabel(L13);
                code.visitFieldStmt(IGET_OBJECT,2,7,new Field("Lorg/mortbay/jetty/servlet/PathMap;","_exactMap","Lorg/mortbay/util/StringMap;"));
                code.visitConstStmt(CONST_4,3, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/lang/String;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,4);
                code.visitConstStmt(CONST_4,5, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitStmt2R(SUB_INT_2ADDR,4,5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,3,4},new Method("Ljava/lang/String;","substring",new String[]{ "I","I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3},new Method("Lorg/mortbay/util/StringMap;","remove",new String[]{ "Ljava/lang/String;"},"Ljava/lang/Object;"));
                code.visitLabel(L14);
                code.visitFieldStmt(IGET_OBJECT,2,7,new Field("Lorg/mortbay/jetty/servlet/PathMap;","_exactMap","Lorg/mortbay/util/StringMap;"));
                code.visitConstStmt(CONST_4,3, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/lang/String;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,4);
                code.visitStmt2R(SUB_INT_2ADDR,4,6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,3,4},new Method("Ljava/lang/String;","substring",new String[]{ "I","I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3},new Method("Lorg/mortbay/util/StringMap;","remove",new String[]{ "Ljava/lang/String;"},"Ljava/lang/Object;"));
                code.visitLabel(L4);
                code.visitJumpStmt(GOTO,-1,-1,L11);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,2);
                code.visitStmt1R(MONITOR_EXIT,7);
                code.visitStmt1R(THROW,2);
                code.visitLabel(L5);
                code.visitConstStmt(CONST_STRING,2,"*.");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2},new Method("Ljava/lang/String;","startsWith",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitJumpStmt(IF_EQZ,2,-1,L16);
                code.visitLabel(L15);
                code.visitFieldStmt(IGET_OBJECT,2,7,new Field("Lorg/mortbay/jetty/servlet/PathMap;","_suffixMap","Lorg/mortbay/util/StringMap;"));
                code.visitConstStmt(CONST_4,3, Integer.valueOf(2)); // int: 0x00000002  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,3},new Method("Ljava/lang/String;","substring",new String[]{ "I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3},new Method("Lorg/mortbay/util/StringMap;","remove",new String[]{ "Ljava/lang/String;"},"Ljava/lang/Object;"));
                code.visitJumpStmt(GOTO,-1,-1,L11);
                code.visitLabel(L16);
                code.visitConstStmt(CONST_STRING,2,"/");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2},new Method("Ljava/lang/String;","equals",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitJumpStmt(IF_EQZ,2,-1,L19);
                code.visitLabel(L17);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT_OBJECT,2,7,new Field("Lorg/mortbay/jetty/servlet/PathMap;","_default","Lorg/mortbay/jetty/servlet/PathMap$Entry;"));
                code.visitLabel(L18);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT_OBJECT,2,7,new Field("Lorg/mortbay/jetty/servlet/PathMap;","_defaultSingletonList","Ljava/util/List;"));
                code.visitJumpStmt(GOTO,-1,-1,L11);
                code.visitLabel(L19);
                code.visitFieldStmt(IGET_OBJECT,2,7,new Field("Lorg/mortbay/jetty/servlet/PathMap;","_exactMap","Lorg/mortbay/util/StringMap;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,1},new Method("Lorg/mortbay/util/StringMap;","remove",new String[]{ "Ljava/lang/String;"},"Ljava/lang/Object;"));
                code.visitLabel(L6);
                code.visitJumpStmt(GOTO,-1,-1,L11);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m021_writeExternal(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/servlet/PathMap;","writeExternal",new String[]{ "Ljava/io/ObjectOutput;"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"out");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(131,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(132,L1);
                ddv.visitStartLocal(0,L1,"map","Ljava/util/HashMap;",null);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(133,L2);
                code.visitLabel(L0);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/util/HashMap;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1},new Method("Ljava/util/HashMap;","<init>",new String[]{ "Ljava/util/Map;"},"V"));
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 2,0},new Method("Ljava/io/ObjectOutput;","writeObject",new String[]{ "Ljava/lang/Object;"},"V"));
                code.visitLabel(L2);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
