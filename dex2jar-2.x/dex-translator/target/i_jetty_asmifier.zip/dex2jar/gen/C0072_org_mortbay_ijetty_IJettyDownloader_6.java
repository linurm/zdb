package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0072_org_mortbay_ijetty_IJettyDownloader_6 {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(0,"Lorg/mortbay/ijetty/IJettyDownloader$6;","Lorg/mortbay/jetty/client/ContentExchange;",new String[]{ });
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("IJettyDownloader.java");
        if(cv!=null){
            DexAnnotationVisitor av00 = cv.visitAnnotation("Ldalvik/annotation/EnclosingMethod;", Visibility.SYSTEM);
            if(av00 != null) {
                av00.visit("value", new Method("Lorg/mortbay/ijetty/IJettyDownloader;","doDownload",new String[]{ "Ljava/lang/String;","Ljava/io/File;","Ljava/lang/String;"},"V"));
                av00.visitEnd();
            }
        }
        if(cv!=null){
            DexAnnotationVisitor av00 = cv.visitAnnotation("Ldalvik/annotation/InnerClass;", Visibility.SYSTEM);
            if(av00 != null) {
                av00.visit("accessFlags",  Integer.valueOf(0));
                av00.visit("name", null);
                av00.visitEnd();
            }
        }
        f000__outputStream(cv);
        f001_this$0(cv);
        f002_val$path(cv);
        f003_val$url(cv);
        f004_val$warFile(cv);
        m000__init_(cv);
        m001_closeOutputStream(cv);
        m002_getOutputStream(cv);
        m003_onConnectionFailed(cv);
        m004_onException(cv);
        m005_onExpire(cv);
        m006_onResponseComplete(cv);
        m007_onResponseContent(cv);
    }
    public static void f000__outputStream(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/ijetty/IJettyDownloader$6;","_outputStream","Ljava/io/OutputStream;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f001_this$0(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_FINAL|ACC_SYNTHETIC, new Field("Lorg/mortbay/ijetty/IJettyDownloader$6;","this$0","Lorg/mortbay/ijetty/IJettyDownloader;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f002_val$path(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_FINAL|ACC_SYNTHETIC, new Field("Lorg/mortbay/ijetty/IJettyDownloader$6;","val$path","Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f003_val$url(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_FINAL|ACC_SYNTHETIC, new Field("Lorg/mortbay/ijetty/IJettyDownloader$6;","val$url","Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f004_val$warFile(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_FINAL|ACC_SYNTHETIC, new Field("Lorg/mortbay/ijetty/IJettyDownloader$6;","val$warFile","Ljava/io/File;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void m000__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_CONSTRUCTOR, new Method("Lorg/mortbay/ijetty/IJettyDownloader$6;","<init>",new String[]{ "Lorg/mortbay/ijetty/IJettyDownloader;","Ljava/io/File;","Ljava/lang/String;","Ljava/lang/String;"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/FileNotFoundException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(371,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_OBJECT,1,0,new Field("Lorg/mortbay/ijetty/IJettyDownloader$6;","this$0","Lorg/mortbay/ijetty/IJettyDownloader;"));
                code.visitFieldStmt(IPUT_OBJECT,2,0,new Field("Lorg/mortbay/ijetty/IJettyDownloader$6;","val$warFile","Ljava/io/File;"));
                code.visitFieldStmt(IPUT_OBJECT,3,0,new Field("Lorg/mortbay/ijetty/IJettyDownloader$6;","val$path","Ljava/lang/String;"));
                code.visitFieldStmt(IPUT_OBJECT,4,0,new Field("Lorg/mortbay/ijetty/IJettyDownloader$6;","val$url","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Lorg/mortbay/jetty/client/ContentExchange;","<init>",new String[]{ },"V"));
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001_closeOutputStream(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Lorg/mortbay/ijetty/IJettyDownloader$6;","closeOutputStream",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(6);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ "Ljava/io/IOException;"});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(375,L0);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(376,L3);
                ddv.visitLineNumber(383,L1);
                ddv.visitLineNumber(378,L2);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(380,L4);
                ddv.visitStartLocal(0,L4,"e","Ljava/io/IOException;",null);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(381,L5);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,1,5,new Field("Lorg/mortbay/ijetty/IJettyDownloader$6;","_outputStream","Ljava/io/OutputStream;"));
                code.visitJumpStmt(IF_EQZ,1,-1,L1);
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,1,5,new Field("Lorg/mortbay/ijetty/IJettyDownloader$6;","_outputStream","Ljava/io/OutputStream;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/io/OutputStream;","close",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,1);
                code.visitStmt2R(MOVE_OBJECT,0,1);
                code.visitLabel(L4);
                code.visitConstStmt(CONST_STRING,1,"Jetty");
                code.visitConstStmt(CONST_STRING,2,"Error closing stream");
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1,2,0},new Method("Landroid/util/Log;","e",new String[]{ "Ljava/lang/String;","Ljava/lang/String;","Ljava/lang/Throwable;"},"I"));
                code.visitLabel(L5);
                code.visitFieldStmt(IGET_OBJECT,1,5,new Field("Lorg/mortbay/ijetty/IJettyDownloader$6;","this$0","Lorg/mortbay/ijetty/IJettyDownloader;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1},new Method("Lorg/mortbay/ijetty/IJettyDownloader;","access$200",new String[]{ "Lorg/mortbay/ijetty/IJettyDownloader;"},"Landroid/os/Handler;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitFieldStmt(IGET_OBJECT,2,5,new Field("Lorg/mortbay/ijetty/IJettyDownloader$6;","this$0","Lorg/mortbay/ijetty/IJettyDownloader;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 2},new Method("Lorg/mortbay/ijetty/IJettyDownloader;","access$200",new String[]{ "Lorg/mortbay/ijetty/IJettyDownloader;"},"Landroid/os/Handler;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitConstStmt(CONST_STRING,4,"Exception");
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 2,3,4},new Method("Landroid/os/Message;","obtain",new String[]{ "Landroid/os/Handler;","I","Ljava/lang/Object;"},"Landroid/os/Message;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2},new Method("Landroid/os/Handler;","sendMessage",new String[]{ "Landroid/os/Message;"},"Z"));
                code.visitJumpStmt(GOTO,-1,-1,L1);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m002_getOutputStream(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Lorg/mortbay/ijetty/IJettyDownloader$6;","getOutputStream",new String[]{ },"Ljava/io/OutputStream;"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(364,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(366,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(368,L2);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/ijetty/IJettyDownloader$6;","_outputStream","Ljava/io/OutputStream;"));
                code.visitJumpStmt(IF_NEZ,0,-1,L2);
                code.visitLabel(L1);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/io/FileOutputStream;");
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/ijetty/IJettyDownloader$6;","val$warFile","Ljava/io/File;"));
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1},new Method("Ljava/io/FileOutputStream;","<init>",new String[]{ "Ljava/io/File;"},"V"));
                code.visitFieldStmt(IPUT_OBJECT,0,2,new Field("Lorg/mortbay/ijetty/IJettyDownloader$6;","_outputStream","Ljava/io/OutputStream;"));
                code.visitLabel(L2);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/ijetty/IJettyDownloader$6;","_outputStream","Ljava/io/OutputStream;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m003_onConnectionFailed(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Lorg/mortbay/ijetty/IJettyDownloader$6;","onConnectionFailed",new String[]{ "Ljava/lang/Throwable;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(6);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"ex");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(324,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(325,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(326,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(327,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(328,L4);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Lorg/mortbay/ijetty/IJettyDownloader$6;","closeOutputStream",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,0,4,new Field("Lorg/mortbay/ijetty/IJettyDownloader$6;","this$0","Lorg/mortbay/ijetty/IJettyDownloader;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0},new Method("Lorg/mortbay/ijetty/IJettyDownloader;","access$200",new String[]{ "Lorg/mortbay/ijetty/IJettyDownloader;"},"Landroid/os/Handler;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(IGET_OBJECT,1,4,new Field("Lorg/mortbay/ijetty/IJettyDownloader$6;","this$0","Lorg/mortbay/ijetty/IJettyDownloader;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1},new Method("Lorg/mortbay/ijetty/IJettyDownloader;","access$200",new String[]{ "Lorg/mortbay/ijetty/IJettyDownloader;"},"Landroid/os/Handler;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitConstStmt(CONST_STRING,3,"Connection failed");
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1,2,3},new Method("Landroid/os/Message;","obtain",new String[]{ "Landroid/os/Handler;","I","Ljava/lang/Object;"},"Landroid/os/Message;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Landroid/os/Handler;","sendMessage",new String[]{ "Landroid/os/Message;"},"Z"));
                code.visitLabel(L2);
                code.visitConstStmt(CONST_STRING,0,"Jetty");
                code.visitConstStmt(CONST_STRING,1,"Connection fail");
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0,1,5},new Method("Landroid/util/Log;","e",new String[]{ "Ljava/lang/String;","Ljava/lang/String;","Ljava/lang/Throwable;"},"I"));
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_SUPER,new int[]{ 4,5},new Method("Lorg/mortbay/jetty/client/ContentExchange;","onConnectionFailed",new String[]{ "Ljava/lang/Throwable;"},"V"));
                code.visitLabel(L4);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m004_onException(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Lorg/mortbay/ijetty/IJettyDownloader$6;","onException",new String[]{ "Ljava/lang/Throwable;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(6);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"ex");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(332,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(333,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(334,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(335,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(336,L4);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Lorg/mortbay/ijetty/IJettyDownloader$6;","closeOutputStream",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,0,4,new Field("Lorg/mortbay/ijetty/IJettyDownloader$6;","this$0","Lorg/mortbay/ijetty/IJettyDownloader;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0},new Method("Lorg/mortbay/ijetty/IJettyDownloader;","access$200",new String[]{ "Lorg/mortbay/ijetty/IJettyDownloader;"},"Landroid/os/Handler;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(IGET_OBJECT,1,4,new Field("Lorg/mortbay/ijetty/IJettyDownloader$6;","this$0","Lorg/mortbay/ijetty/IJettyDownloader;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1},new Method("Lorg/mortbay/ijetty/IJettyDownloader;","access$200",new String[]{ "Lorg/mortbay/ijetty/IJettyDownloader;"},"Landroid/os/Handler;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitConstStmt(CONST_STRING,3,"Exception");
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1,2,3},new Method("Landroid/os/Message;","obtain",new String[]{ "Landroid/os/Handler;","I","Ljava/lang/Object;"},"Landroid/os/Message;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Landroid/os/Handler;","sendMessage",new String[]{ "Landroid/os/Message;"},"Z"));
                code.visitLabel(L2);
                code.visitConstStmt(CONST_STRING,0,"Jetty");
                code.visitConstStmt(CONST_STRING,1,"Error on download");
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0,1,5},new Method("Landroid/util/Log;","e",new String[]{ "Ljava/lang/String;","Ljava/lang/String;","Ljava/lang/Throwable;"},"I"));
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_SUPER,new int[]{ 4,5},new Method("Lorg/mortbay/jetty/client/ContentExchange;","onException",new String[]{ "Ljava/lang/Throwable;"},"V"));
                code.visitLabel(L4);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m005_onExpire(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Lorg/mortbay/ijetty/IJettyDownloader$6;","onExpire",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(340,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(341,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(342,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(343,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(344,L4);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Lorg/mortbay/ijetty/IJettyDownloader$6;","closeOutputStream",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,0,4,new Field("Lorg/mortbay/ijetty/IJettyDownloader$6;","this$0","Lorg/mortbay/ijetty/IJettyDownloader;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0},new Method("Lorg/mortbay/ijetty/IJettyDownloader;","access$200",new String[]{ "Lorg/mortbay/ijetty/IJettyDownloader;"},"Landroid/os/Handler;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(IGET_OBJECT,1,4,new Field("Lorg/mortbay/ijetty/IJettyDownloader$6;","this$0","Lorg/mortbay/ijetty/IJettyDownloader;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1},new Method("Lorg/mortbay/ijetty/IJettyDownloader;","access$200",new String[]{ "Lorg/mortbay/ijetty/IJettyDownloader;"},"Landroid/os/Handler;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitConstStmt(CONST_STRING,3,"Expired");
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1,2,3},new Method("Landroid/os/Message;","obtain",new String[]{ "Landroid/os/Handler;","I","Ljava/lang/Object;"},"Landroid/os/Message;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Landroid/os/Handler;","sendMessage",new String[]{ "Landroid/os/Message;"},"Z"));
                code.visitLabel(L2);
                code.visitConstStmt(CONST_STRING,0,"Jetty");
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,2,"Expired: ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitFieldStmt(IGET_OBJECT,2,4,new Field("Lorg/mortbay/ijetty/IJettyDownloader$6;","val$url","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0,1},new Method("Landroid/util/Log;","e",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"I"));
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_SUPER,new int[]{ 4},new Method("Lorg/mortbay/jetty/client/ContentExchange;","onExpire",new String[]{ },"V"));
                code.visitLabel(L4);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m006_onResponseComplete(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Lorg/mortbay/ijetty/IJettyDownloader$6;","onResponseComplete",new String[]{ },"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(7);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(312,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(313,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(314,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(320,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(317,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(318,L6);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_STRING,5,"Bad status: ");
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Lorg/mortbay/ijetty/IJettyDownloader$6;","closeOutputStream",new String[]{ },"V"));
                code.visitLabel(L2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Lorg/mortbay/ijetty/IJettyDownloader$6;","getResponseStatus",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitConstStmt(CONST_16,1, Integer.valueOf(200)); // int: 0x000000c8  float:0.000000
                code.visitJumpStmt(IF_NE,0,1,L5);
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,0,6,new Field("Lorg/mortbay/ijetty/IJettyDownloader$6;","this$0","Lorg/mortbay/ijetty/IJettyDownloader;"));
                code.visitFieldStmt(IGET_OBJECT,1,6,new Field("Lorg/mortbay/ijetty/IJettyDownloader$6;","val$warFile","Ljava/io/File;"));
                code.visitFieldStmt(IGET_OBJECT,2,6,new Field("Lorg/mortbay/ijetty/IJettyDownloader$6;","val$path","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1,2},new Method("Lorg/mortbay/ijetty/IJettyDownloader;","install",new String[]{ "Ljava/io/File;","Ljava/lang/String;"},"V"));
                code.visitLabel(L4);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L5);
                code.visitConstStmt(CONST_STRING,0,"Jetty");
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,2,"Bad status: ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,5},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Lorg/mortbay/ijetty/IJettyDownloader$6;","getResponseStatus",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "I"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0,1},new Method("Landroid/util/Log;","e",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"I"));
                code.visitLabel(L6);
                code.visitFieldStmt(IGET_OBJECT,0,6,new Field("Lorg/mortbay/ijetty/IJettyDownloader$6;","this$0","Lorg/mortbay/ijetty/IJettyDownloader;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0},new Method("Lorg/mortbay/ijetty/IJettyDownloader;","access$200",new String[]{ "Lorg/mortbay/ijetty/IJettyDownloader;"},"Landroid/os/Handler;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(IGET_OBJECT,1,6,new Field("Lorg/mortbay/ijetty/IJettyDownloader$6;","this$0","Lorg/mortbay/ijetty/IJettyDownloader;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1},new Method("Lorg/mortbay/ijetty/IJettyDownloader;","access$200",new String[]{ "Lorg/mortbay/ijetty/IJettyDownloader;"},"Landroid/os/Handler;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitTypeStmt(NEW_INSTANCE,3,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 3},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,4,"Bad status: ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,5},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Lorg/mortbay/ijetty/IJettyDownloader$6;","getResponseStatus",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,4},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "I"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1,2,3},new Method("Landroid/os/Message;","obtain",new String[]{ "Landroid/os/Handler;","I","Ljava/lang/Object;"},"Landroid/os/Message;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Landroid/os/Handler;","sendMessage",new String[]{ "Landroid/os/Message;"},"Z"));
                code.visitJumpStmt(GOTO,-1,-1,L4);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m007_onResponseContent(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Lorg/mortbay/ijetty/IJettyDownloader$6;","onResponseContent",new String[]{ "Lorg/mortbay/io/Buffer;"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(8);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ "Ljava/lang/Exception;"});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"content");
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(351,L0);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(352,L3);
                ddv.visitStartLocal(1,L3,"os","Ljava/io/OutputStream;",null);
                ddv.visitLineNumber(359,L1);
                ddv.visitEndLocal(1,L1);
                ddv.visitLineNumber(354,L2);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(356,L4);
                ddv.visitStartLocal(0,L4,"e","Ljava/lang/Exception;",null);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(357,L5);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Lorg/mortbay/ijetty/IJettyDownloader$6;","getOutputStream",new String[]{ },"Ljava/io/OutputStream;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 7,1},new Method("Lorg/mortbay/io/Buffer;","writeTo",new String[]{ "Ljava/io/OutputStream;"},"V"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,2);
                code.visitStmt2R(MOVE_OBJECT,0,2);
                code.visitLabel(L4);
                code.visitConstStmt(CONST_STRING,2,"Jetty");
                code.visitConstStmt(CONST_STRING,3,"Error reading content");
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 2,3,0},new Method("Landroid/util/Log;","e",new String[]{ "Ljava/lang/String;","Ljava/lang/String;","Ljava/lang/Throwable;"},"I"));
                code.visitLabel(L5);
                code.visitFieldStmt(IGET_OBJECT,2,6,new Field("Lorg/mortbay/ijetty/IJettyDownloader$6;","this$0","Lorg/mortbay/ijetty/IJettyDownloader;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 2},new Method("Lorg/mortbay/ijetty/IJettyDownloader;","access$200",new String[]{ "Lorg/mortbay/ijetty/IJettyDownloader;"},"Landroid/os/Handler;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitFieldStmt(IGET_OBJECT,3,6,new Field("Lorg/mortbay/ijetty/IJettyDownloader$6;","this$0","Lorg/mortbay/ijetty/IJettyDownloader;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 3},new Method("Lorg/mortbay/ijetty/IJettyDownloader;","access$200",new String[]{ "Lorg/mortbay/ijetty/IJettyDownloader;"},"Landroid/os/Handler;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitConstStmt(CONST_4,4, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitConstStmt(CONST_STRING,5,"Exception");
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 3,4,5},new Method("Landroid/os/Message;","obtain",new String[]{ "Landroid/os/Handler;","I","Ljava/lang/Object;"},"Landroid/os/Message;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3},new Method("Landroid/os/Handler;","sendMessage",new String[]{ "Landroid/os/Message;"},"Z"));
                code.visitJumpStmt(GOTO,-1,-1,L1);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
