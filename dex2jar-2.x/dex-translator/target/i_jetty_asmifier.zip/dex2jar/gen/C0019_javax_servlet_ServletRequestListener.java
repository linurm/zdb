package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0019_javax_servlet_ServletRequestListener {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(ACC_PUBLIC|ACC_INTERFACE|ACC_ABSTRACT,"Ljavax/servlet/ServletRequestListener;","Ljava/lang/Object;",new String[]{ "Ljava/util/EventListener;"});
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("ServletRequestListener.java");
        m000_requestDestroyed(cv);
        m001_requestInitialized(cv);
    }
    public static void m000_requestDestroyed(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Ljavax/servlet/ServletRequestListener;","requestDestroyed",new String[]{ "Ljavax/servlet/ServletRequestEvent;"},"V"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m001_requestInitialized(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Ljavax/servlet/ServletRequestListener;","requestInitialized",new String[]{ "Ljavax/servlet/ServletRequestEvent;"},"V"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
}
