package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0354_org_mortbay_jetty_webapp_WebAppClassLoader {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(ACC_PUBLIC,"Lorg/mortbay/jetty/webapp/WebAppClassLoader;","Ljava/net/URLClassLoader;",new String[]{ });
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("WebAppClassLoader.java");
        f000__context(cv);
        f001__extensions(cv);
        f002__name(cv);
        f003__parent(cv);
        m000__init_(cv);
        m001__init_(cv);
        m002_isFileSupported(cv);
        m003_addClassPath(cv);
        m004_addJars(cv);
        m005_destroy(cv);
        m006_getContext(cv);
        m007_getName(cv);
        m008_getPermissions(cv);
        m009_getResource(cv);
        m010_isServerPath(cv);
        m011_isSystemPath(cv);
        m012_loadClass(cv);
        m013_loadClass(cv);
        m014_setName(cv);
        m015_toString(cv);
    }
    public static void f000__context(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/webapp/WebAppClassLoader;","_context","Lorg/mortbay/jetty/webapp/WebAppContext;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f001__extensions(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/webapp/WebAppClassLoader;","_extensions","Ljava/util/HashSet;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f002__name(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/webapp/WebAppClassLoader;","_name","Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f003__parent(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/webapp/WebAppClassLoader;","_parent","Ljava/lang/ClassLoader;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void m000__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/jetty/webapp/WebAppClassLoader;","<init>",new String[]{ "Ljava/lang/ClassLoader;","Lorg/mortbay/jetty/webapp/WebAppContext;"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(8);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"parent");
                ddv.visitParameterName(1,"context");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(74,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(78,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(79,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(80,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(81,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(74,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(83,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(84,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(85,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(87,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(88,L11);
                ddv.visitStartLocal(0,L11,"extensions","Ljava/lang/String;",null);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(90,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(91,L13);
                ddv.visitStartLocal(1,L13,"tokenizer","Ljava/util/StringTokenizer;",null);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(92,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(95,L15);
                ddv.visitEndLocal(1,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(96,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(97,L17);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_CLASS,4,new DexType("Lorg/mortbay/jetty/webapp/WebAppClassLoader;"));
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitTypeStmt(NEW_ARRAY,2,2,"[Ljava/net/URL;");
                code.visitJumpStmt(IF_EQZ,6,-1,L6);
                code.visitStmt2R(MOVE_OBJECT,3,6);
                DexLabel L18=new DexLabel();
                code.visitLabel(L18);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 5,2,3},new Method("Ljava/net/URLClassLoader;","<init>",new String[]{ "[Ljava/net/URL;","Ljava/lang/ClassLoader;"},"V"));
                code.visitLabel(L2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Lorg/mortbay/jetty/webapp/WebAppClassLoader;","getParent",new String[]{ },"Ljava/lang/ClassLoader;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitFieldStmt(IPUT_OBJECT,2,5,new Field("Lorg/mortbay/jetty/webapp/WebAppClassLoader;","_parent","Ljava/lang/ClassLoader;"));
                code.visitLabel(L3);
                code.visitFieldStmt(IPUT_OBJECT,7,5,new Field("Lorg/mortbay/jetty/webapp/WebAppClassLoader;","_context","Lorg/mortbay/jetty/webapp/WebAppContext;"));
                code.visitLabel(L4);
                code.visitFieldStmt(IGET_OBJECT,2,5,new Field("Lorg/mortbay/jetty/webapp/WebAppClassLoader;","_parent","Ljava/lang/ClassLoader;"));
                code.visitJumpStmt(IF_NEZ,2,-1,L7);
                code.visitLabel(L5);
                code.visitTypeStmt(NEW_INSTANCE,2,-1,"Ljava/lang/IllegalArgumentException;");
                code.visitConstStmt(CONST_STRING,3,"no parent classloader!");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2,3},new Method("Ljava/lang/IllegalArgumentException;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitStmt1R(THROW,2);
                code.visitLabel(L6);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Ljava/lang/Thread;","currentThread",new String[]{ },"Ljava/lang/Thread;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Ljava/lang/Thread;","getContextClassLoader",new String[]{ },"Ljava/lang/ClassLoader;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                DexLabel L19=new DexLabel();
                code.visitJumpStmt(IF_EQZ,3,-1,L19);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Ljava/lang/Thread;","currentThread",new String[]{ },"Ljava/lang/Thread;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Ljava/lang/Thread;","getContextClassLoader",new String[]{ },"Ljava/lang/ClassLoader;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitJumpStmt(GOTO,-1,-1,L18);
                code.visitLabel(L19);
                code.visitConstStmt(CONST_CLASS,3,new DexType("Lorg/mortbay/jetty/webapp/WebAppClassLoader;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Ljava/lang/Class;","getClassLoader",new String[]{ },"Ljava/lang/ClassLoader;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                DexLabel L20=new DexLabel();
                code.visitJumpStmt(IF_EQZ,3,-1,L20);
                code.visitConstStmt(CONST_CLASS,3,new DexType("Lorg/mortbay/jetty/webapp/WebAppClassLoader;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Ljava/lang/Class;","getClassLoader",new String[]{ },"Ljava/lang/ClassLoader;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitJumpStmt(GOTO,-1,-1,L18);
                code.visitLabel(L20);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Ljava/lang/ClassLoader;","getSystemClassLoader",new String[]{ },"Ljava/lang/ClassLoader;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitJumpStmt(GOTO,-1,-1,L18);
                code.visitLabel(L7);
                code.visitTypeStmt(NEW_INSTANCE,2,-1,"Ljava/util/HashSet;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2},new Method("Ljava/util/HashSet;","<init>",new String[]{ },"V"));
                code.visitFieldStmt(IPUT_OBJECT,2,5,new Field("Lorg/mortbay/jetty/webapp/WebAppClassLoader;","_extensions","Ljava/util/HashSet;"));
                code.visitLabel(L8);
                code.visitFieldStmt(IGET_OBJECT,2,5,new Field("Lorg/mortbay/jetty/webapp/WebAppClassLoader;","_extensions","Ljava/util/HashSet;"));
                code.visitConstStmt(CONST_STRING,3,".jar");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3},new Method("Ljava/util/HashSet;","add",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitLabel(L9);
                code.visitFieldStmt(IGET_OBJECT,2,5,new Field("Lorg/mortbay/jetty/webapp/WebAppClassLoader;","_extensions","Ljava/util/HashSet;"));
                code.visitConstStmt(CONST_STRING,3,".zip");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3},new Method("Ljava/util/HashSet;","add",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitLabel(L10);
                code.visitTypeStmt(NEW_INSTANCE,2,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_CLASS,3,new DexType("Lorg/mortbay/jetty/webapp/WebAppClassLoader;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Ljava/lang/Class;","getName",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitConstStmt(CONST_STRING,3,".extensions");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 2},new Method("Ljava/lang/System;","getProperty",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L11);
                code.visitJumpStmt(IF_EQZ,0,-1,L15);
                code.visitLabel(L12);
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Ljava/util/StringTokenizer;");
                code.visitConstStmt(CONST_STRING,2,",;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1,0,2},new Method("Ljava/util/StringTokenizer;","<init>",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"V"));
                code.visitLabel(L13);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/util/StringTokenizer;","hasMoreTokens",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitJumpStmt(IF_EQZ,2,-1,L15);
                code.visitLabel(L14);
                code.visitFieldStmt(IGET_OBJECT,2,5,new Field("Lorg/mortbay/jetty/webapp/WebAppClassLoader;","_extensions","Ljava/util/HashSet;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/util/StringTokenizer;","nextToken",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Ljava/lang/String;","trim",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3},new Method("Ljava/util/HashSet;","add",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitJumpStmt(GOTO,-1,-1,L13);
                code.visitLabel(L15);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7},new Method("Lorg/mortbay/jetty/webapp/WebAppContext;","getExtraClasspath",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitJumpStmt(IF_EQZ,2,-1,L17);
                code.visitLabel(L16);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7},new Method("Lorg/mortbay/jetty/webapp/WebAppContext;","getExtraClasspath",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,2},new Method("Lorg/mortbay/jetty/webapp/WebAppClassLoader;","addClassPath",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L17);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/jetty/webapp/WebAppClassLoader;","<init>",new String[]{ "Lorg/mortbay/jetty/webapp/WebAppContext;"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"context");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(65,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(66,L1);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1,0,2},new Method("Lorg/mortbay/jetty/webapp/WebAppClassLoader;","<init>",new String[]{ "Ljava/lang/ClassLoader;","Lorg/mortbay/jetty/webapp/WebAppContext;"},"V"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m002_isFileSupported(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PRIVATE, new Method("Lorg/mortbay/jetty/webapp/WebAppClassLoader;","isFileSupported",new String[]{ "Ljava/lang/String;"},"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"file");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(203,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(204,L1);
                ddv.visitStartLocal(0,L1,"dot","I",null);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_16,1, Integer.valueOf(46)); // int: 0x0000002e  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,1},new Method("Ljava/lang/String;","lastIndexOf",new String[]{ "I"},"I"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(-1)); // int: 0xffffffff  float:NaN
                DexLabel L2=new DexLabel();
                code.visitJumpStmt(IF_EQ,0,1,L2);
                code.visitFieldStmt(IGET_OBJECT,1,3,new Field("Lorg/mortbay/jetty/webapp/WebAppClassLoader;","_extensions","Ljava/util/HashSet;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,0},new Method("Ljava/lang/String;","substring",new String[]{ "I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2},new Method("Ljava/util/HashSet;","contains",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitJumpStmt(IF_EQZ,1,-1,L2);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                DexLabel L3=new DexLabel();
                code.visitLabel(L3);
                code.visitStmt1R(RETURN,1);
                code.visitLabel(L2);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L3);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m003_addClassPath(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/webapp/WebAppClassLoader;","addClassPath",new String[]{ "Ljava/lang/String;"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(14);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexLabel L3=new DexLabel();
                DexLabel L4=new DexLabel();
                code.visitTryCatch(L1,L3,new DexLabel[]{L4},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"classPath");
                DexLabel L5=new DexLabel();
                ddv.visitPrologue(L5);
                ddv.visitLineNumber(133,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(195,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(136,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(137,L8);
                ddv.visitStartLocal(8,L8,"tokenizer","Ljava/util/StringTokenizer;",null);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(139,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(140,L10);
                ddv.visitStartLocal(6,L10,"resource","Lorg/mortbay/resource/Resource;",null);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(141,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(144,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(145,L13);
                ddv.visitStartLocal(0,L13,"file","Ljava/io/File;",null);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(147,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(148,L15);
                ddv.visitStartLocal(9,L15,"url","Ljava/net/URL;",null);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(153,L16);
                ddv.visitEndLocal(9,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(155,L17);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(156,L18);
                ddv.visitStartLocal(1,L18,"in","Ljava/io/InputStream;",null);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(157,L19);
                ddv.visitStartLocal(7,L19,"tmp_dir","Ljava/io/File;",null);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(159,L20);
                DexLabel L21=new DexLabel();
                ddv.visitLineNumber(160,L21);
                DexLabel L22=new DexLabel();
                ddv.visitLineNumber(161,L22);
                DexLabel L23=new DexLabel();
                ddv.visitLineNumber(163,L23);
                DexLabel L24=new DexLabel();
                ddv.visitLineNumber(164,L24);
                ddv.visitStartLocal(3,L24,"lib","Ljava/io/File;",null);
                DexLabel L25=new DexLabel();
                ddv.visitLineNumber(166,L25);
                DexLabel L26=new DexLabel();
                ddv.visitLineNumber(167,L26);
                DexLabel L27=new DexLabel();
                ddv.visitLineNumber(169,L27);
                DexLabel L28=new DexLabel();
                ddv.visitLineNumber(171,L28);
                ddv.visitStartLocal(2,L28,"jar","Ljava/io/File;",null);
                DexLabel L29=new DexLabel();
                ddv.visitLineNumber(172,L29);
                DexLabel L30=new DexLabel();
                ddv.visitLineNumber(173,L30);
                DexLabel L31=new DexLabel();
                ddv.visitLineNumber(174,L31);
                ddv.visitLineNumber(177,L0);
                ddv.visitStartLocal(4,L0,"out","Ljava/io/FileOutputStream;",null);
                ddv.visitLineNumber(178,L1);
                ddv.visitStartLocal(5,L1,"out","Ljava/io/FileOutputStream;",null);
                ddv.visitLineNumber(182,L3);
                ddv.visitEndLocal(4,L3);
                DexLabel L32=new DexLabel();
                ddv.visitLineNumber(185,L32);
                DexLabel L33=new DexLabel();
                ddv.visitLineNumber(186,L33);
                ddv.visitRestartLocal(9,L33);
                ddv.visitLineNumber(182,L2);
                ddv.visitEndLocal(5,L2);
                ddv.visitEndLocal(9,L2);
                ddv.visitRestartLocal(4,L2);
                DexLabel L34=new DexLabel();
                ddv.visitLineNumber(190,L34);
                ddv.visitEndLocal(1,L34);
                ddv.visitEndLocal(7,L34);
                ddv.visitEndLocal(3,L34);
                ddv.visitEndLocal(2,L34);
                ddv.visitEndLocal(4,L34);
                DexLabel L35=new DexLabel();
                ddv.visitLineNumber(191,L35);
                ddv.visitRestartLocal(9,L35);
                ddv.visitLineNumber(182,L4);
                ddv.visitEndLocal(9,L4);
                ddv.visitRestartLocal(1,L4);
                ddv.visitRestartLocal(2,L4);
                ddv.visitRestartLocal(3,L4);
                ddv.visitRestartLocal(5,L4);
                ddv.visitRestartLocal(7,L4);
                DexLabel L36=new DexLabel();
                ddv.visitRestartLocal(4,L36);
                code.visitLabel(L5);
                code.visitJumpStmt(IF_NEZ,13,-1,L7);
                code.visitLabel(L6);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L7);
                code.visitTypeStmt(NEW_INSTANCE,8,-1,"Ljava/util/StringTokenizer;");
                code.visitConstStmt(CONST_STRING,10,",;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 8,13,10},new Method("Ljava/util/StringTokenizer;","<init>",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"V"));
                code.visitLabel(L8);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8},new Method("Ljava/util/StringTokenizer;","hasMoreTokens",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,10);
                code.visitJumpStmt(IF_EQZ,10,-1,L6);
                code.visitLabel(L9);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8},new Method("Ljava/util/StringTokenizer;","nextToken",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,10);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 10},new Method("Lorg/mortbay/resource/Resource;","newResource",new String[]{ "Ljava/lang/String;"},"Lorg/mortbay/resource/Resource;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitLabel(L10);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Lorg/mortbay/log/Log;","isDebugEnabled",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,10);
                code.visitJumpStmt(IF_EQZ,10,-1,L12);
                code.visitLabel(L11);
                code.visitTypeStmt(NEW_INSTANCE,10,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 10},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,11,"Path resource=");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10,11},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,10);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10,6},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,10);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,10);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 10},new Method("Lorg/mortbay/log/Log;","debug",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L12);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Lorg/mortbay/resource/Resource;","getFile",new String[]{ },"Ljava/io/File;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L13);
                code.visitJumpStmt(IF_EQZ,0,-1,L16);
                code.visitLabel(L14);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Lorg/mortbay/resource/Resource;","getURL",new String[]{ },"Ljava/net/URL;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,9);
                code.visitLabel(L15);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 12,9},new Method("Lorg/mortbay/jetty/webapp/WebAppClassLoader;","addURL",new String[]{ "Ljava/net/URL;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L8);
                code.visitLabel(L16);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Lorg/mortbay/resource/Resource;","isDirectory",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,10);
                code.visitJumpStmt(IF_NEZ,10,-1,L34);
                code.visitJumpStmt(IF_NEZ,0,-1,L34);
                code.visitLabel(L17);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Lorg/mortbay/resource/Resource;","getInputStream",new String[]{ },"Ljava/io/InputStream;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L18);
                code.visitFieldStmt(IGET_OBJECT,10,12,new Field("Lorg/mortbay/jetty/webapp/WebAppClassLoader;","_context","Lorg/mortbay/jetty/webapp/WebAppContext;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10},new Method("Lorg/mortbay/jetty/webapp/WebAppContext;","getTempDirectory",new String[]{ },"Ljava/io/File;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitLabel(L19);
                code.visitJumpStmt(IF_NEZ,7,-1,L23);
                code.visitLabel(L20);
                code.visitConstStmt(CONST_STRING,10,"jetty.cl.lib");
                code.visitConstStmt(CONST_4,11, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 10,11},new Method("Ljava/io/File;","createTempFile",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"Ljava/io/File;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitLabel(L21);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7},new Method("Ljava/io/File;","mkdir",new String[]{ },"Z"));
                code.visitLabel(L22);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7},new Method("Ljava/io/File;","deleteOnExit",new String[]{ },"V"));
                code.visitLabel(L23);
                code.visitTypeStmt(NEW_INSTANCE,3,-1,"Ljava/io/File;");
                code.visitConstStmt(CONST_STRING,10,"lib");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 3,7,10},new Method("Ljava/io/File;","<init>",new String[]{ "Ljava/io/File;","Ljava/lang/String;"},"V"));
                code.visitLabel(L24);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Ljava/io/File;","exists",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,10);
                code.visitJumpStmt(IF_NEZ,10,-1,L27);
                code.visitLabel(L25);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Ljava/io/File;","mkdir",new String[]{ },"Z"));
                code.visitLabel(L26);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Ljava/io/File;","deleteOnExit",new String[]{ },"V"));
                code.visitLabel(L27);
                code.visitConstStmt(CONST_STRING,10,"Jetty-");
                code.visitConstStmt(CONST_STRING,11,".jar");
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 10,11,3},new Method("Ljava/io/File;","createTempFile",new String[]{ "Ljava/lang/String;","Ljava/lang/String;","Ljava/io/File;"},"Ljava/io/File;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitLabel(L28);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Ljava/io/File;","deleteOnExit",new String[]{ },"V"));
                code.visitLabel(L29);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Lorg/mortbay/log/Log;","isDebugEnabled",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,10);
                code.visitJumpStmt(IF_EQZ,10,-1,L31);
                code.visitLabel(L30);
                code.visitTypeStmt(NEW_INSTANCE,10,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 10},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,11,"Extract ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10,11},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,10);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10,6},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,10);
                code.visitConstStmt(CONST_STRING,11," to ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10,11},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,10);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10,2},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,10);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,10);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 10},new Method("Lorg/mortbay/log/Log;","debug",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L31);
                code.visitConstStmt(CONST_4,4, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L0);
                code.visitTypeStmt(NEW_INSTANCE,5,-1,"Ljava/io/FileOutputStream;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 5,2},new Method("Ljava/io/FileOutputStream;","<init>",new String[]{ "Ljava/io/File;"},"V"));
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1,5},new Method("Lorg/mortbay/util/IO;","copy",new String[]{ "Ljava/io/InputStream;","Ljava/io/OutputStream;"},"V"));
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 5},new Method("Lorg/mortbay/util/IO;","close",new String[]{ "Ljava/io/OutputStream;"},"V"));
                code.visitLabel(L32);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Ljava/io/File;","toURL",new String[]{ },"Ljava/net/URL;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,9);
                code.visitLabel(L33);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 12,9},new Method("Lorg/mortbay/jetty/webapp/WebAppClassLoader;","addURL",new String[]{ "Ljava/net/URL;"},"V"));
                code.visitJumpStmt(GOTO_16,-1,-1,L8);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,10);
                DexLabel L37=new DexLabel();
                code.visitLabel(L37);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 4},new Method("Lorg/mortbay/util/IO;","close",new String[]{ "Ljava/io/OutputStream;"},"V"));
                code.visitStmt1R(THROW,10);
                code.visitLabel(L34);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Lorg/mortbay/resource/Resource;","getURL",new String[]{ },"Ljava/net/URL;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,9);
                code.visitLabel(L35);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 12,9},new Method("Lorg/mortbay/jetty/webapp/WebAppClassLoader;","addURL",new String[]{ "Ljava/net/URL;"},"V"));
                code.visitJumpStmt(GOTO_16,-1,-1,L8);
                code.visitLabel(L4);
                code.visitStmt1R(MOVE_EXCEPTION,10);
                code.visitStmt2R(MOVE_OBJECT,4,5);
                code.visitLabel(L36);
                code.visitJumpStmt(GOTO,-1,-1,L37);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m004_addJars(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/webapp/WebAppClassLoader;","addJars",new String[]{ "Lorg/mortbay/resource/Resource;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(10);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ "Ljava/lang/Exception;"});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"lib");
                DexLabel L3=new DexLabel();
                ddv.visitPrologue(L3);
                ddv.visitLineNumber(217,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(219,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(220,L5);
                ddv.visitStartLocal(2,L5,"files","[Ljava/lang/String;",null);
                DexLabel L6=new DexLabel();
                ddv.visitStartLocal(1,L6,"f","I",null);
                ddv.visitLineNumber(223,L0);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(224,L7);
                ddv.visitStartLocal(3,L7,"fn","Lorg/mortbay/resource/Resource;",null);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(225,L8);
                ddv.visitStartLocal(4,L8,"fnlc","Ljava/lang/String;",null);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(227,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(228,L10);
                ddv.visitStartLocal(5,L10,"jar","Ljava/lang/String;",null);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(229,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(230,L12);
                ddv.visitRestartLocal(5,L12);
                ddv.visitLineNumber(220,L1);
                ddv.visitEndLocal(3,L1);
                ddv.visitEndLocal(4,L1);
                ddv.visitEndLocal(5,L1);
                ddv.visitLineNumber(233,L2);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(235,L13);
                ddv.visitStartLocal(0,L13,"ex","Ljava/lang/Exception;",null);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(239,L14);
                ddv.visitEndLocal(2,L14);
                ddv.visitEndLocal(1,L14);
                ddv.visitEndLocal(0,L14);
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9},new Method("Lorg/mortbay/resource/Resource;","exists",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,6);
                code.visitJumpStmt(IF_EQZ,6,-1,L14);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9},new Method("Lorg/mortbay/resource/Resource;","isDirectory",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,6);
                code.visitJumpStmt(IF_EQZ,6,-1,L14);
                code.visitLabel(L4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9},new Method("Lorg/mortbay/resource/Resource;","list",new String[]{ },"[Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitLabel(L5);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L6);
                code.visitJumpStmt(IF_EQZ,2,-1,L14);
                code.visitStmt2R(ARRAY_LENGTH,6,2);
                code.visitJumpStmt(IF_GE,1,6,L14);
                code.visitLabel(L0);
                code.visitStmt3R(AGET_OBJECT,6,2,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9,6},new Method("Lorg/mortbay/resource/Resource;","addPath",new String[]{ "Ljava/lang/String;"},"Lorg/mortbay/resource/Resource;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitLabel(L7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Lorg/mortbay/resource/Resource;","getName",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Ljava/lang/String;","toLowerCase",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitLabel(L8);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 8,4},new Method("Lorg/mortbay/jetty/webapp/WebAppClassLoader;","isFileSupported",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,6);
                code.visitJumpStmt(IF_EQZ,6,-1,L1);
                code.visitLabel(L9);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Ljava/lang/Object;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitLabel(L10);
                code.visitConstStmt(CONST_STRING,6,",");
                code.visitConstStmt(CONST_STRING,7,"%2C");
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 5,6,7},new Method("Lorg/mortbay/util/StringUtil;","replace",new String[]{ "Ljava/lang/String;","Ljava/lang/String;","Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitLabel(L11);
                code.visitConstStmt(CONST_STRING,6,";");
                code.visitConstStmt(CONST_STRING,7,"%3B");
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 5,6,7},new Method("Lorg/mortbay/util/StringUtil;","replace",new String[]{ "Ljava/lang/String;","Ljava/lang/String;","Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitLabel(L12);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8,5},new Method("Lorg/mortbay/jetty/webapp/WebAppClassLoader;","addClassPath",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L1);
                code.visitStmt2R1N(ADD_INT_LIT8,1,1,1);
                code.visitJumpStmt(GOTO,-1,-1,L6);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,6);
                code.visitStmt2R(MOVE_OBJECT,0,6);
                code.visitLabel(L13);
                code.visitConstStmt(CONST_STRING,6,"EXCEPTION ");
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 6,0},new Method("Lorg/mortbay/log/Log;","warn",new String[]{ "Ljava/lang/String;","Ljava/lang/Throwable;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L1);
                code.visitLabel(L14);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m005_destroy(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/webapp/WebAppClassLoader;","destroy",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(243,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(244,L1);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/jetty/webapp/WebAppClassLoader;","_parent","Ljava/lang/ClassLoader;"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m006_getContext(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/webapp/WebAppClassLoader;","getContext",new String[]{ },"Lorg/mortbay/jetty/handler/ContextHandler;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(121,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/webapp/WebAppClassLoader;","_context","Lorg/mortbay/jetty/webapp/WebAppContext;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m007_getName(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/webapp/WebAppClassLoader;","getName",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(105,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/webapp/WebAppClassLoader;","_name","Ljava/lang/String;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m008_getPermissions(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/webapp/WebAppClassLoader;","getPermissions",new String[]{ "Ljava/security/CodeSource;"},"Ljava/security/PermissionCollection;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"cs");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(251,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(252,L1);
                ddv.visitStartLocal(1,L1,"permissions","Ljava/security/PermissionCollection;",null);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(253,L2);
                ddv.visitStartLocal(0,L2,"pc","Ljava/security/PermissionCollection;",null);
                DexLabel L3=new DexLabel();
                ddv.visitEndLocal(0,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(252,L4);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,2,3,new Field("Lorg/mortbay/jetty/webapp/WebAppClassLoader;","_context","Lorg/mortbay/jetty/webapp/WebAppContext;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/jetty/webapp/WebAppContext;","getPermissions",new String[]{ },"Ljava/security/PermissionCollection;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L1);
                code.visitJumpStmt(IF_NEZ,1,-1,L3);
                code.visitMethodStmt(INVOKE_SUPER,new int[]{ 3,4},new Method("Ljava/net/URLClassLoader;","getPermissions",new String[]{ "Ljava/security/CodeSource;"},"Ljava/security/PermissionCollection;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitStmt2R(MOVE_OBJECT,0,2);
                code.visitLabel(L2);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitLabel(L3);
                code.visitStmt2R(MOVE_OBJECT,0,1);
                code.visitLabel(L4);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m009_getResource(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/webapp/WebAppClassLoader;","getResource",new String[]{ "Ljava/lang/String;"},"Ljava/net/URL;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(6);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"name");
                DexLabel L3=new DexLabel();
                ddv.visitPrologue(L3);
                ddv.visitLineNumber(259,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(260,L4);
                ddv.visitStartLocal(1,L4,"url","Ljava/net/URL;",null);
                ddv.visitLineNumber(261,L0);
                ddv.visitStartLocal(0,L0,"tried_parent","Z",null);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(263,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(265,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(266,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(269,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(271,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(273,L10);
                ddv.visitRestartLocal(1,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(275,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(276,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(277,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(281,L14);
                ddv.visitRestartLocal(1,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(283,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(284,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(287,L17);
                ddv.visitRestartLocal(1,L17);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(288,L18);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(289,L19);
                ddv.visitLineNumber(291,L1);
                ddv.visitLineNumber(259,L2);
                code.visitLabel(L3);
                code.visitStmt1R(MONITOR_ENTER,4);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L4);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,2,4,new Field("Lorg/mortbay/jetty/webapp/WebAppClassLoader;","_context","Lorg/mortbay/jetty/webapp/WebAppContext;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/jetty/webapp/WebAppContext;","isParentLoaderPriority",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitJumpStmt(IF_NEZ,2,-1,L5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,5},new Method("Lorg/mortbay/jetty/webapp/WebAppClassLoader;","isSystemPath",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitJumpStmt(IF_EQZ,2,-1,L8);
                code.visitLabel(L5);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitLabel(L6);
                code.visitFieldStmt(IGET_OBJECT,2,4,new Field("Lorg/mortbay/jetty/webapp/WebAppClassLoader;","_parent","Ljava/lang/ClassLoader;"));
                code.visitJumpStmt(IF_EQZ,2,-1,L8);
                code.visitLabel(L7);
                code.visitFieldStmt(IGET_OBJECT,2,4,new Field("Lorg/mortbay/jetty/webapp/WebAppClassLoader;","_parent","Ljava/lang/ClassLoader;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,5},new Method("Ljava/lang/ClassLoader;","getResource",new String[]{ "Ljava/lang/String;"},"Ljava/net/URL;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L8);
                code.visitJumpStmt(IF_NEZ,1,-1,L14);
                code.visitLabel(L9);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,5},new Method("Lorg/mortbay/jetty/webapp/WebAppClassLoader;","findResource",new String[]{ "Ljava/lang/String;"},"Ljava/net/URL;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L10);
                code.visitJumpStmt(IF_NEZ,1,-1,L14);
                code.visitConstStmt(CONST_STRING,2,"/");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,2},new Method("Ljava/lang/String;","startsWith",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitJumpStmt(IF_EQZ,2,-1,L14);
                code.visitLabel(L11);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Lorg/mortbay/log/Log;","isDebugEnabled",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitJumpStmt(IF_EQZ,2,-1,L13);
                code.visitLabel(L12);
                code.visitTypeStmt(NEW_INSTANCE,2,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,3,"HACK leading / off ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,5},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 2},new Method("Lorg/mortbay/log/Log;","debug",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L13);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,2},new Method("Ljava/lang/String;","substring",new String[]{ "I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,2},new Method("Lorg/mortbay/jetty/webapp/WebAppClassLoader;","findResource",new String[]{ "Ljava/lang/String;"},"Ljava/net/URL;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L14);
                code.visitJumpStmt(IF_NEZ,1,-1,L17);
                code.visitJumpStmt(IF_NEZ,0,-1,L17);
                code.visitLabel(L15);
                code.visitFieldStmt(IGET_OBJECT,2,4,new Field("Lorg/mortbay/jetty/webapp/WebAppClassLoader;","_parent","Ljava/lang/ClassLoader;"));
                code.visitJumpStmt(IF_EQZ,2,-1,L17);
                code.visitLabel(L16);
                code.visitFieldStmt(IGET_OBJECT,2,4,new Field("Lorg/mortbay/jetty/webapp/WebAppClassLoader;","_parent","Ljava/lang/ClassLoader;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,5},new Method("Ljava/lang/ClassLoader;","getResource",new String[]{ "Ljava/lang/String;"},"Ljava/net/URL;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L17);
                code.visitJumpStmt(IF_EQZ,1,-1,L1);
                code.visitLabel(L18);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Lorg/mortbay/log/Log;","isDebugEnabled",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitJumpStmt(IF_EQZ,2,-1,L1);
                code.visitLabel(L19);
                code.visitTypeStmt(NEW_INSTANCE,2,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,3,"getResource(");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,5},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitConstStmt(CONST_STRING,3,")=");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 2},new Method("Lorg/mortbay/log/Log;","debug",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L1);
                code.visitStmt1R(MONITOR_EXIT,4);
                code.visitStmt1R(RETURN_OBJECT,1);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,2);
                code.visitStmt1R(MONITOR_EXIT,4);
                code.visitStmt1R(THROW,2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m010_isServerPath(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/webapp/WebAppClassLoader;","isServerPath",new String[]{ "Ljava/lang/String;"},"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(10);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"name");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(297,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(298,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(299,L3);
                DexLabel L4=new DexLabel();
                ddv.visitRestartLocal(9,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(301,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(302,L6);
                ddv.visitStartLocal(3,L6,"server_classes","[Ljava/lang/String;",null);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(304,L7);
                DexLabel L8=new DexLabel();
                ddv.visitStartLocal(1,L8,"i","I",null);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(306,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(307,L10);
                ddv.visitStartLocal(2,L10,"result","Z",null);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(308,L11);
                ddv.visitStartLocal(0,L11,"c","Ljava/lang/String;",null);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(310,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(311,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(314,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(316,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(323,L16);
                ddv.visitEndLocal(1,L16);
                ddv.visitEndLocal(2,L16);
                ddv.visitEndLocal(0,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(319,L17);
                ddv.visitRestartLocal(0,L17);
                ddv.visitRestartLocal(1,L17);
                ddv.visitRestartLocal(2,L17);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(320,L18);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(304,L19);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(323,L20);
                ddv.visitEndLocal(0,L20);
                ddv.visitEndLocal(1,L20);
                ddv.visitEndLocal(2,L20);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,6, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitConstStmt(CONST_STRING,7,".");
                code.visitLabel(L1);
                code.visitConstStmt(CONST_16,4, Integer.valueOf(47)); // int: 0x0000002f  float:0.000000
                code.visitConstStmt(CONST_16,5, Integer.valueOf(46)); // int: 0x0000002e  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9,4,5},new Method("Ljava/lang/String;","replace",new String[]{ "C","C"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,9);
                code.visitLabel(L2);
                code.visitConstStmt(CONST_STRING,4,".");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9,7},new Method("Ljava/lang/String;","startsWith",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,4);
                code.visitJumpStmt(IF_EQZ,4,-1,L5);
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9,6},new Method("Ljava/lang/String;","substring",new String[]{ "I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,9);
                code.visitLabel(L4);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitLabel(L5);
                code.visitFieldStmt(IGET_OBJECT,4,8,new Field("Lorg/mortbay/jetty/webapp/WebAppClassLoader;","_context","Lorg/mortbay/jetty/webapp/WebAppContext;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Lorg/mortbay/jetty/webapp/WebAppContext;","getServerClasses",new String[]{ },"[Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitLabel(L6);
                code.visitJumpStmt(IF_EQZ,3,-1,L20);
                code.visitLabel(L7);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L8);
                code.visitStmt2R(ARRAY_LENGTH,4,3);
                code.visitJumpStmt(IF_GE,1,4,L20);
                code.visitLabel(L9);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitLabel(L10);
                code.visitStmt3R(AGET_OBJECT,0,3,1);
                code.visitLabel(L11);
                code.visitConstStmt(CONST_STRING,4,"-");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,4},new Method("Ljava/lang/String;","startsWith",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,4);
                code.visitJumpStmt(IF_EQZ,4,-1,L14);
                code.visitLabel(L12);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,6},new Method("Ljava/lang/String;","substring",new String[]{ "I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L13);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L14);
                code.visitConstStmt(CONST_STRING,4,".");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,7},new Method("Ljava/lang/String;","endsWith",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,4);
                code.visitJumpStmt(IF_EQZ,4,-1,L17);
                code.visitLabel(L15);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9,0},new Method("Ljava/lang/String;","startsWith",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,4);
                code.visitJumpStmt(IF_EQZ,4,-1,L19);
                code.visitStmt2R(MOVE,4,2);
                code.visitLabel(L16);
                code.visitStmt1R(RETURN,4);
                code.visitLabel(L17);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9,0},new Method("Ljava/lang/String;","equals",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,4);
                code.visitJumpStmt(IF_EQZ,4,-1,L19);
                code.visitStmt2R(MOVE,4,2);
                code.visitLabel(L18);
                code.visitJumpStmt(GOTO,-1,-1,L16);
                code.visitLabel(L19);
                code.visitStmt2R1N(ADD_INT_LIT8,1,1,1);
                code.visitJumpStmt(GOTO,-1,-1,L8);
                code.visitLabel(L20);
                code.visitConstStmt(CONST_4,4, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L16);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m011_isSystemPath(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/webapp/WebAppClassLoader;","isSystemPath",new String[]{ "Ljava/lang/String;"},"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(10);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"name");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(329,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(330,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(331,L3);
                DexLabel L4=new DexLabel();
                ddv.visitRestartLocal(9,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(332,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(333,L6);
                ddv.visitStartLocal(3,L6,"system_classes","[Ljava/lang/String;",null);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(335,L7);
                DexLabel L8=new DexLabel();
                ddv.visitStartLocal(1,L8,"i","I",null);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(337,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(338,L10);
                ddv.visitStartLocal(2,L10,"result","Z",null);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(340,L11);
                ddv.visitStartLocal(0,L11,"c","Ljava/lang/String;",null);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(342,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(343,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(346,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(348,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(356,L16);
                ddv.visitEndLocal(1,L16);
                ddv.visitEndLocal(2,L16);
                ddv.visitEndLocal(0,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(351,L17);
                ddv.visitRestartLocal(0,L17);
                ddv.visitRestartLocal(1,L17);
                ddv.visitRestartLocal(2,L17);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(352,L18);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(335,L19);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(356,L20);
                ddv.visitEndLocal(0,L20);
                ddv.visitEndLocal(1,L20);
                ddv.visitEndLocal(2,L20);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,6, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitConstStmt(CONST_STRING,7,".");
                code.visitLabel(L1);
                code.visitConstStmt(CONST_16,4, Integer.valueOf(47)); // int: 0x0000002f  float:0.000000
                code.visitConstStmt(CONST_16,5, Integer.valueOf(46)); // int: 0x0000002e  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9,4,5},new Method("Ljava/lang/String;","replace",new String[]{ "C","C"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,9);
                code.visitLabel(L2);
                code.visitConstStmt(CONST_STRING,4,".");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9,7},new Method("Ljava/lang/String;","startsWith",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,4);
                code.visitJumpStmt(IF_EQZ,4,-1,L5);
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9,6},new Method("Ljava/lang/String;","substring",new String[]{ "I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,9);
                code.visitLabel(L4);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitLabel(L5);
                code.visitFieldStmt(IGET_OBJECT,4,8,new Field("Lorg/mortbay/jetty/webapp/WebAppClassLoader;","_context","Lorg/mortbay/jetty/webapp/WebAppContext;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Lorg/mortbay/jetty/webapp/WebAppContext;","getSystemClasses",new String[]{ },"[Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitLabel(L6);
                code.visitJumpStmt(IF_EQZ,3,-1,L20);
                code.visitLabel(L7);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L8);
                code.visitStmt2R(ARRAY_LENGTH,4,3);
                code.visitJumpStmt(IF_GE,1,4,L20);
                code.visitLabel(L9);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitLabel(L10);
                code.visitStmt3R(AGET_OBJECT,0,3,1);
                code.visitLabel(L11);
                code.visitConstStmt(CONST_STRING,4,"-");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,4},new Method("Ljava/lang/String;","startsWith",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,4);
                code.visitJumpStmt(IF_EQZ,4,-1,L14);
                code.visitLabel(L12);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,6},new Method("Ljava/lang/String;","substring",new String[]{ "I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L13);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L14);
                code.visitConstStmt(CONST_STRING,4,".");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,7},new Method("Ljava/lang/String;","endsWith",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,4);
                code.visitJumpStmt(IF_EQZ,4,-1,L17);
                code.visitLabel(L15);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9,0},new Method("Ljava/lang/String;","startsWith",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,4);
                code.visitJumpStmt(IF_EQZ,4,-1,L19);
                code.visitStmt2R(MOVE,4,2);
                code.visitLabel(L16);
                code.visitStmt1R(RETURN,4);
                code.visitLabel(L17);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9,0},new Method("Ljava/lang/String;","equals",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,4);
                code.visitJumpStmt(IF_EQZ,4,-1,L19);
                code.visitStmt2R(MOVE,4,2);
                code.visitLabel(L18);
                code.visitJumpStmt(GOTO,-1,-1,L16);
                code.visitLabel(L19);
                code.visitStmt2R1N(ADD_INT_LIT8,1,1,1);
                code.visitJumpStmt(GOTO,-1,-1,L8);
                code.visitLabel(L20);
                code.visitConstStmt(CONST_4,4, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L16);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m012_loadClass(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/webapp/WebAppClassLoader;","loadClass",new String[]{ "Ljava/lang/String;"},"Ljava/lang/Class;"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/lang/ClassNotFoundException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"name");
                DexLabel L3=new DexLabel();
                ddv.visitPrologue(L3);
                ddv.visitLineNumber(363,L3);
                code.visitLabel(L3);
                code.visitStmt1R(MONITOR_ENTER,1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2,0},new Method("Lorg/mortbay/jetty/webapp/WebAppClassLoader;","loadClass",new String[]{ "Ljava/lang/String;","Z"},"Ljava/lang/Class;"));
                code.visitLabel(L1);
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitStmt1R(MONITOR_EXIT,1);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,0);
                code.visitStmt1R(MONITOR_EXIT,1);
                code.visitStmt1R(THROW,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m013_loadClass(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Lorg/mortbay/jetty/webapp/WebAppClassLoader;","loadClass",new String[]{ "Ljava/lang/String;","Z"},"Ljava/lang/Class;"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/lang/ClassNotFoundException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(9);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexLabel L3=new DexLabel();
                DexLabel L4=new DexLabel();
                DexLabel L5=new DexLabel();
                code.visitTryCatch(L3,L4,new DexLabel[]{L5,L2},new String[]{ "Ljava/lang/ClassNotFoundException;",null});
                DexLabel L6=new DexLabel();
                DexLabel L7=new DexLabel();
                DexLabel L8=new DexLabel();
                code.visitTryCatch(L6,L7,new DexLabel[]{L8,L2},new String[]{ "Ljava/lang/ClassNotFoundException;",null});
                DexLabel L9=new DexLabel();
                code.visitTryCatch(L9,L2,new DexLabel[]{L2},new String[]{ null});
                DexLabel L10=new DexLabel();
                DexLabel L11=new DexLabel();
                code.visitTryCatch(L10,L11,new DexLabel[]{L2},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"name");
                ddv.visitParameterName(1,"resolve");
                DexLabel L12=new DexLabel();
                ddv.visitPrologue(L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(369,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(370,L14);
                ddv.visitStartLocal(0,L14,"c","Ljava/lang/Class;",null);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(371,L15);
                ddv.visitStartLocal(2,L15,"ex","Ljava/lang/ClassNotFoundException;",null);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(373,L16);
                ddv.visitStartLocal(3,L16,"tried_parent","Z",null);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(375,L17);
                ddv.visitLineNumber(378,L3);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(379,L18);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(380,L19);
                ddv.visitLineNumber(388,L4);
                ddv.visitLineNumber(392,L6);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(400,L20);
                ddv.visitRestartLocal(0,L20);
                DexLabel L21=new DexLabel();
                ddv.visitLineNumber(401,L21);
                DexLabel L22=new DexLabel();
                ddv.visitLineNumber(403,L22);
                ddv.visitRestartLocal(0,L22);
                DexLabel L23=new DexLabel();
                ddv.visitLineNumber(404,L23);
                ddv.visitLineNumber(369,L2);
                ddv.visitEndLocal(2,L2);
                ddv.visitEndLocal(3,L2);
                ddv.visitEndLocal(0,L2);
                ddv.visitLineNumber(382,L5);
                ddv.visitRestartLocal(0,L5);
                ddv.visitRestartLocal(2,L5);
                ddv.visitRestartLocal(3,L5);
                DexLabel L24=new DexLabel();
                ddv.visitLineNumber(384,L24);
                ddv.visitStartLocal(1,L24,"e","Ljava/lang/ClassNotFoundException;",null);
                ddv.visitLineNumber(394,L8);
                ddv.visitEndLocal(1,L8);
                DexLabel L25=new DexLabel();
                ddv.visitLineNumber(396,L25);
                ddv.visitRestartLocal(1,L25);
                DexLabel L26=new DexLabel();
                ddv.visitLineNumber(406,L26);
                ddv.visitEndLocal(1,L26);
                ddv.visitLineNumber(407,L10);
                DexLabel L27=new DexLabel();
                ddv.visitLineNumber(409,L27);
                DexLabel L28=new DexLabel();
                ddv.visitLineNumber(410,L28);
                ddv.visitLineNumber(412,L11);
                code.visitLabel(L12);
                code.visitConstStmt(CONST_STRING,4,"loaded ");
                code.visitLabel(L13);
                code.visitStmt1R(MONITOR_ENTER,6);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,7},new Method("Lorg/mortbay/jetty/webapp/WebAppClassLoader;","findLoadedClass",new String[]{ "Ljava/lang/String;"},"Ljava/lang/Class;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L14);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L15);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L16);
                code.visitJumpStmt(IF_NEZ,0,-1,L4);
                code.visitFieldStmt(IGET_OBJECT,4,6,new Field("Lorg/mortbay/jetty/webapp/WebAppClassLoader;","_parent","Ljava/lang/ClassLoader;"));
                code.visitJumpStmt(IF_EQZ,4,-1,L4);
                code.visitFieldStmt(IGET_OBJECT,4,6,new Field("Lorg/mortbay/jetty/webapp/WebAppClassLoader;","_context","Lorg/mortbay/jetty/webapp/WebAppContext;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Lorg/mortbay/jetty/webapp/WebAppContext;","isParentLoaderPriority",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,4);
                code.visitJumpStmt(IF_NEZ,4,-1,L17);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,7},new Method("Lorg/mortbay/jetty/webapp/WebAppClassLoader;","isSystemPath",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitLabel(L1);
                code.visitStmt1R(MOVE_RESULT,4);
                code.visitJumpStmt(IF_EQZ,4,-1,L4);
                code.visitLabel(L17);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,4,6,new Field("Lorg/mortbay/jetty/webapp/WebAppClassLoader;","_parent","Ljava/lang/ClassLoader;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,7},new Method("Ljava/lang/ClassLoader;","loadClass",new String[]{ "Ljava/lang/String;"},"Ljava/lang/Class;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L18);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Lorg/mortbay/log/Log;","isDebugEnabled",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,4);
                code.visitJumpStmt(IF_EQZ,4,-1,L4);
                code.visitLabel(L19);
                code.visitTypeStmt(NEW_INSTANCE,4,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 4},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,5,"loaded ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,5},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,0},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 4},new Method("Lorg/mortbay/log/Log;","debug",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L4);
                code.visitJumpStmt(IF_NEZ,0,-1,L20);
                code.visitLabel(L6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,7},new Method("Lorg/mortbay/jetty/webapp/WebAppClassLoader;","findClass",new String[]{ "Ljava/lang/String;"},"Ljava/lang/Class;"));
                code.visitLabel(L7);
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L20);
                code.visitJumpStmt(IF_NEZ,0,-1,L22);
                code.visitLabel(L9);
                code.visitFieldStmt(IGET_OBJECT,4,6,new Field("Lorg/mortbay/jetty/webapp/WebAppClassLoader;","_parent","Ljava/lang/ClassLoader;"));
                code.visitJumpStmt(IF_EQZ,4,-1,L22);
                code.visitJumpStmt(IF_NEZ,3,-1,L22);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,7},new Method("Lorg/mortbay/jetty/webapp/WebAppClassLoader;","isServerPath",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,4);
                code.visitJumpStmt(IF_NEZ,4,-1,L22);
                code.visitLabel(L21);
                code.visitFieldStmt(IGET_OBJECT,4,6,new Field("Lorg/mortbay/jetty/webapp/WebAppClassLoader;","_parent","Ljava/lang/ClassLoader;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,7},new Method("Ljava/lang/ClassLoader;","loadClass",new String[]{ "Ljava/lang/String;"},"Ljava/lang/Class;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L22);
                code.visitJumpStmt(IF_NEZ,0,-1,L26);
                code.visitLabel(L23);
                code.visitStmt1R(THROW,2);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,4);
                code.visitStmt1R(MONITOR_EXIT,6);
                code.visitStmt1R(THROW,4);
                code.visitLabel(L5);
                code.visitStmt1R(MOVE_EXCEPTION,4);
                code.visitStmt2R(MOVE_OBJECT,1,4);
                code.visitLabel(L24);
                code.visitStmt2R(MOVE_OBJECT,2,1);
                code.visitJumpStmt(GOTO,-1,-1,L4);
                code.visitLabel(L8);
                code.visitStmt1R(MOVE_EXCEPTION,1);
                code.visitLabel(L25);
                code.visitStmt2R(MOVE_OBJECT,2,1);
                code.visitJumpStmt(GOTO,-1,-1,L20);
                code.visitLabel(L26);
                code.visitJumpStmt(IF_EQZ,8,-1,L27);
                code.visitLabel(L10);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,0},new Method("Lorg/mortbay/jetty/webapp/WebAppClassLoader;","resolveClass",new String[]{ "Ljava/lang/Class;"},"V"));
                code.visitLabel(L27);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Lorg/mortbay/log/Log;","isDebugEnabled",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,4);
                code.visitJumpStmt(IF_EQZ,4,-1,L11);
                code.visitLabel(L28);
                code.visitTypeStmt(NEW_INSTANCE,4,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 4},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,5,"loaded ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,5},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,0},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitConstStmt(CONST_STRING,5," from ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,5},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/lang/Class;","getClassLoader",new String[]{ },"Ljava/lang/ClassLoader;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,5},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 4},new Method("Lorg/mortbay/log/Log;","debug",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L11);
                code.visitStmt1R(MONITOR_EXIT,6);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m014_setName(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/webapp/WebAppClassLoader;","setName",new String[]{ "Ljava/lang/String;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"name");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(114,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(115,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_OBJECT,1,0,new Field("Lorg/mortbay/jetty/webapp/WebAppClassLoader;","_name","Ljava/lang/String;"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m015_toString(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/webapp/WebAppClassLoader;","toString",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(418,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(419,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(420,L3);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_STRING,2,"ContextLoader@");
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Lorg/mortbay/log/Log;","isDebugEnabled",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                DexLabel L4=new DexLabel();
                code.visitJumpStmt(IF_EQZ,0,-1,L4);
                code.visitLabel(L2);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,1,"ContextLoader@");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,2},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(IGET_OBJECT,1,3,new Field("Lorg/mortbay/jetty/webapp/WebAppClassLoader;","_name","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitConstStmt(CONST_STRING,1,"(");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Lorg/mortbay/jetty/webapp/WebAppClassLoader;","getURLs",new String[]{ },"[Ljava/net/URL;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1},new Method("Lorg/mortbay/util/LazyList;","array2List",new String[]{ "[Ljava/lang/Object;"},"Ljava/util/List;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitConstStmt(CONST_STRING,1,") / ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(IGET_OBJECT,1,3,new Field("Lorg/mortbay/jetty/webapp/WebAppClassLoader;","_parent","Ljava/lang/ClassLoader;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L3);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitLabel(L4);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,1,"ContextLoader@");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,2},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(IGET_OBJECT,1,3,new Field("Lorg/mortbay/jetty/webapp/WebAppClassLoader;","_name","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitJumpStmt(GOTO,-1,-1,L3);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
