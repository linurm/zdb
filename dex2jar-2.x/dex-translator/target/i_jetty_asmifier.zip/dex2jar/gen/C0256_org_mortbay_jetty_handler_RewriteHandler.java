package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0256_org_mortbay_jetty_handler_RewriteHandler {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(ACC_PUBLIC,"Lorg/mortbay/jetty/handler/RewriteHandler;","Lorg/mortbay/jetty/handler/HandlerWrapper;",new String[]{ });
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("RewriteHandler.java");
        f000__originalPathAttribute(cv);
        f001__rewrite(cv);
        f002__rewritePathInfo(cv);
        f003__rewriteRequestURI(cv);
        m000__init_(cv);
        m001_addRewriteRule(cv);
        m002_getOriginalPathAttribute(cv);
        m003_getRewrite(cv);
        m004_handle(cv);
        m005_isRewritePathInfo(cv);
        m006_isRewriteRequestURI(cv);
        m007_setOriginalPathAttribute(cv);
        m008_setRewrite(cv);
        m009_setRewritePathInfo(cv);
        m010_setRewriteRequestURI(cv);
    }
    public static void f000__originalPathAttribute(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/handler/RewriteHandler;","_originalPathAttribute","Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f001__rewrite(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/handler/RewriteHandler;","_rewrite","Lorg/mortbay/jetty/servlet/PathMap;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f002__rewritePathInfo(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/handler/RewriteHandler;","_rewritePathInfo","Z"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f003__rewriteRequestURI(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/handler/RewriteHandler;","_rewriteRequestURI","Z"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void m000__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/jetty/handler/RewriteHandler;","<init>",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(62,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(64,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(65,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(67,L4);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2},new Method("Lorg/mortbay/jetty/handler/HandlerWrapper;","<init>",new String[]{ },"V"));
                code.visitLabel(L2);
                code.visitFieldStmt(IPUT_BOOLEAN,1,2,new Field("Lorg/mortbay/jetty/handler/RewriteHandler;","_rewriteRequestURI","Z"));
                code.visitLabel(L3);
                code.visitFieldStmt(IPUT_BOOLEAN,1,2,new Field("Lorg/mortbay/jetty/handler/RewriteHandler;","_rewritePathInfo","Z"));
                code.visitLabel(L4);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Lorg/mortbay/jetty/servlet/PathMap;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1},new Method("Lorg/mortbay/jetty/servlet/PathMap;","<init>",new String[]{ "Z"},"V"));
                code.visitFieldStmt(IPUT_OBJECT,0,2,new Field("Lorg/mortbay/jetty/handler/RewriteHandler;","_rewrite","Lorg/mortbay/jetty/servlet/PathMap;"));
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001_addRewriteRule(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/handler/RewriteHandler;","addRewriteRule",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"pattern");
                ddv.visitParameterName(1,"prefix");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(158,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(159,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(160,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(161,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(162,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(163,L5);
                code.visitLabel(L0);
                code.visitJumpStmt(IF_EQZ,3,-1,L1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Ljava/lang/String;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_EQZ,0,-1,L1);
                code.visitConstStmt(CONST_STRING,0,"/");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,0},new Method("Ljava/lang/String;","startsWith",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_NEZ,0,-1,L2);
                code.visitLabel(L1);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/lang/IllegalArgumentException;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/lang/IllegalArgumentException;","<init>",new String[]{ },"V"));
                code.visitStmt1R(THROW,0);
                code.visitLabel(L2);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/jetty/handler/RewriteHandler;","_rewrite","Lorg/mortbay/jetty/servlet/PathMap;"));
                code.visitJumpStmt(IF_NEZ,0,-1,L4);
                code.visitLabel(L3);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Lorg/mortbay/jetty/servlet/PathMap;");
                code.visitConstStmt(CONST_4,1, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1},new Method("Lorg/mortbay/jetty/servlet/PathMap;","<init>",new String[]{ "Z"},"V"));
                code.visitFieldStmt(IPUT_OBJECT,0,2,new Field("Lorg/mortbay/jetty/handler/RewriteHandler;","_rewrite","Lorg/mortbay/jetty/servlet/PathMap;"));
                code.visitLabel(L4);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/jetty/handler/RewriteHandler;","_rewrite","Lorg/mortbay/jetty/servlet/PathMap;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,3,4},new Method("Lorg/mortbay/jetty/servlet/PathMap;","put",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitLabel(L5);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m002_getOriginalPathAttribute(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/handler/RewriteHandler;","getOriginalPathAttribute",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(117,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/handler/RewriteHandler;","_originalPathAttribute","Ljava/lang/String;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m003_getRewrite(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/handler/RewriteHandler;","getRewrite",new String[]{ },"Lorg/mortbay/jetty/servlet/PathMap;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(136,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/handler/RewriteHandler;","_rewrite","Lorg/mortbay/jetty/servlet/PathMap;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m004_handle(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/handler/RewriteHandler;","handle",new String[]{ "Ljava/lang/String;","Ljavax/servlet/http/HttpServletRequest;","Ljavax/servlet/http/HttpServletResponse;","I"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visit(null, new DexType("Ljavax/servlet/ServletException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(9);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"target");
                ddv.visitParameterName(1,"request");
                ddv.visitParameterName(2,"response");
                ddv.visitParameterName(3,"dispatch");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(171,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(173,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(175,L2);
                ddv.visitStartLocal(1,L2,"rewrite","Ljava/util/Map$Entry;",null);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(177,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(178,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(180,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(183,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(184,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(186,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(187,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(190,L10);
                ddv.visitEndLocal(1,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(192,L11);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Lorg/mortbay/jetty/handler/RewriteHandler;","isStarted",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitJumpStmt(IF_EQZ,2,-1,L10);
                code.visitFieldStmt(IGET_OBJECT,2,4,new Field("Lorg/mortbay/jetty/handler/RewriteHandler;","_rewrite","Lorg/mortbay/jetty/servlet/PathMap;"));
                code.visitJumpStmt(IF_EQZ,2,-1,L10);
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,2,4,new Field("Lorg/mortbay/jetty/handler/RewriteHandler;","_rewrite","Lorg/mortbay/jetty/servlet/PathMap;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,5},new Method("Lorg/mortbay/jetty/servlet/PathMap;","getMatch",new String[]{ "Ljava/lang/String;"},"Lorg/mortbay/jetty/servlet/PathMap$Entry;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L2);
                code.visitJumpStmt(IF_EQZ,1,-1,L10);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 1},new Method("Ljava/util/Map$Entry;","getValue",new String[]{ },"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitJumpStmt(IF_EQZ,2,-1,L10);
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,2,4,new Field("Lorg/mortbay/jetty/handler/RewriteHandler;","_originalPathAttribute","Ljava/lang/String;"));
                code.visitJumpStmt(IF_EQZ,2,-1,L5);
                code.visitLabel(L4);
                code.visitFieldStmt(IGET_OBJECT,2,4,new Field("Lorg/mortbay/jetty/handler/RewriteHandler;","_originalPathAttribute","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 6,2,5},new Method("Ljavax/servlet/http/HttpServletRequest;","setAttribute",new String[]{ "Ljava/lang/String;","Ljava/lang/Object;"},"V"));
                code.visitLabel(L5);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 1},new Method("Ljava/util/Map$Entry;","getValue",new String[]{ },"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Ljava/lang/Object;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 1},new Method("Ljava/util/Map$Entry;","getKey",new String[]{ },"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Ljava/lang/Object;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 3,5},new Method("Lorg/mortbay/jetty/servlet/PathMap;","pathInfo",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 2,3},new Method("Lorg/mortbay/util/URIUtil;","addPaths",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitLabel(L6);
                code.visitFieldStmt(IGET_BOOLEAN,2,4,new Field("Lorg/mortbay/jetty/handler/RewriteHandler;","_rewriteRequestURI","Z"));
                code.visitJumpStmt(IF_EQZ,2,-1,L8);
                code.visitLabel(L7);
                code.visitStmt2R(MOVE_OBJECT,0,6);
                code.visitTypeStmt(CHECK_CAST,0,-1,"Lorg/mortbay/jetty/Request;");
                code.visitStmt2R(MOVE_OBJECT,2,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,5},new Method("Lorg/mortbay/jetty/Request;","setRequestURI",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L8);
                code.visitFieldStmt(IGET_BOOLEAN,2,4,new Field("Lorg/mortbay/jetty/handler/RewriteHandler;","_rewritePathInfo","Z"));
                code.visitJumpStmt(IF_EQZ,2,-1,L10);
                code.visitLabel(L9);
                code.visitStmt2R(MOVE_OBJECT,0,6);
                code.visitTypeStmt(CHECK_CAST,0,-1,"Lorg/mortbay/jetty/Request;");
                code.visitStmt2R(MOVE_OBJECT,2,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,5},new Method("Lorg/mortbay/jetty/Request;","setPathInfo",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L10);
                code.visitMethodStmt(INVOKE_SUPER,new int[]{ 4,5,6,7,8},new Method("Lorg/mortbay/jetty/handler/HandlerWrapper;","handle",new String[]{ "Ljava/lang/String;","Ljavax/servlet/http/HttpServletRequest;","Ljavax/servlet/http/HttpServletResponse;","I"},"V"));
                code.visitLabel(L11);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m005_isRewritePathInfo(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/handler/RewriteHandler;","isRewritePathInfo",new String[]{ },"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(97,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_BOOLEAN,0,1,new Field("Lorg/mortbay/jetty/handler/RewriteHandler;","_rewritePathInfo","Z"));
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m006_isRewriteRequestURI(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/handler/RewriteHandler;","isRewriteRequestURI",new String[]{ },"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(77,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_BOOLEAN,0,1,new Field("Lorg/mortbay/jetty/handler/RewriteHandler;","_rewriteRequestURI","Z"));
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m007_setOriginalPathAttribute(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/handler/RewriteHandler;","setOriginalPathAttribute",new String[]{ "Ljava/lang/String;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"originalPathAttribte");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(127,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(128,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_OBJECT,1,0,new Field("Lorg/mortbay/jetty/handler/RewriteHandler;","_originalPathAttribute","Ljava/lang/String;"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m008_setRewrite(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/handler/RewriteHandler;","setRewrite",new String[]{ "Lorg/mortbay/jetty/servlet/PathMap;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"rewrite");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(146,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(147,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_OBJECT,1,0,new Field("Lorg/mortbay/jetty/handler/RewriteHandler;","_rewrite","Lorg/mortbay/jetty/servlet/PathMap;"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m009_setRewritePathInfo(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/handler/RewriteHandler;","setRewritePathInfo",new String[]{ "Z"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"rewritePathInfo");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(107,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(108,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_BOOLEAN,1,0,new Field("Lorg/mortbay/jetty/handler/RewriteHandler;","_rewritePathInfo","Z"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m010_setRewriteRequestURI(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/handler/RewriteHandler;","setRewriteRequestURI",new String[]{ "Z"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"rewriteRequestURI");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(87,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(88,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_BOOLEAN,1,0,new Field("Lorg/mortbay/jetty/handler/RewriteHandler;","_rewriteRequestURI","Z"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
