package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0126_org_mortbay_io_nio_ChannelEndPoint {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(ACC_PUBLIC,"Lorg/mortbay/io/nio/ChannelEndPoint;","Ljava/lang/Object;",new String[]{ "Lorg/mortbay/io/EndPoint;"});
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("ChannelEndPoint.java");
        f000__channel(cv);
        f001__gather2(cv);
        f002__local(cv);
        f003__remote(cv);
        f004__socket(cv);
        m000__init_(cv);
        m001_blockReadable(cv);
        m002_blockWritable(cv);
        m003_close(cv);
        m004_fill(cv);
        m005_flush(cv);
        m006_flush(cv);
        m007_flush(cv);
        m008_getChannel(cv);
        m009_getLocalAddr(cv);
        m010_getLocalHost(cv);
        m011_getLocalPort(cv);
        m012_getRemoteAddr(cv);
        m013_getRemoteHost(cv);
        m014_getRemotePort(cv);
        m015_getTransport(cv);
        m016_isBlocking(cv);
        m017_isBufferingInput(cv);
        m018_isBufferingOutput(cv);
        m019_isBufferred(cv);
        m020_isOpen(cv);
    }
    public static void f000__channel(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PROTECTED, new Field("Lorg/mortbay/io/nio/ChannelEndPoint;","_channel","Ljava/nio/channels/ByteChannel;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f001__gather2(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PROTECTED, new Field("Lorg/mortbay/io/nio/ChannelEndPoint;","_gather2","[Ljava/nio/ByteBuffer;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f002__local(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PROTECTED, new Field("Lorg/mortbay/io/nio/ChannelEndPoint;","_local","Ljava/net/InetSocketAddress;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f003__remote(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PROTECTED, new Field("Lorg/mortbay/io/nio/ChannelEndPoint;","_remote","Ljava/net/InetSocketAddress;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f004__socket(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PROTECTED, new Field("Lorg/mortbay/io/nio/ChannelEndPoint;","_socket","Ljava/net/Socket;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void m000__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/io/nio/ChannelEndPoint;","<init>",new String[]{ "Ljava/nio/channels/ByteChannel;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"channel");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(52,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(42,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(53,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(54,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(55,L4);
                DexLabel L5=new DexLabel();
                ddv.visitEndLocal(2,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(56,L6);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1},new Method("Ljava/lang/Object;","<init>",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(2)); // int: 0x00000002  float:0.000000
                code.visitTypeStmt(NEW_ARRAY,0,0,"[Ljava/nio/ByteBuffer;");
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/io/nio/ChannelEndPoint;","_gather2","[Ljava/nio/ByteBuffer;"));
                code.visitLabel(L2);
                code.visitFieldStmt(IPUT_OBJECT,2,1,new Field("Lorg/mortbay/io/nio/ChannelEndPoint;","_channel","Ljava/nio/channels/ByteChannel;"));
                code.visitLabel(L3);
                code.visitTypeStmt(INSTANCE_OF,0,2,"Ljava/nio/channels/SocketChannel;");
                code.visitJumpStmt(IF_EQZ,0,-1,L6);
                code.visitLabel(L4);
                code.visitTypeStmt(CHECK_CAST,2,-1,"Ljava/nio/channels/SocketChannel;");
                code.visitLabel(L5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Ljava/nio/channels/SocketChannel;","socket",new String[]{ },"Ljava/net/Socket;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/io/nio/ChannelEndPoint;","_socket","Ljava/net/Socket;"));
                code.visitLabel(L6);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001_blockReadable(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/io/nio/ChannelEndPoint;","blockReadable",new String[]{ "J"},"Z"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"millisecs");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(67,L0);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m002_blockWritable(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/io/nio/ChannelEndPoint;","blockWritable",new String[]{ "J"},"Z"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"millisecs");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(72,L0);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m003_close(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/io/nio/ChannelEndPoint;","close",new String[]{ },"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                DexLabel L3=new DexLabel();
                DexLabel L4=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2,L3,L4},new String[]{ "Ljava/io/IOException;","Ljava/lang/UnsupportedOperationException;",null});
                DexLabel L5=new DexLabel();
                DexLabel L6=new DexLabel();
                code.visitTryCatch(L5,L6,new DexLabel[]{L4},new String[]{ null});
                DexLabel L7=new DexLabel();
                DexLabel L8=new DexLabel();
                code.visitTryCatch(L7,L8,new DexLabel[]{L4},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L9=new DexLabel();
                ddv.visitPrologue(L9);
                ddv.visitLineNumber(88,L9);
                ddv.visitLineNumber(92,L0);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(95,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(96,L11);
                ddv.visitStartLocal(1,L11,"socket","Ljava/net/Socket;",null);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(97,L12);
                ddv.visitLineNumber(110,L1);
                ddv.visitEndLocal(1,L1);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(113,L13);
                ddv.visitLineNumber(100,L2);
                ddv.visitLineNumber(102,L5);
                ddv.visitStartLocal(0,L5,"e","Ljava/io/IOException;",null);
                ddv.visitLineNumber(110,L6);
                ddv.visitLineNumber(104,L3);
                ddv.visitEndLocal(0,L3);
                ddv.visitLineNumber(106,L7);
                ddv.visitStartLocal(0,L7,"e","Ljava/lang/UnsupportedOperationException;",null);
                ddv.visitLineNumber(110,L8);
                ddv.visitEndLocal(0,L4);
                code.visitLabel(L9);
                code.visitFieldStmt(IGET_OBJECT,2,4,new Field("Lorg/mortbay/io/nio/ChannelEndPoint;","_channel","Ljava/nio/channels/ByteChannel;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 2},new Method("Ljava/nio/channels/ByteChannel;","isOpen",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitJumpStmt(IF_EQZ,2,-1,L13);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,2,4,new Field("Lorg/mortbay/io/nio/ChannelEndPoint;","_channel","Ljava/nio/channels/ByteChannel;"));
                code.visitTypeStmt(INSTANCE_OF,2,2,"Ljava/nio/channels/SocketChannel;");
                code.visitJumpStmt(IF_EQZ,2,-1,L1);
                code.visitLabel(L10);
                code.visitFieldStmt(IGET_OBJECT,2,4,new Field("Lorg/mortbay/io/nio/ChannelEndPoint;","_channel","Ljava/nio/channels/ByteChannel;"));
                code.visitTypeStmt(CHECK_CAST,2,-1,"Ljava/nio/channels/SocketChannel;");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Ljava/nio/channels/SocketChannel;","socket",new String[]{ },"Ljava/net/Socket;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L11);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/net/Socket;","isClosed",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitJumpStmt(IF_NEZ,2,-1,L1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/net/Socket;","isOutputShutdown",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitJumpStmt(IF_NEZ,2,-1,L1);
                code.visitLabel(L12);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/net/Socket;","shutdownOutput",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,2,4,new Field("Lorg/mortbay/io/nio/ChannelEndPoint;","_channel","Ljava/nio/channels/ByteChannel;"));
                DexLabel L14=new DexLabel();
                code.visitLabel(L14);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 2},new Method("Ljava/nio/channels/ByteChannel;","close",new String[]{ },"V"));
                code.visitLabel(L13);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,2);
                code.visitStmt2R(MOVE_OBJECT,0,2);
                code.visitLabel(L5);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0},new Method("Lorg/mortbay/log/Log;","ignore",new String[]{ "Ljava/lang/Throwable;"},"V"));
                code.visitLabel(L6);
                code.visitFieldStmt(IGET_OBJECT,2,4,new Field("Lorg/mortbay/io/nio/ChannelEndPoint;","_channel","Ljava/nio/channels/ByteChannel;"));
                code.visitJumpStmt(GOTO,-1,-1,L14);
                code.visitLabel(L3);
                code.visitStmt1R(MOVE_EXCEPTION,2);
                code.visitStmt2R(MOVE_OBJECT,0,2);
                code.visitLabel(L7);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0},new Method("Lorg/mortbay/log/Log;","ignore",new String[]{ "Ljava/lang/Throwable;"},"V"));
                code.visitLabel(L8);
                code.visitFieldStmt(IGET_OBJECT,2,4,new Field("Lorg/mortbay/io/nio/ChannelEndPoint;","_channel","Ljava/nio/channels/ByteChannel;"));
                code.visitJumpStmt(GOTO,-1,-1,L14);
                code.visitLabel(L4);
                code.visitStmt1R(MOVE_EXCEPTION,2);
                code.visitFieldStmt(IGET_OBJECT,3,4,new Field("Lorg/mortbay/io/nio/ChannelEndPoint;","_channel","Ljava/nio/channels/ByteChannel;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 3},new Method("Ljava/nio/channels/ByteChannel;","close",new String[]{ },"V"));
                code.visitStmt1R(THROW,2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m004_fill(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/io/nio/ChannelEndPoint;","fill",new String[]{ "Lorg/mortbay/io/Buffer;"},"I"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(9);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexLabel L3=new DexLabel();
                DexLabel L4=new DexLabel();
                code.visitTryCatch(L1,L3,new DexLabel[]{L4},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"buffer");
                DexLabel L5=new DexLabel();
                ddv.visitPrologue(L5);
                ddv.visitLineNumber(120,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(121,L6);
                ddv.visitStartLocal(2,L6,"buf","Lorg/mortbay/io/Buffer;",null);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(122,L7);
                ddv.visitStartLocal(3,L7,"len","I",null);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(124,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(125,L9);
                ddv.visitStartLocal(4,L9,"nbuf","Lorg/mortbay/io/nio/NIOBuffer;",null);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(126,L10);
                ddv.visitStartLocal(1,L10,"bbuf","Ljava/nio/ByteBuffer;",null);
                ddv.visitLineNumber(130,L0);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(131,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(132,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(133,L13);
                ddv.visitLineNumber(137,L1);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(138,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(140,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(147,L16);
                ddv.visitLineNumber(137,L2);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(138,L17);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(137,L18);
                ddv.visitLineNumber(140,L4);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(144,L19);
                ddv.visitEndLocal(4,L19);
                ddv.visitEndLocal(1,L19);
                code.visitLabel(L5);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 8},new Method("Lorg/mortbay/io/Buffer;","buffer",new String[]{ },"Lorg/mortbay/io/Buffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitLabel(L6);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L7);
                code.visitTypeStmt(INSTANCE_OF,5,2,"Lorg/mortbay/io/nio/NIOBuffer;");
                code.visitJumpStmt(IF_EQZ,5,-1,L19);
                code.visitLabel(L8);
                code.visitStmt2R(MOVE_OBJECT,0,2);
                code.visitTypeStmt(CHECK_CAST,0,-1,"Lorg/mortbay/io/nio/NIOBuffer;");
                code.visitStmt2R(MOVE_OBJECT,4,0);
                code.visitLabel(L9);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 4},new Method("Lorg/mortbay/io/nio/NIOBuffer;","getByteBuffer",new String[]{ },"Ljava/nio/ByteBuffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L10);
                code.visitStmt1R(MONITOR_ENTER,4);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 8},new Method("Lorg/mortbay/io/Buffer;","putIndex",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,5},new Method("Ljava/nio/ByteBuffer;","position",new String[]{ "I"},"Ljava/nio/Buffer;"));
                code.visitLabel(L11);
                code.visitFieldStmt(IGET_OBJECT,5,7,new Field("Lorg/mortbay/io/nio/ChannelEndPoint;","_channel","Ljava/nio/channels/ByteChannel;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 5,1},new Method("Ljava/nio/channels/ByteChannel;","read",new String[]{ "Ljava/nio/ByteBuffer;"},"I"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitLabel(L12);
                code.visitJumpStmt(IF_GEZ,3,-1,L1);
                code.visitLabel(L13);
                code.visitFieldStmt(IGET_OBJECT,5,7,new Field("Lorg/mortbay/io/nio/ChannelEndPoint;","_channel","Ljava/nio/channels/ByteChannel;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 5},new Method("Ljava/nio/channels/ByteChannel;","close",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/nio/ByteBuffer;","position",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,5);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 8,5},new Method("Lorg/mortbay/io/Buffer;","setPutIndex",new String[]{ "I"},"V"));
                code.visitLabel(L14);
                code.visitConstStmt(CONST_4,5, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,5},new Method("Ljava/nio/ByteBuffer;","position",new String[]{ "I"},"Ljava/nio/Buffer;"));
                code.visitLabel(L15);
                code.visitStmt1R(MONITOR_EXIT,4);
                code.visitLabel(L16);
                code.visitStmt1R(RETURN,3);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/nio/ByteBuffer;","position",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,6);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 8,6},new Method("Lorg/mortbay/io/Buffer;","setPutIndex",new String[]{ "I"},"V"));
                code.visitLabel(L17);
                code.visitConstStmt(CONST_4,6, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,6},new Method("Ljava/nio/ByteBuffer;","position",new String[]{ "I"},"Ljava/nio/Buffer;"));
                code.visitLabel(L18);
                code.visitStmt1R(THROW,5);
                code.visitLabel(L4);
                code.visitStmt1R(MOVE_EXCEPTION,5);
                code.visitStmt1R(MONITOR_EXIT,4);
                code.visitLabel(L3);
                code.visitStmt1R(THROW,5);
                code.visitLabel(L19);
                code.visitTypeStmt(NEW_INSTANCE,5,-1,"Ljava/io/IOException;");
                code.visitConstStmt(CONST_STRING,6,"Not Implemented");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 5,6},new Method("Ljava/io/IOException;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitStmt1R(THROW,5);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m005_flush(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/io/nio/ChannelEndPoint;","flush",new String[]{ "Lorg/mortbay/io/Buffer;"},"I"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(11);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexLabel L3=new DexLabel();
                DexLabel L4=new DexLabel();
                DexLabel L5=new DexLabel();
                code.visitTryCatch(L3,L4,new DexLabel[]{L5},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"buffer");
                DexLabel L6=new DexLabel();
                ddv.visitPrologue(L6);
                ddv.visitLineNumber(155,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(156,L7);
                ddv.visitStartLocal(3,L7,"buf","Lorg/mortbay/io/Buffer;",null);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(157,L8);
                ddv.visitStartLocal(4,L8,"len","I",null);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(159,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(160,L10);
                ddv.visitStartLocal(5,L10,"nbuf","Lorg/mortbay/io/nio/NIOBuffer;",null);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(163,L11);
                ddv.visitStartLocal(2,L11,"bbuf","Ljava/nio/ByteBuffer;",null);
                ddv.visitLineNumber(167,L0);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(168,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(169,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(173,L14);
                ddv.visitLineNumber(174,L3);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(175,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(176,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(178,L17);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(191,L18);
                ddv.visitEndLocal(5,L18);
                ddv.visitEndLocal(2,L18);
                ddv.visitLineNumber(173,L2);
                ddv.visitRestartLocal(2,L2);
                ddv.visitRestartLocal(5,L2);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(174,L19);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(175,L20);
                DexLabel L21=new DexLabel();
                ddv.visitLineNumber(176,L21);
                DexLabel L22=new DexLabel();
                ddv.visitLineNumber(173,L22);
                ddv.visitLineNumber(178,L5);
                DexLabel L23=new DexLabel();
                ddv.visitLineNumber(180,L23);
                ddv.visitEndLocal(2,L23);
                ddv.visitEndLocal(5,L23);
                DexLabel L24=new DexLabel();
                ddv.visitLineNumber(182,L24);
                DexLabel L25=new DexLabel();
                ddv.visitLineNumber(183,L25);
                ddv.visitStartLocal(1,L25,"b","Ljava/nio/ByteBuffer;",null);
                DexLabel L26=new DexLabel();
                ddv.visitLineNumber(184,L26);
                ddv.visitRestartLocal(4,L26);
                DexLabel L27=new DexLabel();
                ddv.visitLineNumber(185,L27);
                DexLabel L28=new DexLabel();
                ddv.visitLineNumber(189,L28);
                ddv.visitEndLocal(1,L28);
                code.visitLabel(L6);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 10},new Method("Lorg/mortbay/io/Buffer;","buffer",new String[]{ },"Lorg/mortbay/io/Buffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitLabel(L7);
                code.visitConstStmt(CONST_4,4, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L8);
                code.visitTypeStmt(INSTANCE_OF,6,3,"Lorg/mortbay/io/nio/NIOBuffer;");
                code.visitJumpStmt(IF_EQZ,6,-1,L23);
                code.visitLabel(L9);
                code.visitStmt2R(MOVE_OBJECT,0,3);
                code.visitTypeStmt(CHECK_CAST,0,-1,"Lorg/mortbay/io/nio/NIOBuffer;");
                code.visitStmt2R(MOVE_OBJECT,5,0);
                code.visitLabel(L10);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 5},new Method("Lorg/mortbay/io/nio/NIOBuffer;","getByteBuffer",new String[]{ },"Ljava/nio/ByteBuffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitLabel(L11);
                code.visitStmt1R(MONITOR_ENTER,2);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 10},new Method("Lorg/mortbay/io/Buffer;","getIndex",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,6},new Method("Ljava/nio/ByteBuffer;","position",new String[]{ "I"},"Ljava/nio/Buffer;"));
                code.visitLabel(L12);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 10},new Method("Lorg/mortbay/io/Buffer;","putIndex",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,6},new Method("Ljava/nio/ByteBuffer;","limit",new String[]{ "I"},"Ljava/nio/Buffer;"));
                code.visitLabel(L13);
                code.visitFieldStmt(IGET_OBJECT,6,9,new Field("Lorg/mortbay/io/nio/ChannelEndPoint;","_channel","Ljava/nio/channels/ByteChannel;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 6,2},new Method("Ljava/nio/channels/ByteChannel;","write",new String[]{ "Ljava/nio/ByteBuffer;"},"I"));
                code.visitLabel(L1);
                code.visitStmt1R(MOVE_RESULT,4);
                code.visitLabel(L14);
                code.visitJumpStmt(IF_LEZ,4,-1,L15);
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 10,4},new Method("Lorg/mortbay/io/Buffer;","skip",new String[]{ "I"},"I"));
                code.visitLabel(L15);
                code.visitConstStmt(CONST_4,6, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,6},new Method("Ljava/nio/ByteBuffer;","position",new String[]{ "I"},"Ljava/nio/Buffer;"));
                code.visitLabel(L16);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Ljava/nio/ByteBuffer;","capacity",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,6},new Method("Ljava/nio/ByteBuffer;","limit",new String[]{ "I"},"Ljava/nio/Buffer;"));
                code.visitLabel(L17);
                code.visitStmt1R(MONITOR_EXIT,2);
                code.visitLabel(L18);
                code.visitStmt1R(RETURN,4);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,6);
                code.visitJumpStmt(IF_LEZ,4,-1,L20);
                code.visitLabel(L19);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 10,4},new Method("Lorg/mortbay/io/Buffer;","skip",new String[]{ "I"},"I"));
                code.visitLabel(L20);
                code.visitConstStmt(CONST_4,7, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,7},new Method("Ljava/nio/ByteBuffer;","position",new String[]{ "I"},"Ljava/nio/Buffer;"));
                code.visitLabel(L21);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Ljava/nio/ByteBuffer;","capacity",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,7},new Method("Ljava/nio/ByteBuffer;","limit",new String[]{ "I"},"Ljava/nio/Buffer;"));
                code.visitLabel(L22);
                code.visitStmt1R(THROW,6);
                code.visitLabel(L5);
                code.visitStmt1R(MOVE_EXCEPTION,6);
                code.visitStmt1R(MONITOR_EXIT,2);
                code.visitLabel(L4);
                code.visitStmt1R(THROW,6);
                code.visitLabel(L23);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 10},new Method("Lorg/mortbay/io/Buffer;","array",new String[]{ },"[B"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitJumpStmt(IF_EQZ,6,-1,L28);
                code.visitLabel(L24);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 10},new Method("Lorg/mortbay/io/Buffer;","array",new String[]{ },"[B"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 10},new Method("Lorg/mortbay/io/Buffer;","getIndex",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,7);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 10},new Method("Lorg/mortbay/io/Buffer;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,8);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 6,7,8},new Method("Ljava/nio/ByteBuffer;","wrap",new String[]{ "[B","I","I"},"Ljava/nio/ByteBuffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L25);
                code.visitFieldStmt(IGET_OBJECT,6,9,new Field("Lorg/mortbay/io/nio/ChannelEndPoint;","_channel","Ljava/nio/channels/ByteChannel;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 6,1},new Method("Ljava/nio/channels/ByteChannel;","write",new String[]{ "Ljava/nio/ByteBuffer;"},"I"));
                code.visitStmt1R(MOVE_RESULT,4);
                code.visitLabel(L26);
                code.visitJumpStmt(IF_LEZ,4,-1,L18);
                code.visitLabel(L27);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 10,4},new Method("Lorg/mortbay/io/Buffer;","skip",new String[]{ "I"},"I"));
                code.visitJumpStmt(GOTO,-1,-1,L18);
                code.visitLabel(L28);
                code.visitTypeStmt(NEW_INSTANCE,6,-1,"Ljava/io/IOException;");
                code.visitConstStmt(CONST_STRING,7,"Not Implemented");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 6,7},new Method("Ljava/io/IOException;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitStmt1R(THROW,6);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m006_flush(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/io/nio/ChannelEndPoint;","flush",new String[]{ "Lorg/mortbay/io/Buffer;","Lorg/mortbay/io/Buffer;","Lorg/mortbay/io/Buffer;"},"I"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(15);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexLabel L3=new DexLabel();
                DexLabel L4=new DexLabel();
                code.visitTryCatch(L1,L3,new DexLabel[]{L4},new String[]{ null});
                DexLabel L5=new DexLabel();
                DexLabel L6=new DexLabel();
                code.visitTryCatch(L3,L5,new DexLabel[]{L6},new String[]{ null});
                DexLabel L7=new DexLabel();
                DexLabel L8=new DexLabel();
                code.visitTryCatch(L5,L7,new DexLabel[]{L8},new String[]{ null});
                DexLabel L9=new DexLabel();
                code.visitTryCatch(L7,L9,new DexLabel[]{L4},new String[]{ null});
                DexLabel L10=new DexLabel();
                code.visitTryCatch(L9,L10,new DexLabel[]{L2},new String[]{ null});
                DexLabel L11=new DexLabel();
                DexLabel L12=new DexLabel();
                code.visitTryCatch(L11,L12,new DexLabel[]{L6},new String[]{ null});
                DexLabel L13=new DexLabel();
                DexLabel L14=new DexLabel();
                code.visitTryCatch(L13,L14,new DexLabel[]{L8},new String[]{ null});
                DexLabel L15=new DexLabel();
                code.visitTryCatch(L14,L15,new DexLabel[]{L4},new String[]{ null});
                DexLabel L16=new DexLabel();
                code.visitTryCatch(L15,L16,new DexLabel[]{L2},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"header");
                ddv.visitParameterName(1,"buffer");
                ddv.visitParameterName(2,"trailer");
                DexLabel L17=new DexLabel();
                ddv.visitPrologue(L17);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(199,L18);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(201,L19);
                ddv.visitStartLocal(6,L19,"length","I",null);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(202,L20);
                ddv.visitStartLocal(3,L20,"buf0","Lorg/mortbay/io/Buffer;",null);
                DexLabel L21=new DexLabel();
                ddv.visitLineNumber(204,L21);
                ddv.visitStartLocal(4,L21,"buf1","Lorg/mortbay/io/Buffer;",null);
                DexLabel L22=new DexLabel();
                ddv.visitLineNumber(208,L22);
                DexLabel L23=new DexLabel();
                ddv.visitLineNumber(209,L23);
                ddv.visitStartLocal(7,L23,"nbuf0","Lorg/mortbay/io/nio/NIOBuffer;",null);
                DexLabel L24=new DexLabel();
                ddv.visitLineNumber(210,L24);
                ddv.visitStartLocal(1,L24,"bbuf0","Ljava/nio/ByteBuffer;",null);
                DexLabel L25=new DexLabel();
                ddv.visitLineNumber(211,L25);
                ddv.visitStartLocal(8,L25,"nbuf1","Lorg/mortbay/io/nio/NIOBuffer;",null);
                DexLabel L26=new DexLabel();
                ddv.visitLineNumber(213,L26);
                ddv.visitStartLocal(2,L26,"bbuf1","Ljava/nio/ByteBuffer;",null);
                ddv.visitLineNumber(216,L0);
                ddv.visitLineNumber(218,L1);
                ddv.visitLineNumber(223,L3);
                DexLabel L27=new DexLabel();
                ddv.visitLineNumber(224,L27);
                DexLabel L28=new DexLabel();
                ddv.visitLineNumber(225,L28);
                DexLabel L29=new DexLabel();
                ddv.visitLineNumber(226,L29);
                DexLabel L30=new DexLabel();
                ddv.visitLineNumber(228,L30);
                DexLabel L31=new DexLabel();
                ddv.visitLineNumber(229,L31);
                DexLabel L32=new DexLabel();
                ddv.visitLineNumber(232,L32);
                DexLabel L33=new DexLabel();
                ddv.visitLineNumber(234,L33);
                DexLabel L34=new DexLabel();
                ddv.visitLineNumber(235,L34);
                ddv.visitStartLocal(5,L34,"hl","I",null);
                DexLabel L35=new DexLabel();
                ddv.visitLineNumber(237,L35);
                DexLabel L36=new DexLabel();
                ddv.visitLineNumber(238,L36);
                ddv.visitLineNumber(249,L5);
                DexLabel L37=new DexLabel();
                ddv.visitLineNumber(250,L37);
                DexLabel L38=new DexLabel();
                ddv.visitLineNumber(251,L38);
                DexLabel L39=new DexLabel();
                ddv.visitLineNumber(252,L39);
                DexLabel L40=new DexLabel();
                ddv.visitLineNumber(254,L40);
                DexLabel L41=new DexLabel();
                ddv.visitLineNumber(255,L41);
                DexLabel L42=new DexLabel();
                ddv.visitLineNumber(256,L42);
                DexLabel L43=new DexLabel();
                ddv.visitLineNumber(257,L43);
                DexLabel L44=new DexLabel();
                ddv.visitLineNumber(259,L44);
                ddv.visitLineNumber(260,L7);
                ddv.visitLineNumber(261,L9);
                ddv.visitLineNumber(283,L10);
                ddv.visitEndLocal(7,L10);
                ddv.visitEndLocal(1,L10);
                ddv.visitEndLocal(8,L10);
                ddv.visitEndLocal(2,L10);
                ddv.visitEndLocal(5,L10);
                DexLabel L45=new DexLabel();
                ddv.visitLineNumber(201,L45);
                ddv.visitEndLocal(3,L45);
                ddv.visitEndLocal(4,L45);
                DexLabel L46=new DexLabel();
                ddv.visitLineNumber(202,L46);
                ddv.visitRestartLocal(3,L46);
                DexLabel L47=new DexLabel();
                ddv.visitLineNumber(240,L47);
                ddv.visitRestartLocal(1,L47);
                ddv.visitRestartLocal(2,L47);
                ddv.visitRestartLocal(4,L47);
                ddv.visitRestartLocal(5,L47);
                ddv.visitRestartLocal(7,L47);
                ddv.visitRestartLocal(8,L47);
                ddv.visitLineNumber(242,L11);
                ddv.visitLineNumber(249,L6);
                ddv.visitEndLocal(5,L6);
                DexLabel L48=new DexLabel();
                ddv.visitLineNumber(250,L48);
                DexLabel L49=new DexLabel();
                ddv.visitLineNumber(251,L49);
                DexLabel L50=new DexLabel();
                ddv.visitLineNumber(252,L50);
                DexLabel L51=new DexLabel();
                ddv.visitLineNumber(254,L51);
                DexLabel L52=new DexLabel();
                ddv.visitLineNumber(255,L52);
                DexLabel L53=new DexLabel();
                ddv.visitLineNumber(256,L53);
                DexLabel L54=new DexLabel();
                ddv.visitLineNumber(257,L54);
                DexLabel L55=new DexLabel();
                ddv.visitLineNumber(249,L55);
                ddv.visitLineNumber(259,L8);
                ddv.visitLineNumber(260,L4);
                ddv.visitLineNumber(261,L2);
                DexLabel L56=new DexLabel();
                ddv.visitLineNumber(268,L56);
                ddv.visitEndLocal(1,L56);
                ddv.visitEndLocal(2,L56);
                ddv.visitEndLocal(7,L56);
                ddv.visitEndLocal(8,L56);
                DexLabel L57=new DexLabel();
                ddv.visitLineNumber(269,L57);
                DexLabel L58=new DexLabel();
                ddv.visitLineNumber(272,L58);
                DexLabel L59=new DexLabel();
                ddv.visitLineNumber(274,L59);
                DexLabel L60=new DexLabel();
                ddv.visitLineNumber(277,L60);
                DexLabel L61=new DexLabel();
                ddv.visitLineNumber(280,L61);
                code.visitLabel(L17);
                code.visitConstStmt(CONST_4,10, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L18);
                code.visitConstStmt(CONST_4,6, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L19);
                code.visitJumpStmt(IF_NEZ,12,-1,L45);
                code.visitStmt2R(MOVE_OBJECT,3,10);
                code.visitLabel(L20);
                code.visitJumpStmt(IF_NEZ,13,-1,L46);
                code.visitStmt2R(MOVE_OBJECT,4,10);
                code.visitLabel(L21);
                code.visitFieldStmt(IGET_OBJECT,9,11,new Field("Lorg/mortbay/io/nio/ChannelEndPoint;","_channel","Ljava/nio/channels/ByteChannel;"));
                code.visitTypeStmt(INSTANCE_OF,9,9,"Ljava/nio/channels/GatheringByteChannel;");
                code.visitJumpStmt(IF_EQZ,9,-1,L56);
                code.visitJumpStmt(IF_EQZ,12,-1,L56);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 12},new Method("Lorg/mortbay/io/Buffer;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,9);
                code.visitJumpStmt(IF_EQZ,9,-1,L56);
                code.visitTypeStmt(INSTANCE_OF,9,12,"Lorg/mortbay/io/nio/NIOBuffer;");
                code.visitJumpStmt(IF_EQZ,9,-1,L56);
                code.visitJumpStmt(IF_EQZ,13,-1,L56);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 13},new Method("Lorg/mortbay/io/Buffer;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,9);
                code.visitJumpStmt(IF_EQZ,9,-1,L56);
                code.visitTypeStmt(INSTANCE_OF,9,13,"Lorg/mortbay/io/nio/NIOBuffer;");
                code.visitJumpStmt(IF_EQZ,9,-1,L56);
                code.visitLabel(L22);
                code.visitStmt2R(MOVE_OBJECT,0,3);
                code.visitTypeStmt(CHECK_CAST,0,-1,"Lorg/mortbay/io/nio/NIOBuffer;");
                code.visitStmt2R(MOVE_OBJECT,7,0);
                code.visitLabel(L23);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 7},new Method("Lorg/mortbay/io/nio/NIOBuffer;","getByteBuffer",new String[]{ },"Ljava/nio/ByteBuffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L24);
                code.visitStmt2R(MOVE_OBJECT,0,4);
                code.visitTypeStmt(CHECK_CAST,0,-1,"Lorg/mortbay/io/nio/NIOBuffer;");
                code.visitStmt2R(MOVE_OBJECT,8,0);
                code.visitLabel(L25);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 8},new Method("Lorg/mortbay/io/nio/NIOBuffer;","getByteBuffer",new String[]{ },"Ljava/nio/ByteBuffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitLabel(L26);
                code.visitStmt1R(MONITOR_ENTER,11);
                code.visitLabel(L0);
                code.visitStmt1R(MONITOR_ENTER,1);
                code.visitLabel(L1);
                code.visitStmt1R(MONITOR_ENTER,2);
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 12},new Method("Lorg/mortbay/io/Buffer;","getIndex",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,9);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,9},new Method("Ljava/nio/ByteBuffer;","position",new String[]{ "I"},"Ljava/nio/Buffer;"));
                code.visitLabel(L27);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 12},new Method("Lorg/mortbay/io/Buffer;","putIndex",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,9);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,9},new Method("Ljava/nio/ByteBuffer;","limit",new String[]{ "I"},"Ljava/nio/Buffer;"));
                code.visitLabel(L28);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 13},new Method("Lorg/mortbay/io/Buffer;","getIndex",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,9);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,9},new Method("Ljava/nio/ByteBuffer;","position",new String[]{ "I"},"Ljava/nio/Buffer;"));
                code.visitLabel(L29);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 13},new Method("Lorg/mortbay/io/Buffer;","putIndex",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,9);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,9},new Method("Ljava/nio/ByteBuffer;","limit",new String[]{ "I"},"Ljava/nio/Buffer;"));
                code.visitLabel(L30);
                code.visitFieldStmt(IGET_OBJECT,9,11,new Field("Lorg/mortbay/io/nio/ChannelEndPoint;","_gather2","[Ljava/nio/ByteBuffer;"));
                code.visitConstStmt(CONST_4,10, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitStmt3R(APUT_OBJECT,1,9,10);
                code.visitLabel(L31);
                code.visitFieldStmt(IGET_OBJECT,9,11,new Field("Lorg/mortbay/io/nio/ChannelEndPoint;","_gather2","[Ljava/nio/ByteBuffer;"));
                code.visitConstStmt(CONST_4,10, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitStmt3R(APUT_OBJECT,2,9,10);
                code.visitLabel(L32);
                code.visitFieldStmt(IGET_OBJECT,9,11,new Field("Lorg/mortbay/io/nio/ChannelEndPoint;","_channel","Ljava/nio/channels/ByteChannel;"));
                code.visitTypeStmt(CHECK_CAST,9,-1,"Ljava/nio/channels/GatheringByteChannel;");
                code.visitFieldStmt(IGET_OBJECT,10,11,new Field("Lorg/mortbay/io/nio/ChannelEndPoint;","_gather2","[Ljava/nio/ByteBuffer;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 9,10},new Method("Ljava/nio/channels/GatheringByteChannel;","write",new String[]{ "[Ljava/nio/ByteBuffer;"},"J"));
                code.visitStmt1R(MOVE_RESULT_WIDE,9);
                code.visitStmt2R(LONG_TO_INT,6,9);
                code.visitLabel(L33);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 12},new Method("Lorg/mortbay/io/Buffer;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,5);
                code.visitLabel(L34);
                code.visitJumpStmt(IF_LE,6,5,L47);
                code.visitLabel(L35);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 12},new Method("Lorg/mortbay/io/Buffer;","clear",new String[]{ },"V"));
                code.visitLabel(L36);
                code.visitStmt3R(SUB_INT,9,6,5);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 13,9},new Method("Lorg/mortbay/io/Buffer;","skip",new String[]{ "I"},"I"));
                code.visitLabel(L5);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 12},new Method("Lorg/mortbay/io/Buffer;","isImmutable",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,9);
                code.visitJumpStmt(IF_NEZ,9,-1,L38);
                code.visitLabel(L37);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/nio/ByteBuffer;","position",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,9);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 12,9},new Method("Lorg/mortbay/io/Buffer;","setGetIndex",new String[]{ "I"},"V"));
                code.visitLabel(L38);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 13},new Method("Lorg/mortbay/io/Buffer;","isImmutable",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,9);
                code.visitJumpStmt(IF_NEZ,9,-1,L40);
                code.visitLabel(L39);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Ljava/nio/ByteBuffer;","position",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,9);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 13,9},new Method("Lorg/mortbay/io/Buffer;","setGetIndex",new String[]{ "I"},"V"));
                code.visitLabel(L40);
                code.visitConstStmt(CONST_4,9, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,9},new Method("Ljava/nio/ByteBuffer;","position",new String[]{ "I"},"Ljava/nio/Buffer;"));
                code.visitLabel(L41);
                code.visitConstStmt(CONST_4,9, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,9},new Method("Ljava/nio/ByteBuffer;","position",new String[]{ "I"},"Ljava/nio/Buffer;"));
                code.visitLabel(L42);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/nio/ByteBuffer;","capacity",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,9);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,9},new Method("Ljava/nio/ByteBuffer;","limit",new String[]{ "I"},"Ljava/nio/Buffer;"));
                code.visitLabel(L43);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Ljava/nio/ByteBuffer;","capacity",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,9);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,9},new Method("Ljava/nio/ByteBuffer;","limit",new String[]{ "I"},"Ljava/nio/Buffer;"));
                code.visitLabel(L44);
                code.visitStmt1R(MONITOR_EXIT,2);
                code.visitLabel(L7);
                code.visitStmt1R(MONITOR_EXIT,1);
                code.visitLabel(L9);
                code.visitStmt1R(MONITOR_EXIT,11);
                code.visitLabel(L10);
                code.visitStmt1R(RETURN,6);
                code.visitLabel(L45);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 12},new Method("Lorg/mortbay/io/Buffer;","buffer",new String[]{ },"Lorg/mortbay/io/Buffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,9);
                code.visitStmt2R(MOVE_OBJECT,3,9);
                code.visitJumpStmt(GOTO_16,-1,-1,L20);
                code.visitLabel(L46);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 13},new Method("Lorg/mortbay/io/Buffer;","buffer",new String[]{ },"Lorg/mortbay/io/Buffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,9);
                code.visitStmt2R(MOVE_OBJECT,4,9);
                code.visitJumpStmt(GOTO_16,-1,-1,L21);
                code.visitLabel(L47);
                code.visitJumpStmt(IF_LEZ,6,-1,L5);
                code.visitLabel(L11);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 12,6},new Method("Lorg/mortbay/io/Buffer;","skip",new String[]{ "I"},"I"));
                code.visitLabel(L12);
                code.visitJumpStmt(GOTO,-1,-1,L5);
                code.visitLabel(L6);
                code.visitStmt1R(MOVE_EXCEPTION,9);
                code.visitLabel(L13);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 12},new Method("Lorg/mortbay/io/Buffer;","isImmutable",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,10);
                code.visitJumpStmt(IF_NEZ,10,-1,L49);
                code.visitLabel(L48);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/nio/ByteBuffer;","position",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,10);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 12,10},new Method("Lorg/mortbay/io/Buffer;","setGetIndex",new String[]{ "I"},"V"));
                code.visitLabel(L49);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 13},new Method("Lorg/mortbay/io/Buffer;","isImmutable",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,10);
                code.visitJumpStmt(IF_NEZ,10,-1,L51);
                code.visitLabel(L50);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Ljava/nio/ByteBuffer;","position",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,10);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 13,10},new Method("Lorg/mortbay/io/Buffer;","setGetIndex",new String[]{ "I"},"V"));
                code.visitLabel(L51);
                code.visitConstStmt(CONST_4,10, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,10},new Method("Ljava/nio/ByteBuffer;","position",new String[]{ "I"},"Ljava/nio/Buffer;"));
                code.visitLabel(L52);
                code.visitConstStmt(CONST_4,10, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,10},new Method("Ljava/nio/ByteBuffer;","position",new String[]{ "I"},"Ljava/nio/Buffer;"));
                code.visitLabel(L53);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/nio/ByteBuffer;","capacity",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,10);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,10},new Method("Ljava/nio/ByteBuffer;","limit",new String[]{ "I"},"Ljava/nio/Buffer;"));
                code.visitLabel(L54);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Ljava/nio/ByteBuffer;","capacity",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,10);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,10},new Method("Ljava/nio/ByteBuffer;","limit",new String[]{ "I"},"Ljava/nio/Buffer;"));
                code.visitLabel(L55);
                code.visitStmt1R(THROW,9);
                code.visitLabel(L8);
                code.visitStmt1R(MOVE_EXCEPTION,9);
                code.visitStmt1R(MONITOR_EXIT,2);
                code.visitLabel(L14);
                code.visitStmt1R(THROW,9);
                code.visitLabel(L4);
                code.visitStmt1R(MOVE_EXCEPTION,9);
                code.visitStmt1R(MONITOR_EXIT,1);
                code.visitLabel(L15);
                code.visitStmt1R(THROW,9);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,9);
                code.visitStmt1R(MONITOR_EXIT,11);
                code.visitLabel(L16);
                code.visitStmt1R(THROW,9);
                code.visitLabel(L56);
                code.visitJumpStmt(IF_EQZ,12,-1,L58);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 12},new Method("Lorg/mortbay/io/Buffer;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,9);
                code.visitJumpStmt(IF_LEZ,9,-1,L58);
                code.visitLabel(L57);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 11,12},new Method("Lorg/mortbay/io/nio/ChannelEndPoint;","flush",new String[]{ "Lorg/mortbay/io/Buffer;"},"I"));
                code.visitStmt1R(MOVE_RESULT,6);
                code.visitLabel(L58);
                DexLabel L62=new DexLabel();
                code.visitJumpStmt(IF_EQZ,12,-1,L62);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 12},new Method("Lorg/mortbay/io/Buffer;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,9);
                code.visitJumpStmt(IF_NEZ,9,-1,L60);
                code.visitLabel(L62);
                code.visitJumpStmt(IF_EQZ,13,-1,L60);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 13},new Method("Lorg/mortbay/io/Buffer;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,9);
                code.visitJumpStmt(IF_LEZ,9,-1,L60);
                code.visitLabel(L59);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 11,13},new Method("Lorg/mortbay/io/nio/ChannelEndPoint;","flush",new String[]{ "Lorg/mortbay/io/Buffer;"},"I"));
                code.visitStmt1R(MOVE_RESULT,9);
                code.visitStmt2R(ADD_INT_2ADDR,6,9);
                code.visitLabel(L60);
                DexLabel L63=new DexLabel();
                code.visitJumpStmt(IF_EQZ,12,-1,L63);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 12},new Method("Lorg/mortbay/io/Buffer;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,9);
                code.visitJumpStmt(IF_NEZ,9,-1,L10);
                code.visitLabel(L63);
                DexLabel L64=new DexLabel();
                code.visitJumpStmt(IF_EQZ,13,-1,L64);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 13},new Method("Lorg/mortbay/io/Buffer;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,9);
                code.visitJumpStmt(IF_NEZ,9,-1,L10);
                code.visitLabel(L64);
                code.visitJumpStmt(IF_EQZ,14,-1,L10);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 14},new Method("Lorg/mortbay/io/Buffer;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,9);
                code.visitJumpStmt(IF_LEZ,9,-1,L10);
                code.visitLabel(L61);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 11,14},new Method("Lorg/mortbay/io/nio/ChannelEndPoint;","flush",new String[]{ "Lorg/mortbay/io/Buffer;"},"I"));
                code.visitStmt1R(MOVE_RESULT,9);
                code.visitStmt2R(ADD_INT_2ADDR,6,9);
                code.visitJumpStmt(GOTO_16,-1,-1,L10);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m007_flush(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/io/nio/ChannelEndPoint;","flush",new String[]{ },"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(1);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(411,L0);
                code.visitLabel(L0);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m008_getChannel(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/io/nio/ChannelEndPoint;","getChannel",new String[]{ },"Ljava/nio/channels/ByteChannel;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(291,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/io/nio/ChannelEndPoint;","_channel","Ljava/nio/channels/ByteChannel;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m009_getLocalAddr(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/io/nio/ChannelEndPoint;","getLocalAddr",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(301,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(302,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(310,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(304,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(305,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(307,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(308,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(310,L7);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/io/nio/ChannelEndPoint;","_socket","Ljava/net/Socket;"));
                code.visitJumpStmt(IF_NEZ,0,-1,L3);
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L2);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/io/nio/ChannelEndPoint;","_local","Ljava/net/InetSocketAddress;"));
                code.visitJumpStmt(IF_NEZ,0,-1,L5);
                code.visitLabel(L4);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/io/nio/ChannelEndPoint;","_socket","Ljava/net/Socket;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/net/Socket;","getLocalSocketAddress",new String[]{ },"Ljava/net/SocketAddress;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitTypeStmt(CHECK_CAST,0,-1,"Ljava/net/InetSocketAddress;");
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/io/nio/ChannelEndPoint;","_local","Ljava/net/InetSocketAddress;"));
                code.visitLabel(L5);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/io/nio/ChannelEndPoint;","_local","Ljava/net/InetSocketAddress;"));
                code.visitJumpStmt(IF_EQZ,0,-1,L6);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/io/nio/ChannelEndPoint;","_local","Ljava/net/InetSocketAddress;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/net/InetSocketAddress;","getAddress",new String[]{ },"Ljava/net/InetAddress;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitJumpStmt(IF_EQZ,0,-1,L6);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/io/nio/ChannelEndPoint;","_local","Ljava/net/InetSocketAddress;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/net/InetSocketAddress;","getAddress",new String[]{ },"Ljava/net/InetAddress;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/net/InetAddress;","isAnyLocalAddress",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_EQZ,0,-1,L7);
                code.visitLabel(L6);
                code.visitConstStmt(CONST_STRING,0,"0.0.0.0");
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitLabel(L7);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/io/nio/ChannelEndPoint;","_local","Ljava/net/InetSocketAddress;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/net/InetSocketAddress;","getAddress",new String[]{ },"Ljava/net/InetAddress;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/net/InetAddress;","getHostAddress",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m010_getLocalHost(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/io/nio/ChannelEndPoint;","getLocalHost",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(319,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(320,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(328,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(322,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(323,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(325,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(326,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(328,L7);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/io/nio/ChannelEndPoint;","_socket","Ljava/net/Socket;"));
                code.visitJumpStmt(IF_NEZ,0,-1,L3);
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L2);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/io/nio/ChannelEndPoint;","_local","Ljava/net/InetSocketAddress;"));
                code.visitJumpStmt(IF_NEZ,0,-1,L5);
                code.visitLabel(L4);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/io/nio/ChannelEndPoint;","_socket","Ljava/net/Socket;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/net/Socket;","getLocalSocketAddress",new String[]{ },"Ljava/net/SocketAddress;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitTypeStmt(CHECK_CAST,0,-1,"Ljava/net/InetSocketAddress;");
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/io/nio/ChannelEndPoint;","_local","Ljava/net/InetSocketAddress;"));
                code.visitLabel(L5);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/io/nio/ChannelEndPoint;","_local","Ljava/net/InetSocketAddress;"));
                code.visitJumpStmt(IF_EQZ,0,-1,L6);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/io/nio/ChannelEndPoint;","_local","Ljava/net/InetSocketAddress;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/net/InetSocketAddress;","getAddress",new String[]{ },"Ljava/net/InetAddress;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitJumpStmt(IF_EQZ,0,-1,L6);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/io/nio/ChannelEndPoint;","_local","Ljava/net/InetSocketAddress;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/net/InetSocketAddress;","getAddress",new String[]{ },"Ljava/net/InetAddress;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/net/InetAddress;","isAnyLocalAddress",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_EQZ,0,-1,L7);
                code.visitLabel(L6);
                code.visitConstStmt(CONST_STRING,0,"0.0.0.0");
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitLabel(L7);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/io/nio/ChannelEndPoint;","_local","Ljava/net/InetSocketAddress;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/net/InetSocketAddress;","getAddress",new String[]{ },"Ljava/net/InetAddress;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/net/InetAddress;","getCanonicalHostName",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m011_getLocalPort(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/io/nio/ChannelEndPoint;","getLocalPort",new String[]{ },"I"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(337,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(338,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(344,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(340,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(341,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(342,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(343,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(344,L7);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/io/nio/ChannelEndPoint;","_socket","Ljava/net/Socket;"));
                code.visitJumpStmt(IF_NEZ,0,-1,L3);
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L2);
                code.visitStmt1R(RETURN,0);
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/io/nio/ChannelEndPoint;","_local","Ljava/net/InetSocketAddress;"));
                code.visitJumpStmt(IF_NEZ,0,-1,L5);
                code.visitLabel(L4);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/io/nio/ChannelEndPoint;","_socket","Ljava/net/Socket;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/net/Socket;","getLocalSocketAddress",new String[]{ },"Ljava/net/SocketAddress;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitTypeStmt(CHECK_CAST,0,-1,"Ljava/net/InetSocketAddress;");
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/io/nio/ChannelEndPoint;","_local","Ljava/net/InetSocketAddress;"));
                code.visitLabel(L5);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/io/nio/ChannelEndPoint;","_local","Ljava/net/InetSocketAddress;"));
                code.visitJumpStmt(IF_NEZ,0,-1,L7);
                code.visitLabel(L6);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(-1)); // int: 0xffffffff  float:NaN
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitLabel(L7);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/io/nio/ChannelEndPoint;","_local","Ljava/net/InetSocketAddress;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/net/InetSocketAddress;","getPort",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m012_getRemoteAddr(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/io/nio/ChannelEndPoint;","getRemoteAddr",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(353,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(361,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(356,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(357,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(359,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(360,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(361,L7);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/io/nio/ChannelEndPoint;","_socket","Ljava/net/Socket;"));
                code.visitJumpStmt(IF_NEZ,0,-1,L3);
                code.visitStmt2R(MOVE_OBJECT,0,1);
                code.visitLabel(L2);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/io/nio/ChannelEndPoint;","_remote","Ljava/net/InetSocketAddress;"));
                code.visitJumpStmt(IF_NEZ,0,-1,L5);
                code.visitLabel(L4);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/io/nio/ChannelEndPoint;","_socket","Ljava/net/Socket;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/net/Socket;","getRemoteSocketAddress",new String[]{ },"Ljava/net/SocketAddress;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitTypeStmt(CHECK_CAST,0,-1,"Ljava/net/InetSocketAddress;");
                code.visitFieldStmt(IPUT_OBJECT,0,2,new Field("Lorg/mortbay/io/nio/ChannelEndPoint;","_remote","Ljava/net/InetSocketAddress;"));
                code.visitLabel(L5);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/io/nio/ChannelEndPoint;","_remote","Ljava/net/InetSocketAddress;"));
                code.visitJumpStmt(IF_NEZ,0,-1,L7);
                code.visitStmt2R(MOVE_OBJECT,0,1);
                code.visitLabel(L6);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitLabel(L7);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/io/nio/ChannelEndPoint;","_remote","Ljava/net/InetSocketAddress;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/net/InetSocketAddress;","getAddress",new String[]{ },"Ljava/net/InetAddress;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/net/InetAddress;","getHostAddress",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m013_getRemoteHost(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/io/nio/ChannelEndPoint;","getRemoteHost",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(370,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(378,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(373,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(374,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(376,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(377,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(378,L7);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/io/nio/ChannelEndPoint;","_socket","Ljava/net/Socket;"));
                code.visitJumpStmt(IF_NEZ,0,-1,L3);
                code.visitStmt2R(MOVE_OBJECT,0,1);
                code.visitLabel(L2);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/io/nio/ChannelEndPoint;","_remote","Ljava/net/InetSocketAddress;"));
                code.visitJumpStmt(IF_NEZ,0,-1,L5);
                code.visitLabel(L4);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/io/nio/ChannelEndPoint;","_socket","Ljava/net/Socket;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/net/Socket;","getRemoteSocketAddress",new String[]{ },"Ljava/net/SocketAddress;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitTypeStmt(CHECK_CAST,0,-1,"Ljava/net/InetSocketAddress;");
                code.visitFieldStmt(IPUT_OBJECT,0,2,new Field("Lorg/mortbay/io/nio/ChannelEndPoint;","_remote","Ljava/net/InetSocketAddress;"));
                code.visitLabel(L5);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/io/nio/ChannelEndPoint;","_remote","Ljava/net/InetSocketAddress;"));
                code.visitJumpStmt(IF_NEZ,0,-1,L7);
                code.visitStmt2R(MOVE_OBJECT,0,1);
                code.visitLabel(L6);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitLabel(L7);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/io/nio/ChannelEndPoint;","_remote","Ljava/net/InetSocketAddress;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/net/InetSocketAddress;","getAddress",new String[]{ },"Ljava/net/InetAddress;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/net/InetAddress;","getCanonicalHostName",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m014_getRemotePort(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/io/nio/ChannelEndPoint;","getRemotePort",new String[]{ },"I"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(387,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(388,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(395,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(390,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(391,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(393,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(394,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(395,L8);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(-1)); // int: 0xffffffff  float:NaN
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/io/nio/ChannelEndPoint;","_socket","Ljava/net/Socket;"));
                code.visitJumpStmt(IF_NEZ,0,-1,L4);
                code.visitLabel(L2);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L3);
                code.visitStmt1R(RETURN,0);
                code.visitLabel(L4);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/io/nio/ChannelEndPoint;","_remote","Ljava/net/InetSocketAddress;"));
                code.visitJumpStmt(IF_NEZ,0,-1,L6);
                code.visitLabel(L5);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/io/nio/ChannelEndPoint;","_socket","Ljava/net/Socket;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/net/Socket;","getRemoteSocketAddress",new String[]{ },"Ljava/net/SocketAddress;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitTypeStmt(CHECK_CAST,0,-1,"Ljava/net/InetSocketAddress;");
                code.visitFieldStmt(IPUT_OBJECT,0,2,new Field("Lorg/mortbay/io/nio/ChannelEndPoint;","_remote","Ljava/net/InetSocketAddress;"));
                code.visitLabel(L6);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/io/nio/ChannelEndPoint;","_remote","Ljava/net/InetSocketAddress;"));
                code.visitJumpStmt(IF_NEZ,0,-1,L8);
                code.visitStmt2R(MOVE,0,1);
                code.visitLabel(L7);
                code.visitJumpStmt(GOTO,-1,-1,L3);
                code.visitLabel(L8);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/io/nio/ChannelEndPoint;","_remote","Ljava/net/InetSocketAddress;"));
                DexLabel L9=new DexLabel();
                code.visitJumpStmt(IF_NEZ,0,-1,L9);
                code.visitStmt2R(MOVE,0,1);
                code.visitJumpStmt(GOTO,-1,-1,L3);
                code.visitLabel(L9);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/io/nio/ChannelEndPoint;","_remote","Ljava/net/InetSocketAddress;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/net/InetSocketAddress;","getPort",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(GOTO,-1,-1,L3);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m015_getTransport(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/io/nio/ChannelEndPoint;","getTransport",new String[]{ },"Ljava/lang/Object;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(404,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/io/nio/ChannelEndPoint;","_channel","Ljava/nio/channels/ByteChannel;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m016_isBlocking(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/io/nio/ChannelEndPoint;","isBlocking",new String[]{ },"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(60,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(61,L1);
                DexLabel L2=new DexLabel();
                ddv.visitEndLocal(1,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(62,L3);
                DexLabel L4=new DexLabel();
                ddv.visitRestartLocal(1,L4);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/io/nio/ChannelEndPoint;","_channel","Ljava/nio/channels/ByteChannel;"));
                code.visitTypeStmt(INSTANCE_OF,0,0,"Ljava/nio/channels/SelectableChannel;");
                code.visitJumpStmt(IF_EQZ,0,-1,L4);
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,1,1,new Field("Lorg/mortbay/io/nio/ChannelEndPoint;","_channel","Ljava/nio/channels/ByteChannel;"));
                code.visitLabel(L2);
                code.visitTypeStmt(CHECK_CAST,1,-1,"Ljava/nio/channels/SelectableChannel;");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/nio/channels/SelectableChannel;","isBlocking",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitLabel(L3);
                code.visitStmt1R(RETURN,0);
                code.visitLabel(L4);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L3);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m017_isBufferingInput(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/io/nio/ChannelEndPoint;","isBufferingInput",new String[]{ },"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(416,L0);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m018_isBufferingOutput(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/io/nio/ChannelEndPoint;","isBufferingOutput",new String[]{ },"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(422,L0);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m019_isBufferred(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/io/nio/ChannelEndPoint;","isBufferred",new String[]{ },"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(428,L0);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m020_isOpen(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/io/nio/ChannelEndPoint;","isOpen",new String[]{ },"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(80,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/io/nio/ChannelEndPoint;","_channel","Ljava/nio/channels/ByteChannel;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0},new Method("Ljava/nio/channels/ByteChannel;","isOpen",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
