package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0292_org_mortbay_jetty_security_HashUserRealm_KnownUser {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(0,"Lorg/mortbay/jetty/security/HashUserRealm$KnownUser;","Lorg/mortbay/jetty/security/HashUserRealm$User;",new String[]{ });
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("HashUserRealm.java");
        if(cv!=null){
            DexAnnotationVisitor av00 = cv.visitAnnotation("Ldalvik/annotation/EnclosingClass;", Visibility.SYSTEM);
            if(av00 != null) {
                av00.visit("value", new DexType("Lorg/mortbay/jetty/security/HashUserRealm;"));
                av00.visitEnd();
            }
        }
        if(cv!=null){
            DexAnnotationVisitor av00 = cv.visitAnnotation("Ldalvik/annotation/InnerClass;", Visibility.SYSTEM);
            if(av00 != null) {
                av00.visit("accessFlags",  Integer.valueOf(2));
                av00.visit("name", "KnownUser");
                av00.visitEnd();
            }
        }
        f000__cred(cv);
        f001__userName(cv);
        f002_this$0(cv);
        m000__init_(cv);
        m001_authenticate(cv);
        m002_getName(cv);
        m003_isAuthenticated(cv);
    }
    public static void f000__cred(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/security/HashUserRealm$KnownUser;","_cred","Lorg/mortbay/jetty/security/Credential;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f001__userName(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/security/HashUserRealm$KnownUser;","_userName","Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f002_this$0(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_FINAL|ACC_SYNTHETIC, new Field("Lorg/mortbay/jetty/security/HashUserRealm$KnownUser;","this$0","Lorg/mortbay/jetty/security/HashUserRealm;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void m000__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_CONSTRUCTOR, new Method("Lorg/mortbay/jetty/security/HashUserRealm$KnownUser;","<init>",new String[]{ "Lorg/mortbay/jetty/security/HashUserRealm;","Ljava/lang/String;","Lorg/mortbay/jetty/security/Credential;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(1,"name");
                ddv.visitParameterName(2,"credential");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(483,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(484,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(485,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(486,L3);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_OBJECT,2,1,new Field("Lorg/mortbay/jetty/security/HashUserRealm$KnownUser;","this$0","Lorg/mortbay/jetty/security/HashUserRealm;"));
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1,2,0},new Method("Lorg/mortbay/jetty/security/HashUserRealm$User;","<init>",new String[]{ "Lorg/mortbay/jetty/security/HashUserRealm;","Lorg/mortbay/jetty/security/HashUserRealm$1;"},"V"));
                code.visitLabel(L1);
                code.visitFieldStmt(IPUT_OBJECT,3,1,new Field("Lorg/mortbay/jetty/security/HashUserRealm$KnownUser;","_userName","Ljava/lang/String;"));
                code.visitLabel(L2);
                code.visitFieldStmt(IPUT_OBJECT,4,1,new Field("Lorg/mortbay/jetty/security/HashUserRealm$KnownUser;","_cred","Lorg/mortbay/jetty/security/Credential;"));
                code.visitLabel(L3);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001_authenticate(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(0, new Method("Lorg/mortbay/jetty/security/HashUserRealm$KnownUser;","authenticate",new String[]{ "Ljava/lang/Object;"},"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"credentials");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(491,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/security/HashUserRealm$KnownUser;","_cred","Lorg/mortbay/jetty/security/Credential;"));
                DexLabel L1=new DexLabel();
                code.visitJumpStmt(IF_EQZ,0,-1,L1);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/security/HashUserRealm$KnownUser;","_cred","Lorg/mortbay/jetty/security/Credential;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,2},new Method("Lorg/mortbay/jetty/security/Credential;","check",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_EQZ,0,-1,L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                DexLabel L2=new DexLabel();
                code.visitLabel(L2);
                code.visitStmt1R(RETURN,0);
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m002_getName(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/security/HashUserRealm$KnownUser;","getName",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(497,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/security/HashUserRealm$KnownUser;","_userName","Ljava/lang/String;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m003_isAuthenticated(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/security/HashUserRealm$KnownUser;","isAuthenticated",new String[]{ },"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(503,L0);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
