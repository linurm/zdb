package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0351_org_mortbay_jetty_servlet_SessionHandler {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(ACC_PUBLIC,"Lorg/mortbay/jetty/servlet/SessionHandler;","Lorg/mortbay/jetty/handler/HandlerWrapper;",new String[]{ });
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("SessionHandler.java");
        f000__sessionManager(cv);
        m000__init_(cv);
        m001__init_(cv);
        m002_addEventListener(cv);
        m003_clearEventListeners(cv);
        m004_doStart(cv);
        m005_doStop(cv);
        m006_getSessionManager(cv);
        m007_handle(cv);
        m008_setRequestedId(cv);
        m009_setServer(cv);
        m010_setSessionManager(cv);
    }
    public static void f000__sessionManager(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/servlet/SessionHandler;","_sessionManager","Lorg/mortbay/jetty/SessionManager;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void m000__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/jetty/servlet/SessionHandler;","<init>",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(53,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(54,L1);
                code.visitLabel(L0);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Lorg/mortbay/jetty/servlet/HashSessionManager;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Lorg/mortbay/jetty/servlet/HashSessionManager;","<init>",new String[]{ },"V"));
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1,0},new Method("Lorg/mortbay/jetty/servlet/SessionHandler;","<init>",new String[]{ "Lorg/mortbay/jetty/SessionManager;"},"V"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/jetty/servlet/SessionHandler;","<init>",new String[]{ "Lorg/mortbay/jetty/SessionManager;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"manager");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(61,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(62,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(63,L2);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Lorg/mortbay/jetty/handler/HandlerWrapper;","<init>",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Lorg/mortbay/jetty/servlet/SessionHandler;","setSessionManager",new String[]{ "Lorg/mortbay/jetty/SessionManager;"},"V"));
                code.visitLabel(L2);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m002_addEventListener(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/servlet/SessionHandler;","addEventListener",new String[]{ "Ljava/util/EventListener;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"listener");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(278,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(279,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(280,L2);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/servlet/SessionHandler;","_sessionManager","Lorg/mortbay/jetty/SessionManager;"));
                code.visitJumpStmt(IF_EQZ,0,-1,L2);
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/servlet/SessionHandler;","_sessionManager","Lorg/mortbay/jetty/SessionManager;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,2},new Method("Lorg/mortbay/jetty/SessionManager;","addEventListener",new String[]{ "Ljava/util/EventListener;"},"V"));
                code.visitLabel(L2);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m003_clearEventListeners(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/servlet/SessionHandler;","clearEventListeners",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(285,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(286,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(287,L2);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/servlet/SessionHandler;","_sessionManager","Lorg/mortbay/jetty/SessionManager;"));
                code.visitJumpStmt(IF_EQZ,0,-1,L2);
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/servlet/SessionHandler;","_sessionManager","Lorg/mortbay/jetty/SessionManager;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0},new Method("Lorg/mortbay/jetty/SessionManager;","clearEventListeners",new String[]{ },"V"));
                code.visitLabel(L2);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m004_doStart(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Lorg/mortbay/jetty/servlet/SessionHandler;","doStart",new String[]{ },"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/lang/Exception;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(115,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(116,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(117,L2);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/servlet/SessionHandler;","_sessionManager","Lorg/mortbay/jetty/SessionManager;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0},new Method("Lorg/mortbay/jetty/SessionManager;","start",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_SUPER,new int[]{ 1},new Method("Lorg/mortbay/jetty/handler/HandlerWrapper;","doStart",new String[]{ },"V"));
                code.visitLabel(L2);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m005_doStop(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Lorg/mortbay/jetty/servlet/SessionHandler;","doStop",new String[]{ },"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/lang/Exception;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(124,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(125,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(126,L2);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_SUPER,new int[]{ 1},new Method("Lorg/mortbay/jetty/handler/HandlerWrapper;","doStop",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/servlet/SessionHandler;","_sessionManager","Lorg/mortbay/jetty/SessionManager;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0},new Method("Lorg/mortbay/jetty/SessionManager;","stop",new String[]{ },"V"));
                code.visitLabel(L2);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m006_getSessionManager(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/servlet/SessionHandler;","getSessionManager",new String[]{ },"Lorg/mortbay/jetty/SessionManager;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(71,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/servlet/SessionHandler;","_sessionManager","Lorg/mortbay/jetty/SessionManager;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m007_handle(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/servlet/SessionHandler;","handle",new String[]{ "Ljava/lang/String;","Ljavax/servlet/http/HttpServletRequest;","Ljavax/servlet/http/HttpServletResponse;","I"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visit(null, new DexType("Ljavax/servlet/ServletException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(15);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                DexLabel L3=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2,L3},new String[]{ "Lorg/mortbay/jetty/RetryRequest;",null});
                DexLabel L4=new DexLabel();
                DexLabel L5=new DexLabel();
                code.visitTryCatch(L4,L5,new DexLabel[]{L2,L3},new String[]{ "Lorg/mortbay/jetty/RetryRequest;",null});
                DexLabel L6=new DexLabel();
                code.visitTryCatch(L6,L3,new DexLabel[]{L3},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"target");
                ddv.visitParameterName(1,"request");
                ddv.visitParameterName(2,"response");
                ddv.visitParameterName(3,"dispatch");
                DexLabel L7=new DexLabel();
                ddv.visitPrologue(L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(135,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(137,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(138,L10);
                ddv.visitStartLocal(1,L10,"base_request","Lorg/mortbay/jetty/Request;",null);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(139,L11);
                ddv.visitStartLocal(4,L11,"old_session_manager","Lorg/mortbay/jetty/SessionManager;",null);
                ddv.visitLineNumber(143,L0);
                ddv.visitStartLocal(3,L0,"old_session","Ljavax/servlet/http/HttpSession;",null);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(144,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(146,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(149,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(150,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(154,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(155,L17);
                ddv.visitStartLocal(6,L17,"session","Ljavax/servlet/http/HttpSession;",null);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(157,L18);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(158,L19);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(160,L20);
                DexLabel L21=new DexLabel();
                ddv.visitLineNumber(162,L21);
                DexLabel L22=new DexLabel();
                ddv.visitLineNumber(163,L22);
                ddv.visitStartLocal(2,L22,"cookie","Ljavax/servlet/http/Cookie;",null);
                DexLabel L23=new DexLabel();
                ddv.visitLineNumber(164,L23);
                DexLabel L24=new DexLabel();
                ddv.visitLineNumber(175,L24);
                ddv.visitEndLocal(2,L24);
                DexLabel L25=new DexLabel();
                ddv.visitLineNumber(177,L25);
                DexLabel L26=new DexLabel();
                ddv.visitLineNumber(178,L26);
                DexLabel L27=new DexLabel();
                ddv.visitLineNumber(181,L27);
                ddv.visitLineNumber(192,L1);
                DexLabel L28=new DexLabel();
                ddv.visitLineNumber(194,L28);
                ddv.visitRestartLocal(6,L28);
                DexLabel L29=new DexLabel();
                ddv.visitLineNumber(197,L29);
                DexLabel L30=new DexLabel();
                ddv.visitLineNumber(198,L30);
                DexLabel L31=new DexLabel();
                ddv.visitLineNumber(199,L31);
                DexLabel L32=new DexLabel();
                ddv.visitLineNumber(200,L32);
                DexLabel L33=new DexLabel();
                ddv.visitLineNumber(203,L33);
                DexLabel L34=new DexLabel();
                ddv.visitLineNumber(137,L34);
                ddv.visitEndLocal(1,L34);
                ddv.visitEndLocal(4,L34);
                ddv.visitEndLocal(3,L34);
                ddv.visitEndLocal(6,L34);
                ddv.visitLineNumber(169,L4);
                ddv.visitRestartLocal(1,L4);
                ddv.visitRestartLocal(3,L4);
                ddv.visitRestartLocal(4,L4);
                ddv.visitRestartLocal(6,L4);
                DexLabel L35=new DexLabel();
                ddv.visitLineNumber(170,L35);
                ddv.visitRestartLocal(6,L35);
                DexLabel L36=new DexLabel();
                ddv.visitLineNumber(171,L36);
                ddv.visitLineNumber(183,L2);
                ddv.visitEndLocal(6,L2);
                DexLabel L37=new DexLabel();
                ddv.visitLineNumber(185,L37);
                ddv.visitStartLocal(5,L37,"r","Lorg/mortbay/jetty/RetryRequest;",null);
                DexLabel L38=new DexLabel();
                ddv.visitLineNumber(186,L38);
                ddv.visitRestartLocal(6,L38);
                DexLabel L39=new DexLabel();
                ddv.visitLineNumber(187,L39);
                DexLabel L40=new DexLabel();
                ddv.visitLineNumber(188,L40);
                ddv.visitLineNumber(192,L3);
                ddv.visitEndLocal(5,L3);
                ddv.visitEndLocal(6,L3);
                DexLabel L41=new DexLabel();
                ddv.visitLineNumber(194,L41);
                ddv.visitRestartLocal(6,L41);
                DexLabel L42=new DexLabel();
                ddv.visitLineNumber(197,L42);
                DexLabel L43=new DexLabel();
                ddv.visitLineNumber(198,L43);
                DexLabel L44=new DexLabel();
                ddv.visitLineNumber(199,L44);
                DexLabel L45=new DexLabel();
                ddv.visitLineNumber(200,L45);
                DexLabel L46=new DexLabel();
                ddv.visitLineNumber(192,L46);
                code.visitLabel(L7);
                code.visitConstStmt(CONST_4,9, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L8);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10,12,14},new Method("Lorg/mortbay/jetty/servlet/SessionHandler;","setRequestedId",new String[]{ "Ljavax/servlet/http/HttpServletRequest;","I"},"V"));
                code.visitLabel(L9);
                code.visitTypeStmt(INSTANCE_OF,7,12,"Lorg/mortbay/jetty/Request;");
                code.visitJumpStmt(IF_EQZ,7,-1,L34);
                code.visitStmt2R(MOVE_OBJECT,0,12);
                code.visitTypeStmt(CHECK_CAST,0,-1,"Lorg/mortbay/jetty/Request;");
                code.visitStmt2R(MOVE_OBJECT,7,0);
                code.visitStmt2R(MOVE_OBJECT,1,7);
                code.visitLabel(L10);
                code.visitConstStmt(CONST_4,4, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L11);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Lorg/mortbay/jetty/Request;","getSessionManager",new String[]{ },"Lorg/mortbay/jetty/SessionManager;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitLabel(L12);
                code.visitConstStmt(CONST_4,7, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,7},new Method("Lorg/mortbay/jetty/Request;","getSession",new String[]{ "Z"},"Ljavax/servlet/http/HttpSession;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitLabel(L13);
                code.visitFieldStmt(IGET_OBJECT,7,10,new Field("Lorg/mortbay/jetty/servlet/SessionHandler;","_sessionManager","Lorg/mortbay/jetty/SessionManager;"));
                code.visitJumpStmt(IF_EQ,4,7,L16);
                code.visitLabel(L14);
                code.visitFieldStmt(IGET_OBJECT,7,10,new Field("Lorg/mortbay/jetty/servlet/SessionHandler;","_sessionManager","Lorg/mortbay/jetty/SessionManager;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,7},new Method("Lorg/mortbay/jetty/Request;","setSessionManager",new String[]{ "Lorg/mortbay/jetty/SessionManager;"},"V"));
                code.visitLabel(L15);
                code.visitConstStmt(CONST_4,7, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,7},new Method("Lorg/mortbay/jetty/Request;","setSession",new String[]{ "Ljavax/servlet/http/HttpSession;"},"V"));
                code.visitLabel(L16);
                code.visitConstStmt(CONST_4,6, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L17);
                code.visitFieldStmt(IGET_OBJECT,7,10,new Field("Lorg/mortbay/jetty/servlet/SessionHandler;","_sessionManager","Lorg/mortbay/jetty/SessionManager;"));
                code.visitJumpStmt(IF_EQZ,7,-1,L24);
                code.visitLabel(L18);
                code.visitConstStmt(CONST_4,7, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,7},new Method("Lorg/mortbay/jetty/Request;","getSession",new String[]{ "Z"},"Ljavax/servlet/http/HttpSession;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitLabel(L19);
                code.visitJumpStmt(IF_EQZ,6,-1,L4);
                code.visitLabel(L20);
                code.visitJumpStmt(IF_EQ,6,3,L24);
                code.visitLabel(L21);
                code.visitFieldStmt(IGET_OBJECT,7,10,new Field("Lorg/mortbay/jetty/servlet/SessionHandler;","_sessionManager","Lorg/mortbay/jetty/SessionManager;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 12},new Method("Ljavax/servlet/http/HttpServletRequest;","isSecure",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,8);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 7,6,8},new Method("Lorg/mortbay/jetty/SessionManager;","access",new String[]{ "Ljavax/servlet/http/HttpSession;","Z"},"Ljavax/servlet/http/Cookie;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitLabel(L22);
                code.visitJumpStmt(IF_EQZ,2,-1,L24);
                code.visitLabel(L23);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 13,2},new Method("Ljavax/servlet/http/HttpServletResponse;","addCookie",new String[]{ "Ljavax/servlet/http/Cookie;"},"V"));
                code.visitLabel(L24);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Lorg/mortbay/log/Log;","isDebugEnabled",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,7);
                code.visitJumpStmt(IF_EQZ,7,-1,L27);
                code.visitLabel(L25);
                code.visitTypeStmt(NEW_INSTANCE,7,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 7},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,8,"sessionManager=");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7,8},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitFieldStmt(IGET_OBJECT,8,10,new Field("Lorg/mortbay/jetty/servlet/SessionHandler;","_sessionManager","Lorg/mortbay/jetty/SessionManager;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7,8},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 7},new Method("Lorg/mortbay/log/Log;","debug",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L26);
                code.visitTypeStmt(NEW_INSTANCE,7,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 7},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,8,"session=");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7,8},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7,6},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 7},new Method("Lorg/mortbay/log/Log;","debug",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L27);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10},new Method("Lorg/mortbay/jetty/servlet/SessionHandler;","getHandler",new String[]{ },"Lorg/mortbay/jetty/Handler;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 7,11,12,13,14},new Method("Lorg/mortbay/jetty/Handler;","handle",new String[]{ "Ljava/lang/String;","Ljavax/servlet/http/HttpServletRequest;","Ljavax/servlet/http/HttpServletResponse;","I"},"V"));
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 12,9},new Method("Ljavax/servlet/http/HttpServletRequest;","getSession",new String[]{ "Z"},"Ljavax/servlet/http/HttpSession;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitLabel(L28);
                code.visitFieldStmt(IGET_OBJECT,7,10,new Field("Lorg/mortbay/jetty/servlet/SessionHandler;","_sessionManager","Lorg/mortbay/jetty/SessionManager;"));
                code.visitJumpStmt(IF_EQ,4,7,L33);
                code.visitLabel(L29);
                code.visitJumpStmt(IF_EQZ,6,-1,L31);
                code.visitLabel(L30);
                code.visitFieldStmt(IGET_OBJECT,7,10,new Field("Lorg/mortbay/jetty/servlet/SessionHandler;","_sessionManager","Lorg/mortbay/jetty/SessionManager;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 7,6},new Method("Lorg/mortbay/jetty/SessionManager;","complete",new String[]{ "Ljavax/servlet/http/HttpSession;"},"V"));
                code.visitLabel(L31);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,4},new Method("Lorg/mortbay/jetty/Request;","setSessionManager",new String[]{ "Lorg/mortbay/jetty/SessionManager;"},"V"));
                code.visitLabel(L32);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,3},new Method("Lorg/mortbay/jetty/Request;","setSession",new String[]{ "Ljavax/servlet/http/HttpSession;"},"V"));
                code.visitLabel(L33);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L34);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Lorg/mortbay/jetty/HttpConnection;","getCurrentConnection",new String[]{ },"Lorg/mortbay/jetty/HttpConnection;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7},new Method("Lorg/mortbay/jetty/HttpConnection;","getRequest",new String[]{ },"Lorg/mortbay/jetty/Request;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitStmt2R(MOVE_OBJECT,1,7);
                code.visitJumpStmt(GOTO_16,-1,-1,L10);
                code.visitLabel(L4);
                code.visitFieldStmt(IGET_OBJECT,7,10,new Field("Lorg/mortbay/jetty/servlet/SessionHandler;","_sessionManager","Lorg/mortbay/jetty/SessionManager;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,7},new Method("Lorg/mortbay/jetty/Request;","recoverNewSession",new String[]{ "Ljava/lang/Object;"},"Ljavax/servlet/http/HttpSession;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitLabel(L35);
                code.visitJumpStmt(IF_EQZ,6,-1,L24);
                code.visitLabel(L36);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,6},new Method("Lorg/mortbay/jetty/Request;","setSession",new String[]{ "Ljavax/servlet/http/HttpSession;"},"V"));
                code.visitLabel(L5);
                code.visitJumpStmt(GOTO,-1,-1,L24);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,7);
                code.visitStmt2R(MOVE_OBJECT,5,7);
                code.visitLabel(L37);
                code.visitConstStmt(CONST_4,7, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,7},new Method("Lorg/mortbay/jetty/Request;","getSession",new String[]{ "Z"},"Ljavax/servlet/http/HttpSession;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitLabel(L38);
                code.visitJumpStmt(IF_EQZ,6,-1,L40);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 6},new Method("Ljavax/servlet/http/HttpSession;","isNew",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,7);
                code.visitJumpStmt(IF_EQZ,7,-1,L40);
                code.visitLabel(L39);
                code.visitFieldStmt(IGET_OBJECT,7,10,new Field("Lorg/mortbay/jetty/servlet/SessionHandler;","_sessionManager","Lorg/mortbay/jetty/SessionManager;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,7,6},new Method("Lorg/mortbay/jetty/Request;","saveNewSession",new String[]{ "Ljava/lang/Object;","Ljavax/servlet/http/HttpSession;"},"V"));
                code.visitLabel(L40);
                code.visitStmt1R(THROW,5);
                code.visitLabel(L3);
                code.visitStmt1R(MOVE_EXCEPTION,7);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 12,9},new Method("Ljavax/servlet/http/HttpServletRequest;","getSession",new String[]{ "Z"},"Ljavax/servlet/http/HttpSession;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitLabel(L41);
                code.visitFieldStmt(IGET_OBJECT,8,10,new Field("Lorg/mortbay/jetty/servlet/SessionHandler;","_sessionManager","Lorg/mortbay/jetty/SessionManager;"));
                code.visitJumpStmt(IF_EQ,4,8,L46);
                code.visitLabel(L42);
                code.visitJumpStmt(IF_EQZ,6,-1,L44);
                code.visitLabel(L43);
                code.visitFieldStmt(IGET_OBJECT,8,10,new Field("Lorg/mortbay/jetty/servlet/SessionHandler;","_sessionManager","Lorg/mortbay/jetty/SessionManager;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 8,6},new Method("Lorg/mortbay/jetty/SessionManager;","complete",new String[]{ "Ljavax/servlet/http/HttpSession;"},"V"));
                code.visitLabel(L44);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,4},new Method("Lorg/mortbay/jetty/Request;","setSessionManager",new String[]{ "Lorg/mortbay/jetty/SessionManager;"},"V"));
                code.visitLabel(L45);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,3},new Method("Lorg/mortbay/jetty/Request;","setSession",new String[]{ "Ljavax/servlet/http/HttpSession;"},"V"));
                code.visitLabel(L46);
                code.visitStmt1R(THROW,7);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m008_setRequestedId(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Lorg/mortbay/jetty/servlet/SessionHandler;","setRequestedId",new String[]{ "Ljavax/servlet/http/HttpServletRequest;","I"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(16);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"request");
                ddv.visitParameterName(1,"dispatch");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(212,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(213,L1);
                ddv.visitStartLocal(1,L1,"base_request","Lorg/mortbay/jetty/Request;",null);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(214,L2);
                ddv.visitStartLocal(6,L2,"requested_session_id","Ljava/lang/String;",null);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(270,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(212,L4);
                ddv.visitEndLocal(1,L4);
                ddv.visitEndLocal(6,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(219,L5);
                ddv.visitRestartLocal(1,L5);
                ddv.visitRestartLocal(6,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(220,L6);
                ddv.visitStartLocal(9,L6,"sessionManager","Lorg/mortbay/jetty/SessionManager;",null);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(223,L7);
                ddv.visitStartLocal(7,L7,"requested_session_id_from_cookie","Z",null);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(225,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(226,L9);
                ddv.visitStartLocal(2,L9,"cookies","[Ljavax/servlet/http/Cookie;",null);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(228,L10);
                DexLabel L11=new DexLabel();
                ddv.visitStartLocal(3,L11,"i","I",null);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(230,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(232,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(237,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(249,L15);
                ddv.visitEndLocal(2,L15);
                ddv.visitEndLocal(3,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(251,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(253,L17);
                ddv.visitStartLocal(10,L17,"uri","Ljava/lang/String;",null);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(254,L18);
                ddv.visitStartLocal(8,L18,"semi","I",null);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(256,L19);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(259,L20);
                ddv.visitStartLocal(5,L20,"path_params","Ljava/lang/String;",null);
                DexLabel L21=new DexLabel();
                ddv.visitLineNumber(260,L21);
                ddv.visitStartLocal(4,L21,"param","Ljava/lang/String;",null);
                DexLabel L22=new DexLabel();
                ddv.visitLineNumber(262,L22);
                DexLabel L23=new DexLabel();
                ddv.visitLineNumber(263,L23);
                ddv.visitRestartLocal(6,L23);
                DexLabel L24=new DexLabel();
                ddv.visitLineNumber(268,L24);
                ddv.visitEndLocal(10,L24);
                ddv.visitEndLocal(8,L24);
                ddv.visitEndLocal(5,L24);
                ddv.visitEndLocal(4,L24);
                DexLabel L25=new DexLabel();
                ddv.visitLineNumber(269,L25);
                DexLabel L26=new DexLabel();
                ddv.visitLineNumber(241,L26);
                ddv.visitRestartLocal(2,L26);
                ddv.visitRestartLocal(3,L26);
                DexLabel L27=new DexLabel();
                ddv.visitLineNumber(242,L27);
                ddv.visitRestartLocal(6,L27);
                DexLabel L28=new DexLabel();
                ddv.visitLineNumber(243,L28);
                DexLabel L29=new DexLabel();
                ddv.visitLineNumber(228,L29);
                DexLabel L30=new DexLabel();
                ddv.visitLineNumber(269,L30);
                ddv.visitEndLocal(2,L30);
                ddv.visitEndLocal(3,L30);
                code.visitLabel(L0);
                code.visitTypeStmt(INSTANCE_OF,11,14,"Lorg/mortbay/jetty/Request;");
                code.visitJumpStmt(IF_EQZ,11,-1,L4);
                code.visitStmt2R(MOVE_OBJECT,0,14);
                code.visitTypeStmt(CHECK_CAST,0,-1,"Lorg/mortbay/jetty/Request;");
                code.visitStmt2R(MOVE_OBJECT,1,0);
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 14},new Method("Ljavax/servlet/http/HttpServletRequest;","getRequestedSessionId",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitLabel(L2);
                code.visitConstStmt(CONST_4,11, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitJumpStmt(IF_NE,15,11,L3);
                code.visitJumpStmt(IF_EQZ,6,-1,L5);
                code.visitLabel(L3);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L4);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Lorg/mortbay/jetty/HttpConnection;","getCurrentConnection",new String[]{ },"Lorg/mortbay/jetty/HttpConnection;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,11);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 11},new Method("Lorg/mortbay/jetty/HttpConnection;","getRequest",new String[]{ },"Lorg/mortbay/jetty/Request;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,11);
                code.visitStmt2R(MOVE_OBJECT,1,11);
                code.visitJumpStmt(GOTO,-1,-1,L1);
                code.visitLabel(L5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 13},new Method("Lorg/mortbay/jetty/servlet/SessionHandler;","getSessionManager",new String[]{ },"Lorg/mortbay/jetty/SessionManager;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,9);
                code.visitLabel(L6);
                code.visitConstStmt(CONST_4,7, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L7);
                code.visitFieldStmt(IGET_OBJECT,11,13,new Field("Lorg/mortbay/jetty/servlet/SessionHandler;","_sessionManager","Lorg/mortbay/jetty/SessionManager;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 11},new Method("Lorg/mortbay/jetty/SessionManager;","isUsingCookies",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,11);
                code.visitJumpStmt(IF_EQZ,11,-1,L15);
                code.visitLabel(L8);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 14},new Method("Ljavax/servlet/http/HttpServletRequest;","getCookies",new String[]{ },"[Ljavax/servlet/http/Cookie;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitLabel(L9);
                code.visitJumpStmt(IF_EQZ,2,-1,L15);
                code.visitStmt2R(ARRAY_LENGTH,11,2);
                code.visitJumpStmt(IF_LEZ,11,-1,L15);
                code.visitLabel(L10);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L11);
                code.visitStmt2R(ARRAY_LENGTH,11,2);
                code.visitJumpStmt(IF_GE,3,11,L15);
                code.visitLabel(L12);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 9},new Method("Lorg/mortbay/jetty/SessionManager;","getSessionCookie",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,11);
                code.visitStmt3R(AGET_OBJECT,12,2,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 12},new Method("Ljavax/servlet/http/Cookie;","getName",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,12);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 11,12},new Method("Ljava/lang/String;","equalsIgnoreCase",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,11);
                code.visitJumpStmt(IF_EQZ,11,-1,L29);
                code.visitLabel(L13);
                code.visitJumpStmt(IF_EQZ,6,-1,L26);
                code.visitLabel(L14);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 9,6},new Method("Lorg/mortbay/jetty/SessionManager;","getHttpSession",new String[]{ "Ljava/lang/String;"},"Ljavax/servlet/http/HttpSession;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,11);
                code.visitJumpStmt(IF_EQZ,11,-1,L26);
                code.visitLabel(L15);
                code.visitJumpStmt(IF_NEZ,6,-1,L24);
                code.visitLabel(L16);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 14},new Method("Ljavax/servlet/http/HttpServletRequest;","getRequestURI",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,10);
                code.visitLabel(L17);
                code.visitConstStmt(CONST_16,11, Integer.valueOf(59)); // int: 0x0000003b  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10,11},new Method("Ljava/lang/String;","lastIndexOf",new String[]{ "I"},"I"));
                code.visitStmt1R(MOVE_RESULT,8);
                code.visitLabel(L18);
                code.visitJumpStmt(IF_LTZ,8,-1,L24);
                code.visitLabel(L19);
                code.visitStmt2R1N(ADD_INT_LIT8,11,8,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10,11},new Method("Ljava/lang/String;","substring",new String[]{ "I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitLabel(L20);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 9},new Method("Lorg/mortbay/jetty/SessionManager;","getSessionURL",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitLabel(L21);
                code.visitJumpStmt(IF_EQZ,4,-1,L24);
                code.visitJumpStmt(IF_EQZ,5,-1,L24);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,4},new Method("Ljava/lang/String;","startsWith",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,11);
                code.visitJumpStmt(IF_EQZ,11,-1,L24);
                code.visitLabel(L22);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 9},new Method("Lorg/mortbay/jetty/SessionManager;","getSessionURL",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,11);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 11},new Method("Ljava/lang/String;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,11);
                code.visitStmt2R1N(ADD_INT_LIT8,11,11,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,11},new Method("Ljava/lang/String;","substring",new String[]{ "I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitLabel(L23);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Lorg/mortbay/log/Log;","isDebugEnabled",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,11);
                code.visitJumpStmt(IF_EQZ,11,-1,L24);
                code.visitTypeStmt(NEW_INSTANCE,11,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 11},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,12,"Got Session ID ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 11,12},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,11);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 11,6},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,11);
                code.visitConstStmt(CONST_STRING,12," from URL");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 11,12},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,11);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 11},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,11);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 11},new Method("Lorg/mortbay/log/Log;","debug",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L24);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,6},new Method("Lorg/mortbay/jetty/Request;","setRequestedSessionId",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L25);
                code.visitJumpStmt(IF_EQZ,6,-1,L30);
                code.visitJumpStmt(IF_EQZ,7,-1,L30);
                code.visitConstStmt(CONST_4,11, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                DexLabel L31=new DexLabel();
                code.visitLabel(L31);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,11},new Method("Lorg/mortbay/jetty/Request;","setRequestedSessionIdFromCookie",new String[]{ "Z"},"V"));
                code.visitJumpStmt(GOTO_16,-1,-1,L3);
                code.visitLabel(L26);
                code.visitStmt3R(AGET_OBJECT,11,2,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 11},new Method("Ljavax/servlet/http/Cookie;","getValue",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitLabel(L27);
                code.visitConstStmt(CONST_4,7, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitLabel(L28);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Lorg/mortbay/log/Log;","isDebugEnabled",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,11);
                code.visitJumpStmt(IF_EQZ,11,-1,L29);
                code.visitTypeStmt(NEW_INSTANCE,11,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 11},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,12,"Got Session ID ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 11,12},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,11);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 11,6},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,11);
                code.visitConstStmt(CONST_STRING,12," from cookie");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 11,12},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,11);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 11},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,11);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 11},new Method("Lorg/mortbay/log/Log;","debug",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L29);
                code.visitStmt2R1N(ADD_INT_LIT8,3,3,1);
                code.visitJumpStmt(GOTO_16,-1,-1,L11);
                code.visitLabel(L30);
                code.visitConstStmt(CONST_4,11, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L31);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m009_setServer(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/servlet/SessionHandler;","setServer",new String[]{ "Lorg/mortbay/jetty/Server;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(15);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"server");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(100,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(101,L2);
                ddv.visitStartLocal(12,L2,"old_server","Lorg/mortbay/jetty/Server;",null);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(102,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(103,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(104,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(105,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(106,L7);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitConstStmt(CONST_4,5, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitConstStmt(CONST_STRING,4,"sessionManager");
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 13},new Method("Lorg/mortbay/jetty/servlet/SessionHandler;","getServer",new String[]{ },"Lorg/mortbay/jetty/Server;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,12);
                code.visitLabel(L2);
                code.visitJumpStmt(IF_EQZ,12,-1,L4);
                code.visitJumpStmt(IF_EQ,12,14,L4);
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 12},new Method("Lorg/mortbay/jetty/Server;","getContainer",new String[]{ },"Lorg/mortbay/component/Container;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(IGET_OBJECT,2,13,new Field("Lorg/mortbay/jetty/servlet/SessionHandler;","_sessionManager","Lorg/mortbay/jetty/SessionManager;"));
                code.visitConstStmt(CONST_STRING,1,"sessionManager");
                code.visitStmt2R(MOVE_OBJECT,1,13);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 0,1,2,3,4,5},new Method("Lorg/mortbay/component/Container;","update",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;","Ljava/lang/Object;","Ljava/lang/String;","Z"},"V"));
                code.visitLabel(L4);
                code.visitMethodStmt(INVOKE_SUPER,new int[]{ 13,14},new Method("Lorg/mortbay/jetty/handler/HandlerWrapper;","setServer",new String[]{ "Lorg/mortbay/jetty/Server;"},"V"));
                code.visitLabel(L5);
                code.visitJumpStmt(IF_EQZ,14,-1,L7);
                code.visitJumpStmt(IF_EQ,14,12,L7);
                code.visitLabel(L6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 14},new Method("Lorg/mortbay/jetty/Server;","getContainer",new String[]{ },"Lorg/mortbay/component/Container;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitFieldStmt(IGET_OBJECT,9,13,new Field("Lorg/mortbay/jetty/servlet/SessionHandler;","_sessionManager","Lorg/mortbay/jetty/SessionManager;"));
                code.visitConstStmt(CONST_STRING,0,"sessionManager");
                code.visitStmt2R(MOVE_OBJECT,7,13);
                code.visitStmt2R(MOVE_OBJECT,8,3);
                code.visitStmt2R(MOVE_OBJECT,10,4);
                code.visitStmt2R(MOVE,11,5);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 6,7,8,9,10,11},new Method("Lorg/mortbay/component/Container;","update",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;","Ljava/lang/Object;","Ljava/lang/String;","Z"},"V"));
                code.visitLabel(L7);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m010_setSessionManager(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/servlet/SessionHandler;","setSessionManager",new String[]{ "Lorg/mortbay/jetty/SessionManager;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(8);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"sessionManager");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(80,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(81,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(82,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(84,L3);
                ddv.visitStartLocal(2,L3,"old_session_manager","Lorg/mortbay/jetty/SessionManager;",null);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(85,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(87,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(88,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(90,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(92,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(93,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(94,L10);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Lorg/mortbay/jetty/servlet/SessionHandler;","isStarted",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_EQZ,0,-1,L2);
                code.visitLabel(L1);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/lang/IllegalStateException;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/lang/IllegalStateException;","<init>",new String[]{ },"V"));
                code.visitStmt1R(THROW,0);
                code.visitLabel(L2);
                code.visitFieldStmt(IGET_OBJECT,2,6,new Field("Lorg/mortbay/jetty/servlet/SessionHandler;","_sessionManager","Lorg/mortbay/jetty/SessionManager;"));
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Lorg/mortbay/jetty/servlet/SessionHandler;","getServer",new String[]{ },"Lorg/mortbay/jetty/Server;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitJumpStmt(IF_EQZ,0,-1,L5);
                code.visitLabel(L4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Lorg/mortbay/jetty/servlet/SessionHandler;","getServer",new String[]{ },"Lorg/mortbay/jetty/Server;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/jetty/Server;","getContainer",new String[]{ },"Lorg/mortbay/component/Container;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitConstStmt(CONST_STRING,4,"sessionManager");
                code.visitConstStmt(CONST_4,5, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitStmt2R(MOVE_OBJECT,1,6);
                code.visitStmt2R(MOVE_OBJECT,3,7);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 0,1,2,3,4,5},new Method("Lorg/mortbay/component/Container;","update",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;","Ljava/lang/Object;","Ljava/lang/String;","Z"},"V"));
                code.visitLabel(L5);
                code.visitJumpStmt(IF_EQZ,7,-1,L7);
                code.visitLabel(L6);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 7,6},new Method("Lorg/mortbay/jetty/SessionManager;","setSessionHandler",new String[]{ "Lorg/mortbay/jetty/servlet/SessionHandler;"},"V"));
                code.visitLabel(L7);
                code.visitFieldStmt(IPUT_OBJECT,7,6,new Field("Lorg/mortbay/jetty/servlet/SessionHandler;","_sessionManager","Lorg/mortbay/jetty/SessionManager;"));
                code.visitLabel(L8);
                code.visitJumpStmt(IF_EQZ,2,-1,L10);
                code.visitLabel(L9);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 2,0},new Method("Lorg/mortbay/jetty/SessionManager;","setSessionHandler",new String[]{ "Lorg/mortbay/jetty/servlet/SessionHandler;"},"V"));
                code.visitLabel(L10);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
