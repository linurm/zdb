package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0294_org_mortbay_jetty_security_UserRealm {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(ACC_PUBLIC|ACC_INTERFACE|ACC_ABSTRACT,"Lorg/mortbay/jetty/security/UserRealm;","Ljava/lang/Object;",new String[]{ });
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("UserRealm.java");
        m000_authenticate(cv);
        m001_disassociate(cv);
        m002_getName(cv);
        m003_getPrincipal(cv);
        m004_isUserInRole(cv);
        m005_logout(cv);
        m006_popRole(cv);
        m007_pushRole(cv);
        m008_reauthenticate(cv);
    }
    public static void m000_authenticate(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Lorg/mortbay/jetty/security/UserRealm;","authenticate",new String[]{ "Ljava/lang/String;","Ljava/lang/Object;","Lorg/mortbay/jetty/Request;"},"Ljava/security/Principal;"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m001_disassociate(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Lorg/mortbay/jetty/security/UserRealm;","disassociate",new String[]{ "Ljava/security/Principal;"},"V"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m002_getName(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Lorg/mortbay/jetty/security/UserRealm;","getName",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m003_getPrincipal(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Lorg/mortbay/jetty/security/UserRealm;","getPrincipal",new String[]{ "Ljava/lang/String;"},"Ljava/security/Principal;"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m004_isUserInRole(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Lorg/mortbay/jetty/security/UserRealm;","isUserInRole",new String[]{ "Ljava/security/Principal;","Ljava/lang/String;"},"Z"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m005_logout(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Lorg/mortbay/jetty/security/UserRealm;","logout",new String[]{ "Ljava/security/Principal;"},"V"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m006_popRole(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Lorg/mortbay/jetty/security/UserRealm;","popRole",new String[]{ "Ljava/security/Principal;"},"Ljava/security/Principal;"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m007_pushRole(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Lorg/mortbay/jetty/security/UserRealm;","pushRole",new String[]{ "Ljava/security/Principal;","Ljava/lang/String;"},"Ljava/security/Principal;"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m008_reauthenticate(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Lorg/mortbay/jetty/security/UserRealm;","reauthenticate",new String[]{ "Ljava/security/Principal;"},"Z"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
}
