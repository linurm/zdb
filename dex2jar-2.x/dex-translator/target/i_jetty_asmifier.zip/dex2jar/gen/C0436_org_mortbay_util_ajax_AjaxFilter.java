package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0436_org_mortbay_util_ajax_AjaxFilter {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(ACC_PUBLIC,"Lorg/mortbay/util/ajax/AjaxFilter;","Ljava/lang/Object;",new String[]{ "Ljavax/servlet/Filter;"});
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("AjaxFilter.java");
        if(cv!=null){
            DexAnnotationVisitor av00 = cv.visitAnnotation("Ldalvik/annotation/MemberClasses;", Visibility.SYSTEM);
            if(av00 != null) {
                {
                    DexAnnotationVisitor av01 = av00.visitArray("value");
                    if(av01 != null) {
                        av01.visit(null, new DexType("Lorg/mortbay/util/ajax/AjaxFilter$1;"));
                        av01.visit(null, new DexType("Lorg/mortbay/util/ajax/AjaxFilter$AjaxResponse;"));
                        av01.visitEnd();
                    }
                }
                av00.visitEnd();
            }
        }
        f000_context(cv);
        m000__init_(cv);
        m001_encodeText(cv);
        m002_destroy(cv);
        m003_doFilter(cv);
        m004_getContext(cv);
        m005_handle(cv);
        m006_init(cv);
    }
    public static void f000_context(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(0, new Field("Lorg/mortbay/util/ajax/AjaxFilter;","context","Ljavax/servlet/ServletContext;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void m000__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/util/ajax/AjaxFilter;","<init>",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(1);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(37,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(133,L1);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/lang/Object;","<init>",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001_encodeText(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Lorg/mortbay/util/ajax/AjaxFilter;","encodeText",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(6);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"s");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(103,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(104,L1);
                ddv.visitStartLocal(0,L1,"buf","Ljava/lang/StringBuffer;",null);
                DexLabel L2=new DexLabel();
                ddv.visitStartLocal(2,L2,"i","I",null);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(106,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(107,L4);
                ddv.visitStartLocal(1,L4,"c","C",null);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(108,L5);
                ddv.visitStartLocal(3,L5,"r","Ljava/lang/String;",null);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(115,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(117,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(119,L8);
                DexLabel L9=new DexLabel();
                ddv.visitEndLocal(0,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(120,L10);
                ddv.visitRestartLocal(0,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(122,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(104,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(110,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(111,L14);
                DexLabel L15=new DexLabel();
                ddv.visitRestartLocal(3,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(112,L16);
                DexLabel L17=new DexLabel();
                ddv.visitRestartLocal(3,L17);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(124,L18);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(125,L19);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(128,L20);
                ddv.visitEndLocal(1,L20);
                ddv.visitEndLocal(3,L20);
                DexLabel L21=new DexLabel();
                ddv.visitLineNumber(129,L21);
                DexLabel L22=new DexLabel();
                ddv.visitLineNumber(130,L22);
                DexLabel L23=new DexLabel();
                ddv.visitLineNumber(108,L23);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Ljava/lang/String;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,4);
                code.visitJumpStmt(IF_GE,2,4,L20);
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,2},new Method("Ljava/lang/String;","charAt",new String[]{ "I"},"C"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitLabel(L4);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L5);
                code.visitSparseSwitchStmt(SPARSE_SWITCH,1,new int[]{ 38,60,62},new DexLabel[]{L16,L13,L14});
                code.visitLabel(L6);
                code.visitJumpStmt(IF_EQZ,3,-1,L18);
                code.visitLabel(L7);
                code.visitJumpStmt(IF_NEZ,0,-1,L11);
                code.visitLabel(L8);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/lang/StringBuffer;");
                code.visitLabel(L9);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Ljava/lang/String;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,4);
                code.visitStmt2R1N(MUL_INT_LIT8,4,4,2);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,4},new Method("Ljava/lang/StringBuffer;","<init>",new String[]{ "I"},"V"));
                code.visitLabel(L10);
                code.visitConstStmt(CONST_4,4, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,4,2},new Method("Ljava/lang/String;","subSequence",new String[]{ "I","I"},"Ljava/lang/CharSequence;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,4},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "Ljava/lang/CharSequence;"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L11);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,3},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L12);
                code.visitStmt2R1N(ADD_INT_LIT8,2,2,1);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitLabel(L13);
                code.visitConstStmt(CONST_STRING,3,"&lt;");
                code.visitJumpStmt(GOTO,-1,-1,L6);
                code.visitLabel(L14);
                code.visitConstStmt(CONST_STRING,3,"&gt;");
                code.visitLabel(L15);
                code.visitJumpStmt(GOTO,-1,-1,L6);
                code.visitLabel(L16);
                code.visitConstStmt(CONST_STRING,3,"&amp;");
                code.visitLabel(L17);
                code.visitJumpStmt(GOTO,-1,-1,L6);
                code.visitLabel(L18);
                code.visitJumpStmt(IF_EQZ,0,-1,L12);
                code.visitLabel(L19);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "C"},"Ljava/lang/StringBuffer;"));
                code.visitJumpStmt(GOTO,-1,-1,L12);
                code.visitLabel(L20);
                DexLabel L24=new DexLabel();
                code.visitJumpStmt(IF_EQZ,0,-1,L24);
                code.visitLabel(L21);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/lang/StringBuffer;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitLabel(L22);
                code.visitStmt1R(RETURN_OBJECT,4);
                code.visitLabel(L24);
                code.visitStmt2R(MOVE_OBJECT,4,5);
                code.visitJumpStmt(GOTO,-1,-1,L22);
                code.visitLabel(L23);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m002_destroy(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/util/ajax/AjaxFilter;","destroy",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(98,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(99,L1);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/util/ajax/AjaxFilter;","context","Ljavax/servlet/ServletContext;"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m003_doFilter(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/util/ajax/AjaxFilter;","doFilter",new String[]{ "Ljavax/servlet/ServletRequest;","Ljavax/servlet/ServletResponse;","Ljavax/servlet/FilterChain;"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visit(null, new DexType("Ljavax/servlet/ServletException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(19);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"request");
                ddv.visitParameterName(1,"response");
                ddv.visitParameterName(2,"chain");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(58,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(59,L1);
                ddv.visitStartLocal(7,L1,"method","[Ljava/lang/String;",null);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(61,L2);
                ddv.visitStartLocal(6,L2,"message","[Ljava/lang/String;",null);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(63,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(64,L4);
                ddv.visitStartLocal(10,L4,"srequest","Ljavax/servlet/http/HttpServletRequest;",null);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(66,L5);
                ddv.visitStartLocal(11,L5,"sresponse","Ljavax/servlet/http/HttpServletResponse;",null);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(67,L6);
                ddv.visitStartLocal(9,L6,"sout","Ljava/io/StringWriter;",null);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(69,L7);
                ddv.visitStartLocal(8,L7,"out","Ljava/io/PrintWriter;",null);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(70,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(72,L9);
                ddv.visitStartLocal(3,L9,"aResponse","Lorg/mortbay/util/ajax/AjaxFilter$AjaxResponse;",null);
                DexLabel L10=new DexLabel();
                ddv.visitStartLocal(5,L10,"i","I",null);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(74,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(72,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(77,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(78,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(79,L15);
                ddv.visitStartLocal(4,L15,"ajax","[B",null);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(80,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(81,L17);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(82,L18);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(83,L19);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(84,L20);
                DexLabel L21=new DexLabel();
                ddv.visitLineNumber(85,L21);
                DexLabel L22=new DexLabel();
                ddv.visitLineNumber(89,L22);
                ddv.visitEndLocal(10,L22);
                ddv.visitEndLocal(11,L22);
                ddv.visitEndLocal(9,L22);
                ddv.visitEndLocal(8,L22);
                ddv.visitEndLocal(3,L22);
                ddv.visitEndLocal(5,L22);
                ddv.visitEndLocal(4,L22);
                DexLabel L23=new DexLabel();
                ddv.visitLineNumber(88,L23);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_STRING,12,"ajax");
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,16);
                code.visitStmt2R(MOVE_OBJECT,1,12);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,1},new Method("Ljavax/servlet/ServletRequest;","getParameterValues",new String[]{ "Ljava/lang/String;"},"[Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitLabel(L1);
                code.visitConstStmt(CONST_STRING,12,"message");
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,16);
                code.visitStmt2R(MOVE_OBJECT,1,12);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,1},new Method("Ljavax/servlet/ServletRequest;","getParameterValues",new String[]{ "Ljava/lang/String;"},"[Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitLabel(L2);
                code.visitJumpStmt(IF_EQZ,7,-1,L23);
                code.visitStmt2R(ARRAY_LENGTH,12,7);
                code.visitJumpStmt(IF_LEZ,12,-1,L23);
                code.visitLabel(L3);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,16);
                code.visitTypeStmt(CHECK_CAST,0,-1,"Ljavax/servlet/http/HttpServletRequest;");
                code.visitStmt2R(MOVE_OBJECT,10,0);
                code.visitLabel(L4);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,17);
                code.visitTypeStmt(CHECK_CAST,0,-1,"Ljavax/servlet/http/HttpServletResponse;");
                code.visitStmt2R(MOVE_OBJECT,11,0);
                code.visitLabel(L5);
                code.visitTypeStmt(NEW_INSTANCE,9,-1,"Ljava/io/StringWriter;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 9},new Method("Ljava/io/StringWriter;","<init>",new String[]{ },"V"));
                code.visitLabel(L6);
                code.visitTypeStmt(NEW_INSTANCE,8,-1,"Ljava/io/PrintWriter;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 8,9},new Method("Ljava/io/PrintWriter;","<init>",new String[]{ "Ljava/io/Writer;"},"V"));
                code.visitLabel(L7);
                code.visitConstStmt(CONST_STRING,12,"<ajax-response>");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8,12},new Method("Ljava/io/PrintWriter;","println",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L8);
                code.visitTypeStmt(NEW_INSTANCE,3,-1,"Lorg/mortbay/util/ajax/AjaxFilter$AjaxResponse;");
                code.visitConstStmt(CONST_4,12, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 3,10,8,12},new Method("Lorg/mortbay/util/ajax/AjaxFilter$AjaxResponse;","<init>",new String[]{ "Ljavax/servlet/http/HttpServletRequest;","Ljava/io/PrintWriter;","Lorg/mortbay/util/ajax/AjaxFilter$1;"},"V"));
                code.visitLabel(L9);
                code.visitConstStmt(CONST_4,5, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L10);
                code.visitStmt2R(ARRAY_LENGTH,12,7);
                code.visitJumpStmt(IF_GE,5,12,L13);
                code.visitLabel(L11);
                code.visitStmt3R(AGET_OBJECT,12,7,5);
                code.visitStmt3R(AGET_OBJECT,13,6,5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 15,12,13,10,3},new Method("Lorg/mortbay/util/ajax/AjaxFilter;","handle",new String[]{ "Ljava/lang/String;","Ljava/lang/String;","Ljavax/servlet/http/HttpServletRequest;","Lorg/mortbay/util/ajax/AjaxFilter$AjaxResponse;"},"V"));
                code.visitLabel(L12);
                code.visitStmt2R1N(ADD_INT_LIT8,5,5,1);
                code.visitJumpStmt(GOTO,-1,-1,L10);
                code.visitLabel(L13);
                code.visitConstStmt(CONST_STRING,12,"</ajax-response>");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8,12},new Method("Ljava/io/PrintWriter;","println",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L14);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9},new Method("Ljava/io/StringWriter;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,12);
                code.visitConstStmt(CONST_STRING,13,"UTF-8");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 12,13},new Method("Ljava/lang/String;","getBytes",new String[]{ "Ljava/lang/String;"},"[B"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitLabel(L15);
                code.visitConstStmt(CONST_STRING,12,"Pragma");
                code.visitConstStmt(CONST_STRING,13,"no-cache");
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 11,12,13},new Method("Ljavax/servlet/http/HttpServletResponse;","setHeader",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"V"));
                code.visitLabel(L16);
                code.visitConstStmt(CONST_STRING,12,"Cache-Control");
                code.visitConstStmt(CONST_STRING,13,"must-revalidate,no-cache,no-store");
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 11,12,13},new Method("Ljavax/servlet/http/HttpServletResponse;","addHeader",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"V"));
                code.visitLabel(L17);
                code.visitConstStmt(CONST_STRING,12,"Expires");
                code.visitConstStmt(CONST_WIDE_16,13,Long.valueOf(0L)); // long: 0x0000000000000000  double:0.000000
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 11,12,13,14},new Method("Ljavax/servlet/http/HttpServletResponse;","setDateHeader",new String[]{ "Ljava/lang/String;","J"},"V"));
                code.visitLabel(L18);
                code.visitConstStmt(CONST_STRING,12,"text/xml; charset=UTF-8");
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 11,12},new Method("Ljavax/servlet/http/HttpServletResponse;","setContentType",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L19);
                code.visitStmt2R(ARRAY_LENGTH,12,4);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 11,12},new Method("Ljavax/servlet/http/HttpServletResponse;","setContentLength",new String[]{ "I"},"V"));
                code.visitLabel(L20);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 11},new Method("Ljavax/servlet/http/HttpServletResponse;","getOutputStream",new String[]{ },"Ljavax/servlet/ServletOutputStream;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,12);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 12,4},new Method("Ljavax/servlet/ServletOutputStream;","write",new String[]{ "[B"},"V"));
                code.visitLabel(L21);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 11},new Method("Ljavax/servlet/http/HttpServletResponse;","flushBuffer",new String[]{ },"V"));
                code.visitLabel(L22);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L23);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,18);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,16);
                code.visitStmt2R(MOVE_OBJECT_FROM16,2,17);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,1,2},new Method("Ljavax/servlet/FilterChain;","doFilter",new String[]{ "Ljavax/servlet/ServletRequest;","Ljavax/servlet/ServletResponse;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L22);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m004_getContext(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/util/ajax/AjaxFilter;","getContext",new String[]{ },"Ljavax/servlet/ServletContext;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(52,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/util/ajax/AjaxFilter;","context","Ljavax/servlet/ServletContext;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m005_handle(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/util/ajax/AjaxFilter;","handle",new String[]{ "Ljava/lang/String;","Ljava/lang/String;","Ljavax/servlet/http/HttpServletRequest;","Lorg/mortbay/util/ajax/AjaxFilter$AjaxResponse;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(8);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"method");
                ddv.visitParameterName(1,"message");
                ddv.visitParameterName(2,"request");
                ddv.visitParameterName(3,"response");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(93,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(94,L1);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,2,"<span class=\"error\">No implementation for ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,4},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitConstStmt(CONST_STRING,2," ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitConstStmt(CONST_STRING,2,"member");
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 6,2},new Method("Ljavax/servlet/http/HttpServletRequest;","getParameter",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitConstStmt(CONST_STRING,2,"</span>");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7,0,1},new Method("Lorg/mortbay/util/ajax/AjaxFilter$AjaxResponse;","elementResponse",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"V"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m006_init(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/util/ajax/AjaxFilter;","init",new String[]{ "Ljavax/servlet/FilterConfig;"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljavax/servlet/ServletException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"filterConfig");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(43,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(44,L1);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 2},new Method("Ljavax/servlet/FilterConfig;","getServletContext",new String[]{ },"Ljavax/servlet/ServletContext;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/util/ajax/AjaxFilter;","context","Ljavax/servlet/ServletContext;"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
