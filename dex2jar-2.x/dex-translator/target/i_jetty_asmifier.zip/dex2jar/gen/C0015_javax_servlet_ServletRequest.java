package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0015_javax_servlet_ServletRequest {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(ACC_PUBLIC|ACC_INTERFACE|ACC_ABSTRACT,"Ljavax/servlet/ServletRequest;","Ljava/lang/Object;",new String[]{ });
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("ServletRequest.java");
        m000_getAttribute(cv);
        m001_getAttributeNames(cv);
        m002_getCharacterEncoding(cv);
        m003_getContentLength(cv);
        m004_getContentType(cv);
        m005_getInputStream(cv);
        m006_getLocalAddr(cv);
        m007_getLocalName(cv);
        m008_getLocalPort(cv);
        m009_getLocale(cv);
        m010_getLocales(cv);
        m011_getParameter(cv);
        m012_getParameterMap(cv);
        m013_getParameterNames(cv);
        m014_getParameterValues(cv);
        m015_getProtocol(cv);
        m016_getReader(cv);
        m017_getRealPath(cv);
        m018_getRemoteAddr(cv);
        m019_getRemoteHost(cv);
        m020_getRemotePort(cv);
        m021_getRequestDispatcher(cv);
        m022_getScheme(cv);
        m023_getServerName(cv);
        m024_getServerPort(cv);
        m025_isSecure(cv);
        m026_removeAttribute(cv);
        m027_setAttribute(cv);
        m028_setCharacterEncoding(cv);
    }
    public static void m000_getAttribute(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Ljavax/servlet/ServletRequest;","getAttribute",new String[]{ "Ljava/lang/String;"},"Ljava/lang/Object;"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m001_getAttributeNames(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Ljavax/servlet/ServletRequest;","getAttributeNames",new String[]{ },"Ljava/util/Enumeration;"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m002_getCharacterEncoding(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Ljavax/servlet/ServletRequest;","getCharacterEncoding",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m003_getContentLength(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Ljavax/servlet/ServletRequest;","getContentLength",new String[]{ },"I"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m004_getContentType(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Ljavax/servlet/ServletRequest;","getContentType",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m005_getInputStream(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Ljavax/servlet/ServletRequest;","getInputStream",new String[]{ },"Ljavax/servlet/ServletInputStream;"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            mv.visitEnd();
        }
    }
    public static void m006_getLocalAddr(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Ljavax/servlet/ServletRequest;","getLocalAddr",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m007_getLocalName(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Ljavax/servlet/ServletRequest;","getLocalName",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m008_getLocalPort(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Ljavax/servlet/ServletRequest;","getLocalPort",new String[]{ },"I"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m009_getLocale(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Ljavax/servlet/ServletRequest;","getLocale",new String[]{ },"Ljava/util/Locale;"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m010_getLocales(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Ljavax/servlet/ServletRequest;","getLocales",new String[]{ },"Ljava/util/Enumeration;"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m011_getParameter(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Ljavax/servlet/ServletRequest;","getParameter",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m012_getParameterMap(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Ljavax/servlet/ServletRequest;","getParameterMap",new String[]{ },"Ljava/util/Map;"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m013_getParameterNames(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Ljavax/servlet/ServletRequest;","getParameterNames",new String[]{ },"Ljava/util/Enumeration;"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m014_getParameterValues(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Ljavax/servlet/ServletRequest;","getParameterValues",new String[]{ "Ljava/lang/String;"},"[Ljava/lang/String;"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m015_getProtocol(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Ljavax/servlet/ServletRequest;","getProtocol",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m016_getReader(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Ljavax/servlet/ServletRequest;","getReader",new String[]{ },"Ljava/io/BufferedReader;"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            mv.visitEnd();
        }
    }
    public static void m017_getRealPath(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Ljavax/servlet/ServletRequest;","getRealPath",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m018_getRemoteAddr(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Ljavax/servlet/ServletRequest;","getRemoteAddr",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m019_getRemoteHost(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Ljavax/servlet/ServletRequest;","getRemoteHost",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m020_getRemotePort(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Ljavax/servlet/ServletRequest;","getRemotePort",new String[]{ },"I"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m021_getRequestDispatcher(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Ljavax/servlet/ServletRequest;","getRequestDispatcher",new String[]{ "Ljava/lang/String;"},"Ljavax/servlet/RequestDispatcher;"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m022_getScheme(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Ljavax/servlet/ServletRequest;","getScheme",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m023_getServerName(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Ljavax/servlet/ServletRequest;","getServerName",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m024_getServerPort(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Ljavax/servlet/ServletRequest;","getServerPort",new String[]{ },"I"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m025_isSecure(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Ljavax/servlet/ServletRequest;","isSecure",new String[]{ },"Z"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m026_removeAttribute(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Ljavax/servlet/ServletRequest;","removeAttribute",new String[]{ "Ljava/lang/String;"},"V"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m027_setAttribute(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Ljavax/servlet/ServletRequest;","setAttribute",new String[]{ "Ljava/lang/String;","Ljava/lang/Object;"},"V"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m028_setCharacterEncoding(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Ljavax/servlet/ServletRequest;","setCharacterEncoding",new String[]{ "Ljava/lang/String;"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/UnsupportedEncodingException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            mv.visitEnd();
        }
    }
}
