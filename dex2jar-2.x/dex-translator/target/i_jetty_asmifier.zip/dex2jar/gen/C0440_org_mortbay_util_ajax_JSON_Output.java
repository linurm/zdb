package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0440_org_mortbay_util_ajax_JSON_Output {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(ACC_PUBLIC|ACC_INTERFACE|ACC_ABSTRACT,"Lorg/mortbay/util/ajax/JSON$Output;","Ljava/lang/Object;",new String[]{ });
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("JSON.java");
        if(cv!=null){
            DexAnnotationVisitor av00 = cv.visitAnnotation("Ldalvik/annotation/EnclosingClass;", Visibility.SYSTEM);
            if(av00 != null) {
                av00.visit("value", new DexType("Lorg/mortbay/util/ajax/JSON;"));
                av00.visitEnd();
            }
        }
        if(cv!=null){
            DexAnnotationVisitor av00 = cv.visitAnnotation("Ldalvik/annotation/InnerClass;", Visibility.SYSTEM);
            if(av00 != null) {
                av00.visit("accessFlags",  Integer.valueOf(1545));
                av00.visit("name", "Output");
                av00.visitEnd();
            }
        }
        m000_add(cv);
        m001_add(cv);
        m002_add(cv);
        m003_add(cv);
        m004_add(cv);
        m005_addClass(cv);
    }
    public static void m000_add(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Lorg/mortbay/util/ajax/JSON$Output;","add",new String[]{ "Ljava/lang/Object;"},"V"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m001_add(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Lorg/mortbay/util/ajax/JSON$Output;","add",new String[]{ "Ljava/lang/String;","D"},"V"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m002_add(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Lorg/mortbay/util/ajax/JSON$Output;","add",new String[]{ "Ljava/lang/String;","J"},"V"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m003_add(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Lorg/mortbay/util/ajax/JSON$Output;","add",new String[]{ "Ljava/lang/String;","Ljava/lang/Object;"},"V"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m004_add(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Lorg/mortbay/util/ajax/JSON$Output;","add",new String[]{ "Ljava/lang/String;","Z"},"V"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m005_addClass(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Lorg/mortbay/util/ajax/JSON$Output;","addClass",new String[]{ "Ljava/lang/Class;"},"V"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
}
