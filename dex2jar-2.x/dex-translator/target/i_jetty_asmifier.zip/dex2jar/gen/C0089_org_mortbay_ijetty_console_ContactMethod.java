package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0089_org_mortbay_ijetty_console_ContactMethod {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(ACC_PUBLIC,"Lorg/mortbay/ijetty/console/ContactMethod;","Ljava/lang/Object;",new String[]{ });
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("ContactMethod.java");
        if(cv!=null){
            DexAnnotationVisitor av00 = cv.visitAnnotation("Ldalvik/annotation/MemberClasses;", Visibility.SYSTEM);
            if(av00 != null) {
                {
                    DexAnnotationVisitor av01 = av00.visitArray("value");
                    if(av01 != null) {
                        av01.visit(null, new DexType("Lorg/mortbay/ijetty/console/ContactMethod$ContactMethodsCollection;"));
                        av01.visitEnd();
                    }
                }
                av00.visitEnd();
            }
        }
        f000_contactMethodsProjection(cv);
        m000__clinit_(cv);
        m001__init_(cv);
        m002_addContactMethod(cv);
        m003_deleteContactMethod(cv);
        m004_getContactMethods(cv);
        m005_saveContactMethod(cv);
    }
    public static void f000_contactMethodsProjection(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/ijetty/console/ContactMethod;","contactMethodsProjection","[Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void m000__clinit_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_STATIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/ijetty/console/ContactMethod;","<clinit>",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(26,L0);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(7)); // int: 0x00000007  float:0.000000
                code.visitTypeStmt(NEW_ARRAY,0,0,"[Ljava/lang/String;");
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitConstStmt(CONST_STRING,2,"_id");
                code.visitStmt3R(APUT_OBJECT,2,0,1);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitConstStmt(CONST_STRING,2,"data");
                code.visitStmt3R(APUT_OBJECT,2,0,1);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(2)); // int: 0x00000002  float:0.000000
                code.visitConstStmt(CONST_STRING,2,"aux_data");
                code.visitStmt3R(APUT_OBJECT,2,0,1);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(3)); // int: 0x00000003  float:0.000000
                code.visitConstStmt(CONST_STRING,2,"kind");
                code.visitStmt3R(APUT_OBJECT,2,0,1);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(4)); // int: 0x00000004  float:0.000000
                code.visitConstStmt(CONST_STRING,2,"label");
                code.visitStmt3R(APUT_OBJECT,2,0,1);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(5)); // int: 0x00000005  float:0.000000
                code.visitConstStmt(CONST_STRING,2,"type");
                code.visitStmt3R(APUT_OBJECT,2,0,1);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(6)); // int: 0x00000006  float:0.000000
                code.visitConstStmt(CONST_STRING,2,"isprimary");
                code.visitStmt3R(APUT_OBJECT,2,0,1);
                code.visitFieldStmt(SPUT_OBJECT,0,-1,new Field("Lorg/mortbay/ijetty/console/ContactMethod;","contactMethodsProjection","[Ljava/lang/String;"));
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/ijetty/console/ContactMethod;","<init>",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(1);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(24,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(39,L1);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/lang/Object;","<init>",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m002_addContactMethod(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Lorg/mortbay/ijetty/console/ContactMethod;","addContactMethod",new String[]{ "Landroid/content/ContentResolver;","Landroid/content/ContentValues;","Ljava/lang/String;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"resolver");
                ddv.visitParameterName(1,"contactMethod");
                ddv.visitParameterName(2,"userId");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(94,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(95,L1);
                ddv.visitStartLocal(0,L1,"peopleUri","Landroid/net/Uri;",null);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(96,L2);
                code.visitLabel(L0);
                code.visitFieldStmt(SGET_OBJECT,1,-1,new Field("Landroid/provider/Contacts$People;","CONTENT_URI","Landroid/net/Uri;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1,4},new Method("Landroid/net/Uri;","withAppendedPath",new String[]{ "Landroid/net/Uri;","Ljava/lang/String;"},"Landroid/net/Uri;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L1);
                code.visitConstStmt(CONST_STRING,1,"contact_methods");
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0,1},new Method("Landroid/net/Uri;","withAppendedPath",new String[]{ "Landroid/net/Uri;","Ljava/lang/String;"},"Landroid/net/Uri;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,1,3},new Method("Landroid/content/ContentResolver;","insert",new String[]{ "Landroid/net/Uri;","Landroid/content/ContentValues;"},"Landroid/net/Uri;"));
                code.visitLabel(L2);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m003_deleteContactMethod(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Lorg/mortbay/ijetty/console/ContactMethod;","deleteContactMethod",new String[]{ "Landroid/content/ContentResolver;","Ljava/lang/String;","Ljava/lang/String;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"resolver");
                ddv.visitParameterName(1,"id");
                ddv.visitParameterName(2,"userId");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(100,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(101,L2);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L1);
                code.visitFieldStmt(SGET_OBJECT,0,-1,new Field("Landroid/provider/Contacts$ContactMethods;","CONTENT_URI","Landroid/net/Uri;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0,3},new Method("Landroid/net/Uri;","withAppendedPath",new String[]{ "Landroid/net/Uri;","Ljava/lang/String;"},"Landroid/net/Uri;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,0,1,1},new Method("Landroid/content/ContentResolver;","delete",new String[]{ "Landroid/net/Uri;","Ljava/lang/String;","[Ljava/lang/String;"},"I"));
                code.visitLabel(L2);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m004_getContactMethods(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Lorg/mortbay/ijetty/console/ContactMethod;","getContactMethods",new String[]{ "Landroid/content/ContentResolver;","Ljava/lang/String;"},"Lorg/mortbay/ijetty/console/ContactMethod$ContactMethodsCollection;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(9);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"resolver");
                ddv.visitParameterName(1,"userId");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(82,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(83,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(86,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(85,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(86,L4);
                ddv.visitStartLocal(4,L4,"whereArgs","[Ljava/lang/String;",null);
                code.visitLabel(L0);
                code.visitJumpStmt(IF_NEZ,8,-1,L3);
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L2);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitLabel(L3);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitTypeStmt(NEW_ARRAY,4,0,"[Ljava/lang/String;");
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitStmt3R(APUT_OBJECT,8,4,0);
                code.visitLabel(L4);
                code.visitTypeStmt(NEW_INSTANCE,6,-1,"Lorg/mortbay/ijetty/console/ContactMethod$ContactMethodsCollection;");
                code.visitFieldStmt(SGET_OBJECT,1,-1,new Field("Landroid/provider/Contacts$ContactMethods;","CONTENT_URI","Landroid/net/Uri;"));
                code.visitFieldStmt(SGET_OBJECT,2,-1,new Field("Lorg/mortbay/ijetty/console/ContactMethod;","contactMethodsProjection","[Ljava/lang/String;"));
                code.visitConstStmt(CONST_STRING,3,"people._id = ?");
                code.visitConstStmt(CONST_STRING,5,"kind DESC");
                code.visitStmt2R(MOVE_OBJECT,0,7);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 0,1,2,3,4,5},new Method("Landroid/content/ContentResolver;","query",new String[]{ "Landroid/net/Uri;","[Ljava/lang/String;","Ljava/lang/String;","[Ljava/lang/String;","Ljava/lang/String;"},"Landroid/database/Cursor;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 6,0},new Method("Lorg/mortbay/ijetty/console/ContactMethod$ContactMethodsCollection;","<init>",new String[]{ "Landroid/database/Cursor;"},"V"));
                code.visitStmt2R(MOVE_OBJECT,0,6);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m005_saveContactMethod(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Lorg/mortbay/ijetty/console/ContactMethod;","saveContactMethod",new String[]{ "Landroid/content/ContentResolver;","Landroid/content/ContentValues;","Ljava/lang/String;","Ljava/lang/String;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(7);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"resolver");
                ddv.visitParameterName(1,"contactMethod");
                ddv.visitParameterName(2,"id");
                ddv.visitParameterName(3,"userId");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(105,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(106,L2);
                ddv.visitStartLocal(0,L2,"uri","Landroid/net/Uri;",null);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(107,L3);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L1);
                code.visitFieldStmt(SGET_OBJECT,1,-1,new Field("Landroid/provider/Contacts$ContactMethods;","CONTENT_URI","Landroid/net/Uri;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1,5},new Method("Landroid/net/Uri;","withAppendedPath",new String[]{ "Landroid/net/Uri;","Ljava/lang/String;"},"Landroid/net/Uri;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,0,4,2,2},new Method("Landroid/content/ContentResolver;","update",new String[]{ "Landroid/net/Uri;","Landroid/content/ContentValues;","Ljava/lang/String;","[Ljava/lang/String;"},"I"));
                code.visitLabel(L3);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
