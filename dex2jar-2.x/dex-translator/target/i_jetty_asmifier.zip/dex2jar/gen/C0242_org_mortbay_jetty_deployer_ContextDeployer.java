package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0242_org_mortbay_jetty_deployer_ContextDeployer {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(ACC_PUBLIC,"Lorg/mortbay/jetty/deployer/ContextDeployer;","Lorg/mortbay/component/AbstractLifeCycle;",new String[]{ });
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("ContextDeployer.java");
        if(cv!=null){
            DexAnnotationVisitor av00 = cv.visitAnnotation("Ldalvik/annotation/MemberClasses;", Visibility.SYSTEM);
            if(av00 != null) {
                {
                    DexAnnotationVisitor av01 = av00.visitArray("value");
                    if(av01 != null) {
                        av01.visit(null, new DexType("Lorg/mortbay/jetty/deployer/ContextDeployer$ScannerListener;"));
                        av01.visitEnd();
                    }
                }
                av00.visitEnd();
            }
        }
        f000_NAME(cv);
        f001__configMgr(cv);
        f002__configurationDir(cv);
        f003__contexts(cv);
        f004__currentDeployments(cv);
        f005__recursive(cv);
        f006__scanInterval(cv);
        f007__scanner(cv);
        f008__scannerListener(cv);
        m000__init_(cv);
        m001_access$000(cv);
        m002_access$100(cv);
        m003_access$200(cv);
        m004_createContext(cv);
        m005_deploy(cv);
        m006_redeploy(cv);
        m007_undeploy(cv);
        m008_doStart(cv);
        m009_doStop(cv);
        m010_getConfigurationDir(cv);
        m011_getConfigurationManager(cv);
        m012_getContexts(cv);
        m013_getDirectory(cv);
        m014_getRecursive(cv);
        m015_getScanInterval(cv);
        m016_isRecursive(cv);
        m017_setConfigurationDir(cv);
        m018_setConfigurationDir(cv);
        m019_setConfigurationDir(cv);
        m020_setConfigurationManager(cv);
        m021_setContexts(cv);
        m022_setDirectory(cv);
        m023_setRecursive(cv);
        m024_setScanInterval(cv);
    }
    public static void f000_NAME(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/deployer/ContextDeployer;","NAME","Ljava/lang/String;"), "ConfiguredDeployer");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f001__configMgr(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/deployer/ContextDeployer;","_configMgr","Lorg/mortbay/jetty/deployer/ConfigurationManager;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f002__configurationDir(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/deployer/ContextDeployer;","_configurationDir","Lorg/mortbay/resource/Resource;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f003__contexts(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/deployer/ContextDeployer;","_contexts","Lorg/mortbay/jetty/handler/ContextHandlerCollection;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f004__currentDeployments(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/deployer/ContextDeployer;","_currentDeployments","Ljava/util/Map;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f005__recursive(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/deployer/ContextDeployer;","_recursive","Z"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f006__scanInterval(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/deployer/ContextDeployer;","_scanInterval","I"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f007__scanner(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/deployer/ContextDeployer;","_scanner","Lorg/mortbay/util/Scanner;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f008__scannerListener(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/deployer/ContextDeployer;","_scannerListener","Lorg/mortbay/jetty/deployer/ContextDeployer$ScannerListener;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void m000__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/jetty/deployer/ContextDeployer;","<init>",new String[]{ },"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/lang/Exception;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(123,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(70,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(74,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(77,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(124,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(125,L5);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1},new Method("Lorg/mortbay/component/AbstractLifeCycle;","<init>",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitConstStmt(CONST_16,0, Integer.valueOf(10)); // int: 0x0000000a  float:0.000000
                code.visitFieldStmt(IPUT,0,1,new Field("Lorg/mortbay/jetty/deployer/ContextDeployer;","_scanInterval","I"));
                code.visitLabel(L2);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/util/HashMap;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/util/HashMap;","<init>",new String[]{ },"V"));
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/jetty/deployer/ContextDeployer;","_currentDeployments","Ljava/util/Map;"));
                code.visitLabel(L3);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT_BOOLEAN,0,1,new Field("Lorg/mortbay/jetty/deployer/ContextDeployer;","_recursive","Z"));
                code.visitLabel(L4);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Lorg/mortbay/util/Scanner;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Lorg/mortbay/util/Scanner;","<init>",new String[]{ },"V"));
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/jetty/deployer/ContextDeployer;","_scanner","Lorg/mortbay/util/Scanner;"));
                code.visitLabel(L5);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001_access$000(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_STATIC|ACC_SYNTHETIC, new Method("Lorg/mortbay/jetty/deployer/ContextDeployer;","access$000",new String[]{ "Lorg/mortbay/jetty/deployer/ContextDeployer;","Ljava/lang/String;"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/lang/Exception;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"x0");
                ddv.visitParameterName(1,"x1");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(67,L0);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1},new Method("Lorg/mortbay/jetty/deployer/ContextDeployer;","deploy",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m002_access$100(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_STATIC|ACC_SYNTHETIC, new Method("Lorg/mortbay/jetty/deployer/ContextDeployer;","access$100",new String[]{ "Lorg/mortbay/jetty/deployer/ContextDeployer;","Ljava/lang/String;"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/lang/Exception;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"x0");
                ddv.visitParameterName(1,"x1");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(67,L0);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1},new Method("Lorg/mortbay/jetty/deployer/ContextDeployer;","redeploy",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m003_access$200(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_STATIC|ACC_SYNTHETIC, new Method("Lorg/mortbay/jetty/deployer/ContextDeployer;","access$200",new String[]{ "Lorg/mortbay/jetty/deployer/ContextDeployer;","Ljava/lang/String;"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/lang/Exception;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"x0");
                ddv.visitParameterName(1,"x1");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(67,L0);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1},new Method("Lorg/mortbay/jetty/deployer/ContextDeployer;","undeploy",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m004_createContext(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PRIVATE, new Method("Lorg/mortbay/jetty/deployer/ContextDeployer;","createContext",new String[]{ "Ljava/lang/String;"},"Lorg/mortbay/jetty/handler/ContextHandler;"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/lang/Exception;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(8);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"filename");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(358,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(359,L1);
                ddv.visitStartLocal(2,L1,"resource","Lorg/mortbay/resource/Resource;",null);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(360,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(370,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(362,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(363,L5);
                ddv.visitStartLocal(3,L5,"xmlConfiguration","Lorg/mortbay/xml/XmlConfiguration;",null);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(364,L6);
                ddv.visitStartLocal(1,L6,"properties","Ljava/util/HashMap;",null);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(365,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(366,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(368,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(369,L10);
                DexLabel L11=new DexLabel();
                ddv.visitStartLocal(0,L11,"context","Lorg/mortbay/jetty/handler/ContextHandler;",null);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(370,L12);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 7},new Method("Lorg/mortbay/resource/Resource;","newResource",new String[]{ "Ljava/lang/String;"},"Lorg/mortbay/resource/Resource;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/resource/Resource;","exists",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,4);
                code.visitJumpStmt(IF_NEZ,4,-1,L4);
                code.visitLabel(L2);
                code.visitConstStmt(CONST_4,4, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L3);
                code.visitStmt1R(RETURN_OBJECT,4);
                code.visitLabel(L4);
                code.visitTypeStmt(NEW_INSTANCE,3,-1,"Lorg/mortbay/xml/XmlConfiguration;");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/resource/Resource;","getURL",new String[]{ },"Ljava/net/URL;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 3,4},new Method("Lorg/mortbay/xml/XmlConfiguration;","<init>",new String[]{ "Ljava/net/URL;"},"V"));
                code.visitLabel(L5);
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Ljava/util/HashMap;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1},new Method("Ljava/util/HashMap;","<init>",new String[]{ },"V"));
                code.visitLabel(L6);
                code.visitConstStmt(CONST_STRING,4,"Server");
                code.visitFieldStmt(IGET_OBJECT,5,6,new Field("Lorg/mortbay/jetty/deployer/ContextDeployer;","_contexts","Lorg/mortbay/jetty/handler/ContextHandlerCollection;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Lorg/mortbay/jetty/handler/ContextHandlerCollection;","getServer",new String[]{ },"Lorg/mortbay/jetty/Server;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,4,5},new Method("Ljava/util/HashMap;","put",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitLabel(L7);
                code.visitFieldStmt(IGET_OBJECT,4,6,new Field("Lorg/mortbay/jetty/deployer/ContextDeployer;","_configMgr","Lorg/mortbay/jetty/deployer/ConfigurationManager;"));
                code.visitJumpStmt(IF_EQZ,4,-1,L9);
                code.visitLabel(L8);
                code.visitFieldStmt(IGET_OBJECT,4,6,new Field("Lorg/mortbay/jetty/deployer/ContextDeployer;","_configMgr","Lorg/mortbay/jetty/deployer/ConfigurationManager;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 4},new Method("Lorg/mortbay/jetty/deployer/ConfigurationManager;","getProperties",new String[]{ },"Ljava/util/Map;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,4},new Method("Ljava/util/HashMap;","putAll",new String[]{ "Ljava/util/Map;"},"V"));
                code.visitLabel(L9);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,1},new Method("Lorg/mortbay/xml/XmlConfiguration;","setProperties",new String[]{ "Ljava/util/Map;"},"V"));
                code.visitLabel(L10);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Lorg/mortbay/xml/XmlConfiguration;","configure",new String[]{ },"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitTypeStmt(CHECK_CAST,0,-1,"Lorg/mortbay/jetty/handler/ContextHandler;");
                code.visitLabel(L11);
                code.visitStmt2R(MOVE_OBJECT,4,0);
                code.visitLabel(L12);
                code.visitJumpStmt(GOTO,-1,-1,L3);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m005_deploy(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PRIVATE, new Method("Lorg/mortbay/jetty/deployer/ContextDeployer;","deploy",new String[]{ "Ljava/lang/String;"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/lang/Exception;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"filename");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(263,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(264,L1);
                ddv.visitStartLocal(0,L1,"context","Lorg/mortbay/jetty/handler/ContextHandler;",null);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(265,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(266,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(267,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(268,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(269,L6);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 3,4},new Method("Lorg/mortbay/jetty/deployer/ContextDeployer;","createContext",new String[]{ "Ljava/lang/String;"},"Lorg/mortbay/jetty/handler/ContextHandler;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L1);
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,2,"Deploy ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,4},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitConstStmt(CONST_STRING,2," -> ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,0},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1},new Method("Lorg/mortbay/log/Log;","info",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L2);
                code.visitFieldStmt(IGET_OBJECT,1,3,new Field("Lorg/mortbay/jetty/deployer/ContextDeployer;","_contexts","Lorg/mortbay/jetty/handler/ContextHandlerCollection;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,0},new Method("Lorg/mortbay/jetty/handler/ContextHandlerCollection;","addHandler",new String[]{ "Lorg/mortbay/jetty/Handler;"},"V"));
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,1,3,new Field("Lorg/mortbay/jetty/deployer/ContextDeployer;","_currentDeployments","Ljava/util/Map;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 1,4,0},new Method("Ljava/util/Map;","put",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitLabel(L4);
                code.visitFieldStmt(IGET_OBJECT,1,3,new Field("Lorg/mortbay/jetty/deployer/ContextDeployer;","_contexts","Lorg/mortbay/jetty/handler/ContextHandlerCollection;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Lorg/mortbay/jetty/handler/ContextHandlerCollection;","isStarted",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitJumpStmt(IF_EQZ,1,-1,L6);
                code.visitLabel(L5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/jetty/handler/ContextHandler;","start",new String[]{ },"V"));
                code.visitLabel(L6);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m006_redeploy(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PRIVATE, new Method("Lorg/mortbay/jetty/deployer/ContextDeployer;","redeploy",new String[]{ "Ljava/lang/String;"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/lang/Exception;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"filename");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(286,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(287,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(288,L2);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1},new Method("Lorg/mortbay/jetty/deployer/ContextDeployer;","undeploy",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1},new Method("Lorg/mortbay/jetty/deployer/ContextDeployer;","deploy",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L2);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m007_undeploy(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PRIVATE, new Method("Lorg/mortbay/jetty/deployer/ContextDeployer;","undeploy",new String[]{ "Ljava/lang/String;"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/lang/Exception;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"filename");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(274,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(275,L1);
                ddv.visitStartLocal(0,L1,"context","Lorg/mortbay/jetty/handler/ContextHandler;",null);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(276,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(281,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(278,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(279,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(280,L6);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,1,3,new Field("Lorg/mortbay/jetty/deployer/ContextDeployer;","_currentDeployments","Ljava/util/Map;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 1,4},new Method("Ljava/util/Map;","get",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitTypeStmt(CHECK_CAST,0,-1,"Lorg/mortbay/jetty/handler/ContextHandler;");
                code.visitLabel(L1);
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,2,"Undeploy ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,4},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitConstStmt(CONST_STRING,2," -> ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,0},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1},new Method("Lorg/mortbay/log/Log;","info",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L2);
                code.visitJumpStmt(IF_NEZ,0,-1,L4);
                code.visitLabel(L3);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/jetty/handler/ContextHandler;","stop",new String[]{ },"V"));
                code.visitLabel(L5);
                code.visitFieldStmt(IGET_OBJECT,1,3,new Field("Lorg/mortbay/jetty/deployer/ContextDeployer;","_contexts","Lorg/mortbay/jetty/handler/ContextHandlerCollection;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,0},new Method("Lorg/mortbay/jetty/handler/ContextHandlerCollection;","removeHandler",new String[]{ "Lorg/mortbay/jetty/Handler;"},"V"));
                code.visitLabel(L6);
                code.visitFieldStmt(IGET_OBJECT,1,3,new Field("Lorg/mortbay/jetty/deployer/ContextDeployer;","_currentDeployments","Ljava/util/Map;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 1,4},new Method("Ljava/util/Map;","remove",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitJumpStmt(GOTO,-1,-1,L3);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m008_doStart(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Lorg/mortbay/jetty/deployer/ContextDeployer;","doStart",new String[]{ },"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/lang/Exception;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(298,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(299,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(301,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(302,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(304,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(305,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(306,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(308,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(325,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(326,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(327,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(328,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(329,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(330,L13);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/jetty/deployer/ContextDeployer;","_configurationDir","Lorg/mortbay/resource/Resource;"));
                code.visitJumpStmt(IF_NEZ,0,-1,L2);
                code.visitLabel(L1);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/lang/IllegalStateException;");
                code.visitConstStmt(CONST_STRING,1,"No configuraition dir specified");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1},new Method("Ljava/lang/IllegalStateException;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitStmt1R(THROW,0);
                code.visitLabel(L2);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/jetty/deployer/ContextDeployer;","_contexts","Lorg/mortbay/jetty/handler/ContextHandlerCollection;"));
                code.visitJumpStmt(IF_NEZ,0,-1,L4);
                code.visitLabel(L3);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/lang/IllegalStateException;");
                code.visitConstStmt(CONST_STRING,1,"No context handler collection specified for deployer");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1},new Method("Ljava/lang/IllegalStateException;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitStmt1R(THROW,0);
                code.visitLabel(L4);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/jetty/deployer/ContextDeployer;","_scanner","Lorg/mortbay/util/Scanner;"));
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/jetty/deployer/ContextDeployer;","_configurationDir","Lorg/mortbay/resource/Resource;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Lorg/mortbay/resource/Resource;","getFile",new String[]{ },"Ljava/io/File;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Lorg/mortbay/util/Scanner;","setScanDir",new String[]{ "Ljava/io/File;"},"V"));
                code.visitLabel(L5);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/jetty/deployer/ContextDeployer;","_scanner","Lorg/mortbay/util/Scanner;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/jetty/deployer/ContextDeployer;","getScanInterval",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Lorg/mortbay/util/Scanner;","setScanInterval",new String[]{ "I"},"V"));
                code.visitLabel(L6);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/jetty/deployer/ContextDeployer;","_scanner","Lorg/mortbay/util/Scanner;"));
                code.visitFieldStmt(IGET_BOOLEAN,1,2,new Field("Lorg/mortbay/jetty/deployer/ContextDeployer;","_recursive","Z"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Lorg/mortbay/util/Scanner;","setRecursive",new String[]{ "Z"},"V"));
                code.visitLabel(L7);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/jetty/deployer/ContextDeployer;","_scanner","Lorg/mortbay/util/Scanner;"));
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Lorg/mortbay/jetty/deployer/ContextDeployer$1;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1,2},new Method("Lorg/mortbay/jetty/deployer/ContextDeployer$1;","<init>",new String[]{ "Lorg/mortbay/jetty/deployer/ContextDeployer;"},"V"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Lorg/mortbay/util/Scanner;","setFilenameFilter",new String[]{ "Ljava/io/FilenameFilter;"},"V"));
                code.visitLabel(L8);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Lorg/mortbay/jetty/deployer/ContextDeployer$ScannerListener;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,2},new Method("Lorg/mortbay/jetty/deployer/ContextDeployer$ScannerListener;","<init>",new String[]{ "Lorg/mortbay/jetty/deployer/ContextDeployer;"},"V"));
                code.visitFieldStmt(IPUT_OBJECT,0,2,new Field("Lorg/mortbay/jetty/deployer/ContextDeployer;","_scannerListener","Lorg/mortbay/jetty/deployer/ContextDeployer$ScannerListener;"));
                code.visitLabel(L9);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/jetty/deployer/ContextDeployer;","_scanner","Lorg/mortbay/util/Scanner;"));
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/jetty/deployer/ContextDeployer;","_scannerListener","Lorg/mortbay/jetty/deployer/ContextDeployer$ScannerListener;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Lorg/mortbay/util/Scanner;","addListener",new String[]{ "Lorg/mortbay/util/Scanner$Listener;"},"V"));
                code.visitLabel(L10);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/jetty/deployer/ContextDeployer;","_scanner","Lorg/mortbay/util/Scanner;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/util/Scanner;","scan",new String[]{ },"V"));
                code.visitLabel(L11);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/jetty/deployer/ContextDeployer;","_scanner","Lorg/mortbay/util/Scanner;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/util/Scanner;","start",new String[]{ },"V"));
                code.visitLabel(L12);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/jetty/deployer/ContextDeployer;","_contexts","Lorg/mortbay/jetty/handler/ContextHandlerCollection;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/jetty/handler/ContextHandlerCollection;","getServer",new String[]{ },"Lorg/mortbay/jetty/Server;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/jetty/Server;","getContainer",new String[]{ },"Lorg/mortbay/component/Container;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/jetty/deployer/ContextDeployer;","_scanner","Lorg/mortbay/util/Scanner;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Lorg/mortbay/component/Container;","addBean",new String[]{ "Ljava/lang/Object;"},"V"));
                code.visitLabel(L13);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m009_doStop(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Lorg/mortbay/jetty/deployer/ContextDeployer;","doStop",new String[]{ },"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/lang/Exception;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(340,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(341,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(342,L2);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/jetty/deployer/ContextDeployer;","_scanner","Lorg/mortbay/util/Scanner;"));
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/jetty/deployer/ContextDeployer;","_scannerListener","Lorg/mortbay/jetty/deployer/ContextDeployer$ScannerListener;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Lorg/mortbay/util/Scanner;","removeListener",new String[]{ "Lorg/mortbay/util/Scanner$Listener;"},"V"));
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/jetty/deployer/ContextDeployer;","_scanner","Lorg/mortbay/util/Scanner;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/util/Scanner;","stop",new String[]{ },"V"));
                code.visitLabel(L2);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m010_getConfigurationDir(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/deployer/ContextDeployer;","getConfigurationDir",new String[]{ },"Lorg/mortbay/resource/Resource;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(224,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/deployer/ContextDeployer;","_configurationDir","Lorg/mortbay/resource/Resource;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m011_getConfigurationManager(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/deployer/ContextDeployer;","getConfigurationManager",new String[]{ },"Lorg/mortbay/jetty/deployer/ConfigurationManager;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(242,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/deployer/ContextDeployer;","_configMgr","Lorg/mortbay/jetty/deployer/ConfigurationManager;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m012_getContexts(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/deployer/ContextDeployer;","getContexts",new String[]{ },"Lorg/mortbay/jetty/handler/ContextHandlerCollection;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(133,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/deployer/ContextDeployer;","_contexts","Lorg/mortbay/jetty/handler/ContextHandlerCollection;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m013_getDirectory(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/deployer/ContextDeployer;","getDirectory",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(215,L0);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Lorg/mortbay/jetty/deployer/ContextDeployer;","getConfigurationDir",new String[]{ },"Lorg/mortbay/resource/Resource;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/resource/Resource;","getName",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m014_getRecursive(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/deployer/ContextDeployer;","getRecursive",new String[]{ },"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(253,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_BOOLEAN,0,1,new Field("Lorg/mortbay/jetty/deployer/ContextDeployer;","_recursive","Z"));
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m015_getScanInterval(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/deployer/ContextDeployer;","getScanInterval",new String[]{ },"I"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(166,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET,0,1,new Field("Lorg/mortbay/jetty/deployer/ContextDeployer;","_scanInterval","I"));
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m016_isRecursive(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/deployer/ContextDeployer;","isRecursive",new String[]{ },"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(258,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_BOOLEAN,0,1,new Field("Lorg/mortbay/jetty/deployer/ContextDeployer;","_recursive","Z"));
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m017_setConfigurationDir(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/deployer/ContextDeployer;","setConfigurationDir",new String[]{ "Ljava/io/File;"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/lang/Exception;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"file");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(186,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(187,L1);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Ljava/io/File;","toURL",new String[]{ },"Ljava/net/URL;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0},new Method("Lorg/mortbay/resource/Resource;","newResource",new String[]{ "Ljava/net/URL;"},"Lorg/mortbay/resource/Resource;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,0},new Method("Lorg/mortbay/jetty/deployer/ContextDeployer;","setConfigurationDir",new String[]{ "Lorg/mortbay/resource/Resource;"},"V"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m018_setConfigurationDir(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/deployer/ContextDeployer;","setConfigurationDir",new String[]{ "Ljava/lang/String;"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/lang/Exception;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"dir");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(176,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(177,L1);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 2},new Method("Lorg/mortbay/resource/Resource;","newResource",new String[]{ "Ljava/lang/String;"},"Lorg/mortbay/resource/Resource;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,0},new Method("Lorg/mortbay/jetty/deployer/ContextDeployer;","setConfigurationDir",new String[]{ "Lorg/mortbay/resource/Resource;"},"V"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m019_setConfigurationDir(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/deployer/ContextDeployer;","setConfigurationDir",new String[]{ "Lorg/mortbay/resource/Resource;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"resource");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(195,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(196,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(197,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(198,L3);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/jetty/deployer/ContextDeployer;","isStarted",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_NEZ,0,-1,L1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/jetty/deployer/ContextDeployer;","isStarting",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_EQZ,0,-1,L2);
                code.visitLabel(L1);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/lang/IllegalStateException;");
                code.visitConstStmt(CONST_STRING,1,"Cannot change hot deploy dir after deployer start");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1},new Method("Ljava/lang/IllegalStateException;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitStmt1R(THROW,0);
                code.visitLabel(L2);
                code.visitFieldStmt(IPUT_OBJECT,3,2,new Field("Lorg/mortbay/jetty/deployer/ContextDeployer;","_configurationDir","Lorg/mortbay/resource/Resource;"));
                code.visitLabel(L3);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m020_setConfigurationManager(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/deployer/ContextDeployer;","setConfigurationManager",new String[]{ "Lorg/mortbay/jetty/deployer/ConfigurationManager;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"configMgr");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(233,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(234,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_OBJECT,1,0,new Field("Lorg/mortbay/jetty/deployer/ContextDeployer;","_configMgr","Lorg/mortbay/jetty/deployer/ConfigurationManager;"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m021_setContexts(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/deployer/ContextDeployer;","setContexts",new String[]{ "Lorg/mortbay/jetty/handler/ContextHandlerCollection;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"contexts");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(145,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(146,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(147,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(148,L3);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/jetty/deployer/ContextDeployer;","isStarted",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_NEZ,0,-1,L1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/jetty/deployer/ContextDeployer;","isStarting",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_EQZ,0,-1,L2);
                code.visitLabel(L1);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/lang/IllegalStateException;");
                code.visitConstStmt(CONST_STRING,1,"Cannot set Contexts after deployer start");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1},new Method("Ljava/lang/IllegalStateException;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitStmt1R(THROW,0);
                code.visitLabel(L2);
                code.visitFieldStmt(IPUT_OBJECT,3,2,new Field("Lorg/mortbay/jetty/deployer/ContextDeployer;","_contexts","Lorg/mortbay/jetty/handler/ContextHandlerCollection;"));
                code.visitLabel(L3);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m022_setDirectory(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/deployer/ContextDeployer;","setDirectory",new String[]{ "Ljava/lang/String;"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/lang/Exception;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"directory");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(206,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(207,L1);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Lorg/mortbay/jetty/deployer/ContextDeployer;","setConfigurationDir",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m023_setRecursive(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/deployer/ContextDeployer;","setRecursive",new String[]{ "Z"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"recursive");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(248,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(249,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_BOOLEAN,1,0,new Field("Lorg/mortbay/jetty/deployer/ContextDeployer;","_recursive","Z"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m024_setScanInterval(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/deployer/ContextDeployer;","setScanInterval",new String[]{ "I"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"seconds");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(158,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(159,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(160,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(161,L3);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/jetty/deployer/ContextDeployer;","isStarted",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_NEZ,0,-1,L1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/jetty/deployer/ContextDeployer;","isStarting",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_EQZ,0,-1,L2);
                code.visitLabel(L1);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/lang/IllegalStateException;");
                code.visitConstStmt(CONST_STRING,1,"Cannot change scan interval after deployer start");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1},new Method("Ljava/lang/IllegalStateException;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitStmt1R(THROW,0);
                code.visitLabel(L2);
                code.visitFieldStmt(IPUT,3,2,new Field("Lorg/mortbay/jetty/deployer/ContextDeployer;","_scanInterval","I"));
                code.visitLabel(L3);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
