package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0247_org_mortbay_jetty_handler_ContextHandlerCollection {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(ACC_PUBLIC,"Lorg/mortbay/jetty/handler/ContextHandlerCollection;","Lorg/mortbay/jetty/handler/HandlerCollection;",new String[]{ });
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("ContextHandlerCollection.java");
        f000__contextClass(cv);
        f001__contextMap(cv);
        m000__init_(cv);
        m001_normalizeHostname(cv);
        m002_addContext(cv);
        m003_doStart(cv);
        m004_getContextClass(cv);
        m005_handle(cv);
        m006_mapContexts(cv);
        m007_setContextClass(cv);
        m008_setHandlers(cv);
    }
    public static void f000__contextClass(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/handler/ContextHandlerCollection;","_contextClass","Ljava/lang/Class;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f001__contextMap(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/handler/ContextHandlerCollection;","_contextMap","Lorg/mortbay/jetty/servlet/PathMap;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void m000__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/jetty/handler/ContextHandlerCollection;","<init>",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(45,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(48,L1);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1},new Method("Lorg/mortbay/jetty/handler/HandlerCollection;","<init>",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitConstStmt(CONST_CLASS,0,new DexType("Lorg/mortbay/jetty/handler/ContextHandler;"));
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/jetty/handler/ContextHandlerCollection;","_contextClass","Ljava/lang/Class;"));
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001_normalizeHostname(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PRIVATE, new Method("Lorg/mortbay/jetty/handler/ContextHandlerCollection;","normalizeHostname",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"host");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(300,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(301,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(306,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(303,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(304,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(306,L5);
                code.visitLabel(L0);
                code.visitJumpStmt(IF_NEZ,4,-1,L3);
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L2);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitLabel(L3);
                code.visitConstStmt(CONST_STRING,0,".");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,0},new Method("Ljava/lang/String;","endsWith",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                DexLabel L6=new DexLabel();
                code.visitJumpStmt(IF_EQZ,0,-1,L6);
                code.visitLabel(L4);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Ljava/lang/String;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitStmt2R(SUB_INT_2ADDR,1,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,0,1},new Method("Ljava/lang/String;","substring",new String[]{ "I","I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitLabel(L6);
                code.visitStmt2R(MOVE_OBJECT,0,4);
                code.visitLabel(L5);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m002_addContext(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/handler/ContextHandlerCollection;","addContext",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"Lorg/mortbay/jetty/handler/ContextHandler;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(6);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ "Ljava/lang/Exception;"});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"contextPath");
                ddv.visitParameterName(1,"resourceBase");
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(261,L0);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(262,L3);
                ddv.visitStartLocal(0,L3,"context","Lorg/mortbay/jetty/handler/ContextHandler;",null);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(263,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(264,L5);
                ddv.visitLineNumber(265,L1);
                ddv.visitLineNumber(267,L2);
                ddv.visitEndLocal(0,L2);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(269,L6);
                ddv.visitStartLocal(1,L6,"e","Ljava/lang/Exception;",null);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(270,L7);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,2,3,new Field("Lorg/mortbay/jetty/handler/ContextHandlerCollection;","_contextClass","Ljava/lang/Class;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Ljava/lang/Class;","newInstance",new String[]{ },"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitTypeStmt(CHECK_CAST,0,-1,"Lorg/mortbay/jetty/handler/ContextHandler;");
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,4},new Method("Lorg/mortbay/jetty/handler/ContextHandler;","setContextPath",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,5},new Method("Lorg/mortbay/jetty/handler/ContextHandler;","setResourceBase",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,0},new Method("Lorg/mortbay/jetty/handler/ContextHandlerCollection;","addHandler",new String[]{ "Lorg/mortbay/jetty/Handler;"},"V"));
                code.visitLabel(L1);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,2);
                code.visitStmt2R(MOVE_OBJECT,1,2);
                code.visitLabel(L6);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1},new Method("Lorg/mortbay/log/Log;","warn",new String[]{ "Ljava/lang/Throwable;"},"V"));
                code.visitLabel(L7);
                code.visitTypeStmt(NEW_INSTANCE,2,-1,"Ljava/lang/Error;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2,1},new Method("Ljava/lang/Error;","<init>",new String[]{ "Ljava/lang/Throwable;"},"V"));
                code.visitStmt1R(THROW,2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m003_doStart(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Lorg/mortbay/jetty/handler/ContextHandlerCollection;","doStart",new String[]{ },"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/lang/Exception;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(1);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(155,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(156,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(157,L2);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/jetty/handler/ContextHandlerCollection;","mapContexts",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_SUPER,new int[]{ 0},new Method("Lorg/mortbay/jetty/handler/HandlerCollection;","doStart",new String[]{ },"V"));
                code.visitLabel(L2);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m004_getContextClass(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/handler/ContextHandlerCollection;","getContextClass",new String[]{ },"Ljava/lang/Class;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(282,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/handler/ContextHandlerCollection;","_contextClass","Ljava/lang/Class;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m005_handle(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/handler/ContextHandlerCollection;","handle",new String[]{ "Ljava/lang/String;","Ljavax/servlet/http/HttpServletRequest;","Ljavax/servlet/http/HttpServletResponse;","I"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visit(null, new DexType("Ljavax/servlet/ServletException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(23);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"target");
                ddv.visitParameterName(1,"request");
                ddv.visitParameterName(2,"response");
                ddv.visitParameterName(3,"dispatch");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(166,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(167,L1);
                ddv.visitStartLocal(9,L1,"handlers","[Lorg/mortbay/jetty/Handler;",null);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(247,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(170,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(177,L4);
                ddv.visitStartLocal(5,L4,"base_request","Lorg/mortbay/jetty/Request;",null);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(178,L5);
                ddv.visitStartLocal(15,L5,"map","Lorg/mortbay/jetty/servlet/PathMap;",null);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(181,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(183,L7);
                ddv.visitStartLocal(6,L7,"contexts","Ljava/lang/Object;",null);
                DexLabel L8=new DexLabel();
                ddv.visitStartLocal(12,L8,"i","I",null);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(186,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(187,L10);
                ddv.visitStartLocal(7,L10,"entry","Ljava/util/Map$Entry;",null);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(189,L11);
                ddv.visitStartLocal(14,L11,"list","Ljava/lang/Object;",null);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(191,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(192,L13);
                ddv.visitStartLocal(11,L13,"hosts","Ljava/util/Map;",null);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(195,L14);
                ddv.visitStartLocal(10,L14,"host","Ljava/lang/String;",null);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(196,L15);
                DexLabel L16=new DexLabel();
                ddv.visitStartLocal(13,L16,"j","I",null);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(198,L17);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(199,L18);
                ddv.visitStartLocal(8,L18,"handler","Lorg/mortbay/jetty/Handler;",null);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(200,L19);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(196,L20);
                DexLabel L21=new DexLabel();
                ddv.visitLineNumber(205,L21);
                ddv.visitEndLocal(8,L21);
                DexLabel L22=new DexLabel();
                ddv.visitLineNumber(206,L22);
                ddv.visitRestartLocal(14,L22);
                DexLabel L23=new DexLabel();
                ddv.visitLineNumber(208,L23);
                DexLabel L24=new DexLabel();
                ddv.visitLineNumber(209,L24);
                ddv.visitRestartLocal(8,L24);
                DexLabel L25=new DexLabel();
                ddv.visitLineNumber(210,L25);
                DexLabel L26=new DexLabel();
                ddv.visitLineNumber(206,L26);
                DexLabel L27=new DexLabel();
                ddv.visitLineNumber(216,L27);
                ddv.visitEndLocal(8,L27);
                DexLabel L28=new DexLabel();
                ddv.visitLineNumber(217,L28);
                ddv.visitRestartLocal(14,L28);
                DexLabel L29=new DexLabel();
                ddv.visitLineNumber(219,L29);
                DexLabel L30=new DexLabel();
                ddv.visitLineNumber(220,L30);
                ddv.visitRestartLocal(8,L30);
                DexLabel L31=new DexLabel();
                ddv.visitLineNumber(221,L31);
                DexLabel L32=new DexLabel();
                ddv.visitLineNumber(217,L32);
                DexLabel L33=new DexLabel();
                ddv.visitLineNumber(227,L33);
                ddv.visitEndLocal(11,L33);
                ddv.visitEndLocal(10,L33);
                ddv.visitEndLocal(13,L33);
                ddv.visitEndLocal(8,L33);
                DexLabel L34=new DexLabel();
                ddv.visitRestartLocal(13,L34);
                DexLabel L35=new DexLabel();
                ddv.visitLineNumber(229,L35);
                DexLabel L36=new DexLabel();
                ddv.visitLineNumber(230,L36);
                ddv.visitRestartLocal(8,L36);
                DexLabel L37=new DexLabel();
                ddv.visitLineNumber(231,L37);
                DexLabel L38=new DexLabel();
                ddv.visitLineNumber(227,L38);
                DexLabel L39=new DexLabel();
                ddv.visitLineNumber(183,L39);
                ddv.visitEndLocal(8,L39);
                DexLabel L40=new DexLabel();
                ddv.visitLineNumber(240,L40);
                ddv.visitEndLocal(6,L40);
                ddv.visitEndLocal(12,L40);
                ddv.visitEndLocal(7,L40);
                ddv.visitEndLocal(14,L40);
                ddv.visitEndLocal(13,L40);
                DexLabel L41=new DexLabel();
                ddv.visitRestartLocal(12,L41);
                DexLabel L42=new DexLabel();
                ddv.visitLineNumber(242,L42);
                DexLabel L43=new DexLabel();
                ddv.visitLineNumber(243,L43);
                DexLabel L44=new DexLabel();
                ddv.visitLineNumber(240,L44);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 18},new Method("Lorg/mortbay/jetty/handler/ContextHandlerCollection;","getHandlers",new String[]{ },"[Lorg/mortbay/jetty/Handler;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,9);
                code.visitLabel(L1);
                code.visitJumpStmt(IF_EQZ,9,-1,L2);
                code.visitStmt2R(MOVE_OBJECT,0,9);
                code.visitStmt2R(ARRAY_LENGTH,0,0);
                code.visitStmt2R(MOVE_FROM16,16,0);
                code.visitJumpStmt(IF_NEZ,16,-1,L3);
                code.visitLabel(L2);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Lorg/mortbay/jetty/HttpConnection;","getCurrentConnection",new String[]{ },"Lorg/mortbay/jetty/HttpConnection;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,16);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 16},new Method("Lorg/mortbay/jetty/HttpConnection;","getRequest",new String[]{ },"Lorg/mortbay/jetty/Request;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitLabel(L4);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,18);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/handler/ContextHandlerCollection;","_contextMap","Lorg/mortbay/jetty/servlet/PathMap;"));
                code.visitStmt2R(MOVE_OBJECT,15,0);
                code.visitLabel(L5);
                code.visitJumpStmt(IF_EQZ,15,-1,L40);
                code.visitJumpStmt(IF_EQZ,19,-1,L40);
                code.visitConstStmt(CONST_STRING,16,"/");
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,19);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,16);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/String;","startsWith",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,16);
                code.visitJumpStmt(IF_EQZ,16,-1,L40);
                code.visitLabel(L6);
                code.visitStmt2R(MOVE_OBJECT,0,15);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,19);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Lorg/mortbay/jetty/servlet/PathMap;","getLazyMatches",new String[]{ "Ljava/lang/String;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitLabel(L7);
                code.visitConstStmt(CONST_4,12, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L8);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 6},new Method("Lorg/mortbay/util/LazyList;","size",new String[]{ "Ljava/lang/Object;"},"I"));
                code.visitStmt1R(MOVE_RESULT,16);
                code.visitStmt2R(MOVE,0,12);
                code.visitStmt2R(MOVE_FROM16,1,16);
                code.visitJumpStmt(IF_GE,0,1,L2);
                code.visitLabel(L9);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 6,12},new Method("Lorg/mortbay/util/LazyList;","get",new String[]{ "Ljava/lang/Object;","I"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitTypeStmt(CHECK_CAST,7,-1,"Ljava/util/Map$Entry;");
                code.visitLabel(L10);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 7},new Method("Ljava/util/Map$Entry;","getValue",new String[]{ },"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,14);
                code.visitLabel(L11);
                code.visitStmt2R(MOVE_OBJECT,0,14);
                code.visitTypeStmt(INSTANCE_OF,0,0,"Ljava/util/Map;");
                code.visitStmt2R(MOVE_FROM16,16,0);
                code.visitJumpStmt(IF_EQZ,16,-1,L33);
                code.visitLabel(L12);
                code.visitStmt2R(MOVE_OBJECT,0,14);
                code.visitTypeStmt(CHECK_CAST,0,-1,"Ljava/util/Map;");
                code.visitStmt2R(MOVE_OBJECT,11,0);
                code.visitLabel(L13);
                code.visitMethodStmt(INVOKE_INTERFACE_RANGE,new int[]{ 20},new Method("Ljavax/servlet/http/HttpServletRequest;","getServerName",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,16);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,18);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,16);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1},new Method("Lorg/mortbay/jetty/handler/ContextHandlerCollection;","normalizeHostname",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,10);
                code.visitLabel(L14);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 11,10},new Method("Ljava/util/Map;","get",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,14);
                code.visitLabel(L15);
                code.visitConstStmt(CONST_4,13, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L16);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 14},new Method("Lorg/mortbay/util/LazyList;","size",new String[]{ "Ljava/lang/Object;"},"I"));
                code.visitStmt1R(MOVE_RESULT,16);
                code.visitStmt2R(MOVE,0,13);
                code.visitStmt2R(MOVE_FROM16,1,16);
                code.visitJumpStmt(IF_GE,0,1,L21);
                code.visitLabel(L17);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 14,13},new Method("Lorg/mortbay/util/LazyList;","get",new String[]{ "Ljava/lang/Object;","I"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitTypeStmt(CHECK_CAST,8,-1,"Lorg/mortbay/jetty/Handler;");
                code.visitLabel(L18);
                code.visitStmt2R(MOVE_OBJECT,0,8);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,19);
                code.visitStmt2R(MOVE_OBJECT_FROM16,2,20);
                code.visitStmt2R(MOVE_OBJECT_FROM16,3,21);
                code.visitStmt2R(MOVE_FROM16,4,22);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,1,2,3,4},new Method("Lorg/mortbay/jetty/Handler;","handle",new String[]{ "Ljava/lang/String;","Ljavax/servlet/http/HttpServletRequest;","Ljavax/servlet/http/HttpServletResponse;","I"},"V"));
                code.visitLabel(L19);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Lorg/mortbay/jetty/Request;","isHandled",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,16);
                code.visitJumpStmt(IF_NEZ,16,-1,L2);
                code.visitLabel(L20);
                code.visitStmt2R1N(ADD_INT_LIT8,13,13,1);
                code.visitJumpStmt(GOTO,-1,-1,L16);
                code.visitLabel(L21);
                code.visitTypeStmt(NEW_INSTANCE,16,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT_RANGE,new int[]{ 16},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,17,"*.");
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 16,17},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,16);
                code.visitConstStmt(CONST_STRING,17,".");
                code.visitStmt2R(MOVE_OBJECT,0,10);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,17);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/String;","indexOf",new String[]{ "Ljava/lang/String;"},"I"));
                code.visitStmt1R(MOVE_RESULT,17);
                code.visitStmt2R1N(ADD_INT_LIT8,17,17,1);
                code.visitStmt2R(MOVE_OBJECT,0,10);
                code.visitStmt2R(MOVE_FROM16,1,17);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/String;","substring",new String[]{ "I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,17);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 16,17},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,16);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 16},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,16);
                code.visitStmt2R(MOVE_OBJECT,0,11);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,16);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,1},new Method("Ljava/util/Map;","get",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,14);
                code.visitLabel(L22);
                code.visitConstStmt(CONST_4,13, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                DexLabel L45=new DexLabel();
                code.visitLabel(L45);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 14},new Method("Lorg/mortbay/util/LazyList;","size",new String[]{ "Ljava/lang/Object;"},"I"));
                code.visitStmt1R(MOVE_RESULT,16);
                code.visitStmt2R(MOVE,0,13);
                code.visitStmt2R(MOVE_FROM16,1,16);
                code.visitJumpStmt(IF_GE,0,1,L27);
                code.visitLabel(L23);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 14,13},new Method("Lorg/mortbay/util/LazyList;","get",new String[]{ "Ljava/lang/Object;","I"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitTypeStmt(CHECK_CAST,8,-1,"Lorg/mortbay/jetty/Handler;");
                code.visitLabel(L24);
                code.visitStmt2R(MOVE_OBJECT,0,8);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,19);
                code.visitStmt2R(MOVE_OBJECT_FROM16,2,20);
                code.visitStmt2R(MOVE_OBJECT_FROM16,3,21);
                code.visitStmt2R(MOVE_FROM16,4,22);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,1,2,3,4},new Method("Lorg/mortbay/jetty/Handler;","handle",new String[]{ "Ljava/lang/String;","Ljavax/servlet/http/HttpServletRequest;","Ljavax/servlet/http/HttpServletResponse;","I"},"V"));
                code.visitLabel(L25);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Lorg/mortbay/jetty/Request;","isHandled",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,16);
                code.visitJumpStmt(IF_NEZ,16,-1,L2);
                code.visitLabel(L26);
                code.visitStmt2R1N(ADD_INT_LIT8,13,13,1);
                code.visitJumpStmt(GOTO,-1,-1,L45);
                code.visitLabel(L27);
                code.visitConstStmt(CONST_STRING,16,"*");
                code.visitStmt2R(MOVE_OBJECT,0,11);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,16);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,1},new Method("Ljava/util/Map;","get",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,14);
                code.visitLabel(L28);
                code.visitConstStmt(CONST_4,13, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                DexLabel L46=new DexLabel();
                code.visitLabel(L46);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 14},new Method("Lorg/mortbay/util/LazyList;","size",new String[]{ "Ljava/lang/Object;"},"I"));
                code.visitStmt1R(MOVE_RESULT,16);
                code.visitStmt2R(MOVE,0,13);
                code.visitStmt2R(MOVE_FROM16,1,16);
                code.visitJumpStmt(IF_GE,0,1,L39);
                code.visitLabel(L29);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 14,13},new Method("Lorg/mortbay/util/LazyList;","get",new String[]{ "Ljava/lang/Object;","I"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitTypeStmt(CHECK_CAST,8,-1,"Lorg/mortbay/jetty/Handler;");
                code.visitLabel(L30);
                code.visitStmt2R(MOVE_OBJECT,0,8);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,19);
                code.visitStmt2R(MOVE_OBJECT_FROM16,2,20);
                code.visitStmt2R(MOVE_OBJECT_FROM16,3,21);
                code.visitStmt2R(MOVE_FROM16,4,22);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,1,2,3,4},new Method("Lorg/mortbay/jetty/Handler;","handle",new String[]{ "Ljava/lang/String;","Ljavax/servlet/http/HttpServletRequest;","Ljavax/servlet/http/HttpServletResponse;","I"},"V"));
                code.visitLabel(L31);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Lorg/mortbay/jetty/Request;","isHandled",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,16);
                code.visitJumpStmt(IF_NEZ,16,-1,L2);
                code.visitLabel(L32);
                code.visitStmt2R1N(ADD_INT_LIT8,13,13,1);
                code.visitJumpStmt(GOTO,-1,-1,L46);
                code.visitLabel(L33);
                code.visitConstStmt(CONST_4,13, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L34);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 14},new Method("Lorg/mortbay/util/LazyList;","size",new String[]{ "Ljava/lang/Object;"},"I"));
                code.visitStmt1R(MOVE_RESULT,16);
                code.visitStmt2R(MOVE,0,13);
                code.visitStmt2R(MOVE_FROM16,1,16);
                code.visitJumpStmt(IF_GE,0,1,L39);
                code.visitLabel(L35);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 14,13},new Method("Lorg/mortbay/util/LazyList;","get",new String[]{ "Ljava/lang/Object;","I"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitTypeStmt(CHECK_CAST,8,-1,"Lorg/mortbay/jetty/Handler;");
                code.visitLabel(L36);
                code.visitStmt2R(MOVE_OBJECT,0,8);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,19);
                code.visitStmt2R(MOVE_OBJECT_FROM16,2,20);
                code.visitStmt2R(MOVE_OBJECT_FROM16,3,21);
                code.visitStmt2R(MOVE_FROM16,4,22);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,1,2,3,4},new Method("Lorg/mortbay/jetty/Handler;","handle",new String[]{ "Ljava/lang/String;","Ljavax/servlet/http/HttpServletRequest;","Ljavax/servlet/http/HttpServletResponse;","I"},"V"));
                code.visitLabel(L37);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Lorg/mortbay/jetty/Request;","isHandled",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,16);
                code.visitJumpStmt(IF_NEZ,16,-1,L2);
                code.visitLabel(L38);
                code.visitStmt2R1N(ADD_INT_LIT8,13,13,1);
                code.visitJumpStmt(GOTO,-1,-1,L34);
                code.visitLabel(L39);
                code.visitStmt2R1N(ADD_INT_LIT8,12,12,1);
                code.visitJumpStmt(GOTO_16,-1,-1,L8);
                code.visitLabel(L40);
                code.visitConstStmt(CONST_4,12, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L41);
                code.visitStmt2R(MOVE_OBJECT,0,9);
                code.visitStmt2R(ARRAY_LENGTH,0,0);
                code.visitStmt2R(MOVE_FROM16,16,0);
                code.visitStmt2R(MOVE,0,12);
                code.visitStmt2R(MOVE_FROM16,1,16);
                code.visitJumpStmt(IF_GE,0,1,L2);
                code.visitLabel(L42);
                code.visitStmt3R(AGET_OBJECT,16,9,12);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,16);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,19);
                code.visitStmt2R(MOVE_OBJECT_FROM16,2,20);
                code.visitStmt2R(MOVE_OBJECT_FROM16,3,21);
                code.visitStmt2R(MOVE_FROM16,4,22);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,1,2,3,4},new Method("Lorg/mortbay/jetty/Handler;","handle",new String[]{ "Ljava/lang/String;","Ljavax/servlet/http/HttpServletRequest;","Ljavax/servlet/http/HttpServletResponse;","I"},"V"));
                code.visitLabel(L43);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Lorg/mortbay/jetty/Request;","isHandled",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,16);
                code.visitJumpStmt(IF_NEZ,16,-1,L2);
                code.visitLabel(L44);
                code.visitStmt2R1N(ADD_INT_LIT8,12,12,1);
                code.visitJumpStmt(GOTO,-1,-1,L41);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m006_mapContexts(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/handler/ContextHandlerCollection;","mapContexts",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(18);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(56,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(57,L1);
                ddv.visitStartLocal(4,L1,"contextMap","Lorg/mortbay/jetty/servlet/PathMap;",null);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(60,L2);
                ddv.visitStartLocal(3,L2,"branches","[Lorg/mortbay/jetty/Handler;",null);
                DexLabel L3=new DexLabel();
                ddv.visitStartLocal(2,L3,"b","I",null);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(62,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(64,L5);
                ddv.visitStartLocal(8,L5,"handlers","[Lorg/mortbay/jetty/Handler;",null);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(66,L6);
                DexLabel L7=new DexLabel();
                ddv.visitEndLocal(8,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(75,L8);
                ddv.visitRestartLocal(8,L8);
                DexLabel L9=new DexLabel();
                ddv.visitStartLocal(10,L9,"i","I",null);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(77,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(79,L11);
                ddv.visitStartLocal(7,L11,"handler","Lorg/mortbay/jetty/handler/ContextHandler;",null);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(81,L12);
                ddv.visitStartLocal(5,L12,"contextPath","Ljava/lang/String;",null);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(82,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(68,L14);
                ddv.visitEndLocal(10,L14);
                ddv.visitEndLocal(7,L14);
                ddv.visitEndLocal(5,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(70,L15);
                DexLabel L16=new DexLabel();
                ddv.visitRestartLocal(8,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(84,L17);
                ddv.visitRestartLocal(5,L17);
                ddv.visitRestartLocal(7,L17);
                ddv.visitRestartLocal(10,L17);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(85,L18);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(87,L19);
                ddv.visitRestartLocal(5,L19);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(89,L20);
                DexLabel L21=new DexLabel();
                ddv.visitLineNumber(90,L21);
                DexLabel L22=new DexLabel();
                ddv.visitLineNumber(95,L22);
                ddv.visitRestartLocal(5,L22);
                DexLabel L23=new DexLabel();
                ddv.visitLineNumber(96,L23);
                ddv.visitStartLocal(6,L23,"contexts","Ljava/lang/Object;",null);
                DexLabel L24=new DexLabel();
                ddv.visitLineNumber(99,L24);
                ddv.visitStartLocal(13,L24,"vhosts","[Ljava/lang/String;",null);
                DexLabel L25=new DexLabel();
                ddv.visitLineNumber(103,L25);
                DexLabel L26=new DexLabel();
                ddv.visitLineNumber(104,L26);
                DexLabel L27=new DexLabel();
                ddv.visitLineNumber(112,L27);
                ddv.visitStartLocal(9,L27,"hosts","Ljava/util/Map;",null);
                DexLabel L28=new DexLabel();
                ddv.visitStartLocal(11,L28,"j","I",null);
                DexLabel L29=new DexLabel();
                ddv.visitLineNumber(114,L29);
                DexLabel L30=new DexLabel();
                ddv.visitLineNumber(115,L30);
                ddv.visitStartLocal(12,L30,"vhost","Ljava/lang/String;",null);
                DexLabel L31=new DexLabel();
                ddv.visitLineNumber(116,L31);
                DexLabel L32=new DexLabel();
                ddv.visitLineNumber(117,L32);
                ddv.visitRestartLocal(6,L32);
                DexLabel L33=new DexLabel();
                ddv.visitLineNumber(112,L33);
                DexLabel L34=new DexLabel();
                ddv.visitLineNumber(91,L34);
                ddv.visitEndLocal(13,L34);
                ddv.visitEndLocal(9,L34);
                ddv.visitEndLocal(11,L34);
                ddv.visitEndLocal(12,L34);
                ddv.visitEndLocal(6,L34);
                DexLabel L35=new DexLabel();
                ddv.visitLineNumber(92,L35);
                DexLabel L36=new DexLabel();
                ddv.visitRestartLocal(5,L36);
                DexLabel L37=new DexLabel();
                ddv.visitLineNumber(107,L37);
                ddv.visitRestartLocal(6,L37);
                ddv.visitRestartLocal(13,L37);
                DexLabel L38=new DexLabel();
                ddv.visitLineNumber(108,L38);
                ddv.visitRestartLocal(9,L38);
                DexLabel L39=new DexLabel();
                ddv.visitLineNumber(109,L39);
                DexLabel L40=new DexLabel();
                ddv.visitLineNumber(120,L40);
                ddv.visitEndLocal(9,L40);
                DexLabel L41=new DexLabel();
                ddv.visitLineNumber(122,L41);
                DexLabel L42=new DexLabel();
                ddv.visitLineNumber(123,L42);
                ddv.visitRestartLocal(9,L42);
                DexLabel L43=new DexLabel();
                ddv.visitLineNumber(124,L43);
                ddv.visitRestartLocal(6,L43);
                DexLabel L44=new DexLabel();
                ddv.visitLineNumber(125,L44);
                ddv.visitRestartLocal(6,L44);
                DexLabel L45=new DexLabel();
                ddv.visitLineNumber(75,L45);
                ddv.visitEndLocal(9,L45);
                DexLabel L46=new DexLabel();
                ddv.visitLineNumber(129,L46);
                DexLabel L47=new DexLabel();
                ddv.visitLineNumber(130,L47);
                ddv.visitRestartLocal(6,L47);
                DexLabel L48=new DexLabel();
                ddv.visitLineNumber(60,L48);
                ddv.visitEndLocal(7,L48);
                ddv.visitEndLocal(10,L48);
                ddv.visitEndLocal(5,L48);
                ddv.visitEndLocal(13,L48);
                ddv.visitEndLocal(6,L48);
                DexLabel L49=new DexLabel();
                ddv.visitLineNumber(134,L49);
                ddv.visitEndLocal(8,L49);
                DexLabel L50=new DexLabel();
                ddv.visitLineNumber(136,L50);
                code.visitLabel(L0);
                code.visitTypeStmt(NEW_INSTANCE,4,-1,"Lorg/mortbay/jetty/servlet/PathMap;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 4},new Method("Lorg/mortbay/jetty/servlet/PathMap;","<init>",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 17},new Method("Lorg/mortbay/jetty/handler/ContextHandlerCollection;","getHandlers",new String[]{ },"[Lorg/mortbay/jetty/Handler;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitLabel(L2);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L3);
                code.visitJumpStmt(IF_EQZ,3,-1,L49);
                code.visitStmt2R(ARRAY_LENGTH,14,3);
                code.visitJumpStmt(IF_GE,2,14,L49);
                code.visitLabel(L4);
                code.visitConstStmt(CONST_4,8, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L5);
                code.visitStmt3R(AGET_OBJECT,14,3,2);
                code.visitTypeStmt(INSTANCE_OF,14,14,"Lorg/mortbay/jetty/handler/ContextHandler;");
                code.visitJumpStmt(IF_EQZ,14,-1,L14);
                code.visitLabel(L6);
                code.visitConstStmt(CONST_4,14, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitTypeStmt(NEW_ARRAY,8,14,"[Lorg/mortbay/jetty/Handler;");
                code.visitLabel(L7);
                code.visitConstStmt(CONST_4,14, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitStmt3R(AGET_OBJECT,15,3,2);
                code.visitStmt3R(APUT_OBJECT,15,8,14);
                code.visitLabel(L8);
                code.visitConstStmt(CONST_4,10, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L9);
                code.visitStmt2R(ARRAY_LENGTH,14,8);
                code.visitJumpStmt(IF_GE,10,14,L48);
                code.visitLabel(L10);
                code.visitStmt3R(AGET_OBJECT,7,8,10);
                code.visitTypeStmt(CHECK_CAST,7,-1,"Lorg/mortbay/jetty/handler/ContextHandler;");
                code.visitLabel(L11);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7},new Method("Lorg/mortbay/jetty/handler/ContextHandler;","getContextPath",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitLabel(L12);
                code.visitJumpStmt(IF_EQZ,5,-1,L13);
                code.visitConstStmt(CONST_16,14, Integer.valueOf(44)); // int: 0x0000002c  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,14},new Method("Ljava/lang/String;","indexOf",new String[]{ "I"},"I"));
                code.visitStmt1R(MOVE_RESULT,14);
                code.visitJumpStmt(IF_GEZ,14,-1,L13);
                code.visitConstStmt(CONST_STRING,14,"*");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,14},new Method("Ljava/lang/String;","startsWith",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,14);
                code.visitJumpStmt(IF_EQZ,14,-1,L17);
                code.visitLabel(L13);
                code.visitTypeStmt(NEW_INSTANCE,14,-1,"Ljava/lang/IllegalArgumentException;");
                code.visitTypeStmt(NEW_INSTANCE,15,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 15},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,16,"Illegal context spec:");
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 15,16},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,15);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 15,5},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,15);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 15},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,15);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 14,15},new Method("Ljava/lang/IllegalArgumentException;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitStmt1R(THROW,14);
                code.visitLabel(L14);
                code.visitStmt3R(AGET_OBJECT,14,3,2);
                code.visitTypeStmt(INSTANCE_OF,14,14,"Lorg/mortbay/jetty/HandlerContainer;");
                code.visitJumpStmt(IF_EQZ,14,-1,L48);
                code.visitLabel(L15);
                code.visitStmt3R(AGET_OBJECT,5,3,2);
                code.visitTypeStmt(CHECK_CAST,5,-1,"Lorg/mortbay/jetty/HandlerContainer;");
                code.visitConstStmt(CONST_CLASS,14,new DexType("Lorg/mortbay/jetty/handler/ContextHandler;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 5,14},new Method("Lorg/mortbay/jetty/HandlerContainer;","getChildHandlersByClass",new String[]{ "Ljava/lang/Class;"},"[Lorg/mortbay/jetty/Handler;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitLabel(L16);
                code.visitJumpStmt(GOTO,-1,-1,L8);
                code.visitLabel(L17);
                code.visitConstStmt(CONST_STRING,14,"/");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,14},new Method("Ljava/lang/String;","startsWith",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,14);
                code.visitJumpStmt(IF_NEZ,14,-1,L19);
                code.visitLabel(L18);
                code.visitTypeStmt(NEW_INSTANCE,14,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 14},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_16,15, Integer.valueOf(47)); // int: 0x0000002f  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 14,15},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "C"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,14);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 14,5},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,14);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 14},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitLabel(L19);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Ljava/lang/String;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,14);
                code.visitConstStmt(CONST_4,15, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitJumpStmt(IF_LE,14,15,L22);
                code.visitLabel(L20);
                code.visitConstStmt(CONST_STRING,14,"/");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,14},new Method("Ljava/lang/String;","endsWith",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,14);
                code.visitJumpStmt(IF_EQZ,14,-1,L34);
                code.visitLabel(L21);
                code.visitTypeStmt(NEW_INSTANCE,14,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 14},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 14,5},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,14);
                code.visitConstStmt(CONST_STRING,15,"*");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 14,15},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,14);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 14},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitLabel(L22);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,5},new Method("Lorg/mortbay/jetty/servlet/PathMap;","get",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitLabel(L23);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7},new Method("Lorg/mortbay/jetty/handler/ContextHandler;","getVirtualHosts",new String[]{ },"[Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,13);
                code.visitLabel(L24);
                code.visitJumpStmt(IF_EQZ,13,-1,L40);
                code.visitStmt2R(ARRAY_LENGTH,14,13);
                code.visitJumpStmt(IF_LEZ,14,-1,L40);
                code.visitLabel(L25);
                code.visitTypeStmt(INSTANCE_OF,14,6,"Ljava/util/Map;");
                code.visitJumpStmt(IF_EQZ,14,-1,L37);
                code.visitLabel(L26);
                code.visitStmt2R(MOVE_OBJECT,0,6);
                code.visitTypeStmt(CHECK_CAST,0,-1,"Ljava/util/Map;");
                code.visitStmt2R(MOVE_OBJECT,9,0);
                code.visitLabel(L27);
                code.visitConstStmt(CONST_4,11, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L28);
                code.visitStmt2R(ARRAY_LENGTH,14,13);
                code.visitJumpStmt(IF_GE,11,14,L45);
                code.visitLabel(L29);
                code.visitStmt3R(AGET_OBJECT,12,13,11);
                code.visitLabel(L30);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 9,12},new Method("Ljava/util/Map;","get",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitLabel(L31);
                code.visitStmt3R(AGET_OBJECT,14,3,2);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 6,14},new Method("Lorg/mortbay/util/LazyList;","add",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitLabel(L32);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 9,12,6},new Method("Ljava/util/Map;","put",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitLabel(L33);
                code.visitStmt2R1N(ADD_INT_LIT8,11,11,1);
                code.visitJumpStmt(GOTO,-1,-1,L28);
                code.visitLabel(L34);
                code.visitConstStmt(CONST_STRING,14,"/*");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,14},new Method("Ljava/lang/String;","endsWith",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,14);
                code.visitJumpStmt(IF_NEZ,14,-1,L22);
                code.visitLabel(L35);
                code.visitTypeStmt(NEW_INSTANCE,14,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 14},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 14,5},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,14);
                code.visitConstStmt(CONST_STRING,15,"/*");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 14,15},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,14);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 14},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitLabel(L36);
                code.visitJumpStmt(GOTO,-1,-1,L22);
                code.visitLabel(L37);
                code.visitTypeStmt(NEW_INSTANCE,9,-1,"Ljava/util/HashMap;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 9},new Method("Ljava/util/HashMap;","<init>",new String[]{ },"V"));
                code.visitLabel(L38);
                code.visitConstStmt(CONST_STRING,14,"*");
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 9,14,6},new Method("Ljava/util/Map;","put",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitLabel(L39);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,5,9},new Method("Lorg/mortbay/jetty/servlet/PathMap;","put",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitJumpStmt(GOTO,-1,-1,L27);
                code.visitLabel(L40);
                code.visitTypeStmt(INSTANCE_OF,14,6,"Ljava/util/Map;");
                code.visitJumpStmt(IF_EQZ,14,-1,L46);
                code.visitLabel(L41);
                code.visitStmt2R(MOVE_OBJECT,0,6);
                code.visitTypeStmt(CHECK_CAST,0,-1,"Ljava/util/Map;");
                code.visitStmt2R(MOVE_OBJECT,9,0);
                code.visitLabel(L42);
                code.visitConstStmt(CONST_STRING,14,"*");
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 9,14},new Method("Ljava/util/Map;","get",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitLabel(L43);
                code.visitStmt3R(AGET_OBJECT,14,3,2);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 6,14},new Method("Lorg/mortbay/util/LazyList;","add",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitLabel(L44);
                code.visitConstStmt(CONST_STRING,14,"*");
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 9,14,6},new Method("Ljava/util/Map;","put",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitLabel(L45);
                code.visitStmt2R1N(ADD_INT_LIT8,10,10,1);
                code.visitJumpStmt(GOTO_16,-1,-1,L9);
                code.visitLabel(L46);
                code.visitStmt3R(AGET_OBJECT,14,3,2);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 6,14},new Method("Lorg/mortbay/util/LazyList;","add",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitLabel(L47);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,5,6},new Method("Lorg/mortbay/jetty/servlet/PathMap;","put",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitJumpStmt(GOTO,-1,-1,L45);
                code.visitLabel(L48);
                code.visitStmt2R1N(ADD_INT_LIT8,2,2,1);
                code.visitJumpStmt(GOTO_16,-1,-1,L3);
                code.visitLabel(L49);
                code.visitStmt2R(MOVE_OBJECT,0,4);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,17);
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/jetty/handler/ContextHandlerCollection;","_contextMap","Lorg/mortbay/jetty/servlet/PathMap;"));
                code.visitLabel(L50);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m007_setContextClass(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/handler/ContextHandlerCollection;","setContextClass",new String[]{ "Ljava/lang/Class;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"contextClass");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(292,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(293,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(294,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(295,L3);
                code.visitLabel(L0);
                code.visitJumpStmt(IF_EQZ,2,-1,L1);
                code.visitConstStmt(CONST_CLASS,0,new DexType("Lorg/mortbay/jetty/handler/ContextHandler;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,2},new Method("Ljava/lang/Class;","isAssignableFrom",new String[]{ "Ljava/lang/Class;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_NEZ,0,-1,L2);
                code.visitLabel(L1);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/lang/IllegalArgumentException;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/lang/IllegalArgumentException;","<init>",new String[]{ },"V"));
                code.visitStmt1R(THROW,0);
                code.visitLabel(L2);
                code.visitFieldStmt(IPUT_OBJECT,2,1,new Field("Lorg/mortbay/jetty/handler/ContextHandlerCollection;","_contextClass","Ljava/lang/Class;"));
                code.visitLabel(L3);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m008_setHandlers(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/handler/ContextHandlerCollection;","setHandlers",new String[]{ "[Lorg/mortbay/jetty/Handler;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"handlers");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(146,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(147,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(148,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(149,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(150,L4);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/jetty/handler/ContextHandlerCollection;","_contextMap","Lorg/mortbay/jetty/servlet/PathMap;"));
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_SUPER,new int[]{ 1,2},new Method("Lorg/mortbay/jetty/handler/HandlerCollection;","setHandlers",new String[]{ "[Lorg/mortbay/jetty/Handler;"},"V"));
                code.visitLabel(L2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Lorg/mortbay/jetty/handler/ContextHandlerCollection;","isStarted",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_EQZ,0,-1,L4);
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Lorg/mortbay/jetty/handler/ContextHandlerCollection;","mapContexts",new String[]{ },"V"));
                code.visitLabel(L4);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
