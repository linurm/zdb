package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0245_org_mortbay_jetty_handler_ContextHandler {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(ACC_PUBLIC,"Lorg/mortbay/jetty/handler/ContextHandler;","Lorg/mortbay/jetty/handler/HandlerWrapper;",new String[]{ "Lorg/mortbay/util/Attributes;","Lorg/mortbay/jetty/Server$Graceful;"});
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("ContextHandler.java");
        if(cv!=null){
            DexAnnotationVisitor av00 = cv.visitAnnotation("Ldalvik/annotation/MemberClasses;", Visibility.SYSTEM);
            if(av00 != null) {
                {
                    DexAnnotationVisitor av01 = av00.visitArray("value");
                    if(av01 != null) {
                        av01.visit(null, new DexType("Lorg/mortbay/jetty/handler/ContextHandler$SContext;"));
                        av01.visitEnd();
                    }
                }
                av00.visitEnd();
            }
        }
        f000_MANAGED_ATTRIBUTES(cv);
        f001___context(cv);
        f002__allowNullPathInfo(cv);
        f003__attributes(cv);
        f004__baseResource(cv);
        f005__classLoader(cv);
        f006__compactPath(cv);
        f007__connectors(cv);
        f008__contextAttributeListeners(cv);
        f009__contextAttributes(cv);
        f010__contextListeners(cv);
        f011__contextPath(cv);
        f012__displayName(cv);
        f013__errorHandler(cv);
        f014__eventListeners(cv);
        f015__initParams(cv);
        f016__localeEncodingMap(cv);
        f017__logger(cv);
        f018__managedAttributes(cv);
        f019__maxFormContentSize(cv);
        f020__mimeTypes(cv);
        f021__requestAttributeListeners(cv);
        f022__requestListeners(cv);
        f023__scontext(cv);
        f024__shutdown(cv);
        f025__vhosts(cv);
        f026__welcomeFiles(cv);
        m000__clinit_(cv);
        m001__init_(cv);
        m002__init_(cv);
        m003__init_(cv);
        m004__init_(cv);
        m005_access$000(cv);
        m006_access$100(cv);
        m007_access$200(cv);
        m008_access$300(cv);
        m009_access$400(cv);
        m010_access$500(cv);
        m011_access$600(cv);
        m012_getCurrentContext(cv);
        m013_normalizeHostname(cv);
        m014_setManagedAttribute(cv);
        m015_addEventListener(cv);
        m016_addLocaleEncoding(cv);
        m017_clearAttributes(cv);
        m018_doStart(cv);
        m019_doStop(cv);
        m020_getAllowNullPathInfo(cv);
        m021_getAttribute(cv);
        m022_getAttributeNames(cv);
        m023_getAttributes(cv);
        m024_getBaseResource(cv);
        m025_getClassLoader(cv);
        m026_getClassPath(cv);
        m027_getConnectorNames(cv);
        m028_getContextPath(cv);
        m029_getDisplayName(cv);
        m030_getErrorHandler(cv);
        m031_getEventListeners(cv);
        m032_getHosts(cv);
        m033_getInitParameter(cv);
        m034_getInitParameterNames(cv);
        m035_getInitParams(cv);
        m036_getLocaleEncoding(cv);
        m037_getMaxFormContentSize(cv);
        m038_getMimeTypes(cv);
        m039_getResource(cv);
        m040_getResourceBase(cv);
        m041_getResourcePaths(cv);
        m042_getServletContext(cv);
        m043_getVirtualHosts(cv);
        m044_getWelcomeFiles(cv);
        m045_handle(cv);
        m046_isCompactPath(cv);
        m047_isProtectedTarget(cv);
        m048_isShutdown(cv);
        m049_loadClass(cv);
        m050_removeAttribute(cv);
        m051_setAllowNullPathInfo(cv);
        m052_setAttribute(cv);
        m053_setAttributes(cv);
        m054_setBaseResource(cv);
        m055_setClassLoader(cv);
        m056_setCompactPath(cv);
        m057_setConnectorNames(cv);
        m058_setContextPath(cv);
        m059_setDisplayName(cv);
        m060_setErrorHandler(cv);
        m061_setEventListeners(cv);
        m062_setHosts(cv);
        m063_setInitParams(cv);
        m064_setMaxFormContentSize(cv);
        m065_setMimeTypes(cv);
        m066_setResourceBase(cv);
        m067_setServer(cv);
        m068_setShutdown(cv);
        m069_setVirtualHosts(cv);
        m070_setWelcomeFiles(cv);
        m071_startContext(cv);
        m072_toString(cv);
    }
    public static void f000_MANAGED_ATTRIBUTES(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/handler/ContextHandler;","MANAGED_ATTRIBUTES","Ljava/lang/String;"), "org.mortbay.jetty.servlet.ManagedAttributes");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f001___context(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE|ACC_STATIC, new Field("Lorg/mortbay/jetty/handler/ContextHandler;","__context","Ljava/lang/ThreadLocal;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f002__allowNullPathInfo(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/handler/ContextHandler;","_allowNullPathInfo","Z"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f003__attributes(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/handler/ContextHandler;","_attributes","Lorg/mortbay/util/AttributesMap;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f004__baseResource(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/handler/ContextHandler;","_baseResource","Lorg/mortbay/resource/Resource;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f005__classLoader(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/handler/ContextHandler;","_classLoader","Ljava/lang/ClassLoader;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f006__compactPath(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/handler/ContextHandler;","_compactPath","Z"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f007__connectors(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/handler/ContextHandler;","_connectors","Ljava/util/Set;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f008__contextAttributeListeners(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/handler/ContextHandler;","_contextAttributeListeners","Ljava/lang/Object;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f009__contextAttributes(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/handler/ContextHandler;","_contextAttributes","Lorg/mortbay/util/AttributesMap;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f010__contextListeners(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/handler/ContextHandler;","_contextListeners","Ljava/lang/Object;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f011__contextPath(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/handler/ContextHandler;","_contextPath","Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f012__displayName(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/handler/ContextHandler;","_displayName","Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f013__errorHandler(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/handler/ContextHandler;","_errorHandler","Lorg/mortbay/jetty/handler/ErrorHandler;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f014__eventListeners(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/handler/ContextHandler;","_eventListeners","[Ljava/util/EventListener;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f015__initParams(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/handler/ContextHandler;","_initParams","Ljava/util/Map;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f016__localeEncodingMap(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/handler/ContextHandler;","_localeEncodingMap","Ljava/util/Map;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f017__logger(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/handler/ContextHandler;","_logger","Lorg/mortbay/log/Logger;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f018__managedAttributes(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/handler/ContextHandler;","_managedAttributes","Ljava/util/Set;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f019__maxFormContentSize(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/handler/ContextHandler;","_maxFormContentSize","I"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f020__mimeTypes(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/handler/ContextHandler;","_mimeTypes","Lorg/mortbay/jetty/MimeTypes;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f021__requestAttributeListeners(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/handler/ContextHandler;","_requestAttributeListeners","Ljava/lang/Object;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f022__requestListeners(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/handler/ContextHandler;","_requestListeners","Ljava/lang/Object;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f023__scontext(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PROTECTED, new Field("Lorg/mortbay/jetty/handler/ContextHandler;","_scontext","Lorg/mortbay/jetty/handler/ContextHandler$SContext;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f024__shutdown(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/handler/ContextHandler;","_shutdown","Z"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f025__vhosts(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/handler/ContextHandler;","_vhosts","[Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f026__welcomeFiles(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/handler/ContextHandler;","_welcomeFiles","[Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void m000__clinit_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_STATIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/jetty/handler/ContextHandler;","<clinit>",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(1);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(85,L0);
                code.visitLabel(L0);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/lang/ThreadLocal;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/lang/ThreadLocal;","<init>",new String[]{ },"V"));
                code.visitFieldStmt(SPUT_OBJECT,0,-1,new Field("Lorg/mortbay/jetty/handler/ContextHandler;","__context","Ljava/lang/ThreadLocal;"));
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/jetty/handler/ContextHandler;","<init>",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(135,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(106,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(120,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(121,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(136,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(137,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(138,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(139,L7);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2},new Method("Lorg/mortbay/jetty/handler/HandlerWrapper;","<init>",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitConstStmt(CONST_STRING,0,"/");
                code.visitFieldStmt(IPUT_OBJECT,0,2,new Field("Lorg/mortbay/jetty/handler/ContextHandler;","_contextPath","Ljava/lang/String;"));
                code.visitLabel(L2);
                code.visitConstStmt(CONST_STRING,0,"org.mortbay.jetty.Request.maxFormContentSize");
                code.visitConstStmt(CONST,1, Integer.valueOf(200000)); // int: 0x00030d40  float:0.000000
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0,1},new Method("Ljava/lang/Integer;","getInteger",new String[]{ "Ljava/lang/String;","I"},"Ljava/lang/Integer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/lang/Integer;","intValue",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitFieldStmt(IPUT,0,2,new Field("Lorg/mortbay/jetty/handler/ContextHandler;","_maxFormContentSize","I"));
                code.visitLabel(L3);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT_BOOLEAN,0,2,new Field("Lorg/mortbay/jetty/handler/ContextHandler;","_compactPath","Z"));
                code.visitLabel(L4);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Lorg/mortbay/jetty/handler/ContextHandler$SContext;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,2},new Method("Lorg/mortbay/jetty/handler/ContextHandler$SContext;","<init>",new String[]{ "Lorg/mortbay/jetty/handler/ContextHandler;"},"V"));
                code.visitFieldStmt(IPUT_OBJECT,0,2,new Field("Lorg/mortbay/jetty/handler/ContextHandler;","_scontext","Lorg/mortbay/jetty/handler/ContextHandler$SContext;"));
                code.visitLabel(L5);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Lorg/mortbay/util/AttributesMap;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Lorg/mortbay/util/AttributesMap;","<init>",new String[]{ },"V"));
                code.visitFieldStmt(IPUT_OBJECT,0,2,new Field("Lorg/mortbay/jetty/handler/ContextHandler;","_attributes","Lorg/mortbay/util/AttributesMap;"));
                code.visitLabel(L6);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/util/HashMap;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/util/HashMap;","<init>",new String[]{ },"V"));
                code.visitFieldStmt(IPUT_OBJECT,0,2,new Field("Lorg/mortbay/jetty/handler/ContextHandler;","_initParams","Ljava/util/Map;"));
                code.visitLabel(L7);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m002__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/jetty/handler/ContextHandler;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"contextPath");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(159,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(160,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(161,L2);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Lorg/mortbay/jetty/handler/ContextHandler;","<init>",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Lorg/mortbay/jetty/handler/ContextHandler;","setContextPath",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L2);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m003__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/jetty/handler/ContextHandler;","<init>",new String[]{ "Lorg/mortbay/jetty/HandlerContainer;","Ljava/lang/String;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"parent");
                ddv.visitParameterName(1,"contextPath");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(169,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(170,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(171,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(172,L3);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Lorg/mortbay/jetty/handler/ContextHandler;","<init>",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,2},new Method("Lorg/mortbay/jetty/handler/ContextHandler;","setContextPath",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L2);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 1,0},new Method("Lorg/mortbay/jetty/HandlerContainer;","addHandler",new String[]{ "Lorg/mortbay/jetty/Handler;"},"V"));
                code.visitLabel(L3);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m004__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/jetty/handler/ContextHandler;","<init>",new String[]{ "Lorg/mortbay/jetty/handler/ContextHandler$SContext;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"context");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(147,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(106,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(120,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(121,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(148,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(149,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(150,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(151,L7);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2},new Method("Lorg/mortbay/jetty/handler/HandlerWrapper;","<init>",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitConstStmt(CONST_STRING,0,"/");
                code.visitFieldStmt(IPUT_OBJECT,0,2,new Field("Lorg/mortbay/jetty/handler/ContextHandler;","_contextPath","Ljava/lang/String;"));
                code.visitLabel(L2);
                code.visitConstStmt(CONST_STRING,0,"org.mortbay.jetty.Request.maxFormContentSize");
                code.visitConstStmt(CONST,1, Integer.valueOf(200000)); // int: 0x00030d40  float:0.000000
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0,1},new Method("Ljava/lang/Integer;","getInteger",new String[]{ "Ljava/lang/String;","I"},"Ljava/lang/Integer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/lang/Integer;","intValue",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitFieldStmt(IPUT,0,2,new Field("Lorg/mortbay/jetty/handler/ContextHandler;","_maxFormContentSize","I"));
                code.visitLabel(L3);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT_BOOLEAN,0,2,new Field("Lorg/mortbay/jetty/handler/ContextHandler;","_compactPath","Z"));
                code.visitLabel(L4);
                code.visitFieldStmt(IPUT_OBJECT,3,2,new Field("Lorg/mortbay/jetty/handler/ContextHandler;","_scontext","Lorg/mortbay/jetty/handler/ContextHandler$SContext;"));
                code.visitLabel(L5);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Lorg/mortbay/util/AttributesMap;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Lorg/mortbay/util/AttributesMap;","<init>",new String[]{ },"V"));
                code.visitFieldStmt(IPUT_OBJECT,0,2,new Field("Lorg/mortbay/jetty/handler/ContextHandler;","_attributes","Lorg/mortbay/util/AttributesMap;"));
                code.visitLabel(L6);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/util/HashMap;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/util/HashMap;","<init>",new String[]{ },"V"));
                code.visitFieldStmt(IPUT_OBJECT,0,2,new Field("Lorg/mortbay/jetty/handler/ContextHandler;","_initParams","Ljava/util/Map;"));
                code.visitLabel(L7);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m005_access$000(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_STATIC|ACC_SYNTHETIC, new Method("Lorg/mortbay/jetty/handler/ContextHandler;","access$000",new String[]{ "Lorg/mortbay/jetty/handler/ContextHandler;"},"Lorg/mortbay/jetty/MimeTypes;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"x0");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(83,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/handler/ContextHandler;","_mimeTypes","Lorg/mortbay/jetty/MimeTypes;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m006_access$100(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_STATIC|ACC_SYNTHETIC, new Method("Lorg/mortbay/jetty/handler/ContextHandler;","access$100",new String[]{ "Lorg/mortbay/jetty/handler/ContextHandler;"},"Lorg/mortbay/log/Logger;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"x0");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(83,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/handler/ContextHandler;","_logger","Lorg/mortbay/log/Logger;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m007_access$200(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_STATIC|ACC_SYNTHETIC, new Method("Lorg/mortbay/jetty/handler/ContextHandler;","access$200",new String[]{ "Lorg/mortbay/jetty/handler/ContextHandler;"},"Lorg/mortbay/util/AttributesMap;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"x0");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(83,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/handler/ContextHandler;","_contextAttributes","Lorg/mortbay/util/AttributesMap;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m008_access$300(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_STATIC|ACC_SYNTHETIC, new Method("Lorg/mortbay/jetty/handler/ContextHandler;","access$300",new String[]{ "Lorg/mortbay/jetty/handler/ContextHandler;"},"Lorg/mortbay/util/AttributesMap;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"x0");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(83,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/handler/ContextHandler;","_attributes","Lorg/mortbay/util/AttributesMap;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m009_access$400(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_STATIC|ACC_SYNTHETIC, new Method("Lorg/mortbay/jetty/handler/ContextHandler;","access$400",new String[]{ "Lorg/mortbay/jetty/handler/ContextHandler;","Ljava/lang/String;","Ljava/lang/Object;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"x0");
                ddv.visitParameterName(1,"x1");
                ddv.visitParameterName(2,"x2");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(83,L0);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1,2},new Method("Lorg/mortbay/jetty/handler/ContextHandler;","setManagedAttribute",new String[]{ "Ljava/lang/String;","Ljava/lang/Object;"},"V"));
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m010_access$500(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_STATIC|ACC_SYNTHETIC, new Method("Lorg/mortbay/jetty/handler/ContextHandler;","access$500",new String[]{ "Lorg/mortbay/jetty/handler/ContextHandler;"},"Ljava/lang/Object;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"x0");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(83,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/handler/ContextHandler;","_contextAttributeListeners","Ljava/lang/Object;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m011_access$600(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_STATIC|ACC_SYNTHETIC, new Method("Lorg/mortbay/jetty/handler/ContextHandler;","access$600",new String[]{ "Lorg/mortbay/jetty/handler/ContextHandler;"},"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"x0");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(83,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/handler/ContextHandler;","_contextPath","Ljava/lang/String;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m012_getCurrentContext(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Lorg/mortbay/jetty/handler/ContextHandler;","getCurrentContext",new String[]{ },"Lorg/mortbay/jetty/handler/ContextHandler$SContext;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(97,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(98,L1);
                ddv.visitStartLocal(0,L1,"context","Lorg/mortbay/jetty/handler/ContextHandler$SContext;",null);
                code.visitLabel(L0);
                code.visitFieldStmt(SGET_OBJECT,1,-1,new Field("Lorg/mortbay/jetty/handler/ContextHandler;","__context","Ljava/lang/ThreadLocal;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/lang/ThreadLocal;","get",new String[]{ },"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitTypeStmt(CHECK_CAST,0,-1,"Lorg/mortbay/jetty/handler/ContextHandler$SContext;");
                code.visitLabel(L1);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m013_normalizeHostname(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PRIVATE, new Method("Lorg/mortbay/jetty/handler/ContextHandler;","normalizeHostname",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"host");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(1580,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(1581,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(1586,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(1583,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(1584,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(1586,L5);
                code.visitLabel(L0);
                code.visitJumpStmt(IF_NEZ,4,-1,L3);
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L2);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitLabel(L3);
                code.visitConstStmt(CONST_STRING,0,".");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,0},new Method("Ljava/lang/String;","endsWith",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                DexLabel L6=new DexLabel();
                code.visitJumpStmt(IF_EQZ,0,-1,L6);
                code.visitLabel(L4);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Ljava/lang/String;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitStmt2R(SUB_INT_2ADDR,1,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,0,1},new Method("Ljava/lang/String;","substring",new String[]{ "I","I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitLabel(L6);
                code.visitStmt2R(MOVE_OBJECT,0,4);
                code.visitLabel(L5);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m014_setManagedAttribute(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PRIVATE, new Method("Lorg/mortbay/jetty/handler/ContextHandler;","setManagedAttribute",new String[]{ "Ljava/lang/String;","Ljava/lang/Object;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"name");
                ddv.visitParameterName(1,"value");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(886,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(888,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(889,L2);
                ddv.visitStartLocal(0,L2,"o","Ljava/lang/Object;",null);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(890,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(891,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(892,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(894,L6);
                ddv.visitEndLocal(0,L6);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/jetty/handler/ContextHandler;","_managedAttributes","Ljava/util/Set;"));
                code.visitJumpStmt(IF_EQZ,1,-1,L6);
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/jetty/handler/ContextHandler;","_managedAttributes","Ljava/util/Set;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 1,3},new Method("Ljava/util/Set;","contains",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitJumpStmt(IF_EQZ,1,-1,L6);
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/jetty/handler/ContextHandler;","_scontext","Lorg/mortbay/jetty/handler/ContextHandler$SContext;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,3},new Method("Lorg/mortbay/jetty/handler/ContextHandler$SContext;","getAttribute",new String[]{ "Ljava/lang/String;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L2);
                code.visitJumpStmt(IF_EQZ,0,-1,L4);
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/jetty/handler/ContextHandler;","getServer",new String[]{ },"Lorg/mortbay/jetty/Server;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Lorg/mortbay/jetty/Server;","getContainer",new String[]{ },"Lorg/mortbay/component/Container;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,0},new Method("Lorg/mortbay/component/Container;","removeBean",new String[]{ "Ljava/lang/Object;"},"V"));
                code.visitLabel(L4);
                code.visitJumpStmt(IF_EQZ,4,-1,L6);
                code.visitLabel(L5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/jetty/handler/ContextHandler;","getServer",new String[]{ },"Lorg/mortbay/jetty/Server;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Lorg/mortbay/jetty/Server;","getContainer",new String[]{ },"Lorg/mortbay/component/Container;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,4},new Method("Lorg/mortbay/component/Container;","addBean",new String[]{ "Ljava/lang/Object;"},"V"));
                code.visitLabel(L6);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m015_addEventListener(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/handler/ContextHandler;","addEventListener",new String[]{ "Ljava/util/EventListener;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"listener");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(458,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(459,L1);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/jetty/handler/ContextHandler;","getEventListeners",new String[]{ },"[Ljava/util/EventListener;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitConstStmt(CONST_CLASS,1,new DexType("Ljava/util/EventListener;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0,3,1},new Method("Lorg/mortbay/util/LazyList;","addToArray",new String[]{ "[Ljava/lang/Object;","Ljava/lang/Object;","Ljava/lang/Class;"},"[Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitTypeStmt(CHECK_CAST,0,-1,"[Ljava/util/EventListener;");
                code.visitTypeStmt(CHECK_CAST,0,-1,"[Ljava/util/EventListener;");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,0},new Method("Lorg/mortbay/jetty/handler/ContextHandler;","setEventListeners",new String[]{ "[Ljava/util/EventListener;"},"V"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m016_addLocaleEncoding(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/handler/ContextHandler;","addLocaleEncoding",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"locale");
                ddv.visitParameterName(1,"encoding");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(1107,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(1108,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(1109,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(1110,L3);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/handler/ContextHandler;","_localeEncodingMap","Ljava/util/Map;"));
                code.visitJumpStmt(IF_NEZ,0,-1,L2);
                code.visitLabel(L1);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/util/HashMap;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/util/HashMap;","<init>",new String[]{ },"V"));
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/jetty/handler/ContextHandler;","_localeEncodingMap","Ljava/util/Map;"));
                code.visitLabel(L2);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/handler/ContextHandler;","_localeEncodingMap","Ljava/util/Map;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,2,3},new Method("Ljava/util/Map;","put",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitLabel(L3);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m017_clearAttributes(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/handler/ContextHandler;","clearAttributes",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(874,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(875,L1);
                ddv.visitStartLocal(0,L1,"e","Ljava/util/Enumeration;",null);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(877,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(878,L3);
                ddv.visitStartLocal(1,L3,"name","Ljava/lang/String;",null);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(880,L4);
                ddv.visitEndLocal(1,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(881,L5);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,2,3,new Field("Lorg/mortbay/jetty/handler/ContextHandler;","_attributes","Lorg/mortbay/util/AttributesMap;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/util/AttributesMap;","getAttributeNames",new String[]{ },"Ljava/util/Enumeration;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0},new Method("Ljava/util/Enumeration;","hasMoreElements",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitJumpStmt(IF_EQZ,2,-1,L4);
                code.visitLabel(L2);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0},new Method("Ljava/util/Enumeration;","nextElement",new String[]{ },"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitTypeStmt(CHECK_CAST,1,-1,"Ljava/lang/String;");
                code.visitLabel(L3);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 3,1,2},new Method("Lorg/mortbay/jetty/handler/ContextHandler;","setManagedAttribute",new String[]{ "Ljava/lang/String;","Ljava/lang/Object;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L1);
                code.visitLabel(L4);
                code.visitFieldStmt(IGET_OBJECT,2,3,new Field("Lorg/mortbay/jetty/handler/ContextHandler;","_attributes","Lorg/mortbay/util/AttributesMap;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/util/AttributesMap;","clearAttributes",new String[]{ },"V"));
                code.visitLabel(L5);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m018_doStart(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Lorg/mortbay/jetty/handler/ContextHandler;","doStart",new String[]{ },"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/lang/Exception;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(7);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L3=new DexLabel();
                ddv.visitPrologue(L3);
                ddv.visitLineNumber(487,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(488,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(490,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(491,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(492,L7);
                ddv.visitStartLocal(2,L7,"old_classloader","Ljava/lang/ClassLoader;",null);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(493,L8);
                ddv.visitStartLocal(1,L8,"current_thread","Ljava/lang/Thread;",null);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(495,L9);
                ddv.visitStartLocal(3,L9,"old_context","Lorg/mortbay/jetty/handler/ContextHandler$SContext;",null);
                ddv.visitLineNumber(500,L0);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(502,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(503,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(504,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(508,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(509,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(511,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(512,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(514,L17);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(515,L18);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(517,L19);
                ddv.visitLineNumber(523,L1);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(526,L20);
                DexLabel L21=new DexLabel();
                ddv.visitLineNumber(528,L21);
                DexLabel L22=new DexLabel();
                ddv.visitLineNumber(531,L22);
                DexLabel L23=new DexLabel();
                ddv.visitLineNumber(490,L23);
                ddv.visitEndLocal(1,L23);
                ddv.visitEndLocal(2,L23);
                ddv.visitEndLocal(3,L23);
                ddv.visitLineNumber(523,L2);
                ddv.visitRestartLocal(1,L2);
                ddv.visitRestartLocal(2,L2);
                ddv.visitRestartLocal(3,L2);
                DexLabel L24=new DexLabel();
                ddv.visitLineNumber(526,L24);
                DexLabel L25=new DexLabel();
                ddv.visitLineNumber(528,L25);
                DexLabel L26=new DexLabel();
                ddv.visitLineNumber(523,L26);
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,4,6,new Field("Lorg/mortbay/jetty/handler/ContextHandler;","_contextPath","Ljava/lang/String;"));
                code.visitJumpStmt(IF_NEZ,4,-1,L5);
                code.visitLabel(L4);
                code.visitTypeStmt(NEW_INSTANCE,4,-1,"Ljava/lang/IllegalStateException;");
                code.visitConstStmt(CONST_STRING,5,"Null contextPath");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 4,5},new Method("Ljava/lang/IllegalStateException;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitStmt1R(THROW,4);
                code.visitLabel(L5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Lorg/mortbay/jetty/handler/ContextHandler;","getDisplayName",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitJumpStmt(IF_NEZ,4,-1,L23);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Lorg/mortbay/jetty/handler/ContextHandler;","getContextPath",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                DexLabel L27=new DexLabel();
                code.visitLabel(L27);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 4},new Method("Lorg/mortbay/log/Log;","getLogger",new String[]{ "Ljava/lang/String;"},"Lorg/mortbay/log/Logger;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitFieldStmt(IPUT_OBJECT,4,6,new Field("Lorg/mortbay/jetty/handler/ContextHandler;","_logger","Lorg/mortbay/log/Logger;"));
                code.visitLabel(L6);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L7);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L8);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L9);
                code.visitTypeStmt(NEW_INSTANCE,4,-1,"Lorg/mortbay/util/AttributesMap;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 4},new Method("Lorg/mortbay/util/AttributesMap;","<init>",new String[]{ },"V"));
                code.visitFieldStmt(IPUT_OBJECT,4,6,new Field("Lorg/mortbay/jetty/handler/ContextHandler;","_contextAttributes","Lorg/mortbay/util/AttributesMap;"));
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,4,6,new Field("Lorg/mortbay/jetty/handler/ContextHandler;","_classLoader","Ljava/lang/ClassLoader;"));
                code.visitJumpStmt(IF_EQZ,4,-1,L13);
                code.visitLabel(L10);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Ljava/lang/Thread;","currentThread",new String[]{ },"Ljava/lang/Thread;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L11);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/lang/Thread;","getContextClassLoader",new String[]{ },"Ljava/lang/ClassLoader;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitLabel(L12);
                code.visitFieldStmt(IGET_OBJECT,4,6,new Field("Lorg/mortbay/jetty/handler/ContextHandler;","_classLoader","Ljava/lang/ClassLoader;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,4},new Method("Ljava/lang/Thread;","setContextClassLoader",new String[]{ "Ljava/lang/ClassLoader;"},"V"));
                code.visitLabel(L13);
                code.visitFieldStmt(IGET_OBJECT,4,6,new Field("Lorg/mortbay/jetty/handler/ContextHandler;","_mimeTypes","Lorg/mortbay/jetty/MimeTypes;"));
                code.visitJumpStmt(IF_NEZ,4,-1,L15);
                code.visitLabel(L14);
                code.visitTypeStmt(NEW_INSTANCE,4,-1,"Lorg/mortbay/jetty/MimeTypes;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 4},new Method("Lorg/mortbay/jetty/MimeTypes;","<init>",new String[]{ },"V"));
                code.visitFieldStmt(IPUT_OBJECT,4,6,new Field("Lorg/mortbay/jetty/handler/ContextHandler;","_mimeTypes","Lorg/mortbay/jetty/MimeTypes;"));
                code.visitLabel(L15);
                code.visitFieldStmt(SGET_OBJECT,4,-1,new Field("Lorg/mortbay/jetty/handler/ContextHandler;","__context","Ljava/lang/ThreadLocal;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Ljava/lang/ThreadLocal;","get",new String[]{ },"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitStmt2R(MOVE_OBJECT,0,4);
                code.visitTypeStmt(CHECK_CAST,0,-1,"Lorg/mortbay/jetty/handler/ContextHandler$SContext;");
                code.visitStmt2R(MOVE_OBJECT,3,0);
                code.visitLabel(L16);
                code.visitFieldStmt(SGET_OBJECT,4,-1,new Field("Lorg/mortbay/jetty/handler/ContextHandler;","__context","Ljava/lang/ThreadLocal;"));
                code.visitFieldStmt(IGET_OBJECT,5,6,new Field("Lorg/mortbay/jetty/handler/ContextHandler;","_scontext","Lorg/mortbay/jetty/handler/ContextHandler$SContext;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,5},new Method("Ljava/lang/ThreadLocal;","set",new String[]{ "Ljava/lang/Object;"},"V"));
                code.visitLabel(L17);
                code.visitFieldStmt(IGET_OBJECT,4,6,new Field("Lorg/mortbay/jetty/handler/ContextHandler;","_errorHandler","Lorg/mortbay/jetty/handler/ErrorHandler;"));
                code.visitJumpStmt(IF_NEZ,4,-1,L19);
                code.visitLabel(L18);
                code.visitTypeStmt(NEW_INSTANCE,4,-1,"Lorg/mortbay/jetty/handler/ErrorHandler;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 4},new Method("Lorg/mortbay/jetty/handler/ErrorHandler;","<init>",new String[]{ },"V"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,4},new Method("Lorg/mortbay/jetty/handler/ContextHandler;","setErrorHandler",new String[]{ "Lorg/mortbay/jetty/handler/ErrorHandler;"},"V"));
                code.visitLabel(L19);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Lorg/mortbay/jetty/handler/ContextHandler;","startContext",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitFieldStmt(SGET_OBJECT,4,-1,new Field("Lorg/mortbay/jetty/handler/ContextHandler;","__context","Ljava/lang/ThreadLocal;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,3},new Method("Ljava/lang/ThreadLocal;","set",new String[]{ "Ljava/lang/Object;"},"V"));
                code.visitLabel(L20);
                code.visitFieldStmt(IGET_OBJECT,4,6,new Field("Lorg/mortbay/jetty/handler/ContextHandler;","_classLoader","Ljava/lang/ClassLoader;"));
                code.visitJumpStmt(IF_EQZ,4,-1,L22);
                code.visitLabel(L21);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2},new Method("Ljava/lang/Thread;","setContextClassLoader",new String[]{ "Ljava/lang/ClassLoader;"},"V"));
                code.visitLabel(L22);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L23);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Lorg/mortbay/jetty/handler/ContextHandler;","getDisplayName",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitJumpStmt(GOTO,-1,-1,L27);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,4);
                code.visitFieldStmt(SGET_OBJECT,5,-1,new Field("Lorg/mortbay/jetty/handler/ContextHandler;","__context","Ljava/lang/ThreadLocal;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,3},new Method("Ljava/lang/ThreadLocal;","set",new String[]{ "Ljava/lang/Object;"},"V"));
                code.visitLabel(L24);
                code.visitFieldStmt(IGET_OBJECT,5,6,new Field("Lorg/mortbay/jetty/handler/ContextHandler;","_classLoader","Ljava/lang/ClassLoader;"));
                code.visitJumpStmt(IF_EQZ,5,-1,L26);
                code.visitLabel(L25);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2},new Method("Ljava/lang/Thread;","setContextClassLoader",new String[]{ "Ljava/lang/ClassLoader;"},"V"));
                code.visitLabel(L26);
                code.visitStmt1R(THROW,4);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m019_doStop(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Lorg/mortbay/jetty/handler/ContextHandler;","doStop",new String[]{ },"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/lang/Exception;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(12);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L3=new DexLabel();
                ddv.visitPrologue(L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(576,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(577,L5);
                ddv.visitStartLocal(6,L5,"old_classloader","Ljava/lang/ClassLoader;",null);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(579,L6);
                ddv.visitStartLocal(0,L6,"current_thread","Ljava/lang/Thread;",null);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(580,L7);
                ddv.visitStartLocal(7,L7,"old_context","Lorg/mortbay/jetty/handler/ContextHandler$SContext;",null);
                ddv.visitLineNumber(584,L0);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(586,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(587,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(588,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(591,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(594,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(596,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(597,L14);
                ddv.visitStartLocal(2,L14,"event","Ljavax/servlet/ServletContextEvent;",null);
                DexLabel L15=new DexLabel();
                ddv.visitStartLocal(3,L15,"i","I",null);
                DexLabel L16=new DexLabel();
                ddv.visitEndLocal(3,L16);
                ddv.visitStartLocal(4,L16,"i","I",null);
                DexLabel L17=new DexLabel();
                ddv.visitRestartLocal(3,L17);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(599,L18);
                ddv.visitEndLocal(4,L18);
                DexLabel L19=new DexLabel();
                ddv.visitRestartLocal(4,L19);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(603,L20);
                ddv.visitEndLocal(2,L20);
                ddv.visitEndLocal(3,L20);
                ddv.visitEndLocal(4,L20);
                DexLabel L21=new DexLabel();
                ddv.visitLineNumber(604,L21);
                DexLabel L22=new DexLabel();
                ddv.visitLineNumber(606,L22);
                DexLabel L23=new DexLabel();
                ddv.visitLineNumber(607,L23);
                ddv.visitStartLocal(1,L23,"e","Ljava/util/Enumeration;",null);
                DexLabel L24=new DexLabel();
                ddv.visitLineNumber(609,L24);
                DexLabel L25=new DexLabel();
                ddv.visitLineNumber(610,L25);
                ddv.visitStartLocal(5,L25,"name","Ljava/lang/String;",null);
                ddv.visitLineNumber(615,L2);
                ddv.visitEndLocal(1,L2);
                ddv.visitEndLocal(5,L2);
                DexLabel L26=new DexLabel();
                ddv.visitLineNumber(617,L26);
                DexLabel L27=new DexLabel();
                ddv.visitLineNumber(618,L27);
                DexLabel L28=new DexLabel();
                ddv.visitLineNumber(615,L28);
                DexLabel L29=new DexLabel();
                ddv.visitRestartLocal(1,L29);
                DexLabel L30=new DexLabel();
                ddv.visitLineNumber(617,L30);
                DexLabel L31=new DexLabel();
                ddv.visitLineNumber(618,L31);
                DexLabel L32=new DexLabel();
                ddv.visitLineNumber(621,L32);
                DexLabel L33=new DexLabel();
                ddv.visitLineNumber(622,L33);
                DexLabel L34=new DexLabel();
                ddv.visitLineNumber(623,L34);
                DexLabel L35=new DexLabel();
                ddv.visitLineNumber(624,L35);
                code.visitLabel(L3);
                code.visitConstStmt(CONST_4,10, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L4);
                code.visitConstStmt(CONST_4,6, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L5);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L6);
                code.visitFieldStmt(SGET_OBJECT,8,-1,new Field("Lorg/mortbay/jetty/handler/ContextHandler;","__context","Ljava/lang/ThreadLocal;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8},new Method("Ljava/lang/ThreadLocal;","get",new String[]{ },"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitTypeStmt(CHECK_CAST,7,-1,"Lorg/mortbay/jetty/handler/ContextHandler$SContext;");
                code.visitLabel(L7);
                code.visitFieldStmt(SGET_OBJECT,8,-1,new Field("Lorg/mortbay/jetty/handler/ContextHandler;","__context","Ljava/lang/ThreadLocal;"));
                code.visitFieldStmt(IGET_OBJECT,9,11,new Field("Lorg/mortbay/jetty/handler/ContextHandler;","_scontext","Lorg/mortbay/jetty/handler/ContextHandler$SContext;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8,9},new Method("Ljava/lang/ThreadLocal;","set",new String[]{ "Ljava/lang/Object;"},"V"));
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,8,11,new Field("Lorg/mortbay/jetty/handler/ContextHandler;","_classLoader","Ljava/lang/ClassLoader;"));
                code.visitJumpStmt(IF_EQZ,8,-1,L11);
                code.visitLabel(L8);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Ljava/lang/Thread;","currentThread",new String[]{ },"Ljava/lang/Thread;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L9);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/lang/Thread;","getContextClassLoader",new String[]{ },"Ljava/lang/ClassLoader;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitLabel(L10);
                code.visitFieldStmt(IGET_OBJECT,8,11,new Field("Lorg/mortbay/jetty/handler/ContextHandler;","_classLoader","Ljava/lang/ClassLoader;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,8},new Method("Ljava/lang/Thread;","setContextClassLoader",new String[]{ "Ljava/lang/ClassLoader;"},"V"));
                code.visitLabel(L11);
                code.visitMethodStmt(INVOKE_SUPER,new int[]{ 11},new Method("Lorg/mortbay/jetty/handler/HandlerWrapper;","doStop",new String[]{ },"V"));
                code.visitLabel(L12);
                code.visitFieldStmt(IGET_OBJECT,8,11,new Field("Lorg/mortbay/jetty/handler/ContextHandler;","_contextListeners","Ljava/lang/Object;"));
                code.visitJumpStmt(IF_EQZ,8,-1,L20);
                code.visitLabel(L13);
                code.visitTypeStmt(NEW_INSTANCE,2,-1,"Ljavax/servlet/ServletContextEvent;");
                code.visitFieldStmt(IGET_OBJECT,8,11,new Field("Lorg/mortbay/jetty/handler/ContextHandler;","_scontext","Lorg/mortbay/jetty/handler/ContextHandler$SContext;"));
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2,8},new Method("Ljavax/servlet/ServletContextEvent;","<init>",new String[]{ "Ljavax/servlet/ServletContext;"},"V"));
                code.visitLabel(L14);
                code.visitFieldStmt(IGET_OBJECT,8,11,new Field("Lorg/mortbay/jetty/handler/ContextHandler;","_contextListeners","Ljava/lang/Object;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 8},new Method("Lorg/mortbay/util/LazyList;","size",new String[]{ "Ljava/lang/Object;"},"I"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitLabel(L15);
                code.visitStmt2R(MOVE,4,3);
                code.visitLabel(L16);
                code.visitConstStmt(CONST_4,8, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitStmt3R(SUB_INT,3,4,8);
                code.visitLabel(L17);
                code.visitJumpStmt(IF_LEZ,4,-1,L20);
                code.visitLabel(L18);
                code.visitFieldStmt(IGET_OBJECT,8,11,new Field("Lorg/mortbay/jetty/handler/ContextHandler;","_contextListeners","Ljava/lang/Object;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 8,3},new Method("Lorg/mortbay/util/LazyList;","get",new String[]{ "Ljava/lang/Object;","I"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitTypeStmt(CHECK_CAST,8,-1,"Ljavax/servlet/ServletContextListener;");
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 8,2},new Method("Ljavax/servlet/ServletContextListener;","contextDestroyed",new String[]{ "Ljavax/servlet/ServletContextEvent;"},"V"));
                code.visitStmt2R(MOVE,4,3);
                code.visitLabel(L19);
                code.visitJumpStmt(GOTO,-1,-1,L16);
                code.visitLabel(L20);
                code.visitFieldStmt(IGET_OBJECT,8,11,new Field("Lorg/mortbay/jetty/handler/ContextHandler;","_errorHandler","Lorg/mortbay/jetty/handler/ErrorHandler;"));
                code.visitJumpStmt(IF_EQZ,8,-1,L22);
                code.visitLabel(L21);
                code.visitFieldStmt(IGET_OBJECT,8,11,new Field("Lorg/mortbay/jetty/handler/ContextHandler;","_errorHandler","Lorg/mortbay/jetty/handler/ErrorHandler;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8},new Method("Lorg/mortbay/jetty/handler/ErrorHandler;","stop",new String[]{ },"V"));
                code.visitLabel(L22);
                code.visitFieldStmt(IGET_OBJECT,8,11,new Field("Lorg/mortbay/jetty/handler/ContextHandler;","_scontext","Lorg/mortbay/jetty/handler/ContextHandler$SContext;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8},new Method("Lorg/mortbay/jetty/handler/ContextHandler$SContext;","getAttributeNames",new String[]{ },"Ljava/util/Enumeration;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L23);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 1},new Method("Ljava/util/Enumeration;","hasMoreElements",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,8);
                code.visitJumpStmt(IF_EQZ,8,-1,L29);
                code.visitLabel(L24);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 1},new Method("Ljava/util/Enumeration;","nextElement",new String[]{ },"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitTypeStmt(CHECK_CAST,5,-1,"Ljava/lang/String;");
                code.visitLabel(L25);
                code.visitConstStmt(CONST_4,8, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 11,5,8},new Method("Lorg/mortbay/jetty/handler/ContextHandler;","setManagedAttribute",new String[]{ "Ljava/lang/String;","Ljava/lang/Object;"},"V"));
                code.visitLabel(L1);
                code.visitJumpStmt(GOTO,-1,-1,L23);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,8);
                code.visitFieldStmt(SGET_OBJECT,9,-1,new Field("Lorg/mortbay/jetty/handler/ContextHandler;","__context","Ljava/lang/ThreadLocal;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9,7},new Method("Ljava/lang/ThreadLocal;","set",new String[]{ "Ljava/lang/Object;"},"V"));
                code.visitLabel(L26);
                code.visitFieldStmt(IGET_OBJECT,9,11,new Field("Lorg/mortbay/jetty/handler/ContextHandler;","_classLoader","Ljava/lang/ClassLoader;"));
                code.visitJumpStmt(IF_EQZ,9,-1,L28);
                code.visitLabel(L27);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,6},new Method("Ljava/lang/Thread;","setContextClassLoader",new String[]{ "Ljava/lang/ClassLoader;"},"V"));
                code.visitLabel(L28);
                code.visitStmt1R(THROW,8);
                code.visitLabel(L29);
                code.visitFieldStmt(SGET_OBJECT,8,-1,new Field("Lorg/mortbay/jetty/handler/ContextHandler;","__context","Ljava/lang/ThreadLocal;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8,7},new Method("Ljava/lang/ThreadLocal;","set",new String[]{ "Ljava/lang/Object;"},"V"));
                code.visitLabel(L30);
                code.visitFieldStmt(IGET_OBJECT,8,11,new Field("Lorg/mortbay/jetty/handler/ContextHandler;","_classLoader","Ljava/lang/ClassLoader;"));
                code.visitJumpStmt(IF_EQZ,8,-1,L32);
                code.visitLabel(L31);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,6},new Method("Ljava/lang/Thread;","setContextClassLoader",new String[]{ "Ljava/lang/ClassLoader;"},"V"));
                code.visitLabel(L32);
                code.visitFieldStmt(IGET_OBJECT,8,11,new Field("Lorg/mortbay/jetty/handler/ContextHandler;","_contextAttributes","Lorg/mortbay/util/AttributesMap;"));
                code.visitJumpStmt(IF_EQZ,8,-1,L34);
                code.visitLabel(L33);
                code.visitFieldStmt(IGET_OBJECT,8,11,new Field("Lorg/mortbay/jetty/handler/ContextHandler;","_contextAttributes","Lorg/mortbay/util/AttributesMap;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8},new Method("Lorg/mortbay/util/AttributesMap;","clearAttributes",new String[]{ },"V"));
                code.visitLabel(L34);
                code.visitFieldStmt(IPUT_OBJECT,10,11,new Field("Lorg/mortbay/jetty/handler/ContextHandler;","_contextAttributes","Lorg/mortbay/util/AttributesMap;"));
                code.visitLabel(L35);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m020_getAllowNullPathInfo(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/handler/ContextHandler;","getAllowNullPathInfo",new String[]{ },"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(186,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_BOOLEAN,0,1,new Field("Lorg/mortbay/jetty/handler/ContextHandler;","_allowNullPathInfo","Z"));
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m021_getAttribute(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/handler/ContextHandler;","getAttribute",new String[]{ "Ljava/lang/String;"},"Ljava/lang/Object;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"name");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(311,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/handler/ContextHandler;","_attributes","Lorg/mortbay/util/AttributesMap;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,2},new Method("Lorg/mortbay/util/AttributesMap;","getAttribute",new String[]{ "Ljava/lang/String;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m022_getAttributeNames(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/handler/ContextHandler;","getAttributeNames",new String[]{ },"Ljava/util/Enumeration;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(320,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/handler/ContextHandler;","_attributes","Lorg/mortbay/util/AttributesMap;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0},new Method("Lorg/mortbay/util/AttributesMap;","getAttributeNamesCopy",new String[]{ "Lorg/mortbay/util/Attributes;"},"Ljava/util/Enumeration;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m023_getAttributes(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/handler/ContextHandler;","getAttributes",new String[]{ },"Lorg/mortbay/util/Attributes;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(329,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/handler/ContextHandler;","_attributes","Lorg/mortbay/util/AttributesMap;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m024_getBaseResource(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/handler/ContextHandler;","getBaseResource",new String[]{ },"Lorg/mortbay/resource/Resource;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(951,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(952,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(953,L2);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/handler/ContextHandler;","_baseResource","Lorg/mortbay/resource/Resource;"));
                DexLabel L3=new DexLabel();
                code.visitJumpStmt(IF_NEZ,0,-1,L3);
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L2);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/handler/ContextHandler;","_baseResource","Lorg/mortbay/resource/Resource;"));
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m025_getClassLoader(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/handler/ContextHandler;","getClassLoader",new String[]{ },"Ljava/lang/ClassLoader;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(338,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/handler/ContextHandler;","_classLoader","Ljava/lang/ClassLoader;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m026_getClassPath(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/handler/ContextHandler;","getClassPath",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(10);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ "Ljava/io/IOException;"});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L3=new DexLabel();
                ddv.visitPrologue(L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(348,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(373,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(350,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(351,L7);
                ddv.visitStartLocal(4,L7,"loader","Ljava/net/URLClassLoader;",null);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(352,L8);
                ddv.visitStartLocal(6,L8,"urls","[Ljava/net/URL;",null);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(353,L9);
                ddv.visitStartLocal(0,L9,"classpath","Ljava/lang/StringBuffer;",null);
                DexLabel L10=new DexLabel();
                ddv.visitStartLocal(3,L10,"i","I",null);
                ddv.visitLineNumber(357,L0);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(358,L11);
                ddv.visitStartLocal(5,L11,"resource","Lorg/mortbay/resource/Resource;",null);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(359,L12);
                ddv.visitStartLocal(2,L12,"file","Ljava/io/File;",null);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(361,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(362,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(363,L15);
                ddv.visitLineNumber(353,L1);
                ddv.visitEndLocal(5,L1);
                ddv.visitEndLocal(2,L1);
                ddv.visitLineNumber(366,L2);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(368,L16);
                ddv.visitStartLocal(1,L16,"e","Ljava/io/IOException;",null);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(371,L17);
                ddv.visitEndLocal(1,L17);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(372,L18);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(373,L19);
                code.visitLabel(L3);
                code.visitConstStmt(CONST_4,8, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L4);
                code.visitFieldStmt(IGET_OBJECT,7,9,new Field("Lorg/mortbay/jetty/handler/ContextHandler;","_classLoader","Ljava/lang/ClassLoader;"));
                DexLabel L20=new DexLabel();
                code.visitJumpStmt(IF_EQZ,7,-1,L20);
                code.visitFieldStmt(IGET_OBJECT,7,9,new Field("Lorg/mortbay/jetty/handler/ContextHandler;","_classLoader","Ljava/lang/ClassLoader;"));
                code.visitTypeStmt(INSTANCE_OF,7,7,"Ljava/net/URLClassLoader;");
                code.visitJumpStmt(IF_NEZ,7,-1,L6);
                code.visitLabel(L20);
                code.visitStmt2R(MOVE_OBJECT,7,8);
                code.visitLabel(L5);
                code.visitStmt1R(RETURN_OBJECT,7);
                code.visitLabel(L6);
                code.visitFieldStmt(IGET_OBJECT,4,9,new Field("Lorg/mortbay/jetty/handler/ContextHandler;","_classLoader","Ljava/lang/ClassLoader;"));
                code.visitTypeStmt(CHECK_CAST,4,-1,"Ljava/net/URLClassLoader;");
                code.visitLabel(L7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Ljava/net/URLClassLoader;","getURLs",new String[]{ },"[Ljava/net/URL;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitLabel(L8);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/lang/StringBuffer;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/lang/StringBuffer;","<init>",new String[]{ },"V"));
                code.visitLabel(L9);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L10);
                code.visitStmt2R(ARRAY_LENGTH,7,6);
                code.visitJumpStmt(IF_GE,3,7,L17);
                code.visitLabel(L0);
                code.visitStmt3R(AGET_OBJECT,7,6,3);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 7},new Method("Lorg/mortbay/resource/Resource;","newResource",new String[]{ "Ljava/net/URL;"},"Lorg/mortbay/resource/Resource;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitLabel(L11);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Lorg/mortbay/resource/Resource;","getFile",new String[]{ },"Ljava/io/File;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitLabel(L12);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Ljava/io/File;","exists",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,7);
                code.visitJumpStmt(IF_EQZ,7,-1,L1);
                code.visitLabel(L13);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/lang/StringBuffer;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,7);
                code.visitJumpStmt(IF_LEZ,7,-1,L15);
                code.visitLabel(L14);
                code.visitFieldStmt(SGET_CHAR,7,-1,new Field("Ljava/io/File;","pathSeparatorChar","C"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,7},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "C"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L15);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Ljava/io/File;","getAbsolutePath",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,7},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L1);
                code.visitStmt2R1N(ADD_INT_LIT8,3,3,1);
                code.visitJumpStmt(GOTO,-1,-1,L10);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,7);
                code.visitStmt2R(MOVE_OBJECT,1,7);
                code.visitLabel(L16);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1},new Method("Lorg/mortbay/log/Log;","debug",new String[]{ "Ljava/lang/Throwable;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L1);
                code.visitLabel(L17);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/lang/StringBuffer;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,7);
                code.visitJumpStmt(IF_NEZ,7,-1,L19);
                code.visitStmt2R(MOVE_OBJECT,7,8);
                code.visitLabel(L18);
                code.visitJumpStmt(GOTO,-1,-1,L5);
                code.visitLabel(L19);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/lang/StringBuffer;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitJumpStmt(GOTO,-1,-1,L5);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m027_getConnectorNames(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/handler/ContextHandler;","getConnectorNames",new String[]{ },"[Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(283,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(284,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(286,L2);
                ddv.visitEndLocal(2,L2);
                DexLabel L3=new DexLabel();
                ddv.visitRestartLocal(2,L3);
                DexLabel L4=new DexLabel();
                ddv.visitEndLocal(2,L4);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/jetty/handler/ContextHandler;","_connectors","Ljava/util/Set;"));
                code.visitJumpStmt(IF_EQZ,0,-1,L1);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/jetty/handler/ContextHandler;","_connectors","Ljava/util/Set;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0},new Method("Ljava/util/Set;","size",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_NEZ,0,-1,L3);
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L2);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/jetty/handler/ContextHandler;","_connectors","Ljava/util/Set;"));
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/jetty/handler/ContextHandler;","_connectors","Ljava/util/Set;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 1},new Method("Ljava/util/Set;","size",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitTypeStmt(NEW_ARRAY,1,1,"[Ljava/lang/String;");
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,1},new Method("Ljava/util/Set;","toArray",new String[]{ "[Ljava/lang/Object;"},"[Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitLabel(L4);
                code.visitTypeStmt(CHECK_CAST,2,-1,"[Ljava/lang/String;");
                code.visitTypeStmt(CHECK_CAST,2,-1,"[Ljava/lang/String;");
                code.visitStmt2R(MOVE_OBJECT,0,2);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m028_getContextPath(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/handler/ContextHandler;","getContextPath",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(382,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/handler/ContextHandler;","_contextPath","Ljava/lang/String;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m029_getDisplayName(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/handler/ContextHandler;","getDisplayName",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(418,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/handler/ContextHandler;","_displayName","Ljava/lang/String;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m030_getErrorHandler(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/handler/ContextHandler;","getErrorHandler",new String[]{ },"Lorg/mortbay/jetty/handler/ErrorHandler;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(1036,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/handler/ContextHandler;","_errorHandler","Lorg/mortbay/jetty/handler/ErrorHandler;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m031_getEventListeners(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/handler/ContextHandler;","getEventListeners",new String[]{ },"[Ljava/util/EventListener;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(424,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/handler/ContextHandler;","_eventListeners","[Ljava/util/EventListener;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m032_getHosts(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/handler/ContextHandler;","getHosts",new String[]{ },"[Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(273,L0);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Lorg/mortbay/jetty/handler/ContextHandler;","getConnectorNames",new String[]{ },"[Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m033_getInitParameter(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/handler/ContextHandler;","getInitParameter",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"name");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(391,L0);
                DexLabel L1=new DexLabel();
                ddv.visitEndLocal(1,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/handler/ContextHandler;","_initParams","Ljava/util/Map;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,2},new Method("Ljava/util/Map;","get",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L1);
                code.visitTypeStmt(CHECK_CAST,1,-1,"Ljava/lang/String;");
                code.visitStmt1R(RETURN_OBJECT,1);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m034_getInitParameterNames(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/handler/ContextHandler;","getInitParameterNames",new String[]{ },"Ljava/util/Enumeration;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(400,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/handler/ContextHandler;","_initParams","Ljava/util/Map;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0},new Method("Ljava/util/Map;","keySet",new String[]{ },"Ljava/util/Set;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0},new Method("Ljava/util/Collections;","enumeration",new String[]{ "Ljava/util/Collection;"},"Ljava/util/Enumeration;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m035_getInitParams(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/handler/ContextHandler;","getInitParams",new String[]{ },"Ljava/util/Map;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(409,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/handler/ContextHandler;","_initParams","Ljava/util/Map;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m036_getLocaleEncoding(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/handler/ContextHandler;","getLocaleEncoding",new String[]{ "Ljava/util/Locale;"},"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"locale");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(1124,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(1125,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(1129,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(1126,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(1127,L4);
                ddv.visitStartLocal(0,L4,"encoding","Ljava/lang/String;",null);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(1128,L5);
                DexLabel L6=new DexLabel();
                ddv.visitEndLocal(0,L6);
                DexLabel L7=new DexLabel();
                ddv.visitRestartLocal(0,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(1129,L8);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,1,3,new Field("Lorg/mortbay/jetty/handler/ContextHandler;","_localeEncodingMap","Ljava/util/Map;"));
                code.visitJumpStmt(IF_NEZ,1,-1,L3);
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L2);
                code.visitStmt1R(RETURN_OBJECT,1);
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,1,3,new Field("Lorg/mortbay/jetty/handler/ContextHandler;","_localeEncodingMap","Ljava/util/Map;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Ljava/util/Locale;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 1,2},new Method("Ljava/util/Map;","get",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitTypeStmt(CHECK_CAST,0,-1,"Ljava/lang/String;");
                code.visitLabel(L4);
                code.visitJumpStmt(IF_NEZ,0,-1,L7);
                code.visitLabel(L5);
                code.visitFieldStmt(IGET_OBJECT,1,3,new Field("Lorg/mortbay/jetty/handler/ContextHandler;","_localeEncodingMap","Ljava/util/Map;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Ljava/util/Locale;","getLanguage",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 1,2},new Method("Ljava/util/Map;","get",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L6);
                code.visitTypeStmt(CHECK_CAST,0,-1,"Ljava/lang/String;");
                code.visitLabel(L7);
                code.visitStmt2R(MOVE_OBJECT,1,0);
                code.visitLabel(L8);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m037_getMaxFormContentSize(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/handler/ContextHandler;","getMaxFormContentSize",new String[]{ },"I"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(1055,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET,0,1,new Field("Lorg/mortbay/jetty/handler/ContextHandler;","_maxFormContentSize","I"));
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m038_getMimeTypes(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/handler/ContextHandler;","getMimeTypes",new String[]{ },"Lorg/mortbay/jetty/MimeTypes;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(999,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/handler/ContextHandler;","_mimeTypes","Lorg/mortbay/jetty/MimeTypes;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m039_getResource(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/handler/ContextHandler;","getResource",new String[]{ "Ljava/lang/String;"},"Lorg/mortbay/resource/Resource;"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/net/MalformedURLException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(6);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ "Ljava/lang/Exception;"});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"path");
                DexLabel L3=new DexLabel();
                ddv.visitPrologue(L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(1137,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(1138,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(1140,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(1154,L7);
                ddv.visitLineNumber(1145,L0);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(1146,L8);
                DexLabel L9=new DexLabel();
                ddv.visitStartLocal(1,L9,"resource","Lorg/mortbay/resource/Resource;",null);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(1147,L10);
                ddv.visitLineNumber(1149,L2);
                ddv.visitEndLocal(1,L2);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(1151,L11);
                ddv.visitStartLocal(0,L11,"e","Ljava/lang/Exception;",null);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(1154,L12);
                code.visitLabel(L3);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L4);
                code.visitJumpStmt(IF_EQZ,5,-1,L5);
                code.visitConstStmt(CONST_STRING,2,"/");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,2},new Method("Ljava/lang/String;","startsWith",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitJumpStmt(IF_NEZ,2,-1,L6);
                code.visitLabel(L5);
                code.visitTypeStmt(NEW_INSTANCE,2,-1,"Ljava/net/MalformedURLException;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2,5},new Method("Ljava/net/MalformedURLException;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitStmt1R(THROW,2);
                code.visitLabel(L6);
                code.visitFieldStmt(IGET_OBJECT,2,4,new Field("Lorg/mortbay/jetty/handler/ContextHandler;","_baseResource","Lorg/mortbay/resource/Resource;"));
                code.visitJumpStmt(IF_NEZ,2,-1,L0);
                code.visitStmt2R(MOVE_OBJECT,2,3);
                code.visitLabel(L7);
                code.visitStmt1R(RETURN_OBJECT,2);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 5},new Method("Lorg/mortbay/util/URIUtil;","canonicalPath",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitLabel(L8);
                code.visitFieldStmt(IGET_OBJECT,2,4,new Field("Lorg/mortbay/jetty/handler/ContextHandler;","_baseResource","Lorg/mortbay/resource/Resource;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,5},new Method("Lorg/mortbay/resource/Resource;","addPath",new String[]{ "Ljava/lang/String;"},"Lorg/mortbay/resource/Resource;"));
                code.visitLabel(L1);
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L9);
                code.visitStmt2R(MOVE_OBJECT,2,1);
                code.visitLabel(L10);
                code.visitJumpStmt(GOTO,-1,-1,L7);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,2);
                code.visitStmt2R(MOVE_OBJECT,0,2);
                code.visitLabel(L11);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0},new Method("Lorg/mortbay/log/Log;","ignore",new String[]{ "Ljava/lang/Throwable;"},"V"));
                code.visitStmt2R(MOVE_OBJECT,2,3);
                code.visitLabel(L12);
                code.visitJumpStmt(GOTO,-1,-1,L7);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m040_getResourceBase(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/handler/ContextHandler;","getResourceBase",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(962,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(963,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(964,L2);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/handler/ContextHandler;","_baseResource","Lorg/mortbay/resource/Resource;"));
                DexLabel L3=new DexLabel();
                code.visitJumpStmt(IF_NEZ,0,-1,L3);
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L2);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/handler/ContextHandler;","_baseResource","Lorg/mortbay/resource/Resource;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/lang/Object;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m041_getResourcePaths(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/handler/ContextHandler;","getResourcePaths",new String[]{ "Ljava/lang/String;"},"Ljava/util/Set;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(9);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ "Ljava/lang/Exception;"});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"path");
                DexLabel L3=new DexLabel();
                ddv.visitPrologue(L3);
                ddv.visitLineNumber(1165,L0);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(1166,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(1168,L5);
                ddv.visitStartLocal(3,L5,"resource","Lorg/mortbay/resource/Resource;",null);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(1170,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(1171,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(1173,L8);
                ddv.visitRestartLocal(8,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(1174,L9);
                ddv.visitStartLocal(2,L9,"l","[Ljava/lang/String;",null);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(1176,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(1177,L11);
                ddv.visitStartLocal(4,L11,"set","Ljava/util/HashSet;",null);
                DexLabel L12=new DexLabel();
                ddv.visitStartLocal(1,L12,"i","I",null);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(1178,L13);
                ddv.visitLineNumber(1177,L1);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(1187,L14);
                ddv.visitEndLocal(3,L14);
                ddv.visitEndLocal(2,L14);
                ddv.visitEndLocal(4,L14);
                ddv.visitEndLocal(1,L14);
                ddv.visitLineNumber(1183,L2);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(1185,L15);
                ddv.visitStartLocal(0,L15,"e","Ljava/lang/Exception;",null);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(1187,L16);
                ddv.visitEndLocal(0,L16);
                code.visitLabel(L3);
                code.visitConstStmt(CONST_STRING,5,"/");
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 8},new Method("Lorg/mortbay/util/URIUtil;","canonicalPath",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitLabel(L4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7,8},new Method("Lorg/mortbay/jetty/handler/ContextHandler;","getResource",new String[]{ "Ljava/lang/String;"},"Lorg/mortbay/resource/Resource;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitLabel(L5);
                code.visitJumpStmt(IF_EQZ,3,-1,L16);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Lorg/mortbay/resource/Resource;","exists",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,5);
                code.visitJumpStmt(IF_EQZ,5,-1,L16);
                code.visitLabel(L6);
                code.visitConstStmt(CONST_STRING,5,"/");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8,5},new Method("Ljava/lang/String;","endsWith",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,5);
                code.visitJumpStmt(IF_NEZ,5,-1,L8);
                code.visitLabel(L7);
                code.visitTypeStmt(NEW_INSTANCE,5,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 5},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,8},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitConstStmt(CONST_STRING,6,"/");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,6},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitLabel(L8);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Lorg/mortbay/resource/Resource;","list",new String[]{ },"[Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitLabel(L9);
                code.visitJumpStmt(IF_EQZ,2,-1,L16);
                code.visitLabel(L10);
                code.visitTypeStmt(NEW_INSTANCE,4,-1,"Ljava/util/HashSet;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 4},new Method("Ljava/util/HashSet;","<init>",new String[]{ },"V"));
                code.visitLabel(L11);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L12);
                code.visitStmt2R(ARRAY_LENGTH,5,2);
                DexLabel L17=new DexLabel();
                code.visitJumpStmt(IF_GE,1,5,L17);
                code.visitLabel(L13);
                code.visitTypeStmt(NEW_INSTANCE,5,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 5},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,8},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitStmt3R(AGET_OBJECT,6,2,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,6},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,5},new Method("Ljava/util/HashSet;","add",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitLabel(L1);
                code.visitStmt2R1N(ADD_INT_LIT8,1,1,1);
                code.visitJumpStmt(GOTO,-1,-1,L12);
                code.visitLabel(L17);
                code.visitStmt2R(MOVE_OBJECT,5,4);
                code.visitLabel(L14);
                code.visitStmt1R(RETURN_OBJECT,5);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,5);
                code.visitStmt2R(MOVE_OBJECT,0,5);
                code.visitLabel(L15);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0},new Method("Lorg/mortbay/log/Log;","ignore",new String[]{ "Ljava/lang/Throwable;"},"V"));
                code.visitLabel(L16);
                code.visitFieldStmt(SGET_OBJECT,5,-1,new Field("Ljava/util/Collections;","EMPTY_SET","Ljava/util/Set;"));
                code.visitJumpStmt(GOTO,-1,-1,L14);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m042_getServletContext(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/handler/ContextHandler;","getServletContext",new String[]{ },"Lorg/mortbay/jetty/handler/ContextHandler$SContext;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(177,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/handler/ContextHandler;","_scontext","Lorg/mortbay/jetty/handler/ContextHandler$SContext;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m043_getVirtualHosts(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/handler/ContextHandler;","getVirtualHosts",new String[]{ },"[Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(255,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/handler/ContextHandler;","_vhosts","[Ljava/lang/String;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m044_getWelcomeFiles(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/handler/ContextHandler;","getWelcomeFiles",new String[]{ },"[Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(1027,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/handler/ContextHandler;","_welcomeFiles","[Ljava/lang/String;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m045_handle(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/handler/ContextHandler;","handle",new String[]{ "Ljava/lang/String;","Ljavax/servlet/http/HttpServletRequest;","Ljavax/servlet/http/HttpServletResponse;","I"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visit(null, new DexType("Ljavax/servlet/ServletException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(32);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexLabel L3=new DexLabel();
                DexLabel L4=new DexLabel();
                code.visitTryCatch(L3,L4,new DexLabel[]{L2},new String[]{ null});
                DexLabel L5=new DexLabel();
                DexLabel L6=new DexLabel();
                DexLabel L7=new DexLabel();
                code.visitTryCatch(L5,L6,new DexLabel[]{L6,L7},new String[]{ "Lorg/mortbay/jetty/HttpException;",null});
                DexLabel L8=new DexLabel();
                DexLabel L9=new DexLabel();
                code.visitTryCatch(L8,L9,new DexLabel[]{L7},new String[]{ null});
                DexLabel L10=new DexLabel();
                DexLabel L11=new DexLabel();
                code.visitTryCatch(L10,L11,new DexLabel[]{L2},new String[]{ null});
                DexLabel L12=new DexLabel();
                DexLabel L13=new DexLabel();
                code.visitTryCatch(L12,L13,new DexLabel[]{L6,L7},new String[]{ "Lorg/mortbay/jetty/HttpException;",null});
                DexLabel L14=new DexLabel();
                DexLabel L15=new DexLabel();
                code.visitTryCatch(L14,L15,new DexLabel[]{L2},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"target");
                ddv.visitParameterName(1,"request");
                ddv.visitParameterName(2,"response");
                ddv.visitParameterName(3,"dispatch");
                DexLabel L16=new DexLabel();
                ddv.visitPrologue(L16);
                ddv.visitLineNumber(633,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(634,L17);
                ddv.visitStartLocal(20,L17,"new_context","Z",null);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(635,L18);
                ddv.visitStartLocal(22,L18,"old_context","Lorg/mortbay/jetty/handler/ContextHandler$SContext;",null);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(636,L19);
                ddv.visitStartLocal(23,L19,"old_context_path","Ljava/lang/String;",null);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(637,L20);
                ddv.visitStartLocal(25,L20,"old_servlet_path","Ljava/lang/String;",null);
                DexLabel L21=new DexLabel();
                ddv.visitLineNumber(638,L21);
                ddv.visitStartLocal(24,L21,"old_path_info","Ljava/lang/String;",null);
                DexLabel L22=new DexLabel();
                ddv.visitLineNumber(639,L22);
                ddv.visitStartLocal(21,L22,"old_classloader","Ljava/lang/ClassLoader;",null);
                DexLabel L23=new DexLabel();
                ddv.visitLineNumber(641,L23);
                ddv.visitStartLocal(13,L23,"current_thread","Ljava/lang/Thread;",null);
                DexLabel L24=new DexLabel();
                ddv.visitLineNumber(642,L24);
                ddv.visitStartLocal(11,L24,"base_request","Lorg/mortbay/jetty/Request;",null);
                DexLabel L25=new DexLabel();
                ddv.visitLineNumber(803,L25);
                ddv.visitEndLocal(29,L25);
                DexLabel L26=new DexLabel();
                ddv.visitLineNumber(641,L26);
                ddv.visitEndLocal(11,L26);
                ddv.visitRestartLocal(29,L26);
                DexLabel L27=new DexLabel();
                ddv.visitLineNumber(645,L27);
                ddv.visitRestartLocal(11,L27);
                DexLabel L28=new DexLabel();
                ddv.visitLineNumber(648,L28);
                DexLabel L29=new DexLabel();
                ddv.visitLineNumber(650,L29);
                DexLabel L30=new DexLabel();
                ddv.visitLineNumber(653,L30);
                DexLabel L31=new DexLabel();
                ddv.visitLineNumber(655,L31);
                DexLabel L32=new DexLabel();
                ddv.visitLineNumber(657,L32);
                ddv.visitStartLocal(8,L32,"vhost","Ljava/lang/String;",null);
                DexLabel L33=new DexLabel();
                ddv.visitLineNumber(660,L33);
                ddv.visitStartLocal(19,L33,"match","Z",null);
                DexLabel L34=new DexLabel();
                ddv.visitStartLocal(17,L34,"i","I",null);
                DexLabel L35=new DexLabel();
                ddv.visitLineNumber(662,L35);
                DexLabel L36=new DexLabel();
                ddv.visitLineNumber(663,L36);
                ddv.visitStartLocal(5,L36,"contextVhost","Ljava/lang/String;",null);
                DexLabel L37=new DexLabel();
                ddv.visitLineNumber(660,L37);
                DexLabel L38=new DexLabel();
                ddv.visitLineNumber(664,L38);
                DexLabel L39=new DexLabel();
                ddv.visitLineNumber(666,L39);
                DexLabel L40=new DexLabel();
                ddv.visitLineNumber(668,L40);
                DexLabel L41=new DexLabel();
                ddv.visitRestartLocal(19,L41);
                DexLabel L42=new DexLabel();
                ddv.visitLineNumber(670,L42);
                ddv.visitEndLocal(5,L42);
                DexLabel L43=new DexLabel();
                ddv.visitLineNumber(675,L43);
                ddv.visitEndLocal(8,L43);
                ddv.visitEndLocal(17,L43);
                ddv.visitEndLocal(19,L43);
                DexLabel L44=new DexLabel();
                ddv.visitLineNumber(677,L44);
                DexLabel L45=new DexLabel();
                ddv.visitLineNumber(678,L45);
                ddv.visitStartLocal(12,L45,"connector","Ljava/lang/String;",null);
                DexLabel L46=new DexLabel();
                ddv.visitLineNumber(683,L46);
                ddv.visitEndLocal(12,L46);
                DexLabel L47=new DexLabel();
                ddv.visitLineNumber(685,L47);
                DexLabel L48=new DexLabel();
                ddv.visitLineNumber(686,L48);
                DexLabel L49=new DexLabel();
                ddv.visitLineNumber(688,L49);
                DexLabel L50=new DexLabel();
                ddv.visitLineNumber(690,L50);
                DexLabel L51=new DexLabel();
                ddv.visitLineNumber(692,L51);
                DexLabel L52=new DexLabel();
                ddv.visitLineNumber(693,L52);
                DexLabel L53=new DexLabel();
                ddv.visitLineNumber(694,L53);
                DexLabel L54=new DexLabel();
                ddv.visitLineNumber(696,L54);
                DexLabel L55=new DexLabel();
                ddv.visitLineNumber(699,L55);
                DexLabel L56=new DexLabel();
                ddv.visitLineNumber(701,L56);
                DexLabel L57=new DexLabel();
                ddv.visitLineNumber(702,L57);
                ddv.visitRestartLocal(28,L57);
                ddv.visitLineNumber(720,L0);
                DexLabel L58=new DexLabel();
                ddv.visitLineNumber(721,L58);
                DexLabel L59=new DexLabel();
                ddv.visitLineNumber(722,L59);
                DexLabel L60=new DexLabel();
                ddv.visitLineNumber(725,L60);
                DexLabel L61=new DexLabel();
                ddv.visitLineNumber(726,L61);
                DexLabel L62=new DexLabel();
                ddv.visitLineNumber(728,L62);
                DexLabel L63=new DexLabel();
                ddv.visitLineNumber(729,L63);
                DexLabel L64=new DexLabel();
                ddv.visitLineNumber(732,L64);
                DexLabel L65=new DexLabel();
                ddv.visitLineNumber(733,L65);
                DexLabel L66=new DexLabel();
                ddv.visitLineNumber(736,L66);
                DexLabel L67=new DexLabel();
                ddv.visitLineNumber(737,L67);
                ddv.visitStartLocal(15,L67,"event","Ljavax/servlet/ServletRequestEvent;",null);
                DexLabel L68=new DexLabel();
                ddv.visitLineNumber(740,L68);
                DexLabel L69=new DexLabel();
                ddv.visitLineNumber(742,L69);
                DexLabel L70=new DexLabel();
                ddv.visitLineNumber(743,L70);
                DexLabel L71=new DexLabel();
                ddv.visitLineNumber(744,L71);
                DexLabel L72=new DexLabel();
                ddv.visitLineNumber(748,L72);
                DexLabel L73=new DexLabel();
                ddv.visitLineNumber(749,L73);
                DexLabel L74=new DexLabel();
                ddv.visitLineNumber(751,L74);
                DexLabel L75=new DexLabel();
                ddv.visitLineNumber(752,L75);
                ddv.visitStartLocal(26,L75,"s","I",null);
                DexLabel L76=new DexLabel();
                ddv.visitRestartLocal(17,L76);
                DexLabel L77=new DexLabel();
                ddv.visitLineNumber(753,L77);
                ddv.visitLineNumber(752,L1);
                DexLabel L78=new DexLabel();
                ddv.visitLineNumber(705,L78);
                ddv.visitEndLocal(15,L78);
                ddv.visitEndLocal(26,L78);
                ddv.visitEndLocal(17,L78);
                DexLabel L79=new DexLabel();
                ddv.visitLineNumber(707,L79);
                DexLabel L80=new DexLabel();
                ddv.visitLineNumber(708,L80);
                DexLabel L81=new DexLabel();
                ddv.visitRestartLocal(28,L81);
                ddv.visitLineNumber(731,L3);
                ddv.visitLineNumber(788,L2);
                ddv.visitEndLocal(29,L2);
                ddv.visitEndLocal(28,L2);
                DexLabel L82=new DexLabel();
                ddv.visitLineNumber(791,L82);
                DexLabel L83=new DexLabel();
                ddv.visitLineNumber(793,L83);
                DexLabel L84=new DexLabel();
                ddv.visitLineNumber(797,L84);
                DexLabel L85=new DexLabel();
                ddv.visitLineNumber(798,L85);
                DexLabel L86=new DexLabel();
                ddv.visitLineNumber(799,L86);
                DexLabel L87=new DexLabel();
                ddv.visitLineNumber(800,L87);
                DexLabel L88=new DexLabel();
                ddv.visitLineNumber(788,L88);
                DexLabel L89=new DexLabel();
                ddv.visitLineNumber(760,L89);
                ddv.visitRestartLocal(15,L89);
                ddv.visitRestartLocal(28,L89);
                ddv.visitRestartLocal(29,L89);
                DexLabel L90=new DexLabel();
                ddv.visitLineNumber(761,L90);
                ddv.visitLineNumber(767,L6);
                ddv.visitLineNumber(769,L8);
                ddv.visitStartLocal(14,L8,"e","Lorg/mortbay/jetty/HttpException;",null);
                DexLabel L91=new DexLabel();
                ddv.visitLineNumber(770,L91);
                ddv.visitLineNumber(775,L9);
                ddv.visitLineNumber(777,L10);
                DexLabel L92=new DexLabel();
                ddv.visitLineNumber(778,L92);
                DexLabel L93=new DexLabel();
                ddv.visitLineNumber(780,L93);
                DexLabel L94=new DexLabel();
                ddv.visitRestartLocal(17,L94);
                DexLabel L95=new DexLabel();
                ddv.visitEndLocal(29,L95);
                ddv.visitEndLocal(17,L95);
                ddv.visitStartLocal(18,L95,"i","I",null);
                DexLabel L96=new DexLabel();
                ddv.visitRestartLocal(17,L96);
                DexLabel L97=new DexLabel();
                ddv.visitLineNumber(781,L97);
                ddv.visitEndLocal(18,L97);
                DexLabel L98=new DexLabel();
                ddv.visitRestartLocal(18,L98);
                ddv.visitLineNumber(763,L12);
                ddv.visitEndLocal(14,L12);
                ddv.visitEndLocal(17,L12);
                ddv.visitEndLocal(18,L12);
                ddv.visitRestartLocal(29,L12);
                DexLabel L99=new DexLabel();
                ddv.visitLineNumber(764,L99);
                ddv.visitStartLocal(16,L99,"handler","Lorg/mortbay/jetty/Handler;",null);
                DexLabel L100=new DexLabel();
                ddv.visitLineNumber(765,L100);
                ddv.visitLineNumber(775,L13);
                ddv.visitLineNumber(777,L14);
                DexLabel L101=new DexLabel();
                ddv.visitLineNumber(778,L101);
                DexLabel L102=new DexLabel();
                ddv.visitLineNumber(780,L102);
                DexLabel L103=new DexLabel();
                ddv.visitRestartLocal(17,L103);
                DexLabel L104=new DexLabel();
                ddv.visitEndLocal(29,L104);
                ddv.visitEndLocal(17,L104);
                ddv.visitRestartLocal(18,L104);
                DexLabel L105=new DexLabel();
                ddv.visitRestartLocal(17,L105);
                DexLabel L106=new DexLabel();
                ddv.visitLineNumber(781,L106);
                ddv.visitEndLocal(18,L106);
                DexLabel L107=new DexLabel();
                ddv.visitRestartLocal(18,L107);
                DexLabel L108=new DexLabel();
                ddv.visitLineNumber(775,L108);
                ddv.visitEndLocal(28,L108);
                ddv.visitEndLocal(16,L108);
                ddv.visitEndLocal(17,L108);
                ddv.visitEndLocal(18,L108);
                ddv.visitRestartLocal(29,L108);
                ddv.visitRestartLocal(28,L7);
                DexLabel L109=new DexLabel();
                ddv.visitLineNumber(777,L109);
                DexLabel L110=new DexLabel();
                ddv.visitLineNumber(778,L110);
                DexLabel L111=new DexLabel();
                ddv.visitLineNumber(780,L111);
                DexLabel L112=new DexLabel();
                ddv.visitRestartLocal(17,L112);
                DexLabel L113=new DexLabel();
                ddv.visitEndLocal(28,L113);
                ddv.visitEndLocal(17,L113);
                ddv.visitRestartLocal(18,L113);
                DexLabel L114=new DexLabel();
                ddv.visitRestartLocal(17,L114);
                DexLabel L115=new DexLabel();
                ddv.visitLineNumber(781,L115);
                ddv.visitEndLocal(18,L115);
                DexLabel L116=new DexLabel();
                ddv.visitRestartLocal(18,L116);
                DexLabel L117=new DexLabel();
                ddv.visitLineNumber(788,L117);
                ddv.visitEndLocal(29,L117);
                ddv.visitEndLocal(17,L117);
                ddv.visitEndLocal(18,L117);
                ddv.visitRestartLocal(28,L117);
                DexLabel L118=new DexLabel();
                ddv.visitLineNumber(791,L118);
                DexLabel L119=new DexLabel();
                ddv.visitLineNumber(793,L119);
                DexLabel L120=new DexLabel();
                ddv.visitLineNumber(797,L120);
                DexLabel L121=new DexLabel();
                ddv.visitLineNumber(798,L121);
                DexLabel L122=new DexLabel();
                ddv.visitLineNumber(799,L122);
                DexLabel L123=new DexLabel();
                ddv.visitLineNumber(800,L123);
                code.visitLabel(L16);
                code.visitConstStmt(CONST_16,20, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L17);
                code.visitConstStmt(CONST_16,22, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L18);
                code.visitConstStmt(CONST_16,23, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L19);
                code.visitConstStmt(CONST_16,25, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L20);
                code.visitConstStmt(CONST_16,24, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L21);
                code.visitConstStmt(CONST_16,21, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L22);
                code.visitConstStmt(CONST_4,13, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L23);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,29);
                code.visitTypeStmt(INSTANCE_OF,0,0,"Lorg/mortbay/jetty/Request;");
                code.visitStmt2R(MOVE,6,0);
                code.visitJumpStmt(IF_EQZ,6,-1,L26);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,29);
                code.visitTypeStmt(CHECK_CAST,0,-1,"Lorg/mortbay/jetty/Request;");
                code.visitStmt2R(MOVE_OBJECT,5,0);
                code.visitStmt2R(MOVE_OBJECT,11,5);
                code.visitLabel(L24);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 27},new Method("Lorg/mortbay/jetty/handler/ContextHandler;","isStarted",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,6);
                code.visitJumpStmt(IF_EQZ,6,-1,L25);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_BOOLEAN,0,0,new Field("Lorg/mortbay/jetty/handler/ContextHandler;","_shutdown","Z"));
                code.visitStmt2R(MOVE,6,0);
                code.visitJumpStmt(IF_NEZ,6,-1,L25);
                code.visitConstStmt(CONST_4,6, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitStmt2R(MOVE_FROM16,0,31);
                code.visitStmt2R(MOVE,1,6);
                code.visitJumpStmt(IF_NE,0,1,L27);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 11},new Method("Lorg/mortbay/jetty/Request;","isHandled",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,6);
                code.visitJumpStmt(IF_EQZ,6,-1,L27);
                code.visitLabel(L25);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L26);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Lorg/mortbay/jetty/HttpConnection;","getCurrentConnection",new String[]{ },"Lorg/mortbay/jetty/HttpConnection;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Lorg/mortbay/jetty/HttpConnection;","getRequest",new String[]{ },"Lorg/mortbay/jetty/Request;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitStmt2R(MOVE_OBJECT,11,6);
                code.visitJumpStmt(GOTO,-1,-1,L24);
                code.visitLabel(L27);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 11},new Method("Lorg/mortbay/jetty/Request;","getContext",new String[]{ },"Lorg/mortbay/jetty/handler/ContextHandler$SContext;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,22);
                code.visitLabel(L28);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/handler/ContextHandler;","_scontext","Lorg/mortbay/jetty/handler/ContextHandler$SContext;"));
                code.visitStmt2R(MOVE_OBJECT,6,0);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,22);
                code.visitStmt2R(MOVE_OBJECT,1,6);
                code.visitJumpStmt(IF_EQ,0,1,L0);
                code.visitLabel(L29);
                code.visitConstStmt(CONST_16,20, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitLabel(L30);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/handler/ContextHandler;","_vhosts","[Ljava/lang/String;"));
                code.visitStmt2R(MOVE_OBJECT,6,0);
                code.visitJumpStmt(IF_EQZ,6,-1,L43);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/handler/ContextHandler;","_vhosts","[Ljava/lang/String;"));
                code.visitStmt2R(MOVE_OBJECT,6,0);
                code.visitStmt2R(ARRAY_LENGTH,6,6);
                code.visitJumpStmt(IF_LEZ,6,-1,L43);
                code.visitLabel(L31);
                code.visitMethodStmt(INVOKE_INTERFACE_RANGE,new int[]{ 29},new Method("Ljavax/servlet/http/HttpServletRequest;","getServerName",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitStmt2R(MOVE_OBJECT,1,6);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1},new Method("Lorg/mortbay/jetty/handler/ContextHandler;","normalizeHostname",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitLabel(L32);
                code.visitConstStmt(CONST_16,19, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L33);
                code.visitConstStmt(CONST_16,17, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L34);
                code.visitJumpStmt(IF_NEZ,19,-1,L42);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/handler/ContextHandler;","_vhosts","[Ljava/lang/String;"));
                code.visitStmt2R(MOVE_OBJECT,6,0);
                code.visitStmt2R(ARRAY_LENGTH,6,6);
                code.visitStmt2R(MOVE_FROM16,0,17);
                code.visitStmt2R(MOVE,1,6);
                code.visitJumpStmt(IF_GE,0,1,L42);
                code.visitLabel(L35);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/handler/ContextHandler;","_vhosts","[Ljava/lang/String;"));
                code.visitStmt2R(MOVE_OBJECT,6,0);
                code.visitStmt3R(AGET_OBJECT,5,6,17);
                code.visitLabel(L36);
                code.visitJumpStmt(IF_NEZ,5,-1,L38);
                code.visitLabel(L37);
                code.visitStmt2R1N(ADD_INT_LIT8,17,17,1);
                code.visitJumpStmt(GOTO,-1,-1,L34);
                code.visitLabel(L38);
                code.visitConstStmt(CONST_STRING,6,"*.");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,6},new Method("Ljava/lang/String;","startsWith",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,6);
                code.visitJumpStmt(IF_EQZ,6,-1,L40);
                code.visitLabel(L39);
                code.visitConstStmt(CONST_4,6, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitConstStmt(CONST_4,7, Integer.valueOf(2)); // int: 0x00000002  float:0.000000
                code.visitConstStmt(CONST_STRING,9,".");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8,9},new Method("Ljava/lang/String;","indexOf",new String[]{ "Ljava/lang/String;"},"I"));
                code.visitStmt1R(MOVE_RESULT,9);
                code.visitStmt2R1N(ADD_INT_LIT8,9,9,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Ljava/lang/String;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,10);
                code.visitConstStmt(CONST_4,12, Integer.valueOf(2)); // int: 0x00000002  float:0.000000
                code.visitStmt2R(SUB_INT_2ADDR,10,12);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 5,6,7,8,9,10},new Method("Ljava/lang/String;","regionMatches",new String[]{ "Z","I","Ljava/lang/String;","I","I"},"Z"));
                code.visitStmt1R(MOVE_RESULT,19);
                code.visitJumpStmt(GOTO,-1,-1,L37);
                code.visitLabel(L40);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,8},new Method("Ljava/lang/String;","equalsIgnoreCase",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,19);
                code.visitLabel(L41);
                code.visitJumpStmt(GOTO,-1,-1,L37);
                code.visitLabel(L42);
                code.visitJumpStmt(IF_EQZ,19,-1,L25);
                code.visitLabel(L43);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/handler/ContextHandler;","_connectors","Ljava/util/Set;"));
                code.visitStmt2R(MOVE_OBJECT,6,0);
                code.visitJumpStmt(IF_EQZ,6,-1,L46);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/handler/ContextHandler;","_connectors","Ljava/util/Set;"));
                code.visitStmt2R(MOVE_OBJECT,6,0);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 6},new Method("Ljava/util/Set;","size",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,6);
                code.visitJumpStmt(IF_LEZ,6,-1,L46);
                code.visitLabel(L44);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Lorg/mortbay/jetty/HttpConnection;","getCurrentConnection",new String[]{ },"Lorg/mortbay/jetty/HttpConnection;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Lorg/mortbay/jetty/HttpConnection;","getConnector",new String[]{ },"Lorg/mortbay/jetty/Connector;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 6},new Method("Lorg/mortbay/jetty/Connector;","getName",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,12);
                code.visitLabel(L45);
                code.visitJumpStmt(IF_EQZ,12,-1,L25);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/handler/ContextHandler;","_connectors","Ljava/util/Set;"));
                code.visitStmt2R(MOVE_OBJECT,6,0);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 6,12},new Method("Ljava/util/Set;","contains",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,6);
                code.visitJumpStmt(IF_EQZ,6,-1,L25);
                code.visitLabel(L46);
                code.visitConstStmt(CONST_4,6, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitStmt2R(MOVE_FROM16,0,31);
                code.visitStmt2R(MOVE,1,6);
                code.visitJumpStmt(IF_NE,0,1,L0);
                code.visitLabel(L47);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_BOOLEAN,0,0,new Field("Lorg/mortbay/jetty/handler/ContextHandler;","_compactPath","Z"));
                code.visitStmt2R(MOVE,6,0);
                code.visitJumpStmt(IF_EQZ,6,-1,L49);
                code.visitLabel(L48);
                code.visitMethodStmt(INVOKE_STATIC_RANGE,new int[]{ 28},new Method("Lorg/mortbay/util/URIUtil;","compactPath",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,28);
                code.visitLabel(L49);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/handler/ContextHandler;","_contextPath","Ljava/lang/String;"));
                code.visitStmt2R(MOVE_OBJECT,6,0);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,28);
                code.visitStmt2R(MOVE_OBJECT,1,6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/String;","equals",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,6);
                code.visitJumpStmt(IF_EQZ,6,-1,L78);
                code.visitLabel(L50);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_BOOLEAN,0,0,new Field("Lorg/mortbay/jetty/handler/ContextHandler;","_allowNullPathInfo","Z"));
                code.visitStmt2R(MOVE,6,0);
                code.visitJumpStmt(IF_NEZ,6,-1,L55);
                code.visitConstStmt(CONST_STRING,6,"/");
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,28);
                code.visitStmt2R(MOVE_OBJECT,1,6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/String;","endsWith",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,6);
                code.visitJumpStmt(IF_NEZ,6,-1,L55);
                code.visitLabel(L51);
                code.visitConstStmt(CONST_4,6, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 11,6},new Method("Lorg/mortbay/jetty/Request;","setHandled",new String[]{ "Z"},"V"));
                code.visitLabel(L52);
                code.visitMethodStmt(INVOKE_INTERFACE_RANGE,new int[]{ 29},new Method("Ljavax/servlet/http/HttpServletRequest;","getQueryString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitJumpStmt(IF_EQZ,6,-1,L54);
                code.visitLabel(L53);
                code.visitTypeStmt(NEW_INSTANCE,6,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 6},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitMethodStmt(INVOKE_INTERFACE_RANGE,new int[]{ 29},new Method("Ljavax/servlet/http/HttpServletRequest;","getRequestURI",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitConstStmt(CONST_STRING,8,"/");
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 7,8},new Method("Lorg/mortbay/util/URIUtil;","addPaths",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,7},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitConstStmt(CONST_STRING,7,"?");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,7},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitMethodStmt(INVOKE_INTERFACE_RANGE,new int[]{ 29},new Method("Ljavax/servlet/http/HttpServletRequest;","getQueryString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,7},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,30);
                code.visitStmt2R(MOVE_OBJECT,1,6);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,1},new Method("Ljavax/servlet/http/HttpServletResponse;","sendRedirect",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitJumpStmt(GOTO_16,-1,-1,L25);
                code.visitLabel(L54);
                code.visitMethodStmt(INVOKE_INTERFACE_RANGE,new int[]{ 29},new Method("Ljavax/servlet/http/HttpServletRequest;","getRequestURI",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitConstStmt(CONST_STRING,7,"/");
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 6,7},new Method("Lorg/mortbay/util/URIUtil;","addPaths",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,30);
                code.visitStmt2R(MOVE_OBJECT,1,6);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,1},new Method("Ljavax/servlet/http/HttpServletResponse;","sendRedirect",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitJumpStmt(GOTO_16,-1,-1,L25);
                code.visitLabel(L55);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/handler/ContextHandler;","_contextPath","Ljava/lang/String;"));
                code.visitStmt2R(MOVE_OBJECT,6,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Ljava/lang/String;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,6);
                code.visitConstStmt(CONST_4,7, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitJumpStmt(IF_LE,6,7,L0);
                code.visitLabel(L56);
                code.visitConstStmt(CONST_STRING,28,"/");
                code.visitLabel(L57);
                code.visitConstStmt(CONST_STRING,6,"org.mortbay.jetty.nullPathInfo");
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,29);
                code.visitStmt2R(MOVE_OBJECT,1,6);
                code.visitStmt2R(MOVE_OBJECT_FROM16,2,28);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,1,2},new Method("Ljavax/servlet/http/HttpServletRequest;","setAttribute",new String[]{ "Ljava/lang/String;","Ljava/lang/Object;"},"V"));
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 11},new Method("Lorg/mortbay/jetty/Request;","getContextPath",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,23);
                code.visitLabel(L58);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 11},new Method("Lorg/mortbay/jetty/Request;","getServletPath",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,25);
                code.visitLabel(L59);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 11},new Method("Lorg/mortbay/jetty/Request;","getPathInfo",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,24);
                code.visitLabel(L60);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/handler/ContextHandler;","_scontext","Lorg/mortbay/jetty/handler/ContextHandler$SContext;"));
                code.visitStmt2R(MOVE_OBJECT,6,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 11,6},new Method("Lorg/mortbay/jetty/Request;","setContext",new String[]{ "Lorg/mortbay/jetty/handler/ContextHandler$SContext;"},"V"));
                code.visitLabel(L61);
                code.visitConstStmt(CONST_4,6, Integer.valueOf(4)); // int: 0x00000004  float:0.000000
                code.visitStmt2R(MOVE_FROM16,0,31);
                code.visitStmt2R(MOVE,1,6);
                code.visitJumpStmt(IF_EQ,0,1,L66);
                code.visitConstStmt(CONST_STRING,6,"/");
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,28);
                code.visitStmt2R(MOVE_OBJECT,1,6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/String;","startsWith",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,6);
                code.visitJumpStmt(IF_EQZ,6,-1,L66);
                code.visitLabel(L62);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/handler/ContextHandler;","_contextPath","Ljava/lang/String;"));
                code.visitStmt2R(MOVE_OBJECT,6,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Ljava/lang/String;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,6);
                code.visitConstStmt(CONST_4,7, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitJumpStmt(IF_NE,6,7,L3);
                code.visitLabel(L63);
                code.visitConstStmt(CONST_STRING,6,"");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 11,6},new Method("Lorg/mortbay/jetty/Request;","setContextPath",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L64);
                code.visitConstStmt(CONST_4,6, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 11,6},new Method("Lorg/mortbay/jetty/Request;","setServletPath",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L65);
                code.visitStmt2R(MOVE_OBJECT,0,11);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,28);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Lorg/mortbay/jetty/Request;","setPathInfo",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L66);
                code.visitConstStmt(CONST_4,15, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L67);
                code.visitJumpStmt(IF_EQZ,20,-1,L89);
                code.visitLabel(L68);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/handler/ContextHandler;","_classLoader","Ljava/lang/ClassLoader;"));
                code.visitStmt2R(MOVE_OBJECT,6,0);
                code.visitJumpStmt(IF_EQZ,6,-1,L72);
                code.visitLabel(L69);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Ljava/lang/Thread;","currentThread",new String[]{ },"Ljava/lang/Thread;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,13);
                code.visitLabel(L70);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 13},new Method("Ljava/lang/Thread;","getContextClassLoader",new String[]{ },"Ljava/lang/ClassLoader;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,21);
                code.visitLabel(L71);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/handler/ContextHandler;","_classLoader","Ljava/lang/ClassLoader;"));
                code.visitStmt2R(MOVE_OBJECT,6,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 13,6},new Method("Ljava/lang/Thread;","setContextClassLoader",new String[]{ "Ljava/lang/ClassLoader;"},"V"));
                code.visitLabel(L72);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/handler/ContextHandler;","_requestListeners","Ljava/lang/Object;"));
                code.visitStmt2R(MOVE_OBJECT,6,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 11,6},new Method("Lorg/mortbay/jetty/Request;","setRequestListeners",new String[]{ "Ljava/lang/Object;"},"V"));
                code.visitLabel(L73);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/handler/ContextHandler;","_requestAttributeListeners","Ljava/lang/Object;"));
                code.visitStmt2R(MOVE_OBJECT,6,0);
                code.visitJumpStmt(IF_EQZ,6,-1,L89);
                code.visitLabel(L74);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/handler/ContextHandler;","_requestAttributeListeners","Ljava/lang/Object;"));
                code.visitStmt2R(MOVE_OBJECT,6,0);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 6},new Method("Lorg/mortbay/util/LazyList;","size",new String[]{ "Ljava/lang/Object;"},"I"));
                code.visitStmt1R(MOVE_RESULT,26);
                code.visitLabel(L75);
                code.visitConstStmt(CONST_16,17, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L76);
                code.visitStmt2R(MOVE_FROM16,0,17);
                code.visitStmt2R(MOVE_FROM16,1,26);
                code.visitJumpStmt(IF_GE,0,1,L89);
                code.visitLabel(L77);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/handler/ContextHandler;","_requestAttributeListeners","Ljava/lang/Object;"));
                code.visitStmt2R(MOVE_OBJECT,6,0);
                code.visitStmt2R(MOVE_OBJECT,0,6);
                code.visitStmt2R(MOVE_FROM16,1,17);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0,1},new Method("Lorg/mortbay/util/LazyList;","get",new String[]{ "Ljava/lang/Object;","I"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitTypeStmt(CHECK_CAST,5,-1,"Ljava/util/EventListener;");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 11,5},new Method("Lorg/mortbay/jetty/Request;","addEventListener",new String[]{ "Ljava/util/EventListener;"},"V"));
                code.visitLabel(L1);
                code.visitStmt2R1N(ADD_INT_LIT8,17,17,1);
                code.visitJumpStmt(GOTO,-1,-1,L76);
                code.visitLabel(L78);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/handler/ContextHandler;","_contextPath","Ljava/lang/String;"));
                code.visitStmt2R(MOVE_OBJECT,6,0);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,28);
                code.visitStmt2R(MOVE_OBJECT,1,6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/String;","startsWith",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,6);
                code.visitJumpStmt(IF_EQZ,6,-1,L25);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/handler/ContextHandler;","_contextPath","Ljava/lang/String;"));
                code.visitStmt2R(MOVE_OBJECT,6,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Ljava/lang/String;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,6);
                code.visitConstStmt(CONST_4,7, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitJumpStmt(IF_EQ,6,7,L79);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/handler/ContextHandler;","_contextPath","Ljava/lang/String;"));
                code.visitStmt2R(MOVE_OBJECT,6,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Ljava/lang/String;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,6);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,28);
                code.visitStmt2R(MOVE,1,6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/String;","charAt",new String[]{ "I"},"C"));
                code.visitStmt1R(MOVE_RESULT,6);
                code.visitConstStmt(CONST_16,7, Integer.valueOf(47)); // int: 0x0000002f  float:0.000000
                code.visitJumpStmt(IF_NE,6,7,L25);
                code.visitLabel(L79);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/handler/ContextHandler;","_contextPath","Ljava/lang/String;"));
                code.visitStmt2R(MOVE_OBJECT,6,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Ljava/lang/String;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,6);
                code.visitConstStmt(CONST_4,7, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitJumpStmt(IF_LE,6,7,L0);
                code.visitLabel(L80);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/handler/ContextHandler;","_contextPath","Ljava/lang/String;"));
                code.visitStmt2R(MOVE_OBJECT,6,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Ljava/lang/String;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,6);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,28);
                code.visitStmt2R(MOVE,1,6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/String;","substring",new String[]{ "I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,28);
                code.visitLabel(L81);
                code.visitJumpStmt(GOTO_16,-1,-1,L0);
                code.visitLabel(L3);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/handler/ContextHandler;","_contextPath","Ljava/lang/String;"));
                code.visitStmt2R(MOVE_OBJECT,6,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 11,6},new Method("Lorg/mortbay/jetty/Request;","setContextPath",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L4);
                code.visitJumpStmt(GOTO_16,-1,-1,L64);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,6);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/handler/ContextHandler;","_scontext","Lorg/mortbay/jetty/handler/ContextHandler$SContext;"));
                code.visitStmt2R(MOVE_OBJECT,7,0);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,22);
                code.visitStmt2R(MOVE_OBJECT,1,7);
                code.visitJumpStmt(IF_EQ,0,1,L88);
                code.visitLabel(L82);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/handler/ContextHandler;","_classLoader","Ljava/lang/ClassLoader;"));
                code.visitStmt2R(MOVE_OBJECT,7,0);
                code.visitJumpStmt(IF_EQZ,7,-1,L84);
                code.visitLabel(L83);
                code.visitStmt2R(MOVE_OBJECT,0,13);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,21);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/Thread;","setContextClassLoader",new String[]{ "Ljava/lang/ClassLoader;"},"V"));
                code.visitLabel(L84);
                code.visitStmt2R(MOVE_OBJECT,0,11);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,22);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Lorg/mortbay/jetty/Request;","setContext",new String[]{ "Lorg/mortbay/jetty/handler/ContextHandler$SContext;"},"V"));
                code.visitLabel(L85);
                code.visitStmt2R(MOVE_OBJECT,0,11);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,23);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Lorg/mortbay/jetty/Request;","setContextPath",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L86);
                code.visitStmt2R(MOVE_OBJECT,0,11);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,25);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Lorg/mortbay/jetty/Request;","setServletPath",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L87);
                code.visitStmt2R(MOVE_OBJECT,0,11);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,24);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Lorg/mortbay/jetty/Request;","setPathInfo",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L88);
                code.visitStmt1R(THROW,6);
                code.visitLabel(L89);
                code.visitConstStmt(CONST_4,6, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitStmt2R(MOVE_FROM16,0,31);
                code.visitStmt2R(MOVE,1,6);
                code.visitJumpStmt(IF_NE,0,1,L12);
                code.visitLabel(L5);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 27,28},new Method("Lorg/mortbay/jetty/handler/ContextHandler;","isProtectedTarget",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,6);
                code.visitJumpStmt(IF_EQZ,6,-1,L12);
                code.visitLabel(L90);
                code.visitTypeStmt(NEW_INSTANCE,6,-1,"Lorg/mortbay/jetty/HttpException;");
                code.visitConstStmt(CONST_16,7, Integer.valueOf(404)); // int: 0x00000194  float:0.000000
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 6,7},new Method("Lorg/mortbay/jetty/HttpException;","<init>",new String[]{ "I"},"V"));
                code.visitStmt1R(THROW,6);
                code.visitLabel(L6);
                code.visitStmt1R(MOVE_EXCEPTION,6);
                code.visitStmt2R(MOVE_OBJECT,14,6);
                code.visitLabel(L8);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 14},new Method("Lorg/mortbay/log/Log;","debug",new String[]{ "Ljava/lang/Throwable;"},"V"));
                code.visitLabel(L91);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 14},new Method("Lorg/mortbay/jetty/HttpException;","getStatus",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 14},new Method("Lorg/mortbay/jetty/HttpException;","getReason",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,30);
                code.visitStmt2R(MOVE,1,6);
                code.visitStmt2R(MOVE_OBJECT,2,7);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,1,2},new Method("Ljavax/servlet/http/HttpServletResponse;","sendError",new String[]{ "I","Ljava/lang/String;"},"V"));
                code.visitLabel(L9);
                code.visitJumpStmt(IF_EQZ,20,-1,L117);
                code.visitLabel(L10);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 11},new Method("Lorg/mortbay/jetty/Request;","takeRequestListeners",new String[]{ },"Ljava/lang/Object;"));
                code.visitLabel(L92);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/handler/ContextHandler;","_requestAttributeListeners","Ljava/lang/Object;"));
                code.visitStmt2R(MOVE_OBJECT,6,0);
                code.visitJumpStmt(IF_EQZ,6,-1,L117);
                code.visitLabel(L93);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/handler/ContextHandler;","_requestAttributeListeners","Ljava/lang/Object;"));
                code.visitStmt2R(MOVE_OBJECT,6,0);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 6},new Method("Lorg/mortbay/util/LazyList;","size",new String[]{ "Ljava/lang/Object;"},"I"));
                code.visitStmt1R(MOVE_RESULT,17);
                code.visitLabel(L94);
                code.visitStmt2R(MOVE_FROM16,18,17);
                code.visitLabel(L95);
                code.visitConstStmt(CONST_4,6, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitStmt3R(SUB_INT,17,18,6);
                code.visitLabel(L96);
                code.visitJumpStmt(IF_LEZ,18,-1,L117);
                code.visitLabel(L97);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/handler/ContextHandler;","_requestAttributeListeners","Ljava/lang/Object;"));
                code.visitStmt2R(MOVE_OBJECT,6,0);
                code.visitStmt2R(MOVE_OBJECT,0,6);
                code.visitStmt2R(MOVE_FROM16,1,17);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0,1},new Method("Lorg/mortbay/util/LazyList;","get",new String[]{ "Ljava/lang/Object;","I"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,29);
                code.visitTypeStmt(CHECK_CAST,29,-1,"Ljava/util/EventListener;");
                code.visitStmt2R(MOVE_OBJECT,0,11);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,29);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Lorg/mortbay/jetty/Request;","removeEventListener",new String[]{ "Ljava/util/EventListener;"},"V"));
                code.visitLabel(L11);
                code.visitStmt2R(MOVE_FROM16,18,17);
                code.visitLabel(L98);
                code.visitJumpStmt(GOTO,-1,-1,L95);
                code.visitLabel(L12);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 27},new Method("Lorg/mortbay/jetty/handler/ContextHandler;","getHandler",new String[]{ },"Lorg/mortbay/jetty/Handler;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,16);
                code.visitLabel(L99);
                code.visitJumpStmt(IF_EQZ,16,-1,L13);
                code.visitLabel(L100);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,16);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,28);
                code.visitStmt2R(MOVE_OBJECT_FROM16,2,29);
                code.visitStmt2R(MOVE_OBJECT_FROM16,3,30);
                code.visitStmt2R(MOVE_FROM16,4,31);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,1,2,3,4},new Method("Lorg/mortbay/jetty/Handler;","handle",new String[]{ "Ljava/lang/String;","Ljavax/servlet/http/HttpServletRequest;","Ljavax/servlet/http/HttpServletResponse;","I"},"V"));
                code.visitLabel(L13);
                code.visitJumpStmt(IF_EQZ,20,-1,L117);
                code.visitLabel(L14);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 11},new Method("Lorg/mortbay/jetty/Request;","takeRequestListeners",new String[]{ },"Ljava/lang/Object;"));
                code.visitLabel(L101);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/handler/ContextHandler;","_requestAttributeListeners","Ljava/lang/Object;"));
                code.visitStmt2R(MOVE_OBJECT,6,0);
                code.visitJumpStmt(IF_EQZ,6,-1,L117);
                code.visitLabel(L102);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/handler/ContextHandler;","_requestAttributeListeners","Ljava/lang/Object;"));
                code.visitStmt2R(MOVE_OBJECT,6,0);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 6},new Method("Lorg/mortbay/util/LazyList;","size",new String[]{ "Ljava/lang/Object;"},"I"));
                code.visitStmt1R(MOVE_RESULT,17);
                code.visitLabel(L103);
                code.visitStmt2R(MOVE_FROM16,18,17);
                code.visitLabel(L104);
                code.visitConstStmt(CONST_4,6, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitStmt3R(SUB_INT,17,18,6);
                code.visitLabel(L105);
                code.visitJumpStmt(IF_LEZ,18,-1,L117);
                code.visitLabel(L106);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/handler/ContextHandler;","_requestAttributeListeners","Ljava/lang/Object;"));
                code.visitStmt2R(MOVE_OBJECT,6,0);
                code.visitStmt2R(MOVE_OBJECT,0,6);
                code.visitStmt2R(MOVE_FROM16,1,17);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0,1},new Method("Lorg/mortbay/util/LazyList;","get",new String[]{ "Ljava/lang/Object;","I"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,29);
                code.visitTypeStmt(CHECK_CAST,29,-1,"Ljava/util/EventListener;");
                code.visitStmt2R(MOVE_OBJECT,0,11);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,29);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Lorg/mortbay/jetty/Request;","removeEventListener",new String[]{ "Ljava/util/EventListener;"},"V"));
                code.visitStmt2R(MOVE_FROM16,18,17);
                code.visitLabel(L107);
                code.visitJumpStmt(GOTO,-1,-1,L104);
                code.visitLabel(L108);
                code.visitStmt1R(THROW,6);
                code.visitLabel(L7);
                code.visitStmt1R(MOVE_EXCEPTION,6);
                code.visitJumpStmt(IF_EQZ,20,-1,L108);
                code.visitLabel(L109);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 11},new Method("Lorg/mortbay/jetty/Request;","takeRequestListeners",new String[]{ },"Ljava/lang/Object;"));
                code.visitLabel(L110);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/handler/ContextHandler;","_requestAttributeListeners","Ljava/lang/Object;"));
                code.visitStmt2R(MOVE_OBJECT,7,0);
                code.visitJumpStmt(IF_EQZ,7,-1,L108);
                code.visitLabel(L111);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/handler/ContextHandler;","_requestAttributeListeners","Ljava/lang/Object;"));
                code.visitStmt2R(MOVE_OBJECT,7,0);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 7},new Method("Lorg/mortbay/util/LazyList;","size",new String[]{ "Ljava/lang/Object;"},"I"));
                code.visitStmt1R(MOVE_RESULT,17);
                code.visitLabel(L112);
                code.visitStmt2R(MOVE_FROM16,18,17);
                code.visitLabel(L113);
                code.visitConstStmt(CONST_4,7, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitStmt3R(SUB_INT,17,18,7);
                code.visitLabel(L114);
                code.visitJumpStmt(IF_LEZ,18,-1,L108);
                code.visitLabel(L115);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/handler/ContextHandler;","_requestAttributeListeners","Ljava/lang/Object;"));
                code.visitStmt2R(MOVE_OBJECT,7,0);
                code.visitStmt2R(MOVE_OBJECT,0,7);
                code.visitStmt2R(MOVE_FROM16,1,17);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0,1},new Method("Lorg/mortbay/util/LazyList;","get",new String[]{ "Ljava/lang/Object;","I"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,28);
                code.visitTypeStmt(CHECK_CAST,28,-1,"Ljava/util/EventListener;");
                code.visitStmt2R(MOVE_OBJECT,0,11);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,28);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Lorg/mortbay/jetty/Request;","removeEventListener",new String[]{ "Ljava/util/EventListener;"},"V"));
                code.visitLabel(L15);
                code.visitStmt2R(MOVE_FROM16,18,17);
                code.visitLabel(L116);
                code.visitJumpStmt(GOTO,-1,-1,L113);
                code.visitLabel(L117);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/handler/ContextHandler;","_scontext","Lorg/mortbay/jetty/handler/ContextHandler$SContext;"));
                code.visitStmt2R(MOVE_OBJECT,6,0);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,22);
                code.visitStmt2R(MOVE_OBJECT,1,6);
                code.visitJumpStmt(IF_EQ,0,1,L25);
                code.visitLabel(L118);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/handler/ContextHandler;","_classLoader","Ljava/lang/ClassLoader;"));
                code.visitStmt2R(MOVE_OBJECT,6,0);
                code.visitJumpStmt(IF_EQZ,6,-1,L120);
                code.visitLabel(L119);
                code.visitStmt2R(MOVE_OBJECT,0,13);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,21);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/Thread;","setContextClassLoader",new String[]{ "Ljava/lang/ClassLoader;"},"V"));
                code.visitLabel(L120);
                code.visitStmt2R(MOVE_OBJECT,0,11);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,22);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Lorg/mortbay/jetty/Request;","setContext",new String[]{ "Lorg/mortbay/jetty/handler/ContextHandler$SContext;"},"V"));
                code.visitLabel(L121);
                code.visitStmt2R(MOVE_OBJECT,0,11);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,23);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Lorg/mortbay/jetty/Request;","setContextPath",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L122);
                code.visitStmt2R(MOVE_OBJECT,0,11);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,25);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Lorg/mortbay/jetty/Request;","setServletPath",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L123);
                code.visitStmt2R(MOVE_OBJECT,0,11);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,24);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Lorg/mortbay/jetty/Request;","setPathInfo",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitJumpStmt(GOTO_16,-1,-1,L25);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m046_isCompactPath(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/handler/ContextHandler;","isCompactPath",new String[]{ },"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(1071,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_BOOLEAN,0,1,new Field("Lorg/mortbay/jetty/handler/ContextHandler;","_compactPath","Z"));
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m047_isProtectedTarget(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Lorg/mortbay/jetty/handler/ContextHandler;","isProtectedTarget",new String[]{ "Ljava/lang/String;"},"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"target");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(815,L0);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m048_isShutdown(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/handler/ContextHandler;","isShutdown",new String[]{ },"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(467,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_BOOLEAN,0,1,new Field("Lorg/mortbay/jetty/handler/ContextHandler;","_shutdown","Z"));
                DexLabel L1=new DexLabel();
                code.visitJumpStmt(IF_NEZ,0,-1,L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                DexLabel L2=new DexLabel();
                code.visitLabel(L2);
                code.visitStmt1R(RETURN,0);
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m049_loadClass(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/handler/ContextHandler;","loadClass",new String[]{ "Ljava/lang/String;"},"Ljava/lang/Class;"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/lang/ClassNotFoundException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"className");
                DexLabel L3=new DexLabel();
                ddv.visitPrologue(L3);
                ddv.visitLineNumber(1094,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(1095,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(1100,L5);
                ddv.visitLineNumber(1097,L0);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(1098,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(1100,L7);
                ddv.visitLineNumber(1094,L2);
                code.visitLabel(L3);
                code.visitStmt1R(MONITOR_ENTER,1);
                code.visitJumpStmt(IF_NEZ,2,-1,L0);
                code.visitLabel(L4);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L5);
                code.visitStmt1R(MONITOR_EXIT,1);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/handler/ContextHandler;","_classLoader","Ljava/lang/ClassLoader;"));
                code.visitJumpStmt(IF_NEZ,0,-1,L7);
                code.visitLabel(L6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/lang/Object;","getClass",new String[]{ },"Ljava/lang/Class;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0,2},new Method("Lorg/mortbay/util/Loader;","loadClass",new String[]{ "Ljava/lang/Class;","Ljava/lang/String;"},"Ljava/lang/Class;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitJumpStmt(GOTO,-1,-1,L5);
                code.visitLabel(L7);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/handler/ContextHandler;","_classLoader","Ljava/lang/ClassLoader;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,2},new Method("Ljava/lang/ClassLoader;","loadClass",new String[]{ "Ljava/lang/String;"},"Ljava/lang/Class;"));
                code.visitLabel(L1);
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitJumpStmt(GOTO,-1,-1,L5);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,0);
                code.visitStmt1R(MONITOR_EXIT,1);
                code.visitStmt1R(THROW,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m050_removeAttribute(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/handler/ContextHandler;","removeAttribute",new String[]{ "Ljava/lang/String;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"name");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(824,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(825,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(826,L2);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1,2,0},new Method("Lorg/mortbay/jetty/handler/ContextHandler;","setManagedAttribute",new String[]{ "Ljava/lang/String;","Ljava/lang/Object;"},"V"));
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/handler/ContextHandler;","_attributes","Lorg/mortbay/util/AttributesMap;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,2},new Method("Lorg/mortbay/util/AttributesMap;","removeAttribute",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L2);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m051_setAllowNullPathInfo(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/handler/ContextHandler;","setAllowNullPathInfo",new String[]{ "Z"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"allowNullPathInfo");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(195,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(196,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_BOOLEAN,1,0,new Field("Lorg/mortbay/jetty/handler/ContextHandler;","_allowNullPathInfo","Z"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m052_setAttribute(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/handler/ContextHandler;","setAttribute",new String[]{ "Ljava/lang/String;","Ljava/lang/Object;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"name");
                ddv.visitParameterName(1,"value");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(837,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(838,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(839,L2);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1,2,3},new Method("Lorg/mortbay/jetty/handler/ContextHandler;","setManagedAttribute",new String[]{ "Ljava/lang/String;","Ljava/lang/Object;"},"V"));
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/handler/ContextHandler;","_attributes","Lorg/mortbay/util/AttributesMap;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,2,3},new Method("Lorg/mortbay/util/AttributesMap;","setAttribute",new String[]{ "Ljava/lang/String;","Ljava/lang/Object;"},"V"));
                code.visitLabel(L2);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m053_setAttributes(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/handler/ContextHandler;","setAttributes",new String[]{ "Lorg/mortbay/util/Attributes;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(7);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"attributes");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(847,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(849,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(850,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(851,L3);
                ddv.visitStartLocal(1,L3,"e","Ljava/util/Enumeration;",null);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(853,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(854,L5);
                ddv.visitStartLocal(2,L5,"name","Ljava/lang/String;",null);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(859,L6);
                ddv.visitEndLocal(1,L6);
                ddv.visitEndLocal(2,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(860,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(861,L8);
                ddv.visitRestartLocal(1,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(863,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(864,L10);
                ddv.visitRestartLocal(2,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(865,L11);
                ddv.visitStartLocal(3,L11,"value","Ljava/lang/Object;",null);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(866,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(869,L13);
                ddv.visitEndLocal(2,L13);
                ddv.visitEndLocal(3,L13);
                code.visitLabel(L0);
                code.visitTypeStmt(INSTANCE_OF,4,6,"Lorg/mortbay/util/AttributesMap;");
                code.visitJumpStmt(IF_EQZ,4,-1,L6);
                code.visitLabel(L1);
                code.visitStmt2R(MOVE_OBJECT,0,6);
                code.visitTypeStmt(CHECK_CAST,0,-1,"Lorg/mortbay/util/AttributesMap;");
                code.visitStmt2R(MOVE_OBJECT,4,0);
                code.visitFieldStmt(IPUT_OBJECT,4,5,new Field("Lorg/mortbay/jetty/handler/ContextHandler;","_attributes","Lorg/mortbay/util/AttributesMap;"));
                code.visitLabel(L2);
                code.visitFieldStmt(IGET_OBJECT,4,5,new Field("Lorg/mortbay/jetty/handler/ContextHandler;","_attributes","Lorg/mortbay/util/AttributesMap;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Lorg/mortbay/util/AttributesMap;","getAttributeNames",new String[]{ },"Ljava/util/Enumeration;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 1},new Method("Ljava/util/Enumeration;","hasMoreElements",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,4);
                code.visitJumpStmt(IF_EQZ,4,-1,L13);
                code.visitLabel(L4);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 1},new Method("Ljava/util/Enumeration;","nextElement",new String[]{ },"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitTypeStmt(CHECK_CAST,2,-1,"Ljava/lang/String;");
                code.visitLabel(L5);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 6,2},new Method("Lorg/mortbay/util/Attributes;","getAttribute",new String[]{ "Ljava/lang/String;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 5,2,4},new Method("Lorg/mortbay/jetty/handler/ContextHandler;","setManagedAttribute",new String[]{ "Ljava/lang/String;","Ljava/lang/Object;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L3);
                code.visitLabel(L6);
                code.visitTypeStmt(NEW_INSTANCE,4,-1,"Lorg/mortbay/util/AttributesMap;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 4},new Method("Lorg/mortbay/util/AttributesMap;","<init>",new String[]{ },"V"));
                code.visitFieldStmt(IPUT_OBJECT,4,5,new Field("Lorg/mortbay/jetty/handler/ContextHandler;","_attributes","Lorg/mortbay/util/AttributesMap;"));
                code.visitLabel(L7);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 6},new Method("Lorg/mortbay/util/Attributes;","getAttributeNames",new String[]{ },"Ljava/util/Enumeration;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L8);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 1},new Method("Ljava/util/Enumeration;","hasMoreElements",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,4);
                code.visitJumpStmt(IF_EQZ,4,-1,L13);
                code.visitLabel(L9);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 1},new Method("Ljava/util/Enumeration;","nextElement",new String[]{ },"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitTypeStmt(CHECK_CAST,2,-1,"Ljava/lang/String;");
                code.visitLabel(L10);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 6,2},new Method("Lorg/mortbay/util/Attributes;","getAttribute",new String[]{ "Ljava/lang/String;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitLabel(L11);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 5,2,3},new Method("Lorg/mortbay/jetty/handler/ContextHandler;","setManagedAttribute",new String[]{ "Ljava/lang/String;","Ljava/lang/Object;"},"V"));
                code.visitLabel(L12);
                code.visitFieldStmt(IGET_OBJECT,4,5,new Field("Lorg/mortbay/jetty/handler/ContextHandler;","_attributes","Lorg/mortbay/util/AttributesMap;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,2,3},new Method("Lorg/mortbay/util/AttributesMap;","setAttribute",new String[]{ "Ljava/lang/String;","Ljava/lang/Object;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L8);
                code.visitLabel(L13);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m054_setBaseResource(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/handler/ContextHandler;","setBaseResource",new String[]{ "Lorg/mortbay/resource/Resource;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"base");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(973,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(974,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_OBJECT,1,0,new Field("Lorg/mortbay/jetty/handler/ContextHandler;","_baseResource","Lorg/mortbay/resource/Resource;"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m055_setClassLoader(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/handler/ContextHandler;","setClassLoader",new String[]{ "Ljava/lang/ClassLoader;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"classLoader");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(902,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(903,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_OBJECT,1,0,new Field("Lorg/mortbay/jetty/handler/ContextHandler;","_classLoader","Ljava/lang/ClassLoader;"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m056_setCompactPath(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/handler/ContextHandler;","setCompactPath",new String[]{ "Z"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"compactPath");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(1080,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(1081,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_BOOLEAN,1,0,new Field("Lorg/mortbay/jetty/handler/ContextHandler;","_compactPath","Z"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m057_setConnectorNames(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/handler/ContextHandler;","setConnectorNames",new String[]{ "[Ljava/lang/String;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"connectors");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(299,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(300,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(303,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(302,L3);
                code.visitLabel(L0);
                code.visitJumpStmt(IF_EQZ,3,-1,L1);
                code.visitStmt2R(ARRAY_LENGTH,0,3);
                code.visitJumpStmt(IF_NEZ,0,-1,L3);
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT_OBJECT,0,2,new Field("Lorg/mortbay/jetty/handler/ContextHandler;","_connectors","Ljava/util/Set;"));
                code.visitLabel(L2);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L3);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/util/HashSet;");
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 3},new Method("Ljava/util/Arrays;","asList",new String[]{ "[Ljava/lang/Object;"},"Ljava/util/List;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1},new Method("Ljava/util/HashSet;","<init>",new String[]{ "Ljava/util/Collection;"},"V"));
                code.visitFieldStmt(IPUT_OBJECT,0,2,new Field("Lorg/mortbay/jetty/handler/ContextHandler;","_connectors","Ljava/util/Set;"));
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m058_setContextPath(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/handler/ContextHandler;","setContextPath",new String[]{ "Ljava/lang/String;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(6);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"contextPath");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(911,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(912,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(913,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(915,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(917,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(918,L5);
                ddv.visitStartLocal(0,L5,"contextCollections","[Lorg/mortbay/jetty/Handler;",null);
                DexLabel L6=new DexLabel();
                ddv.visitEndLocal(4,L6);
                ddv.visitStartLocal(1,L6,"h","I",null);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(919,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(918,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(921,L9);
                ddv.visitEndLocal(0,L9);
                ddv.visitEndLocal(1,L9);
                code.visitLabel(L0);
                code.visitJumpStmt(IF_EQZ,5,-1,L2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Ljava/lang/String;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitJumpStmt(IF_LE,2,3,L2);
                code.visitConstStmt(CONST_STRING,2,"/");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,2},new Method("Ljava/lang/String;","endsWith",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitJumpStmt(IF_EQZ,2,-1,L2);
                code.visitLabel(L1);
                code.visitTypeStmt(NEW_INSTANCE,2,-1,"Ljava/lang/IllegalArgumentException;");
                code.visitConstStmt(CONST_STRING,3,"ends with /");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2,3},new Method("Ljava/lang/IllegalArgumentException;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitStmt1R(THROW,2);
                code.visitLabel(L2);
                code.visitFieldStmt(IPUT_OBJECT,5,4,new Field("Lorg/mortbay/jetty/handler/ContextHandler;","_contextPath","Ljava/lang/String;"));
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Lorg/mortbay/jetty/handler/ContextHandler;","getServer",new String[]{ },"Lorg/mortbay/jetty/Server;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitJumpStmt(IF_EQZ,2,-1,L9);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Lorg/mortbay/jetty/handler/ContextHandler;","getServer",new String[]{ },"Lorg/mortbay/jetty/Server;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/jetty/Server;","isStarting",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitJumpStmt(IF_NEZ,2,-1,L4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Lorg/mortbay/jetty/handler/ContextHandler;","getServer",new String[]{ },"Lorg/mortbay/jetty/Server;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/jetty/Server;","isStarted",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitJumpStmt(IF_EQZ,2,-1,L9);
                code.visitLabel(L4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Lorg/mortbay/jetty/handler/ContextHandler;","getServer",new String[]{ },"Lorg/mortbay/jetty/Server;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitConstStmt(CONST_CLASS,3,new DexType("Lorg/mortbay/jetty/handler/ContextHandlerCollection;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3},new Method("Lorg/mortbay/jetty/Server;","getChildHandlersByClass",new String[]{ "Ljava/lang/Class;"},"[Lorg/mortbay/jetty/Handler;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L5);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L6);
                code.visitJumpStmt(IF_EQZ,0,-1,L9);
                code.visitStmt2R(ARRAY_LENGTH,2,0);
                code.visitJumpStmt(IF_GE,1,2,L9);
                code.visitLabel(L7);
                code.visitStmt3R(AGET_OBJECT,4,0,1);
                code.visitTypeStmt(CHECK_CAST,4,-1,"Lorg/mortbay/jetty/handler/ContextHandlerCollection;");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Lorg/mortbay/jetty/handler/ContextHandlerCollection;","mapContexts",new String[]{ },"V"));
                code.visitLabel(L8);
                code.visitStmt2R1N(ADD_INT_LIT8,1,1,1);
                code.visitJumpStmt(GOTO,-1,-1,L6);
                code.visitLabel(L9);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m059_setDisplayName(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/handler/ContextHandler;","setDisplayName",new String[]{ "Ljava/lang/String;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"servletContextName");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(940,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(941,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(942,L2);
                DexLabel L3=new DexLabel();
                ddv.visitEndLocal(1,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(943,L4);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_OBJECT,2,1,new Field("Lorg/mortbay/jetty/handler/ContextHandler;","_displayName","Ljava/lang/String;"));
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/handler/ContextHandler;","_classLoader","Ljava/lang/ClassLoader;"));
                code.visitJumpStmt(IF_EQZ,0,-1,L4);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/handler/ContextHandler;","_classLoader","Ljava/lang/ClassLoader;"));
                code.visitTypeStmt(INSTANCE_OF,0,0,"Lorg/mortbay/jetty/webapp/WebAppClassLoader;");
                code.visitJumpStmt(IF_EQZ,0,-1,L4);
                code.visitLabel(L2);
                code.visitFieldStmt(IGET_OBJECT,1,1,new Field("Lorg/mortbay/jetty/handler/ContextHandler;","_classLoader","Ljava/lang/ClassLoader;"));
                code.visitLabel(L3);
                code.visitTypeStmt(CHECK_CAST,1,-1,"Lorg/mortbay/jetty/webapp/WebAppClassLoader;");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2},new Method("Lorg/mortbay/jetty/webapp/WebAppClassLoader;","setName",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L4);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m060_setErrorHandler(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/handler/ContextHandler;","setErrorHandler",new String[]{ "Lorg/mortbay/jetty/handler/ErrorHandler;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(8);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"errorHandler");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(1045,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(1046,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(1047,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(1048,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(1049,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(1050,L5);
                code.visitLabel(L0);
                code.visitJumpStmt(IF_EQZ,7,-1,L2);
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Lorg/mortbay/jetty/handler/ContextHandler;","getServer",new String[]{ },"Lorg/mortbay/jetty/Server;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7,0},new Method("Lorg/mortbay/jetty/handler/ErrorHandler;","setServer",new String[]{ "Lorg/mortbay/jetty/Server;"},"V"));
                code.visitLabel(L2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Lorg/mortbay/jetty/handler/ContextHandler;","getServer",new String[]{ },"Lorg/mortbay/jetty/Server;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitJumpStmt(IF_EQZ,0,-1,L4);
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Lorg/mortbay/jetty/handler/ContextHandler;","getServer",new String[]{ },"Lorg/mortbay/jetty/Server;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/jetty/Server;","getContainer",new String[]{ },"Lorg/mortbay/component/Container;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(IGET_OBJECT,2,6,new Field("Lorg/mortbay/jetty/handler/ContextHandler;","_errorHandler","Lorg/mortbay/jetty/handler/ErrorHandler;"));
                code.visitConstStmt(CONST_STRING,4,"errorHandler");
                code.visitConstStmt(CONST_4,5, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitStmt2R(MOVE_OBJECT,1,6);
                code.visitStmt2R(MOVE_OBJECT,3,7);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 0,1,2,3,4,5},new Method("Lorg/mortbay/component/Container;","update",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;","Ljava/lang/Object;","Ljava/lang/String;","Z"},"V"));
                code.visitLabel(L4);
                code.visitFieldStmt(IPUT_OBJECT,7,6,new Field("Lorg/mortbay/jetty/handler/ContextHandler;","_errorHandler","Lorg/mortbay/jetty/handler/ErrorHandler;"));
                code.visitLabel(L5);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m061_setEventListeners(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/handler/ContextHandler;","setEventListeners",new String[]{ "[Ljava/util/EventListener;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"eventListeners");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(430,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(431,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(432,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(433,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(435,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(437,L6);
                DexLabel L7=new DexLabel();
                ddv.visitStartLocal(0,L7,"i","I",null);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(439,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(441,L9);
                ddv.visitStartLocal(1,L9,"listener","Ljava/util/EventListener;",null);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(442,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(444,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(445,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(447,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(448,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(450,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(451,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(437,L17);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(453,L18);
                ddv.visitEndLocal(1,L18);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L1);
                code.visitFieldStmt(IPUT_OBJECT,2,3,new Field("Lorg/mortbay/jetty/handler/ContextHandler;","_contextListeners","Ljava/lang/Object;"));
                code.visitLabel(L2);
                code.visitFieldStmt(IPUT_OBJECT,2,3,new Field("Lorg/mortbay/jetty/handler/ContextHandler;","_contextAttributeListeners","Ljava/lang/Object;"));
                code.visitLabel(L3);
                code.visitFieldStmt(IPUT_OBJECT,2,3,new Field("Lorg/mortbay/jetty/handler/ContextHandler;","_requestListeners","Ljava/lang/Object;"));
                code.visitLabel(L4);
                code.visitFieldStmt(IPUT_OBJECT,2,3,new Field("Lorg/mortbay/jetty/handler/ContextHandler;","_requestAttributeListeners","Ljava/lang/Object;"));
                code.visitLabel(L5);
                code.visitFieldStmt(IPUT_OBJECT,4,3,new Field("Lorg/mortbay/jetty/handler/ContextHandler;","_eventListeners","[Ljava/util/EventListener;"));
                code.visitLabel(L6);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L7);
                code.visitJumpStmt(IF_EQZ,4,-1,L18);
                code.visitStmt2R(ARRAY_LENGTH,2,4);
                code.visitJumpStmt(IF_GE,0,2,L18);
                code.visitLabel(L8);
                code.visitFieldStmt(IGET_OBJECT,2,3,new Field("Lorg/mortbay/jetty/handler/ContextHandler;","_eventListeners","[Ljava/util/EventListener;"));
                code.visitStmt3R(AGET_OBJECT,1,2,0);
                code.visitLabel(L9);
                code.visitTypeStmt(INSTANCE_OF,2,1,"Ljavax/servlet/ServletContextListener;");
                code.visitJumpStmt(IF_EQZ,2,-1,L11);
                code.visitLabel(L10);
                code.visitFieldStmt(IGET_OBJECT,2,3,new Field("Lorg/mortbay/jetty/handler/ContextHandler;","_contextListeners","Ljava/lang/Object;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 2,1},new Method("Lorg/mortbay/util/LazyList;","add",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitFieldStmt(IPUT_OBJECT,2,3,new Field("Lorg/mortbay/jetty/handler/ContextHandler;","_contextListeners","Ljava/lang/Object;"));
                code.visitLabel(L11);
                code.visitTypeStmt(INSTANCE_OF,2,1,"Ljavax/servlet/ServletContextAttributeListener;");
                code.visitJumpStmt(IF_EQZ,2,-1,L13);
                code.visitLabel(L12);
                code.visitFieldStmt(IGET_OBJECT,2,3,new Field("Lorg/mortbay/jetty/handler/ContextHandler;","_contextAttributeListeners","Ljava/lang/Object;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 2,1},new Method("Lorg/mortbay/util/LazyList;","add",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitFieldStmt(IPUT_OBJECT,2,3,new Field("Lorg/mortbay/jetty/handler/ContextHandler;","_contextAttributeListeners","Ljava/lang/Object;"));
                code.visitLabel(L13);
                code.visitTypeStmt(INSTANCE_OF,2,1,"Ljavax/servlet/ServletRequestListener;");
                code.visitJumpStmt(IF_EQZ,2,-1,L15);
                code.visitLabel(L14);
                code.visitFieldStmt(IGET_OBJECT,2,3,new Field("Lorg/mortbay/jetty/handler/ContextHandler;","_requestListeners","Ljava/lang/Object;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 2,1},new Method("Lorg/mortbay/util/LazyList;","add",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitFieldStmt(IPUT_OBJECT,2,3,new Field("Lorg/mortbay/jetty/handler/ContextHandler;","_requestListeners","Ljava/lang/Object;"));
                code.visitLabel(L15);
                code.visitTypeStmt(INSTANCE_OF,2,1,"Ljavax/servlet/ServletRequestAttributeListener;");
                code.visitJumpStmt(IF_EQZ,2,-1,L17);
                code.visitLabel(L16);
                code.visitFieldStmt(IGET_OBJECT,2,3,new Field("Lorg/mortbay/jetty/handler/ContextHandler;","_requestAttributeListeners","Ljava/lang/Object;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 2,1},new Method("Lorg/mortbay/util/LazyList;","add",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitFieldStmt(IPUT_OBJECT,2,3,new Field("Lorg/mortbay/jetty/handler/ContextHandler;","_requestAttributeListeners","Ljava/lang/Object;"));
                code.visitLabel(L17);
                code.visitStmt2R1N(ADD_INT_LIT8,0,0,1);
                code.visitJumpStmt(GOTO,-1,-1,L7);
                code.visitLabel(L18);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m062_setHosts(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/handler/ContextHandler;","setHosts",new String[]{ "[Ljava/lang/String;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"hosts");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(264,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(265,L1);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Lorg/mortbay/jetty/handler/ContextHandler;","setConnectorNames",new String[]{ "[Ljava/lang/String;"},"V"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m063_setInitParams(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/handler/ContextHandler;","setInitParams",new String[]{ "Ljava/util/Map;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"initParams");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(929,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(932,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(931,L2);
                code.visitLabel(L0);
                code.visitJumpStmt(IF_NEZ,2,-1,L2);
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L2);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/util/HashMap;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,2},new Method("Ljava/util/HashMap;","<init>",new String[]{ "Ljava/util/Map;"},"V"));
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/jetty/handler/ContextHandler;","_initParams","Ljava/util/Map;"));
                code.visitJumpStmt(GOTO,-1,-1,L1);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m064_setMaxFormContentSize(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/handler/ContextHandler;","setMaxFormContentSize",new String[]{ "I"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"maxSize");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(1061,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(1062,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT,1,0,new Field("Lorg/mortbay/jetty/handler/ContextHandler;","_maxFormContentSize","I"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m065_setMimeTypes(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/handler/ContextHandler;","setMimeTypes",new String[]{ "Lorg/mortbay/jetty/MimeTypes;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"mimeTypes");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(1008,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(1009,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_OBJECT,1,0,new Field("Lorg/mortbay/jetty/handler/ContextHandler;","_mimeTypes","Lorg/mortbay/jetty/MimeTypes;"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m066_setResourceBase(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/handler/ContextHandler;","setResourceBase",new String[]{ "Ljava/lang/String;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ "Ljava/lang/Exception;"});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"resourceBase");
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(984,L0);
                ddv.visitLineNumber(991,L1);
                ddv.visitLineNumber(986,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(988,L3);
                ddv.visitStartLocal(0,L3,"e","Ljava/lang/Exception;",null);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(989,L4);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 3},new Method("Lorg/mortbay/resource/Resource;","newResource",new String[]{ "Ljava/lang/String;"},"Lorg/mortbay/resource/Resource;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,1},new Method("Lorg/mortbay/jetty/handler/ContextHandler;","setBaseResource",new String[]{ "Lorg/mortbay/resource/Resource;"},"V"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,1);
                code.visitStmt2R(MOVE_OBJECT,0,1);
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0},new Method("Lorg/mortbay/log/Log;","warn",new String[]{ "Ljava/lang/Throwable;"},"V"));
                code.visitLabel(L4);
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Ljava/lang/IllegalArgumentException;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1,3},new Method("Ljava/lang/IllegalArgumentException;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitStmt1R(THROW,1);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m067_setServer(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/handler/ContextHandler;","setServer",new String[]{ "Lorg/mortbay/jetty/Server;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(15);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"server");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(201,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(203,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(204,L3);
                ddv.visitStartLocal(12,L3,"old_server","Lorg/mortbay/jetty/Server;",null);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(205,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(206,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(207,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(208,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(209,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(213,L9);
                ddv.visitEndLocal(12,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(212,L10);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitConstStmt(CONST_4,5, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitConstStmt(CONST_STRING,4,"error");
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,0,13,new Field("Lorg/mortbay/jetty/handler/ContextHandler;","_errorHandler","Lorg/mortbay/jetty/handler/ErrorHandler;"));
                code.visitJumpStmt(IF_EQZ,0,-1,L10);
                code.visitLabel(L2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 13},new Method("Lorg/mortbay/jetty/handler/ContextHandler;","getServer",new String[]{ },"Lorg/mortbay/jetty/Server;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,12);
                code.visitLabel(L3);
                code.visitJumpStmt(IF_EQZ,12,-1,L5);
                code.visitJumpStmt(IF_EQ,12,14,L5);
                code.visitLabel(L4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 12},new Method("Lorg/mortbay/jetty/Server;","getContainer",new String[]{ },"Lorg/mortbay/component/Container;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(IGET_OBJECT,2,13,new Field("Lorg/mortbay/jetty/handler/ContextHandler;","_errorHandler","Lorg/mortbay/jetty/handler/ErrorHandler;"));
                code.visitConstStmt(CONST_STRING,1,"error");
                code.visitStmt2R(MOVE_OBJECT,1,13);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 0,1,2,3,4,5},new Method("Lorg/mortbay/component/Container;","update",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;","Ljava/lang/Object;","Ljava/lang/String;","Z"},"V"));
                code.visitLabel(L5);
                code.visitMethodStmt(INVOKE_SUPER,new int[]{ 13,14},new Method("Lorg/mortbay/jetty/handler/HandlerWrapper;","setServer",new String[]{ "Lorg/mortbay/jetty/Server;"},"V"));
                code.visitLabel(L6);
                code.visitJumpStmt(IF_EQZ,14,-1,L8);
                code.visitJumpStmt(IF_EQ,14,12,L8);
                code.visitLabel(L7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 14},new Method("Lorg/mortbay/jetty/Server;","getContainer",new String[]{ },"Lorg/mortbay/component/Container;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitFieldStmt(IGET_OBJECT,9,13,new Field("Lorg/mortbay/jetty/handler/ContextHandler;","_errorHandler","Lorg/mortbay/jetty/handler/ErrorHandler;"));
                code.visitConstStmt(CONST_STRING,0,"error");
                code.visitStmt2R(MOVE_OBJECT,7,13);
                code.visitStmt2R(MOVE_OBJECT,8,3);
                code.visitStmt2R(MOVE_OBJECT,10,4);
                code.visitStmt2R(MOVE,11,5);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 6,7,8,9,10,11},new Method("Lorg/mortbay/component/Container;","update",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;","Ljava/lang/Object;","Ljava/lang/String;","Z"},"V"));
                code.visitLabel(L8);
                code.visitFieldStmt(IGET_OBJECT,0,13,new Field("Lorg/mortbay/jetty/handler/ContextHandler;","_errorHandler","Lorg/mortbay/jetty/handler/ErrorHandler;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,14},new Method("Lorg/mortbay/jetty/handler/ErrorHandler;","setServer",new String[]{ "Lorg/mortbay/jetty/Server;"},"V"));
                code.visitLabel(L9);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L10);
                code.visitMethodStmt(INVOKE_SUPER,new int[]{ 13,14},new Method("Lorg/mortbay/jetty/handler/HandlerWrapper;","setServer",new String[]{ "Lorg/mortbay/jetty/Server;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L9);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m068_setShutdown(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/handler/ContextHandler;","setShutdown",new String[]{ "Z"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"shutdown");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(478,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(479,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_BOOLEAN,1,0,new Field("Lorg/mortbay/jetty/handler/ContextHandler;","_shutdown","Z"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m069_setVirtualHosts(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/handler/ContextHandler;","setVirtualHosts",new String[]{ "[Ljava/lang/String;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"vhosts");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(229,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(231,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(239,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(235,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(236,L4);
                DexLabel L5=new DexLabel();
                ddv.visitStartLocal(0,L5,"i","I",null);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(237,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(236,L7);
                code.visitLabel(L0);
                code.visitJumpStmt(IF_NEZ,4,-1,L3);
                code.visitLabel(L1);
                code.visitFieldStmt(IPUT_OBJECT,4,3,new Field("Lorg/mortbay/jetty/handler/ContextHandler;","_vhosts","[Ljava/lang/String;"));
                code.visitLabel(L2);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L3);
                code.visitStmt2R(ARRAY_LENGTH,1,4);
                code.visitTypeStmt(NEW_ARRAY,1,1,"[Ljava/lang/String;");
                code.visitFieldStmt(IPUT_OBJECT,1,3,new Field("Lorg/mortbay/jetty/handler/ContextHandler;","_vhosts","[Ljava/lang/String;"));
                code.visitLabel(L4);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L5);
                code.visitStmt2R(ARRAY_LENGTH,1,4);
                code.visitJumpStmt(IF_GE,0,1,L2);
                code.visitLabel(L6);
                code.visitFieldStmt(IGET_OBJECT,1,3,new Field("Lorg/mortbay/jetty/handler/ContextHandler;","_vhosts","[Ljava/lang/String;"));
                code.visitStmt3R(AGET_OBJECT,2,4,0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 3,2},new Method("Lorg/mortbay/jetty/handler/ContextHandler;","normalizeHostname",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitStmt3R(APUT_OBJECT,2,1,0);
                code.visitLabel(L7);
                code.visitStmt2R1N(ADD_INT_LIT8,0,0,1);
                code.visitJumpStmt(GOTO,-1,-1,L5);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m070_setWelcomeFiles(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/handler/ContextHandler;","setWelcomeFiles",new String[]{ "[Ljava/lang/String;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"files");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(1016,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(1017,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_OBJECT,1,0,new Field("Lorg/mortbay/jetty/handler/ContextHandler;","_welcomeFiles","[Ljava/lang/String;"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m071_startContext(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Lorg/mortbay/jetty/handler/ContextHandler;","startContext",new String[]{ },"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/lang/Exception;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(10);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(537,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(539,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(540,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(543,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(545,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(546,L5);
                ddv.visitStartLocal(2,L5,"event","Ljavax/servlet/ServletContextEvent;",null);
                DexLabel L6=new DexLabel();
                ddv.visitStartLocal(3,L6,"i","I",null);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(548,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(546,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(552,L9);
                ddv.visitEndLocal(2,L9);
                ddv.visitEndLocal(3,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(553,L10);
                ddv.visitStartLocal(4,L10,"managedAttributes","Ljava/lang/String;",null);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(555,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(556,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(557,L13);
                ddv.visitStartLocal(0,L13,"attributes","[Ljava/lang/String;",null);
                DexLabel L14=new DexLabel();
                ddv.visitRestartLocal(3,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(558,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(557,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(560,L17);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(561,L18);
                ddv.visitStartLocal(1,L18,"e","Ljava/util/Enumeration;",null);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(563,L19);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(564,L20);
                ddv.visitStartLocal(5,L20,"name","Ljava/lang/String;",null);
                DexLabel L21=new DexLabel();
                ddv.visitLineNumber(565,L21);
                ddv.visitStartLocal(6,L21,"value","Ljava/lang/Object;",null);
                DexLabel L22=new DexLabel();
                ddv.visitLineNumber(568,L22);
                ddv.visitEndLocal(0,L22);
                ddv.visitEndLocal(3,L22);
                ddv.visitEndLocal(1,L22);
                ddv.visitEndLocal(5,L22);
                ddv.visitEndLocal(6,L22);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_SUPER,new int[]{ 9},new Method("Lorg/mortbay/jetty/handler/HandlerWrapper;","doStart",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,7,9,new Field("Lorg/mortbay/jetty/handler/ContextHandler;","_errorHandler","Lorg/mortbay/jetty/handler/ErrorHandler;"));
                code.visitJumpStmt(IF_EQZ,7,-1,L3);
                code.visitLabel(L2);
                code.visitFieldStmt(IGET_OBJECT,7,9,new Field("Lorg/mortbay/jetty/handler/ContextHandler;","_errorHandler","Lorg/mortbay/jetty/handler/ErrorHandler;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7},new Method("Lorg/mortbay/jetty/handler/ErrorHandler;","start",new String[]{ },"V"));
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,7,9,new Field("Lorg/mortbay/jetty/handler/ContextHandler;","_contextListeners","Ljava/lang/Object;"));
                code.visitJumpStmt(IF_EQZ,7,-1,L9);
                code.visitLabel(L4);
                code.visitTypeStmt(NEW_INSTANCE,2,-1,"Ljavax/servlet/ServletContextEvent;");
                code.visitFieldStmt(IGET_OBJECT,7,9,new Field("Lorg/mortbay/jetty/handler/ContextHandler;","_scontext","Lorg/mortbay/jetty/handler/ContextHandler$SContext;"));
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2,7},new Method("Ljavax/servlet/ServletContextEvent;","<init>",new String[]{ "Ljavax/servlet/ServletContext;"},"V"));
                code.visitLabel(L5);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L6);
                code.visitFieldStmt(IGET_OBJECT,7,9,new Field("Lorg/mortbay/jetty/handler/ContextHandler;","_contextListeners","Ljava/lang/Object;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 7},new Method("Lorg/mortbay/util/LazyList;","size",new String[]{ "Ljava/lang/Object;"},"I"));
                code.visitStmt1R(MOVE_RESULT,7);
                code.visitJumpStmt(IF_GE,3,7,L9);
                code.visitLabel(L7);
                code.visitFieldStmt(IGET_OBJECT,7,9,new Field("Lorg/mortbay/jetty/handler/ContextHandler;","_contextListeners","Ljava/lang/Object;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 7,3},new Method("Lorg/mortbay/util/LazyList;","get",new String[]{ "Ljava/lang/Object;","I"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitTypeStmt(CHECK_CAST,7,-1,"Ljavax/servlet/ServletContextListener;");
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 7,2},new Method("Ljavax/servlet/ServletContextListener;","contextInitialized",new String[]{ "Ljavax/servlet/ServletContextEvent;"},"V"));
                code.visitLabel(L8);
                code.visitStmt2R1N(ADD_INT_LIT8,3,3,1);
                code.visitJumpStmt(GOTO,-1,-1,L6);
                code.visitLabel(L9);
                code.visitFieldStmt(IGET_OBJECT,7,9,new Field("Lorg/mortbay/jetty/handler/ContextHandler;","_initParams","Ljava/util/Map;"));
                code.visitConstStmt(CONST_STRING,8,"org.mortbay.jetty.servlet.ManagedAttributes");
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 7,8},new Method("Ljava/util/Map;","get",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitTypeStmt(CHECK_CAST,4,-1,"Ljava/lang/String;");
                code.visitLabel(L10);
                code.visitJumpStmt(IF_EQZ,4,-1,L22);
                code.visitLabel(L11);
                code.visitTypeStmt(NEW_INSTANCE,7,-1,"Ljava/util/HashSet;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 7},new Method("Ljava/util/HashSet;","<init>",new String[]{ },"V"));
                code.visitFieldStmt(IPUT_OBJECT,7,9,new Field("Lorg/mortbay/jetty/handler/ContextHandler;","_managedAttributes","Ljava/util/Set;"));
                code.visitLabel(L12);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Ljava/lang/String;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitConstStmt(CONST_STRING,8,",");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7,8},new Method("Ljava/lang/String;","split",new String[]{ "Ljava/lang/String;"},"[Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L13);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L14);
                code.visitStmt2R(ARRAY_LENGTH,7,0);
                code.visitJumpStmt(IF_GE,3,7,L17);
                code.visitLabel(L15);
                code.visitFieldStmt(IGET_OBJECT,7,9,new Field("Lorg/mortbay/jetty/handler/ContextHandler;","_managedAttributes","Ljava/util/Set;"));
                code.visitStmt3R(AGET_OBJECT,8,0,3);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 7,8},new Method("Ljava/util/Set;","add",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitLabel(L16);
                code.visitStmt2R1N(ADD_INT_LIT8,3,3,1);
                code.visitJumpStmt(GOTO,-1,-1,L14);
                code.visitLabel(L17);
                code.visitFieldStmt(IGET_OBJECT,7,9,new Field("Lorg/mortbay/jetty/handler/ContextHandler;","_scontext","Lorg/mortbay/jetty/handler/ContextHandler$SContext;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7},new Method("Lorg/mortbay/jetty/handler/ContextHandler$SContext;","getAttributeNames",new String[]{ },"Ljava/util/Enumeration;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L18);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 1},new Method("Ljava/util/Enumeration;","hasMoreElements",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,7);
                code.visitJumpStmt(IF_EQZ,7,-1,L22);
                code.visitLabel(L19);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 1},new Method("Ljava/util/Enumeration;","nextElement",new String[]{ },"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitTypeStmt(CHECK_CAST,5,-1,"Ljava/lang/String;");
                code.visitLabel(L20);
                code.visitFieldStmt(IGET_OBJECT,7,9,new Field("Lorg/mortbay/jetty/handler/ContextHandler;","_scontext","Lorg/mortbay/jetty/handler/ContextHandler$SContext;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7,5},new Method("Lorg/mortbay/jetty/handler/ContextHandler$SContext;","getAttribute",new String[]{ "Ljava/lang/String;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitLabel(L21);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 9,5,6},new Method("Lorg/mortbay/jetty/handler/ContextHandler;","setManagedAttribute",new String[]{ "Ljava/lang/String;","Ljava/lang/Object;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L18);
                code.visitLabel(L22);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m072_toString(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/handler/ContextHandler;","toString",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(1087,L0);
                code.visitLabel(L0);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Ljava/lang/Object;","getClass",new String[]{ },"Ljava/lang/Class;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/lang/Class;","getName",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitConstStmt(CONST_STRING,1,"@");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Ljava/lang/Object;","hashCode",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1},new Method("Ljava/lang/Integer;","toHexString",new String[]{ "I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitConstStmt(CONST_STRING,1,"{");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/jetty/handler/ContextHandler;","getContextPath",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitConstStmt(CONST_STRING,1,",");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/jetty/handler/ContextHandler;","getBaseResource",new String[]{ },"Lorg/mortbay/resource/Resource;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitConstStmt(CONST_STRING,1,"}");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
