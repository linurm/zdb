package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0309_org_mortbay_jetty_security_SslSocketConnector_SslConnection {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(ACC_PUBLIC,"Lorg/mortbay/jetty/security/SslSocketConnector$SslConnection;","Lorg/mortbay/jetty/bio/SocketConnector$Connection;",new String[]{ });
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("SslSocketConnector.java");
        if(cv!=null){
            DexAnnotationVisitor av00 = cv.visitAnnotation("Ldalvik/annotation/EnclosingClass;", Visibility.SYSTEM);
            if(av00 != null) {
                av00.visit("value", new DexType("Lorg/mortbay/jetty/security/SslSocketConnector;"));
                av00.visitEnd();
            }
        }
        if(cv!=null){
            DexAnnotationVisitor av00 = cv.visitAnnotation("Ldalvik/annotation/InnerClass;", Visibility.SYSTEM);
            if(av00 != null) {
                av00.visit("accessFlags",  Integer.valueOf(1));
                av00.visit("name", "SslConnection");
                av00.visitEnd();
            }
        }
        f000_this$0(cv);
        m000__init_(cv);
        m001_run(cv);
    }
    public static void f000_this$0(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_FINAL|ACC_SYNTHETIC, new Field("Lorg/mortbay/jetty/security/SslSocketConnector$SslConnection;","this$0","Lorg/mortbay/jetty/security/SslSocketConnector;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void m000__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/jetty/security/SslSocketConnector$SslConnection;","<init>",new String[]{ "Lorg/mortbay/jetty/security/SslSocketConnector;","Ljava/net/Socket;"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(1,"socket");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(618,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(619,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(620,L2);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_OBJECT,1,0,new Field("Lorg/mortbay/jetty/security/SslSocketConnector$SslConnection;","this$0","Lorg/mortbay/jetty/security/SslSocketConnector;"));
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1,2},new Method("Lorg/mortbay/jetty/bio/SocketConnector$Connection;","<init>",new String[]{ "Lorg/mortbay/jetty/bio/SocketConnector;","Ljava/net/Socket;"},"V"));
                code.visitLabel(L2);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001_run(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/security/SslSocketConnector$SslConnection;","run",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(6);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                DexLabel L3=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2,L3},new String[]{ "Ljavax/net/ssl/SSLException;","Ljava/io/IOException;"});
                DexLabel L4=new DexLabel();
                DexLabel L5=new DexLabel();
                DexLabel L6=new DexLabel();
                code.visitTryCatch(L4,L5,new DexLabel[]{L6},new String[]{ "Ljava/io/IOException;"});
                DexLabel L7=new DexLabel();
                DexLabel L8=new DexLabel();
                DexLabel L9=new DexLabel();
                code.visitTryCatch(L7,L8,new DexLabel[]{L9},new String[]{ "Ljava/io/IOException;"});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(626,L0);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(627,L10);
                ddv.visitStartLocal(2,L10,"handshakeTimeout","I",null);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(628,L11);
                ddv.visitStartLocal(3,L11,"oldTimeout","I",null);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(629,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(631,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(633,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(634,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(636,L16);
                ddv.visitLineNumber(650,L1);
                ddv.visitEndLocal(2,L1);
                ddv.visitEndLocal(3,L1);
                ddv.visitLineNumber(638,L2);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(640,L17);
                ddv.visitStartLocal(0,L17,"e","Ljavax/net/ssl/SSLException;",null);
                ddv.visitLineNumber(641,L4);
                ddv.visitLineNumber(642,L6);
                DexLabel L18=new DexLabel();
                ddv.visitStartLocal(1,L18,"e2","Ljava/io/IOException;",null);
                ddv.visitLineNumber(644,L3);
                ddv.visitEndLocal(0,L3);
                ddv.visitEndLocal(1,L3);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(646,L19);
                ddv.visitStartLocal(0,L19,"e","Ljava/io/IOException;",null);
                ddv.visitLineNumber(647,L7);
                ddv.visitLineNumber(648,L9);
                DexLabel L20=new DexLabel();
                ddv.visitRestartLocal(1,L20);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,4,5,new Field("Lorg/mortbay/jetty/security/SslSocketConnector$SslConnection;","this$0","Lorg/mortbay/jetty/security/SslSocketConnector;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Lorg/mortbay/jetty/security/SslSocketConnector;","getHandshakeTimeout",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitLabel(L10);
                code.visitFieldStmt(IGET_OBJECT,4,5,new Field("Lorg/mortbay/jetty/security/SslSocketConnector$SslConnection;","_socket","Ljava/net/Socket;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Ljava/net/Socket;","getSoTimeout",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitLabel(L11);
                code.visitJumpStmt(IF_LEZ,2,-1,L13);
                code.visitLabel(L12);
                code.visitFieldStmt(IGET_OBJECT,4,5,new Field("Lorg/mortbay/jetty/security/SslSocketConnector$SslConnection;","_socket","Ljava/net/Socket;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,2},new Method("Ljava/net/Socket;","setSoTimeout",new String[]{ "I"},"V"));
                code.visitLabel(L13);
                code.visitFieldStmt(IGET_OBJECT,4,5,new Field("Lorg/mortbay/jetty/security/SslSocketConnector$SslConnection;","_socket","Ljava/net/Socket;"));
                code.visitTypeStmt(CHECK_CAST,4,-1,"Ljavax/net/ssl/SSLSocket;");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Ljavax/net/ssl/SSLSocket;","startHandshake",new String[]{ },"V"));
                code.visitLabel(L14);
                code.visitJumpStmt(IF_LEZ,2,-1,L16);
                code.visitLabel(L15);
                code.visitFieldStmt(IGET_OBJECT,4,5,new Field("Lorg/mortbay/jetty/security/SslSocketConnector$SslConnection;","_socket","Ljava/net/Socket;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,3},new Method("Ljava/net/Socket;","setSoTimeout",new String[]{ "I"},"V"));
                code.visitLabel(L16);
                code.visitMethodStmt(INVOKE_SUPER,new int[]{ 5},new Method("Lorg/mortbay/jetty/bio/SocketConnector$Connection;","run",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,4);
                code.visitStmt2R(MOVE_OBJECT,0,4);
                code.visitLabel(L17);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0},new Method("Lorg/mortbay/log/Log;","warn",new String[]{ "Ljava/lang/Throwable;"},"V"));
                code.visitLabel(L4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Lorg/mortbay/jetty/security/SslSocketConnector$SslConnection;","close",new String[]{ },"V"));
                code.visitLabel(L5);
                code.visitJumpStmt(GOTO,-1,-1,L1);
                code.visitLabel(L6);
                code.visitStmt1R(MOVE_EXCEPTION,1);
                code.visitLabel(L18);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1},new Method("Lorg/mortbay/log/Log;","ignore",new String[]{ "Ljava/lang/Throwable;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L1);
                code.visitLabel(L3);
                code.visitStmt1R(MOVE_EXCEPTION,4);
                code.visitStmt2R(MOVE_OBJECT,0,4);
                code.visitLabel(L19);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0},new Method("Lorg/mortbay/log/Log;","debug",new String[]{ "Ljava/lang/Throwable;"},"V"));
                code.visitLabel(L7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Lorg/mortbay/jetty/security/SslSocketConnector$SslConnection;","close",new String[]{ },"V"));
                code.visitLabel(L8);
                code.visitJumpStmt(GOTO,-1,-1,L1);
                code.visitLabel(L9);
                code.visitStmt1R(MOVE_EXCEPTION,1);
                code.visitLabel(L20);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1},new Method("Lorg/mortbay/log/Log;","ignore",new String[]{ "Ljava/lang/Throwable;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L1);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
