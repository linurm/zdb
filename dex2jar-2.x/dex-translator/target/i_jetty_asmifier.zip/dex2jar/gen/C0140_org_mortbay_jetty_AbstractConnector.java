package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0140_org_mortbay_jetty_AbstractConnector {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(ACC_PUBLIC|ACC_ABSTRACT,"Lorg/mortbay/jetty/AbstractConnector;","Lorg/mortbay/jetty/AbstractBuffers;",new String[]{ "Lorg/mortbay/jetty/Connector;"});
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("AbstractConnector.java");
        if(cv!=null){
            DexAnnotationVisitor av00 = cv.visitAnnotation("Ldalvik/annotation/MemberClasses;", Visibility.SYSTEM);
            if(av00 != null) {
                {
                    DexAnnotationVisitor av01 = av00.visitArray("value");
                    if(av01 != null) {
                        av01.visit(null, new DexType("Lorg/mortbay/jetty/AbstractConnector$Acceptor;"));
                        av01.visitEnd();
                    }
                }
                av00.visitEnd();
            }
        }
        f000__acceptQueueSize(cv);
        f001__acceptorPriorityOffset(cv);
        f002__acceptorThread(cv);
        f003__acceptors(cv);
        f004__confidentialPort(cv);
        f005__confidentialScheme(cv);
        f006__connections(cv);
        f007__connectionsDurationMax(cv);
        f008__connectionsDurationMin(cv);
        f009__connectionsDurationTotal(cv);
        f010__connectionsOpen(cv);
        f011__connectionsOpenMax(cv);
        f012__connectionsOpenMin(cv);
        f013__connectionsRequestsMax(cv);
        f014__connectionsRequestsMin(cv);
        f015__forwarded(cv);
        f016__forwardedForHeader(cv);
        f017__forwardedHostHeader(cv);
        f018__forwardedServerHeader(cv);
        f019__host(cv);
        f020__hostHeader(cv);
        f021__integralPort(cv);
        f022__integralScheme(cv);
        f023__lowResourceMaxIdleTime(cv);
        f024__maxIdleTime(cv);
        f025__name(cv);
        f026__port(cv);
        f027__requests(cv);
        f028__reuseAddress(cv);
        f029__server(cv);
        f030__soLingerTime(cv);
        f031__statsLock(cv);
        f032__statsStartedAt(cv);
        f033__threadPool(cv);
        f034__useDNS(cv);
        m000__init_(cv);
        m001_access$000(cv);
        m002_access$100(cv);
        m003_accept(cv);
        m004_checkForwardedHeaders(cv);
        m005_configure(cv);
        m006_connectionClosed(cv);
        m007_connectionOpened(cv);
        m008_customize(cv);
        m009_doStart(cv);
        m010_doStop(cv);
        m011_getAcceptQueueSize(cv);
        m012_getAcceptorPriorityOffset(cv);
        m013_getAcceptors(cv);
        m014_getConfidentialPort(cv);
        m015_getConfidentialScheme(cv);
        m016_getConnections(cv);
        m017_getConnectionsDurationAve(cv);
        m018_getConnectionsDurationMax(cv);
        m019_getConnectionsDurationMin(cv);
        m020_getConnectionsDurationTotal(cv);
        m021_getConnectionsOpen(cv);
        m022_getConnectionsOpenMax(cv);
        m023_getConnectionsOpenMin(cv);
        m024_getConnectionsRequestsAve(cv);
        m025_getConnectionsRequestsMax(cv);
        m026_getConnectionsRequestsMin(cv);
        m027_getForwardedForHeader(cv);
        m028_getForwardedHostHeader(cv);
        m029_getForwardedServerHeader(cv);
        m030_getHost(cv);
        m031_getHostHeader(cv);
        m032_getIntegralPort(cv);
        m033_getIntegralScheme(cv);
        m034_getLeftMostValue(cv);
        m035_getLowResourceMaxIdleTime(cv);
        m036_getMaxIdleTime(cv);
        m037_getName(cv);
        m038_getPort(cv);
        m039_getRequests(cv);
        m040_getResolveNames(cv);
        m041_getReuseAddress(cv);
        m042_getServer(cv);
        m043_getSoLingerTime(cv);
        m044_getStatsOn(cv);
        m045_getStatsOnMs(cv);
        m046_getThreadPool(cv);
        m047_isConfidential(cv);
        m048_isForwarded(cv);
        m049_isIntegral(cv);
        m050_join(cv);
        m051_newContinuation(cv);
        m052_persist(cv);
        m053_setAcceptQueueSize(cv);
        m054_setAcceptorPriorityOffset(cv);
        m055_setAcceptors(cv);
        m056_setConfidentialPort(cv);
        m057_setConfidentialScheme(cv);
        m058_setForwarded(cv);
        m059_setForwardedForHeader(cv);
        m060_setForwardedHostHeader(cv);
        m061_setForwardedServerHeader(cv);
        m062_setHost(cv);
        m063_setHostHeader(cv);
        m064_setIntegralPort(cv);
        m065_setIntegralScheme(cv);
        m066_setLowResourceMaxIdleTime(cv);
        m067_setMaxIdleTime(cv);
        m068_setName(cv);
        m069_setPort(cv);
        m070_setResolveNames(cv);
        m071_setReuseAddress(cv);
        m072_setServer(cv);
        m073_setSoLingerTime(cv);
        m074_setStatsOn(cv);
        m075_setThreadPool(cv);
        m076_statsReset(cv);
        m077_stopAccept(cv);
        m078_toString(cv);
    }
    public static void f000__acceptQueueSize(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/AbstractConnector;","_acceptQueueSize","I"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f001__acceptorPriorityOffset(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/AbstractConnector;","_acceptorPriorityOffset","I"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f002__acceptorThread(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE|ACC_TRANSIENT, new Field("Lorg/mortbay/jetty/AbstractConnector;","_acceptorThread","[Ljava/lang/Thread;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f003__acceptors(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/AbstractConnector;","_acceptors","I"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f004__confidentialPort(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/AbstractConnector;","_confidentialPort","I"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f005__confidentialScheme(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/AbstractConnector;","_confidentialScheme","Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f006__connections(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_TRANSIENT, new Field("Lorg/mortbay/jetty/AbstractConnector;","_connections","I"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f007__connectionsDurationMax(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_TRANSIENT, new Field("Lorg/mortbay/jetty/AbstractConnector;","_connectionsDurationMax","J"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f008__connectionsDurationMin(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_TRANSIENT, new Field("Lorg/mortbay/jetty/AbstractConnector;","_connectionsDurationMin","J"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f009__connectionsDurationTotal(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_TRANSIENT, new Field("Lorg/mortbay/jetty/AbstractConnector;","_connectionsDurationTotal","J"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f010__connectionsOpen(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_TRANSIENT, new Field("Lorg/mortbay/jetty/AbstractConnector;","_connectionsOpen","I"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f011__connectionsOpenMax(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_TRANSIENT, new Field("Lorg/mortbay/jetty/AbstractConnector;","_connectionsOpenMax","I"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f012__connectionsOpenMin(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_TRANSIENT, new Field("Lorg/mortbay/jetty/AbstractConnector;","_connectionsOpenMin","I"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f013__connectionsRequestsMax(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_TRANSIENT, new Field("Lorg/mortbay/jetty/AbstractConnector;","_connectionsRequestsMax","I"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f014__connectionsRequestsMin(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_TRANSIENT, new Field("Lorg/mortbay/jetty/AbstractConnector;","_connectionsRequestsMin","I"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f015__forwarded(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/AbstractConnector;","_forwarded","Z"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f016__forwardedForHeader(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/AbstractConnector;","_forwardedForHeader","Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f017__forwardedHostHeader(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/AbstractConnector;","_forwardedHostHeader","Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f018__forwardedServerHeader(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/AbstractConnector;","_forwardedServerHeader","Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f019__host(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/AbstractConnector;","_host","Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f020__hostHeader(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/AbstractConnector;","_hostHeader","Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f021__integralPort(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/AbstractConnector;","_integralPort","I"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f022__integralScheme(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/AbstractConnector;","_integralScheme","Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f023__lowResourceMaxIdleTime(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PROTECTED, new Field("Lorg/mortbay/jetty/AbstractConnector;","_lowResourceMaxIdleTime","I"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f024__maxIdleTime(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PROTECTED, new Field("Lorg/mortbay/jetty/AbstractConnector;","_maxIdleTime","I"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f025__name(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/AbstractConnector;","_name","Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f026__port(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/AbstractConnector;","_port","I"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f027__requests(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_TRANSIENT, new Field("Lorg/mortbay/jetty/AbstractConnector;","_requests","I"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f028__reuseAddress(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/AbstractConnector;","_reuseAddress","Z"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f029__server(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/AbstractConnector;","_server","Lorg/mortbay/jetty/Server;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f030__soLingerTime(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PROTECTED, new Field("Lorg/mortbay/jetty/AbstractConnector;","_soLingerTime","I"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f031__statsLock(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(0, new Field("Lorg/mortbay/jetty/AbstractConnector;","_statsLock","Ljava/lang/Object;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f032__statsStartedAt(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_TRANSIENT, new Field("Lorg/mortbay/jetty/AbstractConnector;","_statsStartedAt","J"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f033__threadPool(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/AbstractConnector;","_threadPool","Lorg/mortbay/thread/ThreadPool;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f034__useDNS(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/AbstractConnector;","_useDNS","Z"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void m000__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/jetty/AbstractConnector;","<init>",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(6);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(97,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(54,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(55,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(56,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(57,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(58,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(59,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(60,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(61,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(65,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(66,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(67,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(68,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(70,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(71,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(72,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(76,L17);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(77,L18);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(98,L19);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitConstStmt(CONST_4,2, Integer.valueOf(-1)); // int: 0xffffffff  float:NaN
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitConstStmt(CONST_STRING,4,"https");
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 5},new Method("Lorg/mortbay/jetty/AbstractBuffers;","<init>",new String[]{ },"V"));
                code.visitLabel(L2);
                code.visitFieldStmt(IPUT,1,5,new Field("Lorg/mortbay/jetty/AbstractConnector;","_port","I"));
                code.visitLabel(L3);
                code.visitConstStmt(CONST_STRING,0,"https");
                code.visitFieldStmt(IPUT_OBJECT,4,5,new Field("Lorg/mortbay/jetty/AbstractConnector;","_integralScheme","Ljava/lang/String;"));
                code.visitLabel(L4);
                code.visitFieldStmt(IPUT,1,5,new Field("Lorg/mortbay/jetty/AbstractConnector;","_integralPort","I"));
                code.visitLabel(L5);
                code.visitConstStmt(CONST_STRING,0,"https");
                code.visitFieldStmt(IPUT_OBJECT,4,5,new Field("Lorg/mortbay/jetty/AbstractConnector;","_confidentialScheme","Ljava/lang/String;"));
                code.visitLabel(L6);
                code.visitFieldStmt(IPUT,1,5,new Field("Lorg/mortbay/jetty/AbstractConnector;","_confidentialPort","I"));
                code.visitLabel(L7);
                code.visitFieldStmt(IPUT,1,5,new Field("Lorg/mortbay/jetty/AbstractConnector;","_acceptQueueSize","I"));
                code.visitLabel(L8);
                code.visitFieldStmt(IPUT,3,5,new Field("Lorg/mortbay/jetty/AbstractConnector;","_acceptors","I"));
                code.visitLabel(L9);
                code.visitFieldStmt(IPUT,1,5,new Field("Lorg/mortbay/jetty/AbstractConnector;","_acceptorPriorityOffset","I"));
                code.visitLabel(L10);
                code.visitConstStmt(CONST_STRING,0,"X-Forwarded-Host");
                code.visitFieldStmt(IPUT_OBJECT,0,5,new Field("Lorg/mortbay/jetty/AbstractConnector;","_forwardedHostHeader","Ljava/lang/String;"));
                code.visitLabel(L11);
                code.visitConstStmt(CONST_STRING,0,"X-Forwarded-Server");
                code.visitFieldStmt(IPUT_OBJECT,0,5,new Field("Lorg/mortbay/jetty/AbstractConnector;","_forwardedServerHeader","Ljava/lang/String;"));
                code.visitLabel(L12);
                code.visitConstStmt(CONST_STRING,0,"X-Forwarded-For");
                code.visitFieldStmt(IPUT_OBJECT,0,5,new Field("Lorg/mortbay/jetty/AbstractConnector;","_forwardedForHeader","Ljava/lang/String;"));
                code.visitLabel(L13);
                code.visitFieldStmt(IPUT_BOOLEAN,3,5,new Field("Lorg/mortbay/jetty/AbstractConnector;","_reuseAddress","Z"));
                code.visitLabel(L14);
                code.visitConstStmt(CONST,0, Integer.valueOf(200000)); // int: 0x00030d40  float:0.000000
                code.visitFieldStmt(IPUT,0,5,new Field("Lorg/mortbay/jetty/AbstractConnector;","_maxIdleTime","I"));
                code.visitLabel(L15);
                code.visitFieldStmt(IPUT,2,5,new Field("Lorg/mortbay/jetty/AbstractConnector;","_lowResourceMaxIdleTime","I"));
                code.visitLabel(L16);
                code.visitFieldStmt(IPUT,2,5,new Field("Lorg/mortbay/jetty/AbstractConnector;","_soLingerTime","I"));
                code.visitLabel(L17);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/lang/Object;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/lang/Object;","<init>",new String[]{ },"V"));
                code.visitFieldStmt(IPUT_OBJECT,0,5,new Field("Lorg/mortbay/jetty/AbstractConnector;","_statsLock","Ljava/lang/Object;"));
                code.visitLabel(L18);
                code.visitConstStmt(CONST_WIDE_16,0,Long.valueOf(-1L)); // long: 0xffffffffffffffff  double:NaN
                code.visitFieldStmt(IPUT_WIDE,0,5,new Field("Lorg/mortbay/jetty/AbstractConnector;","_statsStartedAt","J"));
                code.visitLabel(L19);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001_access$000(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_STATIC|ACC_SYNTHETIC, new Method("Lorg/mortbay/jetty/AbstractConnector;","access$000",new String[]{ "Lorg/mortbay/jetty/AbstractConnector;"},"[Ljava/lang/Thread;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"x0");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(47,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/AbstractConnector;","_acceptorThread","[Ljava/lang/Thread;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m002_access$100(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_STATIC|ACC_SYNTHETIC, new Method("Lorg/mortbay/jetty/AbstractConnector;","access$100",new String[]{ "Lorg/mortbay/jetty/AbstractConnector;"},"I"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"x0");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(47,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET,0,1,new Field("Lorg/mortbay/jetty/AbstractConnector;","_acceptorPriorityOffset","I"));
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m003_accept(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED|ACC_ABSTRACT, new Method("Lorg/mortbay/jetty/AbstractConnector;","accept",new String[]{ "I"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visit(null, new DexType("Ljava/lang/InterruptedException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            mv.visitEnd();
        }
    }
    public static void m004_checkForwardedHeaders(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Lorg/mortbay/jetty/AbstractConnector;","checkForwardedHeaders",new String[]{ "Lorg/mortbay/io/EndPoint;","Lorg/mortbay/jetty/Request;"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(13);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ "Ljava/net/UnknownHostException;"});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"endpoint");
                ddv.visitParameterName(1,"request");
                DexLabel L3=new DexLabel();
                ddv.visitPrologue(L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(383,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(386,L5);
                ddv.visitStartLocal(4,L5,"httpFields","Lorg/mortbay/jetty/HttpFields;",null);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(387,L6);
                ddv.visitStartLocal(2,L6,"forwardedHost","Ljava/lang/String;",null);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(388,L7);
                ddv.visitStartLocal(3,L7,"forwardedServer","Ljava/lang/String;",null);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(390,L8);
                ddv.visitStartLocal(1,L8,"forwardedFor","Ljava/lang/String;",null);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(393,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(394,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(395,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(396,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(407,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(410,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(413,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(415,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(416,L17);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(418,L18);
                ddv.visitStartLocal(5,L18,"inetAddress","Ljava/net/InetAddress;",null);
                ddv.visitLineNumber(422,L0);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(430,L19);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(432,L20);
                ddv.visitEndLocal(5,L20);
                DexLabel L21=new DexLabel();
                ddv.visitLineNumber(398,L21);
                DexLabel L22=new DexLabel();
                ddv.visitLineNumber(401,L22);
                DexLabel L23=new DexLabel();
                ddv.visitLineNumber(402,L23);
                DexLabel L24=new DexLabel();
                ddv.visitLineNumber(403,L24);
                DexLabel L25=new DexLabel();
                ddv.visitLineNumber(404,L25);
                ddv.visitLineNumber(424,L2);
                ddv.visitRestartLocal(5,L2);
                DexLabel L26=new DexLabel();
                ddv.visitLineNumber(426,L26);
                ddv.visitStartLocal(0,L26,"e","Ljava/net/UnknownHostException;",null);
                DexLabel L27=new DexLabel();
                ddv.visitLineNumber(430,L27);
                ddv.visitEndLocal(0,L27);
                code.visitLabel(L3);
                code.visitConstStmt(CONST_4,9, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitConstStmt(CONST_4,8, Integer.valueOf(-1)); // int: 0xffffffff  float:NaN
                code.visitLabel(L4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 12},new Method("Lorg/mortbay/jetty/Request;","getConnection",new String[]{ },"Lorg/mortbay/jetty/HttpConnection;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Lorg/mortbay/jetty/HttpConnection;","getRequestFields",new String[]{ },"Lorg/mortbay/jetty/HttpFields;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitLabel(L5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10},new Method("Lorg/mortbay/jetty/AbstractConnector;","getForwardedHostHeader",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,6},new Method("Lorg/mortbay/jetty/HttpFields;","getStringField",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10,6},new Method("Lorg/mortbay/jetty/AbstractConnector;","getLeftMostValue",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitLabel(L6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10},new Method("Lorg/mortbay/jetty/AbstractConnector;","getForwardedServerHeader",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,6},new Method("Lorg/mortbay/jetty/HttpFields;","getStringField",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10,6},new Method("Lorg/mortbay/jetty/AbstractConnector;","getLeftMostValue",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitLabel(L7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10},new Method("Lorg/mortbay/jetty/AbstractConnector;","getForwardedForHeader",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,6},new Method("Lorg/mortbay/jetty/HttpFields;","getStringField",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10,6},new Method("Lorg/mortbay/jetty/AbstractConnector;","getLeftMostValue",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L8);
                code.visitFieldStmt(IGET_OBJECT,6,10,new Field("Lorg/mortbay/jetty/AbstractConnector;","_hostHeader","Ljava/lang/String;"));
                code.visitJumpStmt(IF_EQZ,6,-1,L21);
                code.visitLabel(L9);
                code.visitFieldStmt(SGET_OBJECT,6,-1,new Field("Lorg/mortbay/jetty/HttpHeaders;","HOST_BUFFER","Lorg/mortbay/io/Buffer;"));
                code.visitFieldStmt(IGET_OBJECT,7,10,new Field("Lorg/mortbay/jetty/AbstractConnector;","_hostHeader","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,6,7},new Method("Lorg/mortbay/jetty/HttpFields;","put",new String[]{ "Lorg/mortbay/io/Buffer;","Ljava/lang/String;"},"V"));
                code.visitLabel(L10);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 12,9},new Method("Lorg/mortbay/jetty/Request;","setServerName",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L11);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 12,8},new Method("Lorg/mortbay/jetty/Request;","setServerPort",new String[]{ "I"},"V"));
                code.visitLabel(L12);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 12},new Method("Lorg/mortbay/jetty/Request;","getServerName",new String[]{ },"Ljava/lang/String;"));
                code.visitLabel(L13);
                code.visitJumpStmt(IF_EQZ,3,-1,L15);
                code.visitLabel(L14);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 12,3},new Method("Lorg/mortbay/jetty/Request;","setServerName",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L15);
                code.visitJumpStmt(IF_EQZ,1,-1,L20);
                code.visitLabel(L16);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 12,1},new Method("Lorg/mortbay/jetty/Request;","setRemoteAddr",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L17);
                code.visitConstStmt(CONST_4,5, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L18);
                code.visitFieldStmt(IGET_BOOLEAN,6,10,new Field("Lorg/mortbay/jetty/AbstractConnector;","_useDNS","Z"));
                code.visitJumpStmt(IF_EQZ,6,-1,L19);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1},new Method("Ljava/net/InetAddress;","getByName",new String[]{ "Ljava/lang/String;"},"Ljava/net/InetAddress;"));
                code.visitLabel(L1);
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitLabel(L19);
                code.visitJumpStmt(IF_NEZ,5,-1,L27);
                code.visitStmt2R(MOVE_OBJECT,6,1);
                DexLabel L28=new DexLabel();
                code.visitLabel(L28);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 12,6},new Method("Lorg/mortbay/jetty/Request;","setRemoteHost",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L20);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L21);
                code.visitJumpStmt(IF_EQZ,2,-1,L13);
                code.visitLabel(L22);
                code.visitFieldStmt(SGET_OBJECT,6,-1,new Field("Lorg/mortbay/jetty/HttpHeaders;","HOST_BUFFER","Lorg/mortbay/io/Buffer;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,6,2},new Method("Lorg/mortbay/jetty/HttpFields;","put",new String[]{ "Lorg/mortbay/io/Buffer;","Ljava/lang/String;"},"V"));
                code.visitLabel(L23);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 12,9},new Method("Lorg/mortbay/jetty/Request;","setServerName",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L24);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 12,8},new Method("Lorg/mortbay/jetty/Request;","setServerPort",new String[]{ "I"},"V"));
                code.visitLabel(L25);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 12},new Method("Lorg/mortbay/jetty/Request;","getServerName",new String[]{ },"Ljava/lang/String;"));
                code.visitJumpStmt(GOTO,-1,-1,L13);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,0);
                code.visitLabel(L26);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0},new Method("Lorg/mortbay/log/Log;","ignore",new String[]{ "Ljava/lang/Throwable;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L19);
                code.visitLabel(L27);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Ljava/net/InetAddress;","getHostName",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitJumpStmt(GOTO,-1,-1,L28);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m005_configure(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Lorg/mortbay/jetty/AbstractConnector;","configure",new String[]{ "Ljava/net/Socket;"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ "Ljava/lang/Exception;"});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"socket");
                DexLabel L3=new DexLabel();
                ddv.visitPrologue(L3);
                ddv.visitLineNumber(356,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(357,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(358,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(359,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(360,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(368,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(362,L9);
                ddv.visitLineNumber(364,L2);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(366,L10);
                ddv.visitStartLocal(0,L10,"e","Ljava/lang/Exception;",null);
                code.visitLabel(L3);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,1},new Method("Ljava/net/Socket;","setTcpNoDelay",new String[]{ "Z"},"V"));
                code.visitLabel(L4);
                code.visitFieldStmt(IGET,1,3,new Field("Lorg/mortbay/jetty/AbstractConnector;","_maxIdleTime","I"));
                code.visitJumpStmt(IF_LTZ,1,-1,L6);
                code.visitLabel(L5);
                code.visitFieldStmt(IGET,1,3,new Field("Lorg/mortbay/jetty/AbstractConnector;","_maxIdleTime","I"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,1},new Method("Ljava/net/Socket;","setSoTimeout",new String[]{ "I"},"V"));
                code.visitLabel(L6);
                code.visitFieldStmt(IGET,1,3,new Field("Lorg/mortbay/jetty/AbstractConnector;","_soLingerTime","I"));
                code.visitJumpStmt(IF_LTZ,1,-1,L9);
                code.visitLabel(L7);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitFieldStmt(IGET,2,3,new Field("Lorg/mortbay/jetty/AbstractConnector;","_soLingerTime","I"));
                code.visitStmt2R1N(DIV_INT_LIT16,2,2,1000);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,1,2},new Method("Ljava/net/Socket;","setSoLinger",new String[]{ "Z","I"},"V"));
                code.visitLabel(L8);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L9);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,1,2},new Method("Ljava/net/Socket;","setSoLinger",new String[]{ "Z","I"},"V"));
                code.visitLabel(L1);
                code.visitJumpStmt(GOTO,-1,-1,L8);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,1);
                code.visitStmt2R(MOVE_OBJECT,0,1);
                code.visitLabel(L10);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0},new Method("Lorg/mortbay/log/Log;","ignore",new String[]{ "Ljava/lang/Throwable;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L8);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m006_connectionClosed(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Lorg/mortbay/jetty/AbstractConnector;","connectionClosed",new String[]{ "Lorg/mortbay/jetty/HttpConnection;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(11);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexLabel L3=new DexLabel();
                DexLabel L4=new DexLabel();
                code.visitTryCatch(L3,L4,new DexLabel[]{L2},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"connection");
                DexLabel L5=new DexLabel();
                ddv.visitPrologue(L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(930,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(932,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(933,L8);
                ddv.visitStartLocal(0,L8,"duration","J",null);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(934,L9);
                ddv.visitStartLocal(2,L9,"requests","I",null);
                ddv.visitLineNumber(936,L0);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(937,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(938,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(939,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(940,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(941,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(942,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(943,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(944,L17);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(945,L18);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(946,L19);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(947,L20);
                DexLabel L21=new DexLabel();
                ddv.visitLineNumber(948,L21);
                DexLabel L22=new DexLabel();
                ddv.visitLineNumber(949,L22);
                DexLabel L23=new DexLabel();
                ddv.visitLineNumber(950,L23);
                DexLabel L24=new DexLabel();
                ddv.visitLineNumber(951,L24);
                DexLabel L25=new DexLabel();
                ddv.visitLineNumber(952,L25);
                ddv.visitLineNumber(955,L1);
                ddv.visitEndLocal(0,L1);
                ddv.visitEndLocal(2,L1);
                DexLabel L26=new DexLabel();
                ddv.visitLineNumber(956,L26);
                ddv.visitLineNumber(952,L2);
                ddv.visitRestartLocal(0,L2);
                ddv.visitRestartLocal(2,L2);
                code.visitLabel(L5);
                code.visitConstStmt(CONST_WIDE_16,7,Long.valueOf(0L)); // long: 0x0000000000000000  double:0.000000
                code.visitLabel(L6);
                code.visitFieldStmt(IGET_WIDE,3,9,new Field("Lorg/mortbay/jetty/AbstractConnector;","_statsStartedAt","J"));
                code.visitStmt3R(CMP_LONG,3,3,7);
                code.visitJumpStmt(IF_LTZ,3,-1,L1);
                code.visitLabel(L7);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Ljava/lang/System;","currentTimeMillis",new String[]{ },"J"));
                code.visitStmt1R(MOVE_RESULT_WIDE,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10},new Method("Lorg/mortbay/jetty/HttpConnection;","getTimeStamp",new String[]{ },"J"));
                code.visitStmt1R(MOVE_RESULT_WIDE,5);
                code.visitStmt3R(SUB_LONG,0,3,5);
                code.visitLabel(L8);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10},new Method("Lorg/mortbay/jetty/HttpConnection;","getRequests",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitLabel(L9);
                code.visitFieldStmt(IGET_OBJECT,3,9,new Field("Lorg/mortbay/jetty/AbstractConnector;","_statsLock","Ljava/lang/Object;"));
                code.visitStmt1R(MONITOR_ENTER,3);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET,4,9,new Field("Lorg/mortbay/jetty/AbstractConnector;","_requests","I"));
                code.visitStmt2R(ADD_INT_2ADDR,4,2);
                code.visitFieldStmt(IPUT,4,9,new Field("Lorg/mortbay/jetty/AbstractConnector;","_requests","I"));
                code.visitLabel(L10);
                code.visitFieldStmt(IGET,4,9,new Field("Lorg/mortbay/jetty/AbstractConnector;","_connections","I"));
                code.visitStmt2R1N(ADD_INT_LIT8,4,4,1);
                code.visitFieldStmt(IPUT,4,9,new Field("Lorg/mortbay/jetty/AbstractConnector;","_connections","I"));
                code.visitLabel(L11);
                code.visitFieldStmt(IGET,4,9,new Field("Lorg/mortbay/jetty/AbstractConnector;","_connectionsOpen","I"));
                code.visitConstStmt(CONST_4,5, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitStmt2R(SUB_INT_2ADDR,4,5);
                code.visitFieldStmt(IPUT,4,9,new Field("Lorg/mortbay/jetty/AbstractConnector;","_connectionsOpen","I"));
                code.visitLabel(L12);
                code.visitFieldStmt(IGET_WIDE,4,9,new Field("Lorg/mortbay/jetty/AbstractConnector;","_connectionsDurationTotal","J"));
                code.visitStmt2R(ADD_LONG_2ADDR,4,0);
                code.visitFieldStmt(IPUT_WIDE,4,9,new Field("Lorg/mortbay/jetty/AbstractConnector;","_connectionsDurationTotal","J"));
                code.visitLabel(L13);
                code.visitFieldStmt(IGET,4,9,new Field("Lorg/mortbay/jetty/AbstractConnector;","_connectionsOpen","I"));
                code.visitJumpStmt(IF_GEZ,4,-1,L15);
                code.visitLabel(L14);
                code.visitConstStmt(CONST_4,4, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT,4,9,new Field("Lorg/mortbay/jetty/AbstractConnector;","_connectionsOpen","I"));
                code.visitLabel(L15);
                code.visitFieldStmt(IGET,4,9,new Field("Lorg/mortbay/jetty/AbstractConnector;","_connectionsOpen","I"));
                code.visitFieldStmt(IGET,5,9,new Field("Lorg/mortbay/jetty/AbstractConnector;","_connectionsOpenMin","I"));
                code.visitJumpStmt(IF_GE,4,5,L17);
                code.visitLabel(L16);
                code.visitFieldStmt(IGET,4,9,new Field("Lorg/mortbay/jetty/AbstractConnector;","_connectionsOpen","I"));
                code.visitFieldStmt(IPUT,4,9,new Field("Lorg/mortbay/jetty/AbstractConnector;","_connectionsOpenMin","I"));
                code.visitLabel(L17);
                code.visitFieldStmt(IGET_WIDE,4,9,new Field("Lorg/mortbay/jetty/AbstractConnector;","_connectionsDurationMin","J"));
                code.visitStmt3R(CMP_LONG,4,4,7);
                code.visitJumpStmt(IF_EQZ,4,-1,L18);
                code.visitFieldStmt(IGET_WIDE,4,9,new Field("Lorg/mortbay/jetty/AbstractConnector;","_connectionsDurationMin","J"));
                code.visitStmt3R(CMP_LONG,4,0,4);
                code.visitJumpStmt(IF_GEZ,4,-1,L19);
                code.visitLabel(L18);
                code.visitFieldStmt(IPUT_WIDE,0,9,new Field("Lorg/mortbay/jetty/AbstractConnector;","_connectionsDurationMin","J"));
                code.visitLabel(L19);
                code.visitFieldStmt(IGET_WIDE,4,9,new Field("Lorg/mortbay/jetty/AbstractConnector;","_connectionsDurationMax","J"));
                code.visitStmt3R(CMP_LONG,4,0,4);
                code.visitJumpStmt(IF_LEZ,4,-1,L21);
                code.visitLabel(L20);
                code.visitFieldStmt(IPUT_WIDE,0,9,new Field("Lorg/mortbay/jetty/AbstractConnector;","_connectionsDurationMax","J"));
                code.visitLabel(L21);
                code.visitFieldStmt(IGET,4,9,new Field("Lorg/mortbay/jetty/AbstractConnector;","_connectionsRequestsMin","I"));
                code.visitJumpStmt(IF_EQZ,4,-1,L22);
                code.visitFieldStmt(IGET,4,9,new Field("Lorg/mortbay/jetty/AbstractConnector;","_connectionsRequestsMin","I"));
                code.visitJumpStmt(IF_GE,2,4,L23);
                code.visitLabel(L22);
                code.visitFieldStmt(IPUT,2,9,new Field("Lorg/mortbay/jetty/AbstractConnector;","_connectionsRequestsMin","I"));
                code.visitLabel(L23);
                code.visitFieldStmt(IGET,4,9,new Field("Lorg/mortbay/jetty/AbstractConnector;","_connectionsRequestsMax","I"));
                code.visitJumpStmt(IF_LE,2,4,L25);
                code.visitLabel(L24);
                code.visitFieldStmt(IPUT,2,9,new Field("Lorg/mortbay/jetty/AbstractConnector;","_connectionsRequestsMax","I"));
                code.visitLabel(L25);
                code.visitStmt1R(MONITOR_EXIT,3);
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10},new Method("Lorg/mortbay/jetty/HttpConnection;","destroy",new String[]{ },"V"));
                code.visitLabel(L26);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,4);
                code.visitLabel(L3);
                code.visitStmt1R(MONITOR_EXIT,3);
                code.visitLabel(L4);
                code.visitStmt1R(THROW,4);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m007_connectionOpened(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Lorg/mortbay/jetty/AbstractConnector;","connectionOpened",new String[]{ "Lorg/mortbay/jetty/HttpConnection;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(6);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"connection");
                DexLabel L3=new DexLabel();
                ddv.visitPrologue(L3);
                ddv.visitLineNumber(917,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(925,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(919,L5);
                ddv.visitLineNumber(921,L0);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(922,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(923,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(924,L8);
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_WIDE,0,4,new Field("Lorg/mortbay/jetty/AbstractConnector;","_statsStartedAt","J"));
                code.visitConstStmt(CONST_WIDE_16,2,Long.valueOf(-1L)); // long: 0xffffffffffffffff  double:NaN
                code.visitStmt3R(CMP_LONG,0,0,2);
                code.visitJumpStmt(IF_NEZ,0,-1,L5);
                code.visitLabel(L4);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L5);
                code.visitFieldStmt(IGET_OBJECT,0,4,new Field("Lorg/mortbay/jetty/AbstractConnector;","_statsLock","Ljava/lang/Object;"));
                code.visitStmt1R(MONITOR_ENTER,0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET,1,4,new Field("Lorg/mortbay/jetty/AbstractConnector;","_connectionsOpen","I"));
                code.visitStmt2R1N(ADD_INT_LIT8,1,1,1);
                code.visitFieldStmt(IPUT,1,4,new Field("Lorg/mortbay/jetty/AbstractConnector;","_connectionsOpen","I"));
                code.visitLabel(L6);
                code.visitFieldStmt(IGET,1,4,new Field("Lorg/mortbay/jetty/AbstractConnector;","_connectionsOpen","I"));
                code.visitFieldStmt(IGET,2,4,new Field("Lorg/mortbay/jetty/AbstractConnector;","_connectionsOpenMax","I"));
                code.visitJumpStmt(IF_LE,1,2,L8);
                code.visitLabel(L7);
                code.visitFieldStmt(IGET,1,4,new Field("Lorg/mortbay/jetty/AbstractConnector;","_connectionsOpen","I"));
                code.visitFieldStmt(IPUT,1,4,new Field("Lorg/mortbay/jetty/AbstractConnector;","_connectionsOpenMax","I"));
                code.visitLabel(L8);
                code.visitStmt1R(MONITOR_EXIT,0);
                code.visitJumpStmt(GOTO,-1,-1,L4);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,1);
                code.visitStmt1R(MONITOR_EXIT,0);
                code.visitLabel(L1);
                code.visitStmt1R(THROW,1);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m008_customize(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/AbstractConnector;","customize",new String[]{ "Lorg/mortbay/io/EndPoint;","Lorg/mortbay/jetty/Request;"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"endpoint");
                ddv.visitParameterName(1,"request");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(375,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(376,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(377,L2);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Lorg/mortbay/jetty/AbstractConnector;","isForwarded",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_EQZ,0,-1,L2);
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2,3},new Method("Lorg/mortbay/jetty/AbstractConnector;","checkForwardedHeaders",new String[]{ "Lorg/mortbay/io/EndPoint;","Lorg/mortbay/jetty/Request;"},"V"));
                code.visitLabel(L2);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m009_doStart(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Lorg/mortbay/jetty/AbstractConnector;","doStart",new String[]{ },"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/lang/Exception;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexLabel L3=new DexLabel();
                DexLabel L4=new DexLabel();
                code.visitTryCatch(L3,L4,new DexLabel[]{L2},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L5=new DexLabel();
                ddv.visitPrologue(L5);
                ddv.visitLineNumber(279,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(280,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(283,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(285,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(287,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(288,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(289,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(290,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(293,L13);
                ddv.visitLineNumber(295,L0);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(297,L14);
                DexLabel L15=new DexLabel();
                ddv.visitStartLocal(0,L15,"i","I",null);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(299,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(301,L17);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(305,L18);
                ddv.visitLineNumber(307,L1);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(308,L19);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(297,L20);
                ddv.visitLineNumber(305,L2);
                ddv.visitEndLocal(0,L2);
                code.visitLabel(L5);
                code.visitFieldStmt(IGET_OBJECT,1,3,new Field("Lorg/mortbay/jetty/AbstractConnector;","_server","Lorg/mortbay/jetty/Server;"));
                code.visitJumpStmt(IF_NEZ,1,-1,L7);
                code.visitLabel(L6);
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Ljava/lang/IllegalStateException;");
                code.visitConstStmt(CONST_STRING,2,"No server");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1,2},new Method("Ljava/lang/IllegalStateException;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitStmt1R(THROW,1);
                code.visitLabel(L7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Lorg/mortbay/jetty/AbstractConnector;","open",new String[]{ },"V"));
                code.visitLabel(L8);
                code.visitMethodStmt(INVOKE_SUPER,new int[]{ 3},new Method("Lorg/mortbay/jetty/AbstractBuffers;","doStart",new String[]{ },"V"));
                code.visitLabel(L9);
                code.visitFieldStmt(IGET_OBJECT,1,3,new Field("Lorg/mortbay/jetty/AbstractConnector;","_threadPool","Lorg/mortbay/thread/ThreadPool;"));
                code.visitJumpStmt(IF_NEZ,1,-1,L11);
                code.visitLabel(L10);
                code.visitFieldStmt(IGET_OBJECT,1,3,new Field("Lorg/mortbay/jetty/AbstractConnector;","_server","Lorg/mortbay/jetty/Server;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Lorg/mortbay/jetty/Server;","getThreadPool",new String[]{ },"Lorg/mortbay/thread/ThreadPool;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitFieldStmt(IPUT_OBJECT,1,3,new Field("Lorg/mortbay/jetty/AbstractConnector;","_threadPool","Lorg/mortbay/thread/ThreadPool;"));
                code.visitLabel(L11);
                code.visitFieldStmt(IGET_OBJECT,1,3,new Field("Lorg/mortbay/jetty/AbstractConnector;","_threadPool","Lorg/mortbay/thread/ThreadPool;"));
                code.visitFieldStmt(IGET_OBJECT,2,3,new Field("Lorg/mortbay/jetty/AbstractConnector;","_server","Lorg/mortbay/jetty/Server;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/jetty/Server;","getThreadPool",new String[]{ },"Lorg/mortbay/thread/ThreadPool;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitJumpStmt(IF_EQ,1,2,L13);
                code.visitFieldStmt(IGET_OBJECT,1,3,new Field("Lorg/mortbay/jetty/AbstractConnector;","_threadPool","Lorg/mortbay/thread/ThreadPool;"));
                code.visitTypeStmt(INSTANCE_OF,1,1,"Lorg/mortbay/component/LifeCycle;");
                code.visitJumpStmt(IF_EQZ,1,-1,L13);
                code.visitLabel(L12);
                code.visitFieldStmt(IGET_OBJECT,1,3,new Field("Lorg/mortbay/jetty/AbstractConnector;","_threadPool","Lorg/mortbay/thread/ThreadPool;"));
                code.visitTypeStmt(CHECK_CAST,1,-1,"Lorg/mortbay/component/LifeCycle;");
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 1},new Method("Lorg/mortbay/component/LifeCycle;","start",new String[]{ },"V"));
                code.visitLabel(L13);
                code.visitStmt1R(MONITOR_ENTER,3);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Lorg/mortbay/jetty/AbstractConnector;","getAcceptors",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitTypeStmt(NEW_ARRAY,1,1,"[Ljava/lang/Thread;");
                code.visitFieldStmt(IPUT_OBJECT,1,3,new Field("Lorg/mortbay/jetty/AbstractConnector;","_acceptorThread","[Ljava/lang/Thread;"));
                code.visitLabel(L14);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L15);
                code.visitFieldStmt(IGET_OBJECT,1,3,new Field("Lorg/mortbay/jetty/AbstractConnector;","_acceptorThread","[Ljava/lang/Thread;"));
                code.visitStmt2R(ARRAY_LENGTH,1,1);
                code.visitJumpStmt(IF_GE,0,1,L18);
                code.visitLabel(L16);
                code.visitFieldStmt(IGET_OBJECT,1,3,new Field("Lorg/mortbay/jetty/AbstractConnector;","_threadPool","Lorg/mortbay/thread/ThreadPool;"));
                code.visitTypeStmt(NEW_INSTANCE,2,-1,"Lorg/mortbay/jetty/AbstractConnector$Acceptor;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2,3,0},new Method("Lorg/mortbay/jetty/AbstractConnector$Acceptor;","<init>",new String[]{ "Lorg/mortbay/jetty/AbstractConnector;","I"},"V"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 1,2},new Method("Lorg/mortbay/thread/ThreadPool;","dispatch",new String[]{ "Ljava/lang/Runnable;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitJumpStmt(IF_NEZ,1,-1,L20);
                code.visitLabel(L17);
                code.visitConstStmt(CONST_STRING,1,"insufficient maxThreads configured for {}");
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1,3},new Method("Lorg/mortbay/log/Log;","warn",new String[]{ "Ljava/lang/String;","Ljava/lang/Object;"},"V"));
                code.visitLabel(L18);
                code.visitStmt1R(MONITOR_EXIT,3);
                code.visitLabel(L1);
                code.visitConstStmt(CONST_STRING,1,"Started {}");
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1,3},new Method("Lorg/mortbay/log/Log;","info",new String[]{ "Ljava/lang/String;","Ljava/lang/Object;"},"V"));
                code.visitLabel(L19);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L20);
                code.visitStmt2R1N(ADD_INT_LIT8,0,0,1);
                code.visitJumpStmt(GOTO,-1,-1,L15);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,1);
                code.visitLabel(L3);
                code.visitStmt1R(MONITOR_EXIT,3);
                code.visitLabel(L4);
                code.visitStmt1R(THROW,1);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m010_doStop(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Lorg/mortbay/jetty/AbstractConnector;","doStop",new String[]{ },"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/lang/Exception;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(8);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ "Ljava/io/IOException;"});
                DexLabel L3=new DexLabel();
                DexLabel L4=new DexLabel();
                DexLabel L5=new DexLabel();
                code.visitTryCatch(L3,L4,new DexLabel[]{L5},new String[]{ null});
                DexLabel L6=new DexLabel();
                DexLabel L7=new DexLabel();
                code.visitTryCatch(L6,L7,new DexLabel[]{L5},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L8=new DexLabel();
                ddv.visitPrologue(L8);
                ddv.visitLineNumber(313,L0);
                ddv.visitLineNumber(315,L1);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(316,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(320,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(322,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(323,L12);
                ddv.visitStartLocal(0,L12,"acceptors","[Ljava/lang/Thread;",null);
                ddv.visitLineNumber(325,L3);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(326,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(327,L14);
                ddv.visitLineNumber(328,L4);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(330,L15);
                DexLabel L16=new DexLabel();
                ddv.visitStartLocal(2,L16,"i","I",null);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(332,L17);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(333,L18);
                ddv.visitStartLocal(3,L18,"thread","Ljava/lang/Thread;",null);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(334,L19);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(330,L20);
                ddv.visitLineNumber(313,L2);
                ddv.visitEndLocal(0,L2);
                ddv.visitEndLocal(2,L2);
                ddv.visitEndLocal(3,L2);
                DexLabel L21=new DexLabel();
                ddv.visitStartLocal(1,L21,"e","Ljava/io/IOException;",null);
                DexLabel L22=new DexLabel();
                ddv.visitLineNumber(317,L22);
                ddv.visitEndLocal(1,L22);
                DexLabel L23=new DexLabel();
                ddv.visitLineNumber(318,L23);
                ddv.visitLineNumber(327,L5);
                ddv.visitRestartLocal(0,L5);
                DexLabel L24=new DexLabel();
                ddv.visitLineNumber(338,L24);
                code.visitLabel(L8);
                code.visitConstStmt(CONST_4,6, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7},new Method("Lorg/mortbay/jetty/AbstractConnector;","close",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,4,7,new Field("Lorg/mortbay/jetty/AbstractConnector;","_threadPool","Lorg/mortbay/thread/ThreadPool;"));
                code.visitFieldStmt(IGET_OBJECT,5,7,new Field("Lorg/mortbay/jetty/AbstractConnector;","_server","Lorg/mortbay/jetty/Server;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Lorg/mortbay/jetty/Server;","getThreadPool",new String[]{ },"Lorg/mortbay/thread/ThreadPool;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitJumpStmt(IF_NE,4,5,L22);
                code.visitLabel(L9);
                code.visitFieldStmt(IPUT_OBJECT,6,7,new Field("Lorg/mortbay/jetty/AbstractConnector;","_threadPool","Lorg/mortbay/thread/ThreadPool;"));
                code.visitLabel(L10);
                code.visitMethodStmt(INVOKE_SUPER,new int[]{ 7},new Method("Lorg/mortbay/jetty/AbstractBuffers;","doStop",new String[]{ },"V"));
                code.visitLabel(L11);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L12);
                code.visitStmt1R(MONITOR_ENTER,7);
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,0,7,new Field("Lorg/mortbay/jetty/AbstractConnector;","_acceptorThread","[Ljava/lang/Thread;"));
                code.visitLabel(L13);
                code.visitConstStmt(CONST_4,4, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT_OBJECT,4,7,new Field("Lorg/mortbay/jetty/AbstractConnector;","_acceptorThread","[Ljava/lang/Thread;"));
                code.visitLabel(L14);
                code.visitStmt1R(MONITOR_EXIT,7);
                code.visitLabel(L4);
                code.visitJumpStmt(IF_EQZ,0,-1,L24);
                code.visitLabel(L15);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L16);
                code.visitStmt2R(ARRAY_LENGTH,4,0);
                code.visitJumpStmt(IF_GE,2,4,L24);
                code.visitLabel(L17);
                code.visitStmt3R(AGET_OBJECT,3,0,2);
                code.visitLabel(L18);
                code.visitJumpStmt(IF_EQZ,3,-1,L20);
                code.visitLabel(L19);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Ljava/lang/Thread;","interrupt",new String[]{ },"V"));
                code.visitLabel(L20);
                code.visitStmt2R1N(ADD_INT_LIT8,2,2,1);
                code.visitJumpStmt(GOTO,-1,-1,L16);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,1);
                code.visitLabel(L21);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1},new Method("Lorg/mortbay/log/Log;","warn",new String[]{ "Ljava/lang/Throwable;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L1);
                code.visitLabel(L22);
                code.visitFieldStmt(IGET_OBJECT,4,7,new Field("Lorg/mortbay/jetty/AbstractConnector;","_threadPool","Lorg/mortbay/thread/ThreadPool;"));
                code.visitTypeStmt(INSTANCE_OF,4,4,"Lorg/mortbay/component/LifeCycle;");
                code.visitJumpStmt(IF_EQZ,4,-1,L10);
                code.visitLabel(L23);
                code.visitFieldStmt(IGET_OBJECT,4,7,new Field("Lorg/mortbay/jetty/AbstractConnector;","_threadPool","Lorg/mortbay/thread/ThreadPool;"));
                code.visitTypeStmt(CHECK_CAST,4,-1,"Lorg/mortbay/component/LifeCycle;");
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 4},new Method("Lorg/mortbay/component/LifeCycle;","stop",new String[]{ },"V"));
                code.visitJumpStmt(GOTO,-1,-1,L10);
                code.visitLabel(L5);
                code.visitStmt1R(MOVE_EXCEPTION,4);
                code.visitLabel(L6);
                code.visitStmt1R(MONITOR_EXIT,7);
                code.visitLabel(L7);
                code.visitStmt1R(THROW,4);
                code.visitLabel(L24);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m011_getAcceptQueueSize(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/AbstractConnector;","getAcceptQueueSize",new String[]{ },"I"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(237,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET,0,1,new Field("Lorg/mortbay/jetty/AbstractConnector;","_acceptQueueSize","I"));
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m012_getAcceptorPriorityOffset(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/AbstractConnector;","getAcceptorPriorityOffset",new String[]{ },"I"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(964,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET,0,1,new Field("Lorg/mortbay/jetty/AbstractConnector;","_acceptorPriorityOffset","I"));
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m013_getAcceptors(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/AbstractConnector;","getAcceptors",new String[]{ },"I"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(255,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET,0,1,new Field("Lorg/mortbay/jetty/AbstractConnector;","_acceptors","I"));
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m014_getConfidentialPort(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/AbstractConnector;","getConfidentialPort",new String[]{ },"I"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(465,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET,0,1,new Field("Lorg/mortbay/jetty/AbstractConnector;","_confidentialPort","I"));
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m015_getConfidentialScheme(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/AbstractConnector;","getConfidentialScheme",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(475,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/AbstractConnector;","_confidentialScheme","Ljava/lang/String;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m016_getConnections(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/AbstractConnector;","getConnections",new String[]{ },"I"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(817,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET,0,1,new Field("Lorg/mortbay/jetty/AbstractConnector;","_connections","I"));
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m017_getConnectionsDurationAve(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/AbstractConnector;","getConnectionsDurationAve",new String[]{ },"J"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(838,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET,0,4,new Field("Lorg/mortbay/jetty/AbstractConnector;","_connections","I"));
                DexLabel L1=new DexLabel();
                code.visitJumpStmt(IF_NEZ,0,-1,L1);
                code.visitConstStmt(CONST_WIDE_16,0,Long.valueOf(0L)); // long: 0x0000000000000000  double:0.000000
                DexLabel L2=new DexLabel();
                code.visitLabel(L2);
                code.visitStmt1R(RETURN_WIDE,0);
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_WIDE,0,4,new Field("Lorg/mortbay/jetty/AbstractConnector;","_connectionsDurationTotal","J"));
                code.visitFieldStmt(IGET,2,4,new Field("Lorg/mortbay/jetty/AbstractConnector;","_connections","I"));
                code.visitStmt2R(INT_TO_LONG,2,2);
                code.visitStmt2R(DIV_LONG_2ADDR,0,2);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m018_getConnectionsDurationMax(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/AbstractConnector;","getConnectionsDurationMax",new String[]{ },"J"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(845,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_WIDE,0,2,new Field("Lorg/mortbay/jetty/AbstractConnector;","_connectionsDurationMax","J"));
                code.visitStmt1R(RETURN_WIDE,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m019_getConnectionsDurationMin(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/AbstractConnector;","getConnectionsDurationMin",new String[]{ },"J"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(781,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_WIDE,0,2,new Field("Lorg/mortbay/jetty/AbstractConnector;","_connectionsDurationMin","J"));
                code.visitStmt1R(RETURN_WIDE,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m020_getConnectionsDurationTotal(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/AbstractConnector;","getConnectionsDurationTotal",new String[]{ },"J"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(790,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_WIDE,0,2,new Field("Lorg/mortbay/jetty/AbstractConnector;","_connectionsDurationTotal","J"));
                code.visitStmt1R(RETURN_WIDE,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m021_getConnectionsOpen(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/AbstractConnector;","getConnectionsOpen",new String[]{ },"I"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(824,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET,0,1,new Field("Lorg/mortbay/jetty/AbstractConnector;","_connectionsOpen","I"));
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m022_getConnectionsOpenMax(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/AbstractConnector;","getConnectionsOpenMax",new String[]{ },"I"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(831,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET,0,1,new Field("Lorg/mortbay/jetty/AbstractConnector;","_connectionsOpenMax","I"));
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m023_getConnectionsOpenMin(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/AbstractConnector;","getConnectionsOpenMin",new String[]{ },"I"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(799,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET,0,1,new Field("Lorg/mortbay/jetty/AbstractConnector;","_connectionsOpenMin","I"));
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m024_getConnectionsRequestsAve(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/AbstractConnector;","getConnectionsRequestsAve",new String[]{ },"I"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(852,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET,0,2,new Field("Lorg/mortbay/jetty/AbstractConnector;","_connections","I"));
                DexLabel L1=new DexLabel();
                code.visitJumpStmt(IF_NEZ,0,-1,L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                DexLabel L2=new DexLabel();
                code.visitLabel(L2);
                code.visitStmt1R(RETURN,0);
                code.visitLabel(L1);
                code.visitFieldStmt(IGET,0,2,new Field("Lorg/mortbay/jetty/AbstractConnector;","_requests","I"));
                code.visitFieldStmt(IGET,1,2,new Field("Lorg/mortbay/jetty/AbstractConnector;","_connections","I"));
                code.visitStmt2R(DIV_INT_2ADDR,0,1);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m025_getConnectionsRequestsMax(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/AbstractConnector;","getConnectionsRequestsMax",new String[]{ },"I"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(859,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET,0,1,new Field("Lorg/mortbay/jetty/AbstractConnector;","_connectionsRequestsMax","I"));
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m026_getConnectionsRequestsMin(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/AbstractConnector;","getConnectionsRequestsMin",new String[]{ },"I"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(808,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET,0,1,new Field("Lorg/mortbay/jetty/AbstractConnector;","_connectionsRequestsMin","I"));
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m027_getForwardedForHeader(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/AbstractConnector;","getForwardedForHeader",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(649,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/AbstractConnector;","_forwardedForHeader","Ljava/lang/String;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m028_getForwardedHostHeader(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/AbstractConnector;","getForwardedHostHeader",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(619,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/AbstractConnector;","_forwardedHostHeader","Ljava/lang/String;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m029_getForwardedServerHeader(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/AbstractConnector;","getForwardedServerHeader",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(634,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/AbstractConnector;","_forwardedServerHeader","Ljava/lang/String;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m030_getHost(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/AbstractConnector;","getHost",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(142,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/AbstractConnector;","_host","Ljava/lang/String;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m031_getHostHeader(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/AbstractConnector;","getHostHeader",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(601,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/AbstractConnector;","_hostHeader","Ljava/lang/String;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m032_getIntegralPort(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/AbstractConnector;","getIntegralPort",new String[]{ },"I"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(493,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET,0,1,new Field("Lorg/mortbay/jetty/AbstractConnector;","_integralPort","I"));
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m033_getIntegralScheme(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/AbstractConnector;","getIntegralScheme",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(502,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/AbstractConnector;","_integralScheme","Ljava/lang/String;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m034_getLeftMostValue(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Lorg/mortbay/jetty/AbstractConnector;","getLeftMostValue",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"headerValue");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(436,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(437,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(448,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(439,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(441,L4);
                ddv.visitStartLocal(0,L4,"commaIndex","I",null);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(444,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(448,L6);
                code.visitLabel(L0);
                code.visitJumpStmt(IF_NEZ,3,-1,L3);
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L2);
                code.visitStmt1R(RETURN_OBJECT,1);
                code.visitLabel(L3);
                code.visitConstStmt(CONST_16,1, Integer.valueOf(44)); // int: 0x0000002c  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,1},new Method("Ljava/lang/String;","indexOf",new String[]{ "I"},"I"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitLabel(L4);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(-1)); // int: 0xffffffff  float:NaN
                code.visitJumpStmt(IF_NE,0,1,L6);
                code.visitStmt2R(MOVE_OBJECT,1,3);
                code.visitLabel(L5);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitLabel(L6);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,1,0},new Method("Ljava/lang/String;","substring",new String[]{ "I","I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m035_getLowResourceMaxIdleTime(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/AbstractConnector;","getLowResourceMaxIdleTime",new String[]{ },"I"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(210,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET,0,1,new Field("Lorg/mortbay/jetty/AbstractConnector;","_lowResourceMaxIdleTime","I"));
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m036_getMaxIdleTime(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/AbstractConnector;","getMaxIdleTime",new String[]{ },"I"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(170,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET,0,1,new Field("Lorg/mortbay/jetty/AbstractConnector;","_maxIdleTime","I"));
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m037_getName(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/AbstractConnector;","getName",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(754,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(755,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(756,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(755,L3);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/jetty/AbstractConnector;","_name","Ljava/lang/String;"));
                code.visitJumpStmt(IF_NEZ,0,-1,L2);
                code.visitLabel(L1);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/jetty/AbstractConnector;","getHost",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitJumpStmt(IF_NEZ,1,-1,L3);
                code.visitConstStmt(CONST_STRING,1,"0.0.0.0");
                DexLabel L4=new DexLabel();
                code.visitLabel(L4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitConstStmt(CONST_STRING,1,":");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/jetty/AbstractConnector;","getLocalPort",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,1);
                DexLabel L5=new DexLabel();
                code.visitJumpStmt(IF_GTZ,1,-1,L5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/jetty/AbstractConnector;","getPort",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,1);
                DexLabel L6=new DexLabel();
                code.visitLabel(L6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "I"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(IPUT_OBJECT,0,2,new Field("Lorg/mortbay/jetty/AbstractConnector;","_name","Ljava/lang/String;"));
                code.visitLabel(L2);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/jetty/AbstractConnector;","_name","Ljava/lang/String;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/jetty/AbstractConnector;","getHost",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitJumpStmt(GOTO,-1,-1,L4);
                code.visitLabel(L5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/jetty/AbstractConnector;","getLocalPort",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitJumpStmt(GOTO,-1,-1,L6);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m038_getPort(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/AbstractConnector;","getPort",new String[]{ },"I"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(160,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET,0,1,new Field("Lorg/mortbay/jetty/AbstractConnector;","_port","I"));
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m039_getRequests(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/AbstractConnector;","getRequests",new String[]{ },"I"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(773,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET,0,1,new Field("Lorg/mortbay/jetty/AbstractConnector;","_requests","I"));
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m040_getResolveNames(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/AbstractConnector;","getResolveNames",new String[]{ },"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(567,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_BOOLEAN,0,1,new Field("Lorg/mortbay/jetty/AbstractConnector;","_useDNS","Z"));
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m041_getReuseAddress(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/AbstractConnector;","getReuseAddress",new String[]{ },"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(985,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_BOOLEAN,0,1,new Field("Lorg/mortbay/jetty/AbstractConnector;","_reuseAddress","Z"));
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m042_getServer(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/AbstractConnector;","getServer",new String[]{ },"Lorg/mortbay/jetty/Server;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(105,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/AbstractConnector;","_server","Lorg/mortbay/jetty/Server;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m043_getSoLingerTime(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/AbstractConnector;","getSoLingerTime",new String[]{ },"I"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(228,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET,0,1,new Field("Lorg/mortbay/jetty/AbstractConnector;","_soLingerTime","I"));
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m044_getStatsOn(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/AbstractConnector;","getStatsOn",new String[]{ },"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(902,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_WIDE,0,4,new Field("Lorg/mortbay/jetty/AbstractConnector;","_statsStartedAt","J"));
                code.visitConstStmt(CONST_WIDE_16,2,Long.valueOf(-1L)); // long: 0xffffffffffffffff  double:NaN
                code.visitStmt3R(CMP_LONG,0,0,2);
                DexLabel L1=new DexLabel();
                code.visitJumpStmt(IF_EQZ,0,-1,L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                DexLabel L2=new DexLabel();
                code.visitLabel(L2);
                code.visitStmt1R(RETURN,0);
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m045_getStatsOnMs(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/AbstractConnector;","getStatsOnMs",new String[]{ },"J"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(911,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_WIDE,0,4,new Field("Lorg/mortbay/jetty/AbstractConnector;","_statsStartedAt","J"));
                code.visitConstStmt(CONST_WIDE_16,2,Long.valueOf(-1L)); // long: 0xffffffffffffffff  double:NaN
                code.visitStmt3R(CMP_LONG,0,0,2);
                DexLabel L1=new DexLabel();
                code.visitJumpStmt(IF_EQZ,0,-1,L1);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Ljava/lang/System;","currentTimeMillis",new String[]{ },"J"));
                code.visitStmt1R(MOVE_RESULT_WIDE,0);
                code.visitFieldStmt(IGET_WIDE,2,4,new Field("Lorg/mortbay/jetty/AbstractConnector;","_statsStartedAt","J"));
                code.visitStmt2R(SUB_LONG_2ADDR,0,2);
                DexLabel L2=new DexLabel();
                code.visitLabel(L2);
                code.visitStmt1R(RETURN_WIDE,0);
                code.visitLabel(L1);
                code.visitConstStmt(CONST_WIDE_16,0,Long.valueOf(0L)); // long: 0x0000000000000000  double:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m046_getThreadPool(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/AbstractConnector;","getThreadPool",new String[]{ },"Lorg/mortbay/thread/ThreadPool;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(120,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/AbstractConnector;","_threadPool","Lorg/mortbay/thread/ThreadPool;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m047_isConfidential(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/AbstractConnector;","isConfidential",new String[]{ "Lorg/mortbay/jetty/Request;"},"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"request");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(511,L0);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m048_isForwarded(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/AbstractConnector;","isForwarded",new String[]{ },"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(583,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_BOOLEAN,0,1,new Field("Lorg/mortbay/jetty/AbstractConnector;","_forwarded","Z"));
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m049_isIntegral(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/AbstractConnector;","isIntegral",new String[]{ "Lorg/mortbay/jetty/Request;"},"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"request");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(484,L0);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m050_join(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/AbstractConnector;","join",new String[]{ },"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/lang/InterruptedException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(343,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(344,L1);
                ddv.visitStartLocal(1,L1,"threads","[Ljava/lang/Thread;",null);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(345,L2);
                DexLabel L3=new DexLabel();
                ddv.visitStartLocal(0,L3,"i","I",null);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(346,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(347,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(345,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(348,L7);
                ddv.visitEndLocal(0,L7);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,1,3,new Field("Lorg/mortbay/jetty/AbstractConnector;","_acceptorThread","[Ljava/lang/Thread;"));
                code.visitLabel(L1);
                code.visitJumpStmt(IF_EQZ,1,-1,L7);
                code.visitLabel(L2);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L3);
                code.visitStmt2R(ARRAY_LENGTH,2,1);
                code.visitJumpStmt(IF_GE,0,2,L7);
                code.visitLabel(L4);
                code.visitStmt3R(AGET_OBJECT,2,1,0);
                code.visitJumpStmt(IF_EQZ,2,-1,L6);
                code.visitLabel(L5);
                code.visitStmt3R(AGET_OBJECT,2,1,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Ljava/lang/Thread;","join",new String[]{ },"V"));
                code.visitLabel(L6);
                code.visitStmt2R1N(ADD_INT_LIT8,0,0,1);
                code.visitJumpStmt(GOTO,-1,-1,L3);
                code.visitLabel(L7);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m051_newContinuation(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/AbstractConnector;","newContinuation",new String[]{ },"Lorg/mortbay/util/ajax/Continuation;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(553,L0);
                code.visitLabel(L0);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Lorg/mortbay/util/ajax/WaitingContinuation;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Lorg/mortbay/util/ajax/WaitingContinuation;","<init>",new String[]{ },"V"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m052_persist(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/AbstractConnector;","persist",new String[]{ "Lorg/mortbay/io/EndPoint;"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"endpoint");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(455,L0);
                code.visitLabel(L0);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m053_setAcceptQueueSize(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/AbstractConnector;","setAcceptQueueSize",new String[]{ "I"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"acceptQueueSize");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(246,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(247,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT,1,0,new Field("Lorg/mortbay/jetty/AbstractConnector;","_acceptQueueSize","I"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m054_setAcceptorPriorityOffset(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/AbstractConnector;","setAcceptorPriorityOffset",new String[]{ "I"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"offset");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(976,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(977,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT,1,0,new Field("Lorg/mortbay/jetty/AbstractConnector;","_acceptorPriorityOffset","I"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m055_setAcceptors(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/AbstractConnector;","setAcceptors",new String[]{ "I"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"acceptors");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(264,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(265,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT,1,0,new Field("Lorg/mortbay/jetty/AbstractConnector;","_acceptors","I"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m056_setConfidentialPort(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/AbstractConnector;","setConfidentialPort",new String[]{ "I"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"confidentialPort");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(520,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(521,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT,1,0,new Field("Lorg/mortbay/jetty/AbstractConnector;","_confidentialPort","I"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m057_setConfidentialScheme(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/AbstractConnector;","setConfidentialScheme",new String[]{ "Ljava/lang/String;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"confidentialScheme");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(529,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(530,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_OBJECT,1,0,new Field("Lorg/mortbay/jetty/AbstractConnector;","_confidentialScheme","Ljava/lang/String;"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m058_setForwarded(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/AbstractConnector;","setForwarded",new String[]{ "Z"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"check");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(593,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(594,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(595,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(596,L3);
                code.visitLabel(L0);
                code.visitJumpStmt(IF_EQZ,3,-1,L2);
                code.visitLabel(L1);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,2},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitConstStmt(CONST_STRING,1," is forwarded");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0},new Method("Lorg/mortbay/log/Log;","debug",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L2);
                code.visitFieldStmt(IPUT_BOOLEAN,3,2,new Field("Lorg/mortbay/jetty/AbstractConnector;","_forwarded","Z"));
                code.visitLabel(L3);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m059_setForwardedForHeader(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/AbstractConnector;","setForwardedForHeader",new String[]{ "Ljava/lang/String;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"forwardedRemoteAddressHeader");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(658,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(659,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_OBJECT,1,0,new Field("Lorg/mortbay/jetty/AbstractConnector;","_forwardedForHeader","Ljava/lang/String;"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m060_setForwardedHostHeader(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/AbstractConnector;","setForwardedHostHeader",new String[]{ "Ljava/lang/String;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"forwardedHostHeader");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(628,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(629,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_OBJECT,1,0,new Field("Lorg/mortbay/jetty/AbstractConnector;","_forwardedHostHeader","Ljava/lang/String;"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m061_setForwardedServerHeader(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/AbstractConnector;","setForwardedServerHeader",new String[]{ "Ljava/lang/String;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"forwardedServerHeader");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(643,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(644,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_OBJECT,1,0,new Field("Lorg/mortbay/jetty/AbstractConnector;","_forwardedServerHeader","Ljava/lang/String;"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m062_setHost(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/AbstractConnector;","setHost",new String[]{ "Ljava/lang/String;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"host");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(134,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(135,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_OBJECT,1,0,new Field("Lorg/mortbay/jetty/AbstractConnector;","_host","Ljava/lang/String;"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m063_setHostHeader(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/AbstractConnector;","setHostHeader",new String[]{ "Ljava/lang/String;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"hostHeader");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(613,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(614,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_OBJECT,1,0,new Field("Lorg/mortbay/jetty/AbstractConnector;","_hostHeader","Ljava/lang/String;"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m064_setIntegralPort(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/AbstractConnector;","setIntegralPort",new String[]{ "I"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"integralPort");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(538,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(539,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT,1,0,new Field("Lorg/mortbay/jetty/AbstractConnector;","_integralPort","I"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m065_setIntegralScheme(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/AbstractConnector;","setIntegralScheme",new String[]{ "Ljava/lang/String;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"integralScheme");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(547,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(548,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_OBJECT,1,0,new Field("Lorg/mortbay/jetty/AbstractConnector;","_integralScheme","Ljava/lang/String;"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m066_setLowResourceMaxIdleTime(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/AbstractConnector;","setLowResourceMaxIdleTime",new String[]{ "I"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"maxIdleTime");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(219,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(220,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT,1,0,new Field("Lorg/mortbay/jetty/AbstractConnector;","_lowResourceMaxIdleTime","I"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m067_setMaxIdleTime(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/AbstractConnector;","setMaxIdleTime",new String[]{ "I"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"maxIdleTime");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(201,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(202,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT,1,0,new Field("Lorg/mortbay/jetty/AbstractConnector;","_maxIdleTime","I"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m068_setName(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/AbstractConnector;","setName",new String[]{ "Ljava/lang/String;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"name");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(762,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(763,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_OBJECT,1,0,new Field("Lorg/mortbay/jetty/AbstractConnector;","_name","Ljava/lang/String;"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m069_setPort(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/AbstractConnector;","setPort",new String[]{ "I"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"port");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(151,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(152,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT,1,0,new Field("Lorg/mortbay/jetty/AbstractConnector;","_port","I"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m070_setResolveNames(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/AbstractConnector;","setResolveNames",new String[]{ "Z"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"resolve");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(573,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(574,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_BOOLEAN,1,0,new Field("Lorg/mortbay/jetty/AbstractConnector;","_useDNS","Z"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m071_setReuseAddress(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/AbstractConnector;","setReuseAddress",new String[]{ "Z"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"reuseAddress");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(994,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(995,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_BOOLEAN,1,0,new Field("Lorg/mortbay/jetty/AbstractConnector;","_reuseAddress","Z"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m072_setServer(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/AbstractConnector;","setServer",new String[]{ "Lorg/mortbay/jetty/Server;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"server");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(111,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(112,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_OBJECT,1,0,new Field("Lorg/mortbay/jetty/AbstractConnector;","_server","Lorg/mortbay/jetty/Server;"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m073_setSoLingerTime(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/AbstractConnector;","setSoLingerTime",new String[]{ "I"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"soLingerTime");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(273,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(274,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT,1,0,new Field("Lorg/mortbay/jetty/AbstractConnector;","_soLingerTime","I"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m074_setStatsOn(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/AbstractConnector;","setStatsOn",new String[]{ "Z"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(6);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"on");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(889,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(894,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(891,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(892,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(893,L5);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_WIDE_16,2,Long.valueOf(-1L)); // long: 0xffffffffffffffff  double:NaN
                code.visitLabel(L1);
                code.visitJumpStmt(IF_EQZ,5,-1,L3);
                code.visitFieldStmt(IGET_WIDE,0,4,new Field("Lorg/mortbay/jetty/AbstractConnector;","_statsStartedAt","J"));
                code.visitStmt3R(CMP_LONG,0,0,2);
                code.visitJumpStmt(IF_EQZ,0,-1,L3);
                code.visitLabel(L2);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L3);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,1,"Statistics on = ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,5},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Z"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitConstStmt(CONST_STRING,1," for ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,4},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0},new Method("Lorg/mortbay/log/Log;","debug",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Lorg/mortbay/jetty/AbstractConnector;","statsReset",new String[]{ },"V"));
                code.visitLabel(L5);
                DexLabel L6=new DexLabel();
                code.visitJumpStmt(IF_EQZ,5,-1,L6);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Ljava/lang/System;","currentTimeMillis",new String[]{ },"J"));
                code.visitStmt1R(MOVE_RESULT_WIDE,0);
                DexLabel L7=new DexLabel();
                code.visitLabel(L7);
                code.visitFieldStmt(IPUT_WIDE,0,4,new Field("Lorg/mortbay/jetty/AbstractConnector;","_statsStartedAt","J"));
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitLabel(L6);
                code.visitStmt2R(MOVE_WIDE,0,2);
                code.visitJumpStmt(GOTO,-1,-1,L7);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m075_setThreadPool(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/AbstractConnector;","setThreadPool",new String[]{ "Lorg/mortbay/thread/ThreadPool;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"pool");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(126,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(127,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_OBJECT,1,0,new Field("Lorg/mortbay/jetty/AbstractConnector;","_threadPool","Lorg/mortbay/thread/ThreadPool;"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m076_statsReset(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/AbstractConnector;","statsReset",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(8);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(868,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(870,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(872,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(873,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(874,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(876,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(877,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(878,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(880,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(882,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(883,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(884,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(868,L13);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_WIDE_16,5,Long.valueOf(-1L)); // long: 0xffffffffffffffff  double:NaN
                code.visitConstStmt(CONST_WIDE_16,3,Long.valueOf(0L)); // long: 0x0000000000000000  double:0.000000
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_WIDE,0,7,new Field("Lorg/mortbay/jetty/AbstractConnector;","_statsStartedAt","J"));
                code.visitStmt3R(CMP_LONG,0,0,5);
                code.visitJumpStmt(IF_NEZ,0,-1,L13);
                code.visitStmt2R(MOVE_WIDE,0,5);
                DexLabel L14=new DexLabel();
                code.visitLabel(L14);
                code.visitFieldStmt(IPUT_WIDE,0,7,new Field("Lorg/mortbay/jetty/AbstractConnector;","_statsStartedAt","J"));
                code.visitLabel(L2);
                code.visitFieldStmt(IPUT,2,7,new Field("Lorg/mortbay/jetty/AbstractConnector;","_connections","I"));
                code.visitLabel(L3);
                code.visitFieldStmt(IGET,0,7,new Field("Lorg/mortbay/jetty/AbstractConnector;","_connectionsOpen","I"));
                code.visitFieldStmt(IPUT,0,7,new Field("Lorg/mortbay/jetty/AbstractConnector;","_connectionsOpenMin","I"));
                code.visitLabel(L4);
                code.visitFieldStmt(IGET,0,7,new Field("Lorg/mortbay/jetty/AbstractConnector;","_connectionsOpen","I"));
                code.visitFieldStmt(IPUT,0,7,new Field("Lorg/mortbay/jetty/AbstractConnector;","_connectionsOpenMax","I"));
                code.visitLabel(L5);
                code.visitFieldStmt(IPUT,2,7,new Field("Lorg/mortbay/jetty/AbstractConnector;","_connectionsOpen","I"));
                code.visitLabel(L6);
                code.visitFieldStmt(IPUT_WIDE,3,7,new Field("Lorg/mortbay/jetty/AbstractConnector;","_connectionsDurationMin","J"));
                code.visitLabel(L7);
                code.visitFieldStmt(IPUT_WIDE,3,7,new Field("Lorg/mortbay/jetty/AbstractConnector;","_connectionsDurationMax","J"));
                code.visitLabel(L8);
                code.visitFieldStmt(IPUT_WIDE,3,7,new Field("Lorg/mortbay/jetty/AbstractConnector;","_connectionsDurationTotal","J"));
                code.visitLabel(L9);
                code.visitFieldStmt(IPUT,2,7,new Field("Lorg/mortbay/jetty/AbstractConnector;","_requests","I"));
                code.visitLabel(L10);
                code.visitFieldStmt(IPUT,2,7,new Field("Lorg/mortbay/jetty/AbstractConnector;","_connectionsRequestsMin","I"));
                code.visitLabel(L11);
                code.visitFieldStmt(IPUT,2,7,new Field("Lorg/mortbay/jetty/AbstractConnector;","_connectionsRequestsMax","I"));
                code.visitLabel(L12);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L13);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Ljava/lang/System;","currentTimeMillis",new String[]{ },"J"));
                code.visitStmt1R(MOVE_RESULT_WIDE,0);
                code.visitJumpStmt(GOTO,-1,-1,L14);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m077_stopAccept(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/AbstractConnector;","stopAccept",new String[]{ "I"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/lang/Exception;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"acceptorID");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(562,L0);
                code.visitLabel(L0);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m078_toString(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/AbstractConnector;","toString",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(664,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(665,L1);
                ddv.visitStartLocal(1,L1,"name","Ljava/lang/String;",null);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(666,L2);
                ddv.visitStartLocal(0,L2,"dot","I",null);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(667,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(669,L4);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Ljava/lang/Object;","getClass",new String[]{ },"Ljava/lang/Class;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Ljava/lang/Class;","getName",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L1);
                code.visitConstStmt(CONST_16,2, Integer.valueOf(46)); // int: 0x0000002e  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2},new Method("Ljava/lang/String;","lastIndexOf",new String[]{ "I"},"I"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitLabel(L2);
                code.visitJumpStmt(IF_LEZ,0,-1,L4);
                code.visitLabel(L3);
                code.visitStmt2R1N(ADD_INT_LIT8,2,0,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2},new Method("Ljava/lang/String;","substring",new String[]{ "I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L4);
                code.visitTypeStmt(NEW_INSTANCE,2,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitConstStmt(CONST_STRING,3,"@");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Lorg/mortbay/jetty/AbstractConnector;","getHost",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                DexLabel L5=new DexLabel();
                code.visitJumpStmt(IF_NEZ,3,-1,L5);
                code.visitConstStmt(CONST_STRING,3,"0.0.0.0");
                DexLabel L6=new DexLabel();
                code.visitLabel(L6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitConstStmt(CONST_STRING,3,":");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Lorg/mortbay/jetty/AbstractConnector;","getLocalPort",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,3);
                DexLabel L7=new DexLabel();
                code.visitJumpStmt(IF_GTZ,3,-1,L7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Lorg/mortbay/jetty/AbstractConnector;","getPort",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,3);
                DexLabel L8=new DexLabel();
                code.visitLabel(L8);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "I"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitStmt1R(RETURN_OBJECT,2);
                code.visitLabel(L5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Lorg/mortbay/jetty/AbstractConnector;","getHost",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitJumpStmt(GOTO,-1,-1,L6);
                code.visitLabel(L7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Lorg/mortbay/jetty/AbstractConnector;","getLocalPort",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitJumpStmt(GOTO,-1,-1,L8);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
