package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0393_org_mortbay_thread_BoundedThreadPool {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(ACC_PUBLIC,"Lorg/mortbay/thread/BoundedThreadPool;","Lorg/mortbay/component/AbstractLifeCycle;",new String[]{ "Ljava/io/Serializable;","Lorg/mortbay/thread/ThreadPool;"});
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("BoundedThreadPool.java");
        if(cv!=null){
            DexAnnotationVisitor av00 = cv.visitAnnotation("Ldalvik/annotation/MemberClasses;", Visibility.SYSTEM);
            if(av00 != null) {
                {
                    DexAnnotationVisitor av01 = av00.visitArray("value");
                    if(av01 != null) {
                        av01.visit(null, new DexType("Lorg/mortbay/thread/BoundedThreadPool$PoolThread;"));
                        av01.visitEnd();
                    }
                }
                av00.visitEnd();
            }
        }
        f000___id(cv);
        f001__daemon(cv);
        f002__id(cv);
        f003__idle(cv);
        f004__joinLock(cv);
        f005__lastShrink(cv);
        f006__lock(cv);
        f007__lowThreads(cv);
        f008__maxIdleTimeMs(cv);
        f009__maxThreads(cv);
        f010__minThreads(cv);
        f011__name(cv);
        f012__priority(cv);
        f013__queue(cv);
        f014__threads(cv);
        f015__warned(cv);
        m000__init_(cv);
        m001_access$000(cv);
        m002_access$100(cv);
        m003_access$200(cv);
        m004_access$302(cv);
        m005_access$400(cv);
        m006_access$500(cv);
        m007_access$600(cv);
        m008_access$700(cv);
        m009_access$800(cv);
        m010_access$802(cv);
        m011_dispatch(cv);
        m012_doStart(cv);
        m013_doStop(cv);
        m014_getIdleThreads(cv);
        m015_getLowThreads(cv);
        m016_getMaxIdleTimeMs(cv);
        m017_getMaxThreads(cv);
        m018_getMinThreads(cv);
        m019_getName(cv);
        m020_getQueueSize(cv);
        m021_getThreads(cv);
        m022_getThreadsPriority(cv);
        m023_isDaemon(cv);
        m024_isLowOnThreads(cv);
        m025_join(cv);
        m026_newThread(cv);
        m027_setDaemon(cv);
        m028_setLowThreads(cv);
        m029_setMaxIdleTimeMs(cv);
        m030_setMaxThreads(cv);
        m031_setMinThreads(cv);
        m032_setName(cv);
        m033_setThreadsPriority(cv);
        m034_stopJob(cv);
    }
    public static void f000___id(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE|ACC_STATIC, new Field("Lorg/mortbay/thread/BoundedThreadPool;","__id","I"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f001__daemon(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/thread/BoundedThreadPool;","_daemon","Z"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f002__id(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/thread/BoundedThreadPool;","_id","I"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f003__idle(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/thread/BoundedThreadPool;","_idle","Ljava/util/List;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f004__joinLock(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE|ACC_FINAL, new Field("Lorg/mortbay/thread/BoundedThreadPool;","_joinLock","Ljava/lang/Object;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f005__lastShrink(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/thread/BoundedThreadPool;","_lastShrink","J"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f006__lock(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE|ACC_FINAL, new Field("Lorg/mortbay/thread/BoundedThreadPool;","_lock","Ljava/lang/Object;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f007__lowThreads(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(0, new Field("Lorg/mortbay/thread/BoundedThreadPool;","_lowThreads","I"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f008__maxIdleTimeMs(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/thread/BoundedThreadPool;","_maxIdleTimeMs","I"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f009__maxThreads(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/thread/BoundedThreadPool;","_maxThreads","I"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f010__minThreads(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/thread/BoundedThreadPool;","_minThreads","I"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f011__name(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/thread/BoundedThreadPool;","_name","Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f012__priority(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(0, new Field("Lorg/mortbay/thread/BoundedThreadPool;","_priority","I"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f013__queue(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/thread/BoundedThreadPool;","_queue","Ljava/util/List;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f014__threads(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/thread/BoundedThreadPool;","_threads","Ljava/util/Set;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f015__warned(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/thread/BoundedThreadPool;","_warned","Z"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void m000__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/thread/BoundedThreadPool;","<init>",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(67,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(49,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(50,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(53,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(54,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(55,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(59,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(60,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(61,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(68,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(69,L11);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 3},new Method("Lorg/mortbay/component/AbstractLifeCycle;","<init>",new String[]{ },"V"));
                code.visitLabel(L2);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/lang/Object;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/lang/Object;","<init>",new String[]{ },"V"));
                code.visitFieldStmt(IPUT_OBJECT,0,3,new Field("Lorg/mortbay/thread/BoundedThreadPool;","_lock","Ljava/lang/Object;"));
                code.visitLabel(L3);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/lang/Object;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/lang/Object;","<init>",new String[]{ },"V"));
                code.visitFieldStmt(IPUT_OBJECT,0,3,new Field("Lorg/mortbay/thread/BoundedThreadPool;","_joinLock","Ljava/lang/Object;"));
                code.visitLabel(L4);
                code.visitConstStmt(CONST,0, Integer.valueOf(60000)); // int: 0x0000ea60  float:0.000000
                code.visitFieldStmt(IPUT,0,3,new Field("Lorg/mortbay/thread/BoundedThreadPool;","_maxIdleTimeMs","I"));
                code.visitLabel(L5);
                code.visitConstStmt(CONST_16,0, Integer.valueOf(255)); // int: 0x000000ff  float:0.000000
                code.visitFieldStmt(IPUT,0,3,new Field("Lorg/mortbay/thread/BoundedThreadPool;","_maxThreads","I"));
                code.visitLabel(L6);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitFieldStmt(IPUT,0,3,new Field("Lorg/mortbay/thread/BoundedThreadPool;","_minThreads","I"));
                code.visitLabel(L7);
                code.visitFieldStmt(IPUT_BOOLEAN,1,3,new Field("Lorg/mortbay/thread/BoundedThreadPool;","_warned","Z"));
                code.visitLabel(L8);
                code.visitFieldStmt(IPUT,1,3,new Field("Lorg/mortbay/thread/BoundedThreadPool;","_lowThreads","I"));
                code.visitLabel(L9);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(5)); // int: 0x00000005  float:0.000000
                code.visitFieldStmt(IPUT,0,3,new Field("Lorg/mortbay/thread/BoundedThreadPool;","_priority","I"));
                code.visitLabel(L10);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,1,"btpool");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(SGET,1,-1,new Field("Lorg/mortbay/thread/BoundedThreadPool;","__id","I"));
                code.visitStmt2R1N(ADD_INT_LIT8,2,1,1);
                code.visitFieldStmt(SPUT,2,-1,new Field("Lorg/mortbay/thread/BoundedThreadPool;","__id","I"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "I"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(IPUT_OBJECT,0,3,new Field("Lorg/mortbay/thread/BoundedThreadPool;","_name","Ljava/lang/String;"));
                code.visitLabel(L11);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001_access$000(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_STATIC|ACC_SYNTHETIC, new Method("Lorg/mortbay/thread/BoundedThreadPool;","access$000",new String[]{ "Lorg/mortbay/thread/BoundedThreadPool;"},"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"x0");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(42,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_BOOLEAN,0,1,new Field("Lorg/mortbay/thread/BoundedThreadPool;","_daemon","Z"));
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m002_access$100(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_STATIC|ACC_SYNTHETIC, new Method("Lorg/mortbay/thread/BoundedThreadPool;","access$100",new String[]{ "Lorg/mortbay/thread/BoundedThreadPool;"},"Ljava/lang/Object;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"x0");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(42,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/thread/BoundedThreadPool;","_lock","Ljava/lang/Object;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m003_access$200(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_STATIC|ACC_SYNTHETIC, new Method("Lorg/mortbay/thread/BoundedThreadPool;","access$200",new String[]{ "Lorg/mortbay/thread/BoundedThreadPool;"},"Ljava/util/List;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"x0");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(42,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/thread/BoundedThreadPool;","_queue","Ljava/util/List;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m004_access$302(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_STATIC|ACC_SYNTHETIC, new Method("Lorg/mortbay/thread/BoundedThreadPool;","access$302",new String[]{ "Lorg/mortbay/thread/BoundedThreadPool;","Z"},"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"x0");
                ddv.visitParameterName(1,"x1");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(42,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_BOOLEAN,1,0,new Field("Lorg/mortbay/thread/BoundedThreadPool;","_warned","Z"));
                code.visitStmt1R(RETURN,1);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m005_access$400(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_STATIC|ACC_SYNTHETIC, new Method("Lorg/mortbay/thread/BoundedThreadPool;","access$400",new String[]{ "Lorg/mortbay/thread/BoundedThreadPool;"},"Ljava/util/Set;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"x0");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(42,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/thread/BoundedThreadPool;","_threads","Ljava/util/Set;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m006_access$500(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_STATIC|ACC_SYNTHETIC, new Method("Lorg/mortbay/thread/BoundedThreadPool;","access$500",new String[]{ "Lorg/mortbay/thread/BoundedThreadPool;"},"I"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"x0");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(42,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET,0,1,new Field("Lorg/mortbay/thread/BoundedThreadPool;","_maxThreads","I"));
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m007_access$600(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_STATIC|ACC_SYNTHETIC, new Method("Lorg/mortbay/thread/BoundedThreadPool;","access$600",new String[]{ "Lorg/mortbay/thread/BoundedThreadPool;"},"Ljava/util/List;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"x0");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(42,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/thread/BoundedThreadPool;","_idle","Ljava/util/List;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m008_access$700(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_STATIC|ACC_SYNTHETIC, new Method("Lorg/mortbay/thread/BoundedThreadPool;","access$700",new String[]{ "Lorg/mortbay/thread/BoundedThreadPool;"},"I"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"x0");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(42,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET,0,1,new Field("Lorg/mortbay/thread/BoundedThreadPool;","_minThreads","I"));
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m009_access$800(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_STATIC|ACC_SYNTHETIC, new Method("Lorg/mortbay/thread/BoundedThreadPool;","access$800",new String[]{ "Lorg/mortbay/thread/BoundedThreadPool;"},"J"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"x0");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(42,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_WIDE,0,2,new Field("Lorg/mortbay/thread/BoundedThreadPool;","_lastShrink","J"));
                code.visitStmt1R(RETURN_WIDE,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m010_access$802(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_STATIC|ACC_SYNTHETIC, new Method("Lorg/mortbay/thread/BoundedThreadPool;","access$802",new String[]{ "Lorg/mortbay/thread/BoundedThreadPool;","J"},"J"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"x0");
                ddv.visitParameterName(1,"x1");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(42,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_WIDE,1,0,new Field("Lorg/mortbay/thread/BoundedThreadPool;","_lastShrink","J"));
                code.visitStmt1R(RETURN_WIDE,1);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m011_dispatch(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/thread/BoundedThreadPool;","dispatch",new String[]{ "Ljava/lang/Runnable;"},"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(8);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexLabel L3=new DexLabel();
                DexLabel L4=new DexLabel();
                code.visitTryCatch(L3,L4,new DexLabel[]{L2},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"job");
                DexLabel L5=new DexLabel();
                ddv.visitPrologue(L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(77,L6);
                ddv.visitLineNumber(79,L0);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(80,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(109,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(83,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(84,L10);
                ddv.visitStartLocal(0,L10,"idle","I",null);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(86,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(87,L12);
                ddv.visitStartLocal(1,L12,"thread","Lorg/mortbay/thread/BoundedThreadPool$PoolThread;",null);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(107,L13);
                ddv.visitEndLocal(1,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(109,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(92,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(95,L16);
                ddv.visitLineNumber(107,L2);
                ddv.visitEndLocal(0,L2);
                ddv.visitLineNumber(99,L3);
                ddv.visitRestartLocal(0,L3);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(101,L17);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(102,L18);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(104,L19);
                code.visitLabel(L5);
                code.visitConstStmt(CONST_4,5, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitLabel(L6);
                code.visitFieldStmt(IGET_OBJECT,2,6,new Field("Lorg/mortbay/thread/BoundedThreadPool;","_lock","Ljava/lang/Object;"));
                code.visitStmt1R(MONITOR_ENTER,2);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Lorg/mortbay/thread/BoundedThreadPool;","isRunning",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitJumpStmt(IF_EQZ,3,-1,L7);
                code.visitJumpStmt(IF_NEZ,7,-1,L9);
                code.visitLabel(L7);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitStmt1R(MONITOR_EXIT,2);
                code.visitStmt2R(MOVE,2,3);
                code.visitLabel(L8);
                code.visitStmt1R(RETURN,2);
                code.visitLabel(L9);
                code.visitFieldStmt(IGET_OBJECT,3,6,new Field("Lorg/mortbay/thread/BoundedThreadPool;","_idle","Ljava/util/List;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 3},new Method("Ljava/util/List;","size",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitLabel(L10);
                code.visitJumpStmt(IF_LEZ,0,-1,L15);
                code.visitLabel(L11);
                code.visitFieldStmt(IGET_OBJECT,3,6,new Field("Lorg/mortbay/thread/BoundedThreadPool;","_idle","Ljava/util/List;"));
                code.visitStmt3R(SUB_INT,4,0,5);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 3,4},new Method("Ljava/util/List;","remove",new String[]{ "I"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitTypeStmt(CHECK_CAST,1,-1,"Lorg/mortbay/thread/BoundedThreadPool$PoolThread;");
                code.visitLabel(L12);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,7},new Method("Lorg/mortbay/thread/BoundedThreadPool$PoolThread;","dispatch",new String[]{ "Ljava/lang/Runnable;"},"V"));
                code.visitLabel(L13);
                code.visitStmt1R(MONITOR_EXIT,2);
                code.visitStmt2R(MOVE,2,5);
                code.visitLabel(L14);
                code.visitJumpStmt(GOTO,-1,-1,L8);
                code.visitLabel(L15);
                code.visitFieldStmt(IGET_OBJECT,3,6,new Field("Lorg/mortbay/thread/BoundedThreadPool;","_threads","Ljava/util/Set;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 3},new Method("Ljava/util/Set;","size",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitFieldStmt(IGET,4,6,new Field("Lorg/mortbay/thread/BoundedThreadPool;","_maxThreads","I"));
                code.visitJumpStmt(IF_GE,3,4,L3);
                code.visitLabel(L16);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,7},new Method("Lorg/mortbay/thread/BoundedThreadPool;","newThread",new String[]{ "Ljava/lang/Runnable;"},"Lorg/mortbay/thread/BoundedThreadPool$PoolThread;"));
                code.visitJumpStmt(GOTO,-1,-1,L13);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,3);
                code.visitStmt1R(MONITOR_EXIT,2);
                code.visitLabel(L1);
                code.visitStmt1R(THROW,3);
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_BOOLEAN,3,6,new Field("Lorg/mortbay/thread/BoundedThreadPool;","_warned","Z"));
                code.visitJumpStmt(IF_NEZ,3,-1,L19);
                code.visitLabel(L17);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitFieldStmt(IPUT_BOOLEAN,3,6,new Field("Lorg/mortbay/thread/BoundedThreadPool;","_warned","Z"));
                code.visitLabel(L18);
                code.visitConstStmt(CONST_STRING,3,"Out of threads for {}");
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 3,6},new Method("Lorg/mortbay/log/Log;","debug",new String[]{ "Ljava/lang/String;","Ljava/lang/Object;"},"V"));
                code.visitLabel(L19);
                code.visitFieldStmt(IGET_OBJECT,3,6,new Field("Lorg/mortbay/thread/BoundedThreadPool;","_queue","Ljava/util/List;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 3,7},new Method("Ljava/util/List;","add",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitLabel(L4);
                code.visitJumpStmt(GOTO,-1,-1,L13);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m012_doStart(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Lorg/mortbay/thread/BoundedThreadPool;","doStart",new String[]{ },"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/lang/Exception;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(323,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(324,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(326,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(327,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(328,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(330,L5);
                DexLabel L6=new DexLabel();
                ddv.visitStartLocal(0,L6,"i","I",null);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(332,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(330,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(334,L9);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET,1,3,new Field("Lorg/mortbay/thread/BoundedThreadPool;","_maxThreads","I"));
                code.visitFieldStmt(IGET,2,3,new Field("Lorg/mortbay/thread/BoundedThreadPool;","_minThreads","I"));
                code.visitJumpStmt(IF_LT,1,2,L1);
                code.visitFieldStmt(IGET,1,3,new Field("Lorg/mortbay/thread/BoundedThreadPool;","_minThreads","I"));
                code.visitJumpStmt(IF_GTZ,1,-1,L2);
                code.visitLabel(L1);
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Ljava/lang/IllegalArgumentException;");
                code.visitConstStmt(CONST_STRING,2,"!0<minThreads<maxThreads");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1,2},new Method("Ljava/lang/IllegalArgumentException;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitStmt1R(THROW,1);
                code.visitLabel(L2);
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Ljava/util/HashSet;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1},new Method("Ljava/util/HashSet;","<init>",new String[]{ },"V"));
                code.visitFieldStmt(IPUT_OBJECT,1,3,new Field("Lorg/mortbay/thread/BoundedThreadPool;","_threads","Ljava/util/Set;"));
                code.visitLabel(L3);
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Ljava/util/ArrayList;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1},new Method("Ljava/util/ArrayList;","<init>",new String[]{ },"V"));
                code.visitFieldStmt(IPUT_OBJECT,1,3,new Field("Lorg/mortbay/thread/BoundedThreadPool;","_idle","Ljava/util/List;"));
                code.visitLabel(L4);
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Ljava/util/LinkedList;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1},new Method("Ljava/util/LinkedList;","<init>",new String[]{ },"V"));
                code.visitFieldStmt(IPUT_OBJECT,1,3,new Field("Lorg/mortbay/thread/BoundedThreadPool;","_queue","Ljava/util/List;"));
                code.visitLabel(L5);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L6);
                code.visitFieldStmt(IGET,1,3,new Field("Lorg/mortbay/thread/BoundedThreadPool;","_minThreads","I"));
                code.visitJumpStmt(IF_GE,0,1,L9);
                code.visitLabel(L7);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,1},new Method("Lorg/mortbay/thread/BoundedThreadPool;","newThread",new String[]{ "Ljava/lang/Runnable;"},"Lorg/mortbay/thread/BoundedThreadPool$PoolThread;"));
                code.visitLabel(L8);
                code.visitStmt2R1N(ADD_INT_LIT8,0,0,1);
                code.visitJumpStmt(GOTO,-1,-1,L6);
                code.visitLabel(L9);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m013_doStop(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Lorg/mortbay/thread/BoundedThreadPool;","doStop",new String[]{ },"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/lang/Exception;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexLabel L3=new DexLabel();
                DexLabel L4=new DexLabel();
                code.visitTryCatch(L3,L4,new DexLabel[]{L2},new String[]{ null});
                DexLabel L5=new DexLabel();
                DexLabel L6=new DexLabel();
                DexLabel L7=new DexLabel();
                code.visitTryCatch(L5,L6,new DexLabel[]{L7},new String[]{ null});
                DexLabel L8=new DexLabel();
                DexLabel L9=new DexLabel();
                DexLabel L10=new DexLabel();
                code.visitTryCatch(L8,L9,new DexLabel[]{L10},new String[]{ "Ljava/lang/InterruptedException;"});
                DexLabel L11=new DexLabel();
                DexLabel L12=new DexLabel();
                code.visitTryCatch(L11,L12,new DexLabel[]{L7},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L13=new DexLabel();
                ddv.visitPrologue(L13);
                ddv.visitLineNumber(346,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(348,L14);
                DexLabel L15=new DexLabel();
                ddv.visitStartLocal(0,L15,"i","I",null);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(350,L16);
                ddv.visitLineNumber(352,L0);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(353,L17);
                ddv.visitStartLocal(1,L17,"iter","Ljava/util/Iterator;",null);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(354,L18);
                ddv.visitLineNumber(355,L2);
                ddv.visitEndLocal(1,L2);
                ddv.visitRestartLocal(1,L3);
                ddv.visitLineNumber(357,L4);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(358,L19);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(369,L20);
                ddv.visitEndLocal(1,L20);
                DexLabel L21=new DexLabel();
                ddv.visitLineNumber(370,L21);
                DexLabel L22=new DexLabel();
                ddv.visitLineNumber(372,L22);
                ddv.visitLineNumber(374,L5);
                DexLabel L23=new DexLabel();
                ddv.visitLineNumber(375,L23);
                ddv.visitLineNumber(376,L6);
                DexLabel L24=new DexLabel();
                ddv.visitLineNumber(363,L24);
                ddv.visitRestartLocal(1,L24);
                ddv.visitLineNumber(348,L9);
                ddv.visitLineNumber(375,L7);
                ddv.visitEndLocal(1,L7);
                ddv.visitLineNumber(365,L10);
                ddv.visitRestartLocal(1,L10);
                code.visitLabel(L13);
                code.visitMethodStmt(INVOKE_SUPER,new int[]{ 4},new Method("Lorg/mortbay/component/AbstractLifeCycle;","doStop",new String[]{ },"V"));
                code.visitLabel(L14);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L15);
                code.visitConstStmt(CONST_16,2, Integer.valueOf(100)); // int: 0x00000064  float:0.000000
                code.visitJumpStmt(IF_GE,0,2,L20);
                code.visitLabel(L16);
                code.visitFieldStmt(IGET_OBJECT,3,4,new Field("Lorg/mortbay/thread/BoundedThreadPool;","_lock","Ljava/lang/Object;"));
                code.visitStmt1R(MONITOR_ENTER,3);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,2,4,new Field("Lorg/mortbay/thread/BoundedThreadPool;","_threads","Ljava/util/Set;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 2},new Method("Ljava/util/Set;","iterator",new String[]{ },"Ljava/util/Iterator;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L17);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 1},new Method("Ljava/util/Iterator;","hasNext",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitJumpStmt(IF_EQZ,2,-1,L3);
                code.visitLabel(L18);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 1},new Method("Ljava/util/Iterator;","next",new String[]{ },"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitTypeStmt(CHECK_CAST,2,-1,"Ljava/lang/Thread;");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Ljava/lang/Thread;","interrupt",new String[]{ },"V"));
                code.visitJumpStmt(GOTO,-1,-1,L17);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,2);
                code.visitStmt1R(MONITOR_EXIT,3);
                code.visitLabel(L1);
                code.visitStmt1R(THROW,2);
                code.visitLabel(L3);
                code.visitStmt1R(MONITOR_EXIT,3);
                code.visitLabel(L4);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Ljava/lang/Thread;","yield",new String[]{ },"V"));
                code.visitLabel(L19);
                code.visitFieldStmt(IGET_OBJECT,2,4,new Field("Lorg/mortbay/thread/BoundedThreadPool;","_threads","Ljava/util/Set;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 2},new Method("Ljava/util/Set;","size",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitJumpStmt(IF_NEZ,2,-1,L24);
                code.visitLabel(L20);
                code.visitFieldStmt(IGET_OBJECT,2,4,new Field("Lorg/mortbay/thread/BoundedThreadPool;","_threads","Ljava/util/Set;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 2},new Method("Ljava/util/Set;","size",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitJumpStmt(IF_LEZ,2,-1,L22);
                code.visitLabel(L21);
                code.visitTypeStmt(NEW_INSTANCE,2,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitFieldStmt(IGET_OBJECT,3,4,new Field("Lorg/mortbay/thread/BoundedThreadPool;","_threads","Ljava/util/Set;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 3},new Method("Ljava/util/Set;","size",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "I"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitConstStmt(CONST_STRING,3," threads could not be stopped");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 2},new Method("Lorg/mortbay/log/Log;","warn",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L22);
                code.visitFieldStmt(IGET_OBJECT,2,4,new Field("Lorg/mortbay/thread/BoundedThreadPool;","_joinLock","Ljava/lang/Object;"));
                code.visitStmt1R(MONITOR_ENTER,2);
                code.visitLabel(L5);
                code.visitFieldStmt(IGET_OBJECT,3,4,new Field("Lorg/mortbay/thread/BoundedThreadPool;","_joinLock","Ljava/lang/Object;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Ljava/lang/Object;","notifyAll",new String[]{ },"V"));
                code.visitLabel(L23);
                code.visitStmt1R(MONITOR_EXIT,2);
                code.visitLabel(L6);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L24);
                code.visitStmt2R1N(MUL_INT_LIT8,2,0,100);
                code.visitStmt2R(INT_TO_LONG,2,2);
                code.visitLabel(L8);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 2,3},new Method("Ljava/lang/Thread;","sleep",new String[]{ "J"},"V"));
                code.visitLabel(L9);
                code.visitStmt2R1N(ADD_INT_LIT8,0,0,1);
                code.visitJumpStmt(GOTO,-1,-1,L15);
                code.visitLabel(L7);
                code.visitStmt1R(MOVE_EXCEPTION,3);
                code.visitLabel(L11);
                code.visitStmt1R(MONITOR_EXIT,2);
                code.visitLabel(L12);
                code.visitStmt1R(THROW,3);
                code.visitLabel(L10);
                code.visitStmt1R(MOVE_EXCEPTION,2);
                code.visitJumpStmt(GOTO,-1,-1,L9);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m014_getIdleThreads(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/thread/BoundedThreadPool;","getIdleThreads",new String[]{ },"I"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(119,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/thread/BoundedThreadPool;","_idle","Ljava/util/List;"));
                DexLabel L1=new DexLabel();
                code.visitJumpStmt(IF_NEZ,0,-1,L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                DexLabel L2=new DexLabel();
                code.visitLabel(L2);
                code.visitStmt1R(RETURN,0);
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/thread/BoundedThreadPool;","_idle","Ljava/util/List;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0},new Method("Ljava/util/List;","size",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m015_getLowThreads(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/thread/BoundedThreadPool;","getLowThreads",new String[]{ },"I"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(128,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET,0,1,new Field("Lorg/mortbay/thread/BoundedThreadPool;","_lowThreads","I"));
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m016_getMaxIdleTimeMs(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/thread/BoundedThreadPool;","getMaxIdleTimeMs",new String[]{ },"I"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(140,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET,0,1,new Field("Lorg/mortbay/thread/BoundedThreadPool;","_maxIdleTimeMs","I"));
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m017_getMaxThreads(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/thread/BoundedThreadPool;","getMaxThreads",new String[]{ },"I"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(151,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET,0,1,new Field("Lorg/mortbay/thread/BoundedThreadPool;","_maxThreads","I"));
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m018_getMinThreads(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/thread/BoundedThreadPool;","getMinThreads",new String[]{ },"I"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(162,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET,0,1,new Field("Lorg/mortbay/thread/BoundedThreadPool;","_minThreads","I"));
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m019_getName(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/thread/BoundedThreadPool;","getName",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(171,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/thread/BoundedThreadPool;","_name","Ljava/lang/String;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m020_getQueueSize(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/thread/BoundedThreadPool;","getQueueSize",new String[]{ },"I"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L3=new DexLabel();
                ddv.visitPrologue(L3);
                ddv.visitLineNumber(196,L3);
                ddv.visitLineNumber(198,L0);
                ddv.visitLineNumber(199,L2);
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/thread/BoundedThreadPool;","_lock","Ljava/lang/Object;"));
                code.visitStmt1R(MONITOR_ENTER,0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/thread/BoundedThreadPool;","_queue","Ljava/util/List;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 1},new Method("Ljava/util/List;","size",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitStmt1R(MONITOR_EXIT,0);
                code.visitStmt1R(RETURN,1);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,1);
                code.visitStmt1R(MONITOR_EXIT,0);
                code.visitLabel(L1);
                code.visitStmt1R(THROW,1);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m021_getThreads(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/thread/BoundedThreadPool;","getThreads",new String[]{ },"I"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(181,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/thread/BoundedThreadPool;","_threads","Ljava/util/Set;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0},new Method("Ljava/util/Set;","size",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m022_getThreadsPriority(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/thread/BoundedThreadPool;","getThreadsPriority",new String[]{ },"I"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(190,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET,0,1,new Field("Lorg/mortbay/thread/BoundedThreadPool;","_priority","I"));
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m023_isDaemon(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/thread/BoundedThreadPool;","isDaemon",new String[]{ },"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(208,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_BOOLEAN,0,1,new Field("Lorg/mortbay/thread/BoundedThreadPool;","_daemon","Z"));
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m024_isLowOnThreads(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/thread/BoundedThreadPool;","isLowOnThreads",new String[]{ },"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L3=new DexLabel();
                ddv.visitPrologue(L3);
                ddv.visitLineNumber(214,L3);
                ddv.visitLineNumber(217,L0);
                ddv.visitLineNumber(218,L2);
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,0,3,new Field("Lorg/mortbay/thread/BoundedThreadPool;","_lock","Ljava/lang/Object;"));
                code.visitStmt1R(MONITOR_ENTER,0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,1,3,new Field("Lorg/mortbay/thread/BoundedThreadPool;","_queue","Ljava/util/List;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 1},new Method("Ljava/util/List;","size",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitFieldStmt(IGET,2,3,new Field("Lorg/mortbay/thread/BoundedThreadPool;","_lowThreads","I"));
                DexLabel L4=new DexLabel();
                code.visitJumpStmt(IF_LE,1,2,L4);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                DexLabel L5=new DexLabel();
                code.visitLabel(L5);
                code.visitStmt1R(MONITOR_EXIT,0);
                code.visitStmt1R(RETURN,1);
                code.visitLabel(L4);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L5);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,1);
                code.visitStmt1R(MONITOR_EXIT,0);
                code.visitLabel(L1);
                code.visitStmt1R(THROW,1);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m025_join(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/thread/BoundedThreadPool;","join",new String[]{ },"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/lang/InterruptedException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexLabel L3=new DexLabel();
                DexLabel L4=new DexLabel();
                code.visitTryCatch(L3,L4,new DexLabel[]{L2},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L5=new DexLabel();
                ddv.visitPrologue(L5);
                ddv.visitLineNumber(224,L5);
                ddv.visitLineNumber(226,L0);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(227,L6);
                ddv.visitLineNumber(228,L2);
                ddv.visitLineNumber(231,L4);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(232,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(233,L8);
                code.visitLabel(L5);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/thread/BoundedThreadPool;","_joinLock","Ljava/lang/Object;"));
                code.visitStmt1R(MONITOR_ENTER,0);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/thread/BoundedThreadPool;","isRunning",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitJumpStmt(IF_EQZ,1,-1,L3);
                code.visitLabel(L6);
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/thread/BoundedThreadPool;","_joinLock","Ljava/lang/Object;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/lang/Object;","wait",new String[]{ },"V"));
                code.visitJumpStmt(GOTO,-1,-1,L0);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,1);
                code.visitStmt1R(MONITOR_EXIT,0);
                code.visitLabel(L1);
                code.visitStmt1R(THROW,1);
                code.visitLabel(L3);
                code.visitStmt1R(MONITOR_EXIT,0);
                code.visitLabel(L4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/thread/BoundedThreadPool;","isStopping",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_EQZ,0,-1,L8);
                code.visitLabel(L7);
                code.visitConstStmt(CONST_WIDE_16,0,Long.valueOf(10L)); // long: 0x000000000000000a  double:0.000000
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0,1},new Method("Ljava/lang/Thread;","sleep",new String[]{ "J"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L4);
                code.visitLabel(L8);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m026_newThread(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Lorg/mortbay/thread/BoundedThreadPool;","newThread",new String[]{ "Ljava/lang/Runnable;"},"Lorg/mortbay/thread/BoundedThreadPool$PoolThread;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(7);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"job");
                DexLabel L3=new DexLabel();
                ddv.visitPrologue(L3);
                ddv.visitLineNumber(381,L3);
                ddv.visitLineNumber(383,L0);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(384,L4);
                ddv.visitStartLocal(0,L4,"thread","Lorg/mortbay/thread/BoundedThreadPool$PoolThread;",null);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(385,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(386,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(387,L7);
                ddv.visitLineNumber(388,L2);
                ddv.visitEndLocal(0,L2);
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,1,5,new Field("Lorg/mortbay/thread/BoundedThreadPool;","_lock","Ljava/lang/Object;"));
                code.visitStmt1R(MONITOR_ENTER,1);
                code.visitLabel(L0);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Lorg/mortbay/thread/BoundedThreadPool$PoolThread;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,5,6},new Method("Lorg/mortbay/thread/BoundedThreadPool$PoolThread;","<init>",new String[]{ "Lorg/mortbay/thread/BoundedThreadPool;","Ljava/lang/Runnable;"},"V"));
                code.visitLabel(L4);
                code.visitFieldStmt(IGET_OBJECT,2,5,new Field("Lorg/mortbay/thread/BoundedThreadPool;","_threads","Ljava/util/Set;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 2,0},new Method("Ljava/util/Set;","add",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitLabel(L5);
                code.visitTypeStmt(NEW_INSTANCE,2,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitFieldStmt(IGET_OBJECT,3,5,new Field("Lorg/mortbay/thread/BoundedThreadPool;","_name","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitConstStmt(CONST_STRING,3,"-");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitFieldStmt(IGET,3,5,new Field("Lorg/mortbay/thread/BoundedThreadPool;","_id","I"));
                code.visitStmt2R1N(ADD_INT_LIT8,4,3,1);
                code.visitFieldStmt(IPUT,4,5,new Field("Lorg/mortbay/thread/BoundedThreadPool;","_id","I"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "I"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,2},new Method("Lorg/mortbay/thread/BoundedThreadPool$PoolThread;","setName",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/thread/BoundedThreadPool$PoolThread;","start",new String[]{ },"V"));
                code.visitLabel(L7);
                code.visitStmt1R(MONITOR_EXIT,1);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,2);
                code.visitStmt1R(MONITOR_EXIT,1);
                code.visitLabel(L1);
                code.visitStmt1R(THROW,2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m027_setDaemon(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/thread/BoundedThreadPool;","setDaemon",new String[]{ "Z"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"daemon");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(241,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(242,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_BOOLEAN,1,0,new Field("Lorg/mortbay/thread/BoundedThreadPool;","_daemon","Z"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m028_setLowThreads(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/thread/BoundedThreadPool;","setLowThreads",new String[]{ "I"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"lowThreads");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(250,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(251,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT,1,0,new Field("Lorg/mortbay/thread/BoundedThreadPool;","_lowThreads","I"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m029_setMaxIdleTimeMs(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/thread/BoundedThreadPool;","setMaxIdleTimeMs",new String[]{ "I"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"maxIdleTimeMs");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(263,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(264,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT,1,0,new Field("Lorg/mortbay/thread/BoundedThreadPool;","_maxIdleTimeMs","I"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m030_setMaxThreads(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/thread/BoundedThreadPool;","setMaxThreads",new String[]{ "I"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"maxThreads");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(274,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(275,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(276,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(277,L3);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/thread/BoundedThreadPool;","isStarted",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_EQZ,0,-1,L2);
                code.visitFieldStmt(IGET,0,2,new Field("Lorg/mortbay/thread/BoundedThreadPool;","_minThreads","I"));
                code.visitJumpStmt(IF_GE,3,0,L2);
                code.visitLabel(L1);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/lang/IllegalArgumentException;");
                code.visitConstStmt(CONST_STRING,1,"!minThreads<maxThreads");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1},new Method("Ljava/lang/IllegalArgumentException;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitStmt1R(THROW,0);
                code.visitLabel(L2);
                code.visitFieldStmt(IPUT,3,2,new Field("Lorg/mortbay/thread/BoundedThreadPool;","_maxThreads","I"));
                code.visitLabel(L3);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m031_setMinThreads(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/thread/BoundedThreadPool;","setMinThreads",new String[]{ "I"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexLabel L3=new DexLabel();
                DexLabel L4=new DexLabel();
                code.visitTryCatch(L3,L4,new DexLabel[]{L2},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"minThreads");
                DexLabel L5=new DexLabel();
                ddv.visitPrologue(L5);
                ddv.visitLineNumber(287,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(288,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(289,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(290,L8);
                ddv.visitLineNumber(292,L0);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(294,L9);
                ddv.visitLineNumber(296,L2);
                ddv.visitLineNumber(297,L4);
                code.visitLabel(L5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Lorg/mortbay/thread/BoundedThreadPool;","isStarted",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_EQZ,0,-1,L7);
                code.visitJumpStmt(IF_LEZ,4,-1,L6);
                code.visitFieldStmt(IGET,0,3,new Field("Lorg/mortbay/thread/BoundedThreadPool;","_maxThreads","I"));
                code.visitJumpStmt(IF_LE,4,0,L7);
                code.visitLabel(L6);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/lang/IllegalArgumentException;");
                code.visitConstStmt(CONST_STRING,1,"!0<=minThreads<maxThreads");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1},new Method("Ljava/lang/IllegalArgumentException;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitStmt1R(THROW,0);
                code.visitLabel(L7);
                code.visitFieldStmt(IPUT,4,3,new Field("Lorg/mortbay/thread/BoundedThreadPool;","_minThreads","I"));
                code.visitLabel(L8);
                code.visitFieldStmt(IGET_OBJECT,0,3,new Field("Lorg/mortbay/thread/BoundedThreadPool;","_lock","Ljava/lang/Object;"));
                code.visitStmt1R(MONITOR_ENTER,0);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Lorg/mortbay/thread/BoundedThreadPool;","isStarted",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitJumpStmt(IF_EQZ,1,-1,L3);
                code.visitFieldStmt(IGET_OBJECT,1,3,new Field("Lorg/mortbay/thread/BoundedThreadPool;","_threads","Ljava/util/Set;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 1},new Method("Ljava/util/Set;","size",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitFieldStmt(IGET,2,3,new Field("Lorg/mortbay/thread/BoundedThreadPool;","_minThreads","I"));
                code.visitJumpStmt(IF_GE,1,2,L3);
                code.visitLabel(L9);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,1},new Method("Lorg/mortbay/thread/BoundedThreadPool;","newThread",new String[]{ "Ljava/lang/Runnable;"},"Lorg/mortbay/thread/BoundedThreadPool$PoolThread;"));
                code.visitJumpStmt(GOTO,-1,-1,L0);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,1);
                code.visitStmt1R(MONITOR_EXIT,0);
                code.visitLabel(L1);
                code.visitStmt1R(THROW,1);
                code.visitLabel(L3);
                code.visitStmt1R(MONITOR_EXIT,0);
                code.visitLabel(L4);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m032_setName(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/thread/BoundedThreadPool;","setName",new String[]{ "Ljava/lang/String;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"name");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(305,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(306,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_OBJECT,1,0,new Field("Lorg/mortbay/thread/BoundedThreadPool;","_name","Ljava/lang/String;"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m033_setThreadsPriority(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/thread/BoundedThreadPool;","setThreadsPriority",new String[]{ "I"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"priority");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(314,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(315,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT,1,0,new Field("Lorg/mortbay/thread/BoundedThreadPool;","_priority","I"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m034_stopJob(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Lorg/mortbay/thread/BoundedThreadPool;","stopJob",new String[]{ "Ljava/lang/Thread;","Ljava/lang/Object;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"thread");
                ddv.visitParameterName(1,"job");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(401,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(402,L1);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/lang/Thread;","interrupt",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
