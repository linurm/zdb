package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0024_javax_servlet_UnavailableException {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(ACC_PUBLIC,"Ljavax/servlet/UnavailableException;","Ljavax/servlet/ServletException;",new String[]{ });
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("UnavailableException.java");
        f000_permanent(cv);
        f001_seconds(cv);
        f002_servlet(cv);
        m000__init_(cv);
        m001__init_(cv);
        m002__init_(cv);
        m003__init_(cv);
        m004_getServlet(cv);
        m005_getUnavailableSeconds(cv);
        m006_isPermanent(cv);
    }
    public static void f000_permanent(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Ljavax/servlet/UnavailableException;","permanent","Z"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f001_seconds(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Ljavax/servlet/UnavailableException;","seconds","I"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f002_servlet(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Ljavax/servlet/UnavailableException;","servlet","Ljavax/servlet/Servlet;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void m000__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Ljavax/servlet/UnavailableException;","<init>",new String[]{ "I","Ljavax/servlet/Servlet;","Ljava/lang/String;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"seconds");
                ddv.visitParameterName(1,"servlet");
                ddv.visitParameterName(2,"msg");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(104,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(105,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(106,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(107,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(110,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(111,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(109,L6);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1,4},new Method("Ljavax/servlet/ServletException;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L1);
                code.visitFieldStmt(IPUT_OBJECT,3,1,new Field("Ljavax/servlet/UnavailableException;","servlet","Ljavax/servlet/Servlet;"));
                code.visitLabel(L2);
                code.visitJumpStmt(IF_GTZ,2,-1,L6);
                code.visitLabel(L3);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(-1)); // int: 0xffffffff  float:NaN
                code.visitFieldStmt(IPUT,0,1,new Field("Ljavax/servlet/UnavailableException;","seconds","I"));
                code.visitLabel(L4);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT_BOOLEAN,0,1,new Field("Ljavax/servlet/UnavailableException;","permanent","Z"));
                code.visitLabel(L5);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L6);
                code.visitFieldStmt(IPUT,2,1,new Field("Ljavax/servlet/UnavailableException;","seconds","I"));
                code.visitJumpStmt(GOTO,-1,-1,L4);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Ljavax/servlet/UnavailableException;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"msg");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(125,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(127,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(128,L2);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1,2},new Method("Ljavax/servlet/ServletException;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitFieldStmt(IPUT_BOOLEAN,0,1,new Field("Ljavax/servlet/UnavailableException;","permanent","Z"));
                code.visitLabel(L2);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m002__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Ljavax/servlet/UnavailableException;","<init>",new String[]{ "Ljava/lang/String;","I"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"msg");
                ddv.visitParameterName(1,"seconds");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(153,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(155,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(156,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(160,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(161,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(158,L5);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1,2},new Method("Ljavax/servlet/ServletException;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L1);
                code.visitJumpStmt(IF_GTZ,3,-1,L5);
                code.visitLabel(L2);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(-1)); // int: 0xffffffff  float:NaN
                code.visitFieldStmt(IPUT,0,1,new Field("Ljavax/servlet/UnavailableException;","seconds","I"));
                code.visitLabel(L3);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT_BOOLEAN,0,1,new Field("Ljavax/servlet/UnavailableException;","permanent","Z"));
                code.visitLabel(L4);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L5);
                code.visitFieldStmt(IPUT,3,1,new Field("Ljavax/servlet/UnavailableException;","seconds","I"));
                code.visitJumpStmt(GOTO,-1,-1,L3);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m003__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Ljavax/servlet/UnavailableException;","<init>",new String[]{ "Ljavax/servlet/Servlet;","Ljava/lang/String;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"servlet");
                ddv.visitParameterName(1,"msg");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(81,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(82,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(83,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(84,L3);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1,3},new Method("Ljavax/servlet/ServletException;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L1);
                code.visitFieldStmt(IPUT_OBJECT,2,1,new Field("Ljavax/servlet/UnavailableException;","servlet","Ljavax/servlet/Servlet;"));
                code.visitLabel(L2);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitFieldStmt(IPUT_BOOLEAN,0,1,new Field("Ljavax/servlet/UnavailableException;","permanent","Z"));
                code.visitLabel(L3);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m004_getServlet(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Ljavax/servlet/UnavailableException;","getServlet",new String[]{ },"Ljavax/servlet/Servlet;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(192,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Ljavax/servlet/UnavailableException;","servlet","Ljavax/servlet/Servlet;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m005_getUnavailableSeconds(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Ljavax/servlet/UnavailableException;","getUnavailableSeconds",new String[]{ },"I"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(213,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_BOOLEAN,0,1,new Field("Ljavax/servlet/UnavailableException;","permanent","Z"));
                DexLabel L1=new DexLabel();
                code.visitJumpStmt(IF_EQZ,0,-1,L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(-1)); // int: 0xffffffff  float:NaN
                DexLabel L2=new DexLabel();
                code.visitLabel(L2);
                code.visitStmt1R(RETURN,0);
                code.visitLabel(L1);
                code.visitFieldStmt(IGET,0,1,new Field("Ljavax/servlet/UnavailableException;","seconds","I"));
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m006_isPermanent(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Ljavax/servlet/UnavailableException;","isPermanent",new String[]{ },"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(178,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_BOOLEAN,0,1,new Field("Ljavax/servlet/UnavailableException;","permanent","Z"));
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
