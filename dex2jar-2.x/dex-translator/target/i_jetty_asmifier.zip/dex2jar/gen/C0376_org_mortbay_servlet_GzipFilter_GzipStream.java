package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0376_org_mortbay_servlet_GzipFilter_GzipStream {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(ACC_PUBLIC,"Lorg/mortbay/servlet/GzipFilter$GzipStream;","Ljavax/servlet/ServletOutputStream;",new String[]{ });
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("GzipFilter.java");
        if(cv!=null){
            DexAnnotationVisitor av00 = cv.visitAnnotation("Ldalvik/annotation/EnclosingClass;", Visibility.SYSTEM);
            if(av00 != null) {
                av00.visit("value", new DexType("Lorg/mortbay/servlet/GzipFilter;"));
                av00.visitEnd();
            }
        }
        if(cv!=null){
            DexAnnotationVisitor av00 = cv.visitAnnotation("Ldalvik/annotation/InnerClass;", Visibility.SYSTEM);
            if(av00 != null) {
                av00.visit("accessFlags",  Integer.valueOf(9));
                av00.visit("name", "GzipStream");
                av00.visitEnd();
            }
        }
        f000__bOut(cv);
        f001__bufferSize(cv);
        f002__closed(cv);
        f003__contentLength(cv);
        f004__gzOut(cv);
        f005__minGzipSize(cv);
        f006__out(cv);
        f007__request(cv);
        f008__response(cv);
        m000__init_(cv);
        m001_checkOut(cv);
        m002_close(cv);
        m003_doGzip(cv);
        m004_doNotGzip(cv);
        m005_finish(cv);
        m006_flush(cv);
        m007_resetBuffer(cv);
        m008_setContentEncodingGzip(cv);
        m009_setContentLength(cv);
        m010_write(cv);
        m011_write(cv);
        m012_write(cv);
    }
    public static void f000__bOut(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PROTECTED, new Field("Lorg/mortbay/servlet/GzipFilter$GzipStream;","_bOut","Lorg/mortbay/util/ByteArrayOutputStream2;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f001__bufferSize(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PROTECTED, new Field("Lorg/mortbay/servlet/GzipFilter$GzipStream;","_bufferSize","I"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f002__closed(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PROTECTED, new Field("Lorg/mortbay/servlet/GzipFilter$GzipStream;","_closed","Z"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f003__contentLength(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PROTECTED, new Field("Lorg/mortbay/servlet/GzipFilter$GzipStream;","_contentLength","J"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f004__gzOut(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PROTECTED, new Field("Lorg/mortbay/servlet/GzipFilter$GzipStream;","_gzOut","Ljava/util/zip/GZIPOutputStream;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f005__minGzipSize(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PROTECTED, new Field("Lorg/mortbay/servlet/GzipFilter$GzipStream;","_minGzipSize","I"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f006__out(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PROTECTED, new Field("Lorg/mortbay/servlet/GzipFilter$GzipStream;","_out","Ljava/io/OutputStream;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f007__request(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PROTECTED, new Field("Lorg/mortbay/servlet/GzipFilter$GzipStream;","_request","Ljavax/servlet/http/HttpServletRequest;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f008__response(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PROTECTED, new Field("Lorg/mortbay/servlet/GzipFilter$GzipStream;","_response","Ljavax/servlet/http/HttpServletResponse;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void m000__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/servlet/GzipFilter$GzipStream;","<init>",new String[]{ "Ljavax/servlet/http/HttpServletRequest;","Ljavax/servlet/http/HttpServletResponse;","J","I","I"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(7);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"request");
                ddv.visitParameterName(1,"response");
                ddv.visitParameterName(2,"contentLength");
                ddv.visitParameterName(3,"bufferSize");
                ddv.visitParameterName(4,"minGzipSize");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(366,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(367,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(368,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(369,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(370,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(371,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(372,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(373,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(374,L8);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljavax/servlet/ServletOutputStream;","<init>",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitFieldStmt(IPUT_OBJECT,1,0,new Field("Lorg/mortbay/servlet/GzipFilter$GzipStream;","_request","Ljavax/servlet/http/HttpServletRequest;"));
                code.visitLabel(L2);
                code.visitFieldStmt(IPUT_OBJECT,2,0,new Field("Lorg/mortbay/servlet/GzipFilter$GzipStream;","_response","Ljavax/servlet/http/HttpServletResponse;"));
                code.visitLabel(L3);
                code.visitFieldStmt(IPUT_WIDE,3,0,new Field("Lorg/mortbay/servlet/GzipFilter$GzipStream;","_contentLength","J"));
                code.visitLabel(L4);
                code.visitFieldStmt(IPUT,5,0,new Field("Lorg/mortbay/servlet/GzipFilter$GzipStream;","_bufferSize","I"));
                code.visitLabel(L5);
                code.visitFieldStmt(IPUT,6,0,new Field("Lorg/mortbay/servlet/GzipFilter$GzipStream;","_minGzipSize","I"));
                code.visitLabel(L6);
                code.visitJumpStmt(IF_NEZ,6,-1,L8);
                code.visitLabel(L7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/servlet/GzipFilter$GzipStream;","doGzip",new String[]{ },"V"));
                code.visitLabel(L8);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001_checkOut(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PRIVATE, new Method("Lorg/mortbay/servlet/GzipFilter$GzipStream;","checkOut",new String[]{ "I"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(6);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"length");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(517,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(519,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(520,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(523,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(525,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(526,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(539,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(527,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(528,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(530,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(532,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(534,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(535,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(536,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(537,L15);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_WIDE_16,2,Long.valueOf(0L)); // long: 0x0000000000000000  double:0.000000
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_BOOLEAN,0,4,new Field("Lorg/mortbay/servlet/GzipFilter$GzipStream;","_closed","Z"));
                code.visitJumpStmt(IF_EQZ,0,-1,L4);
                code.visitLabel(L2);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/lang/Throwable;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/lang/Throwable;","<init>",new String[]{ },"V"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/lang/Throwable;","printStackTrace",new String[]{ },"V"));
                code.visitLabel(L3);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/io/IOException;");
                code.visitConstStmt(CONST_STRING,1,"CLOSED");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1},new Method("Ljava/io/IOException;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitStmt1R(THROW,0);
                code.visitLabel(L4);
                code.visitFieldStmt(IGET_OBJECT,0,4,new Field("Lorg/mortbay/servlet/GzipFilter$GzipStream;","_out","Ljava/io/OutputStream;"));
                code.visitJumpStmt(IF_NEZ,0,-1,L11);
                code.visitLabel(L5);
                code.visitFieldStmt(IGET_OBJECT,0,4,new Field("Lorg/mortbay/servlet/GzipFilter$GzipStream;","_response","Ljavax/servlet/http/HttpServletResponse;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0},new Method("Ljavax/servlet/http/HttpServletResponse;","isCommitted",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_NEZ,0,-1,L6);
                code.visitFieldStmt(IGET_WIDE,0,4,new Field("Lorg/mortbay/servlet/GzipFilter$GzipStream;","_contentLength","J"));
                code.visitStmt3R(CMP_LONG,0,0,2);
                code.visitJumpStmt(IF_LTZ,0,-1,L8);
                code.visitFieldStmt(IGET_WIDE,0,4,new Field("Lorg/mortbay/servlet/GzipFilter$GzipStream;","_contentLength","J"));
                code.visitFieldStmt(IGET,2,4,new Field("Lorg/mortbay/servlet/GzipFilter$GzipStream;","_minGzipSize","I"));
                code.visitStmt2R(INT_TO_LONG,2,2);
                code.visitStmt3R(CMP_LONG,0,0,2);
                code.visitJumpStmt(IF_GEZ,0,-1,L8);
                code.visitLabel(L6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Lorg/mortbay/servlet/GzipFilter$GzipStream;","doNotGzip",new String[]{ },"V"));
                code.visitLabel(L7);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L8);
                code.visitFieldStmt(IGET,0,4,new Field("Lorg/mortbay/servlet/GzipFilter$GzipStream;","_minGzipSize","I"));
                code.visitJumpStmt(IF_LE,5,0,L10);
                code.visitLabel(L9);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Lorg/mortbay/servlet/GzipFilter$GzipStream;","doGzip",new String[]{ },"V"));
                code.visitJumpStmt(GOTO,-1,-1,L7);
                code.visitLabel(L10);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Lorg/mortbay/util/ByteArrayOutputStream2;");
                code.visitFieldStmt(IGET,1,4,new Field("Lorg/mortbay/servlet/GzipFilter$GzipStream;","_bufferSize","I"));
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1},new Method("Lorg/mortbay/util/ByteArrayOutputStream2;","<init>",new String[]{ "I"},"V"));
                code.visitFieldStmt(IPUT_OBJECT,0,4,new Field("Lorg/mortbay/servlet/GzipFilter$GzipStream;","_bOut","Lorg/mortbay/util/ByteArrayOutputStream2;"));
                code.visitFieldStmt(IPUT_OBJECT,0,4,new Field("Lorg/mortbay/servlet/GzipFilter$GzipStream;","_out","Ljava/io/OutputStream;"));
                code.visitJumpStmt(GOTO,-1,-1,L7);
                code.visitLabel(L11);
                code.visitFieldStmt(IGET_OBJECT,0,4,new Field("Lorg/mortbay/servlet/GzipFilter$GzipStream;","_bOut","Lorg/mortbay/util/ByteArrayOutputStream2;"));
                code.visitJumpStmt(IF_EQZ,0,-1,L7);
                code.visitLabel(L12);
                code.visitFieldStmt(IGET_OBJECT,0,4,new Field("Lorg/mortbay/servlet/GzipFilter$GzipStream;","_response","Ljavax/servlet/http/HttpServletResponse;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0},new Method("Ljavax/servlet/http/HttpServletResponse;","isCommitted",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_NEZ,0,-1,L13);
                code.visitFieldStmt(IGET_WIDE,0,4,new Field("Lorg/mortbay/servlet/GzipFilter$GzipStream;","_contentLength","J"));
                code.visitStmt3R(CMP_LONG,0,0,2);
                code.visitJumpStmt(IF_LTZ,0,-1,L14);
                code.visitFieldStmt(IGET_WIDE,0,4,new Field("Lorg/mortbay/servlet/GzipFilter$GzipStream;","_contentLength","J"));
                code.visitFieldStmt(IGET,2,4,new Field("Lorg/mortbay/servlet/GzipFilter$GzipStream;","_minGzipSize","I"));
                code.visitStmt2R(INT_TO_LONG,2,2);
                code.visitStmt3R(CMP_LONG,0,0,2);
                code.visitJumpStmt(IF_GEZ,0,-1,L14);
                code.visitLabel(L13);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Lorg/mortbay/servlet/GzipFilter$GzipStream;","doNotGzip",new String[]{ },"V"));
                code.visitJumpStmt(GOTO,-1,-1,L7);
                code.visitLabel(L14);
                code.visitFieldStmt(IGET_OBJECT,0,4,new Field("Lorg/mortbay/servlet/GzipFilter$GzipStream;","_bOut","Lorg/mortbay/util/ByteArrayOutputStream2;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/util/ByteArrayOutputStream2;","size",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitFieldStmt(IGET_OBJECT,1,4,new Field("Lorg/mortbay/servlet/GzipFilter$GzipStream;","_bOut","Lorg/mortbay/util/ByteArrayOutputStream2;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Lorg/mortbay/util/ByteArrayOutputStream2;","getCount",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitStmt2R(SUB_INT_2ADDR,0,1);
                code.visitJumpStmt(IF_LT,5,0,L7);
                code.visitLabel(L15);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Lorg/mortbay/servlet/GzipFilter$GzipStream;","doGzip",new String[]{ },"V"));
                code.visitJumpStmt(GOTO,-1,-1,L7);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m002_close(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/servlet/GzipFilter$GzipStream;","close",new String[]{ },"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(406,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(407,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(429,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(410,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(412,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(413,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(414,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(415,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(424,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(425,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(426,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(427,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(417,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(419,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(421,L14);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,4,new Field("Lorg/mortbay/servlet/GzipFilter$GzipStream;","_request","Ljavax/servlet/http/HttpServletRequest;"));
                code.visitConstStmt(CONST_STRING,1,"javax.servlet.include.request_uri");
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,1},new Method("Ljavax/servlet/http/HttpServletRequest;","getAttribute",new String[]{ "Ljava/lang/String;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitJumpStmt(IF_EQZ,0,-1,L3);
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Lorg/mortbay/servlet/GzipFilter$GzipStream;","flush",new String[]{ },"V"));
                code.visitLabel(L2);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,0,4,new Field("Lorg/mortbay/servlet/GzipFilter$GzipStream;","_bOut","Lorg/mortbay/util/ByteArrayOutputStream2;"));
                code.visitJumpStmt(IF_EQZ,0,-1,L13);
                code.visitLabel(L4);
                code.visitFieldStmt(IGET_WIDE,0,4,new Field("Lorg/mortbay/servlet/GzipFilter$GzipStream;","_contentLength","J"));
                code.visitConstStmt(CONST_WIDE_16,2,Long.valueOf(0L)); // long: 0x0000000000000000  double:0.000000
                code.visitStmt3R(CMP_LONG,0,0,2);
                code.visitJumpStmt(IF_GEZ,0,-1,L6);
                code.visitLabel(L5);
                code.visitFieldStmt(IGET_OBJECT,0,4,new Field("Lorg/mortbay/servlet/GzipFilter$GzipStream;","_bOut","Lorg/mortbay/util/ByteArrayOutputStream2;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/util/ByteArrayOutputStream2;","getCount",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitStmt2R(INT_TO_LONG,0,0);
                code.visitFieldStmt(IPUT_WIDE,0,4,new Field("Lorg/mortbay/servlet/GzipFilter$GzipStream;","_contentLength","J"));
                code.visitLabel(L6);
                code.visitFieldStmt(IGET_WIDE,0,4,new Field("Lorg/mortbay/servlet/GzipFilter$GzipStream;","_contentLength","J"));
                code.visitFieldStmt(IGET,2,4,new Field("Lorg/mortbay/servlet/GzipFilter$GzipStream;","_minGzipSize","I"));
                code.visitStmt2R(INT_TO_LONG,2,2);
                code.visitStmt3R(CMP_LONG,0,0,2);
                code.visitJumpStmt(IF_GEZ,0,-1,L12);
                code.visitLabel(L7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Lorg/mortbay/servlet/GzipFilter$GzipStream;","doNotGzip",new String[]{ },"V"));
                code.visitLabel(L8);
                code.visitFieldStmt(IGET_OBJECT,0,4,new Field("Lorg/mortbay/servlet/GzipFilter$GzipStream;","_gzOut","Ljava/util/zip/GZIPOutputStream;"));
                code.visitJumpStmt(IF_EQZ,0,-1,L10);
                code.visitLabel(L9);
                code.visitFieldStmt(IGET_OBJECT,0,4,new Field("Lorg/mortbay/servlet/GzipFilter$GzipStream;","_gzOut","Ljava/util/zip/GZIPOutputStream;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/util/zip/GZIPOutputStream;","finish",new String[]{ },"V"));
                code.visitLabel(L10);
                code.visitFieldStmt(IGET_OBJECT,0,4,new Field("Lorg/mortbay/servlet/GzipFilter$GzipStream;","_out","Ljava/io/OutputStream;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/io/OutputStream;","close",new String[]{ },"V"));
                code.visitLabel(L11);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitFieldStmt(IPUT_BOOLEAN,0,4,new Field("Lorg/mortbay/servlet/GzipFilter$GzipStream;","_closed","Z"));
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitLabel(L12);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Lorg/mortbay/servlet/GzipFilter$GzipStream;","doGzip",new String[]{ },"V"));
                code.visitJumpStmt(GOTO,-1,-1,L8);
                code.visitLabel(L13);
                code.visitFieldStmt(IGET_OBJECT,0,4,new Field("Lorg/mortbay/servlet/GzipFilter$GzipStream;","_out","Ljava/io/OutputStream;"));
                code.visitJumpStmt(IF_NEZ,0,-1,L8);
                code.visitLabel(L14);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Lorg/mortbay/servlet/GzipFilter$GzipStream;","doNotGzip",new String[]{ },"V"));
                code.visitJumpStmt(GOTO,-1,-1,L8);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m003_doGzip(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/servlet/GzipFilter$GzipStream;","doGzip",new String[]{ },"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(474,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(476,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(477,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(479,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(481,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(483,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(485,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(486,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(492,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(490,L9);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,4,new Field("Lorg/mortbay/servlet/GzipFilter$GzipStream;","_gzOut","Ljava/util/zip/GZIPOutputStream;"));
                code.visitJumpStmt(IF_NEZ,0,-1,L8);
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,0,4,new Field("Lorg/mortbay/servlet/GzipFilter$GzipStream;","_response","Ljavax/servlet/http/HttpServletResponse;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0},new Method("Ljavax/servlet/http/HttpServletResponse;","isCommitted",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_EQZ,0,-1,L3);
                code.visitLabel(L2);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/lang/IllegalStateException;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/lang/IllegalStateException;","<init>",new String[]{ },"V"));
                code.visitStmt1R(THROW,0);
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Lorg/mortbay/servlet/GzipFilter$GzipStream;","setContentEncodingGzip",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_EQZ,0,-1,L9);
                code.visitLabel(L4);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/util/zip/GZIPOutputStream;");
                code.visitFieldStmt(IGET_OBJECT,1,4,new Field("Lorg/mortbay/servlet/GzipFilter$GzipStream;","_response","Ljavax/servlet/http/HttpServletResponse;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 1},new Method("Ljavax/servlet/http/HttpServletResponse;","getOutputStream",new String[]{ },"Ljavax/servlet/ServletOutputStream;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitFieldStmt(IGET,2,4,new Field("Lorg/mortbay/servlet/GzipFilter$GzipStream;","_bufferSize","I"));
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1,2},new Method("Ljava/util/zip/GZIPOutputStream;","<init>",new String[]{ "Ljava/io/OutputStream;","I"},"V"));
                code.visitFieldStmt(IPUT_OBJECT,0,4,new Field("Lorg/mortbay/servlet/GzipFilter$GzipStream;","_gzOut","Ljava/util/zip/GZIPOutputStream;"));
                code.visitFieldStmt(IPUT_OBJECT,0,4,new Field("Lorg/mortbay/servlet/GzipFilter$GzipStream;","_out","Ljava/io/OutputStream;"));
                code.visitLabel(L5);
                code.visitFieldStmt(IGET_OBJECT,0,4,new Field("Lorg/mortbay/servlet/GzipFilter$GzipStream;","_bOut","Lorg/mortbay/util/ByteArrayOutputStream2;"));
                code.visitJumpStmt(IF_EQZ,0,-1,L8);
                code.visitLabel(L6);
                code.visitFieldStmt(IGET_OBJECT,0,4,new Field("Lorg/mortbay/servlet/GzipFilter$GzipStream;","_out","Ljava/io/OutputStream;"));
                code.visitFieldStmt(IGET_OBJECT,1,4,new Field("Lorg/mortbay/servlet/GzipFilter$GzipStream;","_bOut","Lorg/mortbay/util/ByteArrayOutputStream2;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Lorg/mortbay/util/ByteArrayOutputStream2;","getBuf",new String[]{ },"[B"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IGET_OBJECT,3,4,new Field("Lorg/mortbay/servlet/GzipFilter$GzipStream;","_bOut","Lorg/mortbay/util/ByteArrayOutputStream2;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Lorg/mortbay/util/ByteArrayOutputStream2;","getCount",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1,2,3},new Method("Ljava/io/OutputStream;","write",new String[]{ "[B","I","I"},"V"));
                code.visitLabel(L7);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT_OBJECT,0,4,new Field("Lorg/mortbay/servlet/GzipFilter$GzipStream;","_bOut","Lorg/mortbay/util/ByteArrayOutputStream2;"));
                code.visitLabel(L8);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L9);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Lorg/mortbay/servlet/GzipFilter$GzipStream;","doNotGzip",new String[]{ },"V"));
                code.visitJumpStmt(GOTO,-1,-1,L8);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m004_doNotGzip(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/servlet/GzipFilter$GzipStream;","doNotGzip",new String[]{ },"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(496,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(497,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(498,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(500,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(501,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(503,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(504,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(509,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(510,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(511,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(513,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(506,L11);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,4,new Field("Lorg/mortbay/servlet/GzipFilter$GzipStream;","_gzOut","Ljava/util/zip/GZIPOutputStream;"));
                code.visitJumpStmt(IF_EQZ,0,-1,L2);
                code.visitLabel(L1);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/lang/IllegalStateException;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/lang/IllegalStateException;","<init>",new String[]{ },"V"));
                code.visitStmt1R(THROW,0);
                code.visitLabel(L2);
                code.visitFieldStmt(IGET_OBJECT,0,4,new Field("Lorg/mortbay/servlet/GzipFilter$GzipStream;","_out","Ljava/io/OutputStream;"));
                code.visitJumpStmt(IF_EQZ,0,-1,L3);
                code.visitFieldStmt(IGET_OBJECT,0,4,new Field("Lorg/mortbay/servlet/GzipFilter$GzipStream;","_bOut","Lorg/mortbay/util/ByteArrayOutputStream2;"));
                code.visitJumpStmt(IF_EQZ,0,-1,L10);
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,0,4,new Field("Lorg/mortbay/servlet/GzipFilter$GzipStream;","_response","Ljavax/servlet/http/HttpServletResponse;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0},new Method("Ljavax/servlet/http/HttpServletResponse;","getOutputStream",new String[]{ },"Ljavax/servlet/ServletOutputStream;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(IPUT_OBJECT,0,4,new Field("Lorg/mortbay/servlet/GzipFilter$GzipStream;","_out","Ljava/io/OutputStream;"));
                code.visitLabel(L4);
                code.visitFieldStmt(IGET_WIDE,0,4,new Field("Lorg/mortbay/servlet/GzipFilter$GzipStream;","_contentLength","J"));
                code.visitConstStmt(CONST_WIDE_16,2,Long.valueOf(0L)); // long: 0x0000000000000000  double:0.000000
                code.visitStmt3R(CMP_LONG,0,0,2);
                code.visitJumpStmt(IF_LTZ,0,-1,L7);
                code.visitLabel(L5);
                code.visitFieldStmt(IGET_WIDE,0,4,new Field("Lorg/mortbay/servlet/GzipFilter$GzipStream;","_contentLength","J"));
                code.visitConstStmt(CONST_WIDE_32,2,Long.valueOf(2147483647L)); // long: 0x000000007fffffff  double:0.000000
                code.visitStmt3R(CMP_LONG,0,0,2);
                code.visitJumpStmt(IF_GEZ,0,-1,L11);
                code.visitLabel(L6);
                code.visitFieldStmt(IGET_OBJECT,0,4,new Field("Lorg/mortbay/servlet/GzipFilter$GzipStream;","_response","Ljavax/servlet/http/HttpServletResponse;"));
                code.visitFieldStmt(IGET_WIDE,1,4,new Field("Lorg/mortbay/servlet/GzipFilter$GzipStream;","_contentLength","J"));
                code.visitStmt2R(LONG_TO_INT,1,1);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,1},new Method("Ljavax/servlet/http/HttpServletResponse;","setContentLength",new String[]{ "I"},"V"));
                code.visitLabel(L7);
                code.visitFieldStmt(IGET_OBJECT,0,4,new Field("Lorg/mortbay/servlet/GzipFilter$GzipStream;","_bOut","Lorg/mortbay/util/ByteArrayOutputStream2;"));
                code.visitJumpStmt(IF_EQZ,0,-1,L9);
                code.visitLabel(L8);
                code.visitFieldStmt(IGET_OBJECT,0,4,new Field("Lorg/mortbay/servlet/GzipFilter$GzipStream;","_out","Ljava/io/OutputStream;"));
                code.visitFieldStmt(IGET_OBJECT,1,4,new Field("Lorg/mortbay/servlet/GzipFilter$GzipStream;","_bOut","Lorg/mortbay/util/ByteArrayOutputStream2;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Lorg/mortbay/util/ByteArrayOutputStream2;","getBuf",new String[]{ },"[B"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IGET_OBJECT,3,4,new Field("Lorg/mortbay/servlet/GzipFilter$GzipStream;","_bOut","Lorg/mortbay/util/ByteArrayOutputStream2;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Lorg/mortbay/util/ByteArrayOutputStream2;","getCount",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1,2,3},new Method("Ljava/io/OutputStream;","write",new String[]{ "[B","I","I"},"V"));
                code.visitLabel(L9);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT_OBJECT,0,4,new Field("Lorg/mortbay/servlet/GzipFilter$GzipStream;","_bOut","Lorg/mortbay/util/ByteArrayOutputStream2;"));
                code.visitLabel(L10);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L11);
                code.visitFieldStmt(IGET_OBJECT,0,4,new Field("Lorg/mortbay/servlet/GzipFilter$GzipStream;","_response","Ljavax/servlet/http/HttpServletResponse;"));
                code.visitConstStmt(CONST_STRING,1,"Content-Length");
                code.visitFieldStmt(IGET_WIDE,2,4,new Field("Lorg/mortbay/servlet/GzipFilter$GzipStream;","_contentLength","J"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 2,3},new Method("Ljava/lang/Long;","toString",new String[]{ "J"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,1,2},new Method("Ljavax/servlet/http/HttpServletResponse;","setHeader",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L7);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m005_finish(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/servlet/GzipFilter$GzipStream;","finish",new String[]{ },"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(433,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(435,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(437,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(438,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(443,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(444,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(446,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(440,L7);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_BOOLEAN,0,4,new Field("Lorg/mortbay/servlet/GzipFilter$GzipStream;","_closed","Z"));
                code.visitJumpStmt(IF_NEZ,0,-1,L6);
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,0,4,new Field("Lorg/mortbay/servlet/GzipFilter$GzipStream;","_out","Ljava/io/OutputStream;"));
                code.visitJumpStmt(IF_EQZ,0,-1,L2);
                code.visitFieldStmt(IGET_OBJECT,0,4,new Field("Lorg/mortbay/servlet/GzipFilter$GzipStream;","_bOut","Lorg/mortbay/util/ByteArrayOutputStream2;"));
                code.visitJumpStmt(IF_EQZ,0,-1,L4);
                code.visitLabel(L2);
                code.visitFieldStmt(IGET_WIDE,0,4,new Field("Lorg/mortbay/servlet/GzipFilter$GzipStream;","_contentLength","J"));
                code.visitConstStmt(CONST_WIDE_16,2,Long.valueOf(0L)); // long: 0x0000000000000000  double:0.000000
                code.visitStmt3R(CMP_LONG,0,0,2);
                code.visitJumpStmt(IF_LEZ,0,-1,L7);
                code.visitFieldStmt(IGET_WIDE,0,4,new Field("Lorg/mortbay/servlet/GzipFilter$GzipStream;","_contentLength","J"));
                code.visitFieldStmt(IGET,2,4,new Field("Lorg/mortbay/servlet/GzipFilter$GzipStream;","_minGzipSize","I"));
                code.visitStmt2R(INT_TO_LONG,2,2);
                code.visitStmt3R(CMP_LONG,0,0,2);
                code.visitJumpStmt(IF_GEZ,0,-1,L7);
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Lorg/mortbay/servlet/GzipFilter$GzipStream;","doNotGzip",new String[]{ },"V"));
                code.visitLabel(L4);
                code.visitFieldStmt(IGET_OBJECT,0,4,new Field("Lorg/mortbay/servlet/GzipFilter$GzipStream;","_gzOut","Ljava/util/zip/GZIPOutputStream;"));
                code.visitJumpStmt(IF_EQZ,0,-1,L6);
                code.visitLabel(L5);
                code.visitFieldStmt(IGET_OBJECT,0,4,new Field("Lorg/mortbay/servlet/GzipFilter$GzipStream;","_gzOut","Ljava/util/zip/GZIPOutputStream;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/util/zip/GZIPOutputStream;","finish",new String[]{ },"V"));
                code.visitLabel(L6);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Lorg/mortbay/servlet/GzipFilter$GzipStream;","doGzip",new String[]{ },"V"));
                code.visitJumpStmt(GOTO,-1,-1,L4);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m006_flush(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/servlet/GzipFilter$GzipStream;","flush",new String[]{ },"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(393,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(395,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(396,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(401,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(402,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(398,L5);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,4,new Field("Lorg/mortbay/servlet/GzipFilter$GzipStream;","_out","Ljava/io/OutputStream;"));
                code.visitJumpStmt(IF_EQZ,0,-1,L1);
                code.visitFieldStmt(IGET_OBJECT,0,4,new Field("Lorg/mortbay/servlet/GzipFilter$GzipStream;","_bOut","Lorg/mortbay/util/ByteArrayOutputStream2;"));
                code.visitJumpStmt(IF_EQZ,0,-1,L3);
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_WIDE,0,4,new Field("Lorg/mortbay/servlet/GzipFilter$GzipStream;","_contentLength","J"));
                code.visitConstStmt(CONST_WIDE_16,2,Long.valueOf(0L)); // long: 0x0000000000000000  double:0.000000
                code.visitStmt3R(CMP_LONG,0,0,2);
                code.visitJumpStmt(IF_LEZ,0,-1,L5);
                code.visitFieldStmt(IGET_WIDE,0,4,new Field("Lorg/mortbay/servlet/GzipFilter$GzipStream;","_contentLength","J"));
                code.visitFieldStmt(IGET,2,4,new Field("Lorg/mortbay/servlet/GzipFilter$GzipStream;","_minGzipSize","I"));
                code.visitStmt2R(INT_TO_LONG,2,2);
                code.visitStmt3R(CMP_LONG,0,0,2);
                code.visitJumpStmt(IF_GEZ,0,-1,L5);
                code.visitLabel(L2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Lorg/mortbay/servlet/GzipFilter$GzipStream;","doNotGzip",new String[]{ },"V"));
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,0,4,new Field("Lorg/mortbay/servlet/GzipFilter$GzipStream;","_out","Ljava/io/OutputStream;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/io/OutputStream;","flush",new String[]{ },"V"));
                code.visitLabel(L4);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Lorg/mortbay/servlet/GzipFilter$GzipStream;","doGzip",new String[]{ },"V"));
                code.visitJumpStmt(GOTO,-1,-1,L3);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m007_resetBuffer(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/servlet/GzipFilter$GzipStream;","resetBuffer",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(378,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(379,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(380,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(381,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(382,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(383,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(384,L7);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT_BOOLEAN,0,3,new Field("Lorg/mortbay/servlet/GzipFilter$GzipStream;","_closed","Z"));
                code.visitLabel(L2);
                code.visitFieldStmt(IPUT_OBJECT,2,3,new Field("Lorg/mortbay/servlet/GzipFilter$GzipStream;","_out","Ljava/io/OutputStream;"));
                code.visitLabel(L3);
                code.visitFieldStmt(IPUT_OBJECT,2,3,new Field("Lorg/mortbay/servlet/GzipFilter$GzipStream;","_bOut","Lorg/mortbay/util/ByteArrayOutputStream2;"));
                code.visitLabel(L4);
                code.visitFieldStmt(IGET_OBJECT,0,3,new Field("Lorg/mortbay/servlet/GzipFilter$GzipStream;","_gzOut","Ljava/util/zip/GZIPOutputStream;"));
                code.visitJumpStmt(IF_EQZ,0,-1,L6);
                code.visitFieldStmt(IGET_OBJECT,0,3,new Field("Lorg/mortbay/servlet/GzipFilter$GzipStream;","_response","Ljavax/servlet/http/HttpServletResponse;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0},new Method("Ljavax/servlet/http/HttpServletResponse;","isCommitted",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_NEZ,0,-1,L6);
                code.visitLabel(L5);
                code.visitFieldStmt(IGET_OBJECT,0,3,new Field("Lorg/mortbay/servlet/GzipFilter$GzipStream;","_response","Ljavax/servlet/http/HttpServletResponse;"));
                code.visitConstStmt(CONST_STRING,1,"Content-Encoding");
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,1,2},new Method("Ljavax/servlet/http/HttpServletResponse;","setHeader",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"V"));
                code.visitLabel(L6);
                code.visitFieldStmt(IPUT_OBJECT,2,3,new Field("Lorg/mortbay/servlet/GzipFilter$GzipStream;","_gzOut","Ljava/util/zip/GZIPOutputStream;"));
                code.visitLabel(L7);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m008_setContentEncodingGzip(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Lorg/mortbay/servlet/GzipFilter$GzipStream;","setContentEncodingGzip",new String[]{ },"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(468,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(469,L2);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_STRING,2,"Content-Encoding");
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,0,3,new Field("Lorg/mortbay/servlet/GzipFilter$GzipStream;","_response","Ljavax/servlet/http/HttpServletResponse;"));
                code.visitConstStmt(CONST_STRING,1,"Content-Encoding");
                code.visitConstStmt(CONST_STRING,1,"gzip");
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,2,1},new Method("Ljavax/servlet/http/HttpServletResponse;","setHeader",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"V"));
                code.visitLabel(L2);
                code.visitFieldStmt(IGET_OBJECT,0,3,new Field("Lorg/mortbay/servlet/GzipFilter$GzipStream;","_response","Ljavax/servlet/http/HttpServletResponse;"));
                code.visitConstStmt(CONST_STRING,1,"Content-Encoding");
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,2},new Method("Ljavax/servlet/http/HttpServletResponse;","containsHeader",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m009_setContentLength(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/servlet/GzipFilter$GzipStream;","setContentLength",new String[]{ "J"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"length");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(388,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(389,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_WIDE,1,0,new Field("Lorg/mortbay/servlet/GzipFilter$GzipStream;","_contentLength","J"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m010_write(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/servlet/GzipFilter$GzipStream;","write",new String[]{ "I"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"b");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(450,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(451,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(452,L2);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1,0},new Method("Lorg/mortbay/servlet/GzipFilter$GzipStream;","checkOut",new String[]{ "I"},"V"));
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/servlet/GzipFilter$GzipStream;","_out","Ljava/io/OutputStream;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,2},new Method("Ljava/io/OutputStream;","write",new String[]{ "I"},"V"));
                code.visitLabel(L2);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m011_write(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/servlet/GzipFilter$GzipStream;","write",new String[]{ "[B"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"b");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(456,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(457,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(458,L2);
                code.visitLabel(L0);
                code.visitStmt2R(ARRAY_LENGTH,0,2);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1,0},new Method("Lorg/mortbay/servlet/GzipFilter$GzipStream;","checkOut",new String[]{ "I"},"V"));
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/servlet/GzipFilter$GzipStream;","_out","Ljava/io/OutputStream;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,2},new Method("Ljava/io/OutputStream;","write",new String[]{ "[B"},"V"));
                code.visitLabel(L2);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m012_write(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/servlet/GzipFilter$GzipStream;","write",new String[]{ "[B","I","I"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"b");
                ddv.visitParameterName(1,"off");
                ddv.visitParameterName(2,"len");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(462,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(463,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(464,L2);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1,4},new Method("Lorg/mortbay/servlet/GzipFilter$GzipStream;","checkOut",new String[]{ "I"},"V"));
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/servlet/GzipFilter$GzipStream;","_out","Ljava/io/OutputStream;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,2,3,4},new Method("Ljava/io/OutputStream;","write",new String[]{ "[B","I","I"},"V"));
                code.visitLabel(L2);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
