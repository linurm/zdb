package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0257_org_mortbay_jetty_handler_StatisticsHandler {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(ACC_PUBLIC,"Lorg/mortbay/jetty/handler/StatisticsHandler;","Lorg/mortbay/jetty/handler/HandlerWrapper;",new String[]{ });
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("StatisticsHandler.java");
        f000__requests(cv);
        f001__requestsActive(cv);
        f002__requestsActiveMax(cv);
        f003__requestsActiveMin(cv);
        f004__requestsDurationMax(cv);
        f005__requestsDurationMin(cv);
        f006__requestsDurationTotal(cv);
        f007__responses1xx(cv);
        f008__responses2xx(cv);
        f009__responses3xx(cv);
        f010__responses4xx(cv);
        f011__responses5xx(cv);
        f012__statsStartedAt(cv);
        m000__init_(cv);
        m001_doStart(cv);
        m002_doStop(cv);
        m003_getRequests(cv);
        m004_getRequestsActive(cv);
        m005_getRequestsActiveMax(cv);
        m006_getRequestsActiveMin(cv);
        m007_getRequestsDurationAve(cv);
        m008_getRequestsDurationMax(cv);
        m009_getRequestsDurationMin(cv);
        m010_getRequestsDurationTotal(cv);
        m011_getResponses1xx(cv);
        m012_getResponses2xx(cv);
        m013_getResponses3xx(cv);
        m014_getResponses4xx(cv);
        m015_getResponses5xx(cv);
        m016_getStatsOnMs(cv);
        m017_handle(cv);
        m018_statsReset(cv);
    }
    public static void f000__requests(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_TRANSIENT, new Field("Lorg/mortbay/jetty/handler/StatisticsHandler;","_requests","I"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f001__requestsActive(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_TRANSIENT, new Field("Lorg/mortbay/jetty/handler/StatisticsHandler;","_requestsActive","I"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f002__requestsActiveMax(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_TRANSIENT, new Field("Lorg/mortbay/jetty/handler/StatisticsHandler;","_requestsActiveMax","I"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f003__requestsActiveMin(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_TRANSIENT, new Field("Lorg/mortbay/jetty/handler/StatisticsHandler;","_requestsActiveMin","I"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f004__requestsDurationMax(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_TRANSIENT, new Field("Lorg/mortbay/jetty/handler/StatisticsHandler;","_requestsDurationMax","J"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f005__requestsDurationMin(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_TRANSIENT, new Field("Lorg/mortbay/jetty/handler/StatisticsHandler;","_requestsDurationMin","J"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f006__requestsDurationTotal(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_TRANSIENT, new Field("Lorg/mortbay/jetty/handler/StatisticsHandler;","_requestsDurationTotal","J"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f007__responses1xx(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_TRANSIENT, new Field("Lorg/mortbay/jetty/handler/StatisticsHandler;","_responses1xx","I"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f008__responses2xx(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_TRANSIENT, new Field("Lorg/mortbay/jetty/handler/StatisticsHandler;","_responses2xx","I"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f009__responses3xx(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_TRANSIENT, new Field("Lorg/mortbay/jetty/handler/StatisticsHandler;","_responses3xx","I"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f010__responses4xx(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_TRANSIENT, new Field("Lorg/mortbay/jetty/handler/StatisticsHandler;","_responses4xx","I"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f011__responses5xx(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_TRANSIENT, new Field("Lorg/mortbay/jetty/handler/StatisticsHandler;","_responses5xx","I"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f012__statsStartedAt(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_TRANSIENT, new Field("Lorg/mortbay/jetty/handler/StatisticsHandler;","_statsStartedAt","J"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void m000__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/jetty/handler/StatisticsHandler;","<init>",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(1);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(27,L0);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Lorg/mortbay/jetty/handler/HandlerWrapper;","<init>",new String[]{ },"V"));
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001_doStart(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Lorg/mortbay/jetty/handler/StatisticsHandler;","doStart",new String[]{ },"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/lang/Exception;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(125,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(126,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(127,L2);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_SUPER,new int[]{ 2},new Method("Lorg/mortbay/jetty/handler/HandlerWrapper;","doStart",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Ljava/lang/System;","currentTimeMillis",new String[]{ },"J"));
                code.visitStmt1R(MOVE_RESULT_WIDE,0);
                code.visitFieldStmt(IPUT_WIDE,0,2,new Field("Lorg/mortbay/jetty/handler/StatisticsHandler;","_statsStartedAt","J"));
                code.visitLabel(L2);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m002_doStop(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Lorg/mortbay/jetty/handler/StatisticsHandler;","doStop",new String[]{ },"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/lang/Exception;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(1);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(132,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(133,L1);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_SUPER,new int[]{ 0},new Method("Lorg/mortbay/jetty/handler/HandlerWrapper;","doStop",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m003_getRequests(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/handler/StatisticsHandler;","getRequests",new String[]{ },"I"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(141,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET,0,1,new Field("Lorg/mortbay/jetty/handler/StatisticsHandler;","_requests","I"));
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m004_getRequestsActive(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/handler/StatisticsHandler;","getRequestsActive",new String[]{ },"I"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(148,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET,0,1,new Field("Lorg/mortbay/jetty/handler/StatisticsHandler;","_requestsActive","I"));
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m005_getRequestsActiveMax(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/handler/StatisticsHandler;","getRequestsActiveMax",new String[]{ },"I"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(155,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET,0,1,new Field("Lorg/mortbay/jetty/handler/StatisticsHandler;","_requestsActiveMax","I"));
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m006_getRequestsActiveMin(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/handler/StatisticsHandler;","getRequestsActiveMin",new String[]{ },"I"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(212,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET,0,1,new Field("Lorg/mortbay/jetty/handler/StatisticsHandler;","_requestsActiveMin","I"));
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m007_getRequestsDurationAve(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/handler/StatisticsHandler;","getRequestsDurationAve",new String[]{ },"J"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(238,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET,0,4,new Field("Lorg/mortbay/jetty/handler/StatisticsHandler;","_requests","I"));
                DexLabel L1=new DexLabel();
                code.visitJumpStmt(IF_NEZ,0,-1,L1);
                code.visitConstStmt(CONST_WIDE_16,0,Long.valueOf(0L)); // long: 0x0000000000000000  double:0.000000
                DexLabel L2=new DexLabel();
                code.visitLabel(L2);
                code.visitStmt1R(RETURN_WIDE,0);
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_WIDE,0,4,new Field("Lorg/mortbay/jetty/handler/StatisticsHandler;","_requestsDurationTotal","J"));
                code.visitFieldStmt(IGET,2,4,new Field("Lorg/mortbay/jetty/handler/StatisticsHandler;","_requests","I"));
                code.visitStmt2R(INT_TO_LONG,2,2);
                code.visitStmt2R(DIV_LONG_2ADDR,0,2);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m008_getRequestsDurationMax(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/handler/StatisticsHandler;","getRequestsDurationMax",new String[]{ },"J"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(245,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_WIDE,0,2,new Field("Lorg/mortbay/jetty/handler/StatisticsHandler;","_requestsDurationMax","J"));
                code.visitStmt1R(RETURN_WIDE,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m009_getRequestsDurationMin(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/handler/StatisticsHandler;","getRequestsDurationMin",new String[]{ },"J"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(221,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_WIDE,0,2,new Field("Lorg/mortbay/jetty/handler/StatisticsHandler;","_requestsDurationMin","J"));
                code.visitStmt1R(RETURN_WIDE,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m010_getRequestsDurationTotal(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/handler/StatisticsHandler;","getRequestsDurationTotal",new String[]{ },"J"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(230,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_WIDE,0,2,new Field("Lorg/mortbay/jetty/handler/StatisticsHandler;","_requestsDurationTotal","J"));
                code.visitStmt1R(RETURN_WIDE,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m011_getResponses1xx(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/handler/StatisticsHandler;","getResponses1xx",new String[]{ },"I"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(163,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET,0,1,new Field("Lorg/mortbay/jetty/handler/StatisticsHandler;","_responses1xx","I"));
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m012_getResponses2xx(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/handler/StatisticsHandler;","getResponses2xx",new String[]{ },"I"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(171,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET,0,1,new Field("Lorg/mortbay/jetty/handler/StatisticsHandler;","_responses2xx","I"));
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m013_getResponses3xx(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/handler/StatisticsHandler;","getResponses3xx",new String[]{ },"I"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(179,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET,0,1,new Field("Lorg/mortbay/jetty/handler/StatisticsHandler;","_responses3xx","I"));
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m014_getResponses4xx(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/handler/StatisticsHandler;","getResponses4xx",new String[]{ },"I"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(187,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET,0,1,new Field("Lorg/mortbay/jetty/handler/StatisticsHandler;","_responses4xx","I"));
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m015_getResponses5xx(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/handler/StatisticsHandler;","getResponses5xx",new String[]{ },"I"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(195,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET,0,1,new Field("Lorg/mortbay/jetty/handler/StatisticsHandler;","_responses5xx","I"));
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m016_getStatsOnMs(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/handler/StatisticsHandler;","getStatsOnMs",new String[]{ },"J"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(203,L0);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Ljava/lang/System;","currentTimeMillis",new String[]{ },"J"));
                code.visitStmt1R(MOVE_RESULT_WIDE,0);
                code.visitFieldStmt(IGET_WIDE,2,4,new Field("Lorg/mortbay/jetty/handler/StatisticsHandler;","_statsStartedAt","J"));
                code.visitStmt2R(SUB_LONG_2ADDR,0,2);
                code.visitStmt1R(RETURN_WIDE,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m017_handle(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/handler/StatisticsHandler;","handle",new String[]{ "Ljava/lang/String;","Ljavax/servlet/http/HttpServletRequest;","Ljavax/servlet/http/HttpServletResponse;","I"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visit(null, new DexType("Ljavax/servlet/ServletException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(17);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexLabel L3=new DexLabel();
                DexLabel L4=new DexLabel();
                code.visitTryCatch(L1,L3,new DexLabel[]{L4},new String[]{ null});
                DexLabel L5=new DexLabel();
                code.visitTryCatch(L3,L5,new DexLabel[]{L2},new String[]{ null});
                DexLabel L6=new DexLabel();
                DexLabel L7=new DexLabel();
                DexLabel L8=new DexLabel();
                code.visitTryCatch(L6,L7,new DexLabel[]{L8},new String[]{ null});
                DexLabel L9=new DexLabel();
                DexLabel L10=new DexLabel();
                code.visitTryCatch(L9,L10,new DexLabel[]{L4},new String[]{ null});
                code.visitTryCatch(L10,L2,new DexLabel[]{L2},new String[]{ null});
                DexLabel L11=new DexLabel();
                DexLabel L12=new DexLabel();
                DexLabel L13=new DexLabel();
                code.visitTryCatch(L11,L12,new DexLabel[]{L13},new String[]{ null});
                DexLabel L14=new DexLabel();
                DexLabel L15=new DexLabel();
                code.visitTryCatch(L14,L15,new DexLabel[]{L13},new String[]{ null});
                DexLabel L16=new DexLabel();
                DexLabel L17=new DexLabel();
                code.visitTryCatch(L16,L17,new DexLabel[]{L13},new String[]{ null});
                DexLabel L18=new DexLabel();
                DexLabel L19=new DexLabel();
                code.visitTryCatch(L18,L19,new DexLabel[]{L8},new String[]{ null});
                DexLabel L20=new DexLabel();
                DexLabel L21=new DexLabel();
                code.visitTryCatch(L20,L21,new DexLabel[]{L8},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"target");
                ddv.visitParameterName(1,"request");
                ddv.visitParameterName(2,"response");
                ddv.visitParameterName(3,"dispatch");
                DexLabel L22=new DexLabel();
                ddv.visitPrologue(L22);
                DexLabel L23=new DexLabel();
                ddv.visitLineNumber(76,L23);
                DexLabel L24=new DexLabel();
                ddv.visitLineNumber(77,L24);
                ddv.visitStartLocal(1,L24,"base_request","Lorg/mortbay/jetty/Request;",null);
                ddv.visitLineNumber(81,L0);
                ddv.visitStartLocal(2,L0,"base_response","Lorg/mortbay/jetty/Response;",null);
                ddv.visitLineNumber(83,L1);
                DexLabel L25=new DexLabel();
                ddv.visitLineNumber(84,L25);
                DexLabel L26=new DexLabel();
                ddv.visitLineNumber(85,L26);
                DexLabel L27=new DexLabel();
                ddv.visitLineNumber(86,L27);
                DexLabel L28=new DexLabel();
                ddv.visitLineNumber(87,L28);
                ddv.visitLineNumber(89,L3);
                ddv.visitLineNumber(93,L5);
                ddv.visitLineNumber(95,L6);
                DexLabel L29=new DexLabel();
                ddv.visitLineNumber(96,L29);
                DexLabel L30=new DexLabel();
                ddv.visitLineNumber(97,L30);
                DexLabel L31=new DexLabel();
                ddv.visitLineNumber(98,L31);
                DexLabel L32=new DexLabel();
                ddv.visitLineNumber(99,L32);
                DexLabel L33=new DexLabel();
                ddv.visitLineNumber(101,L33);
                DexLabel L34=new DexLabel();
                ddv.visitLineNumber(103,L34);
                ddv.visitStartLocal(3,L34,"duration","J",null);
                DexLabel L35=new DexLabel();
                ddv.visitLineNumber(104,L35);
                DexLabel L36=new DexLabel();
                ddv.visitLineNumber(105,L36);
                DexLabel L37=new DexLabel();
                ddv.visitLineNumber(106,L37);
                DexLabel L38=new DexLabel();
                ddv.visitLineNumber(107,L38);
                DexLabel L39=new DexLabel();
                ddv.visitLineNumber(109,L39);
                DexLabel L40=new DexLabel();
                ddv.visitLineNumber(118,L40);
                ddv.visitLineNumber(120,L7);
                DexLabel L41=new DexLabel();
                ddv.visitLineNumber(76,L41);
                ddv.visitEndLocal(1,L41);
                ddv.visitEndLocal(2,L41);
                ddv.visitEndLocal(3,L41);
                DexLabel L42=new DexLabel();
                ddv.visitLineNumber(77,L42);
                ddv.visitRestartLocal(1,L42);
                ddv.visitLineNumber(87,L4);
                ddv.visitRestartLocal(2,L4);
                ddv.visitLineNumber(93,L2);
                ddv.visitLineNumber(95,L11);
                DexLabel L43=new DexLabel();
                ddv.visitLineNumber(96,L43);
                DexLabel L44=new DexLabel();
                ddv.visitLineNumber(97,L44);
                DexLabel L45=new DexLabel();
                ddv.visitLineNumber(98,L45);
                DexLabel L46=new DexLabel();
                ddv.visitLineNumber(99,L46);
                DexLabel L47=new DexLabel();
                ddv.visitLineNumber(101,L47);
                DexLabel L48=new DexLabel();
                ddv.visitLineNumber(103,L48);
                ddv.visitRestartLocal(3,L48);
                DexLabel L49=new DexLabel();
                ddv.visitLineNumber(104,L49);
                DexLabel L50=new DexLabel();
                ddv.visitLineNumber(105,L50);
                DexLabel L51=new DexLabel();
                ddv.visitLineNumber(106,L51);
                DexLabel L52=new DexLabel();
                ddv.visitLineNumber(107,L52);
                DexLabel L53=new DexLabel();
                ddv.visitLineNumber(109,L53);
                DexLabel L54=new DexLabel();
                ddv.visitLineNumber(118,L54);
                ddv.visitLineNumber(93,L12);
                ddv.visitLineNumber(118,L13);
                ddv.visitEndLocal(3,L13);
                ddv.visitLineNumber(111,L16);
                ddv.visitRestartLocal(3,L16);
                DexLabel L55=new DexLabel();
                ddv.visitLineNumber(112,L55);
                DexLabel L56=new DexLabel();
                ddv.visitLineNumber(113,L56);
                DexLabel L57=new DexLabel();
                ddv.visitLineNumber(114,L57);
                DexLabel L58=new DexLabel();
                ddv.visitLineNumber(115,L58);
                ddv.visitLineNumber(118,L8);
                ddv.visitEndLocal(3,L8);
                ddv.visitLineNumber(111,L20);
                ddv.visitRestartLocal(3,L20);
                DexLabel L59=new DexLabel();
                ddv.visitLineNumber(112,L59);
                DexLabel L60=new DexLabel();
                ddv.visitLineNumber(113,L60);
                DexLabel L61=new DexLabel();
                ddv.visitLineNumber(114,L61);
                DexLabel L62=new DexLabel();
                ddv.visitLineNumber(115,L62);
                DexLabel L63=new DexLabel();
                ddv.visitLineNumber(109,L63);
                code.visitLabel(L22);
                code.visitConstStmt(CONST_WIDE_16,10,Long.valueOf(0L)); // long: 0x0000000000000000  double:0.000000
                code.visitConstStmt(CONST_4,7, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitLabel(L23);
                code.visitTypeStmt(INSTANCE_OF,5,14,"Lorg/mortbay/jetty/Request;");
                code.visitJumpStmt(IF_EQZ,5,-1,L41);
                code.visitStmt2R(MOVE_OBJECT,0,14);
                code.visitTypeStmt(CHECK_CAST,0,-1,"Lorg/mortbay/jetty/Request;");
                code.visitStmt2R(MOVE_OBJECT,5,0);
                code.visitStmt2R(MOVE_OBJECT,1,5);
                code.visitLabel(L24);
                code.visitTypeStmt(INSTANCE_OF,5,15,"Lorg/mortbay/jetty/Response;");
                code.visitJumpStmt(IF_EQZ,5,-1,L42);
                code.visitStmt2R(MOVE_OBJECT,0,15);
                code.visitTypeStmt(CHECK_CAST,0,-1,"Lorg/mortbay/jetty/Response;");
                code.visitStmt2R(MOVE_OBJECT,5,0);
                code.visitStmt2R(MOVE_OBJECT,2,5);
                code.visitLabel(L0);
                code.visitStmt1R(MONITOR_ENTER,12);
                code.visitLabel(L1);
                code.visitFieldStmt(IGET,5,12,new Field("Lorg/mortbay/jetty/handler/StatisticsHandler;","_requests","I"));
                code.visitStmt2R1N(ADD_INT_LIT8,5,5,1);
                code.visitFieldStmt(IPUT,5,12,new Field("Lorg/mortbay/jetty/handler/StatisticsHandler;","_requests","I"));
                code.visitLabel(L25);
                code.visitFieldStmt(IGET,5,12,new Field("Lorg/mortbay/jetty/handler/StatisticsHandler;","_requestsActive","I"));
                code.visitStmt2R1N(ADD_INT_LIT8,5,5,1);
                code.visitFieldStmt(IPUT,5,12,new Field("Lorg/mortbay/jetty/handler/StatisticsHandler;","_requestsActive","I"));
                code.visitLabel(L26);
                code.visitFieldStmt(IGET,5,12,new Field("Lorg/mortbay/jetty/handler/StatisticsHandler;","_requestsActive","I"));
                code.visitFieldStmt(IGET,6,12,new Field("Lorg/mortbay/jetty/handler/StatisticsHandler;","_requestsActiveMax","I"));
                code.visitJumpStmt(IF_LE,5,6,L28);
                code.visitLabel(L27);
                code.visitFieldStmt(IGET,5,12,new Field("Lorg/mortbay/jetty/handler/StatisticsHandler;","_requestsActive","I"));
                code.visitFieldStmt(IPUT,5,12,new Field("Lorg/mortbay/jetty/handler/StatisticsHandler;","_requestsActiveMax","I"));
                code.visitLabel(L28);
                code.visitStmt1R(MONITOR_EXIT,12);
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_SUPER_RANGE,new int[]{ 12,13,14,15,16},new Method("Lorg/mortbay/jetty/handler/HandlerWrapper;","handle",new String[]{ "Ljava/lang/String;","Ljavax/servlet/http/HttpServletRequest;","Ljavax/servlet/http/HttpServletResponse;","I"},"V"));
                code.visitLabel(L5);
                code.visitStmt1R(MONITOR_ENTER,12);
                code.visitLabel(L6);
                code.visitFieldStmt(IGET,5,12,new Field("Lorg/mortbay/jetty/handler/StatisticsHandler;","_requestsActive","I"));
                code.visitStmt2R(SUB_INT_2ADDR,5,7);
                code.visitFieldStmt(IPUT,5,12,new Field("Lorg/mortbay/jetty/handler/StatisticsHandler;","_requestsActive","I"));
                code.visitLabel(L29);
                code.visitFieldStmt(IGET,5,12,new Field("Lorg/mortbay/jetty/handler/StatisticsHandler;","_requestsActive","I"));
                code.visitJumpStmt(IF_GEZ,5,-1,L31);
                code.visitLabel(L30);
                code.visitConstStmt(CONST_4,5, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT,5,12,new Field("Lorg/mortbay/jetty/handler/StatisticsHandler;","_requestsActive","I"));
                code.visitLabel(L31);
                code.visitFieldStmt(IGET,5,12,new Field("Lorg/mortbay/jetty/handler/StatisticsHandler;","_requestsActive","I"));
                code.visitFieldStmt(IGET,6,12,new Field("Lorg/mortbay/jetty/handler/StatisticsHandler;","_requestsActiveMin","I"));
                code.visitJumpStmt(IF_GE,5,6,L33);
                code.visitLabel(L32);
                code.visitFieldStmt(IGET,5,12,new Field("Lorg/mortbay/jetty/handler/StatisticsHandler;","_requestsActive","I"));
                code.visitFieldStmt(IPUT,5,12,new Field("Lorg/mortbay/jetty/handler/StatisticsHandler;","_requestsActiveMin","I"));
                code.visitLabel(L33);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Ljava/lang/System;","currentTimeMillis",new String[]{ },"J"));
                code.visitStmt1R(MOVE_RESULT_WIDE,5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Lorg/mortbay/jetty/Request;","getTimeStamp",new String[]{ },"J"));
                code.visitStmt1R(MOVE_RESULT_WIDE,7);
                code.visitStmt3R(SUB_LONG,3,5,7);
                code.visitLabel(L34);
                code.visitFieldStmt(IGET_WIDE,5,12,new Field("Lorg/mortbay/jetty/handler/StatisticsHandler;","_requestsDurationTotal","J"));
                code.visitStmt2R(ADD_LONG_2ADDR,5,3);
                code.visitFieldStmt(IPUT_WIDE,5,12,new Field("Lorg/mortbay/jetty/handler/StatisticsHandler;","_requestsDurationTotal","J"));
                code.visitLabel(L35);
                code.visitFieldStmt(IGET_WIDE,5,12,new Field("Lorg/mortbay/jetty/handler/StatisticsHandler;","_requestsDurationMin","J"));
                code.visitStmt3R(CMP_LONG,5,5,10);
                code.visitJumpStmt(IF_EQZ,5,-1,L36);
                code.visitFieldStmt(IGET_WIDE,5,12,new Field("Lorg/mortbay/jetty/handler/StatisticsHandler;","_requestsDurationMin","J"));
                code.visitStmt3R(CMP_LONG,5,3,5);
                code.visitJumpStmt(IF_GEZ,5,-1,L37);
                code.visitLabel(L36);
                code.visitFieldStmt(IPUT_WIDE,3,12,new Field("Lorg/mortbay/jetty/handler/StatisticsHandler;","_requestsDurationMin","J"));
                code.visitLabel(L37);
                code.visitFieldStmt(IGET_WIDE,5,12,new Field("Lorg/mortbay/jetty/handler/StatisticsHandler;","_requestsDurationMax","J"));
                code.visitStmt3R(CMP_LONG,5,3,5);
                code.visitJumpStmt(IF_LEZ,5,-1,L39);
                code.visitLabel(L38);
                code.visitFieldStmt(IPUT_WIDE,3,12,new Field("Lorg/mortbay/jetty/handler/StatisticsHandler;","_requestsDurationMax","J"));
                code.visitLabel(L39);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/jetty/Response;","getStatus",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,5);
                code.visitStmt2R1N(DIV_INT_LIT8,5,5,100);
                code.visitSparseSwitchStmt(PACKED_SWITCH,5,1,new DexLabel[]{L20,L59,L60,L61,L62});
                code.visitLabel(L40);
                code.visitStmt1R(MONITOR_EXIT,12);
                code.visitLabel(L7);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L41);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Lorg/mortbay/jetty/HttpConnection;","getCurrentConnection",new String[]{ },"Lorg/mortbay/jetty/HttpConnection;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Lorg/mortbay/jetty/HttpConnection;","getRequest",new String[]{ },"Lorg/mortbay/jetty/Request;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitStmt2R(MOVE_OBJECT,1,5);
                code.visitJumpStmt(GOTO,-1,-1,L24);
                code.visitLabel(L42);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Lorg/mortbay/jetty/HttpConnection;","getCurrentConnection",new String[]{ },"Lorg/mortbay/jetty/HttpConnection;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Lorg/mortbay/jetty/HttpConnection;","getResponse",new String[]{ },"Lorg/mortbay/jetty/Response;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitStmt2R(MOVE_OBJECT,2,5);
                code.visitJumpStmt(GOTO,-1,-1,L0);
                code.visitLabel(L4);
                code.visitStmt1R(MOVE_EXCEPTION,5);
                code.visitLabel(L9);
                code.visitStmt1R(MONITOR_EXIT,12);
                code.visitLabel(L10);
                code.visitStmt1R(THROW,5);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,5);
                code.visitStmt1R(MONITOR_ENTER,12);
                code.visitLabel(L11);
                code.visitFieldStmt(IGET,6,12,new Field("Lorg/mortbay/jetty/handler/StatisticsHandler;","_requestsActive","I"));
                code.visitStmt2R(SUB_INT_2ADDR,6,7);
                code.visitFieldStmt(IPUT,6,12,new Field("Lorg/mortbay/jetty/handler/StatisticsHandler;","_requestsActive","I"));
                code.visitLabel(L43);
                code.visitFieldStmt(IGET,6,12,new Field("Lorg/mortbay/jetty/handler/StatisticsHandler;","_requestsActive","I"));
                code.visitJumpStmt(IF_GEZ,6,-1,L45);
                code.visitLabel(L44);
                code.visitConstStmt(CONST_4,6, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT,6,12,new Field("Lorg/mortbay/jetty/handler/StatisticsHandler;","_requestsActive","I"));
                code.visitLabel(L45);
                code.visitFieldStmt(IGET,6,12,new Field("Lorg/mortbay/jetty/handler/StatisticsHandler;","_requestsActive","I"));
                code.visitFieldStmt(IGET,7,12,new Field("Lorg/mortbay/jetty/handler/StatisticsHandler;","_requestsActiveMin","I"));
                code.visitJumpStmt(IF_GE,6,7,L47);
                code.visitLabel(L46);
                code.visitFieldStmt(IGET,6,12,new Field("Lorg/mortbay/jetty/handler/StatisticsHandler;","_requestsActive","I"));
                code.visitFieldStmt(IPUT,6,12,new Field("Lorg/mortbay/jetty/handler/StatisticsHandler;","_requestsActiveMin","I"));
                code.visitLabel(L47);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Ljava/lang/System;","currentTimeMillis",new String[]{ },"J"));
                code.visitStmt1R(MOVE_RESULT_WIDE,6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Lorg/mortbay/jetty/Request;","getTimeStamp",new String[]{ },"J"));
                code.visitStmt1R(MOVE_RESULT_WIDE,8);
                code.visitStmt3R(SUB_LONG,3,6,8);
                code.visitLabel(L48);
                code.visitFieldStmt(IGET_WIDE,6,12,new Field("Lorg/mortbay/jetty/handler/StatisticsHandler;","_requestsDurationTotal","J"));
                code.visitStmt2R(ADD_LONG_2ADDR,6,3);
                code.visitFieldStmt(IPUT_WIDE,6,12,new Field("Lorg/mortbay/jetty/handler/StatisticsHandler;","_requestsDurationTotal","J"));
                code.visitLabel(L49);
                code.visitFieldStmt(IGET_WIDE,6,12,new Field("Lorg/mortbay/jetty/handler/StatisticsHandler;","_requestsDurationMin","J"));
                code.visitStmt3R(CMP_LONG,6,6,10);
                code.visitJumpStmt(IF_EQZ,6,-1,L50);
                code.visitFieldStmt(IGET_WIDE,6,12,new Field("Lorg/mortbay/jetty/handler/StatisticsHandler;","_requestsDurationMin","J"));
                code.visitStmt3R(CMP_LONG,6,3,6);
                code.visitJumpStmt(IF_GEZ,6,-1,L51);
                code.visitLabel(L50);
                code.visitFieldStmt(IPUT_WIDE,3,12,new Field("Lorg/mortbay/jetty/handler/StatisticsHandler;","_requestsDurationMin","J"));
                code.visitLabel(L51);
                code.visitFieldStmt(IGET_WIDE,6,12,new Field("Lorg/mortbay/jetty/handler/StatisticsHandler;","_requestsDurationMax","J"));
                code.visitStmt3R(CMP_LONG,6,3,6);
                code.visitJumpStmt(IF_LEZ,6,-1,L53);
                code.visitLabel(L52);
                code.visitFieldStmt(IPUT_WIDE,3,12,new Field("Lorg/mortbay/jetty/handler/StatisticsHandler;","_requestsDurationMax","J"));
                code.visitLabel(L53);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/jetty/Response;","getStatus",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,6);
                code.visitStmt2R1N(DIV_INT_LIT8,6,6,100);
                code.visitSparseSwitchStmt(PACKED_SWITCH,6,1,new DexLabel[]{L16,L55,L56,L57,L58});
                code.visitLabel(L54);
                code.visitStmt1R(MONITOR_EXIT,12);
                code.visitLabel(L12);
                code.visitStmt1R(THROW,5);
                code.visitLabel(L13);
                code.visitStmt1R(MOVE_EXCEPTION,5);
                code.visitLabel(L14);
                code.visitStmt1R(MONITOR_EXIT,12);
                code.visitLabel(L15);
                code.visitStmt1R(THROW,5);
                code.visitLabel(L16);
                code.visitFieldStmt(IGET,6,12,new Field("Lorg/mortbay/jetty/handler/StatisticsHandler;","_responses1xx","I"));
                code.visitStmt2R1N(ADD_INT_LIT8,6,6,1);
                code.visitFieldStmt(IPUT,6,12,new Field("Lorg/mortbay/jetty/handler/StatisticsHandler;","_responses1xx","I"));
                code.visitJumpStmt(GOTO,-1,-1,L54);
                code.visitLabel(L55);
                code.visitFieldStmt(IGET,6,12,new Field("Lorg/mortbay/jetty/handler/StatisticsHandler;","_responses2xx","I"));
                code.visitStmt2R1N(ADD_INT_LIT8,6,6,1);
                code.visitFieldStmt(IPUT,6,12,new Field("Lorg/mortbay/jetty/handler/StatisticsHandler;","_responses2xx","I"));
                code.visitJumpStmt(GOTO,-1,-1,L54);
                code.visitLabel(L56);
                code.visitFieldStmt(IGET,6,12,new Field("Lorg/mortbay/jetty/handler/StatisticsHandler;","_responses3xx","I"));
                code.visitStmt2R1N(ADD_INT_LIT8,6,6,1);
                code.visitFieldStmt(IPUT,6,12,new Field("Lorg/mortbay/jetty/handler/StatisticsHandler;","_responses3xx","I"));
                code.visitJumpStmt(GOTO,-1,-1,L54);
                code.visitLabel(L57);
                code.visitFieldStmt(IGET,6,12,new Field("Lorg/mortbay/jetty/handler/StatisticsHandler;","_responses4xx","I"));
                code.visitStmt2R1N(ADD_INT_LIT8,6,6,1);
                code.visitFieldStmt(IPUT,6,12,new Field("Lorg/mortbay/jetty/handler/StatisticsHandler;","_responses4xx","I"));
                code.visitJumpStmt(GOTO,-1,-1,L54);
                code.visitLabel(L58);
                code.visitFieldStmt(IGET,6,12,new Field("Lorg/mortbay/jetty/handler/StatisticsHandler;","_responses5xx","I"));
                code.visitStmt2R1N(ADD_INT_LIT8,6,6,1);
                code.visitFieldStmt(IPUT,6,12,new Field("Lorg/mortbay/jetty/handler/StatisticsHandler;","_responses5xx","I"));
                code.visitLabel(L17);
                code.visitJumpStmt(GOTO,-1,-1,L54);
                code.visitLabel(L8);
                code.visitStmt1R(MOVE_EXCEPTION,5);
                code.visitLabel(L18);
                code.visitStmt1R(MONITOR_EXIT,12);
                code.visitLabel(L19);
                code.visitStmt1R(THROW,5);
                code.visitLabel(L20);
                code.visitFieldStmt(IGET,5,12,new Field("Lorg/mortbay/jetty/handler/StatisticsHandler;","_responses1xx","I"));
                code.visitStmt2R1N(ADD_INT_LIT8,5,5,1);
                code.visitFieldStmt(IPUT,5,12,new Field("Lorg/mortbay/jetty/handler/StatisticsHandler;","_responses1xx","I"));
                code.visitJumpStmt(GOTO_16,-1,-1,L40);
                code.visitLabel(L59);
                code.visitFieldStmt(IGET,5,12,new Field("Lorg/mortbay/jetty/handler/StatisticsHandler;","_responses2xx","I"));
                code.visitStmt2R1N(ADD_INT_LIT8,5,5,1);
                code.visitFieldStmt(IPUT,5,12,new Field("Lorg/mortbay/jetty/handler/StatisticsHandler;","_responses2xx","I"));
                code.visitJumpStmt(GOTO_16,-1,-1,L40);
                code.visitLabel(L60);
                code.visitFieldStmt(IGET,5,12,new Field("Lorg/mortbay/jetty/handler/StatisticsHandler;","_responses3xx","I"));
                code.visitStmt2R1N(ADD_INT_LIT8,5,5,1);
                code.visitFieldStmt(IPUT,5,12,new Field("Lorg/mortbay/jetty/handler/StatisticsHandler;","_responses3xx","I"));
                code.visitJumpStmt(GOTO_16,-1,-1,L40);
                code.visitLabel(L61);
                code.visitFieldStmt(IGET,5,12,new Field("Lorg/mortbay/jetty/handler/StatisticsHandler;","_responses4xx","I"));
                code.visitStmt2R1N(ADD_INT_LIT8,5,5,1);
                code.visitFieldStmt(IPUT,5,12,new Field("Lorg/mortbay/jetty/handler/StatisticsHandler;","_responses4xx","I"));
                code.visitJumpStmt(GOTO_16,-1,-1,L40);
                code.visitLabel(L62);
                code.visitFieldStmt(IGET,5,12,new Field("Lorg/mortbay/jetty/handler/StatisticsHandler;","_responses5xx","I"));
                code.visitStmt2R1N(ADD_INT_LIT8,5,5,1);
                code.visitFieldStmt(IPUT,5,12,new Field("Lorg/mortbay/jetty/handler/StatisticsHandler;","_responses5xx","I"));
                code.visitLabel(L21);
                code.visitJumpStmt(GOTO_16,-1,-1,L40);
                code.visitLabel(L63);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m018_statsReset(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/handler/StatisticsHandler;","statsReset",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L3=new DexLabel();
                ddv.visitPrologue(L3);
                ddv.visitLineNumber(50,L3);
                ddv.visitLineNumber(52,L0);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(53,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(54,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(55,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(56,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(57,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(58,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(59,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(60,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(62,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(63,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(64,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(66,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(67,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(68,L17);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(69,L18);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(70,L19);
                ddv.visitLineNumber(69,L2);
                code.visitLabel(L3);
                code.visitStmt1R(MONITOR_ENTER,2);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/jetty/handler/StatisticsHandler;","isStarted",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_EQZ,0,-1,L5);
                code.visitLabel(L4);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Ljava/lang/System;","currentTimeMillis",new String[]{ },"J"));
                code.visitStmt1R(MOVE_RESULT_WIDE,0);
                code.visitFieldStmt(IPUT_WIDE,0,2,new Field("Lorg/mortbay/jetty/handler/StatisticsHandler;","_statsStartedAt","J"));
                code.visitLabel(L5);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT,0,2,new Field("Lorg/mortbay/jetty/handler/StatisticsHandler;","_requests","I"));
                code.visitLabel(L6);
                code.visitFieldStmt(IGET,0,2,new Field("Lorg/mortbay/jetty/handler/StatisticsHandler;","_requestsActive","I"));
                code.visitFieldStmt(IPUT,0,2,new Field("Lorg/mortbay/jetty/handler/StatisticsHandler;","_requestsActiveMax","I"));
                code.visitLabel(L7);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT,0,2,new Field("Lorg/mortbay/jetty/handler/StatisticsHandler;","_responses1xx","I"));
                code.visitLabel(L8);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT,0,2,new Field("Lorg/mortbay/jetty/handler/StatisticsHandler;","_responses2xx","I"));
                code.visitLabel(L9);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT,0,2,new Field("Lorg/mortbay/jetty/handler/StatisticsHandler;","_responses3xx","I"));
                code.visitLabel(L10);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT,0,2,new Field("Lorg/mortbay/jetty/handler/StatisticsHandler;","_responses4xx","I"));
                code.visitLabel(L11);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT,0,2,new Field("Lorg/mortbay/jetty/handler/StatisticsHandler;","_responses5xx","I"));
                code.visitLabel(L12);
                code.visitFieldStmt(IGET,0,2,new Field("Lorg/mortbay/jetty/handler/StatisticsHandler;","_requestsActive","I"));
                code.visitFieldStmt(IPUT,0,2,new Field("Lorg/mortbay/jetty/handler/StatisticsHandler;","_requestsActiveMin","I"));
                code.visitLabel(L13);
                code.visitFieldStmt(IGET,0,2,new Field("Lorg/mortbay/jetty/handler/StatisticsHandler;","_requestsActive","I"));
                code.visitFieldStmt(IPUT,0,2,new Field("Lorg/mortbay/jetty/handler/StatisticsHandler;","_requestsActiveMax","I"));
                code.visitLabel(L14);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT,0,2,new Field("Lorg/mortbay/jetty/handler/StatisticsHandler;","_requestsActive","I"));
                code.visitLabel(L15);
                code.visitConstStmt(CONST_WIDE_16,0,Long.valueOf(0L)); // long: 0x0000000000000000  double:0.000000
                code.visitFieldStmt(IPUT_WIDE,0,2,new Field("Lorg/mortbay/jetty/handler/StatisticsHandler;","_requestsDurationMin","J"));
                code.visitLabel(L16);
                code.visitConstStmt(CONST_WIDE_16,0,Long.valueOf(0L)); // long: 0x0000000000000000  double:0.000000
                code.visitFieldStmt(IPUT_WIDE,0,2,new Field("Lorg/mortbay/jetty/handler/StatisticsHandler;","_requestsDurationMax","J"));
                code.visitLabel(L17);
                code.visitConstStmt(CONST_WIDE_16,0,Long.valueOf(0L)); // long: 0x0000000000000000  double:0.000000
                code.visitFieldStmt(IPUT_WIDE,0,2,new Field("Lorg/mortbay/jetty/handler/StatisticsHandler;","_requestsDurationTotal","J"));
                code.visitLabel(L18);
                code.visitStmt1R(MONITOR_EXIT,2);
                code.visitLabel(L19);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,0);
                code.visitStmt1R(MONITOR_EXIT,2);
                code.visitLabel(L1);
                code.visitStmt1R(THROW,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
