package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0397_org_mortbay_thread_QueuedThreadPool {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(ACC_PUBLIC,"Lorg/mortbay/thread/QueuedThreadPool;","Lorg/mortbay/component/AbstractLifeCycle;",new String[]{ "Ljava/io/Serializable;","Lorg/mortbay/thread/ThreadPool;"});
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("QueuedThreadPool.java");
        if(cv!=null){
            DexAnnotationVisitor av00 = cv.visitAnnotation("Ldalvik/annotation/MemberClasses;", Visibility.SYSTEM);
            if(av00 != null) {
                {
                    DexAnnotationVisitor av01 = av00.visitArray("value");
                    if(av01 != null) {
                        av01.visit(null, new DexType("Lorg/mortbay/thread/QueuedThreadPool$1;"));
                        av01.visit(null, new DexType("Lorg/mortbay/thread/QueuedThreadPool$Lock;"));
                        av01.visit(null, new DexType("Lorg/mortbay/thread/QueuedThreadPool$PoolThread;"));
                        av01.visitEnd();
                    }
                }
                av00.visitEnd();
            }
        }
        f000__daemon(cv);
        f001__id(cv);
        f002__idle(cv);
        f003__jobs(cv);
        f004__joinLock(cv);
        f005__lastShrink(cv);
        f006__lock(cv);
        f007__lowThreads(cv);
        f008__maxIdleTimeMs(cv);
        f009__maxQueued(cv);
        f010__maxStopTimeMs(cv);
        f011__maxThreads(cv);
        f012__minThreads(cv);
        f013__name(cv);
        f014__nextJob(cv);
        f015__nextJobSlot(cv);
        f016__priority(cv);
        f017__queued(cv);
        f018__spawnOrShrinkAt(cv);
        f019__threads(cv);
        f020__threadsLock(cv);
        f021__warned(cv);
        m000__init_(cv);
        m001__init_(cv);
        m002_access$100(cv);
        m003_access$1000(cv);
        m004_access$1100(cv);
        m005_access$1200(cv);
        m006_access$1202(cv);
        m007_access$1300(cv);
        m008_access$200(cv);
        m009_access$300(cv);
        m010_access$400(cv);
        m011_access$410(cv);
        m012_access$500(cv);
        m013_access$600(cv);
        m014_access$602(cv);
        m015_access$608(cv);
        m016_access$700(cv);
        m017_access$800(cv);
        m018_access$900(cv);
        m019_dispatch(cv);
        m020_doStart(cv);
        m021_doStop(cv);
        m022_getIdleThreads(cv);
        m023_getLowThreads(cv);
        m024_getMaxIdleTimeMs(cv);
        m025_getMaxQueued(cv);
        m026_getMaxStopTimeMs(cv);
        m027_getMaxThreads(cv);
        m028_getMinThreads(cv);
        m029_getName(cv);
        m030_getQueueSize(cv);
        m031_getSpawnOrShrinkAt(cv);
        m032_getThreads(cv);
        m033_getThreadsPriority(cv);
        m034_isDaemon(cv);
        m035_isLowOnThreads(cv);
        m036_join(cv);
        m037_newThread(cv);
        m038_setDaemon(cv);
        m039_setLowThreads(cv);
        m040_setMaxIdleTimeMs(cv);
        m041_setMaxStopTimeMs(cv);
        m042_setMaxThreads(cv);
        m043_setMinThreads(cv);
        m044_setName(cv);
        m045_setSpawnOrShrinkAt(cv);
        m046_setThreadsPriority(cv);
        m047_stopJob(cv);
    }
    public static void f000__daemon(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/thread/QueuedThreadPool;","_daemon","Z"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f001__id(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/thread/QueuedThreadPool;","_id","I"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f002__idle(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/thread/QueuedThreadPool;","_idle","Ljava/util/List;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f003__jobs(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/thread/QueuedThreadPool;","_jobs","[Ljava/lang/Runnable;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f004__joinLock(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE|ACC_FINAL, new Field("Lorg/mortbay/thread/QueuedThreadPool;","_joinLock","Ljava/lang/Object;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f005__lastShrink(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/thread/QueuedThreadPool;","_lastShrink","J"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f006__lock(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE|ACC_FINAL, new Field("Lorg/mortbay/thread/QueuedThreadPool;","_lock","Ljava/lang/Object;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f007__lowThreads(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/thread/QueuedThreadPool;","_lowThreads","I"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f008__maxIdleTimeMs(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/thread/QueuedThreadPool;","_maxIdleTimeMs","I"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f009__maxQueued(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/thread/QueuedThreadPool;","_maxQueued","I"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f010__maxStopTimeMs(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/thread/QueuedThreadPool;","_maxStopTimeMs","I"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f011__maxThreads(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/thread/QueuedThreadPool;","_maxThreads","I"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f012__minThreads(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/thread/QueuedThreadPool;","_minThreads","I"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f013__name(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/thread/QueuedThreadPool;","_name","Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f014__nextJob(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/thread/QueuedThreadPool;","_nextJob","I"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f015__nextJobSlot(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/thread/QueuedThreadPool;","_nextJobSlot","I"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f016__priority(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/thread/QueuedThreadPool;","_priority","I"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f017__queued(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/thread/QueuedThreadPool;","_queued","I"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f018__spawnOrShrinkAt(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/thread/QueuedThreadPool;","_spawnOrShrinkAt","I"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f019__threads(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/thread/QueuedThreadPool;","_threads","Ljava/util/Set;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f020__threadsLock(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE|ACC_FINAL, new Field("Lorg/mortbay/thread/QueuedThreadPool;","_threadsLock","Ljava/lang/Object;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f021__warned(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/thread/QueuedThreadPool;","_warned","Z"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void m000__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/thread/QueuedThreadPool;","<init>",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(74,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(55,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(56,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(57,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(60,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(61,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(62,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(63,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(64,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(65,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(66,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(75,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(76,L13);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 3},new Method("Lorg/mortbay/component/AbstractLifeCycle;","<init>",new String[]{ },"V"));
                code.visitLabel(L2);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Lorg/mortbay/thread/QueuedThreadPool$Lock;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,3,2},new Method("Lorg/mortbay/thread/QueuedThreadPool$Lock;","<init>",new String[]{ "Lorg/mortbay/thread/QueuedThreadPool;","Lorg/mortbay/thread/QueuedThreadPool$1;"},"V"));
                code.visitFieldStmt(IPUT_OBJECT,0,3,new Field("Lorg/mortbay/thread/QueuedThreadPool;","_lock","Ljava/lang/Object;"));
                code.visitLabel(L3);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Lorg/mortbay/thread/QueuedThreadPool$Lock;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,3,2},new Method("Lorg/mortbay/thread/QueuedThreadPool$Lock;","<init>",new String[]{ "Lorg/mortbay/thread/QueuedThreadPool;","Lorg/mortbay/thread/QueuedThreadPool$1;"},"V"));
                code.visitFieldStmt(IPUT_OBJECT,0,3,new Field("Lorg/mortbay/thread/QueuedThreadPool;","_threadsLock","Ljava/lang/Object;"));
                code.visitLabel(L4);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Lorg/mortbay/thread/QueuedThreadPool$Lock;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,3,2},new Method("Lorg/mortbay/thread/QueuedThreadPool$Lock;","<init>",new String[]{ "Lorg/mortbay/thread/QueuedThreadPool;","Lorg/mortbay/thread/QueuedThreadPool$1;"},"V"));
                code.visitFieldStmt(IPUT_OBJECT,0,3,new Field("Lorg/mortbay/thread/QueuedThreadPool;","_joinLock","Ljava/lang/Object;"));
                code.visitLabel(L5);
                code.visitConstStmt(CONST,0, Integer.valueOf(60000)); // int: 0x0000ea60  float:0.000000
                code.visitFieldStmt(IPUT,0,3,new Field("Lorg/mortbay/thread/QueuedThreadPool;","_maxIdleTimeMs","I"));
                code.visitLabel(L6);
                code.visitConstStmt(CONST_16,0, Integer.valueOf(250)); // int: 0x000000fa  float:0.000000
                code.visitFieldStmt(IPUT,0,3,new Field("Lorg/mortbay/thread/QueuedThreadPool;","_maxThreads","I"));
                code.visitLabel(L7);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(2)); // int: 0x00000002  float:0.000000
                code.visitFieldStmt(IPUT,0,3,new Field("Lorg/mortbay/thread/QueuedThreadPool;","_minThreads","I"));
                code.visitLabel(L8);
                code.visitFieldStmt(IPUT_BOOLEAN,1,3,new Field("Lorg/mortbay/thread/QueuedThreadPool;","_warned","Z"));
                code.visitLabel(L9);
                code.visitFieldStmt(IPUT,1,3,new Field("Lorg/mortbay/thread/QueuedThreadPool;","_lowThreads","I"));
                code.visitLabel(L10);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(5)); // int: 0x00000005  float:0.000000
                code.visitFieldStmt(IPUT,0,3,new Field("Lorg/mortbay/thread/QueuedThreadPool;","_priority","I"));
                code.visitLabel(L11);
                code.visitFieldStmt(IPUT,1,3,new Field("Lorg/mortbay/thread/QueuedThreadPool;","_spawnOrShrinkAt","I"));
                code.visitLabel(L12);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,1,"qtp-");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Ljava/lang/Object;","hashCode",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "I"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(IPUT_OBJECT,0,3,new Field("Lorg/mortbay/thread/QueuedThreadPool;","_name","Ljava/lang/String;"));
                code.visitLabel(L13);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/thread/QueuedThreadPool;","<init>",new String[]{ "I"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"maxThreads");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(83,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(84,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(85,L2);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Lorg/mortbay/thread/QueuedThreadPool;","<init>",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Lorg/mortbay/thread/QueuedThreadPool;","setMaxThreads",new String[]{ "I"},"V"));
                code.visitLabel(L2);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m002_access$100(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_STATIC|ACC_SYNTHETIC, new Method("Lorg/mortbay/thread/QueuedThreadPool;","access$100",new String[]{ "Lorg/mortbay/thread/QueuedThreadPool;"},"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"x0");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(41,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_BOOLEAN,0,1,new Field("Lorg/mortbay/thread/QueuedThreadPool;","_daemon","Z"));
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m003_access$1000(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_STATIC|ACC_SYNTHETIC, new Method("Lorg/mortbay/thread/QueuedThreadPool;","access$1000",new String[]{ "Lorg/mortbay/thread/QueuedThreadPool;"},"Ljava/util/List;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"x0");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(41,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/thread/QueuedThreadPool;","_idle","Ljava/util/List;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m004_access$1100(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_STATIC|ACC_SYNTHETIC, new Method("Lorg/mortbay/thread/QueuedThreadPool;","access$1100",new String[]{ "Lorg/mortbay/thread/QueuedThreadPool;"},"I"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"x0");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(41,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET,0,1,new Field("Lorg/mortbay/thread/QueuedThreadPool;","_spawnOrShrinkAt","I"));
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m005_access$1200(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_STATIC|ACC_SYNTHETIC, new Method("Lorg/mortbay/thread/QueuedThreadPool;","access$1200",new String[]{ "Lorg/mortbay/thread/QueuedThreadPool;"},"J"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"x0");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(41,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_WIDE,0,2,new Field("Lorg/mortbay/thread/QueuedThreadPool;","_lastShrink","J"));
                code.visitStmt1R(RETURN_WIDE,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m006_access$1202(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_STATIC|ACC_SYNTHETIC, new Method("Lorg/mortbay/thread/QueuedThreadPool;","access$1202",new String[]{ "Lorg/mortbay/thread/QueuedThreadPool;","J"},"J"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"x0");
                ddv.visitParameterName(1,"x1");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(41,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_WIDE,1,0,new Field("Lorg/mortbay/thread/QueuedThreadPool;","_lastShrink","J"));
                code.visitStmt1R(RETURN_WIDE,1);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m007_access$1300(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_STATIC|ACC_SYNTHETIC, new Method("Lorg/mortbay/thread/QueuedThreadPool;","access$1300",new String[]{ "Lorg/mortbay/thread/QueuedThreadPool;"},"Ljava/lang/Object;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"x0");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(41,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/thread/QueuedThreadPool;","_threadsLock","Ljava/lang/Object;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m008_access$200(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_STATIC|ACC_SYNTHETIC, new Method("Lorg/mortbay/thread/QueuedThreadPool;","access$200",new String[]{ "Lorg/mortbay/thread/QueuedThreadPool;"},"I"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"x0");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(41,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET,0,1,new Field("Lorg/mortbay/thread/QueuedThreadPool;","_priority","I"));
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m009_access$300(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_STATIC|ACC_SYNTHETIC, new Method("Lorg/mortbay/thread/QueuedThreadPool;","access$300",new String[]{ "Lorg/mortbay/thread/QueuedThreadPool;"},"Ljava/lang/Object;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"x0");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(41,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/thread/QueuedThreadPool;","_lock","Ljava/lang/Object;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m010_access$400(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_STATIC|ACC_SYNTHETIC, new Method("Lorg/mortbay/thread/QueuedThreadPool;","access$400",new String[]{ "Lorg/mortbay/thread/QueuedThreadPool;"},"I"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"x0");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(41,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET,0,1,new Field("Lorg/mortbay/thread/QueuedThreadPool;","_queued","I"));
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m011_access$410(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_STATIC|ACC_SYNTHETIC, new Method("Lorg/mortbay/thread/QueuedThreadPool;","access$410",new String[]{ "Lorg/mortbay/thread/QueuedThreadPool;"},"I"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"x0");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(41,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET,0,2,new Field("Lorg/mortbay/thread/QueuedThreadPool;","_queued","I"));
                code.visitConstStmt(CONST_4,1, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitStmt3R(SUB_INT,1,0,1);
                code.visitFieldStmt(IPUT,1,2,new Field("Lorg/mortbay/thread/QueuedThreadPool;","_queued","I"));
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m012_access$500(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_STATIC|ACC_SYNTHETIC, new Method("Lorg/mortbay/thread/QueuedThreadPool;","access$500",new String[]{ "Lorg/mortbay/thread/QueuedThreadPool;"},"[Ljava/lang/Runnable;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"x0");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(41,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/thread/QueuedThreadPool;","_jobs","[Ljava/lang/Runnable;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m013_access$600(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_STATIC|ACC_SYNTHETIC, new Method("Lorg/mortbay/thread/QueuedThreadPool;","access$600",new String[]{ "Lorg/mortbay/thread/QueuedThreadPool;"},"I"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"x0");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(41,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET,0,1,new Field("Lorg/mortbay/thread/QueuedThreadPool;","_nextJob","I"));
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m014_access$602(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_STATIC|ACC_SYNTHETIC, new Method("Lorg/mortbay/thread/QueuedThreadPool;","access$602",new String[]{ "Lorg/mortbay/thread/QueuedThreadPool;","I"},"I"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"x0");
                ddv.visitParameterName(1,"x1");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(41,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT,1,0,new Field("Lorg/mortbay/thread/QueuedThreadPool;","_nextJob","I"));
                code.visitStmt1R(RETURN,1);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m015_access$608(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_STATIC|ACC_SYNTHETIC, new Method("Lorg/mortbay/thread/QueuedThreadPool;","access$608",new String[]{ "Lorg/mortbay/thread/QueuedThreadPool;"},"I"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"x0");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(41,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET,0,2,new Field("Lorg/mortbay/thread/QueuedThreadPool;","_nextJob","I"));
                code.visitStmt2R1N(ADD_INT_LIT8,1,0,1);
                code.visitFieldStmt(IPUT,1,2,new Field("Lorg/mortbay/thread/QueuedThreadPool;","_nextJob","I"));
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m016_access$700(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_STATIC|ACC_SYNTHETIC, new Method("Lorg/mortbay/thread/QueuedThreadPool;","access$700",new String[]{ "Lorg/mortbay/thread/QueuedThreadPool;"},"Ljava/util/Set;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"x0");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(41,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/thread/QueuedThreadPool;","_threads","Ljava/util/Set;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m017_access$800(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_STATIC|ACC_SYNTHETIC, new Method("Lorg/mortbay/thread/QueuedThreadPool;","access$800",new String[]{ "Lorg/mortbay/thread/QueuedThreadPool;"},"I"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"x0");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(41,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET,0,1,new Field("Lorg/mortbay/thread/QueuedThreadPool;","_minThreads","I"));
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m018_access$900(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_STATIC|ACC_SYNTHETIC, new Method("Lorg/mortbay/thread/QueuedThreadPool;","access$900",new String[]{ "Lorg/mortbay/thread/QueuedThreadPool;"},"I"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"x0");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(41,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET,0,1,new Field("Lorg/mortbay/thread/QueuedThreadPool;","_maxThreads","I"));
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m019_dispatch(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/thread/QueuedThreadPool;","dispatch",new String[]{ "Ljava/lang/Runnable;"},"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(14);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexLabel L3=new DexLabel();
                DexLabel L4=new DexLabel();
                code.visitTryCatch(L3,L4,new DexLabel[]{L2},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"job");
                DexLabel L5=new DexLabel();
                ddv.visitPrologue(L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(93,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(141,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(96,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(97,L9);
                ddv.visitStartLocal(5,L9,"thread","Lorg/mortbay/thread/QueuedThreadPool$PoolThread;",null);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(99,L10);
                ddv.visitStartLocal(3,L10,"spawn","Z",null);
                ddv.visitLineNumber(102,L0);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(103,L11);
                ddv.visitStartLocal(1,L11,"idle","I",null);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(104,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(131,L13);
                ddv.visitLineNumber(133,L1);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(135,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(141,L15);
                ddv.visitLineNumber(108,L3);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(109,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(110,L17);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(111,L18);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(112,L19);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(113,L20);
                DexLabel L21=new DexLabel();
                ddv.visitLineNumber(114,L21);
                DexLabel L22=new DexLabel();
                ddv.visitLineNumber(117,L22);
                DexLabel L23=new DexLabel();
                ddv.visitLineNumber(118,L23);
                ddv.visitStartLocal(2,L23,"jobs","[Ljava/lang/Runnable;",null);
                DexLabel L24=new DexLabel();
                ddv.visitLineNumber(119,L24);
                ddv.visitStartLocal(4,L24,"split","I",null);
                DexLabel L25=new DexLabel();
                ddv.visitLineNumber(120,L25);
                DexLabel L26=new DexLabel();
                ddv.visitLineNumber(121,L26);
                DexLabel L27=new DexLabel();
                ddv.visitLineNumber(122,L27);
                DexLabel L28=new DexLabel();
                ddv.visitLineNumber(124,L28);
                DexLabel L29=new DexLabel();
                ddv.visitLineNumber(125,L29);
                DexLabel L30=new DexLabel();
                ddv.visitLineNumber(126,L30);
                DexLabel L31=new DexLabel();
                ddv.visitLineNumber(129,L31);
                ddv.visitEndLocal(2,L31);
                ddv.visitEndLocal(4,L31);
                ddv.visitLineNumber(131,L2);
                ddv.visitEndLocal(1,L2);
                DexLabel L32=new DexLabel();
                ddv.visitLineNumber(137,L32);
                ddv.visitRestartLocal(1,L32);
                DexLabel L33=new DexLabel();
                ddv.visitLineNumber(139,L33);
                code.visitLabel(L5);
                code.visitConstStmt(CONST_4,11, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitConstStmt(CONST_4,10, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 12},new Method("Lorg/mortbay/thread/QueuedThreadPool;","isRunning",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,6);
                DexLabel L34=new DexLabel();
                code.visitJumpStmt(IF_EQZ,6,-1,L34);
                code.visitJumpStmt(IF_NEZ,13,-1,L8);
                code.visitLabel(L34);
                code.visitStmt2R(MOVE,6,10);
                code.visitLabel(L7);
                code.visitStmt1R(RETURN,6);
                code.visitLabel(L8);
                code.visitConstStmt(CONST_4,5, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L9);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L10);
                code.visitFieldStmt(IGET_OBJECT,7,12,new Field("Lorg/mortbay/thread/QueuedThreadPool;","_lock","Ljava/lang/Object;"));
                code.visitStmt1R(MONITOR_ENTER,7);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,6,12,new Field("Lorg/mortbay/thread/QueuedThreadPool;","_idle","Ljava/util/List;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 6},new Method("Ljava/util/List;","size",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitLabel(L11);
                code.visitJumpStmt(IF_LEZ,1,-1,L3);
                code.visitLabel(L12);
                code.visitFieldStmt(IGET_OBJECT,6,12,new Field("Lorg/mortbay/thread/QueuedThreadPool;","_idle","Ljava/util/List;"));
                code.visitStmt3R(SUB_INT,8,1,11);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 6,8},new Method("Ljava/util/List;","remove",new String[]{ "I"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitStmt2R(MOVE_OBJECT,0,6);
                code.visitTypeStmt(CHECK_CAST,0,-1,"Lorg/mortbay/thread/QueuedThreadPool$PoolThread;");
                code.visitStmt2R(MOVE_OBJECT,5,0);
                code.visitLabel(L13);
                code.visitStmt1R(MONITOR_EXIT,7);
                code.visitLabel(L1);
                code.visitJumpStmt(IF_EQZ,5,-1,L32);
                code.visitLabel(L14);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,13},new Method("Lorg/mortbay/thread/QueuedThreadPool$PoolThread;","dispatch",new String[]{ "Ljava/lang/Runnable;"},"V"));
                DexLabel L35=new DexLabel();
                code.visitLabel(L35);
                code.visitStmt2R(MOVE,6,11);
                code.visitLabel(L15);
                code.visitJumpStmt(GOTO,-1,-1,L7);
                code.visitLabel(L3);
                code.visitFieldStmt(IGET,6,12,new Field("Lorg/mortbay/thread/QueuedThreadPool;","_queued","I"));
                code.visitStmt2R1N(ADD_INT_LIT8,6,6,1);
                code.visitFieldStmt(IPUT,6,12,new Field("Lorg/mortbay/thread/QueuedThreadPool;","_queued","I"));
                code.visitLabel(L16);
                code.visitFieldStmt(IGET,6,12,new Field("Lorg/mortbay/thread/QueuedThreadPool;","_queued","I"));
                code.visitFieldStmt(IGET,8,12,new Field("Lorg/mortbay/thread/QueuedThreadPool;","_maxQueued","I"));
                code.visitJumpStmt(IF_LE,6,8,L18);
                code.visitLabel(L17);
                code.visitFieldStmt(IGET,6,12,new Field("Lorg/mortbay/thread/QueuedThreadPool;","_queued","I"));
                code.visitFieldStmt(IPUT,6,12,new Field("Lorg/mortbay/thread/QueuedThreadPool;","_maxQueued","I"));
                code.visitLabel(L18);
                code.visitFieldStmt(IGET_OBJECT,6,12,new Field("Lorg/mortbay/thread/QueuedThreadPool;","_jobs","[Ljava/lang/Runnable;"));
                code.visitFieldStmt(IGET,8,12,new Field("Lorg/mortbay/thread/QueuedThreadPool;","_nextJobSlot","I"));
                code.visitStmt2R1N(ADD_INT_LIT8,9,8,1);
                code.visitFieldStmt(IPUT,9,12,new Field("Lorg/mortbay/thread/QueuedThreadPool;","_nextJobSlot","I"));
                code.visitStmt3R(APUT_OBJECT,13,6,8);
                code.visitLabel(L19);
                code.visitFieldStmt(IGET,6,12,new Field("Lorg/mortbay/thread/QueuedThreadPool;","_nextJobSlot","I"));
                code.visitFieldStmt(IGET_OBJECT,8,12,new Field("Lorg/mortbay/thread/QueuedThreadPool;","_jobs","[Ljava/lang/Runnable;"));
                code.visitStmt2R(ARRAY_LENGTH,8,8);
                code.visitJumpStmt(IF_NE,6,8,L21);
                code.visitLabel(L20);
                code.visitConstStmt(CONST_4,6, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT,6,12,new Field("Lorg/mortbay/thread/QueuedThreadPool;","_nextJobSlot","I"));
                code.visitLabel(L21);
                code.visitFieldStmt(IGET,6,12,new Field("Lorg/mortbay/thread/QueuedThreadPool;","_nextJobSlot","I"));
                code.visitFieldStmt(IGET,8,12,new Field("Lorg/mortbay/thread/QueuedThreadPool;","_nextJob","I"));
                code.visitJumpStmt(IF_NE,6,8,L31);
                code.visitLabel(L22);
                code.visitFieldStmt(IGET_OBJECT,6,12,new Field("Lorg/mortbay/thread/QueuedThreadPool;","_jobs","[Ljava/lang/Runnable;"));
                code.visitStmt2R(ARRAY_LENGTH,6,6);
                code.visitFieldStmt(IGET,8,12,new Field("Lorg/mortbay/thread/QueuedThreadPool;","_maxThreads","I"));
                code.visitStmt2R(ADD_INT_2ADDR,6,8);
                code.visitTypeStmt(NEW_ARRAY,2,6,"[Ljava/lang/Runnable;");
                code.visitLabel(L23);
                code.visitFieldStmt(IGET_OBJECT,6,12,new Field("Lorg/mortbay/thread/QueuedThreadPool;","_jobs","[Ljava/lang/Runnable;"));
                code.visitStmt2R(ARRAY_LENGTH,6,6);
                code.visitFieldStmt(IGET,8,12,new Field("Lorg/mortbay/thread/QueuedThreadPool;","_nextJob","I"));
                code.visitStmt3R(SUB_INT,4,6,8);
                code.visitLabel(L24);
                code.visitJumpStmt(IF_LEZ,4,-1,L26);
                code.visitLabel(L25);
                code.visitFieldStmt(IGET_OBJECT,6,12,new Field("Lorg/mortbay/thread/QueuedThreadPool;","_jobs","[Ljava/lang/Runnable;"));
                code.visitFieldStmt(IGET,8,12,new Field("Lorg/mortbay/thread/QueuedThreadPool;","_nextJob","I"));
                code.visitConstStmt(CONST_4,9, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 6,8,2,9,4},new Method("Ljava/lang/System;","arraycopy",new String[]{ "Ljava/lang/Object;","I","Ljava/lang/Object;","I","I"},"V"));
                code.visitLabel(L26);
                code.visitFieldStmt(IGET,6,12,new Field("Lorg/mortbay/thread/QueuedThreadPool;","_nextJob","I"));
                code.visitJumpStmt(IF_EQZ,6,-1,L28);
                code.visitLabel(L27);
                code.visitFieldStmt(IGET_OBJECT,6,12,new Field("Lorg/mortbay/thread/QueuedThreadPool;","_jobs","[Ljava/lang/Runnable;"));
                code.visitConstStmt(CONST_4,8, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IGET,9,12,new Field("Lorg/mortbay/thread/QueuedThreadPool;","_nextJobSlot","I"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 6,8,2,4,9},new Method("Ljava/lang/System;","arraycopy",new String[]{ "Ljava/lang/Object;","I","Ljava/lang/Object;","I","I"},"V"));
                code.visitLabel(L28);
                code.visitFieldStmt(IPUT_OBJECT,2,12,new Field("Lorg/mortbay/thread/QueuedThreadPool;","_jobs","[Ljava/lang/Runnable;"));
                code.visitLabel(L29);
                code.visitConstStmt(CONST_4,6, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT,6,12,new Field("Lorg/mortbay/thread/QueuedThreadPool;","_nextJob","I"));
                code.visitLabel(L30);
                code.visitFieldStmt(IGET,6,12,new Field("Lorg/mortbay/thread/QueuedThreadPool;","_queued","I"));
                code.visitFieldStmt(IPUT,6,12,new Field("Lorg/mortbay/thread/QueuedThreadPool;","_nextJobSlot","I"));
                code.visitLabel(L31);
                code.visitFieldStmt(IGET,6,12,new Field("Lorg/mortbay/thread/QueuedThreadPool;","_queued","I"));
                code.visitFieldStmt(IGET,8,12,new Field("Lorg/mortbay/thread/QueuedThreadPool;","_spawnOrShrinkAt","I"));
                DexLabel L36=new DexLabel();
                code.visitJumpStmt(IF_LE,6,8,L36);
                code.visitStmt2R(MOVE,3,11);
                DexLabel L37=new DexLabel();
                code.visitLabel(L37);
                code.visitJumpStmt(GOTO,-1,-1,L13);
                code.visitLabel(L36);
                code.visitStmt2R(MOVE,3,10);
                code.visitJumpStmt(GOTO,-1,-1,L37);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,6);
                code.visitStmt1R(MONITOR_EXIT,7);
                code.visitLabel(L4);
                code.visitStmt1R(THROW,6);
                code.visitLabel(L32);
                code.visitJumpStmt(IF_EQZ,3,-1,L35);
                code.visitLabel(L33);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 12},new Method("Lorg/mortbay/thread/QueuedThreadPool;","newThread",new String[]{ },"V"));
                code.visitJumpStmt(GOTO,-1,-1,L35);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m020_doStart(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Lorg/mortbay/thread/QueuedThreadPool;","doStart",new String[]{ },"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/lang/Exception;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(394,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(395,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(397,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(398,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(399,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(401,L5);
                DexLabel L6=new DexLabel();
                ddv.visitStartLocal(0,L6,"i","I",null);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(403,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(401,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(405,L9);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET,1,3,new Field("Lorg/mortbay/thread/QueuedThreadPool;","_maxThreads","I"));
                code.visitFieldStmt(IGET,2,3,new Field("Lorg/mortbay/thread/QueuedThreadPool;","_minThreads","I"));
                code.visitJumpStmt(IF_LT,1,2,L1);
                code.visitFieldStmt(IGET,1,3,new Field("Lorg/mortbay/thread/QueuedThreadPool;","_minThreads","I"));
                code.visitJumpStmt(IF_GTZ,1,-1,L2);
                code.visitLabel(L1);
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Ljava/lang/IllegalArgumentException;");
                code.visitConstStmt(CONST_STRING,2,"!0<minThreads<maxThreads");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1,2},new Method("Ljava/lang/IllegalArgumentException;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitStmt1R(THROW,1);
                code.visitLabel(L2);
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Ljava/util/HashSet;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1},new Method("Ljava/util/HashSet;","<init>",new String[]{ },"V"));
                code.visitFieldStmt(IPUT_OBJECT,1,3,new Field("Lorg/mortbay/thread/QueuedThreadPool;","_threads","Ljava/util/Set;"));
                code.visitLabel(L3);
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Ljava/util/ArrayList;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1},new Method("Ljava/util/ArrayList;","<init>",new String[]{ },"V"));
                code.visitFieldStmt(IPUT_OBJECT,1,3,new Field("Lorg/mortbay/thread/QueuedThreadPool;","_idle","Ljava/util/List;"));
                code.visitLabel(L4);
                code.visitFieldStmt(IGET,1,3,new Field("Lorg/mortbay/thread/QueuedThreadPool;","_maxThreads","I"));
                code.visitTypeStmt(NEW_ARRAY,1,1,"[Ljava/lang/Runnable;");
                code.visitFieldStmt(IPUT_OBJECT,1,3,new Field("Lorg/mortbay/thread/QueuedThreadPool;","_jobs","[Ljava/lang/Runnable;"));
                code.visitLabel(L5);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L6);
                code.visitFieldStmt(IGET,1,3,new Field("Lorg/mortbay/thread/QueuedThreadPool;","_minThreads","I"));
                code.visitJumpStmt(IF_GE,0,1,L9);
                code.visitLabel(L7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Lorg/mortbay/thread/QueuedThreadPool;","newThread",new String[]{ },"V"));
                code.visitLabel(L8);
                code.visitStmt2R1N(ADD_INT_LIT8,0,0,1);
                code.visitJumpStmt(GOTO,-1,-1,L6);
                code.visitLabel(L9);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m021_doStop(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Lorg/mortbay/thread/QueuedThreadPool;","doStop",new String[]{ },"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/lang/Exception;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(9);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexLabel L3=new DexLabel();
                DexLabel L4=new DexLabel();
                code.visitTryCatch(L3,L4,new DexLabel[]{L2},new String[]{ null});
                DexLabel L5=new DexLabel();
                DexLabel L6=new DexLabel();
                DexLabel L7=new DexLabel();
                code.visitTryCatch(L5,L6,new DexLabel[]{L7},new String[]{ null});
                DexLabel L8=new DexLabel();
                DexLabel L9=new DexLabel();
                DexLabel L10=new DexLabel();
                code.visitTryCatch(L8,L9,new DexLabel[]{L10},new String[]{ "Ljava/lang/InterruptedException;"});
                DexLabel L11=new DexLabel();
                DexLabel L12=new DexLabel();
                code.visitTryCatch(L11,L12,new DexLabel[]{L7},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L13=new DexLabel();
                ddv.visitPrologue(L13);
                ddv.visitLineNumber(417,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(419,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(420,L15);
                ddv.visitStartLocal(2,L15,"start","J",null);
                DexLabel L16=new DexLabel();
                ddv.visitStartLocal(0,L16,"i","I",null);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(422,L17);
                ddv.visitLineNumber(424,L0);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(425,L18);
                ddv.visitStartLocal(1,L18,"iter","Ljava/util/Iterator;",null);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(426,L19);
                ddv.visitLineNumber(427,L2);
                ddv.visitEndLocal(1,L2);
                ddv.visitRestartLocal(1,L3);
                ddv.visitLineNumber(429,L4);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(430,L20);
                DexLabel L21=new DexLabel();
                ddv.visitLineNumber(443,L21);
                ddv.visitEndLocal(1,L21);
                DexLabel L22=new DexLabel();
                ddv.visitLineNumber(444,L22);
                DexLabel L23=new DexLabel();
                ddv.visitLineNumber(446,L23);
                ddv.visitLineNumber(448,L5);
                DexLabel L24=new DexLabel();
                ddv.visitLineNumber(449,L24);
                ddv.visitLineNumber(450,L6);
                DexLabel L25=new DexLabel();
                ddv.visitLineNumber(435,L25);
                ddv.visitRestartLocal(1,L25);
                ddv.visitLineNumber(420,L9);
                ddv.visitLineNumber(449,L7);
                ddv.visitEndLocal(1,L7);
                ddv.visitLineNumber(437,L10);
                ddv.visitRestartLocal(1,L10);
                code.visitLabel(L13);
                code.visitMethodStmt(INVOKE_SUPER,new int[]{ 8},new Method("Lorg/mortbay/component/AbstractLifeCycle;","doStop",new String[]{ },"V"));
                code.visitLabel(L14);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Ljava/lang/System;","currentTimeMillis",new String[]{ },"J"));
                code.visitStmt1R(MOVE_RESULT_WIDE,2);
                code.visitLabel(L15);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L16);
                code.visitConstStmt(CONST_16,4, Integer.valueOf(100)); // int: 0x00000064  float:0.000000
                code.visitJumpStmt(IF_GE,0,4,L21);
                code.visitLabel(L17);
                code.visitFieldStmt(IGET_OBJECT,5,8,new Field("Lorg/mortbay/thread/QueuedThreadPool;","_threadsLock","Ljava/lang/Object;"));
                code.visitStmt1R(MONITOR_ENTER,5);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,4,8,new Field("Lorg/mortbay/thread/QueuedThreadPool;","_threads","Ljava/util/Set;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 4},new Method("Ljava/util/Set;","iterator",new String[]{ },"Ljava/util/Iterator;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L18);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 1},new Method("Ljava/util/Iterator;","hasNext",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,4);
                code.visitJumpStmt(IF_EQZ,4,-1,L3);
                code.visitLabel(L19);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 1},new Method("Ljava/util/Iterator;","next",new String[]{ },"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitTypeStmt(CHECK_CAST,4,-1,"Ljava/lang/Thread;");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Ljava/lang/Thread;","interrupt",new String[]{ },"V"));
                code.visitJumpStmt(GOTO,-1,-1,L18);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,4);
                code.visitStmt1R(MONITOR_EXIT,5);
                code.visitLabel(L1);
                code.visitStmt1R(THROW,4);
                code.visitLabel(L3);
                code.visitStmt1R(MONITOR_EXIT,5);
                code.visitLabel(L4);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Ljava/lang/Thread;","yield",new String[]{ },"V"));
                code.visitLabel(L20);
                code.visitFieldStmt(IGET_OBJECT,4,8,new Field("Lorg/mortbay/thread/QueuedThreadPool;","_threads","Ljava/util/Set;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 4},new Method("Ljava/util/Set;","size",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,4);
                code.visitJumpStmt(IF_EQZ,4,-1,L21);
                code.visitFieldStmt(IGET,4,8,new Field("Lorg/mortbay/thread/QueuedThreadPool;","_maxStopTimeMs","I"));
                code.visitJumpStmt(IF_LEZ,4,-1,L25);
                code.visitFieldStmt(IGET,4,8,new Field("Lorg/mortbay/thread/QueuedThreadPool;","_maxStopTimeMs","I"));
                code.visitStmt2R(INT_TO_LONG,4,4);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Ljava/lang/System;","currentTimeMillis",new String[]{ },"J"));
                code.visitStmt1R(MOVE_RESULT_WIDE,6);
                code.visitStmt2R(SUB_LONG_2ADDR,6,2);
                code.visitStmt3R(CMP_LONG,4,4,6);
                code.visitJumpStmt(IF_GEZ,4,-1,L25);
                code.visitLabel(L21);
                code.visitFieldStmt(IGET_OBJECT,4,8,new Field("Lorg/mortbay/thread/QueuedThreadPool;","_threads","Ljava/util/Set;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 4},new Method("Ljava/util/Set;","size",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,4);
                code.visitJumpStmt(IF_LEZ,4,-1,L23);
                code.visitLabel(L22);
                code.visitTypeStmt(NEW_INSTANCE,4,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 4},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitFieldStmt(IGET_OBJECT,5,8,new Field("Lorg/mortbay/thread/QueuedThreadPool;","_threads","Ljava/util/Set;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 5},new Method("Ljava/util/Set;","size",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,5},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "I"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitConstStmt(CONST_STRING,5," threads could not be stopped");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,5},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 4},new Method("Lorg/mortbay/log/Log;","warn",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L23);
                code.visitFieldStmt(IGET_OBJECT,4,8,new Field("Lorg/mortbay/thread/QueuedThreadPool;","_joinLock","Ljava/lang/Object;"));
                code.visitStmt1R(MONITOR_ENTER,4);
                code.visitLabel(L5);
                code.visitFieldStmt(IGET_OBJECT,5,8,new Field("Lorg/mortbay/thread/QueuedThreadPool;","_joinLock","Ljava/lang/Object;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Ljava/lang/Object;","notifyAll",new String[]{ },"V"));
                code.visitLabel(L24);
                code.visitStmt1R(MONITOR_EXIT,4);
                code.visitLabel(L6);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L25);
                code.visitStmt2R1N(MUL_INT_LIT8,4,0,100);
                code.visitStmt2R(INT_TO_LONG,4,4);
                code.visitLabel(L8);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 4,5},new Method("Ljava/lang/Thread;","sleep",new String[]{ "J"},"V"));
                code.visitLabel(L9);
                code.visitStmt2R1N(ADD_INT_LIT8,0,0,1);
                code.visitJumpStmt(GOTO,-1,-1,L16);
                code.visitLabel(L7);
                code.visitStmt1R(MOVE_EXCEPTION,5);
                code.visitLabel(L11);
                code.visitStmt1R(MONITOR_EXIT,4);
                code.visitLabel(L12);
                code.visitStmt1R(THROW,5);
                code.visitLabel(L10);
                code.visitStmt1R(MOVE_EXCEPTION,4);
                code.visitJumpStmt(GOTO,-1,-1,L9);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m022_getIdleThreads(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/thread/QueuedThreadPool;","getIdleThreads",new String[]{ },"I"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(151,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/thread/QueuedThreadPool;","_idle","Ljava/util/List;"));
                DexLabel L1=new DexLabel();
                code.visitJumpStmt(IF_NEZ,0,-1,L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                DexLabel L2=new DexLabel();
                code.visitLabel(L2);
                code.visitStmt1R(RETURN,0);
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/thread/QueuedThreadPool;","_idle","Ljava/util/List;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0},new Method("Ljava/util/List;","size",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m023_getLowThreads(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/thread/QueuedThreadPool;","getLowThreads",new String[]{ },"I"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(160,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET,0,1,new Field("Lorg/mortbay/thread/QueuedThreadPool;","_lowThreads","I"));
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m024_getMaxIdleTimeMs(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/thread/QueuedThreadPool;","getMaxIdleTimeMs",new String[]{ },"I"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(180,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET,0,1,new Field("Lorg/mortbay/thread/QueuedThreadPool;","_maxIdleTimeMs","I"));
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m025_getMaxQueued(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/thread/QueuedThreadPool;","getMaxQueued",new String[]{ },"I"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(169,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET,0,1,new Field("Lorg/mortbay/thread/QueuedThreadPool;","_maxQueued","I"));
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m026_getMaxStopTimeMs(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/thread/QueuedThreadPool;","getMaxStopTimeMs",new String[]{ },"I"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(265,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET,0,1,new Field("Lorg/mortbay/thread/QueuedThreadPool;","_maxStopTimeMs","I"));
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m027_getMaxThreads(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/thread/QueuedThreadPool;","getMaxThreads",new String[]{ },"I"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(191,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET,0,1,new Field("Lorg/mortbay/thread/QueuedThreadPool;","_maxThreads","I"));
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m028_getMinThreads(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/thread/QueuedThreadPool;","getMinThreads",new String[]{ },"I"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(202,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET,0,1,new Field("Lorg/mortbay/thread/QueuedThreadPool;","_minThreads","I"));
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m029_getName(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/thread/QueuedThreadPool;","getName",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(211,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/thread/QueuedThreadPool;","_name","Ljava/lang/String;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m030_getQueueSize(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/thread/QueuedThreadPool;","getQueueSize",new String[]{ },"I"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(236,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET,0,1,new Field("Lorg/mortbay/thread/QueuedThreadPool;","_queued","I"));
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m031_getSpawnOrShrinkAt(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/thread/QueuedThreadPool;","getSpawnOrShrinkAt",new String[]{ },"I"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(246,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET,0,1,new Field("Lorg/mortbay/thread/QueuedThreadPool;","_spawnOrShrinkAt","I"));
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m032_getThreads(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/thread/QueuedThreadPool;","getThreads",new String[]{ },"I"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(221,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/thread/QueuedThreadPool;","_threads","Ljava/util/Set;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0},new Method("Ljava/util/Set;","size",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m033_getThreadsPriority(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/thread/QueuedThreadPool;","getThreadsPriority",new String[]{ },"I"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(230,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET,0,1,new Field("Lorg/mortbay/thread/QueuedThreadPool;","_priority","I"));
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m034_isDaemon(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/thread/QueuedThreadPool;","isDaemon",new String[]{ },"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(283,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_BOOLEAN,0,1,new Field("Lorg/mortbay/thread/QueuedThreadPool;","_daemon","Z"));
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m035_isLowOnThreads(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/thread/QueuedThreadPool;","isLowOnThreads",new String[]{ },"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(289,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET,0,2,new Field("Lorg/mortbay/thread/QueuedThreadPool;","_queued","I"));
                code.visitFieldStmt(IGET,1,2,new Field("Lorg/mortbay/thread/QueuedThreadPool;","_lowThreads","I"));
                DexLabel L1=new DexLabel();
                code.visitJumpStmt(IF_LE,0,1,L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                DexLabel L2=new DexLabel();
                code.visitLabel(L2);
                code.visitStmt1R(RETURN,0);
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m036_join(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/thread/QueuedThreadPool;","join",new String[]{ },"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/lang/InterruptedException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexLabel L3=new DexLabel();
                DexLabel L4=new DexLabel();
                code.visitTryCatch(L3,L4,new DexLabel[]{L2},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L5=new DexLabel();
                ddv.visitPrologue(L5);
                ddv.visitLineNumber(295,L5);
                ddv.visitLineNumber(297,L0);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(298,L6);
                ddv.visitLineNumber(299,L2);
                ddv.visitLineNumber(302,L4);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(303,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(304,L8);
                code.visitLabel(L5);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/thread/QueuedThreadPool;","_joinLock","Ljava/lang/Object;"));
                code.visitStmt1R(MONITOR_ENTER,0);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/thread/QueuedThreadPool;","isRunning",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitJumpStmt(IF_EQZ,1,-1,L3);
                code.visitLabel(L6);
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/thread/QueuedThreadPool;","_joinLock","Ljava/lang/Object;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/lang/Object;","wait",new String[]{ },"V"));
                code.visitJumpStmt(GOTO,-1,-1,L0);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,1);
                code.visitStmt1R(MONITOR_EXIT,0);
                code.visitLabel(L1);
                code.visitStmt1R(THROW,1);
                code.visitLabel(L3);
                code.visitStmt1R(MONITOR_EXIT,0);
                code.visitLabel(L4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/thread/QueuedThreadPool;","isStopping",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_EQZ,0,-1,L8);
                code.visitLabel(L7);
                code.visitConstStmt(CONST_WIDE_16,0,Long.valueOf(100L)); // long: 0x0000000000000064  double:0.000000
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0,1},new Method("Ljava/lang/Thread;","sleep",new String[]{ "J"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L4);
                code.visitLabel(L8);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m037_newThread(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Lorg/mortbay/thread/QueuedThreadPool;","newThread",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(6);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L3=new DexLabel();
                ddv.visitPrologue(L3);
                ddv.visitLineNumber(455,L3);
                ddv.visitLineNumber(457,L0);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(459,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(460,L5);
                ddv.visitStartLocal(0,L5,"thread","Lorg/mortbay/thread/QueuedThreadPool$PoolThread;",null);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(461,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(462,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(469,L8);
                ddv.visitEndLocal(0,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(470,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(464,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(466,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(467,L12);
                ddv.visitLineNumber(469,L2);
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,1,5,new Field("Lorg/mortbay/thread/QueuedThreadPool;","_threadsLock","Ljava/lang/Object;"));
                code.visitStmt1R(MONITOR_ENTER,1);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,2,5,new Field("Lorg/mortbay/thread/QueuedThreadPool;","_threads","Ljava/util/Set;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 2},new Method("Ljava/util/Set;","size",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitFieldStmt(IGET,3,5,new Field("Lorg/mortbay/thread/QueuedThreadPool;","_maxThreads","I"));
                code.visitJumpStmt(IF_GE,2,3,L10);
                code.visitLabel(L4);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Lorg/mortbay/thread/QueuedThreadPool$PoolThread;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,5},new Method("Lorg/mortbay/thread/QueuedThreadPool$PoolThread;","<init>",new String[]{ "Lorg/mortbay/thread/QueuedThreadPool;"},"V"));
                code.visitLabel(L5);
                code.visitFieldStmt(IGET_OBJECT,2,5,new Field("Lorg/mortbay/thread/QueuedThreadPool;","_threads","Ljava/util/Set;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 2,0},new Method("Ljava/util/Set;","add",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitLabel(L6);
                code.visitTypeStmt(NEW_INSTANCE,2,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/lang/Object;","hashCode",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "I"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitConstStmt(CONST_STRING,3,"@");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitFieldStmt(IGET_OBJECT,3,5,new Field("Lorg/mortbay/thread/QueuedThreadPool;","_name","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitConstStmt(CONST_STRING,3,"-");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitFieldStmt(IGET,3,5,new Field("Lorg/mortbay/thread/QueuedThreadPool;","_id","I"));
                code.visitStmt2R1N(ADD_INT_LIT8,4,3,1);
                code.visitFieldStmt(IPUT,4,5,new Field("Lorg/mortbay/thread/QueuedThreadPool;","_id","I"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "I"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,2},new Method("Lorg/mortbay/thread/QueuedThreadPool$PoolThread;","setName",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/thread/QueuedThreadPool$PoolThread;","start",new String[]{ },"V"));
                code.visitLabel(L8);
                code.visitStmt1R(MONITOR_EXIT,1);
                code.visitLabel(L9);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L10);
                code.visitFieldStmt(IGET_BOOLEAN,2,5,new Field("Lorg/mortbay/thread/QueuedThreadPool;","_warned","Z"));
                code.visitJumpStmt(IF_NEZ,2,-1,L8);
                code.visitLabel(L11);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitFieldStmt(IPUT_BOOLEAN,2,5,new Field("Lorg/mortbay/thread/QueuedThreadPool;","_warned","Z"));
                code.visitLabel(L12);
                code.visitConstStmt(CONST_STRING,2,"Max threads for {}");
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 2,5},new Method("Lorg/mortbay/log/Log;","debug",new String[]{ "Ljava/lang/String;","Ljava/lang/Object;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L8);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,2);
                code.visitStmt1R(MONITOR_EXIT,1);
                code.visitLabel(L1);
                code.visitStmt1R(THROW,2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m038_setDaemon(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/thread/QueuedThreadPool;","setDaemon",new String[]{ "Z"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"daemon");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(312,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(313,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_BOOLEAN,1,0,new Field("Lorg/mortbay/thread/QueuedThreadPool;","_daemon","Z"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m039_setLowThreads(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/thread/QueuedThreadPool;","setLowThreads",new String[]{ "I"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"lowThreads");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(321,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(322,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT,1,0,new Field("Lorg/mortbay/thread/QueuedThreadPool;","_lowThreads","I"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m040_setMaxIdleTimeMs(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/thread/QueuedThreadPool;","setMaxIdleTimeMs",new String[]{ "I"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"maxIdleTimeMs");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(334,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(335,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT,1,0,new Field("Lorg/mortbay/thread/QueuedThreadPool;","_maxIdleTimeMs","I"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m041_setMaxStopTimeMs(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/thread/QueuedThreadPool;","setMaxStopTimeMs",new String[]{ "I"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"stopTimeMs");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(274,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(275,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT,1,0,new Field("Lorg/mortbay/thread/QueuedThreadPool;","_maxStopTimeMs","I"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m042_setMaxThreads(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/thread/QueuedThreadPool;","setMaxThreads",new String[]{ "I"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"maxThreads");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(345,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(346,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(347,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(348,L3);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/thread/QueuedThreadPool;","isStarted",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_EQZ,0,-1,L2);
                code.visitFieldStmt(IGET,0,2,new Field("Lorg/mortbay/thread/QueuedThreadPool;","_minThreads","I"));
                code.visitJumpStmt(IF_GE,3,0,L2);
                code.visitLabel(L1);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/lang/IllegalArgumentException;");
                code.visitConstStmt(CONST_STRING,1,"!minThreads<maxThreads");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1},new Method("Ljava/lang/IllegalArgumentException;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitStmt1R(THROW,0);
                code.visitLabel(L2);
                code.visitFieldStmt(IPUT,3,2,new Field("Lorg/mortbay/thread/QueuedThreadPool;","_maxThreads","I"));
                code.visitLabel(L3);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m043_setMinThreads(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/thread/QueuedThreadPool;","setMinThreads",new String[]{ "I"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexLabel L3=new DexLabel();
                DexLabel L4=new DexLabel();
                code.visitTryCatch(L3,L4,new DexLabel[]{L2},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"minThreads");
                DexLabel L5=new DexLabel();
                ddv.visitPrologue(L5);
                ddv.visitLineNumber(358,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(359,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(360,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(361,L8);
                ddv.visitLineNumber(363,L0);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(365,L9);
                ddv.visitLineNumber(367,L2);
                ddv.visitLineNumber(368,L4);
                code.visitLabel(L5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Lorg/mortbay/thread/QueuedThreadPool;","isStarted",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_EQZ,0,-1,L7);
                code.visitJumpStmt(IF_LEZ,4,-1,L6);
                code.visitFieldStmt(IGET,0,3,new Field("Lorg/mortbay/thread/QueuedThreadPool;","_maxThreads","I"));
                code.visitJumpStmt(IF_LE,4,0,L7);
                code.visitLabel(L6);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/lang/IllegalArgumentException;");
                code.visitConstStmt(CONST_STRING,1,"!0<=minThreads<maxThreads");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1},new Method("Ljava/lang/IllegalArgumentException;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitStmt1R(THROW,0);
                code.visitLabel(L7);
                code.visitFieldStmt(IPUT,4,3,new Field("Lorg/mortbay/thread/QueuedThreadPool;","_minThreads","I"));
                code.visitLabel(L8);
                code.visitFieldStmt(IGET_OBJECT,0,3,new Field("Lorg/mortbay/thread/QueuedThreadPool;","_threadsLock","Ljava/lang/Object;"));
                code.visitStmt1R(MONITOR_ENTER,0);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Lorg/mortbay/thread/QueuedThreadPool;","isStarted",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitJumpStmt(IF_EQZ,1,-1,L3);
                code.visitFieldStmt(IGET_OBJECT,1,3,new Field("Lorg/mortbay/thread/QueuedThreadPool;","_threads","Ljava/util/Set;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 1},new Method("Ljava/util/Set;","size",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitFieldStmt(IGET,2,3,new Field("Lorg/mortbay/thread/QueuedThreadPool;","_minThreads","I"));
                code.visitJumpStmt(IF_GE,1,2,L3);
                code.visitLabel(L9);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Lorg/mortbay/thread/QueuedThreadPool;","newThread",new String[]{ },"V"));
                code.visitJumpStmt(GOTO,-1,-1,L0);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,1);
                code.visitStmt1R(MONITOR_EXIT,0);
                code.visitLabel(L1);
                code.visitStmt1R(THROW,1);
                code.visitLabel(L3);
                code.visitStmt1R(MONITOR_EXIT,0);
                code.visitLabel(L4);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m044_setName(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/thread/QueuedThreadPool;","setName",new String[]{ "Ljava/lang/String;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"name");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(376,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(377,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_OBJECT,1,0,new Field("Lorg/mortbay/thread/QueuedThreadPool;","_name","Ljava/lang/String;"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m045_setSpawnOrShrinkAt(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/thread/QueuedThreadPool;","setSpawnOrShrinkAt",new String[]{ "I"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"spawnOrShrinkAt");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(256,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(257,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT,1,0,new Field("Lorg/mortbay/thread/QueuedThreadPool;","_spawnOrShrinkAt","I"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m046_setThreadsPriority(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/thread/QueuedThreadPool;","setThreadsPriority",new String[]{ "I"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"priority");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(385,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(386,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT,1,0,new Field("Lorg/mortbay/thread/QueuedThreadPool;","_priority","I"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m047_stopJob(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Lorg/mortbay/thread/QueuedThreadPool;","stopJob",new String[]{ "Ljava/lang/Thread;","Ljava/lang/Object;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"thread");
                ddv.visitParameterName(1,"job");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(482,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(483,L1);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/lang/Thread;","interrupt",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
