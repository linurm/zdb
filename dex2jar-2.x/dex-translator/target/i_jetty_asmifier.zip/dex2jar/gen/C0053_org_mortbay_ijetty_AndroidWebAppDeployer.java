package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0053_org_mortbay_ijetty_AndroidWebAppDeployer {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(ACC_PUBLIC,"Lorg/mortbay/ijetty/AndroidWebAppDeployer;","Lorg/mortbay/jetty/deployer/WebAppDeployer;",new String[]{ });
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("AndroidWebAppDeployer.java");
        f000__deployed(cv);
        f001__resolver(cv);
        m000__init_(cv);
        m001_doStart(cv);
        m002_doStop(cv);
        m003_getContentResolver(cv);
        m004_scan(cv);
        m005_setContentResolver(cv);
    }
    public static void f000__deployed(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/ijetty/AndroidWebAppDeployer;","_deployed","Ljava/util/ArrayList;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f001__resolver(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/ijetty/AndroidWebAppDeployer;","_resolver","Landroid/content/ContentResolver;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void m000__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/ijetty/AndroidWebAppDeployer;","<init>",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(50,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(53,L1);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1},new Method("Lorg/mortbay/jetty/deployer/WebAppDeployer;","<init>",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/ijetty/AndroidWebAppDeployer;","_resolver","Landroid/content/ContentResolver;"));
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001_doStart(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/ijetty/AndroidWebAppDeployer;","doStart",new String[]{ },"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/lang/Exception;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(71,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(72,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(74,L2);
                code.visitLabel(L0);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/util/ArrayList;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/util/ArrayList;","<init>",new String[]{ },"V"));
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/ijetty/AndroidWebAppDeployer;","_deployed","Ljava/util/ArrayList;"));
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Lorg/mortbay/ijetty/AndroidWebAppDeployer;","scan",new String[]{ },"V"));
                code.visitLabel(L2);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m002_doStop(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/ijetty/AndroidWebAppDeployer;","doStop",new String[]{ },"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/lang/Exception;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(213,L0);
                DexLabel L1=new DexLabel();
                ddv.visitStartLocal(0,L1,"i","I",null);
                DexLabel L2=new DexLabel();
                ddv.visitEndLocal(0,L2);
                ddv.visitStartLocal(1,L2,"i","I",null);
                DexLabel L3=new DexLabel();
                ddv.visitRestartLocal(0,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(215,L4);
                ddv.visitEndLocal(1,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(216,L5);
                ddv.visitStartLocal(2,L5,"wac","Lorg/mortbay/jetty/handler/ContextHandler;",null);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(217,L6);
                ddv.visitRestartLocal(1,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(218,L7);
                ddv.visitEndLocal(2,L7);
                ddv.visitEndLocal(1,L7);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,3,4,new Field("Lorg/mortbay/ijetty/AndroidWebAppDeployer;","_deployed","Ljava/util/ArrayList;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Ljava/util/ArrayList;","size",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitLabel(L1);
                code.visitStmt2R(MOVE,1,0);
                code.visitLabel(L2);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitStmt3R(SUB_INT,0,1,3);
                code.visitLabel(L3);
                code.visitJumpStmt(IF_LEZ,1,-1,L7);
                code.visitLabel(L4);
                code.visitFieldStmt(IGET_OBJECT,3,4,new Field("Lorg/mortbay/ijetty/AndroidWebAppDeployer;","_deployed","Ljava/util/ArrayList;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,0},new Method("Ljava/util/ArrayList;","get",new String[]{ "I"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitTypeStmt(CHECK_CAST,2,-1,"Lorg/mortbay/jetty/handler/ContextHandler;");
                code.visitLabel(L5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/jetty/handler/ContextHandler;","stop",new String[]{ },"V"));
                code.visitStmt2R(MOVE,1,0);
                code.visitLabel(L6);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitLabel(L7);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m003_getContentResolver(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/ijetty/AndroidWebAppDeployer;","getContentResolver",new String[]{ },"Landroid/content/ContentResolver;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(62,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/ijetty/AndroidWebAppDeployer;","_resolver","Landroid/content/ContentResolver;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m004_scan(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/ijetty/AndroidWebAppDeployer;","scan",new String[]{ },"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/lang/Exception;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(18);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ "Ljava/lang/Exception;"});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L3=new DexLabel();
                ddv.visitPrologue(L3);
                ddv.visitLineNumber(84,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(85,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(87,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(88,L6);
                ddv.visitStartLocal(11,L6,"r","Lorg/mortbay/resource/Resource;",null);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(89,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(91,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(92,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(95,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(97,L11);
                ddv.visitStartLocal(7,L11,"files","[Ljava/lang/String;",null);
                DexLabel L12=new DexLabel();
                ddv.visitStartLocal(6,L12,"f","I",null);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(99,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(101,L14);
                ddv.visitStartLocal(3,L14,"context","Ljava/lang/String;",null);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(97,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(105,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(107,L17);
                ddv.visitStartLocal(1,L17,"app","Lorg/mortbay/resource/Resource;",null);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(110,L18);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(111,L19);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(113,L20);
                ddv.visitStartLocal(12,L20,"unpacked","Lorg/mortbay/resource/Resource;",null);
                DexLabel L21=new DexLabel();
                ddv.visitLineNumber(116,L21);
                DexLabel L22=new DexLabel();
                ddv.visitLineNumber(120,L22);
                ddv.visitEndLocal(12,L22);
                DexLabel L23=new DexLabel();
                ddv.visitLineNumber(122,L23);
                DexLabel L24=new DexLabel();
                ddv.visitLineNumber(126,L24);
                DexLabel L25=new DexLabel();
                ddv.visitLineNumber(128,L25);
                DexLabel L26=new DexLabel();
                ddv.visitLineNumber(131,L26);
                ddv.visitRestartLocal(3,L26);
                DexLabel L27=new DexLabel();
                ddv.visitLineNumber(132,L27);
                DexLabel L28=new DexLabel();
                ddv.visitLineNumber(136,L28);
                ddv.visitRestartLocal(3,L28);
                DexLabel L29=new DexLabel();
                ddv.visitLineNumber(138,L29);
                DexLabel L30=new DexLabel();
                ddv.visitLineNumber(140,L30);
                ddv.visitStartLocal(9,L30,"installed","[Lorg/mortbay/jetty/Handler;",null);
                DexLabel L31=new DexLabel();
                ddv.visitStartLocal(8,L31,"i","I",null);
                DexLabel L32=new DexLabel();
                ddv.visitLineNumber(142,L32);
                DexLabel L33=new DexLabel();
                ddv.visitLineNumber(144,L33);
                ddv.visitStartLocal(2,L33,"c","Lorg/mortbay/jetty/handler/ContextHandler;",null);
                DexLabel L34=new DexLabel();
                ddv.visitLineNumber(145,L34);
                DexLabel L35=new DexLabel();
                ddv.visitLineNumber(130,L35);
                ddv.visitEndLocal(9,L35);
                ddv.visitEndLocal(8,L35);
                ddv.visitEndLocal(2,L35);
                DexLabel L36=new DexLabel();
                ddv.visitRestartLocal(3,L36);
                DexLabel L37=new DexLabel();
                ddv.visitLineNumber(150,L37);
                ddv.visitRestartLocal(2,L37);
                ddv.visitRestartLocal(8,L37);
                ddv.visitRestartLocal(9,L37);
                DexLabel L38=new DexLabel();
                ddv.visitLineNumber(151,L38);
                DexLabel L39=new DexLabel();
                ddv.visitEndLocal(2,L39);
                DexLabel L40=new DexLabel();
                ddv.visitLineNumber(156,L40);
                ddv.visitStartLocal(10,L40,"path","Ljava/lang/String;",null);
                DexLabel L41=new DexLabel();
                ddv.visitLineNumber(158,L41);
                DexLabel L42=new DexLabel();
                ddv.visitLineNumber(153,L42);
                ddv.visitEndLocal(10,L42);
                ddv.visitRestartLocal(2,L42);
                DexLabel L43=new DexLabel();
                ddv.visitRestartLocal(10,L43);
                DexLabel L44=new DexLabel();
                ddv.visitEndLocal(10,L44);
                DexLabel L45=new DexLabel();
                ddv.visitLineNumber(140,L45);
                ddv.visitEndLocal(2,L45);
                ddv.visitRestartLocal(10,L45);
                DexLabel L46=new DexLabel();
                ddv.visitLineNumber(166,L46);
                ddv.visitEndLocal(8,L46);
                ddv.visitEndLocal(9,L46);
                ddv.visitEndLocal(10,L46);
                DexLabel L47=new DexLabel();
                ddv.visitLineNumber(167,L47);
                ddv.visitStartLocal(13,L47,"wah","Lorg/mortbay/jetty/webapp/WebAppContext;",null);
                DexLabel L48=new DexLabel();
                ddv.visitLineNumber(168,L48);
                ddv.visitStartLocal(4,L48,"contexts","Lorg/mortbay/jetty/HandlerContainer;",null);
                ddv.visitLineNumber(174,L0);
                DexLabel L49=new DexLabel();
                ddv.visitEndLocal(13,L49);
                ddv.visitLineNumber(187,L1);
                ddv.visitRestartLocal(13,L1);
                DexLabel L50=new DexLabel();
                ddv.visitLineNumber(189,L50);
                DexLabel L51=new DexLabel();
                ddv.visitLineNumber(191,L51);
                DexLabel L52=new DexLabel();
                ddv.visitLineNumber(195,L52);
                DexLabel L53=new DexLabel();
                ddv.visitLineNumber(197,L53);
                DexLabel L54=new DexLabel();
                ddv.visitLineNumber(199,L54);
                DexLabel L55=new DexLabel();
                ddv.visitLineNumber(200,L55);
                DexLabel L56=new DexLabel();
                ddv.visitLineNumber(201,L56);
                DexLabel L57=new DexLabel();
                ddv.visitLineNumber(202,L57);
                DexLabel L58=new DexLabel();
                ddv.visitLineNumber(203,L58);
                DexLabel L59=new DexLabel();
                ddv.visitLineNumber(205,L59);
                DexLabel L60=new DexLabel();
                ddv.visitLineNumber(206,L60);
                DexLabel L61=new DexLabel();
                ddv.visitLineNumber(207,L61);
                ddv.visitLineNumber(176,L2);
                ddv.visitEndLocal(13,L2);
                DexLabel L62=new DexLabel();
                ddv.visitLineNumber(178,L62);
                ddv.visitStartLocal(5,L62,"e","Ljava/lang/Exception;",null);
                DexLabel L63=new DexLabel();
                ddv.visitLineNumber(183,L63);
                ddv.visitEndLocal(5,L63);
                ddv.visitRestartLocal(13,L63);
                DexLabel L64=new DexLabel();
                ddv.visitEndLocal(13,L64);
                DexLabel L65=new DexLabel();
                ddv.visitRestartLocal(13,L65);
                DexLabel L66=new DexLabel();
                ddv.visitLineNumber(209,L66);
                ddv.visitEndLocal(1,L66);
                ddv.visitEndLocal(3,L66);
                ddv.visitEndLocal(4,L66);
                ddv.visitEndLocal(13,L66);
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 17},new Method("Lorg/mortbay/ijetty/AndroidWebAppDeployer;","getContexts",new String[]{ },"Lorg/mortbay/jetty/HandlerContainer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,14);
                code.visitJumpStmt(IF_NEZ,14,-1,L5);
                code.visitLabel(L4);
                code.visitTypeStmt(NEW_INSTANCE,14,-1,"Ljava/lang/IllegalArgumentException;");
                code.visitConstStmt(CONST_STRING,15,"No HandlerContainer");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 14,15},new Method("Ljava/lang/IllegalArgumentException;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitStmt1R(THROW,14);
                code.visitLabel(L5);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 17},new Method("Lorg/mortbay/ijetty/AndroidWebAppDeployer;","getWebAppDir",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,14);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 14},new Method("Lorg/mortbay/resource/Resource;","newResource",new String[]{ "Ljava/lang/String;"},"Lorg/mortbay/resource/Resource;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,11);
                code.visitLabel(L6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 11},new Method("Lorg/mortbay/resource/Resource;","exists",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,14);
                code.visitJumpStmt(IF_NEZ,14,-1,L8);
                code.visitLabel(L7);
                code.visitTypeStmt(NEW_INSTANCE,14,-1,"Ljava/lang/IllegalArgumentException;");
                code.visitTypeStmt(NEW_INSTANCE,15,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 15},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,16,"No such webapps resource ");
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 15,16},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,15);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 15,11},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,15);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 15},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,15);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 14,15},new Method("Ljava/lang/IllegalArgumentException;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitStmt1R(THROW,14);
                code.visitLabel(L8);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 11},new Method("Lorg/mortbay/resource/Resource;","isDirectory",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,14);
                code.visitJumpStmt(IF_NEZ,14,-1,L10);
                code.visitLabel(L9);
                code.visitTypeStmt(NEW_INSTANCE,14,-1,"Ljava/lang/IllegalArgumentException;");
                code.visitTypeStmt(NEW_INSTANCE,15,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 15},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,16,"Not directory webapps resource ");
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 15,16},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,15);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 15,11},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,15);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 15},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,15);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 14,15},new Method("Ljava/lang/IllegalArgumentException;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitStmt1R(THROW,14);
                code.visitLabel(L10);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 11},new Method("Lorg/mortbay/resource/Resource;","list",new String[]{ },"[Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitLabel(L11);
                code.visitConstStmt(CONST_4,6, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L12);
                code.visitJumpStmt(IF_EQZ,7,-1,L66);
                code.visitStmt2R(ARRAY_LENGTH,14,7);
                code.visitJumpStmt(IF_GE,6,14,L66);
                code.visitLabel(L13);
                code.visitStmt3R(AGET_OBJECT,3,7,6);
                code.visitLabel(L14);
                code.visitConstStmt(CONST_STRING,14,"CVS/");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,14},new Method("Ljava/lang/String;","equalsIgnoreCase",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,14);
                code.visitJumpStmt(IF_NEZ,14,-1,L15);
                code.visitConstStmt(CONST_STRING,14,"CVS");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,14},new Method("Ljava/lang/String;","equalsIgnoreCase",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,14);
                code.visitJumpStmt(IF_NEZ,14,-1,L15);
                code.visitConstStmt(CONST_STRING,14,".");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,14},new Method("Ljava/lang/String;","startsWith",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,14);
                code.visitJumpStmt(IF_EQZ,14,-1,L16);
                code.visitLabel(L15);
                code.visitStmt2R1N(ADD_INT_LIT8,6,6,1);
                code.visitJumpStmt(GOTO,-1,-1,L12);
                code.visitLabel(L16);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 11,3},new Method("Lorg/mortbay/resource/Resource;","encode",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,14);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 11,14},new Method("Lorg/mortbay/resource/Resource;","addPath",new String[]{ "Ljava/lang/String;"},"Lorg/mortbay/resource/Resource;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L17);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Ljava/lang/String;","toLowerCase",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,14);
                code.visitConstStmt(CONST_STRING,15,".war");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 14,15},new Method("Ljava/lang/String;","endsWith",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,14);
                code.visitJumpStmt(IF_NEZ,14,-1,L18);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Ljava/lang/String;","toLowerCase",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,14);
                code.visitConstStmt(CONST_STRING,15,".jar");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 14,15},new Method("Ljava/lang/String;","endsWith",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,14);
                code.visitJumpStmt(IF_EQZ,14,-1,L22);
                code.visitLabel(L18);
                code.visitConstStmt(CONST_4,14, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Ljava/lang/String;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,15);
                code.visitConstStmt(CONST_16,16, Integer.valueOf(4)); // int: 0x00000004  float:0.000000
                code.visitStmt3R(SUB_INT,15,15,16);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,14,15},new Method("Ljava/lang/String;","substring",new String[]{ "I","I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitLabel(L19);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 11,3},new Method("Lorg/mortbay/resource/Resource;","addPath",new String[]{ "Ljava/lang/String;"},"Lorg/mortbay/resource/Resource;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,12);
                code.visitLabel(L20);
                code.visitJumpStmt(IF_EQZ,12,-1,L24);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 12},new Method("Lorg/mortbay/resource/Resource;","exists",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,14);
                code.visitJumpStmt(IF_EQZ,14,-1,L24);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 12},new Method("Lorg/mortbay/resource/Resource;","isDirectory",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,14);
                code.visitJumpStmt(IF_EQZ,14,-1,L24);
                code.visitLabel(L21);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Lorg/mortbay/log/Log;","isDebugEnabled",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,14);
                code.visitJumpStmt(IF_EQZ,14,-1,L15);
                code.visitTypeStmt(NEW_INSTANCE,14,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 14},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 14,3},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,14);
                code.visitConstStmt(CONST_STRING,15," already exists.");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 14,15},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,14);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 14},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,14);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 14},new Method("Lorg/mortbay/log/Log;","debug",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L15);
                code.visitLabel(L22);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Lorg/mortbay/resource/Resource;","isDirectory",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,14);
                code.visitJumpStmt(IF_NEZ,14,-1,L24);
                code.visitLabel(L23);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Lorg/mortbay/log/Log;","isDebugEnabled",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,14);
                code.visitJumpStmt(IF_EQZ,14,-1,L15);
                code.visitTypeStmt(NEW_INSTANCE,14,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 14},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 14,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,14);
                code.visitConstStmt(CONST_STRING,15," Not directory");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 14,15},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,14);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 14},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,14);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 14},new Method("Lorg/mortbay/log/Log;","debug",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitJumpStmt(GOTO_16,-1,-1,L15);
                code.visitLabel(L24);
                code.visitConstStmt(CONST_STRING,14,"root");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,14},new Method("Ljava/lang/String;","equalsIgnoreCase",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,14);
                code.visitJumpStmt(IF_NEZ,14,-1,L25);
                code.visitConstStmt(CONST_STRING,14,"root/");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,14},new Method("Ljava/lang/String;","equalsIgnoreCase",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,14);
                code.visitJumpStmt(IF_EQZ,14,-1,L35);
                code.visitLabel(L25);
                code.visitConstStmt(CONST_STRING,3,"/");
                code.visitLabel(L26);
                code.visitConstStmt(CONST_STRING,14,"/");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,14},new Method("Ljava/lang/String;","endsWith",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,14);
                code.visitJumpStmt(IF_EQZ,14,-1,L28);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Ljava/lang/String;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,14);
                code.visitJumpStmt(IF_LEZ,14,-1,L28);
                code.visitLabel(L27);
                code.visitConstStmt(CONST_4,14, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Ljava/lang/String;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,15);
                code.visitConstStmt(CONST_16,16, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitStmt3R(SUB_INT,15,15,16);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,14,15},new Method("Ljava/lang/String;","substring",new String[]{ "I","I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitLabel(L28);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 17},new Method("Lorg/mortbay/ijetty/AndroidWebAppDeployer;","getAllowDuplicates",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,14);
                code.visitJumpStmt(IF_NEZ,14,-1,L46);
                code.visitLabel(L29);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 17},new Method("Lorg/mortbay/ijetty/AndroidWebAppDeployer;","getContexts",new String[]{ },"Lorg/mortbay/jetty/HandlerContainer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,14);
                code.visitConstStmt(CONST_CLASS,15,new DexType("Lorg/mortbay/jetty/handler/ContextHandler;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 14,15},new Method("Lorg/mortbay/jetty/HandlerContainer;","getChildHandlersByClass",new String[]{ "Ljava/lang/Class;"},"[Lorg/mortbay/jetty/Handler;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,9);
                code.visitLabel(L30);
                code.visitConstStmt(CONST_4,8, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L31);
                code.visitStmt2R(ARRAY_LENGTH,14,9);
                code.visitJumpStmt(IF_GE,8,14,L46);
                code.visitLabel(L32);
                code.visitStmt3R(AGET_OBJECT,2,9,8);
                code.visitTypeStmt(CHECK_CAST,2,-1,"Lorg/mortbay/jetty/handler/ContextHandler;");
                code.visitLabel(L33);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/jetty/handler/ContextHandler;","getContextPath",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,14);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,14},new Method("Ljava/lang/String;","equals",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,14);
                code.visitJumpStmt(IF_EQZ,14,-1,L37);
                code.visitLabel(L34);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Lorg/mortbay/log/Log;","isDebugEnabled",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,14);
                code.visitJumpStmt(IF_EQZ,14,-1,L15);
                code.visitTypeStmt(NEW_INSTANCE,14,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 14},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 14,3},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,14);
                code.visitConstStmt(CONST_STRING,15," Context were equal; duplicate!");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 14,15},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,14);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 14},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,14);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 14},new Method("Lorg/mortbay/log/Log;","debug",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitJumpStmt(GOTO_16,-1,-1,L15);
                code.visitLabel(L35);
                code.visitTypeStmt(NEW_INSTANCE,14,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 14},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,15,"/");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 14,15},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,14);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 14,3},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,14);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 14},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitLabel(L36);
                code.visitJumpStmt(GOTO,-1,-1,L26);
                code.visitLabel(L37);
                code.visitTypeStmt(INSTANCE_OF,14,2,"Lorg/mortbay/jetty/webapp/WebAppContext;");
                code.visitJumpStmt(IF_EQZ,14,-1,L42);
                code.visitLabel(L38);
                code.visitTypeStmt(CHECK_CAST,2,-1,"Lorg/mortbay/jetty/webapp/WebAppContext;");
                code.visitLabel(L39);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/jetty/webapp/WebAppContext;","getWar",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,10);
                code.visitLabel(L40);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Lorg/mortbay/resource/Resource;","getFile",new String[]{ },"Ljava/io/File;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,14);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 14},new Method("Ljava/io/File;","getAbsolutePath",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,14);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10,14},new Method("Ljava/lang/String;","equals",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,14);
                code.visitJumpStmt(IF_EQZ,14,-1,L45);
                code.visitLabel(L41);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Lorg/mortbay/log/Log;","isDebugEnabled",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,14);
                code.visitJumpStmt(IF_EQZ,14,-1,L15);
                code.visitTypeStmt(NEW_INSTANCE,14,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 14},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 14,10},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,14);
                code.visitConstStmt(CONST_STRING,15," Paths were equal; duplicate!");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 14,15},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,14);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 14},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,14);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 14},new Method("Lorg/mortbay/log/Log;","debug",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitJumpStmt(GOTO_16,-1,-1,L15);
                code.visitLabel(L42);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/jetty/handler/ContextHandler;","getBaseResource",new String[]{ },"Lorg/mortbay/resource/Resource;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,14);
                code.visitJumpStmt(IF_NEZ,14,-1,L44);
                code.visitConstStmt(CONST_STRING,14,"");
                code.visitStmt2R(MOVE_OBJECT,10,14);
                code.visitLabel(L43);
                code.visitJumpStmt(GOTO,-1,-1,L40);
                code.visitLabel(L44);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/jetty/handler/ContextHandler;","getBaseResource",new String[]{ },"Lorg/mortbay/resource/Resource;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,14);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 14},new Method("Lorg/mortbay/resource/Resource;","getFile",new String[]{ },"Ljava/io/File;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,14);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 14},new Method("Ljava/io/File;","getAbsolutePath",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,14);
                code.visitStmt2R(MOVE_OBJECT,10,14);
                code.visitJumpStmt(GOTO,-1,-1,L43);
                code.visitLabel(L45);
                code.visitStmt2R1N(ADD_INT_LIT8,8,8,1);
                code.visitJumpStmt(GOTO_16,-1,-1,L31);
                code.visitLabel(L46);
                code.visitConstStmt(CONST_4,13, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L47);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 17},new Method("Lorg/mortbay/ijetty/AndroidWebAppDeployer;","getContexts",new String[]{ },"Lorg/mortbay/jetty/HandlerContainer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitLabel(L48);
                code.visitTypeStmt(INSTANCE_OF,14,4,"Lorg/mortbay/jetty/handler/ContextHandlerCollection;");
                code.visitJumpStmt(IF_EQZ,14,-1,L63);
                code.visitConstStmt(CONST_CLASS,14,new DexType("Lorg/mortbay/jetty/webapp/WebAppContext;"));
                code.visitStmt2R(MOVE_OBJECT,0,4);
                code.visitTypeStmt(CHECK_CAST,0,-1,"Lorg/mortbay/jetty/handler/ContextHandlerCollection;");
                code.visitStmt2R(MOVE_OBJECT,5,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Lorg/mortbay/jetty/handler/ContextHandlerCollection;","getContextClass",new String[]{ },"Ljava/lang/Class;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,15);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 14,15},new Method("Ljava/lang/Class;","isAssignableFrom",new String[]{ "Ljava/lang/Class;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,14);
                code.visitJumpStmt(IF_EQZ,14,-1,L63);
                code.visitLabel(L0);
                code.visitStmt2R(MOVE_OBJECT,0,4);
                code.visitTypeStmt(CHECK_CAST,0,-1,"Lorg/mortbay/jetty/handler/ContextHandlerCollection;");
                code.visitStmt2R(MOVE_OBJECT,5,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Lorg/mortbay/jetty/handler/ContextHandlerCollection;","getContextClass",new String[]{ },"Ljava/lang/Class;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,14);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 14},new Method("Ljava/lang/Class;","newInstance",new String[]{ },"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,13);
                code.visitLabel(L49);
                code.visitTypeStmt(CHECK_CAST,13,-1,"Lorg/mortbay/jetty/webapp/WebAppContext;");
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 13,3},new Method("Lorg/mortbay/jetty/webapp/WebAppContext;","setContextPath",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L50);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 17},new Method("Lorg/mortbay/ijetty/AndroidWebAppDeployer;","getConfigurationClasses",new String[]{ },"[Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,14);
                code.visitJumpStmt(IF_EQZ,14,-1,L52);
                code.visitLabel(L51);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 17},new Method("Lorg/mortbay/ijetty/AndroidWebAppDeployer;","getConfigurationClasses",new String[]{ },"[Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,14);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 13,14},new Method("Lorg/mortbay/jetty/webapp/WebAppContext;","setConfigurationClasses",new String[]{ "[Ljava/lang/String;"},"V"));
                code.visitLabel(L52);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 17},new Method("Lorg/mortbay/ijetty/AndroidWebAppDeployer;","getDefaultsDescriptor",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,14);
                code.visitJumpStmt(IF_EQZ,14,-1,L54);
                code.visitLabel(L53);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 17},new Method("Lorg/mortbay/ijetty/AndroidWebAppDeployer;","getDefaultsDescriptor",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,14);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 13,14},new Method("Lorg/mortbay/jetty/webapp/WebAppContext;","setDefaultsDescriptor",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L54);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 17},new Method("Lorg/mortbay/ijetty/AndroidWebAppDeployer;","isExtract",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,14);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 13,14},new Method("Lorg/mortbay/jetty/webapp/WebAppContext;","setExtractWAR",new String[]{ "Z"},"V"));
                code.visitLabel(L55);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/lang/Object;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,14);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 13,14},new Method("Lorg/mortbay/jetty/webapp/WebAppContext;","setWar",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L56);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 17},new Method("Lorg/mortbay/ijetty/AndroidWebAppDeployer;","isParentLoaderPriority",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,14);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 13,14},new Method("Lorg/mortbay/jetty/webapp/WebAppContext;","setParentLoaderPriority",new String[]{ "Z"},"V"));
                code.visitLabel(L57);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,17);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/ijetty/AndroidWebAppDeployer;","_resolver","Landroid/content/ContentResolver;"));
                code.visitStmt2R(MOVE_OBJECT,14,0);
                code.visitJumpStmt(IF_EQZ,14,-1,L59);
                code.visitLabel(L58);
                code.visitConstStmt(CONST_STRING,14,"contentResolver");
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,17);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/ijetty/AndroidWebAppDeployer;","_resolver","Landroid/content/ContentResolver;"));
                code.visitStmt2R(MOVE_OBJECT,15,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 13,14,15},new Method("Lorg/mortbay/jetty/webapp/WebAppContext;","setAttribute",new String[]{ "Ljava/lang/String;","Ljava/lang/Object;"},"V"));
                code.visitLabel(L59);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Lorg/mortbay/log/Log;","isDebugEnabled",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,14);
                code.visitJumpStmt(IF_EQZ,14,-1,L60);
                code.visitTypeStmt(NEW_INSTANCE,14,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 14},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,15,"AndroidWebAppDeployer: prepared ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 14,15},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,14);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/lang/Object;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,15);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 14,15},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,14);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 14},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,14);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 14},new Method("Lorg/mortbay/log/Log;","debug",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L60);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 4,13},new Method("Lorg/mortbay/jetty/HandlerContainer;","addHandler",new String[]{ "Lorg/mortbay/jetty/Handler;"},"V"));
                code.visitLabel(L61);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,17);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/ijetty/AndroidWebAppDeployer;","_deployed","Ljava/util/ArrayList;"));
                code.visitStmt2R(MOVE_OBJECT,14,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 14,13},new Method("Ljava/util/ArrayList;","add",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitJumpStmt(GOTO_16,-1,-1,L15);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,14);
                code.visitStmt2R(MOVE_OBJECT,5,14);
                code.visitLabel(L62);
                code.visitTypeStmt(NEW_INSTANCE,14,-1,"Ljava/lang/Error;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 14,5},new Method("Ljava/lang/Error;","<init>",new String[]{ "Ljava/lang/Throwable;"},"V"));
                code.visitStmt1R(THROW,14);
                code.visitLabel(L63);
                code.visitTypeStmt(NEW_INSTANCE,13,-1,"Lorg/mortbay/jetty/webapp/WebAppContext;");
                code.visitLabel(L64);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 13},new Method("Lorg/mortbay/jetty/webapp/WebAppContext;","<init>",new String[]{ },"V"));
                code.visitLabel(L65);
                code.visitJumpStmt(GOTO,-1,-1,L1);
                code.visitLabel(L66);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m005_setContentResolver(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/ijetty/AndroidWebAppDeployer;","setContentResolver",new String[]{ "Landroid/content/ContentResolver;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"resolver");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(57,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(58,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_OBJECT,1,0,new Field("Lorg/mortbay/ijetty/AndroidWebAppDeployer;","_resolver","Landroid/content/ContentResolver;"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
