package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0283_org_mortbay_jetty_security_HTAccessHandler_HTAccess {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(0,"Lorg/mortbay/jetty/security/HTAccessHandler$HTAccess;","Ljava/lang/Object;",new String[]{ });
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("HTAccessHandler.java");
        if(cv!=null){
            DexAnnotationVisitor av00 = cv.visitAnnotation("Ldalvik/annotation/EnclosingClass;", Visibility.SYSTEM);
            if(av00 != null) {
                av00.visit("value", new DexType("Lorg/mortbay/jetty/security/HTAccessHandler;"));
                av00.visitEnd();
            }
        }
        if(cv!=null){
            DexAnnotationVisitor av00 = cv.visitAnnotation("Ldalvik/annotation/InnerClass;", Visibility.SYSTEM);
            if(av00 != null) {
                av00.visit("accessFlags",  Integer.valueOf(10));
                av00.visit("name", "HTAccess");
                av00.visitEnd();
            }
        }
        f000_ALL(cv);
        f001_ANY(cv);
        f002_GROUP(cv);
        f003_USER(cv);
        f004_VALID_USER(cv);
        f005__allowList(cv);
        f006__denyList(cv);
        f007__forbidden(cv);
        f008__groupFile(cv);
        f009__groupModified(cv);
        f010__groupResource(cv);
        f011__groups(cv);
        f012__lastModified(cv);
        f013__methods(cv);
        f014__name(cv);
        f015__order(cv);
        f016__requireEntities(cv);
        f017__requireName(cv);
        f018__satisfy(cv);
        f019__type(cv);
        f020__userFile(cv);
        f021__userModified(cv);
        f022__userResource(cv);
        f023__users(cv);
        m000__init_(cv);
        m001_getUserCode(cv);
        m002_getUserGroups(cv);
        m003_parse(cv);
        m004_checkAccess(cv);
        m005_checkAuth(cv);
        m006_getGroupResource(cv);
        m007_getLastModified(cv);
        m008_getMethods(cv);
        m009_getName(cv);
        m010_getSatisfy(cv);
        m011_getType(cv);
        m012_getUserResource(cv);
        m013_isAccessLimited(cv);
        m014_isAuthLimited(cv);
        m015_isForbidden(cv);
        m016_toString(cv);
    }
    public static void f000_ALL(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/security/HTAccessHandler$HTAccess;","ALL","I"),  Integer.valueOf(1));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f001_ANY(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/security/HTAccessHandler$HTAccess;","ANY","I"),  Integer.valueOf(0));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f002_GROUP(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/security/HTAccessHandler$HTAccess;","GROUP","Ljava/lang/String;"), "group");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f003_USER(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/security/HTAccessHandler$HTAccess;","USER","Ljava/lang/String;"), "user");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f004_VALID_USER(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/security/HTAccessHandler$HTAccess;","VALID_USER","Ljava/lang/String;"), "valid-user");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f005__allowList(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(0, new Field("Lorg/mortbay/jetty/security/HTAccessHandler$HTAccess;","_allowList","Ljava/util/ArrayList;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f006__denyList(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(0, new Field("Lorg/mortbay/jetty/security/HTAccessHandler$HTAccess;","_denyList","Ljava/util/ArrayList;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f007__forbidden(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(0, new Field("Lorg/mortbay/jetty/security/HTAccessHandler$HTAccess;","_forbidden","Z"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f008__groupFile(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(0, new Field("Lorg/mortbay/jetty/security/HTAccessHandler$HTAccess;","_groupFile","Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f009__groupModified(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(0, new Field("Lorg/mortbay/jetty/security/HTAccessHandler$HTAccess;","_groupModified","J"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f010__groupResource(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(0, new Field("Lorg/mortbay/jetty/security/HTAccessHandler$HTAccess;","_groupResource","Lorg/mortbay/resource/Resource;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f011__groups(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(0, new Field("Lorg/mortbay/jetty/security/HTAccessHandler$HTAccess;","_groups","Ljava/util/HashMap;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f012__lastModified(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(0, new Field("Lorg/mortbay/jetty/security/HTAccessHandler$HTAccess;","_lastModified","J"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f013__methods(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(0, new Field("Lorg/mortbay/jetty/security/HTAccessHandler$HTAccess;","_methods","Ljava/util/HashMap;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f014__name(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(0, new Field("Lorg/mortbay/jetty/security/HTAccessHandler$HTAccess;","_name","Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f015__order(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(0, new Field("Lorg/mortbay/jetty/security/HTAccessHandler$HTAccess;","_order","I"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f016__requireEntities(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(0, new Field("Lorg/mortbay/jetty/security/HTAccessHandler$HTAccess;","_requireEntities","Ljava/util/HashSet;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f017__requireName(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(0, new Field("Lorg/mortbay/jetty/security/HTAccessHandler$HTAccess;","_requireName","Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f018__satisfy(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(0, new Field("Lorg/mortbay/jetty/security/HTAccessHandler$HTAccess;","_satisfy","I"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f019__type(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(0, new Field("Lorg/mortbay/jetty/security/HTAccessHandler$HTAccess;","_type","Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f020__userFile(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(0, new Field("Lorg/mortbay/jetty/security/HTAccessHandler$HTAccess;","_userFile","Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f021__userModified(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(0, new Field("Lorg/mortbay/jetty/security/HTAccessHandler$HTAccess;","_userModified","J"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f022__userResource(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(0, new Field("Lorg/mortbay/jetty/security/HTAccessHandler$HTAccess;","_userResource","Lorg/mortbay/resource/Resource;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f023__users(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(0, new Field("Lorg/mortbay/jetty/security/HTAccessHandler$HTAccess;","_users","Ljava/util/HashMap;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void m000__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/jetty/security/HTAccessHandler$HTAccess;","<init>",new String[]{ "Lorg/mortbay/resource/Resource;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(10);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ "Ljava/io/IOException;"});
                DexLabel L3=new DexLabel();
                DexLabel L4=new DexLabel();
                code.visitTryCatch(L1,L3,new DexLabel[]{L4},new String[]{ "Ljava/io/IOException;"});
                DexLabel L5=new DexLabel();
                DexLabel L6=new DexLabel();
                code.visitTryCatch(L5,L6,new DexLabel[]{L4},new String[]{ "Ljava/io/IOException;"});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"resource");
                DexLabel L7=new DexLabel();
                ddv.visitPrologue(L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(326,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(303,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(309,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(312,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(315,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(316,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(319,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(320,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(322,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(327,L17);
                ddv.visitLineNumber(330,L0);
                ddv.visitStartLocal(1,L0,"htin","Ljava/io/BufferedReader;",null);
                ddv.visitLineNumber(331,L1);
                ddv.visitStartLocal(2,L1,"htin","Ljava/io/BufferedReader;",null);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(332,L18);
                ddv.visitEndLocal(1,L18);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(334,L19);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(336,L20);
                DexLabel L21=new DexLabel();
                ddv.visitLineNumber(337,L21);
                DexLabel L22=new DexLabel();
                ddv.visitLineNumber(339,L22);
                DexLabel L23=new DexLabel();
                ddv.visitLineNumber(340,L23);
                DexLabel L24=new DexLabel();
                ddv.visitLineNumber(346,L24);
                DexLabel L25=new DexLabel();
                ddv.visitLineNumber(348,L25);
                DexLabel L26=new DexLabel();
                ddv.visitLineNumber(349,L26);
                DexLabel L27=new DexLabel();
                ddv.visitLineNumber(351,L27);
                DexLabel L28=new DexLabel();
                ddv.visitLineNumber(352,L28);
                DexLabel L29=new DexLabel();
                ddv.visitLineNumber(363,L29);
                ddv.visitEndLocal(2,L29);
                ddv.visitRestartLocal(1,L29);
                DexLabel L30=new DexLabel();
                ddv.visitLineNumber(342,L30);
                ddv.visitEndLocal(1,L30);
                ddv.visitRestartLocal(2,L30);
                DexLabel L31=new DexLabel();
                ddv.visitLineNumber(343,L31);
                ddv.visitLineNumber(358,L4);
                DexLabel L32=new DexLabel();
                ddv.visitLineNumber(360,L32);
                ddv.visitEndLocal(2,L32);
                ddv.visitRestartLocal(1,L32);
                ddv.visitStartLocal(0,L32,"e","Ljava/io/IOException;",null);
                DexLabel L33=new DexLabel();
                ddv.visitLineNumber(361,L33);
                ddv.visitLineNumber(354,L5);
                ddv.visitEndLocal(1,L5);
                ddv.visitEndLocal(0,L5);
                ddv.visitRestartLocal(2,L5);
                DexLabel L34=new DexLabel();
                ddv.visitLineNumber(355,L34);
                ddv.visitLineNumber(358,L2);
                ddv.visitEndLocal(2,L2);
                ddv.visitRestartLocal(1,L2);
                code.visitLabel(L7);
                code.visitConstStmt(CONST_4,4, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitConstStmt(CONST_4,7, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitConstStmt(CONST_4,3, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L8);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 8},new Method("Ljava/lang/Object;","<init>",new String[]{ },"V"));
                code.visitLabel(L9);
                code.visitFieldStmt(IPUT_OBJECT,3,8,new Field("Lorg/mortbay/jetty/security/HTAccessHandler$HTAccess;","_users","Ljava/util/HashMap;"));
                code.visitLabel(L10);
                code.visitFieldStmt(IPUT_OBJECT,3,8,new Field("Lorg/mortbay/jetty/security/HTAccessHandler$HTAccess;","_groups","Ljava/util/HashMap;"));
                code.visitLabel(L11);
                code.visitFieldStmt(IPUT,4,8,new Field("Lorg/mortbay/jetty/security/HTAccessHandler$HTAccess;","_satisfy","I"));
                code.visitLabel(L12);
                code.visitTypeStmt(NEW_INSTANCE,3,-1,"Ljava/util/HashMap;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 3},new Method("Ljava/util/HashMap;","<init>",new String[]{ },"V"));
                code.visitFieldStmt(IPUT_OBJECT,3,8,new Field("Lorg/mortbay/jetty/security/HTAccessHandler$HTAccess;","_methods","Ljava/util/HashMap;"));
                code.visitLabel(L13);
                code.visitTypeStmt(NEW_INSTANCE,3,-1,"Ljava/util/HashSet;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 3},new Method("Ljava/util/HashSet;","<init>",new String[]{ },"V"));
                code.visitFieldStmt(IPUT_OBJECT,3,8,new Field("Lorg/mortbay/jetty/security/HTAccessHandler$HTAccess;","_requireEntities","Ljava/util/HashSet;"));
                code.visitLabel(L14);
                code.visitTypeStmt(NEW_INSTANCE,3,-1,"Ljava/util/ArrayList;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 3},new Method("Ljava/util/ArrayList;","<init>",new String[]{ },"V"));
                code.visitFieldStmt(IPUT_OBJECT,3,8,new Field("Lorg/mortbay/jetty/security/HTAccessHandler$HTAccess;","_allowList","Ljava/util/ArrayList;"));
                code.visitLabel(L15);
                code.visitTypeStmt(NEW_INSTANCE,3,-1,"Ljava/util/ArrayList;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 3},new Method("Ljava/util/ArrayList;","<init>",new String[]{ },"V"));
                code.visitFieldStmt(IPUT_OBJECT,3,8,new Field("Lorg/mortbay/jetty/security/HTAccessHandler$HTAccess;","_denyList","Ljava/util/ArrayList;"));
                code.visitLabel(L16);
                code.visitFieldStmt(IPUT_BOOLEAN,4,8,new Field("Lorg/mortbay/jetty/security/HTAccessHandler$HTAccess;","_forbidden","Z"));
                code.visitLabel(L17);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L0);
                code.visitTypeStmt(NEW_INSTANCE,2,-1,"Ljava/io/BufferedReader;");
                code.visitTypeStmt(NEW_INSTANCE,3,-1,"Ljava/io/InputStreamReader;");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9},new Method("Lorg/mortbay/resource/Resource;","getInputStream",new String[]{ },"Ljava/io/InputStream;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 3,4},new Method("Ljava/io/InputStreamReader;","<init>",new String[]{ "Ljava/io/InputStream;"},"V"));
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2,3},new Method("Ljava/io/BufferedReader;","<init>",new String[]{ "Ljava/io/Reader;"},"V"));
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 8,2},new Method("Lorg/mortbay/jetty/security/HTAccessHandler$HTAccess;","parse",new String[]{ "Ljava/io/BufferedReader;"},"V"));
                code.visitLabel(L18);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9},new Method("Lorg/mortbay/resource/Resource;","lastModified",new String[]{ },"J"));
                code.visitStmt1R(MOVE_RESULT_WIDE,3);
                code.visitFieldStmt(IPUT_WIDE,3,8,new Field("Lorg/mortbay/jetty/security/HTAccessHandler$HTAccess;","_lastModified","J"));
                code.visitLabel(L19);
                code.visitFieldStmt(IGET_OBJECT,3,8,new Field("Lorg/mortbay/jetty/security/HTAccessHandler$HTAccess;","_userFile","Ljava/lang/String;"));
                code.visitJumpStmt(IF_EQZ,3,-1,L24);
                code.visitLabel(L20);
                code.visitFieldStmt(IGET_OBJECT,3,8,new Field("Lorg/mortbay/jetty/security/HTAccessHandler$HTAccess;","_userFile","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 3},new Method("Lorg/mortbay/resource/Resource;","newResource",new String[]{ "Ljava/lang/String;"},"Lorg/mortbay/resource/Resource;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitFieldStmt(IPUT_OBJECT,3,8,new Field("Lorg/mortbay/jetty/security/HTAccessHandler$HTAccess;","_userResource","Lorg/mortbay/resource/Resource;"));
                code.visitLabel(L21);
                code.visitFieldStmt(IGET_OBJECT,3,8,new Field("Lorg/mortbay/jetty/security/HTAccessHandler$HTAccess;","_userResource","Lorg/mortbay/resource/Resource;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Lorg/mortbay/resource/Resource;","exists",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitJumpStmt(IF_NEZ,3,-1,L30);
                code.visitLabel(L22);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitFieldStmt(IPUT_BOOLEAN,3,8,new Field("Lorg/mortbay/jetty/security/HTAccessHandler$HTAccess;","_forbidden","Z"));
                code.visitLabel(L23);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Lorg/mortbay/jetty/security/HTAccessHandler;","access$000",new String[]{ },"Lorg/mortbay/log/Logger;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitTypeStmt(NEW_INSTANCE,4,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 4},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,5,"Could not find ht user file: ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,5},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitFieldStmt(IGET_OBJECT,5,8,new Field("Lorg/mortbay/jetty/security/HTAccessHandler$HTAccess;","_userFile","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,5},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitConstStmt(CONST_4,5, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitConstStmt(CONST_4,6, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 3,4,5,6},new Method("Lorg/mortbay/log/Logger;","warn",new String[]{ "Ljava/lang/String;","Ljava/lang/Object;","Ljava/lang/Object;"},"V"));
                code.visitLabel(L24);
                code.visitFieldStmt(IGET_OBJECT,3,8,new Field("Lorg/mortbay/jetty/security/HTAccessHandler$HTAccess;","_groupFile","Ljava/lang/String;"));
                DexLabel L35=new DexLabel();
                code.visitJumpStmt(IF_EQZ,3,-1,L35);
                code.visitLabel(L25);
                code.visitFieldStmt(IGET_OBJECT,3,8,new Field("Lorg/mortbay/jetty/security/HTAccessHandler$HTAccess;","_groupFile","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 3},new Method("Lorg/mortbay/resource/Resource;","newResource",new String[]{ "Ljava/lang/String;"},"Lorg/mortbay/resource/Resource;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitFieldStmt(IPUT_OBJECT,3,8,new Field("Lorg/mortbay/jetty/security/HTAccessHandler$HTAccess;","_groupResource","Lorg/mortbay/resource/Resource;"));
                code.visitLabel(L26);
                code.visitFieldStmt(IGET_OBJECT,3,8,new Field("Lorg/mortbay/jetty/security/HTAccessHandler$HTAccess;","_groupResource","Lorg/mortbay/resource/Resource;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Lorg/mortbay/resource/Resource;","exists",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitJumpStmt(IF_NEZ,3,-1,L5);
                code.visitLabel(L27);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitFieldStmt(IPUT_BOOLEAN,3,8,new Field("Lorg/mortbay/jetty/security/HTAccessHandler$HTAccess;","_forbidden","Z"));
                code.visitLabel(L28);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Lorg/mortbay/jetty/security/HTAccessHandler;","access$000",new String[]{ },"Lorg/mortbay/log/Logger;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitTypeStmt(NEW_INSTANCE,4,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 4},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,5,"Could not find ht group file: ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,5},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitFieldStmt(IGET_OBJECT,5,8,new Field("Lorg/mortbay/jetty/security/HTAccessHandler$HTAccess;","_groupResource","Lorg/mortbay/resource/Resource;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,5},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitConstStmt(CONST_4,5, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitConstStmt(CONST_4,6, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 3,4,5,6},new Method("Lorg/mortbay/log/Logger;","warn",new String[]{ "Ljava/lang/String;","Ljava/lang/Object;","Ljava/lang/Object;"},"V"));
                code.visitLabel(L35);
                code.visitStmt2R(MOVE_OBJECT,1,2);
                code.visitLabel(L29);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L30);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Lorg/mortbay/jetty/security/HTAccessHandler;","access$000",new String[]{ },"Lorg/mortbay/log/Logger;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 3},new Method("Lorg/mortbay/log/Logger;","isDebugEnabled",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitJumpStmt(IF_EQZ,3,-1,L24);
                code.visitLabel(L31);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Lorg/mortbay/jetty/security/HTAccessHandler;","access$000",new String[]{ },"Lorg/mortbay/log/Logger;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitTypeStmt(NEW_INSTANCE,4,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 4},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,5,"user file: ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,5},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitFieldStmt(IGET_OBJECT,5,8,new Field("Lorg/mortbay/jetty/security/HTAccessHandler$HTAccess;","_userResource","Lorg/mortbay/resource/Resource;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,5},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitConstStmt(CONST_4,5, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitConstStmt(CONST_4,6, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 3,4,5,6},new Method("Lorg/mortbay/log/Logger;","debug",new String[]{ "Ljava/lang/String;","Ljava/lang/Object;","Ljava/lang/Object;"},"V"));
                code.visitLabel(L3);
                code.visitJumpStmt(GOTO,-1,-1,L24);
                code.visitLabel(L4);
                code.visitStmt1R(MOVE_EXCEPTION,3);
                code.visitStmt2R(MOVE_OBJECT,0,3);
                code.visitStmt2R(MOVE_OBJECT,1,2);
                code.visitLabel(L32);
                code.visitFieldStmt(IPUT_BOOLEAN,7,8,new Field("Lorg/mortbay/jetty/security/HTAccessHandler$HTAccess;","_forbidden","Z"));
                code.visitLabel(L33);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Lorg/mortbay/jetty/security/HTAccessHandler;","access$000",new String[]{ },"Lorg/mortbay/log/Logger;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitConstStmt(CONST_STRING,4,"LogSupport.EXCEPTION");
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 3,4,0},new Method("Lorg/mortbay/log/Logger;","warn",new String[]{ "Ljava/lang/String;","Ljava/lang/Throwable;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L29);
                code.visitLabel(L5);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Lorg/mortbay/jetty/security/HTAccessHandler;","access$000",new String[]{ },"Lorg/mortbay/log/Logger;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 3},new Method("Lorg/mortbay/log/Logger;","isDebugEnabled",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitJumpStmt(IF_EQZ,3,-1,L35);
                code.visitLabel(L34);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Lorg/mortbay/jetty/security/HTAccessHandler;","access$000",new String[]{ },"Lorg/mortbay/log/Logger;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitTypeStmt(NEW_INSTANCE,4,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 4},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,5,"group file: ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,5},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitFieldStmt(IGET_OBJECT,5,8,new Field("Lorg/mortbay/jetty/security/HTAccessHandler$HTAccess;","_groupResource","Lorg/mortbay/resource/Resource;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,5},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitConstStmt(CONST_4,5, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitConstStmt(CONST_4,6, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 3,4,5,6},new Method("Lorg/mortbay/log/Logger;","debug",new String[]{ "Ljava/lang/String;","Ljava/lang/Object;","Ljava/lang/Object;"},"V"));
                code.visitLabel(L6);
                code.visitJumpStmt(GOTO,-1,-1,L35);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,3);
                code.visitStmt2R(MOVE_OBJECT,0,3);
                code.visitJumpStmt(GOTO,-1,-1,L32);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001_getUserCode(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PRIVATE, new Method("Lorg/mortbay/jetty/security/HTAccessHandler$HTAccess;","getUserCode",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(16);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                DexLabel L3=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2,L3},new String[]{ "Ljava/io/IOException;",null});
                DexLabel L4=new DexLabel();
                DexLabel L5=new DexLabel();
                DexLabel L6=new DexLabel();
                code.visitTryCatch(L1,L4,new DexLabel[]{L5,L6},new String[]{ "Ljava/io/IOException;",null});
                DexLabel L7=new DexLabel();
                DexLabel L8=new DexLabel();
                code.visitTryCatch(L7,L8,new DexLabel[]{L3},new String[]{ null});
                DexLabel L9=new DexLabel();
                DexLabel L10=new DexLabel();
                DexLabel L11=new DexLabel();
                code.visitTryCatch(L9,L10,new DexLabel[]{L11},new String[]{ "Ljava/io/IOException;"});
                DexLabel L12=new DexLabel();
                DexLabel L13=new DexLabel();
                DexLabel L14=new DexLabel();
                code.visitTryCatch(L12,L13,new DexLabel[]{L14},new String[]{ "Ljava/io/IOException;"});
                DexLabel L15=new DexLabel();
                DexLabel L16=new DexLabel();
                DexLabel L17=new DexLabel();
                code.visitTryCatch(L15,L16,new DexLabel[]{L17},new String[]{ "Ljava/io/IOException;"});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"user");
                DexLabel L18=new DexLabel();
                ddv.visitPrologue(L18);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(555,L19);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(600,L20);
                ddv.visitEndLocal(14,L20);
                DexLabel L21=new DexLabel();
                ddv.visitLineNumber(558,L21);
                ddv.visitRestartLocal(14,L21);
                DexLabel L22=new DexLabel();
                ddv.visitLineNumber(560,L22);
                DexLabel L23=new DexLabel();
                ddv.visitLineNumber(561,L23);
                DexLabel L24=new DexLabel();
                ddv.visitLineNumber(562,L24);
                DexLabel L25=new DexLabel();
                ddv.visitLineNumber(563,L25);
                ddv.visitLineNumber(566,L0);
                ddv.visitStartLocal(6,L0,"ufin","Ljava/io/BufferedReader;",null);
                ddv.visitLineNumber(567,L1);
                ddv.visitStartLocal(7,L1,"ufin","Ljava/io/BufferedReader;",null);
                DexLabel L26=new DexLabel();
                ddv.visitEndLocal(6,L26);
                DexLabel L27=new DexLabel();
                ddv.visitLineNumber(569,L27);
                DexLabel L28=new DexLabel();
                ddv.visitStartLocal(2,L28,"line","Ljava/lang/String;",null);
                DexLabel L29=new DexLabel();
                ddv.visitLineNumber(571,L29);
                DexLabel L30=new DexLabel();
                ddv.visitLineNumber(572,L30);
                DexLabel L31=new DexLabel();
                ddv.visitLineNumber(574,L31);
                DexLabel L32=new DexLabel();
                ddv.visitLineNumber(575,L32);
                ddv.visitStartLocal(4,L32,"spos","I",null);
                DexLabel L33=new DexLabel();
                ddv.visitLineNumber(577,L33);
                DexLabel L34=new DexLabel();
                ddv.visitLineNumber(578,L34);
                ddv.visitStartLocal(5,L34,"u","Ljava/lang/String;",null);
                DexLabel L35=new DexLabel();
                ddv.visitLineNumber(579,L35);
                ddv.visitStartLocal(3,L35,"p","Ljava/lang/String;",null);
                ddv.visitLineNumber(582,L5);
                ddv.visitEndLocal(2,L5);
                ddv.visitEndLocal(4,L5);
                ddv.visitEndLocal(5,L5);
                ddv.visitEndLocal(3,L5);
                ddv.visitLineNumber(584,L7);
                ddv.visitEndLocal(7,L7);
                ddv.visitRestartLocal(6,L7);
                ddv.visitStartLocal(0,L7,"e","Ljava/io/IOException;",null);
                ddv.visitLineNumber(590,L8);
                ddv.visitLineNumber(591,L9);
                ddv.visitLineNumber(600,L10);
                ddv.visitEndLocal(6,L10);
                ddv.visitEndLocal(0,L10);
                DexLabel L36=new DexLabel();
                ddv.visitEndLocal(14,L36);
                ddv.visitLineNumber(588,L3);
                ddv.visitRestartLocal(6,L3);
                ddv.visitRestartLocal(14,L3);
                DexLabel L37=new DexLabel();
                ddv.visitLineNumber(590,L37);
                ddv.visitLineNumber(591,L12);
                ddv.visitLineNumber(588,L13);
                ddv.visitLineNumber(593,L14);
                DexLabel L38=new DexLabel();
                ddv.visitLineNumber(595,L38);
                ddv.visitStartLocal(1,L38,"e2","Ljava/io/IOException;",null);
                ddv.visitLineNumber(593,L11);
                ddv.visitEndLocal(1,L11);
                ddv.visitRestartLocal(0,L11);
                DexLabel L39=new DexLabel();
                ddv.visitLineNumber(595,L39);
                ddv.visitRestartLocal(1,L39);
                DexLabel L40=new DexLabel();
                ddv.visitEndLocal(6,L40);
                ddv.visitEndLocal(0,L40);
                DexLabel L41=new DexLabel();
                ddv.visitLineNumber(590,L41);
                ddv.visitEndLocal(1,L41);
                ddv.visitRestartLocal(2,L41);
                ddv.visitRestartLocal(7,L41);
                ddv.visitLineNumber(591,L15);
                ddv.visitLineNumber(593,L17);
                DexLabel L42=new DexLabel();
                ddv.visitLineNumber(595,L42);
                ddv.visitRestartLocal(1,L42);
                ddv.visitLineNumber(588,L6);
                ddv.visitEndLocal(2,L6);
                ddv.visitEndLocal(1,L6);
                DexLabel L43=new DexLabel();
                ddv.visitRestartLocal(6,L43);
                ddv.visitLineNumber(582,L2);
                ddv.visitEndLocal(7,L2);
                code.visitLabel(L18);
                code.visitConstStmt(CONST_4,13, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitConstStmt(CONST_STRING,12,"LogSupport.EXCEPTION");
                code.visitLabel(L19);
                code.visitFieldStmt(IGET_OBJECT,8,14,new Field("Lorg/mortbay/jetty/security/HTAccessHandler$HTAccess;","_userResource","Lorg/mortbay/resource/Resource;"));
                code.visitJumpStmt(IF_NEZ,8,-1,L21);
                code.visitStmt2R(MOVE_OBJECT,8,13);
                code.visitLabel(L20);
                code.visitStmt1R(RETURN_OBJECT,8);
                code.visitLabel(L21);
                code.visitFieldStmt(IGET_OBJECT,8,14,new Field("Lorg/mortbay/jetty/security/HTAccessHandler$HTAccess;","_users","Ljava/util/HashMap;"));
                code.visitJumpStmt(IF_EQZ,8,-1,L22);
                code.visitFieldStmt(IGET_WIDE,8,14,new Field("Lorg/mortbay/jetty/security/HTAccessHandler$HTAccess;","_userModified","J"));
                code.visitFieldStmt(IGET_OBJECT,10,14,new Field("Lorg/mortbay/jetty/security/HTAccessHandler$HTAccess;","_userResource","Lorg/mortbay/resource/Resource;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10},new Method("Lorg/mortbay/resource/Resource;","lastModified",new String[]{ },"J"));
                code.visitStmt1R(MOVE_RESULT_WIDE,10);
                code.visitStmt3R(CMP_LONG,8,8,10);
                code.visitJumpStmt(IF_EQZ,8,-1,L10);
                code.visitLabel(L22);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Lorg/mortbay/jetty/security/HTAccessHandler;","access$000",new String[]{ },"Lorg/mortbay/log/Logger;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 8},new Method("Lorg/mortbay/log/Logger;","isDebugEnabled",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,8);
                code.visitJumpStmt(IF_EQZ,8,-1,L24);
                code.visitLabel(L23);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Lorg/mortbay/jetty/security/HTAccessHandler;","access$000",new String[]{ },"Lorg/mortbay/log/Logger;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitTypeStmt(NEW_INSTANCE,9,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 9},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,10,"LOAD ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9,10},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,9);
                code.visitFieldStmt(IGET_OBJECT,10,14,new Field("Lorg/mortbay/jetty/security/HTAccessHandler$HTAccess;","_userResource","Lorg/mortbay/resource/Resource;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9,10},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,9);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,9);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 8,9,13,13},new Method("Lorg/mortbay/log/Logger;","debug",new String[]{ "Ljava/lang/String;","Ljava/lang/Object;","Ljava/lang/Object;"},"V"));
                code.visitLabel(L24);
                code.visitTypeStmt(NEW_INSTANCE,8,-1,"Ljava/util/HashMap;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 8},new Method("Ljava/util/HashMap;","<init>",new String[]{ },"V"));
                code.visitFieldStmt(IPUT_OBJECT,8,14,new Field("Lorg/mortbay/jetty/security/HTAccessHandler$HTAccess;","_users","Ljava/util/HashMap;"));
                code.visitLabel(L25);
                code.visitConstStmt(CONST_4,6, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L0);
                code.visitTypeStmt(NEW_INSTANCE,7,-1,"Ljava/io/BufferedReader;");
                code.visitTypeStmt(NEW_INSTANCE,8,-1,"Ljava/io/InputStreamReader;");
                code.visitFieldStmt(IGET_OBJECT,9,14,new Field("Lorg/mortbay/jetty/security/HTAccessHandler$HTAccess;","_userResource","Lorg/mortbay/resource/Resource;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9},new Method("Lorg/mortbay/resource/Resource;","getInputStream",new String[]{ },"Ljava/io/InputStream;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,9);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 8,9},new Method("Ljava/io/InputStreamReader;","<init>",new String[]{ "Ljava/io/InputStream;"},"V"));
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 7,8},new Method("Ljava/io/BufferedReader;","<init>",new String[]{ "Ljava/io/Reader;"},"V"));
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,8,14,new Field("Lorg/mortbay/jetty/security/HTAccessHandler$HTAccess;","_userResource","Lorg/mortbay/resource/Resource;"));
                code.visitLabel(L26);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8},new Method("Lorg/mortbay/resource/Resource;","lastModified",new String[]{ },"J"));
                code.visitStmt1R(MOVE_RESULT_WIDE,8);
                code.visitFieldStmt(IPUT_WIDE,8,14,new Field("Lorg/mortbay/jetty/security/HTAccessHandler$HTAccess;","_userModified","J"));
                code.visitLabel(L27);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7},new Method("Ljava/io/BufferedReader;","readLine",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitLabel(L28);
                code.visitJumpStmt(IF_EQZ,2,-1,L41);
                code.visitLabel(L29);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Ljava/lang/String;","trim",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitLabel(L30);
                code.visitConstStmt(CONST_STRING,8,"#");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,8},new Method("Ljava/lang/String;","startsWith",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,8);
                code.visitJumpStmt(IF_NEZ,8,-1,L27);
                code.visitLabel(L31);
                code.visitConstStmt(CONST_16,8, Integer.valueOf(58)); // int: 0x0000003a  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,8},new Method("Ljava/lang/String;","indexOf",new String[]{ "I"},"I"));
                code.visitStmt1R(MOVE_RESULT,4);
                code.visitLabel(L32);
                code.visitJumpStmt(IF_LTZ,4,-1,L27);
                code.visitLabel(L33);
                code.visitConstStmt(CONST_4,8, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,8,4},new Method("Ljava/lang/String;","substring",new String[]{ "I","I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8},new Method("Ljava/lang/String;","trim",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitLabel(L34);
                code.visitStmt2R1N(ADD_INT_LIT8,8,4,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,8},new Method("Ljava/lang/String;","substring",new String[]{ "I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8},new Method("Ljava/lang/String;","trim",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitLabel(L35);
                code.visitFieldStmt(IGET_OBJECT,8,14,new Field("Lorg/mortbay/jetty/security/HTAccessHandler$HTAccess;","_users","Ljava/util/HashMap;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8,5,3},new Method("Ljava/util/HashMap;","put",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitLabel(L4);
                code.visitJumpStmt(GOTO,-1,-1,L27);
                code.visitLabel(L5);
                code.visitStmt1R(MOVE_EXCEPTION,8);
                code.visitStmt2R(MOVE_OBJECT,0,8);
                code.visitStmt2R(MOVE_OBJECT,6,7);
                code.visitLabel(L7);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Lorg/mortbay/jetty/security/HTAccessHandler;","access$000",new String[]{ },"Lorg/mortbay/log/Logger;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitConstStmt(CONST_STRING,9,"LogSupport.EXCEPTION");
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 8,9,0},new Method("Lorg/mortbay/log/Logger;","warn",new String[]{ "Ljava/lang/String;","Ljava/lang/Throwable;"},"V"));
                code.visitLabel(L8);
                code.visitJumpStmt(IF_EQZ,6,-1,L10);
                code.visitLabel(L9);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Ljava/io/BufferedReader;","close",new String[]{ },"V"));
                code.visitLabel(L10);
                code.visitFieldStmt(IGET_OBJECT,8,14,new Field("Lorg/mortbay/jetty/security/HTAccessHandler$HTAccess;","_users","Ljava/util/HashMap;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8,15},new Method("Ljava/util/HashMap;","get",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,14);
                code.visitLabel(L36);
                code.visitTypeStmt(CHECK_CAST,14,-1,"Ljava/lang/String;");
                code.visitStmt2R(MOVE_OBJECT,8,14);
                code.visitJumpStmt(GOTO_16,-1,-1,L20);
                code.visitLabel(L3);
                code.visitStmt1R(MOVE_EXCEPTION,8);
                code.visitLabel(L37);
                code.visitJumpStmt(IF_EQZ,6,-1,L13);
                code.visitLabel(L12);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Ljava/io/BufferedReader;","close",new String[]{ },"V"));
                code.visitLabel(L13);
                code.visitStmt1R(THROW,8);
                code.visitLabel(L14);
                code.visitStmt1R(MOVE_EXCEPTION,1);
                code.visitLabel(L38);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Lorg/mortbay/jetty/security/HTAccessHandler;","access$000",new String[]{ },"Lorg/mortbay/log/Logger;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,9);
                code.visitConstStmt(CONST_STRING,10,"LogSupport.EXCEPTION");
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 9,12,1},new Method("Lorg/mortbay/log/Logger;","warn",new String[]{ "Ljava/lang/String;","Ljava/lang/Throwable;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L13);
                code.visitLabel(L11);
                code.visitStmt1R(MOVE_EXCEPTION,1);
                code.visitLabel(L39);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Lorg/mortbay/jetty/security/HTAccessHandler;","access$000",new String[]{ },"Lorg/mortbay/log/Logger;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitConstStmt(CONST_STRING,9,"LogSupport.EXCEPTION");
                code.visitLabel(L40);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 8,12,1},new Method("Lorg/mortbay/log/Logger;","warn",new String[]{ "Ljava/lang/String;","Ljava/lang/Throwable;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L10);
                code.visitLabel(L41);
                code.visitJumpStmt(IF_EQZ,7,-1,L10);
                code.visitLabel(L15);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7},new Method("Ljava/io/BufferedReader;","close",new String[]{ },"V"));
                code.visitLabel(L16);
                code.visitJumpStmt(GOTO,-1,-1,L10);
                code.visitLabel(L17);
                code.visitStmt1R(MOVE_EXCEPTION,1);
                code.visitLabel(L42);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Lorg/mortbay/jetty/security/HTAccessHandler;","access$000",new String[]{ },"Lorg/mortbay/log/Logger;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitConstStmt(CONST_STRING,9,"LogSupport.EXCEPTION");
                code.visitJumpStmt(GOTO,-1,-1,L40);
                code.visitLabel(L6);
                code.visitStmt1R(MOVE_EXCEPTION,8);
                code.visitStmt2R(MOVE_OBJECT,6,7);
                code.visitLabel(L43);
                code.visitJumpStmt(GOTO,-1,-1,L37);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,8);
                code.visitStmt2R(MOVE_OBJECT,0,8);
                code.visitJumpStmt(GOTO,-1,-1,L7);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m002_getUserGroups(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PRIVATE, new Method("Lorg/mortbay/jetty/security/HTAccessHandler$HTAccess;","getUserGroups",new String[]{ "Ljava/lang/String;"},"Ljava/util/ArrayList;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(15);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                DexLabel L3=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2,L3},new String[]{ "Ljava/io/IOException;",null});
                DexLabel L4=new DexLabel();
                DexLabel L5=new DexLabel();
                DexLabel L6=new DexLabel();
                code.visitTryCatch(L1,L4,new DexLabel[]{L5,L6},new String[]{ "Ljava/io/IOException;",null});
                DexLabel L7=new DexLabel();
                DexLabel L8=new DexLabel();
                code.visitTryCatch(L7,L8,new DexLabel[]{L3},new String[]{ null});
                DexLabel L9=new DexLabel();
                DexLabel L10=new DexLabel();
                DexLabel L11=new DexLabel();
                code.visitTryCatch(L9,L10,new DexLabel[]{L11},new String[]{ "Ljava/io/IOException;"});
                DexLabel L12=new DexLabel();
                DexLabel L13=new DexLabel();
                DexLabel L14=new DexLabel();
                code.visitTryCatch(L12,L13,new DexLabel[]{L14},new String[]{ "Ljava/io/IOException;"});
                DexLabel L15=new DexLabel();
                DexLabel L16=new DexLabel();
                DexLabel L17=new DexLabel();
                code.visitTryCatch(L15,L16,new DexLabel[]{L17},new String[]{ "Ljava/io/IOException;"});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"group");
                DexLabel L18=new DexLabel();
                ddv.visitPrologue(L18);
                ddv.visitLineNumber(606,L18);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(607,L19);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(665,L20);
                ddv.visitEndLocal(13,L20);
                DexLabel L21=new DexLabel();
                ddv.visitLineNumber(609,L21);
                ddv.visitRestartLocal(13,L21);
                DexLabel L22=new DexLabel();
                ddv.visitLineNumber(611,L22);
                DexLabel L23=new DexLabel();
                ddv.visitLineNumber(612,L23);
                DexLabel L24=new DexLabel();
                ddv.visitLineNumber(614,L24);
                DexLabel L25=new DexLabel();
                ddv.visitLineNumber(615,L25);
                ddv.visitLineNumber(618,L0);
                ddv.visitStartLocal(7,L0,"ufin","Ljava/io/BufferedReader;",null);
                ddv.visitLineNumber(619,L1);
                ddv.visitStartLocal(8,L1,"ufin","Ljava/io/BufferedReader;",null);
                DexLabel L26=new DexLabel();
                ddv.visitEndLocal(7,L26);
                DexLabel L27=new DexLabel();
                ddv.visitLineNumber(621,L27);
                DexLabel L28=new DexLabel();
                ddv.visitStartLocal(4,L28,"line","Ljava/lang/String;",null);
                DexLabel L29=new DexLabel();
                ddv.visitLineNumber(623,L29);
                DexLabel L30=new DexLabel();
                ddv.visitLineNumber(624,L30);
                DexLabel L31=new DexLabel();
                ddv.visitLineNumber(627,L31);
                DexLabel L32=new DexLabel();
                ddv.visitLineNumber(629,L32);
                ddv.visitStartLocal(5,L32,"tok","Ljava/util/StringTokenizer;",null);
                DexLabel L33=new DexLabel();
                ddv.visitLineNumber(631,L33);
                DexLabel L34=new DexLabel();
                ddv.visitLineNumber(632,L34);
                ddv.visitStartLocal(2,L34,"g","Ljava/lang/String;",null);
                DexLabel L35=new DexLabel();
                ddv.visitLineNumber(634,L35);
                DexLabel L36=new DexLabel();
                ddv.visitLineNumber(636,L36);
                DexLabel L37=new DexLabel();
                ddv.visitLineNumber(637,L37);
                ddv.visitStartLocal(6,L37,"u","Ljava/lang/String;",null);
                DexLabel L38=new DexLabel();
                ddv.visitLineNumber(638,L38);
                ddv.visitStartLocal(3,L38,"gl","Ljava/util/ArrayList;",null);
                DexLabel L39=new DexLabel();
                ddv.visitLineNumber(640,L39);
                DexLabel L40=new DexLabel();
                ddv.visitEndLocal(3,L40);
                DexLabel L41=new DexLabel();
                ddv.visitLineNumber(641,L41);
                ddv.visitRestartLocal(3,L41);
                DexLabel L42=new DexLabel();
                ddv.visitLineNumber(643,L42);
                ddv.visitLineNumber(647,L5);
                ddv.visitEndLocal(4,L5);
                ddv.visitEndLocal(5,L5);
                ddv.visitEndLocal(2,L5);
                ddv.visitEndLocal(6,L5);
                ddv.visitEndLocal(3,L5);
                ddv.visitLineNumber(649,L7);
                ddv.visitEndLocal(8,L7);
                ddv.visitRestartLocal(7,L7);
                ddv.visitStartLocal(0,L7,"e","Ljava/io/IOException;",null);
                ddv.visitLineNumber(655,L8);
                ddv.visitLineNumber(656,L9);
                ddv.visitLineNumber(665,L10);
                ddv.visitEndLocal(7,L10);
                ddv.visitEndLocal(0,L10);
                DexLabel L43=new DexLabel();
                ddv.visitEndLocal(13,L43);
                ddv.visitLineNumber(653,L3);
                ddv.visitRestartLocal(7,L3);
                ddv.visitRestartLocal(13,L3);
                DexLabel L44=new DexLabel();
                ddv.visitLineNumber(655,L44);
                ddv.visitLineNumber(656,L12);
                ddv.visitLineNumber(653,L13);
                ddv.visitLineNumber(658,L14);
                DexLabel L45=new DexLabel();
                ddv.visitLineNumber(660,L45);
                ddv.visitStartLocal(1,L45,"e2","Ljava/io/IOException;",null);
                ddv.visitLineNumber(658,L11);
                ddv.visitEndLocal(1,L11);
                ddv.visitRestartLocal(0,L11);
                DexLabel L46=new DexLabel();
                ddv.visitLineNumber(660,L46);
                ddv.visitRestartLocal(1,L46);
                DexLabel L47=new DexLabel();
                ddv.visitEndLocal(7,L47);
                ddv.visitEndLocal(0,L47);
                DexLabel L48=new DexLabel();
                ddv.visitLineNumber(655,L48);
                ddv.visitEndLocal(1,L48);
                ddv.visitRestartLocal(4,L48);
                ddv.visitRestartLocal(8,L48);
                ddv.visitLineNumber(656,L15);
                ddv.visitLineNumber(658,L17);
                DexLabel L49=new DexLabel();
                ddv.visitLineNumber(660,L49);
                ddv.visitRestartLocal(1,L49);
                ddv.visitLineNumber(653,L6);
                ddv.visitEndLocal(4,L6);
                ddv.visitEndLocal(1,L6);
                DexLabel L50=new DexLabel();
                ddv.visitRestartLocal(7,L50);
                ddv.visitLineNumber(647,L2);
                ddv.visitEndLocal(8,L2);
                code.visitLabel(L18);
                code.visitFieldStmt(IGET_OBJECT,9,13,new Field("Lorg/mortbay/jetty/security/HTAccessHandler$HTAccess;","_groupResource","Lorg/mortbay/resource/Resource;"));
                code.visitJumpStmt(IF_NEZ,9,-1,L21);
                code.visitLabel(L19);
                code.visitConstStmt(CONST_4,9, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L20);
                code.visitStmt1R(RETURN_OBJECT,9);
                code.visitLabel(L21);
                code.visitFieldStmt(IGET_OBJECT,9,13,new Field("Lorg/mortbay/jetty/security/HTAccessHandler$HTAccess;","_groups","Ljava/util/HashMap;"));
                code.visitJumpStmt(IF_EQZ,9,-1,L22);
                code.visitFieldStmt(IGET_WIDE,9,13,new Field("Lorg/mortbay/jetty/security/HTAccessHandler$HTAccess;","_groupModified","J"));
                code.visitFieldStmt(IGET_OBJECT,11,13,new Field("Lorg/mortbay/jetty/security/HTAccessHandler$HTAccess;","_groupResource","Lorg/mortbay/resource/Resource;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 11},new Method("Lorg/mortbay/resource/Resource;","lastModified",new String[]{ },"J"));
                code.visitStmt1R(MOVE_RESULT_WIDE,11);
                code.visitStmt3R(CMP_LONG,9,9,11);
                code.visitJumpStmt(IF_EQZ,9,-1,L10);
                code.visitLabel(L22);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Lorg/mortbay/jetty/security/HTAccessHandler;","access$000",new String[]{ },"Lorg/mortbay/log/Logger;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,9);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 9},new Method("Lorg/mortbay/log/Logger;","isDebugEnabled",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,9);
                code.visitJumpStmt(IF_EQZ,9,-1,L24);
                code.visitLabel(L23);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Lorg/mortbay/jetty/security/HTAccessHandler;","access$000",new String[]{ },"Lorg/mortbay/log/Logger;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,9);
                code.visitTypeStmt(NEW_INSTANCE,10,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 10},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,11,"LOAD ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10,11},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,10);
                code.visitFieldStmt(IGET_OBJECT,11,13,new Field("Lorg/mortbay/jetty/security/HTAccessHandler$HTAccess;","_groupResource","Lorg/mortbay/resource/Resource;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10,11},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,10);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,10);
                code.visitConstStmt(CONST_4,11, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitConstStmt(CONST_4,12, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 9,10,11,12},new Method("Lorg/mortbay/log/Logger;","debug",new String[]{ "Ljava/lang/String;","Ljava/lang/Object;","Ljava/lang/Object;"},"V"));
                code.visitLabel(L24);
                code.visitTypeStmt(NEW_INSTANCE,9,-1,"Ljava/util/HashMap;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 9},new Method("Ljava/util/HashMap;","<init>",new String[]{ },"V"));
                code.visitFieldStmt(IPUT_OBJECT,9,13,new Field("Lorg/mortbay/jetty/security/HTAccessHandler$HTAccess;","_groups","Ljava/util/HashMap;"));
                code.visitLabel(L25);
                code.visitConstStmt(CONST_4,7, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L0);
                code.visitTypeStmt(NEW_INSTANCE,8,-1,"Ljava/io/BufferedReader;");
                code.visitTypeStmt(NEW_INSTANCE,9,-1,"Ljava/io/InputStreamReader;");
                code.visitFieldStmt(IGET_OBJECT,10,13,new Field("Lorg/mortbay/jetty/security/HTAccessHandler$HTAccess;","_groupResource","Lorg/mortbay/resource/Resource;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10},new Method("Lorg/mortbay/resource/Resource;","getInputStream",new String[]{ },"Ljava/io/InputStream;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,10);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 9,10},new Method("Ljava/io/InputStreamReader;","<init>",new String[]{ "Ljava/io/InputStream;"},"V"));
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 8,9},new Method("Ljava/io/BufferedReader;","<init>",new String[]{ "Ljava/io/Reader;"},"V"));
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,9,13,new Field("Lorg/mortbay/jetty/security/HTAccessHandler$HTAccess;","_groupResource","Lorg/mortbay/resource/Resource;"));
                code.visitLabel(L26);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9},new Method("Lorg/mortbay/resource/Resource;","lastModified",new String[]{ },"J"));
                code.visitStmt1R(MOVE_RESULT_WIDE,9);
                code.visitFieldStmt(IPUT_WIDE,9,13,new Field("Lorg/mortbay/jetty/security/HTAccessHandler$HTAccess;","_groupModified","J"));
                code.visitLabel(L27);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8},new Method("Ljava/io/BufferedReader;","readLine",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitLabel(L28);
                code.visitJumpStmt(IF_EQZ,4,-1,L48);
                code.visitLabel(L29);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Ljava/lang/String;","trim",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitLabel(L30);
                code.visitConstStmt(CONST_STRING,9,"#");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,9},new Method("Ljava/lang/String;","startsWith",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,9);
                code.visitJumpStmt(IF_NEZ,9,-1,L27);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Ljava/lang/String;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,9);
                code.visitJumpStmt(IF_EQZ,9,-1,L27);
                code.visitLabel(L31);
                code.visitTypeStmt(NEW_INSTANCE,5,-1,"Ljava/util/StringTokenizer;");
                code.visitConstStmt(CONST_STRING,9,": \t");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 5,4,9},new Method("Ljava/util/StringTokenizer;","<init>",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"V"));
                code.visitLabel(L32);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Ljava/util/StringTokenizer;","hasMoreTokens",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,9);
                code.visitJumpStmt(IF_EQZ,9,-1,L27);
                code.visitLabel(L33);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Ljava/util/StringTokenizer;","nextToken",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitLabel(L34);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Ljava/util/StringTokenizer;","hasMoreTokens",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,9);
                code.visitJumpStmt(IF_EQZ,9,-1,L27);
                code.visitLabel(L35);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Ljava/util/StringTokenizer;","hasMoreTokens",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,9);
                code.visitJumpStmt(IF_EQZ,9,-1,L27);
                code.visitLabel(L36);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Ljava/util/StringTokenizer;","nextToken",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitLabel(L37);
                code.visitFieldStmt(IGET_OBJECT,9,13,new Field("Lorg/mortbay/jetty/security/HTAccessHandler$HTAccess;","_groups","Ljava/util/HashMap;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9,6},new Method("Ljava/util/HashMap;","get",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitTypeStmt(CHECK_CAST,3,-1,"Ljava/util/ArrayList;");
                code.visitLabel(L38);
                code.visitJumpStmt(IF_NEZ,3,-1,L42);
                code.visitLabel(L39);
                code.visitTypeStmt(NEW_INSTANCE,3,-1,"Ljava/util/ArrayList;");
                code.visitLabel(L40);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 3},new Method("Ljava/util/ArrayList;","<init>",new String[]{ },"V"));
                code.visitLabel(L41);
                code.visitFieldStmt(IGET_OBJECT,9,13,new Field("Lorg/mortbay/jetty/security/HTAccessHandler$HTAccess;","_groups","Ljava/util/HashMap;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9,6,3},new Method("Ljava/util/HashMap;","put",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitLabel(L42);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,2},new Method("Ljava/util/ArrayList;","add",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitLabel(L4);
                code.visitJumpStmt(GOTO,-1,-1,L35);
                code.visitLabel(L5);
                code.visitStmt1R(MOVE_EXCEPTION,9);
                code.visitStmt2R(MOVE_OBJECT,0,9);
                code.visitStmt2R(MOVE_OBJECT,7,8);
                code.visitLabel(L7);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Lorg/mortbay/jetty/security/HTAccessHandler;","access$000",new String[]{ },"Lorg/mortbay/log/Logger;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,9);
                code.visitConstStmt(CONST_STRING,10,"LogSupport.EXCEPTION");
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 9,10,0},new Method("Lorg/mortbay/log/Logger;","warn",new String[]{ "Ljava/lang/String;","Ljava/lang/Throwable;"},"V"));
                code.visitLabel(L8);
                code.visitJumpStmt(IF_EQZ,7,-1,L10);
                code.visitLabel(L9);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7},new Method("Ljava/io/BufferedReader;","close",new String[]{ },"V"));
                code.visitLabel(L10);
                code.visitFieldStmt(IGET_OBJECT,9,13,new Field("Lorg/mortbay/jetty/security/HTAccessHandler$HTAccess;","_groups","Ljava/util/HashMap;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9,14},new Method("Ljava/util/HashMap;","get",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,13);
                code.visitLabel(L43);
                code.visitTypeStmt(CHECK_CAST,13,-1,"Ljava/util/ArrayList;");
                code.visitStmt2R(MOVE_OBJECT,9,13);
                code.visitJumpStmt(GOTO_16,-1,-1,L20);
                code.visitLabel(L3);
                code.visitStmt1R(MOVE_EXCEPTION,9);
                code.visitLabel(L44);
                code.visitJumpStmt(IF_EQZ,7,-1,L13);
                code.visitLabel(L12);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7},new Method("Ljava/io/BufferedReader;","close",new String[]{ },"V"));
                code.visitLabel(L13);
                code.visitStmt1R(THROW,9);
                code.visitLabel(L14);
                code.visitStmt1R(MOVE_EXCEPTION,1);
                code.visitLabel(L45);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Lorg/mortbay/jetty/security/HTAccessHandler;","access$000",new String[]{ },"Lorg/mortbay/log/Logger;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,10);
                code.visitConstStmt(CONST_STRING,11,"LogSupport.EXCEPTION");
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 10,11,1},new Method("Lorg/mortbay/log/Logger;","warn",new String[]{ "Ljava/lang/String;","Ljava/lang/Throwable;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L13);
                code.visitLabel(L11);
                code.visitStmt1R(MOVE_EXCEPTION,1);
                code.visitLabel(L46);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Lorg/mortbay/jetty/security/HTAccessHandler;","access$000",new String[]{ },"Lorg/mortbay/log/Logger;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,9);
                code.visitConstStmt(CONST_STRING,10,"LogSupport.EXCEPTION");
                code.visitLabel(L47);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 9,10,1},new Method("Lorg/mortbay/log/Logger;","warn",new String[]{ "Ljava/lang/String;","Ljava/lang/Throwable;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L10);
                code.visitLabel(L48);
                code.visitJumpStmt(IF_EQZ,8,-1,L10);
                code.visitLabel(L15);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8},new Method("Ljava/io/BufferedReader;","close",new String[]{ },"V"));
                code.visitLabel(L16);
                code.visitJumpStmt(GOTO,-1,-1,L10);
                code.visitLabel(L17);
                code.visitStmt1R(MOVE_EXCEPTION,1);
                code.visitLabel(L49);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Lorg/mortbay/jetty/security/HTAccessHandler;","access$000",new String[]{ },"Lorg/mortbay/log/Logger;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,9);
                code.visitConstStmt(CONST_STRING,10,"LogSupport.EXCEPTION");
                code.visitJumpStmt(GOTO,-1,-1,L47);
                code.visitLabel(L6);
                code.visitStmt1R(MOVE_EXCEPTION,9);
                code.visitStmt2R(MOVE_OBJECT,7,8);
                code.visitLabel(L50);
                code.visitJumpStmt(GOTO,-1,-1,L44);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,9);
                code.visitStmt2R(MOVE_OBJECT,0,9);
                code.visitJumpStmt(GOTO,-1,-1,L7);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m003_parse(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PRIVATE, new Method("Lorg/mortbay/jetty/security/HTAccessHandler$HTAccess;","parse",new String[]{ "Ljava/io/BufferedReader;"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(13);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"htin");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(708,L0);
                DexLabel L1=new DexLabel();
                ddv.visitStartLocal(3,L1,"line","Ljava/lang/String;",null);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(710,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(711,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(713,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(715,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(717,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(719,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(721,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(723,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(725,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(727,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(730,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(732,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(733,L14);
                ddv.visitStartLocal(2,L14,"limit","I",null);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(736,L15);
                ddv.visitStartLocal(0,L15,"endp","I",null);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(737,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(738,L17);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(739,L18);
                ddv.visitStartLocal(6,L18,"tkns","Ljava/util/StringTokenizer;",null);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(741,L19);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(744,L20);
                DexLabel L21=new DexLabel();
                ddv.visitRestartLocal(3,L21);
                DexLabel L22=new DexLabel();
                ddv.visitLineNumber(746,L22);
                DexLabel L23=new DexLabel();
                ddv.visitLineNumber(747,L23);
                ddv.visitRestartLocal(3,L23);
                DexLabel L24=new DexLabel();
                ddv.visitLineNumber(749,L24);
                DexLabel L25=new DexLabel();
                ddv.visitLineNumber(751,L25);
                DexLabel L26=new DexLabel();
                ddv.visitLineNumber(752,L26);
                ddv.visitStartLocal(4,L26,"pos1","I",null);
                DexLabel L27=new DexLabel();
                ddv.visitLineNumber(753,L27);
                DexLabel L28=new DexLabel();
                ddv.visitLineNumber(754,L28);
                DexLabel L29=new DexLabel();
                ddv.visitLineNumber(755,L29);
                DexLabel L30=new DexLabel();
                ddv.visitLineNumber(756,L30);
                ddv.visitStartLocal(5,L30,"pos2","I",null);
                DexLabel L31=new DexLabel();
                ddv.visitLineNumber(757,L31);
                DexLabel L32=new DexLabel();
                ddv.visitLineNumber(758,L32);
                DexLabel L33=new DexLabel();
                ddv.visitLineNumber(759,L33);
                ddv.visitStartLocal(1,L33,"l_string","Ljava/lang/String;",null);
                DexLabel L34=new DexLabel();
                ddv.visitLineNumber(760,L34);
                DexLabel L35=new DexLabel();
                ddv.visitLineNumber(761,L35);
                DexLabel L36=new DexLabel();
                ddv.visitLineNumber(762,L36);
                DexLabel L37=new DexLabel();
                ddv.visitLineNumber(764,L37);
                ddv.visitEndLocal(4,L37);
                ddv.visitEndLocal(5,L37);
                ddv.visitEndLocal(1,L37);
                DexLabel L38=new DexLabel();
                ddv.visitLineNumber(766,L38);
                DexLabel L39=new DexLabel();
                ddv.visitLineNumber(767,L39);
                ddv.visitRestartLocal(4,L39);
                DexLabel L40=new DexLabel();
                ddv.visitLineNumber(768,L40);
                ddv.visitRestartLocal(2,L40);
                DexLabel L41=new DexLabel();
                ddv.visitLineNumber(769,L41);
                DexLabel L42=new DexLabel();
                ddv.visitLineNumber(770,L42);
                DexLabel L43=new DexLabel();
                ddv.visitLineNumber(771,L43);
                ddv.visitRestartLocal(5,L43);
                DexLabel L44=new DexLabel();
                ddv.visitLineNumber(772,L44);
                DexLabel L45=new DexLabel();
                ddv.visitLineNumber(773,L45);
                DexLabel L46=new DexLabel();
                ddv.visitLineNumber(774,L46);
                DexLabel L47=new DexLabel();
                ddv.visitLineNumber(775,L47);
                DexLabel L48=new DexLabel();
                ddv.visitLineNumber(781,L48);
                DexLabel L49=new DexLabel();
                ddv.visitLineNumber(782,L49);
                DexLabel L50=new DexLabel();
                ddv.visitLineNumber(784,L50);
                DexLabel L51=new DexLabel();
                ddv.visitLineNumber(785,L51);
                DexLabel L52=new DexLabel();
                ddv.visitLineNumber(776,L52);
                DexLabel L53=new DexLabel();
                ddv.visitLineNumber(777,L53);
                DexLabel L54=new DexLabel();
                ddv.visitLineNumber(778,L54);
                DexLabel L55=new DexLabel();
                ddv.visitLineNumber(779,L55);
                DexLabel L56=new DexLabel();
                ddv.visitLineNumber(787,L56);
                DexLabel L57=new DexLabel();
                ddv.visitEndLocal(6,L57);
                DexLabel L58=new DexLabel();
                ddv.visitLineNumber(788,L58);
                ddv.visitRestartLocal(6,L58);
                DexLabel L59=new DexLabel();
                ddv.visitLineNumber(790,L59);
                DexLabel L60=new DexLabel();
                ddv.visitLineNumber(795,L60);
                ddv.visitEndLocal(4,L60);
                ddv.visitEndLocal(5,L60);
                DexLabel L61=new DexLabel();
                ddv.visitLineNumber(797,L61);
                DexLabel L62=new DexLabel();
                ddv.visitLineNumber(798,L62);
                DexLabel L63=new DexLabel();
                ddv.visitLineNumber(799,L63);
                DexLabel L64=new DexLabel();
                ddv.visitLineNumber(801,L64);
                DexLabel L65=new DexLabel();
                ddv.visitLineNumber(802,L65);
                DexLabel L66=new DexLabel();
                ddv.visitLineNumber(804,L66);
                DexLabel L67=new DexLabel();
                ddv.visitLineNumber(806,L67);
                DexLabel L68=new DexLabel();
                ddv.visitLineNumber(807,L68);
                DexLabel L69=new DexLabel();
                ddv.visitLineNumber(809,L69);
                DexLabel L70=new DexLabel();
                ddv.visitLineNumber(811,L70);
                DexLabel L71=new DexLabel();
                ddv.visitLineNumber(812,L71);
                DexLabel L72=new DexLabel();
                ddv.visitLineNumber(818,L72);
                DexLabel L73=new DexLabel();
                ddv.visitLineNumber(820,L73);
                DexLabel L74=new DexLabel();
                ddv.visitLineNumber(821,L74);
                ddv.visitRestartLocal(4,L74);
                DexLabel L75=new DexLabel();
                ddv.visitLineNumber(822,L75);
                ddv.visitRestartLocal(2,L75);
                DexLabel L76=new DexLabel();
                ddv.visitLineNumber(823,L76);
                DexLabel L77=new DexLabel();
                ddv.visitLineNumber(824,L77);
                DexLabel L78=new DexLabel();
                ddv.visitLineNumber(825,L78);
                DexLabel L79=new DexLabel();
                ddv.visitLineNumber(826,L79);
                DexLabel L80=new DexLabel();
                ddv.visitEndLocal(6,L80);
                DexLabel L81=new DexLabel();
                ddv.visitLineNumber(827,L81);
                ddv.visitRestartLocal(6,L81);
                DexLabel L82=new DexLabel();
                ddv.visitLineNumber(829,L82);
                DexLabel L83=new DexLabel();
                ddv.visitLineNumber(832,L83);
                ddv.visitEndLocal(4,L83);
                DexLabel L84=new DexLabel();
                ddv.visitLineNumber(834,L84);
                DexLabel L85=new DexLabel();
                ddv.visitLineNumber(835,L85);
                ddv.visitRestartLocal(4,L85);
                DexLabel L86=new DexLabel();
                ddv.visitLineNumber(836,L86);
                ddv.visitRestartLocal(2,L86);
                DexLabel L87=new DexLabel();
                ddv.visitLineNumber(837,L87);
                DexLabel L88=new DexLabel();
                ddv.visitLineNumber(838,L88);
                DexLabel L89=new DexLabel();
                ddv.visitLineNumber(839,L89);
                DexLabel L90=new DexLabel();
                ddv.visitLineNumber(841,L90);
                DexLabel L91=new DexLabel();
                ddv.visitEndLocal(6,L91);
                DexLabel L92=new DexLabel();
                ddv.visitLineNumber(842,L92);
                ddv.visitRestartLocal(6,L92);
                DexLabel L93=new DexLabel();
                ddv.visitLineNumber(844,L93);
                DexLabel L94=new DexLabel();
                ddv.visitLineNumber(847,L94);
                ddv.visitEndLocal(4,L94);
                DexLabel L95=new DexLabel();
                ddv.visitLineNumber(852,L95);
                ddv.visitEndLocal(0,L95);
                ddv.visitEndLocal(2,L95);
                ddv.visitEndLocal(6,L95);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 12},new Method("Ljava/io/BufferedReader;","readLine",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitLabel(L1);
                code.visitJumpStmt(IF_EQZ,3,-1,L95);
                code.visitLabel(L2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Ljava/lang/String;","trim",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitLabel(L3);
                code.visitConstStmt(CONST_STRING,7,"#");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,7},new Method("Ljava/lang/String;","startsWith",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,7);
                code.visitJumpStmt(IF_NEZ,7,-1,L0);
                code.visitLabel(L4);
                code.visitConstStmt(CONST_STRING,7,"AuthUserFile");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,7},new Method("Ljava/lang/String;","startsWith",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,7);
                code.visitJumpStmt(IF_EQZ,7,-1,L6);
                code.visitLabel(L5);
                code.visitConstStmt(CONST_16,7, Integer.valueOf(13)); // int: 0x0000000d  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,7},new Method("Ljava/lang/String;","substring",new String[]{ "I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7},new Method("Ljava/lang/String;","trim",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitFieldStmt(IPUT_OBJECT,7,11,new Field("Lorg/mortbay/jetty/security/HTAccessHandler$HTAccess;","_userFile","Ljava/lang/String;"));
                code.visitJumpStmt(GOTO,-1,-1,L0);
                code.visitLabel(L6);
                code.visitConstStmt(CONST_STRING,7,"AuthGroupFile");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,7},new Method("Ljava/lang/String;","startsWith",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,7);
                code.visitJumpStmt(IF_EQZ,7,-1,L8);
                code.visitLabel(L7);
                code.visitConstStmt(CONST_16,7, Integer.valueOf(14)); // int: 0x0000000e  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,7},new Method("Ljava/lang/String;","substring",new String[]{ "I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7},new Method("Ljava/lang/String;","trim",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitFieldStmt(IPUT_OBJECT,7,11,new Field("Lorg/mortbay/jetty/security/HTAccessHandler$HTAccess;","_groupFile","Ljava/lang/String;"));
                code.visitJumpStmt(GOTO,-1,-1,L0);
                code.visitLabel(L8);
                code.visitConstStmt(CONST_STRING,7,"AuthName");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,7},new Method("Ljava/lang/String;","startsWith",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,7);
                code.visitJumpStmt(IF_EQZ,7,-1,L10);
                code.visitLabel(L9);
                code.visitConstStmt(CONST_16,7, Integer.valueOf(8)); // int: 0x00000008  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,7},new Method("Ljava/lang/String;","substring",new String[]{ "I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7},new Method("Ljava/lang/String;","trim",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitFieldStmt(IPUT_OBJECT,7,11,new Field("Lorg/mortbay/jetty/security/HTAccessHandler$HTAccess;","_name","Ljava/lang/String;"));
                code.visitJumpStmt(GOTO,-1,-1,L0);
                code.visitLabel(L10);
                code.visitConstStmt(CONST_STRING,7,"AuthType");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,7},new Method("Ljava/lang/String;","startsWith",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,7);
                code.visitJumpStmt(IF_EQZ,7,-1,L12);
                code.visitLabel(L11);
                code.visitConstStmt(CONST_16,7, Integer.valueOf(8)); // int: 0x00000008  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,7},new Method("Ljava/lang/String;","substring",new String[]{ "I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7},new Method("Ljava/lang/String;","trim",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitFieldStmt(IPUT_OBJECT,7,11,new Field("Lorg/mortbay/jetty/security/HTAccessHandler$HTAccess;","_type","Ljava/lang/String;"));
                code.visitJumpStmt(GOTO,-1,-1,L0);
                code.visitLabel(L12);
                code.visitConstStmt(CONST_STRING,7,"<Limit");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,7},new Method("Ljava/lang/String;","startsWith",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,7);
                code.visitJumpStmt(IF_EQZ,7,-1,L0);
                code.visitLabel(L13);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Ljava/lang/String;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitLabel(L14);
                code.visitConstStmt(CONST_16,7, Integer.valueOf(62)); // int: 0x0000003e  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,7},new Method("Ljava/lang/String;","indexOf",new String[]{ "I"},"I"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitLabel(L15);
                code.visitJumpStmt(IF_GEZ,0,-1,L17);
                code.visitLabel(L16);
                code.visitStmt2R(MOVE,0,2);
                code.visitLabel(L17);
                code.visitTypeStmt(NEW_INSTANCE,6,-1,"Ljava/util/StringTokenizer;");
                code.visitConstStmt(CONST_4,7, Integer.valueOf(6)); // int: 0x00000006  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,7,0},new Method("Ljava/lang/String;","substring",new String[]{ "I","I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 6,7},new Method("Ljava/util/StringTokenizer;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L18);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Ljava/util/StringTokenizer;","hasMoreTokens",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,7);
                code.visitJumpStmt(IF_EQZ,7,-1,L20);
                code.visitLabel(L19);
                code.visitFieldStmt(IGET_OBJECT,7,11,new Field("Lorg/mortbay/jetty/security/HTAccessHandler$HTAccess;","_methods","Ljava/util/HashMap;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Ljava/util/StringTokenizer;","nextToken",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitFieldStmt(SGET_OBJECT,9,-1,new Field("Ljava/lang/Boolean;","TRUE","Ljava/lang/Boolean;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7,8,9},new Method("Ljava/util/HashMap;","put",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitJumpStmt(GOTO,-1,-1,L18);
                code.visitLabel(L20);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 12},new Method("Ljava/io/BufferedReader;","readLine",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitLabel(L21);
                code.visitJumpStmt(IF_EQZ,3,-1,L0);
                code.visitLabel(L22);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Ljava/lang/String;","trim",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitLabel(L23);
                code.visitConstStmt(CONST_STRING,7,"#");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,7},new Method("Ljava/lang/String;","startsWith",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,7);
                code.visitJumpStmt(IF_NEZ,7,-1,L20);
                code.visitLabel(L24);
                code.visitConstStmt(CONST_STRING,7,"satisfy");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,7},new Method("Ljava/lang/String;","startsWith",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,7);
                code.visitJumpStmt(IF_EQZ,7,-1,L37);
                code.visitLabel(L25);
                code.visitConstStmt(CONST_4,4, Integer.valueOf(7)); // int: 0x00000007  float:0.000000
                code.visitLabel(L26);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Ljava/lang/String;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitLabel(L27);
                code.visitJumpStmt(IF_GE,4,2,L29);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,4},new Method("Ljava/lang/String;","charAt",new String[]{ "I"},"C"));
                code.visitStmt1R(MOVE_RESULT,7);
                code.visitConstStmt(CONST_16,8, Integer.valueOf(32)); // int: 0x00000020  float:0.000000
                code.visitJumpStmt(IF_GT,7,8,L29);
                code.visitLabel(L28);
                code.visitStmt2R1N(ADD_INT_LIT8,4,4,1);
                code.visitJumpStmt(GOTO,-1,-1,L27);
                code.visitLabel(L29);
                code.visitStmt2R(MOVE,5,4);
                code.visitLabel(L30);
                code.visitJumpStmt(IF_GE,5,2,L32);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,5},new Method("Ljava/lang/String;","charAt",new String[]{ "I"},"C"));
                code.visitStmt1R(MOVE_RESULT,7);
                code.visitConstStmt(CONST_16,8, Integer.valueOf(32)); // int: 0x00000020  float:0.000000
                code.visitJumpStmt(IF_LE,7,8,L32);
                code.visitLabel(L31);
                code.visitStmt2R1N(ADD_INT_LIT8,5,5,1);
                code.visitJumpStmt(GOTO,-1,-1,L30);
                code.visitLabel(L32);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,4,5},new Method("Ljava/lang/String;","substring",new String[]{ "I","I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L33);
                code.visitConstStmt(CONST_STRING,7,"all");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,7},new Method("Ljava/lang/String;","equals",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,7);
                code.visitJumpStmt(IF_EQZ,7,-1,L35);
                code.visitLabel(L34);
                code.visitConstStmt(CONST_4,7, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitFieldStmt(IPUT,7,11,new Field("Lorg/mortbay/jetty/security/HTAccessHandler$HTAccess;","_satisfy","I"));
                code.visitJumpStmt(GOTO,-1,-1,L20);
                code.visitLabel(L35);
                code.visitConstStmt(CONST_STRING,7,"any");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,7},new Method("Ljava/lang/String;","equals",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,7);
                code.visitJumpStmt(IF_EQZ,7,-1,L20);
                code.visitLabel(L36);
                code.visitConstStmt(CONST_4,7, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT,7,11,new Field("Lorg/mortbay/jetty/security/HTAccessHandler$HTAccess;","_satisfy","I"));
                code.visitJumpStmt(GOTO,-1,-1,L20);
                code.visitLabel(L37);
                code.visitConstStmt(CONST_STRING,7,"require");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,7},new Method("Ljava/lang/String;","startsWith",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,7);
                code.visitJumpStmt(IF_EQZ,7,-1,L60);
                code.visitLabel(L38);
                code.visitConstStmt(CONST_4,4, Integer.valueOf(7)); // int: 0x00000007  float:0.000000
                code.visitLabel(L39);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Ljava/lang/String;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitLabel(L40);
                code.visitJumpStmt(IF_GE,4,2,L42);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,4},new Method("Ljava/lang/String;","charAt",new String[]{ "I"},"C"));
                code.visitStmt1R(MOVE_RESULT,7);
                code.visitConstStmt(CONST_16,8, Integer.valueOf(32)); // int: 0x00000020  float:0.000000
                code.visitJumpStmt(IF_GT,7,8,L42);
                code.visitLabel(L41);
                code.visitStmt2R1N(ADD_INT_LIT8,4,4,1);
                code.visitJumpStmt(GOTO,-1,-1,L40);
                code.visitLabel(L42);
                code.visitStmt2R(MOVE,5,4);
                code.visitLabel(L43);
                code.visitJumpStmt(IF_GE,5,2,L45);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,5},new Method("Ljava/lang/String;","charAt",new String[]{ "I"},"C"));
                code.visitStmt1R(MOVE_RESULT,7);
                code.visitConstStmt(CONST_16,8, Integer.valueOf(32)); // int: 0x00000020  float:0.000000
                code.visitJumpStmt(IF_LE,7,8,L45);
                code.visitLabel(L44);
                code.visitStmt2R1N(ADD_INT_LIT8,5,5,1);
                code.visitJumpStmt(GOTO,-1,-1,L43);
                code.visitLabel(L45);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,4,5},new Method("Ljava/lang/String;","substring",new String[]{ "I","I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7},new Method("Ljava/lang/String;","toLowerCase",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitFieldStmt(IPUT_OBJECT,7,11,new Field("Lorg/mortbay/jetty/security/HTAccessHandler$HTAccess;","_requireName","Ljava/lang/String;"));
                code.visitLabel(L46);
                code.visitConstStmt(CONST_STRING,7,"user");
                code.visitFieldStmt(IGET_OBJECT,8,11,new Field("Lorg/mortbay/jetty/security/HTAccessHandler$HTAccess;","_requireName","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7,8},new Method("Ljava/lang/String;","equals",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,7);
                code.visitJumpStmt(IF_EQZ,7,-1,L52);
                code.visitLabel(L47);
                code.visitConstStmt(CONST_STRING,7,"user");
                code.visitFieldStmt(IPUT_OBJECT,7,11,new Field("Lorg/mortbay/jetty/security/HTAccessHandler$HTAccess;","_requireName","Ljava/lang/String;"));
                code.visitLabel(L48);
                code.visitStmt2R1N(ADD_INT_LIT8,4,5,1);
                code.visitLabel(L49);
                code.visitJumpStmt(IF_GE,4,2,L20);
                code.visitLabel(L50);
                code.visitJumpStmt(IF_GE,4,2,L56);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,4},new Method("Ljava/lang/String;","charAt",new String[]{ "I"},"C"));
                code.visitStmt1R(MOVE_RESULT,7);
                code.visitConstStmt(CONST_16,8, Integer.valueOf(32)); // int: 0x00000020  float:0.000000
                code.visitJumpStmt(IF_GT,7,8,L56);
                code.visitLabel(L51);
                code.visitStmt2R1N(ADD_INT_LIT8,4,4,1);
                code.visitJumpStmt(GOTO,-1,-1,L50);
                code.visitLabel(L52);
                code.visitConstStmt(CONST_STRING,7,"group");
                code.visitFieldStmt(IGET_OBJECT,8,11,new Field("Lorg/mortbay/jetty/security/HTAccessHandler$HTAccess;","_requireName","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7,8},new Method("Ljava/lang/String;","equals",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,7);
                code.visitJumpStmt(IF_EQZ,7,-1,L54);
                code.visitLabel(L53);
                code.visitConstStmt(CONST_STRING,7,"group");
                code.visitFieldStmt(IPUT_OBJECT,7,11,new Field("Lorg/mortbay/jetty/security/HTAccessHandler$HTAccess;","_requireName","Ljava/lang/String;"));
                code.visitJumpStmt(GOTO,-1,-1,L48);
                code.visitLabel(L54);
                code.visitConstStmt(CONST_STRING,7,"valid-user");
                code.visitFieldStmt(IGET_OBJECT,8,11,new Field("Lorg/mortbay/jetty/security/HTAccessHandler$HTAccess;","_requireName","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7,8},new Method("Ljava/lang/String;","equals",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,7);
                code.visitJumpStmt(IF_EQZ,7,-1,L48);
                code.visitLabel(L55);
                code.visitConstStmt(CONST_STRING,7,"valid-user");
                code.visitFieldStmt(IPUT_OBJECT,7,11,new Field("Lorg/mortbay/jetty/security/HTAccessHandler$HTAccess;","_requireName","Ljava/lang/String;"));
                code.visitJumpStmt(GOTO,-1,-1,L48);
                code.visitLabel(L56);
                code.visitTypeStmt(NEW_INSTANCE,6,-1,"Ljava/util/StringTokenizer;");
                code.visitLabel(L57);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,4},new Method("Ljava/lang/String;","substring",new String[]{ "I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 6,7},new Method("Ljava/util/StringTokenizer;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L58);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Ljava/util/StringTokenizer;","hasMoreTokens",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,7);
                code.visitJumpStmt(IF_EQZ,7,-1,L20);
                code.visitLabel(L59);
                code.visitFieldStmt(IGET_OBJECT,7,11,new Field("Lorg/mortbay/jetty/security/HTAccessHandler$HTAccess;","_requireEntities","Ljava/util/HashSet;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Ljava/util/StringTokenizer;","nextToken",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7,8},new Method("Ljava/util/HashSet;","add",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitJumpStmt(GOTO,-1,-1,L58);
                code.visitLabel(L60);
                code.visitConstStmt(CONST_STRING,7,"order");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,7},new Method("Ljava/lang/String;","startsWith",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,7);
                code.visitJumpStmt(IF_EQZ,7,-1,L72);
                code.visitLabel(L61);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Lorg/mortbay/jetty/security/HTAccessHandler;","access$000",new String[]{ },"Lorg/mortbay/log/Logger;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 7},new Method("Lorg/mortbay/log/Logger;","isDebugEnabled",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,7);
                code.visitJumpStmt(IF_EQZ,7,-1,L63);
                code.visitLabel(L62);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Lorg/mortbay/jetty/security/HTAccessHandler;","access$000",new String[]{ },"Lorg/mortbay/log/Logger;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitTypeStmt(NEW_INSTANCE,8,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 8},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,9,"orderline=");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8,9},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8,3},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitConstStmt(CONST_STRING,9,"order=");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8,9},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitFieldStmt(IGET,9,11,new Field("Lorg/mortbay/jetty/security/HTAccessHandler$HTAccess;","_order","I"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8,9},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "I"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitConstStmt(CONST_4,9, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitConstStmt(CONST_4,10, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 7,8,9,10},new Method("Lorg/mortbay/log/Logger;","debug",new String[]{ "Ljava/lang/String;","Ljava/lang/Object;","Ljava/lang/Object;"},"V"));
                code.visitLabel(L63);
                code.visitConstStmt(CONST_STRING,7,"allow,deny");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,7},new Method("Ljava/lang/String;","indexOf",new String[]{ "Ljava/lang/String;"},"I"));
                code.visitStmt1R(MOVE_RESULT,7);
                code.visitJumpStmt(IF_LEZ,7,-1,L66);
                code.visitLabel(L64);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Lorg/mortbay/jetty/security/HTAccessHandler;","access$000",new String[]{ },"Lorg/mortbay/log/Logger;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitConstStmt(CONST_STRING,8,"==>allow+deny");
                code.visitConstStmt(CONST_4,9, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitConstStmt(CONST_4,10, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 7,8,9,10},new Method("Lorg/mortbay/log/Logger;","debug",new String[]{ "Ljava/lang/String;","Ljava/lang/Object;","Ljava/lang/Object;"},"V"));
                code.visitLabel(L65);
                code.visitConstStmt(CONST_4,7, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitFieldStmt(IPUT,7,11,new Field("Lorg/mortbay/jetty/security/HTAccessHandler$HTAccess;","_order","I"));
                code.visitJumpStmt(GOTO_16,-1,-1,L20);
                code.visitLabel(L66);
                code.visitConstStmt(CONST_STRING,7,"deny,allow");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,7},new Method("Ljava/lang/String;","indexOf",new String[]{ "Ljava/lang/String;"},"I"));
                code.visitStmt1R(MOVE_RESULT,7);
                code.visitJumpStmt(IF_LEZ,7,-1,L69);
                code.visitLabel(L67);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Lorg/mortbay/jetty/security/HTAccessHandler;","access$000",new String[]{ },"Lorg/mortbay/log/Logger;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitConstStmt(CONST_STRING,8,"==>deny,allow");
                code.visitConstStmt(CONST_4,9, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitConstStmt(CONST_4,10, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 7,8,9,10},new Method("Lorg/mortbay/log/Logger;","debug",new String[]{ "Ljava/lang/String;","Ljava/lang/Object;","Ljava/lang/Object;"},"V"));
                code.visitLabel(L68);
                code.visitConstStmt(CONST_4,7, Integer.valueOf(-1)); // int: 0xffffffff  float:NaN
                code.visitFieldStmt(IPUT,7,11,new Field("Lorg/mortbay/jetty/security/HTAccessHandler$HTAccess;","_order","I"));
                code.visitJumpStmt(GOTO_16,-1,-1,L20);
                code.visitLabel(L69);
                code.visitConstStmt(CONST_STRING,7,"mutual-failure");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,7},new Method("Ljava/lang/String;","indexOf",new String[]{ "Ljava/lang/String;"},"I"));
                code.visitStmt1R(MOVE_RESULT,7);
                code.visitJumpStmt(IF_LEZ,7,-1,L20);
                code.visitLabel(L70);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Lorg/mortbay/jetty/security/HTAccessHandler;","access$000",new String[]{ },"Lorg/mortbay/log/Logger;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitConstStmt(CONST_STRING,8,"==>mutual");
                code.visitConstStmt(CONST_4,9, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitConstStmt(CONST_4,10, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 7,8,9,10},new Method("Lorg/mortbay/log/Logger;","debug",new String[]{ "Ljava/lang/String;","Ljava/lang/Object;","Ljava/lang/Object;"},"V"));
                code.visitLabel(L71);
                code.visitConstStmt(CONST_4,7, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT,7,11,new Field("Lorg/mortbay/jetty/security/HTAccessHandler$HTAccess;","_order","I"));
                code.visitJumpStmt(GOTO_16,-1,-1,L20);
                code.visitLabel(L72);
                code.visitConstStmt(CONST_STRING,7,"allow from");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,7},new Method("Ljava/lang/String;","startsWith",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,7);
                code.visitJumpStmt(IF_EQZ,7,-1,L83);
                code.visitLabel(L73);
                code.visitConstStmt(CONST_16,4, Integer.valueOf(10)); // int: 0x0000000a  float:0.000000
                code.visitLabel(L74);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Ljava/lang/String;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitLabel(L75);
                code.visitJumpStmt(IF_GE,4,2,L77);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,4},new Method("Ljava/lang/String;","charAt",new String[]{ "I"},"C"));
                code.visitStmt1R(MOVE_RESULT,7);
                code.visitConstStmt(CONST_16,8, Integer.valueOf(32)); // int: 0x00000020  float:0.000000
                code.visitJumpStmt(IF_GT,7,8,L77);
                code.visitLabel(L76);
                code.visitStmt2R1N(ADD_INT_LIT8,4,4,1);
                code.visitJumpStmt(GOTO,-1,-1,L75);
                code.visitLabel(L77);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Lorg/mortbay/jetty/security/HTAccessHandler;","access$000",new String[]{ },"Lorg/mortbay/log/Logger;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 7},new Method("Lorg/mortbay/log/Logger;","isDebugEnabled",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,7);
                code.visitJumpStmt(IF_EQZ,7,-1,L79);
                code.visitLabel(L78);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Lorg/mortbay/jetty/security/HTAccessHandler;","access$000",new String[]{ },"Lorg/mortbay/log/Logger;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitTypeStmt(NEW_INSTANCE,8,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 8},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,9,"allow process:");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8,9},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,4},new Method("Ljava/lang/String;","substring",new String[]{ "I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,9);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8,9},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitConstStmt(CONST_4,9, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitConstStmt(CONST_4,10, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 7,8,9,10},new Method("Lorg/mortbay/log/Logger;","debug",new String[]{ "Ljava/lang/String;","Ljava/lang/Object;","Ljava/lang/Object;"},"V"));
                code.visitLabel(L79);
                code.visitTypeStmt(NEW_INSTANCE,6,-1,"Ljava/util/StringTokenizer;");
                code.visitLabel(L80);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,4},new Method("Ljava/lang/String;","substring",new String[]{ "I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 6,7},new Method("Ljava/util/StringTokenizer;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L81);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Ljava/util/StringTokenizer;","hasMoreTokens",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,7);
                code.visitJumpStmt(IF_EQZ,7,-1,L20);
                code.visitLabel(L82);
                code.visitFieldStmt(IGET_OBJECT,7,11,new Field("Lorg/mortbay/jetty/security/HTAccessHandler$HTAccess;","_allowList","Ljava/util/ArrayList;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Ljava/util/StringTokenizer;","nextToken",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7,8},new Method("Ljava/util/ArrayList;","add",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitJumpStmt(GOTO,-1,-1,L81);
                code.visitLabel(L83);
                code.visitConstStmt(CONST_STRING,7,"deny from");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,7},new Method("Ljava/lang/String;","startsWith",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,7);
                code.visitJumpStmt(IF_EQZ,7,-1,L94);
                code.visitLabel(L84);
                code.visitConstStmt(CONST_16,4, Integer.valueOf(9)); // int: 0x00000009  float:0.000000
                code.visitLabel(L85);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Ljava/lang/String;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitLabel(L86);
                code.visitJumpStmt(IF_GE,4,2,L88);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,4},new Method("Ljava/lang/String;","charAt",new String[]{ "I"},"C"));
                code.visitStmt1R(MOVE_RESULT,7);
                code.visitConstStmt(CONST_16,8, Integer.valueOf(32)); // int: 0x00000020  float:0.000000
                code.visitJumpStmt(IF_GT,7,8,L88);
                code.visitLabel(L87);
                code.visitStmt2R1N(ADD_INT_LIT8,4,4,1);
                code.visitJumpStmt(GOTO,-1,-1,L86);
                code.visitLabel(L88);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Lorg/mortbay/jetty/security/HTAccessHandler;","access$000",new String[]{ },"Lorg/mortbay/log/Logger;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 7},new Method("Lorg/mortbay/log/Logger;","isDebugEnabled",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,7);
                code.visitJumpStmt(IF_EQZ,7,-1,L90);
                code.visitLabel(L89);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Lorg/mortbay/jetty/security/HTAccessHandler;","access$000",new String[]{ },"Lorg/mortbay/log/Logger;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitTypeStmt(NEW_INSTANCE,8,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 8},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,9,"deny process:");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8,9},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,4},new Method("Ljava/lang/String;","substring",new String[]{ "I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,9);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8,9},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitConstStmt(CONST_4,9, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitConstStmt(CONST_4,10, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 7,8,9,10},new Method("Lorg/mortbay/log/Logger;","debug",new String[]{ "Ljava/lang/String;","Ljava/lang/Object;","Ljava/lang/Object;"},"V"));
                code.visitLabel(L90);
                code.visitTypeStmt(NEW_INSTANCE,6,-1,"Ljava/util/StringTokenizer;");
                code.visitLabel(L91);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,4},new Method("Ljava/lang/String;","substring",new String[]{ "I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 6,7},new Method("Ljava/util/StringTokenizer;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L92);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Ljava/util/StringTokenizer;","hasMoreTokens",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,7);
                code.visitJumpStmt(IF_EQZ,7,-1,L20);
                code.visitLabel(L93);
                code.visitFieldStmt(IGET_OBJECT,7,11,new Field("Lorg/mortbay/jetty/security/HTAccessHandler$HTAccess;","_denyList","Ljava/util/ArrayList;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Ljava/util/StringTokenizer;","nextToken",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7,8},new Method("Ljava/util/ArrayList;","add",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitJumpStmt(GOTO,-1,-1,L92);
                code.visitLabel(L94);
                code.visitConstStmt(CONST_STRING,7,"</Limit>");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,7},new Method("Ljava/lang/String;","startsWith",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,7);
                code.visitJumpStmt(IF_EQZ,7,-1,L20);
                code.visitJumpStmt(GOTO_16,-1,-1,L0);
                code.visitLabel(L95);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m004_checkAccess(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/security/HTAccessHandler$HTAccess;","checkAccess",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(14);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"host");
                ddv.visitParameterName(1,"ip");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(417,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(418,L2);
                ddv.visitStartLocal(0,L2,"alp","Z",null);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(421,L3);
                ddv.visitStartLocal(2,L3,"dep","Z",null);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(491,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(425,L5);
                DexLabel L6=new DexLabel();
                ddv.visitStartLocal(4,L6,"i","I",null);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(427,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(428,L8);
                ddv.visitStartLocal(3,L8,"elm","Ljava/lang/String;",null);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(430,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(458,L10);
                ddv.visitEndLocal(3,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(460,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(461,L12);
                ddv.visitRestartLocal(3,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(463,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(488,L14);
                ddv.visitEndLocal(3,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(489,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(435,L16);
                ddv.visitRestartLocal(3,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(436,L17);
                ddv.visitStartLocal(1,L17,"c","C",null);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(439,L18);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(441,L19);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(442,L20);
                DexLabel L21=new DexLabel();
                ddv.visitLineNumber(448,L21);
                DexLabel L22=new DexLabel();
                ddv.visitLineNumber(450,L22);
                DexLabel L23=new DexLabel();
                ddv.visitLineNumber(451,L23);
                DexLabel L24=new DexLabel();
                ddv.visitLineNumber(425,L24);
                DexLabel L25=new DexLabel();
                ddv.visitLineNumber(468,L25);
                ddv.visitEndLocal(1,L25);
                DexLabel L26=new DexLabel();
                ddv.visitLineNumber(469,L26);
                ddv.visitRestartLocal(1,L26);
                DexLabel L27=new DexLabel();
                ddv.visitLineNumber(471,L27);
                DexLabel L28=new DexLabel();
                ddv.visitLineNumber(473,L28);
                DexLabel L29=new DexLabel();
                ddv.visitLineNumber(474,L29);
                DexLabel L30=new DexLabel();
                ddv.visitLineNumber(479,L30);
                DexLabel L31=new DexLabel();
                ddv.visitLineNumber(481,L31);
                DexLabel L32=new DexLabel();
                ddv.visitLineNumber(482,L32);
                DexLabel L33=new DexLabel();
                ddv.visitLineNumber(458,L33);
                DexLabel L34=new DexLabel();
                ddv.visitEndLocal(3,L34);
                ddv.visitEndLocal(1,L34);
                DexLabel L35=new DexLabel();
                ddv.visitLineNumber(489,L35);
                DexLabel L36=new DexLabel();
                ddv.visitLineNumber(491,L36);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_16,9, Integer.valueOf(57)); // int: 0x00000039  float:0.000000
                code.visitConstStmt(CONST_16,8, Integer.valueOf(48)); // int: 0x00000030  float:0.000000
                code.visitConstStmt(CONST_4,7, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitConstStmt(CONST_4,6, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitConstStmt(CONST_STRING,10,"all");
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L2);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,5,11,new Field("Lorg/mortbay/jetty/security/HTAccessHandler$HTAccess;","_allowList","Ljava/util/ArrayList;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Ljava/util/ArrayList;","size",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,5);
                code.visitJumpStmt(IF_NEZ,5,-1,L5);
                code.visitFieldStmt(IGET_OBJECT,5,11,new Field("Lorg/mortbay/jetty/security/HTAccessHandler$HTAccess;","_denyList","Ljava/util/ArrayList;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Ljava/util/ArrayList;","size",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,5);
                code.visitJumpStmt(IF_NEZ,5,-1,L5);
                code.visitStmt2R(MOVE,5,7);
                code.visitLabel(L4);
                code.visitStmt1R(RETURN,5);
                code.visitLabel(L5);
                code.visitConstStmt(CONST_4,4, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L6);
                code.visitFieldStmt(IGET_OBJECT,5,11,new Field("Lorg/mortbay/jetty/security/HTAccessHandler$HTAccess;","_allowList","Ljava/util/ArrayList;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Ljava/util/ArrayList;","size",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,5);
                code.visitJumpStmt(IF_GE,4,5,L10);
                code.visitLabel(L7);
                code.visitFieldStmt(IGET_OBJECT,5,11,new Field("Lorg/mortbay/jetty/security/HTAccessHandler$HTAccess;","_allowList","Ljava/util/ArrayList;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,4},new Method("Ljava/util/ArrayList;","get",new String[]{ "I"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitTypeStmt(CHECK_CAST,3,-1,"Ljava/lang/String;");
                code.visitLabel(L8);
                code.visitConstStmt(CONST_STRING,5,"all");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,10},new Method("Ljava/lang/String;","equals",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,5);
                code.visitJumpStmt(IF_EQZ,5,-1,L16);
                code.visitLabel(L9);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitLabel(L10);
                code.visitConstStmt(CONST_4,4, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                DexLabel L37=new DexLabel();
                code.visitLabel(L37);
                code.visitFieldStmt(IGET_OBJECT,5,11,new Field("Lorg/mortbay/jetty/security/HTAccessHandler$HTAccess;","_denyList","Ljava/util/ArrayList;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Ljava/util/ArrayList;","size",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,5);
                code.visitJumpStmt(IF_GE,4,5,L14);
                code.visitLabel(L11);
                code.visitFieldStmt(IGET_OBJECT,5,11,new Field("Lorg/mortbay/jetty/security/HTAccessHandler$HTAccess;","_denyList","Ljava/util/ArrayList;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,4},new Method("Ljava/util/ArrayList;","get",new String[]{ "I"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitTypeStmt(CHECK_CAST,3,-1,"Ljava/lang/String;");
                code.visitLabel(L12);
                code.visitConstStmt(CONST_STRING,5,"all");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,10},new Method("Ljava/lang/String;","equals",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,5);
                code.visitJumpStmt(IF_EQZ,5,-1,L25);
                code.visitLabel(L13);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitLabel(L14);
                code.visitFieldStmt(IGET,5,11,new Field("Lorg/mortbay/jetty/security/HTAccessHandler$HTAccess;","_order","I"));
                code.visitJumpStmt(IF_GEZ,5,-1,L36);
                code.visitLabel(L15);
                DexLabel L38=new DexLabel();
                code.visitJumpStmt(IF_EQZ,2,-1,L38);
                code.visitJumpStmt(IF_EQZ,0,-1,L34);
                code.visitLabel(L38);
                code.visitStmt2R(MOVE,5,7);
                code.visitJumpStmt(GOTO,-1,-1,L4);
                code.visitLabel(L16);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,6},new Method("Ljava/lang/String;","charAt",new String[]{ "I"},"C"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitLabel(L17);
                code.visitJumpStmt(IF_LT,1,8,L21);
                code.visitJumpStmt(IF_GT,1,9,L21);
                code.visitLabel(L18);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 13,3},new Method("Ljava/lang/String;","startsWith",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,5);
                code.visitJumpStmt(IF_EQZ,5,-1,L24);
                code.visitLabel(L19);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitLabel(L20);
                code.visitJumpStmt(GOTO,-1,-1,L10);
                code.visitLabel(L21);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 12,3},new Method("Ljava/lang/String;","endsWith",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,5);
                code.visitJumpStmt(IF_EQZ,5,-1,L24);
                code.visitLabel(L22);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitLabel(L23);
                code.visitJumpStmt(GOTO,-1,-1,L10);
                code.visitLabel(L24);
                code.visitStmt2R1N(ADD_INT_LIT8,4,4,1);
                code.visitJumpStmt(GOTO,-1,-1,L6);
                code.visitLabel(L25);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,6},new Method("Ljava/lang/String;","charAt",new String[]{ "I"},"C"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitLabel(L26);
                code.visitJumpStmt(IF_LT,1,8,L30);
                code.visitJumpStmt(IF_GT,1,9,L30);
                code.visitLabel(L27);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 13,3},new Method("Ljava/lang/String;","startsWith",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,5);
                code.visitJumpStmt(IF_EQZ,5,-1,L33);
                code.visitLabel(L28);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitLabel(L29);
                code.visitJumpStmt(GOTO,-1,-1,L14);
                code.visitLabel(L30);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 12,3},new Method("Ljava/lang/String;","endsWith",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,5);
                code.visitJumpStmt(IF_EQZ,5,-1,L33);
                code.visitLabel(L31);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitLabel(L32);
                code.visitJumpStmt(GOTO,-1,-1,L14);
                code.visitLabel(L33);
                code.visitStmt2R1N(ADD_INT_LIT8,4,4,1);
                code.visitJumpStmt(GOTO,-1,-1,L37);
                code.visitLabel(L34);
                code.visitStmt2R(MOVE,5,6);
                code.visitLabel(L35);
                code.visitJumpStmt(GOTO,-1,-1,L4);
                code.visitLabel(L36);
                DexLabel L39=new DexLabel();
                code.visitJumpStmt(IF_EQZ,0,-1,L39);
                code.visitJumpStmt(IF_NEZ,2,-1,L39);
                code.visitStmt2R(MOVE,5,7);
                code.visitJumpStmt(GOTO,-1,-1,L4);
                code.visitLabel(L39);
                code.visitStmt2R(MOVE,5,6);
                code.visitJumpStmt(GOTO,-1,-1,L4);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m005_checkAuth(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/security/HTAccessHandler$HTAccess;","checkAuth",new String[]{ "Ljava/lang/String;","Ljava/lang/String;","Lorg/mortbay/jetty/security/UserRealm;","Lorg/mortbay/jetty/Request;"},"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(14);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"user");
                ddv.visitParameterName(1,"pass");
                ddv.visitParameterName(2,"realm");
                ddv.visitParameterName(3,"request");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(497,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(498,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(531,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(502,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(503,L4);
                ddv.visitStartLocal(5,L4,"principal","Ljava/security/Principal;",null);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(506,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(507,L6);
                ddv.visitStartLocal(0,L6,"code","Ljava/lang/String;",null);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(508,L7);
                ddv.visitStartLocal(6,L7,"salt","Ljava/lang/String;",null);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(509,L8);
                ddv.visitStartLocal(1,L8,"cred","Ljava/lang/String;",null);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(510,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(502,L10);
                ddv.visitEndLocal(5,L10);
                ddv.visitEndLocal(0,L10);
                ddv.visitEndLocal(6,L10);
                ddv.visitEndLocal(1,L10);
                DexLabel L11=new DexLabel();
                ddv.visitRestartLocal(0,L11);
                ddv.visitRestartLocal(5,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(507,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(508,L13);
                ddv.visitRestartLocal(6,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(513,L14);
                ddv.visitEndLocal(0,L14);
                ddv.visitEndLocal(6,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(515,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(516,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(518,L17);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(520,L18);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(521,L19);
                ddv.visitStartLocal(4,L19,"gps","Ljava/util/ArrayList;",null);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(522,L20);
                DexLabel L21=new DexLabel();
                ddv.visitStartLocal(2,L21,"g","I",null);
                DexLabel L22=new DexLabel();
                ddv.visitEndLocal(2,L22);
                ddv.visitStartLocal(3,L22,"g","I",null);
                DexLabel L23=new DexLabel();
                ddv.visitRestartLocal(2,L23);
                DexLabel L24=new DexLabel();
                ddv.visitLineNumber(523,L24);
                ddv.visitEndLocal(3,L24);
                DexLabel L25=new DexLabel();
                ddv.visitLineNumber(524,L25);
                DexLabel L26=new DexLabel();
                ddv.visitLineNumber(526,L26);
                ddv.visitEndLocal(4,L26);
                ddv.visitEndLocal(2,L26);
                DexLabel L27=new DexLabel();
                ddv.visitLineNumber(528,L27);
                DexLabel L28=new DexLabel();
                ddv.visitLineNumber(531,L28);
                DexLabel L29=new DexLabel();
                ddv.visitRestartLocal(2,L29);
                ddv.visitRestartLocal(4,L29);
                DexLabel L30=new DexLabel();
                ddv.visitRestartLocal(3,L30);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,7,9,new Field("Lorg/mortbay/jetty/security/HTAccessHandler$HTAccess;","_requireName","Ljava/lang/String;"));
                code.visitJumpStmt(IF_NEZ,7,-1,L3);
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,7, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitLabel(L2);
                code.visitStmt1R(RETURN,7);
                code.visitLabel(L3);
                code.visitJumpStmt(IF_NEZ,12,-1,L10);
                code.visitConstStmt(CONST_4,7, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitStmt2R(MOVE_OBJECT,5,7);
                code.visitLabel(L4);
                code.visitJumpStmt(IF_NEZ,5,-1,L14);
                code.visitLabel(L5);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 9,10},new Method("Lorg/mortbay/jetty/security/HTAccessHandler$HTAccess;","getUserCode",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L6);
                code.visitJumpStmt(IF_EQZ,0,-1,L11);
                code.visitConstStmt(CONST_4,7, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitConstStmt(CONST_4,8, Integer.valueOf(2)); // int: 0x00000002  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,7,8},new Method("Ljava/lang/String;","substring",new String[]{ "I","I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitStmt2R(MOVE_OBJECT,6,7);
                code.visitLabel(L7);
                code.visitJumpStmt(IF_EQZ,10,-1,L13);
                code.visitJumpStmt(IF_EQZ,11,-1,L13);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 11,6},new Method("Lorg/mortbay/jetty/security/UnixCrypt;","crypt",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitStmt2R(MOVE_OBJECT,1,7);
                code.visitLabel(L8);
                code.visitJumpStmt(IF_EQZ,0,-1,L9);
                code.visitConstStmt(CONST_STRING,7,"");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,7},new Method("Ljava/lang/String;","equals",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,7);
                DexLabel L31=new DexLabel();
                code.visitJumpStmt(IF_EQZ,7,-1,L31);
                code.visitConstStmt(CONST_STRING,7,"");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 11,7},new Method("Ljava/lang/String;","equals",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,7);
                code.visitJumpStmt(IF_EQZ,7,-1,L9);
                code.visitLabel(L31);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/String;","equals",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,7);
                code.visitJumpStmt(IF_NEZ,7,-1,L14);
                code.visitLabel(L9);
                code.visitConstStmt(CONST_4,7, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitLabel(L10);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 12,10,11,13},new Method("Lorg/mortbay/jetty/security/UserRealm;","authenticate",new String[]{ "Ljava/lang/String;","Ljava/lang/Object;","Lorg/mortbay/jetty/Request;"},"Ljava/security/Principal;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitStmt2R(MOVE_OBJECT,5,7);
                code.visitJumpStmt(GOTO,-1,-1,L4);
                code.visitLabel(L11);
                code.visitStmt2R(MOVE_OBJECT,6,10);
                code.visitLabel(L12);
                code.visitJumpStmt(GOTO,-1,-1,L7);
                code.visitLabel(L13);
                code.visitConstStmt(CONST_4,7, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitStmt2R(MOVE_OBJECT,1,7);
                code.visitJumpStmt(GOTO,-1,-1,L8);
                code.visitLabel(L14);
                code.visitFieldStmt(IGET_OBJECT,7,9,new Field("Lorg/mortbay/jetty/security/HTAccessHandler$HTAccess;","_requireName","Ljava/lang/String;"));
                code.visitConstStmt(CONST_STRING,8,"user");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7,8},new Method("Ljava/lang/String;","equalsIgnoreCase",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,7);
                code.visitJumpStmt(IF_EQZ,7,-1,L17);
                code.visitLabel(L15);
                code.visitFieldStmt(IGET_OBJECT,7,9,new Field("Lorg/mortbay/jetty/security/HTAccessHandler$HTAccess;","_requireEntities","Ljava/util/HashSet;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7,10},new Method("Ljava/util/HashSet;","contains",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,7);
                code.visitJumpStmt(IF_EQZ,7,-1,L28);
                code.visitLabel(L16);
                code.visitConstStmt(CONST_4,7, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitLabel(L17);
                code.visitFieldStmt(IGET_OBJECT,7,9,new Field("Lorg/mortbay/jetty/security/HTAccessHandler$HTAccess;","_requireName","Ljava/lang/String;"));
                code.visitConstStmt(CONST_STRING,8,"group");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7,8},new Method("Ljava/lang/String;","equalsIgnoreCase",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,7);
                code.visitJumpStmt(IF_EQZ,7,-1,L26);
                code.visitLabel(L18);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 9,10},new Method("Lorg/mortbay/jetty/security/HTAccessHandler$HTAccess;","getUserGroups",new String[]{ "Ljava/lang/String;"},"Ljava/util/ArrayList;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitLabel(L19);
                code.visitJumpStmt(IF_EQZ,4,-1,L28);
                code.visitLabel(L20);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Ljava/util/ArrayList;","size",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitLabel(L21);
                code.visitStmt2R(MOVE,3,2);
                code.visitLabel(L22);
                code.visitConstStmt(CONST_4,7, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitStmt3R(SUB_INT,2,3,7);
                code.visitLabel(L23);
                code.visitJumpStmt(IF_LEZ,3,-1,L28);
                code.visitLabel(L24);
                code.visitFieldStmt(IGET_OBJECT,7,9,new Field("Lorg/mortbay/jetty/security/HTAccessHandler$HTAccess;","_requireEntities","Ljava/util/HashSet;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,2},new Method("Ljava/util/ArrayList;","get",new String[]{ "I"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7,8},new Method("Ljava/util/HashSet;","contains",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,7);
                code.visitJumpStmt(IF_EQZ,7,-1,L29);
                code.visitLabel(L25);
                code.visitConstStmt(CONST_4,7, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitLabel(L26);
                code.visitFieldStmt(IGET_OBJECT,7,9,new Field("Lorg/mortbay/jetty/security/HTAccessHandler$HTAccess;","_requireName","Ljava/lang/String;"));
                code.visitConstStmt(CONST_STRING,8,"valid-user");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7,8},new Method("Ljava/lang/String;","equalsIgnoreCase",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,7);
                code.visitJumpStmt(IF_EQZ,7,-1,L28);
                code.visitLabel(L27);
                code.visitConstStmt(CONST_4,7, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitJumpStmt(GOTO_16,-1,-1,L2);
                code.visitLabel(L28);
                code.visitConstStmt(CONST_4,7, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitJumpStmt(GOTO_16,-1,-1,L2);
                code.visitLabel(L29);
                code.visitStmt2R(MOVE,3,2);
                code.visitLabel(L30);
                code.visitJumpStmt(GOTO,-1,-1,L22);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m006_getGroupResource(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/security/HTAccessHandler$HTAccess;","getGroupResource",new String[]{ },"Lorg/mortbay/resource/Resource;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(392,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/security/HTAccessHandler$HTAccess;","_groupResource","Lorg/mortbay/resource/Resource;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m007_getLastModified(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/security/HTAccessHandler$HTAccess;","getLastModified",new String[]{ },"J"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(380,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_WIDE,0,2,new Field("Lorg/mortbay/jetty/security/HTAccessHandler$HTAccess;","_lastModified","J"));
                code.visitStmt1R(RETURN_WIDE,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m008_getMethods(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/security/HTAccessHandler$HTAccess;","getMethods",new String[]{ },"Ljava/util/HashMap;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(374,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/security/HTAccessHandler$HTAccess;","_methods","Ljava/util/HashMap;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m009_getName(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/security/HTAccessHandler$HTAccess;","getName",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(404,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/security/HTAccessHandler$HTAccess;","_name","Ljava/lang/String;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m010_getSatisfy(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/security/HTAccessHandler$HTAccess;","getSatisfy",new String[]{ },"I"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(398,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET,0,1,new Field("Lorg/mortbay/jetty/security/HTAccessHandler$HTAccess;","_satisfy","I"));
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m011_getType(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/security/HTAccessHandler$HTAccess;","getType",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(410,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/security/HTAccessHandler$HTAccess;","_type","Ljava/lang/String;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m012_getUserResource(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/security/HTAccessHandler$HTAccess;","getUserResource",new String[]{ },"Lorg/mortbay/resource/Resource;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(386,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/security/HTAccessHandler$HTAccess;","_userResource","Lorg/mortbay/resource/Resource;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m013_isAccessLimited(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/security/HTAccessHandler$HTAccess;","isAccessLimited",new String[]{ },"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(537,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(538,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(540,L2);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/security/HTAccessHandler$HTAccess;","_allowList","Ljava/util/ArrayList;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/util/ArrayList;","size",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_GTZ,0,-1,L1);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/security/HTAccessHandler$HTAccess;","_denyList","Ljava/util/ArrayList;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/util/ArrayList;","size",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,0);
                DexLabel L3=new DexLabel();
                code.visitJumpStmt(IF_LEZ,0,-1,L3);
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitLabel(L2);
                code.visitStmt1R(RETURN,0);
                code.visitLabel(L3);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m014_isAuthLimited(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/security/HTAccessHandler$HTAccess;","isAuthLimited",new String[]{ },"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(546,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(547,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(549,L2);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/security/HTAccessHandler$HTAccess;","_requireName","Ljava/lang/String;"));
                DexLabel L3=new DexLabel();
                code.visitJumpStmt(IF_EQZ,0,-1,L3);
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitLabel(L2);
                code.visitStmt1R(RETURN,0);
                code.visitLabel(L3);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m015_isForbidden(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/security/HTAccessHandler$HTAccess;","isForbidden",new String[]{ },"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(368,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_BOOLEAN,0,1,new Field("Lorg/mortbay/jetty/security/HTAccessHandler$HTAccess;","_forbidden","Z"));
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m016_toString(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/security/HTAccessHandler$HTAccess;","toString",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(671,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(673,L1);
                ddv.visitStartLocal(0,L1,"buf","Ljava/lang/StringBuffer;",null);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(674,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(675,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(676,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(677,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(678,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(679,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(680,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(681,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(682,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(683,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(684,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(685,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(686,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(692,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(693,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(694,L17);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(695,L18);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(696,L19);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(697,L20);
                DexLabel L21=new DexLabel();
                ddv.visitLineNumber(698,L21);
                DexLabel L22=new DexLabel();
                ddv.visitLineNumber(699,L22);
                DexLabel L23=new DexLabel();
                ddv.visitLineNumber(701,L23);
                DexLabel L24=new DexLabel();
                ddv.visitLineNumber(687,L24);
                DexLabel L25=new DexLabel();
                ddv.visitLineNumber(688,L25);
                DexLabel L26=new DexLabel();
                ddv.visitLineNumber(690,L26);
                code.visitLabel(L0);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/lang/StringBuffer;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/lang/StringBuffer;","<init>",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitConstStmt(CONST_STRING,1,"AuthUserFile=");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L2);
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/jetty/security/HTAccessHandler$HTAccess;","_userFile","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L3);
                code.visitConstStmt(CONST_STRING,1,", AuthGroupFile=");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L4);
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/jetty/security/HTAccessHandler$HTAccess;","_groupFile","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L5);
                code.visitConstStmt(CONST_STRING,1,", AuthName=");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L6);
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/jetty/security/HTAccessHandler$HTAccess;","_name","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L7);
                code.visitConstStmt(CONST_STRING,1,", AuthType=");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L8);
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/jetty/security/HTAccessHandler$HTAccess;","_type","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L9);
                code.visitConstStmt(CONST_STRING,1,", Methods=");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L10);
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/jetty/security/HTAccessHandler$HTAccess;","_methods","Ljava/util/HashMap;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L11);
                code.visitConstStmt(CONST_STRING,1,", satisfy=");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L12);
                code.visitFieldStmt(IGET,1,2,new Field("Lorg/mortbay/jetty/security/HTAccessHandler$HTAccess;","_satisfy","I"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "I"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L13);
                code.visitFieldStmt(IGET,1,2,new Field("Lorg/mortbay/jetty/security/HTAccessHandler$HTAccess;","_order","I"));
                code.visitJumpStmt(IF_GEZ,1,-1,L24);
                code.visitLabel(L14);
                code.visitConstStmt(CONST_STRING,1,", order=deny,allow");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L15);
                code.visitConstStmt(CONST_STRING,1,", Allow from=");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L16);
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/jetty/security/HTAccessHandler$HTAccess;","_allowList","Ljava/util/ArrayList;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L17);
                code.visitConstStmt(CONST_STRING,1,", deny from=");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L18);
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/jetty/security/HTAccessHandler$HTAccess;","_denyList","Ljava/util/ArrayList;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L19);
                code.visitConstStmt(CONST_STRING,1,", requireName=");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L20);
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/jetty/security/HTAccessHandler$HTAccess;","_requireName","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L21);
                code.visitConstStmt(CONST_STRING,1," ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L22);
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/jetty/security/HTAccessHandler$HTAccess;","_requireEntities","Ljava/util/HashSet;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L23);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/lang/StringBuffer;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitStmt1R(RETURN_OBJECT,1);
                code.visitLabel(L24);
                code.visitFieldStmt(IGET,1,2,new Field("Lorg/mortbay/jetty/security/HTAccessHandler$HTAccess;","_order","I"));
                code.visitJumpStmt(IF_LEZ,1,-1,L26);
                code.visitLabel(L25);
                code.visitConstStmt(CONST_STRING,1,", order=allow,deny");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuffer;"));
                code.visitJumpStmt(GOTO,-1,-1,L15);
                code.visitLabel(L26);
                code.visitConstStmt(CONST_STRING,1,", order=mutual-failure");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuffer;"));
                code.visitJumpStmt(GOTO,-1,-1,L15);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
