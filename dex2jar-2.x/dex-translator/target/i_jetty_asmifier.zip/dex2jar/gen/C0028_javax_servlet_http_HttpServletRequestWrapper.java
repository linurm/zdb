package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0028_javax_servlet_http_HttpServletRequestWrapper {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(ACC_PUBLIC,"Ljavax/servlet/http/HttpServletRequestWrapper;","Ljavax/servlet/ServletRequestWrapper;",new String[]{ "Ljavax/servlet/http/HttpServletRequest;"});
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("HttpServletRequestWrapper.java");
        m000__init_(cv);
        m001__getHttpServletRequest(cv);
        m002_getAuthType(cv);
        m003_getContextPath(cv);
        m004_getCookies(cv);
        m005_getDateHeader(cv);
        m006_getHeader(cv);
        m007_getHeaderNames(cv);
        m008_getHeaders(cv);
        m009_getIntHeader(cv);
        m010_getMethod(cv);
        m011_getPathInfo(cv);
        m012_getPathTranslated(cv);
        m013_getQueryString(cv);
        m014_getRemoteUser(cv);
        m015_getRequestURI(cv);
        m016_getRequestURL(cv);
        m017_getRequestedSessionId(cv);
        m018_getServletPath(cv);
        m019_getSession(cv);
        m020_getSession(cv);
        m021_getUserPrincipal(cv);
        m022_isRequestedSessionIdFromCookie(cv);
        m023_isRequestedSessionIdFromURL(cv);
        m024_isRequestedSessionIdFromUrl(cv);
        m025_isRequestedSessionIdValid(cv);
        m026_isUserInRole(cv);
    }
    public static void m000__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Ljavax/servlet/http/HttpServletRequestWrapper;","<init>",new String[]{ "Ljavax/servlet/http/HttpServletRequest;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"request");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(54,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(55,L1);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1},new Method("Ljavax/servlet/ServletRequestWrapper;","<init>",new String[]{ "Ljavax/servlet/ServletRequest;"},"V"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001__getHttpServletRequest(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PRIVATE, new Method("Ljavax/servlet/http/HttpServletRequestWrapper;","_getHttpServletRequest",new String[]{ },"Ljavax/servlet/http/HttpServletRequest;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(1);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(58,L0);
                DexLabel L1=new DexLabel();
                ddv.visitEndLocal(0,L1);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_SUPER,new int[]{ 0},new Method("Ljavax/servlet/ServletRequestWrapper;","getRequest",new String[]{ },"Ljavax/servlet/ServletRequest;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L1);
                code.visitTypeStmt(CHECK_CAST,0,-1,"Ljavax/servlet/http/HttpServletRequest;");
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m002_getAuthType(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Ljavax/servlet/http/HttpServletRequestWrapper;","getAuthType",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(67,L0);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1},new Method("Ljavax/servlet/http/HttpServletRequestWrapper;","_getHttpServletRequest",new String[]{ },"Ljavax/servlet/http/HttpServletRequest;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0},new Method("Ljavax/servlet/http/HttpServletRequest;","getAuthType",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m003_getContextPath(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Ljavax/servlet/http/HttpServletRequestWrapper;","getContextPath",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(150,L0);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1},new Method("Ljavax/servlet/http/HttpServletRequestWrapper;","_getHttpServletRequest",new String[]{ },"Ljavax/servlet/http/HttpServletRequest;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0},new Method("Ljavax/servlet/http/HttpServletRequest;","getContextPath",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m004_getCookies(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Ljavax/servlet/http/HttpServletRequestWrapper;","getCookies",new String[]{ },"[Ljavax/servlet/http/Cookie;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(75,L0);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1},new Method("Ljavax/servlet/http/HttpServletRequestWrapper;","_getHttpServletRequest",new String[]{ },"Ljavax/servlet/http/HttpServletRequest;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0},new Method("Ljavax/servlet/http/HttpServletRequest;","getCookies",new String[]{ },"[Ljavax/servlet/http/Cookie;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m005_getDateHeader(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Ljavax/servlet/http/HttpServletRequestWrapper;","getDateHeader",new String[]{ "Ljava/lang/String;"},"J"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"name");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(83,L0);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2},new Method("Ljavax/servlet/http/HttpServletRequestWrapper;","_getHttpServletRequest",new String[]{ },"Ljavax/servlet/http/HttpServletRequest;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,3},new Method("Ljavax/servlet/http/HttpServletRequest;","getDateHeader",new String[]{ "Ljava/lang/String;"},"J"));
                code.visitStmt1R(MOVE_RESULT_WIDE,0);
                code.visitStmt1R(RETURN_WIDE,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m006_getHeader(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Ljavax/servlet/http/HttpServletRequestWrapper;","getHeader",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"name");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(91,L0);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1},new Method("Ljavax/servlet/http/HttpServletRequestWrapper;","_getHttpServletRequest",new String[]{ },"Ljavax/servlet/http/HttpServletRequest;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,2},new Method("Ljavax/servlet/http/HttpServletRequest;","getHeader",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m007_getHeaderNames(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Ljavax/servlet/http/HttpServletRequestWrapper;","getHeaderNames",new String[]{ },"Ljava/util/Enumeration;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(108,L0);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1},new Method("Ljavax/servlet/http/HttpServletRequestWrapper;","_getHttpServletRequest",new String[]{ },"Ljavax/servlet/http/HttpServletRequest;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0},new Method("Ljavax/servlet/http/HttpServletRequest;","getHeaderNames",new String[]{ },"Ljava/util/Enumeration;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m008_getHeaders(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Ljavax/servlet/http/HttpServletRequestWrapper;","getHeaders",new String[]{ "Ljava/lang/String;"},"Ljava/util/Enumeration;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"name");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(99,L0);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1},new Method("Ljavax/servlet/http/HttpServletRequestWrapper;","_getHttpServletRequest",new String[]{ },"Ljavax/servlet/http/HttpServletRequest;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,2},new Method("Ljavax/servlet/http/HttpServletRequest;","getHeaders",new String[]{ "Ljava/lang/String;"},"Ljava/util/Enumeration;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m009_getIntHeader(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Ljavax/servlet/http/HttpServletRequestWrapper;","getIntHeader",new String[]{ "Ljava/lang/String;"},"I"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"name");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(117,L0);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1},new Method("Ljavax/servlet/http/HttpServletRequestWrapper;","_getHttpServletRequest",new String[]{ },"Ljavax/servlet/http/HttpServletRequest;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,2},new Method("Ljavax/servlet/http/HttpServletRequest;","getIntHeader",new String[]{ "Ljava/lang/String;"},"I"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m010_getMethod(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Ljavax/servlet/http/HttpServletRequestWrapper;","getMethod",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(125,L0);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1},new Method("Ljavax/servlet/http/HttpServletRequestWrapper;","_getHttpServletRequest",new String[]{ },"Ljavax/servlet/http/HttpServletRequest;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0},new Method("Ljavax/servlet/http/HttpServletRequest;","getMethod",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m011_getPathInfo(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Ljavax/servlet/http/HttpServletRequestWrapper;","getPathInfo",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(133,L0);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1},new Method("Ljavax/servlet/http/HttpServletRequestWrapper;","_getHttpServletRequest",new String[]{ },"Ljavax/servlet/http/HttpServletRequest;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0},new Method("Ljavax/servlet/http/HttpServletRequest;","getPathInfo",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m012_getPathTranslated(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Ljavax/servlet/http/HttpServletRequestWrapper;","getPathTranslated",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(142,L0);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1},new Method("Ljavax/servlet/http/HttpServletRequestWrapper;","_getHttpServletRequest",new String[]{ },"Ljavax/servlet/http/HttpServletRequest;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0},new Method("Ljavax/servlet/http/HttpServletRequest;","getPathTranslated",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m013_getQueryString(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Ljavax/servlet/http/HttpServletRequestWrapper;","getQueryString",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(158,L0);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1},new Method("Ljavax/servlet/http/HttpServletRequestWrapper;","_getHttpServletRequest",new String[]{ },"Ljavax/servlet/http/HttpServletRequest;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0},new Method("Ljavax/servlet/http/HttpServletRequest;","getQueryString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m014_getRemoteUser(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Ljavax/servlet/http/HttpServletRequestWrapper;","getRemoteUser",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(166,L0);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1},new Method("Ljavax/servlet/http/HttpServletRequestWrapper;","_getHttpServletRequest",new String[]{ },"Ljavax/servlet/http/HttpServletRequest;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0},new Method("Ljavax/servlet/http/HttpServletRequest;","getRemoteUser",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m015_getRequestURI(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Ljavax/servlet/http/HttpServletRequestWrapper;","getRequestURI",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(202,L0);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1},new Method("Ljavax/servlet/http/HttpServletRequestWrapper;","_getHttpServletRequest",new String[]{ },"Ljavax/servlet/http/HttpServletRequest;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0},new Method("Ljavax/servlet/http/HttpServletRequest;","getRequestURI",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m016_getRequestURL(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Ljavax/servlet/http/HttpServletRequestWrapper;","getRequestURL",new String[]{ },"Ljava/lang/StringBuffer;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(209,L0);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1},new Method("Ljavax/servlet/http/HttpServletRequestWrapper;","_getHttpServletRequest",new String[]{ },"Ljavax/servlet/http/HttpServletRequest;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0},new Method("Ljavax/servlet/http/HttpServletRequest;","getRequestURL",new String[]{ },"Ljava/lang/StringBuffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m017_getRequestedSessionId(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Ljavax/servlet/http/HttpServletRequestWrapper;","getRequestedSessionId",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(194,L0);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1},new Method("Ljavax/servlet/http/HttpServletRequestWrapper;","_getHttpServletRequest",new String[]{ },"Ljavax/servlet/http/HttpServletRequest;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0},new Method("Ljavax/servlet/http/HttpServletRequest;","getRequestedSessionId",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m018_getServletPath(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Ljavax/servlet/http/HttpServletRequestWrapper;","getServletPath",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(218,L0);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1},new Method("Ljavax/servlet/http/HttpServletRequestWrapper;","_getHttpServletRequest",new String[]{ },"Ljavax/servlet/http/HttpServletRequest;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0},new Method("Ljavax/servlet/http/HttpServletRequest;","getServletPath",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m019_getSession(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Ljavax/servlet/http/HttpServletRequestWrapper;","getSession",new String[]{ },"Ljavax/servlet/http/HttpSession;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(235,L0);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1},new Method("Ljavax/servlet/http/HttpServletRequestWrapper;","_getHttpServletRequest",new String[]{ },"Ljavax/servlet/http/HttpServletRequest;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0},new Method("Ljavax/servlet/http/HttpServletRequest;","getSession",new String[]{ },"Ljavax/servlet/http/HttpSession;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m020_getSession(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Ljavax/servlet/http/HttpServletRequestWrapper;","getSession",new String[]{ "Z"},"Ljavax/servlet/http/HttpSession;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"create");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(227,L0);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1},new Method("Ljavax/servlet/http/HttpServletRequestWrapper;","_getHttpServletRequest",new String[]{ },"Ljavax/servlet/http/HttpServletRequest;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,2},new Method("Ljavax/servlet/http/HttpServletRequest;","getSession",new String[]{ "Z"},"Ljavax/servlet/http/HttpSession;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m021_getUserPrincipal(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Ljavax/servlet/http/HttpServletRequestWrapper;","getUserPrincipal",new String[]{ },"Ljava/security/Principal;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(185,L0);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1},new Method("Ljavax/servlet/http/HttpServletRequestWrapper;","_getHttpServletRequest",new String[]{ },"Ljavax/servlet/http/HttpServletRequest;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0},new Method("Ljavax/servlet/http/HttpServletRequest;","getUserPrincipal",new String[]{ },"Ljava/security/Principal;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m022_isRequestedSessionIdFromCookie(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Ljavax/servlet/http/HttpServletRequestWrapper;","isRequestedSessionIdFromCookie",new String[]{ },"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(253,L0);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1},new Method("Ljavax/servlet/http/HttpServletRequestWrapper;","_getHttpServletRequest",new String[]{ },"Ljavax/servlet/http/HttpServletRequest;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0},new Method("Ljavax/servlet/http/HttpServletRequest;","isRequestedSessionIdFromCookie",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m023_isRequestedSessionIdFromURL(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Ljavax/servlet/http/HttpServletRequestWrapper;","isRequestedSessionIdFromURL",new String[]{ },"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(261,L0);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1},new Method("Ljavax/servlet/http/HttpServletRequestWrapper;","_getHttpServletRequest",new String[]{ },"Ljavax/servlet/http/HttpServletRequest;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0},new Method("Ljavax/servlet/http/HttpServletRequest;","isRequestedSessionIdFromURL",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m024_isRequestedSessionIdFromUrl(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Ljavax/servlet/http/HttpServletRequestWrapper;","isRequestedSessionIdFromUrl",new String[]{ },"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(269,L0);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1},new Method("Ljavax/servlet/http/HttpServletRequestWrapper;","_getHttpServletRequest",new String[]{ },"Ljavax/servlet/http/HttpServletRequest;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0},new Method("Ljavax/servlet/http/HttpServletRequest;","isRequestedSessionIdFromUrl",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m025_isRequestedSessionIdValid(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Ljavax/servlet/http/HttpServletRequestWrapper;","isRequestedSessionIdValid",new String[]{ },"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(244,L0);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1},new Method("Ljavax/servlet/http/HttpServletRequestWrapper;","_getHttpServletRequest",new String[]{ },"Ljavax/servlet/http/HttpServletRequest;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0},new Method("Ljavax/servlet/http/HttpServletRequest;","isRequestedSessionIdValid",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m026_isUserInRole(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Ljavax/servlet/http/HttpServletRequestWrapper;","isUserInRole",new String[]{ "Ljava/lang/String;"},"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"role");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(175,L0);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1},new Method("Ljavax/servlet/http/HttpServletRequestWrapper;","_getHttpServletRequest",new String[]{ },"Ljavax/servlet/http/HttpServletRequest;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,2},new Method("Ljavax/servlet/http/HttpServletRequest;","isUserInRole",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
