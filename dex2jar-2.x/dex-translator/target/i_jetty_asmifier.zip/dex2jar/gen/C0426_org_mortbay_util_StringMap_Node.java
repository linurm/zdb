package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0426_org_mortbay_util_StringMap_Node {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(0,"Lorg/mortbay/util/StringMap$Node;","Ljava/lang/Object;",new String[]{ "Ljava/util/Map$Entry;"});
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("StringMap.java");
        if(cv!=null){
            DexAnnotationVisitor av00 = cv.visitAnnotation("Ldalvik/annotation/EnclosingClass;", Visibility.SYSTEM);
            if(av00 != null) {
                av00.visit("value", new DexType("Lorg/mortbay/util/StringMap;"));
                av00.visitEnd();
            }
        }
        if(cv!=null){
            DexAnnotationVisitor av00 = cv.visitAnnotation("Ldalvik/annotation/InnerClass;", Visibility.SYSTEM);
            if(av00 != null) {
                av00.visit("accessFlags",  Integer.valueOf(10));
                av00.visit("name", "Node");
                av00.visitEnd();
            }
        }
        f000__char(cv);
        f001__children(cv);
        f002__key(cv);
        f003__next(cv);
        f004__ochar(cv);
        f005__value(cv);
        m000__init_(cv);
        m001__init_(cv);
        m002_toString(cv);
        m003_getKey(cv);
        m004_getValue(cv);
        m005_setValue(cv);
        m006_split(cv);
        m007_toString(cv);
    }
    public static void f000__char(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(0, new Field("Lorg/mortbay/util/StringMap$Node;","_char","[C"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f001__children(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(0, new Field("Lorg/mortbay/util/StringMap$Node;","_children","[Lorg/mortbay/util/StringMap$Node;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f002__key(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(0, new Field("Lorg/mortbay/util/StringMap$Node;","_key","Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f003__next(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(0, new Field("Lorg/mortbay/util/StringMap$Node;","_next","Lorg/mortbay/util/StringMap$Node;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f004__ochar(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(0, new Field("Lorg/mortbay/util/StringMap$Node;","_ochar","[C"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f005__value(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(0, new Field("Lorg/mortbay/util/StringMap$Node;","_value","Ljava/lang/Object;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void m000__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_CONSTRUCTOR, new Method("Lorg/mortbay/util/StringMap$Node;","<init>",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(1);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(552,L0);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/lang/Object;","<init>",new String[]{ },"V"));
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_CONSTRUCTOR, new Method("Lorg/mortbay/util/StringMap$Node;","<init>",new String[]{ "Z","Ljava/lang/String;","I"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(9);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"ignoreCase");
                ddv.visitParameterName(1,"s");
                ddv.visitParameterName(2,"offset");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(555,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(556,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(557,L2);
                ddv.visitStartLocal(2,L2,"l","I",null);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(558,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(559,L4);
                DexLabel L5=new DexLabel();
                ddv.visitStartLocal(1,L5,"i","I",null);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(561,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(562,L7);
                ddv.visitStartLocal(0,L7,"c","C",null);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(563,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(565,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(566,L10);
                ddv.visitStartLocal(3,L10,"o","C",null);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(567,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(570,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(559,L13);
                ddv.visitEndLocal(3,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(568,L14);
                ddv.visitRestartLocal(3,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(569,L15);
                DexLabel L16=new DexLabel();
                ddv.visitRestartLocal(3,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(573,L17);
                ddv.visitEndLocal(0,L17);
                ddv.visitEndLocal(3,L17);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 5},new Method("Ljava/lang/Object;","<init>",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7},new Method("Ljava/lang/String;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,4);
                code.visitStmt3R(SUB_INT,2,4,8);
                code.visitLabel(L2);
                code.visitTypeStmt(NEW_ARRAY,4,2,"[C");
                code.visitFieldStmt(IPUT_OBJECT,4,5,new Field("Lorg/mortbay/util/StringMap$Node;","_char","[C"));
                code.visitLabel(L3);
                code.visitTypeStmt(NEW_ARRAY,4,2,"[C");
                code.visitFieldStmt(IPUT_OBJECT,4,5,new Field("Lorg/mortbay/util/StringMap$Node;","_ochar","[C"));
                code.visitLabel(L4);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L5);
                code.visitJumpStmt(IF_GE,1,2,L17);
                code.visitLabel(L6);
                code.visitStmt3R(ADD_INT,4,8,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7,4},new Method("Ljava/lang/String;","charAt",new String[]{ "I"},"C"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitLabel(L7);
                code.visitFieldStmt(IGET_OBJECT,4,5,new Field("Lorg/mortbay/util/StringMap$Node;","_char","[C"));
                code.visitStmt3R(APUT_CHAR,0,4,1);
                code.visitLabel(L8);
                code.visitJumpStmt(IF_EQZ,6,-1,L13);
                code.visitLabel(L9);
                code.visitStmt2R(MOVE,3,0);
                code.visitLabel(L10);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0},new Method("Ljava/lang/Character;","isUpperCase",new String[]{ "C"},"Z"));
                code.visitStmt1R(MOVE_RESULT,4);
                code.visitJumpStmt(IF_EQZ,4,-1,L14);
                code.visitLabel(L11);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0},new Method("Ljava/lang/Character;","toLowerCase",new String[]{ "C"},"C"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitLabel(L12);
                code.visitFieldStmt(IGET_OBJECT,4,5,new Field("Lorg/mortbay/util/StringMap$Node;","_ochar","[C"));
                code.visitStmt3R(APUT_CHAR,3,4,1);
                code.visitLabel(L13);
                code.visitStmt2R1N(ADD_INT_LIT8,1,1,1);
                code.visitJumpStmt(GOTO,-1,-1,L5);
                code.visitLabel(L14);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0},new Method("Ljava/lang/Character;","isLowerCase",new String[]{ "C"},"Z"));
                code.visitStmt1R(MOVE_RESULT,4);
                code.visitJumpStmt(IF_EQZ,4,-1,L12);
                code.visitLabel(L15);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0},new Method("Ljava/lang/Character;","toUpperCase",new String[]{ "C"},"C"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitLabel(L16);
                code.visitJumpStmt(GOTO,-1,-1,L12);
                code.visitLabel(L17);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m002_toString(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PRIVATE, new Method("Lorg/mortbay/util/StringMap$Node;","toString",new String[]{ "Ljava/lang/StringBuffer;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"buf");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(626,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(627,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(628,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(632,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(633,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(634,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(635,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(636,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(637,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(639,L9);
                DexLabel L10=new DexLabel();
                ddv.visitStartLocal(0,L10,"i","I",null);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(641,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(642,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(643,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(639,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(630,L15);
                ddv.visitEndLocal(0,L15);
                DexLabel L16=new DexLabel();
                ddv.visitRestartLocal(0,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(631,L17);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(630,L18);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(645,L19);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(648,L20);
                ddv.visitEndLocal(0,L20);
                DexLabel L21=new DexLabel();
                ddv.visitLineNumber(649,L21);
                DexLabel L22=new DexLabel();
                ddv.visitLineNumber(651,L22);
                DexLabel L23=new DexLabel();
                ddv.visitLineNumber(652,L23);
                DexLabel L24=new DexLabel();
                ddv.visitLineNumber(654,L24);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_STRING,1,"{[");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,1},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/util/StringMap$Node;","_char","[C"));
                code.visitJumpStmt(IF_NEZ,1,-1,L15);
                code.visitLabel(L2);
                code.visitConstStmt(CONST_16,1, Integer.valueOf(45)); // int: 0x0000002d  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,1},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "C"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L3);
                code.visitConstStmt(CONST_16,1, Integer.valueOf(58)); // int: 0x0000003a  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,1},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "C"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L4);
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/util/StringMap$Node;","_key","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,1},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L5);
                code.visitConstStmt(CONST_16,1, Integer.valueOf(61)); // int: 0x0000003d  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,1},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "C"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L6);
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/util/StringMap$Node;","_value","Ljava/lang/Object;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,1},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L7);
                code.visitConstStmt(CONST_16,1, Integer.valueOf(93)); // int: 0x0000005d  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,1},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "C"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L8);
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/util/StringMap$Node;","_children","[Lorg/mortbay/util/StringMap$Node;"));
                code.visitJumpStmt(IF_EQZ,1,-1,L20);
                code.visitLabel(L9);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L10);
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/util/StringMap$Node;","_children","[Lorg/mortbay/util/StringMap$Node;"));
                code.visitStmt2R(ARRAY_LENGTH,1,1);
                code.visitJumpStmt(IF_GE,0,1,L20);
                code.visitLabel(L11);
                code.visitConstStmt(CONST_16,1, Integer.valueOf(124)); // int: 0x0000007c  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,1},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "C"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L12);
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/util/StringMap$Node;","_children","[Lorg/mortbay/util/StringMap$Node;"));
                code.visitStmt3R(AGET_OBJECT,1,1,0);
                code.visitJumpStmt(IF_EQZ,1,-1,L19);
                code.visitLabel(L13);
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/util/StringMap$Node;","_children","[Lorg/mortbay/util/StringMap$Node;"));
                code.visitStmt3R(AGET_OBJECT,1,1,0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1,3},new Method("Lorg/mortbay/util/StringMap$Node;","toString",new String[]{ "Ljava/lang/StringBuffer;"},"V"));
                code.visitLabel(L14);
                code.visitStmt2R1N(ADD_INT_LIT8,0,0,1);
                code.visitJumpStmt(GOTO,-1,-1,L10);
                code.visitLabel(L15);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L16);
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/util/StringMap$Node;","_char","[C"));
                code.visitStmt2R(ARRAY_LENGTH,1,1);
                code.visitJumpStmt(IF_GE,0,1,L3);
                code.visitLabel(L17);
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/util/StringMap$Node;","_char","[C"));
                code.visitStmt3R(AGET_CHAR,1,1,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,1},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "C"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L18);
                code.visitStmt2R1N(ADD_INT_LIT8,0,0,1);
                code.visitJumpStmt(GOTO,-1,-1,L16);
                code.visitLabel(L19);
                code.visitConstStmt(CONST_STRING,1,"-");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,1},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuffer;"));
                code.visitJumpStmt(GOTO,-1,-1,L14);
                code.visitLabel(L20);
                code.visitConstStmt(CONST_16,1, Integer.valueOf(125)); // int: 0x0000007d  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,1},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "C"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L21);
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/util/StringMap$Node;","_next","Lorg/mortbay/util/StringMap$Node;"));
                code.visitJumpStmt(IF_EQZ,1,-1,L24);
                code.visitLabel(L22);
                code.visitConstStmt(CONST_STRING,1,",\n");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,1},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L23);
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/util/StringMap$Node;","_next","Lorg/mortbay/util/StringMap$Node;"));
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1,3},new Method("Lorg/mortbay/util/StringMap$Node;","toString",new String[]{ "Ljava/lang/StringBuffer;"},"V"));
                code.visitLabel(L24);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m003_getKey(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/util/StringMap$Node;","getKey",new String[]{ },"Ljava/lang/Object;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(611,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/util/StringMap$Node;","_key","Ljava/lang/String;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m004_getValue(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/util/StringMap$Node;","getValue",new String[]{ },"Ljava/lang/Object;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(612,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/util/StringMap$Node;","_value","Ljava/lang/Object;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m005_setValue(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/util/StringMap$Node;","setValue",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/Object;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"o");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(613,L0);
                DexLabel L1=new DexLabel();
                ddv.visitStartLocal(0,L1,"old","Ljava/lang/Object;",null);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/util/StringMap$Node;","_value","Ljava/lang/Object;"));
                code.visitLabel(L1);
                code.visitFieldStmt(IPUT_OBJECT,2,1,new Field("Lorg/mortbay/util/StringMap$Node;","_value","Ljava/lang/Object;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m006_split(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(0, new Method("Lorg/mortbay/util/StringMap$Node;","split",new String[]{ "Lorg/mortbay/util/StringMap;","I"},"Lorg/mortbay/util/StringMap$Node;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(10);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"map");
                ddv.visitParameterName(1,"offset");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(577,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(578,L2);
                ddv.visitStartLocal(1,L2,"split","Lorg/mortbay/util/StringMap$Node;",null);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(580,L3);
                ddv.visitStartLocal(0,L3,"sl","I",null);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(581,L4);
                ddv.visitStartLocal(2,L4,"tmp","[C",null);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(582,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(583,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(584,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(586,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(588,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(589,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(590,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(591,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(592,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(595,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(596,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(597,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(598,L17);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(599,L18);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(600,L19);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(602,L20);
                DexLabel L21=new DexLabel();
                ddv.visitLineNumber(603,L21);
                DexLabel L22=new DexLabel();
                ddv.visitLineNumber(604,L22);
                DexLabel L23=new DexLabel();
                ddv.visitLineNumber(605,L23);
                DexLabel L24=new DexLabel();
                ddv.visitLineNumber(606,L24);
                DexLabel L25=new DexLabel();
                ddv.visitLineNumber(608,L25);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,4, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitConstStmt(CONST_4,6, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L1);
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Lorg/mortbay/util/StringMap$Node;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1},new Method("Lorg/mortbay/util/StringMap$Node;","<init>",new String[]{ },"V"));
                code.visitLabel(L2);
                code.visitFieldStmt(IGET_OBJECT,3,7,new Field("Lorg/mortbay/util/StringMap$Node;","_char","[C"));
                code.visitStmt2R(ARRAY_LENGTH,3,3);
                code.visitStmt3R(SUB_INT,0,3,9);
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,2,7,new Field("Lorg/mortbay/util/StringMap$Node;","_char","[C"));
                code.visitLabel(L4);
                code.visitTypeStmt(NEW_ARRAY,3,9,"[C");
                code.visitFieldStmt(IPUT_OBJECT,3,7,new Field("Lorg/mortbay/util/StringMap$Node;","_char","[C"));
                code.visitLabel(L5);
                code.visitTypeStmt(NEW_ARRAY,3,0,"[C");
                code.visitFieldStmt(IPUT_OBJECT,3,1,new Field("Lorg/mortbay/util/StringMap$Node;","_char","[C"));
                code.visitLabel(L6);
                code.visitFieldStmt(IGET_OBJECT,3,7,new Field("Lorg/mortbay/util/StringMap$Node;","_char","[C"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 2,6,3,6,9},new Method("Ljava/lang/System;","arraycopy",new String[]{ "Ljava/lang/Object;","I","Ljava/lang/Object;","I","I"},"V"));
                code.visitLabel(L7);
                code.visitFieldStmt(IGET_OBJECT,3,1,new Field("Lorg/mortbay/util/StringMap$Node;","_char","[C"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 2,9,3,6,0},new Method("Ljava/lang/System;","arraycopy",new String[]{ "Ljava/lang/Object;","I","Ljava/lang/Object;","I","I"},"V"));
                code.visitLabel(L8);
                code.visitFieldStmt(IGET_OBJECT,3,7,new Field("Lorg/mortbay/util/StringMap$Node;","_ochar","[C"));
                code.visitJumpStmt(IF_EQZ,3,-1,L14);
                code.visitLabel(L9);
                code.visitFieldStmt(IGET_OBJECT,2,7,new Field("Lorg/mortbay/util/StringMap$Node;","_ochar","[C"));
                code.visitLabel(L10);
                code.visitTypeStmt(NEW_ARRAY,3,9,"[C");
                code.visitFieldStmt(IPUT_OBJECT,3,7,new Field("Lorg/mortbay/util/StringMap$Node;","_ochar","[C"));
                code.visitLabel(L11);
                code.visitTypeStmt(NEW_ARRAY,3,0,"[C");
                code.visitFieldStmt(IPUT_OBJECT,3,1,new Field("Lorg/mortbay/util/StringMap$Node;","_ochar","[C"));
                code.visitLabel(L12);
                code.visitFieldStmt(IGET_OBJECT,3,7,new Field("Lorg/mortbay/util/StringMap$Node;","_ochar","[C"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 2,6,3,6,9},new Method("Ljava/lang/System;","arraycopy",new String[]{ "Ljava/lang/Object;","I","Ljava/lang/Object;","I","I"},"V"));
                code.visitLabel(L13);
                code.visitFieldStmt(IGET_OBJECT,3,1,new Field("Lorg/mortbay/util/StringMap$Node;","_ochar","[C"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 2,9,3,6,0},new Method("Ljava/lang/System;","arraycopy",new String[]{ "Ljava/lang/Object;","I","Ljava/lang/Object;","I","I"},"V"));
                code.visitLabel(L14);
                code.visitFieldStmt(IGET_OBJECT,3,7,new Field("Lorg/mortbay/util/StringMap$Node;","_key","Ljava/lang/String;"));
                code.visitFieldStmt(IPUT_OBJECT,3,1,new Field("Lorg/mortbay/util/StringMap$Node;","_key","Ljava/lang/String;"));
                code.visitLabel(L15);
                code.visitFieldStmt(IGET_OBJECT,3,7,new Field("Lorg/mortbay/util/StringMap$Node;","_value","Ljava/lang/Object;"));
                code.visitFieldStmt(IPUT_OBJECT,3,1,new Field("Lorg/mortbay/util/StringMap$Node;","_value","Ljava/lang/Object;"));
                code.visitLabel(L16);
                code.visitFieldStmt(IPUT_OBJECT,4,7,new Field("Lorg/mortbay/util/StringMap$Node;","_key","Ljava/lang/String;"));
                code.visitLabel(L17);
                code.visitFieldStmt(IPUT_OBJECT,4,7,new Field("Lorg/mortbay/util/StringMap$Node;","_value","Ljava/lang/Object;"));
                code.visitLabel(L18);
                code.visitFieldStmt(IGET_OBJECT,3,8,new Field("Lorg/mortbay/util/StringMap;","_entrySet","Ljava/util/HashSet;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,7},new Method("Ljava/util/HashSet;","remove",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitJumpStmt(IF_EQZ,3,-1,L20);
                code.visitLabel(L19);
                code.visitFieldStmt(IGET_OBJECT,3,8,new Field("Lorg/mortbay/util/StringMap;","_entrySet","Ljava/util/HashSet;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,1},new Method("Ljava/util/HashSet;","add",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitLabel(L20);
                code.visitFieldStmt(IGET_OBJECT,3,7,new Field("Lorg/mortbay/util/StringMap$Node;","_children","[Lorg/mortbay/util/StringMap$Node;"));
                code.visitFieldStmt(IPUT_OBJECT,3,1,new Field("Lorg/mortbay/util/StringMap$Node;","_children","[Lorg/mortbay/util/StringMap$Node;"));
                code.visitLabel(L21);
                code.visitFieldStmt(IGET,3,8,new Field("Lorg/mortbay/util/StringMap;","_width","I"));
                code.visitTypeStmt(NEW_ARRAY,3,3,"[Lorg/mortbay/util/StringMap$Node;");
                code.visitFieldStmt(IPUT_OBJECT,3,7,new Field("Lorg/mortbay/util/StringMap$Node;","_children","[Lorg/mortbay/util/StringMap$Node;"));
                code.visitLabel(L22);
                code.visitFieldStmt(IGET_OBJECT,3,7,new Field("Lorg/mortbay/util/StringMap$Node;","_children","[Lorg/mortbay/util/StringMap$Node;"));
                code.visitFieldStmt(IGET_OBJECT,4,1,new Field("Lorg/mortbay/util/StringMap$Node;","_char","[C"));
                code.visitStmt3R(AGET_CHAR,4,4,6);
                code.visitFieldStmt(IGET,5,8,new Field("Lorg/mortbay/util/StringMap;","_width","I"));
                code.visitStmt2R(REM_INT_2ADDR,4,5);
                code.visitStmt3R(APUT_OBJECT,1,3,4);
                code.visitLabel(L23);
                code.visitFieldStmt(IGET_OBJECT,3,1,new Field("Lorg/mortbay/util/StringMap$Node;","_ochar","[C"));
                code.visitJumpStmt(IF_EQZ,3,-1,L25);
                code.visitFieldStmt(IGET_OBJECT,3,7,new Field("Lorg/mortbay/util/StringMap$Node;","_children","[Lorg/mortbay/util/StringMap$Node;"));
                code.visitFieldStmt(IGET_OBJECT,4,1,new Field("Lorg/mortbay/util/StringMap$Node;","_ochar","[C"));
                code.visitStmt3R(AGET_CHAR,4,4,6);
                code.visitFieldStmt(IGET,5,8,new Field("Lorg/mortbay/util/StringMap;","_width","I"));
                code.visitStmt2R(REM_INT_2ADDR,4,5);
                code.visitStmt3R(AGET_OBJECT,3,3,4);
                code.visitJumpStmt(IF_EQ,3,1,L25);
                code.visitLabel(L24);
                code.visitFieldStmt(IGET_OBJECT,3,7,new Field("Lorg/mortbay/util/StringMap$Node;","_children","[Lorg/mortbay/util/StringMap$Node;"));
                code.visitFieldStmt(IGET_OBJECT,4,1,new Field("Lorg/mortbay/util/StringMap$Node;","_ochar","[C"));
                code.visitStmt3R(AGET_CHAR,4,4,6);
                code.visitFieldStmt(IGET,5,8,new Field("Lorg/mortbay/util/StringMap;","_width","I"));
                code.visitStmt2R(REM_INT_2ADDR,4,5);
                code.visitStmt3R(APUT_OBJECT,1,3,4);
                code.visitLabel(L25);
                code.visitStmt1R(RETURN_OBJECT,1);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m007_toString(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/util/StringMap$Node;","toString",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexLabel L3=new DexLabel();
                DexLabel L4=new DexLabel();
                code.visitTryCatch(L3,L4,new DexLabel[]{L2},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L5=new DexLabel();
                ddv.visitPrologue(L5);
                ddv.visitLineNumber(616,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(617,L6);
                ddv.visitStartLocal(0,L6,"buf","Ljava/lang/StringBuffer;",null);
                ddv.visitLineNumber(619,L0);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(620,L7);
                ddv.visitLineNumber(621,L1);
                ddv.visitLineNumber(620,L2);
                code.visitLabel(L5);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/lang/StringBuffer;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/lang/StringBuffer;","<init>",new String[]{ },"V"));
                code.visitLabel(L6);
                code.visitStmt1R(MONITOR_ENTER,0);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2,0},new Method("Lorg/mortbay/util/StringMap$Node;","toString",new String[]{ "Ljava/lang/StringBuffer;"},"V"));
                code.visitLabel(L7);
                code.visitStmt1R(MONITOR_EXIT,0);
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/lang/StringBuffer;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitStmt1R(RETURN_OBJECT,1);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,1);
                code.visitLabel(L3);
                code.visitStmt1R(MONITOR_EXIT,0);
                code.visitLabel(L4);
                code.visitStmt1R(THROW,1);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
