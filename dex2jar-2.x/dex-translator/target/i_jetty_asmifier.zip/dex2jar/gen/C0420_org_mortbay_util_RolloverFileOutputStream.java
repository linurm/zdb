package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0420_org_mortbay_util_RolloverFileOutputStream {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(ACC_PUBLIC,"Lorg/mortbay/util/RolloverFileOutputStream;","Ljava/io/FilterOutputStream;",new String[]{ });
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("RolloverFileOutputStream.java");
        if(cv!=null){
            DexAnnotationVisitor av00 = cv.visitAnnotation("Ldalvik/annotation/MemberClasses;", Visibility.SYSTEM);
            if(av00 != null) {
                {
                    DexAnnotationVisitor av01 = av00.visitArray("value");
                    if(av01 != null) {
                        av01.visit(null, new DexType("Lorg/mortbay/util/RolloverFileOutputStream$1;"));
                        av01.visit(null, new DexType("Lorg/mortbay/util/RolloverFileOutputStream$RollTask;"));
                        av01.visitEnd();
                    }
                }
                av00.visitEnd();
            }
        }
        f000_YYYY_MM_DD(cv);
        f001___rollover(cv);
        f002__append(cv);
        f003__file(cv);
        f004__fileBackupFormat(cv);
        f005__fileDateFormat(cv);
        f006__filename(cv);
        f007__retainDays(cv);
        f008__rollTask(cv);
        m000__init_(cv);
        m001__init_(cv);
        m002__init_(cv);
        m003__init_(cv);
        m004__init_(cv);
        m005_access$100(cv);
        m006_access$200(cv);
        m007_removeOldFiles(cv);
        m008_setFile(cv);
        m009_close(cv);
        m010_getDatedFilename(cv);
        m011_getFilename(cv);
        m012_getRetainDays(cv);
        m013_write(cv);
        m014_write(cv);
    }
    public static void f000_YYYY_MM_DD(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/util/RolloverFileOutputStream;","YYYY_MM_DD","Ljava/lang/String;"), "yyyy_mm_dd");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f001___rollover(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE|ACC_STATIC, new Field("Lorg/mortbay/util/RolloverFileOutputStream;","__rollover","Ljava/util/Timer;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f002__append(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/util/RolloverFileOutputStream;","_append","Z"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f003__file(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/util/RolloverFileOutputStream;","_file","Ljava/io/File;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f004__fileBackupFormat(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/util/RolloverFileOutputStream;","_fileBackupFormat","Ljava/text/SimpleDateFormat;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f005__fileDateFormat(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/util/RolloverFileOutputStream;","_fileDateFormat","Ljava/text/SimpleDateFormat;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f006__filename(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/util/RolloverFileOutputStream;","_filename","Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f007__retainDays(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/util/RolloverFileOutputStream;","_retainDays","I"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f008__rollTask(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/util/RolloverFileOutputStream;","_rollTask","Lorg/mortbay/util/RolloverFileOutputStream$RollTask;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void m000__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/util/RolloverFileOutputStream;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"filename");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(69,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(70,L1);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitConstStmt(CONST_STRING,1,"ROLLOVERFILE_RETAIN_DAYS");
                code.visitConstStmt(CONST_16,2, Integer.valueOf(31)); // int: 0x0000001f  float:0.000000
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1,2},new Method("Ljava/lang/Integer;","getInteger",new String[]{ "Ljava/lang/String;","I"},"Ljava/lang/Integer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/lang/Integer;","intValue",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 3,4,0,1},new Method("Lorg/mortbay/util/RolloverFileOutputStream;","<init>",new String[]{ "Ljava/lang/String;","Z","I"},"V"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/util/RolloverFileOutputStream;","<init>",new String[]{ "Ljava/lang/String;","Z"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"filename");
                ddv.visitParameterName(1,"append");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(82,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(83,L1);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_STRING,0,"ROLLOVERFILE_RETAIN_DAYS");
                code.visitConstStmt(CONST_16,1, Integer.valueOf(31)); // int: 0x0000001f  float:0.000000
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0,1},new Method("Ljava/lang/Integer;","getInteger",new String[]{ "Ljava/lang/String;","I"},"Ljava/lang/Integer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/lang/Integer;","intValue",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2,3,4,0},new Method("Lorg/mortbay/util/RolloverFileOutputStream;","<init>",new String[]{ "Ljava/lang/String;","Z","I"},"V"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m002__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/util/RolloverFileOutputStream;","<init>",new String[]{ "Ljava/lang/String;","Z","I"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"filename");
                ddv.visitParameterName(1,"append");
                ddv.visitParameterName(2,"retainDays");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(98,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(99,L1);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Ljava/util/TimeZone;","getDefault",new String[]{ },"Ljava/util/TimeZone;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1,2,3,4,0},new Method("Lorg/mortbay/util/RolloverFileOutputStream;","<init>",new String[]{ "Ljava/lang/String;","Z","I","Ljava/util/TimeZone;"},"V"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m003__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/util/RolloverFileOutputStream;","<init>",new String[]{ "Ljava/lang/String;","Z","I","Ljava/util/TimeZone;"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(12);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"filename");
                ddv.visitParameterName(1,"append");
                ddv.visitParameterName(2,"retainDays");
                ddv.visitParameterName(3,"zone");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(116,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(117,L2);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,5, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L1);
                code.visitStmt2R(MOVE_OBJECT,0,7);
                code.visitStmt2R(MOVE_OBJECT,1,8);
                code.visitStmt2R(MOVE,2,9);
                code.visitStmt2R(MOVE,3,10);
                code.visitStmt2R(MOVE_OBJECT,4,11);
                code.visitStmt2R(MOVE_OBJECT,6,5);
                code.visitMethodStmt(INVOKE_DIRECT_RANGE,new int[]{ 0,1,2,3,4,5,6},new Method("Lorg/mortbay/util/RolloverFileOutputStream;","<init>",new String[]{ "Ljava/lang/String;","Z","I","Ljava/util/TimeZone;","Ljava/lang/String;","Ljava/lang/String;"},"V"));
                code.visitLabel(L2);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m004__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/util/RolloverFileOutputStream;","<init>",new String[]{ "Ljava/lang/String;","Z","I","Ljava/util/TimeZone;","Ljava/lang/String;","Ljava/lang/String;"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(15);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"filename");
                ddv.visitParameterName(1,"append");
                ddv.visitParameterName(2,"retainDays");
                ddv.visitParameterName(3,"zone");
                ddv.visitParameterName(4,"dateFormat");
                ddv.visitParameterName(5,"backupFormat");
                DexLabel L3=new DexLabel();
                ddv.visitPrologue(L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(139,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(141,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(142,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(143,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(145,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(146,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(147,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(149,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(150,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(152,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(154,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(155,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(156,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(158,L17);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(159,L18);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(161,L19);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(162,L20);
                DexLabel L21=new DexLabel();
                ddv.visitLineNumber(163,L21);
                DexLabel L22=new DexLabel();
                ddv.visitLineNumber(164,L22);
                DexLabel L23=new DexLabel();
                ddv.visitLineNumber(166,L23);
                ddv.visitLineNumber(168,L0);
                DexLabel L24=new DexLabel();
                ddv.visitLineNumber(169,L24);
                DexLabel L25=new DexLabel();
                ddv.visitLineNumber(171,L25);
                DexLabel L26=new DexLabel();
                ddv.visitLineNumber(173,L26);
                DexLabel L27=new DexLabel();
                ddv.visitLineNumber(174,L27);
                ddv.visitStartLocal(6,L27,"now","Ljava/util/Calendar;",null);
                DexLabel L28=new DexLabel();
                ddv.visitLineNumber(176,L28);
                DexLabel L29=new DexLabel();
                ddv.visitLineNumber(181,L29);
                ddv.visitStartLocal(0,L29,"midnight","Ljava/util/GregorianCalendar;",null);
                DexLabel L30=new DexLabel();
                ddv.visitLineNumber(182,L30);
                DexLabel L31=new DexLabel();
                ddv.visitLineNumber(183,L31);
                DexLabel L32=new DexLabel();
                ddv.visitLineNumber(184,L32);
                DexLabel L33=new DexLabel();
                ddv.visitLineNumber(185,L33);
                ddv.visitLineNumber(184,L2);
                ddv.visitEndLocal(6,L2);
                ddv.visitEndLocal(0,L2);
                code.visitLabel(L3);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L4);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 8,1},new Method("Ljava/io/FilterOutputStream;","<init>",new String[]{ "Ljava/io/OutputStream;"},"V"));
                code.visitLabel(L5);
                code.visitJumpStmt(IF_NEZ,13,-1,L7);
                code.visitLabel(L6);
                code.visitConstStmt(CONST_STRING,1,"ROLLOVERFILE_DATE_FORMAT");
                code.visitConstStmt(CONST_STRING,2,"yyyy_MM_dd");
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1,2},new Method("Ljava/lang/System;","getProperty",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,13);
                code.visitLabel(L7);
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Ljava/text/SimpleDateFormat;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1,13},new Method("Ljava/text/SimpleDateFormat;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitFieldStmt(IPUT_OBJECT,1,8,new Field("Lorg/mortbay/util/RolloverFileOutputStream;","_fileDateFormat","Ljava/text/SimpleDateFormat;"));
                code.visitLabel(L8);
                code.visitJumpStmt(IF_NEZ,14,-1,L10);
                code.visitLabel(L9);
                code.visitConstStmt(CONST_STRING,1,"ROLLOVERFILE_BACKUP_FORMAT");
                code.visitConstStmt(CONST_STRING,2,"HHmmssSSS");
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1,2},new Method("Ljava/lang/System;","getProperty",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,14);
                code.visitLabel(L10);
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Ljava/text/SimpleDateFormat;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1,14},new Method("Ljava/text/SimpleDateFormat;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitFieldStmt(IPUT_OBJECT,1,8,new Field("Lorg/mortbay/util/RolloverFileOutputStream;","_fileBackupFormat","Ljava/text/SimpleDateFormat;"));
                code.visitLabel(L11);
                code.visitFieldStmt(IGET_OBJECT,1,8,new Field("Lorg/mortbay/util/RolloverFileOutputStream;","_fileBackupFormat","Ljava/text/SimpleDateFormat;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,12},new Method("Ljava/text/SimpleDateFormat;","setTimeZone",new String[]{ "Ljava/util/TimeZone;"},"V"));
                code.visitLabel(L12);
                code.visitFieldStmt(IGET_OBJECT,1,8,new Field("Lorg/mortbay/util/RolloverFileOutputStream;","_fileDateFormat","Ljava/text/SimpleDateFormat;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,12},new Method("Ljava/text/SimpleDateFormat;","setTimeZone",new String[]{ "Ljava/util/TimeZone;"},"V"));
                code.visitLabel(L13);
                code.visitJumpStmt(IF_EQZ,9,-1,L17);
                code.visitLabel(L14);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9},new Method("Ljava/lang/String;","trim",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,9);
                code.visitLabel(L15);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9},new Method("Ljava/lang/String;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitJumpStmt(IF_NEZ,1,-1,L17);
                code.visitLabel(L16);
                code.visitConstStmt(CONST_4,9, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L17);
                code.visitJumpStmt(IF_NEZ,9,-1,L19);
                code.visitLabel(L18);
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Ljava/lang/IllegalArgumentException;");
                code.visitConstStmt(CONST_STRING,2,"Invalid filename");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1,2},new Method("Ljava/lang/IllegalArgumentException;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitStmt1R(THROW,1);
                code.visitLabel(L19);
                code.visitFieldStmt(IPUT_OBJECT,9,8,new Field("Lorg/mortbay/util/RolloverFileOutputStream;","_filename","Ljava/lang/String;"));
                code.visitLabel(L20);
                code.visitFieldStmt(IPUT_BOOLEAN,10,8,new Field("Lorg/mortbay/util/RolloverFileOutputStream;","_append","Z"));
                code.visitLabel(L21);
                code.visitFieldStmt(IPUT,11,8,new Field("Lorg/mortbay/util/RolloverFileOutputStream;","_retainDays","I"));
                code.visitLabel(L22);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 8},new Method("Lorg/mortbay/util/RolloverFileOutputStream;","setFile",new String[]{ },"V"));
                code.visitLabel(L23);
                code.visitConstStmt(CONST_CLASS,7,new DexType("Lorg/mortbay/util/RolloverFileOutputStream;"));
                code.visitStmt1R(MONITOR_ENTER,7);
                code.visitLabel(L0);
                code.visitFieldStmt(SGET_OBJECT,1,-1,new Field("Lorg/mortbay/util/RolloverFileOutputStream;","__rollover","Ljava/util/Timer;"));
                code.visitJumpStmt(IF_NEZ,1,-1,L25);
                code.visitLabel(L24);
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Ljava/util/Timer;");
                code.visitConstStmt(CONST_4,2, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1,2},new Method("Ljava/util/Timer;","<init>",new String[]{ "Z"},"V"));
                code.visitFieldStmt(SPUT_OBJECT,1,-1,new Field("Lorg/mortbay/util/RolloverFileOutputStream;","__rollover","Ljava/util/Timer;"));
                code.visitLabel(L25);
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Lorg/mortbay/util/RolloverFileOutputStream$RollTask;");
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1,8,2},new Method("Lorg/mortbay/util/RolloverFileOutputStream$RollTask;","<init>",new String[]{ "Lorg/mortbay/util/RolloverFileOutputStream;","Lorg/mortbay/util/RolloverFileOutputStream$1;"},"V"));
                code.visitFieldStmt(IPUT_OBJECT,1,8,new Field("Lorg/mortbay/util/RolloverFileOutputStream;","_rollTask","Lorg/mortbay/util/RolloverFileOutputStream$RollTask;"));
                code.visitLabel(L26);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Ljava/util/Calendar;","getInstance",new String[]{ },"Ljava/util/Calendar;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitLabel(L27);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,12},new Method("Ljava/util/Calendar;","setTimeZone",new String[]{ "Ljava/util/TimeZone;"},"V"));
                code.visitLabel(L28);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/util/GregorianCalendar;");
                code.visitConstStmt(CONST_4,1, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,1},new Method("Ljava/util/Calendar;","get",new String[]{ "I"},"I"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(2)); // int: 0x00000002  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,2},new Method("Ljava/util/Calendar;","get",new String[]{ "I"},"I"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(5)); // int: 0x00000005  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,3},new Method("Ljava/util/Calendar;","get",new String[]{ "I"},"I"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitConstStmt(CONST_16,4, Integer.valueOf(23)); // int: 0x00000017  float:0.000000
                code.visitConstStmt(CONST_4,5, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_DIRECT_RANGE,new int[]{ 0,1,2,3,4,5},new Method("Ljava/util/GregorianCalendar;","<init>",new String[]{ "I","I","I","I","I"},"V"));
                code.visitLabel(L29);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,12},new Method("Ljava/util/GregorianCalendar;","setTimeZone",new String[]{ "Ljava/util/TimeZone;"},"V"));
                code.visitLabel(L30);
                code.visitConstStmt(CONST_16,1, Integer.valueOf(10)); // int: 0x0000000a  float:0.000000
                code.visitConstStmt(CONST_4,2, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1,2},new Method("Ljava/util/GregorianCalendar;","add",new String[]{ "I","I"},"V"));
                code.visitLabel(L31);
                code.visitFieldStmt(SGET_OBJECT,1,-1,new Field("Lorg/mortbay/util/RolloverFileOutputStream;","__rollover","Ljava/util/Timer;"));
                code.visitFieldStmt(IGET_OBJECT,2,8,new Field("Lorg/mortbay/util/RolloverFileOutputStream;","_rollTask","Lorg/mortbay/util/RolloverFileOutputStream$RollTask;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/util/GregorianCalendar;","getTime",new String[]{ },"Ljava/util/Date;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitConstStmt(CONST_WIDE_32,4,Long.valueOf(86400000L)); // long: 0x0000000005265c00  double:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2,3,4,5},new Method("Ljava/util/Timer;","scheduleAtFixedRate",new String[]{ "Ljava/util/TimerTask;","Ljava/util/Date;","J"},"V"));
                code.visitLabel(L32);
                code.visitStmt1R(MONITOR_EXIT,7);
                code.visitLabel(L33);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,1);
                code.visitStmt1R(MONITOR_EXIT,7);
                code.visitLabel(L1);
                code.visitStmt1R(THROW,1);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m005_access$100(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_STATIC|ACC_SYNTHETIC, new Method("Lorg/mortbay/util/RolloverFileOutputStream;","access$100",new String[]{ "Lorg/mortbay/util/RolloverFileOutputStream;"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(1);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"x0");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(45,L0);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Lorg/mortbay/util/RolloverFileOutputStream;","setFile",new String[]{ },"V"));
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m006_access$200(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_STATIC|ACC_SYNTHETIC, new Method("Lorg/mortbay/util/RolloverFileOutputStream;","access$200",new String[]{ "Lorg/mortbay/util/RolloverFileOutputStream;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(1);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"x0");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(45,L0);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Lorg/mortbay/util/RolloverFileOutputStream;","removeOldFiles",new String[]{ },"V"));
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m007_removeOldFiles(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PRIVATE, new Method("Lorg/mortbay/util/RolloverFileOutputStream;","removeOldFiles",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(20);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(253,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(255,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(257,L2);
                ddv.visitStartLocal(10,L2,"now","J",null);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(258,L3);
                ddv.visitStartLocal(6,L3,"file","Ljava/io/File;",null);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(259,L4);
                ddv.visitStartLocal(4,L4,"dir","Ljava/io/File;",null);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(260,L5);
                ddv.visitStartLocal(7,L5,"fn","Ljava/lang/String;",null);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(261,L6);
                ddv.visitStartLocal(13,L6,"s","I",null);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(279,L7);
                ddv.visitEndLocal(10,L7);
                ddv.visitEndLocal(6,L7);
                ddv.visitEndLocal(4,L7);
                ddv.visitEndLocal(7,L7);
                ddv.visitEndLocal(13,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(263,L8);
                ddv.visitRestartLocal(4,L8);
                ddv.visitRestartLocal(6,L8);
                ddv.visitRestartLocal(7,L8);
                ddv.visitRestartLocal(10,L8);
                ddv.visitRestartLocal(13,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(264,L9);
                ddv.visitStartLocal(12,L9,"prefix","Ljava/lang/String;",null);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(266,L10);
                ddv.visitStartLocal(14,L10,"suffix","Ljava/lang/String;",null);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(267,L11);
                ddv.visitStartLocal(9,L11,"logList","[Ljava/lang/String;",null);
                DexLabel L12=new DexLabel();
                ddv.visitStartLocal(8,L12,"i","I",null);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(269,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(270,L14);
                ddv.visitRestartLocal(7,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(272,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(273,L16);
                ddv.visitStartLocal(5,L16,"f","Ljava/io/File;",null);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(274,L17);
                ddv.visitStartLocal(2,L17,"date","J",null);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(275,L18);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(267,L19);
                ddv.visitEndLocal(5,L19);
                ddv.visitEndLocal(2,L19);
                code.visitLabel(L0);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,19);
                code.visitFieldStmt(IGET,0,0,new Field("Lorg/mortbay/util/RolloverFileOutputStream;","_retainDays","I"));
                code.visitStmt2R(MOVE,15,0);
                code.visitJumpStmt(IF_LEZ,15,-1,L7);
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Ljava/lang/System;","currentTimeMillis",new String[]{ },"J"));
                code.visitStmt1R(MOVE_RESULT_WIDE,10);
                code.visitLabel(L2);
                code.visitTypeStmt(NEW_INSTANCE,6,-1,"Ljava/io/File;");
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,19);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/util/RolloverFileOutputStream;","_filename","Ljava/lang/String;"));
                code.visitStmt2R(MOVE_OBJECT,15,0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 6,15},new Method("Ljava/io/File;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L3);
                code.visitTypeStmt(NEW_INSTANCE,4,-1,"Ljava/io/File;");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Ljava/io/File;","getParent",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,15);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 4,15},new Method("Ljava/io/File;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Ljava/io/File;","getName",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitLabel(L5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7},new Method("Ljava/lang/String;","toLowerCase",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,15);
                code.visitConstStmt(CONST_STRING,16,"yyyy_mm_dd");
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 15,16},new Method("Ljava/lang/String;","indexOf",new String[]{ "Ljava/lang/String;"},"I"));
                code.visitStmt1R(MOVE_RESULT,13);
                code.visitLabel(L6);
                code.visitJumpStmt(IF_GEZ,13,-1,L8);
                code.visitLabel(L7);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L8);
                code.visitConstStmt(CONST_4,15, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7,15,13},new Method("Ljava/lang/String;","substring",new String[]{ "I","I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,12);
                code.visitLabel(L9);
                code.visitConstStmt(CONST_STRING,15,"yyyy_mm_dd");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 15},new Method("Ljava/lang/String;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,15);
                code.visitStmt2R(ADD_INT_2ADDR,15,13);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7,15},new Method("Ljava/lang/String;","substring",new String[]{ "I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,14);
                code.visitLabel(L10);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Ljava/io/File;","list",new String[]{ },"[Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,9);
                code.visitLabel(L11);
                code.visitConstStmt(CONST_4,8, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L12);
                code.visitStmt2R(ARRAY_LENGTH,15,9);
                code.visitJumpStmt(IF_GE,8,15,L7);
                code.visitLabel(L13);
                code.visitStmt3R(AGET_OBJECT,7,9,8);
                code.visitLabel(L14);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7,12},new Method("Ljava/lang/String;","startsWith",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,15);
                code.visitJumpStmt(IF_EQZ,15,-1,L19);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 12},new Method("Ljava/lang/String;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,15);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7,14,15},new Method("Ljava/lang/String;","indexOf",new String[]{ "Ljava/lang/String;","I"},"I"));
                code.visitStmt1R(MOVE_RESULT,15);
                code.visitJumpStmt(IF_LTZ,15,-1,L19);
                code.visitLabel(L15);
                code.visitTypeStmt(NEW_INSTANCE,5,-1,"Ljava/io/File;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 5,4,7},new Method("Ljava/io/File;","<init>",new String[]{ "Ljava/io/File;","Ljava/lang/String;"},"V"));
                code.visitLabel(L16);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Ljava/io/File;","lastModified",new String[]{ },"J"));
                code.visitStmt1R(MOVE_RESULT_WIDE,2);
                code.visitLabel(L17);
                code.visitStmt3R(SUB_LONG,15,10,2);
                code.visitConstStmt(CONST_WIDE_32,17,Long.valueOf(86400000L)); // long: 0x0000000005265c00  double:0.000000
                code.visitStmt3R(DIV_LONG,15,15,17);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,19);
                code.visitFieldStmt(IGET,0,0,new Field("Lorg/mortbay/util/RolloverFileOutputStream;","_retainDays","I"));
                code.visitStmt2R(MOVE_FROM16,17,0);
                code.visitStmt2R(MOVE_FROM16,0,17);
                code.visitStmt2R(INT_TO_LONG,0,0);
                code.visitStmt2R(MOVE_WIDE_FROM16,17,0);
                code.visitStmt3R(CMP_LONG,15,15,17);
                code.visitJumpStmt(IF_LEZ,15,-1,L19);
                code.visitLabel(L18);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Ljava/io/File;","delete",new String[]{ },"Z"));
                code.visitLabel(L19);
                code.visitStmt2R1N(ADD_INT_LIT8,8,8,1);
                code.visitJumpStmt(GOTO,-1,-1,L12);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m008_setFile(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PRIVATE, new Method("Lorg/mortbay/util/RolloverFileOutputStream;","setFile",new String[]{ },"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(10);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L1},new String[]{ null});
                DexLabel L2=new DexLabel();
                DexLabel L3=new DexLabel();
                code.visitTryCatch(L2,L3,new DexLabel[]{L1},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L4=new DexLabel();
                ddv.visitPrologue(L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(212,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(213,L6);
                ddv.visitStartLocal(1,L6,"file","Ljava/io/File;",null);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(214,L7);
                DexLabel L8=new DexLabel();
                ddv.visitEndLocal(1,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(215,L9);
                ddv.visitRestartLocal(1,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(216,L10);
                ddv.visitStartLocal(0,L10,"dir","Ljava/io/File;",null);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(217,L11);
                ddv.visitLineNumber(212,L1);
                ddv.visitEndLocal(1,L1);
                ddv.visitEndLocal(0,L1);
                ddv.visitLineNumber(219,L2);
                ddv.visitRestartLocal(0,L2);
                ddv.visitRestartLocal(1,L2);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(222,L12);
                ddv.visitStartLocal(4,L12,"now","Ljava/util/Date;",null);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(223,L13);
                ddv.visitStartLocal(2,L13,"filename","Ljava/lang/String;",null);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(224,L14);
                ddv.visitStartLocal(3,L14,"i","I",null);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(226,L15);
                DexLabel L16=new DexLabel();
                ddv.visitEndLocal(1,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(232,L17);
                ddv.visitRestartLocal(1,L17);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(233,L18);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(236,L19);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(239,L20);
                DexLabel L21=new DexLabel();
                ddv.visitLineNumber(240,L21);
                DexLabel L22=new DexLabel();
                ddv.visitLineNumber(241,L22);
                DexLabel L23=new DexLabel();
                ddv.visitLineNumber(242,L23);
                DexLabel L24=new DexLabel();
                ddv.visitLineNumber(243,L24);
                ddv.visitStartLocal(5,L24,"oldOut","Ljava/io/OutputStream;",null);
                DexLabel L25=new DexLabel();
                ddv.visitLineNumber(244,L25);
                DexLabel L26=new DexLabel();
                ddv.visitLineNumber(245,L26);
                ddv.visitLineNumber(248,L3);
                ddv.visitEndLocal(5,L3);
                code.visitLabel(L4);
                code.visitConstStmt(CONST_STRING,6,"yyyy_mm_dd");
                code.visitLabel(L5);
                code.visitStmt1R(MONITOR_ENTER,9);
                code.visitLabel(L0);
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Ljava/io/File;");
                code.visitFieldStmt(IGET_OBJECT,6,9,new Field("Lorg/mortbay/util/RolloverFileOutputStream;","_filename","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1,6},new Method("Ljava/io/File;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/io/File;","getCanonicalPath",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitFieldStmt(IPUT_OBJECT,6,9,new Field("Lorg/mortbay/util/RolloverFileOutputStream;","_filename","Ljava/lang/String;"));
                code.visitLabel(L7);
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Ljava/io/File;");
                code.visitLabel(L8);
                code.visitFieldStmt(IGET_OBJECT,6,9,new Field("Lorg/mortbay/util/RolloverFileOutputStream;","_filename","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1,6},new Method("Ljava/io/File;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L9);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/io/File;");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/io/File;","getParent",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,6},new Method("Ljava/io/File;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L10);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/io/File;","isDirectory",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,6);
                code.visitJumpStmt(IF_EQZ,6,-1,L11);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/io/File;","canWrite",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,6);
                code.visitJumpStmt(IF_NEZ,6,-1,L2);
                code.visitLabel(L11);
                code.visitTypeStmt(NEW_INSTANCE,6,-1,"Ljava/io/IOException;");
                code.visitTypeStmt(NEW_INSTANCE,7,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 7},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,8,"Cannot write log directory ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7,8},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7,0},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 6,7},new Method("Ljava/io/IOException;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitStmt1R(THROW,6);
                code.visitLabel(L1);
                code.visitStmt1R(MOVE_EXCEPTION,6);
                code.visitStmt1R(MONITOR_EXIT,9);
                code.visitStmt1R(THROW,6);
                code.visitLabel(L2);
                code.visitTypeStmt(NEW_INSTANCE,4,-1,"Ljava/util/Date;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 4},new Method("Ljava/util/Date;","<init>",new String[]{ },"V"));
                code.visitLabel(L12);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/io/File;","getName",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitLabel(L13);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Ljava/lang/String;","toLowerCase",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitConstStmt(CONST_STRING,7,"yyyy_mm_dd");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,7},new Method("Ljava/lang/String;","indexOf",new String[]{ "Ljava/lang/String;"},"I"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitLabel(L14);
                code.visitJumpStmt(IF_LTZ,3,-1,L17);
                code.visitLabel(L15);
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Ljava/io/File;");
                code.visitLabel(L16);
                code.visitTypeStmt(NEW_INSTANCE,6,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 6},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_4,7, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,7,3},new Method("Ljava/lang/String;","substring",new String[]{ "I","I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,7},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitFieldStmt(IGET_OBJECT,7,9,new Field("Lorg/mortbay/util/RolloverFileOutputStream;","_fileDateFormat","Ljava/text/SimpleDateFormat;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7,4},new Method("Ljava/text/SimpleDateFormat;","format",new String[]{ "Ljava/util/Date;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,7},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitConstStmt(CONST_STRING,7,"yyyy_mm_dd");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7},new Method("Ljava/lang/String;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,7);
                code.visitStmt2R(ADD_INT_2ADDR,7,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,7},new Method("Ljava/lang/String;","substring",new String[]{ "I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,7},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1,0,6},new Method("Ljava/io/File;","<init>",new String[]{ "Ljava/io/File;","Ljava/lang/String;"},"V"));
                code.visitLabel(L17);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/io/File;","exists",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,6);
                code.visitJumpStmt(IF_EQZ,6,-1,L19);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/io/File;","canWrite",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,6);
                code.visitJumpStmt(IF_NEZ,6,-1,L19);
                code.visitLabel(L18);
                code.visitTypeStmt(NEW_INSTANCE,6,-1,"Ljava/io/IOException;");
                code.visitTypeStmt(NEW_INSTANCE,7,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 7},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,8,"Cannot write log file ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7,8},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 6,7},new Method("Ljava/io/IOException;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitStmt1R(THROW,6);
                code.visitLabel(L19);
                code.visitFieldStmt(IGET_OBJECT,6,9,new Field("Lorg/mortbay/util/RolloverFileOutputStream;","out","Ljava/io/OutputStream;"));
                code.visitJumpStmt(IF_EQZ,6,-1,L20);
                code.visitFieldStmt(IGET_OBJECT,6,9,new Field("Lorg/mortbay/util/RolloverFileOutputStream;","_file","Ljava/io/File;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,6},new Method("Ljava/io/File;","equals",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,6);
                code.visitJumpStmt(IF_NEZ,6,-1,L3);
                code.visitLabel(L20);
                code.visitFieldStmt(IPUT_OBJECT,1,9,new Field("Lorg/mortbay/util/RolloverFileOutputStream;","_file","Ljava/io/File;"));
                code.visitLabel(L21);
                code.visitFieldStmt(IGET_BOOLEAN,6,9,new Field("Lorg/mortbay/util/RolloverFileOutputStream;","_append","Z"));
                code.visitJumpStmt(IF_NEZ,6,-1,L23);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/io/File;","exists",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,6);
                code.visitJumpStmt(IF_EQZ,6,-1,L23);
                code.visitLabel(L22);
                code.visitTypeStmt(NEW_INSTANCE,6,-1,"Ljava/io/File;");
                code.visitTypeStmt(NEW_INSTANCE,7,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 7},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/io/File;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7,8},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitConstStmt(CONST_STRING,8,".");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7,8},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitFieldStmt(IGET_OBJECT,8,9,new Field("Lorg/mortbay/util/RolloverFileOutputStream;","_fileBackupFormat","Ljava/text/SimpleDateFormat;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8,4},new Method("Ljava/text/SimpleDateFormat;","format",new String[]{ "Ljava/util/Date;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7,8},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 6,7},new Method("Ljava/io/File;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,6},new Method("Ljava/io/File;","renameTo",new String[]{ "Ljava/io/File;"},"Z"));
                code.visitLabel(L23);
                code.visitFieldStmt(IGET_OBJECT,5,9,new Field("Lorg/mortbay/util/RolloverFileOutputStream;","out","Ljava/io/OutputStream;"));
                code.visitLabel(L24);
                code.visitTypeStmt(NEW_INSTANCE,6,-1,"Ljava/io/FileOutputStream;");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/io/File;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitFieldStmt(IGET_BOOLEAN,8,9,new Field("Lorg/mortbay/util/RolloverFileOutputStream;","_append","Z"));
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 6,7,8},new Method("Ljava/io/FileOutputStream;","<init>",new String[]{ "Ljava/lang/String;","Z"},"V"));
                code.visitFieldStmt(IPUT_OBJECT,6,9,new Field("Lorg/mortbay/util/RolloverFileOutputStream;","out","Ljava/io/OutputStream;"));
                code.visitLabel(L25);
                code.visitJumpStmt(IF_EQZ,5,-1,L3);
                code.visitLabel(L26);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Ljava/io/OutputStream;","close",new String[]{ },"V"));
                code.visitLabel(L3);
                code.visitStmt1R(MONITOR_EXIT,9);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m009_close(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/util/RolloverFileOutputStream;","close",new String[]{ },"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexLabel L3=new DexLabel();
                DexLabel L4=new DexLabel();
                DexLabel L5=new DexLabel();
                code.visitTryCatch(L3,L4,new DexLabel[]{L5},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L6=new DexLabel();
                ddv.visitPrologue(L6);
                ddv.visitLineNumber(301,L6);
                ddv.visitLineNumber(303,L0);
                ddv.visitLineNumber(306,L1);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(307,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(310,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(311,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(312,L10);
                ddv.visitLineNumber(306,L2);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(307,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(306,L12);
                ddv.visitLineNumber(311,L5);
                code.visitLabel(L6);
                code.visitConstStmt(CONST_CLASS,0,new DexType("Lorg/mortbay/util/RolloverFileOutputStream;"));
                code.visitStmt1R(MONITOR_ENTER,0);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_SUPER,new int[]{ 3},new Method("Ljava/io/FilterOutputStream;","close",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L3);
                code.visitFieldStmt(IPUT_OBJECT,1,3,new Field("Lorg/mortbay/util/RolloverFileOutputStream;","out","Ljava/io/OutputStream;"));
                code.visitLabel(L7);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT_OBJECT,1,3,new Field("Lorg/mortbay/util/RolloverFileOutputStream;","_file","Ljava/io/File;"));
                code.visitLabel(L8);
                code.visitFieldStmt(IGET_OBJECT,1,3,new Field("Lorg/mortbay/util/RolloverFileOutputStream;","_rollTask","Lorg/mortbay/util/RolloverFileOutputStream$RollTask;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Lorg/mortbay/util/RolloverFileOutputStream$RollTask;","cancel",new String[]{ },"Z"));
                code.visitLabel(L9);
                code.visitStmt1R(MONITOR_EXIT,0);
                code.visitLabel(L10);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,1);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT_OBJECT,2,3,new Field("Lorg/mortbay/util/RolloverFileOutputStream;","out","Ljava/io/OutputStream;"));
                code.visitLabel(L11);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT_OBJECT,2,3,new Field("Lorg/mortbay/util/RolloverFileOutputStream;","_file","Ljava/io/File;"));
                code.visitLabel(L12);
                code.visitStmt1R(THROW,1);
                code.visitLabel(L5);
                code.visitStmt1R(MOVE_EXCEPTION,1);
                code.visitStmt1R(MONITOR_EXIT,0);
                code.visitLabel(L4);
                code.visitStmt1R(THROW,1);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m010_getDatedFilename(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/util/RolloverFileOutputStream;","getDatedFilename",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(196,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(197,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(198,L2);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/util/RolloverFileOutputStream;","_file","Ljava/io/File;"));
                DexLabel L3=new DexLabel();
                code.visitJumpStmt(IF_NEZ,0,-1,L3);
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L2);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/util/RolloverFileOutputStream;","_file","Ljava/io/File;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/io/File;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m011_getFilename(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/util/RolloverFileOutputStream;","getFilename",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(190,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/util/RolloverFileOutputStream;","_filename","Ljava/lang/String;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m012_getRetainDays(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/util/RolloverFileOutputStream;","getRetainDays",new String[]{ },"I"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(204,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET,0,1,new Field("Lorg/mortbay/util/RolloverFileOutputStream;","_retainDays","I"));
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m013_write(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/util/RolloverFileOutputStream;","write",new String[]{ "[B"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"buf");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(285,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(286,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/util/RolloverFileOutputStream;","out","Ljava/io/OutputStream;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,2},new Method("Ljava/io/OutputStream;","write",new String[]{ "[B"},"V"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m014_write(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/util/RolloverFileOutputStream;","write",new String[]{ "[B","I","I"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"buf");
                ddv.visitParameterName(1,"off");
                ddv.visitParameterName(2,"len");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(292,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(293,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/util/RolloverFileOutputStream;","out","Ljava/io/OutputStream;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,2,3,4},new Method("Ljava/io/OutputStream;","write",new String[]{ "[B","I","I"},"V"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
