package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0235_org_mortbay_jetty_client_webdav_WebdavListener {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(ACC_PUBLIC,"Lorg/mortbay/jetty/client/webdav/WebdavListener;","Lorg/mortbay/jetty/client/HttpEventListenerWrapper;",new String[]{ });
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("WebdavListener.java");
        f000__destination(cv);
        f001__exchange(cv);
        f002__needIntercept(cv);
        f003__requestComplete(cv);
        f004__responseComplete(cv);
        f005__webdavEnabled(cv);
        m000__init_(cv);
        m001_checkExists(cv);
        m002_checkWebdavSupported(cv);
        m003_makeCollection(cv);
        m004_resolveCollectionIssues(cv);
        m005_onRequestComplete(cv);
        m006_onResponseComplete(cv);
        m007_onResponseStatus(cv);
    }
    public static void f000__destination(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/client/webdav/WebdavListener;","_destination","Lorg/mortbay/jetty/client/HttpDestination;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f001__exchange(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/client/webdav/WebdavListener;","_exchange","Lorg/mortbay/jetty/client/HttpExchange;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f002__needIntercept(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/client/webdav/WebdavListener;","_needIntercept","Z"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f003__requestComplete(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/client/webdav/WebdavListener;","_requestComplete","Z"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f004__responseComplete(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/client/webdav/WebdavListener;","_responseComplete","Z"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f005__webdavEnabled(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/client/webdav/WebdavListener;","_webdavEnabled","Z"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void m000__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/jetty/client/webdav/WebdavListener;","<init>",new String[]{ "Lorg/mortbay/jetty/client/HttpDestination;","Lorg/mortbay/jetty/client/HttpExchange;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(6);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"destination");
                ddv.visitParameterName(1,"ex");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(51,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(52,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(53,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(56,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(58,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(60,L6);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Lorg/mortbay/jetty/client/HttpExchange;","getEventListener",new String[]{ },"Lorg/mortbay/jetty/client/HttpEventListener;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 3,0,2},new Method("Lorg/mortbay/jetty/client/HttpEventListenerWrapper;","<init>",new String[]{ "Lorg/mortbay/jetty/client/HttpEventListener;","Z"},"V"));
                code.visitLabel(L2);
                code.visitFieldStmt(IPUT_OBJECT,4,3,new Field("Lorg/mortbay/jetty/client/webdav/WebdavListener;","_destination","Lorg/mortbay/jetty/client/HttpDestination;"));
                code.visitLabel(L3);
                code.visitFieldStmt(IPUT_OBJECT,5,3,new Field("Lorg/mortbay/jetty/client/webdav/WebdavListener;","_exchange","Lorg/mortbay/jetty/client/HttpExchange;"));
                code.visitLabel(L4);
                code.visitConstStmt(CONST_STRING,0,"PUT");
                code.visitFieldStmt(IGET_OBJECT,1,3,new Field("Lorg/mortbay/jetty/client/webdav/WebdavListener;","_exchange","Lorg/mortbay/jetty/client/HttpExchange;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Lorg/mortbay/jetty/client/HttpExchange;","getMethod",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/String;","equalsIgnoreCase",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_EQZ,0,-1,L6);
                code.visitLabel(L5);
                code.visitFieldStmt(IPUT_BOOLEAN,2,3,new Field("Lorg/mortbay/jetty/client/webdav/WebdavListener;","_webdavEnabled","Z"));
                code.visitLabel(L6);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001_checkExists(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PRIVATE, new Method("Lorg/mortbay/jetty/client/webdav/WebdavListener;","checkExists",new String[]{ "Ljava/lang/String;"},"Z"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(7);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ "Ljava/lang/InterruptedException;"});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"uri");
                DexLabel L3=new DexLabel();
                ddv.visitPrologue(L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(240,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(241,L5);
                ddv.visitStartLocal(1,L5,"propfindExchange","Lorg/mortbay/jetty/client/webdav/PropfindExchange;",null);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(242,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(243,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(244,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(245,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(246,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(248,L11);
                ddv.visitLineNumber(252,L0);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(254,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(259,L13);
                ddv.visitLineNumber(256,L2);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(258,L14);
                ddv.visitStartLocal(0,L14,"ie","Ljava/lang/InterruptedException;",null);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(259,L15);
                code.visitLabel(L3);
                code.visitConstStmt(CONST_4,4, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L4);
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Lorg/mortbay/jetty/client/webdav/PropfindExchange;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1},new Method("Lorg/mortbay/jetty/client/webdav/PropfindExchange;","<init>",new String[]{ },"V"));
                code.visitLabel(L5);
                code.visitFieldStmt(IGET_OBJECT,2,5,new Field("Lorg/mortbay/jetty/client/webdav/WebdavListener;","_exchange","Lorg/mortbay/jetty/client/HttpExchange;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/jetty/client/HttpExchange;","getAddress",new String[]{ },"Lorg/mortbay/jetty/client/Address;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2},new Method("Lorg/mortbay/jetty/client/webdav/PropfindExchange;","setAddress",new String[]{ "Lorg/mortbay/jetty/client/Address;"},"V"));
                code.visitLabel(L6);
                code.visitConstStmt(CONST_STRING,2,"GET");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2},new Method("Lorg/mortbay/jetty/client/webdav/PropfindExchange;","setMethod",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L7);
                code.visitFieldStmt(IGET_OBJECT,2,5,new Field("Lorg/mortbay/jetty/client/webdav/WebdavListener;","_exchange","Lorg/mortbay/jetty/client/HttpExchange;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/jetty/client/HttpExchange;","getScheme",new String[]{ },"Lorg/mortbay/io/Buffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2},new Method("Lorg/mortbay/jetty/client/webdav/PropfindExchange;","setScheme",new String[]{ "Lorg/mortbay/io/Buffer;"},"V"));
                code.visitLabel(L8);
                code.visitTypeStmt(NEW_INSTANCE,2,-1,"Lorg/mortbay/jetty/client/security/SecurityListener;");
                code.visitFieldStmt(IGET_OBJECT,3,5,new Field("Lorg/mortbay/jetty/client/webdav/WebdavListener;","_destination","Lorg/mortbay/jetty/client/HttpDestination;"));
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2,3,1},new Method("Lorg/mortbay/jetty/client/security/SecurityListener;","<init>",new String[]{ "Lorg/mortbay/jetty/client/HttpDestination;","Lorg/mortbay/jetty/client/HttpExchange;"},"V"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2},new Method("Lorg/mortbay/jetty/client/webdav/PropfindExchange;","setEventListener",new String[]{ "Lorg/mortbay/jetty/client/HttpEventListener;"},"V"));
                code.visitLabel(L9);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,4},new Method("Lorg/mortbay/jetty/client/webdav/PropfindExchange;","setConfigureListeners",new String[]{ "Z"},"V"));
                code.visitLabel(L10);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,6},new Method("Lorg/mortbay/jetty/client/webdav/PropfindExchange;","setURI",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L11);
                code.visitFieldStmt(IGET_OBJECT,2,5,new Field("Lorg/mortbay/jetty/client/webdav/WebdavListener;","_destination","Lorg/mortbay/jetty/client/HttpDestination;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,1},new Method("Lorg/mortbay/jetty/client/HttpDestination;","send",new String[]{ "Lorg/mortbay/jetty/client/HttpExchange;"},"V"));
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Lorg/mortbay/jetty/client/webdav/PropfindExchange;","waitForDone",new String[]{ },"I"));
                code.visitLabel(L12);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Lorg/mortbay/jetty/client/webdav/PropfindExchange;","exists",new String[]{ },"Z"));
                code.visitLabel(L1);
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitLabel(L13);
                code.visitStmt1R(RETURN,2);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,2);
                code.visitStmt2R(MOVE_OBJECT,0,2);
                code.visitLabel(L14);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0},new Method("Lorg/mortbay/log/Log;","ignore",new String[]{ "Ljava/lang/Throwable;"},"V"));
                code.visitStmt2R(MOVE,2,4);
                code.visitLabel(L15);
                code.visitJumpStmt(GOTO,-1,-1,L13);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m002_checkWebdavSupported(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PRIVATE, new Method("Lorg/mortbay/jetty/client/webdav/WebdavListener;","checkWebdavSupported",new String[]{ },"Z"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(6);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ "Ljava/lang/InterruptedException;"});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L3=new DexLabel();
                ddv.visitPrologue(L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(291,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(292,L5);
                ddv.visitStartLocal(1,L5,"supportedExchange","Lorg/mortbay/jetty/client/webdav/WebdavSupportedExchange;",null);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(293,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(294,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(295,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(296,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(297,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(299,L11);
                ddv.visitLineNumber(303,L0);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(304,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(309,L13);
                ddv.visitLineNumber(306,L2);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(308,L14);
                ddv.visitStartLocal(0,L14,"ie","Ljava/lang/InterruptedException;",null);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(309,L15);
                code.visitLabel(L3);
                code.visitConstStmt(CONST_4,4, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L4);
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Lorg/mortbay/jetty/client/webdav/WebdavSupportedExchange;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1},new Method("Lorg/mortbay/jetty/client/webdav/WebdavSupportedExchange;","<init>",new String[]{ },"V"));
                code.visitLabel(L5);
                code.visitFieldStmt(IGET_OBJECT,2,5,new Field("Lorg/mortbay/jetty/client/webdav/WebdavListener;","_exchange","Lorg/mortbay/jetty/client/HttpExchange;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/jetty/client/HttpExchange;","getAddress",new String[]{ },"Lorg/mortbay/jetty/client/Address;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2},new Method("Lorg/mortbay/jetty/client/webdav/WebdavSupportedExchange;","setAddress",new String[]{ "Lorg/mortbay/jetty/client/Address;"},"V"));
                code.visitLabel(L6);
                code.visitConstStmt(CONST_STRING,2,"OPTIONS");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2},new Method("Lorg/mortbay/jetty/client/webdav/WebdavSupportedExchange;","setMethod",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L7);
                code.visitFieldStmt(IGET_OBJECT,2,5,new Field("Lorg/mortbay/jetty/client/webdav/WebdavListener;","_exchange","Lorg/mortbay/jetty/client/HttpExchange;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/jetty/client/HttpExchange;","getScheme",new String[]{ },"Lorg/mortbay/io/Buffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2},new Method("Lorg/mortbay/jetty/client/webdav/WebdavSupportedExchange;","setScheme",new String[]{ "Lorg/mortbay/io/Buffer;"},"V"));
                code.visitLabel(L8);
                code.visitTypeStmt(NEW_INSTANCE,2,-1,"Lorg/mortbay/jetty/client/security/SecurityListener;");
                code.visitFieldStmt(IGET_OBJECT,3,5,new Field("Lorg/mortbay/jetty/client/webdav/WebdavListener;","_destination","Lorg/mortbay/jetty/client/HttpDestination;"));
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2,3,1},new Method("Lorg/mortbay/jetty/client/security/SecurityListener;","<init>",new String[]{ "Lorg/mortbay/jetty/client/HttpDestination;","Lorg/mortbay/jetty/client/HttpExchange;"},"V"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2},new Method("Lorg/mortbay/jetty/client/webdav/WebdavSupportedExchange;","setEventListener",new String[]{ "Lorg/mortbay/jetty/client/HttpEventListener;"},"V"));
                code.visitLabel(L9);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,4},new Method("Lorg/mortbay/jetty/client/webdav/WebdavSupportedExchange;","setConfigureListeners",new String[]{ "Z"},"V"));
                code.visitLabel(L10);
                code.visitFieldStmt(IGET_OBJECT,2,5,new Field("Lorg/mortbay/jetty/client/webdav/WebdavListener;","_exchange","Lorg/mortbay/jetty/client/HttpExchange;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/jetty/client/HttpExchange;","getURI",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2},new Method("Lorg/mortbay/jetty/client/webdav/WebdavSupportedExchange;","setURI",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L11);
                code.visitFieldStmt(IGET_OBJECT,2,5,new Field("Lorg/mortbay/jetty/client/webdav/WebdavListener;","_destination","Lorg/mortbay/jetty/client/HttpDestination;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,1},new Method("Lorg/mortbay/jetty/client/HttpDestination;","send",new String[]{ "Lorg/mortbay/jetty/client/HttpExchange;"},"V"));
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Lorg/mortbay/jetty/client/webdav/WebdavSupportedExchange;","waitTilCompletion",new String[]{ },"V"));
                code.visitLabel(L12);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Lorg/mortbay/jetty/client/webdav/WebdavSupportedExchange;","isWebdavSupported",new String[]{ },"Z"));
                code.visitLabel(L1);
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitLabel(L13);
                code.visitStmt1R(RETURN,2);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,2);
                code.visitStmt2R(MOVE_OBJECT,0,2);
                code.visitLabel(L14);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0},new Method("Lorg/mortbay/log/Log;","ignore",new String[]{ "Ljava/lang/Throwable;"},"V"));
                code.visitStmt2R(MOVE,2,4);
                code.visitLabel(L15);
                code.visitJumpStmt(GOTO,-1,-1,L13);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m003_makeCollection(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PRIVATE, new Method("Lorg/mortbay/jetty/client/webdav/WebdavListener;","makeCollection",new String[]{ "Ljava/lang/String;"},"Z"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(7);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ "Ljava/lang/InterruptedException;"});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"uri");
                DexLabel L3=new DexLabel();
                ddv.visitPrologue(L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(265,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(266,L5);
                ddv.visitStartLocal(1,L5,"mkcolExchange","Lorg/mortbay/jetty/client/webdav/MkcolExchange;",null);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(267,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(268,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(269,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(270,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(271,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(273,L11);
                ddv.visitLineNumber(277,L0);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(279,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(284,L13);
                ddv.visitLineNumber(281,L2);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(283,L14);
                ddv.visitStartLocal(0,L14,"ie","Ljava/lang/InterruptedException;",null);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(284,L15);
                code.visitLabel(L3);
                code.visitConstStmt(CONST_4,4, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L4);
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Lorg/mortbay/jetty/client/webdav/MkcolExchange;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1},new Method("Lorg/mortbay/jetty/client/webdav/MkcolExchange;","<init>",new String[]{ },"V"));
                code.visitLabel(L5);
                code.visitFieldStmt(IGET_OBJECT,2,5,new Field("Lorg/mortbay/jetty/client/webdav/WebdavListener;","_exchange","Lorg/mortbay/jetty/client/HttpExchange;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/jetty/client/HttpExchange;","getAddress",new String[]{ },"Lorg/mortbay/jetty/client/Address;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2},new Method("Lorg/mortbay/jetty/client/webdav/MkcolExchange;","setAddress",new String[]{ "Lorg/mortbay/jetty/client/Address;"},"V"));
                code.visitLabel(L6);
                code.visitTypeStmt(NEW_INSTANCE,2,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,3,"MKCOL ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,6},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitConstStmt(CONST_STRING,3," HTTP/1.1");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2},new Method("Lorg/mortbay/jetty/client/webdav/MkcolExchange;","setMethod",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L7);
                code.visitFieldStmt(IGET_OBJECT,2,5,new Field("Lorg/mortbay/jetty/client/webdav/WebdavListener;","_exchange","Lorg/mortbay/jetty/client/HttpExchange;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/jetty/client/HttpExchange;","getScheme",new String[]{ },"Lorg/mortbay/io/Buffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2},new Method("Lorg/mortbay/jetty/client/webdav/MkcolExchange;","setScheme",new String[]{ "Lorg/mortbay/io/Buffer;"},"V"));
                code.visitLabel(L8);
                code.visitTypeStmt(NEW_INSTANCE,2,-1,"Lorg/mortbay/jetty/client/security/SecurityListener;");
                code.visitFieldStmt(IGET_OBJECT,3,5,new Field("Lorg/mortbay/jetty/client/webdav/WebdavListener;","_destination","Lorg/mortbay/jetty/client/HttpDestination;"));
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2,3,1},new Method("Lorg/mortbay/jetty/client/security/SecurityListener;","<init>",new String[]{ "Lorg/mortbay/jetty/client/HttpDestination;","Lorg/mortbay/jetty/client/HttpExchange;"},"V"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2},new Method("Lorg/mortbay/jetty/client/webdav/MkcolExchange;","setEventListener",new String[]{ "Lorg/mortbay/jetty/client/HttpEventListener;"},"V"));
                code.visitLabel(L9);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,4},new Method("Lorg/mortbay/jetty/client/webdav/MkcolExchange;","setConfigureListeners",new String[]{ "Z"},"V"));
                code.visitLabel(L10);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,6},new Method("Lorg/mortbay/jetty/client/webdav/MkcolExchange;","setURI",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L11);
                code.visitFieldStmt(IGET_OBJECT,2,5,new Field("Lorg/mortbay/jetty/client/webdav/WebdavListener;","_destination","Lorg/mortbay/jetty/client/HttpDestination;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,1},new Method("Lorg/mortbay/jetty/client/HttpDestination;","send",new String[]{ "Lorg/mortbay/jetty/client/HttpExchange;"},"V"));
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Lorg/mortbay/jetty/client/webdav/MkcolExchange;","waitForDone",new String[]{ },"I"));
                code.visitLabel(L12);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Lorg/mortbay/jetty/client/webdav/MkcolExchange;","exists",new String[]{ },"Z"));
                code.visitLabel(L1);
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitLabel(L13);
                code.visitStmt1R(RETURN,2);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,2);
                code.visitStmt2R(MOVE_OBJECT,0,2);
                code.visitLabel(L14);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0},new Method("Lorg/mortbay/log/Log;","ignore",new String[]{ "Ljava/lang/Throwable;"},"V"));
                code.visitStmt2R(MOVE,2,4);
                code.visitLabel(L15);
                code.visitJumpStmt(GOTO,-1,-1,L13);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m004_resolveCollectionIssues(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PRIVATE, new Method("Lorg/mortbay/jetty/client/webdav/WebdavListener;","resolveCollectionIssues",new String[]{ },"Z"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(11);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(208,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(209,L2);
                ddv.visitStartLocal(4,L2,"uri","Ljava/lang/String;",null);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(210,L3);
                ddv.visitStartLocal(5,L3,"uriCollection","[Ljava/lang/String;",null);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(211,L4);
                ddv.visitStartLocal(0,L4,"checkNum","I",null);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(213,L5);
                ddv.visitStartLocal(3,L5,"rewind","I",null);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(214,L6);
                ddv.visitStartLocal(2,L6,"parentUri","Ljava/lang/String;",null);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(216,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(217,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(221,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(223,L10);
                DexLabel L11=new DexLabel();
                ddv.visitStartLocal(1,L11,"i","I",null);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(225,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(226,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(227,L14);
                ddv.visitRestartLocal(2,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(232,L15);
                ddv.visitEndLocal(1,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(235,L16);
                DexLabel L17=new DexLabel();
                ddv.visitRestartLocal(1,L17);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,8, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitConstStmt(CONST_STRING,9,"/");
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,6,10,new Field("Lorg/mortbay/jetty/client/webdav/WebdavListener;","_exchange","Lorg/mortbay/jetty/client/HttpExchange;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Lorg/mortbay/jetty/client/HttpExchange;","getURI",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitLabel(L2);
                code.visitFieldStmt(IGET_OBJECT,6,10,new Field("Lorg/mortbay/jetty/client/webdav/WebdavListener;","_exchange","Lorg/mortbay/jetty/client/HttpExchange;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Lorg/mortbay/jetty/client/HttpExchange;","getURI",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitConstStmt(CONST_STRING,7,"/");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,9},new Method("Ljava/lang/String;","split",new String[]{ "Ljava/lang/String;"},"[Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitLabel(L3);
                code.visitStmt2R(ARRAY_LENGTH,0,5);
                code.visitLabel(L4);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L5);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 4},new Method("Lorg/mortbay/util/URIUtil;","parentPath",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitLabel(L6);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 10,2},new Method("Lorg/mortbay/jetty/client/webdav/WebdavListener;","checkExists",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,6);
                code.visitJumpStmt(IF_NEZ,6,-1,L9);
                code.visitLabel(L7);
                code.visitStmt2R1N(ADD_INT_LIT8,3,3,1);
                code.visitLabel(L8);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 2},new Method("Lorg/mortbay/util/URIUtil;","parentPath",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitJumpStmt(GOTO,-1,-1,L6);
                code.visitLabel(L9);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 10},new Method("Lorg/mortbay/jetty/client/webdav/WebdavListener;","checkWebdavSupported",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,6);
                code.visitJumpStmt(IF_EQZ,6,-1,L15);
                code.visitLabel(L10);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L11);
                code.visitJumpStmt(IF_GE,1,3,L17);
                code.visitLabel(L12);
                code.visitTypeStmt(NEW_INSTANCE,6,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 6},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,2},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitConstStmt(CONST_STRING,7,"/");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,9},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitStmt3R(SUB_INT,7,0,3);
                code.visitStmt2R(SUB_INT_2ADDR,7,8);
                code.visitStmt3R(AGET_OBJECT,7,5,7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,7},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 10,6},new Method("Lorg/mortbay/jetty/client/webdav/WebdavListener;","makeCollection",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitLabel(L13);
                code.visitTypeStmt(NEW_INSTANCE,6,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 6},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,2},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitConstStmt(CONST_STRING,7,"/");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,9},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitStmt3R(SUB_INT,7,0,3);
                code.visitStmt2R(SUB_INT_2ADDR,7,8);
                code.visitStmt3R(AGET_OBJECT,7,5,7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,7},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitLabel(L14);
                code.visitStmt2R1N(ADD_INT_LIT8,3,3,-1);
                code.visitJumpStmt(GOTO,-1,-1,L11);
                code.visitLabel(L15);
                code.visitConstStmt(CONST_4,6, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L16);
                code.visitStmt1R(RETURN,6);
                code.visitLabel(L17);
                code.visitStmt2R(MOVE,6,8);
                code.visitJumpStmt(GOTO,-1,-1,L16);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m005_onRequestComplete(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/client/webdav/WebdavListener;","onRequestComplete",new String[]{ },"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ "Ljava/io/IOException;"});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L3=new DexLabel();
                ddv.visitPrologue(L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(153,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(154,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(156,L6);
                ddv.visitLineNumber(161,L0);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(163,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(164,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(165,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(166,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(167,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(194,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(172,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(173,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(174,L15);
                ddv.visitLineNumber(177,L2);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(179,L16);
                ddv.visitStartLocal(0,L16,"ioe","Ljava/io/IOException;",null);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(180,L17);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(185,L18);
                ddv.visitEndLocal(0,L18);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(186,L19);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(187,L20);
                DexLabel L21=new DexLabel();
                ddv.visitLineNumber(192,L21);
                code.visitLabel(L3);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitLabel(L4);
                code.visitFieldStmt(IPUT_BOOLEAN,1,3,new Field("Lorg/mortbay/jetty/client/webdav/WebdavListener;","_requestComplete","Z"));
                code.visitLabel(L5);
                code.visitFieldStmt(IGET_BOOLEAN,1,3,new Field("Lorg/mortbay/jetty/client/webdav/WebdavListener;","_needIntercept","Z"));
                code.visitJumpStmt(IF_EQZ,1,-1,L21);
                code.visitLabel(L6);
                code.visitFieldStmt(IGET_BOOLEAN,1,3,new Field("Lorg/mortbay/jetty/client/webdav/WebdavListener;","_requestComplete","Z"));
                code.visitJumpStmt(IF_EQZ,1,-1,L18);
                code.visitFieldStmt(IGET_BOOLEAN,1,3,new Field("Lorg/mortbay/jetty/client/webdav/WebdavListener;","_responseComplete","Z"));
                code.visitJumpStmt(IF_EQZ,1,-1,L18);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 3},new Method("Lorg/mortbay/jetty/client/webdav/WebdavListener;","resolveCollectionIssues",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitJumpStmt(IF_EQZ,1,-1,L13);
                code.visitLabel(L7);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,1},new Method("Lorg/mortbay/jetty/client/webdav/WebdavListener;","setDelegatingRequests",new String[]{ "Z"},"V"));
                code.visitLabel(L8);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,1},new Method("Lorg/mortbay/jetty/client/webdav/WebdavListener;","setDelegatingResponses",new String[]{ "Z"},"V"));
                code.visitLabel(L9);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT_BOOLEAN,1,3,new Field("Lorg/mortbay/jetty/client/webdav/WebdavListener;","_requestComplete","Z"));
                code.visitLabel(L10);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT_BOOLEAN,1,3,new Field("Lorg/mortbay/jetty/client/webdav/WebdavListener;","_responseComplete","Z"));
                code.visitLabel(L11);
                code.visitFieldStmt(IGET_OBJECT,1,3,new Field("Lorg/mortbay/jetty/client/webdav/WebdavListener;","_destination","Lorg/mortbay/jetty/client/HttpDestination;"));
                code.visitFieldStmt(IGET_OBJECT,2,3,new Field("Lorg/mortbay/jetty/client/webdav/WebdavListener;","_exchange","Lorg/mortbay/jetty/client/HttpExchange;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2},new Method("Lorg/mortbay/jetty/client/HttpDestination;","resend",new String[]{ "Lorg/mortbay/jetty/client/HttpExchange;"},"V"));
                code.visitLabel(L12);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L13);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,1},new Method("Lorg/mortbay/jetty/client/webdav/WebdavListener;","setDelegatingRequests",new String[]{ "Z"},"V"));
                code.visitLabel(L14);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,1},new Method("Lorg/mortbay/jetty/client/webdav/WebdavListener;","setDelegatingResponses",new String[]{ "Z"},"V"));
                code.visitLabel(L15);
                code.visitMethodStmt(INVOKE_SUPER,new int[]{ 3},new Method("Lorg/mortbay/jetty/client/HttpEventListenerWrapper;","onRequestComplete",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitJumpStmt(GOTO,-1,-1,L12);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,1);
                code.visitStmt2R(MOVE_OBJECT,0,1);
                code.visitLabel(L16);
                code.visitConstStmt(CONST_STRING,1,"WebdavListener:Complete:IOException: might not be dealing with dav server, delegate");
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1},new Method("Lorg/mortbay/log/Log;","debug",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L17);
                code.visitMethodStmt(INVOKE_SUPER,new int[]{ 3},new Method("Lorg/mortbay/jetty/client/HttpEventListenerWrapper;","onRequestComplete",new String[]{ },"V"));
                code.visitJumpStmt(GOTO,-1,-1,L12);
                code.visitLabel(L18);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Lorg/mortbay/log/Log;","isDebugEnabled",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitJumpStmt(IF_EQZ,1,-1,L20);
                code.visitLabel(L19);
                code.visitConstStmt(CONST_STRING,1,"WebdavListener:Not ready, calling super");
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1},new Method("Lorg/mortbay/log/Log;","debug",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L20);
                code.visitMethodStmt(INVOKE_SUPER,new int[]{ 3},new Method("Lorg/mortbay/jetty/client/HttpEventListenerWrapper;","onRequestComplete",new String[]{ },"V"));
                code.visitJumpStmt(GOTO,-1,-1,L12);
                code.visitLabel(L21);
                code.visitMethodStmt(INVOKE_SUPER,new int[]{ 3},new Method("Lorg/mortbay/jetty/client/HttpEventListenerWrapper;","onRequestComplete",new String[]{ },"V"));
                code.visitJumpStmt(GOTO,-1,-1,L12);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m006_onResponseComplete(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/client/webdav/WebdavListener;","onResponseComplete",new String[]{ },"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ "Ljava/io/IOException;"});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L3=new DexLabel();
                ddv.visitPrologue(L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(106,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(107,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(109,L6);
                ddv.visitLineNumber(114,L0);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(116,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(117,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(118,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(119,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(120,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(147,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(125,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(126,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(127,L15);
                ddv.visitLineNumber(130,L2);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(132,L16);
                ddv.visitStartLocal(0,L16,"ioe","Ljava/io/IOException;",null);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(133,L17);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(138,L18);
                ddv.visitEndLocal(0,L18);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(139,L19);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(140,L20);
                DexLabel L21=new DexLabel();
                ddv.visitLineNumber(145,L21);
                code.visitLabel(L3);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitLabel(L4);
                code.visitFieldStmt(IPUT_BOOLEAN,1,3,new Field("Lorg/mortbay/jetty/client/webdav/WebdavListener;","_responseComplete","Z"));
                code.visitLabel(L5);
                code.visitFieldStmt(IGET_BOOLEAN,1,3,new Field("Lorg/mortbay/jetty/client/webdav/WebdavListener;","_needIntercept","Z"));
                code.visitJumpStmt(IF_EQZ,1,-1,L21);
                code.visitLabel(L6);
                code.visitFieldStmt(IGET_BOOLEAN,1,3,new Field("Lorg/mortbay/jetty/client/webdav/WebdavListener;","_requestComplete","Z"));
                code.visitJumpStmt(IF_EQZ,1,-1,L18);
                code.visitFieldStmt(IGET_BOOLEAN,1,3,new Field("Lorg/mortbay/jetty/client/webdav/WebdavListener;","_responseComplete","Z"));
                code.visitJumpStmt(IF_EQZ,1,-1,L18);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 3},new Method("Lorg/mortbay/jetty/client/webdav/WebdavListener;","resolveCollectionIssues",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitJumpStmt(IF_EQZ,1,-1,L13);
                code.visitLabel(L7);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,1},new Method("Lorg/mortbay/jetty/client/webdav/WebdavListener;","setDelegatingRequests",new String[]{ "Z"},"V"));
                code.visitLabel(L8);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,1},new Method("Lorg/mortbay/jetty/client/webdav/WebdavListener;","setDelegatingResponses",new String[]{ "Z"},"V"));
                code.visitLabel(L9);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT_BOOLEAN,1,3,new Field("Lorg/mortbay/jetty/client/webdav/WebdavListener;","_requestComplete","Z"));
                code.visitLabel(L10);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT_BOOLEAN,1,3,new Field("Lorg/mortbay/jetty/client/webdav/WebdavListener;","_responseComplete","Z"));
                code.visitLabel(L11);
                code.visitFieldStmt(IGET_OBJECT,1,3,new Field("Lorg/mortbay/jetty/client/webdav/WebdavListener;","_destination","Lorg/mortbay/jetty/client/HttpDestination;"));
                code.visitFieldStmt(IGET_OBJECT,2,3,new Field("Lorg/mortbay/jetty/client/webdav/WebdavListener;","_exchange","Lorg/mortbay/jetty/client/HttpExchange;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2},new Method("Lorg/mortbay/jetty/client/HttpDestination;","resend",new String[]{ "Lorg/mortbay/jetty/client/HttpExchange;"},"V"));
                code.visitLabel(L12);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L13);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,1},new Method("Lorg/mortbay/jetty/client/webdav/WebdavListener;","setDelegatingRequests",new String[]{ "Z"},"V"));
                code.visitLabel(L14);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,1},new Method("Lorg/mortbay/jetty/client/webdav/WebdavListener;","setDelegatingResponses",new String[]{ "Z"},"V"));
                code.visitLabel(L15);
                code.visitMethodStmt(INVOKE_SUPER,new int[]{ 3},new Method("Lorg/mortbay/jetty/client/HttpEventListenerWrapper;","onResponseComplete",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitJumpStmt(GOTO,-1,-1,L12);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,1);
                code.visitStmt2R(MOVE_OBJECT,0,1);
                code.visitLabel(L16);
                code.visitConstStmt(CONST_STRING,1,"WebdavListener:Complete:IOException: might not be dealing with dav server, delegate");
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1},new Method("Lorg/mortbay/log/Log;","debug",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L17);
                code.visitMethodStmt(INVOKE_SUPER,new int[]{ 3},new Method("Lorg/mortbay/jetty/client/HttpEventListenerWrapper;","onResponseComplete",new String[]{ },"V"));
                code.visitJumpStmt(GOTO,-1,-1,L12);
                code.visitLabel(L18);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Lorg/mortbay/log/Log;","isDebugEnabled",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitJumpStmt(IF_EQZ,1,-1,L20);
                code.visitLabel(L19);
                code.visitConstStmt(CONST_STRING,1,"WebdavListener:Not ready, calling super");
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1},new Method("Lorg/mortbay/log/Log;","debug",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L20);
                code.visitMethodStmt(INVOKE_SUPER,new int[]{ 3},new Method("Lorg/mortbay/jetty/client/HttpEventListenerWrapper;","onResponseComplete",new String[]{ },"V"));
                code.visitJumpStmt(GOTO,-1,-1,L12);
                code.visitLabel(L21);
                code.visitMethodStmt(INVOKE_SUPER,new int[]{ 3},new Method("Lorg/mortbay/jetty/client/HttpEventListenerWrapper;","onResponseComplete",new String[]{ },"V"));
                code.visitJumpStmt(GOTO,-1,-1,L12);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m007_onResponseStatus(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/client/webdav/WebdavListener;","onResponseStatus",new String[]{ "Lorg/mortbay/io/Buffer;","I","Lorg/mortbay/io/Buffer;"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(8);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"version");
                ddv.visitParameterName(1,"status");
                ddv.visitParameterName(2,"reason");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(64,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(66,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(67,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(102,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(71,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(72,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(76,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(78,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(80,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(81,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(82,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(83,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(101,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(87,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(88,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(89,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(90,L17);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(91,L18);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(96,L19);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(97,L20);
                DexLabel L21=new DexLabel();
                ddv.visitLineNumber(98,L21);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitConstStmt(CONST_4,2, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_BOOLEAN,0,4,new Field("Lorg/mortbay/jetty/client/webdav/WebdavListener;","_webdavEnabled","Z"));
                code.visitJumpStmt(IF_NEZ,0,-1,L5);
                code.visitLabel(L2);
                code.visitFieldStmt(IPUT_BOOLEAN,3,4,new Field("Lorg/mortbay/jetty/client/webdav/WebdavListener;","_needIntercept","Z"));
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_SUPER,new int[]{ 4,5,6,7},new Method("Lorg/mortbay/jetty/client/HttpEventListenerWrapper;","onResponseStatus",new String[]{ "Lorg/mortbay/io/Buffer;","I","Lorg/mortbay/io/Buffer;"},"V"));
                code.visitLabel(L4);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L5);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Lorg/mortbay/log/Log;","isDebugEnabled",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_EQZ,0,-1,L7);
                code.visitLabel(L6);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,1,"WebdavListener:Response Status: ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,6},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "I"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0},new Method("Lorg/mortbay/log/Log;","debug",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L7);
                code.visitConstStmt(CONST_16,0, Integer.valueOf(409)); // int: 0x00000199  float:0.000000
                code.visitJumpStmt(IF_EQ,6,0,L8);
                code.visitConstStmt(CONST_16,0, Integer.valueOf(403)); // int: 0x00000193  float:0.000000
                code.visitJumpStmt(IF_NE,6,0,L19);
                code.visitLabel(L8);
                code.visitFieldStmt(IGET_BOOLEAN,0,4,new Field("Lorg/mortbay/jetty/client/webdav/WebdavListener;","_webdavEnabled","Z"));
                code.visitJumpStmt(IF_EQZ,0,-1,L14);
                code.visitLabel(L9);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Lorg/mortbay/log/Log;","isDebugEnabled",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_EQZ,0,-1,L11);
                code.visitLabel(L10);
                code.visitConstStmt(CONST_STRING,0,"WebdavListener:Response Status: dav enabled, taking a stab at resolving put issue");
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0},new Method("Lorg/mortbay/log/Log;","debug",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L11);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,3},new Method("Lorg/mortbay/jetty/client/webdav/WebdavListener;","setDelegatingResponses",new String[]{ "Z"},"V"));
                code.visitLabel(L12);
                code.visitFieldStmt(IPUT_BOOLEAN,2,4,new Field("Lorg/mortbay/jetty/client/webdav/WebdavListener;","_needIntercept","Z"));
                code.visitLabel(L13);
                code.visitMethodStmt(INVOKE_SUPER,new int[]{ 4,5,6,7},new Method("Lorg/mortbay/jetty/client/HttpEventListenerWrapper;","onResponseStatus",new String[]{ "Lorg/mortbay/io/Buffer;","I","Lorg/mortbay/io/Buffer;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L4);
                code.visitLabel(L14);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Lorg/mortbay/log/Log;","isDebugEnabled",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_EQZ,0,-1,L16);
                code.visitLabel(L15);
                code.visitConstStmt(CONST_STRING,0,"WebdavListener:Response Status: Webdav Disabled");
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0},new Method("Lorg/mortbay/log/Log;","debug",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L16);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,2},new Method("Lorg/mortbay/jetty/client/webdav/WebdavListener;","setDelegatingResponses",new String[]{ "Z"},"V"));
                code.visitLabel(L17);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,2},new Method("Lorg/mortbay/jetty/client/webdav/WebdavListener;","setDelegatingRequests",new String[]{ "Z"},"V"));
                code.visitLabel(L18);
                code.visitFieldStmt(IPUT_BOOLEAN,3,4,new Field("Lorg/mortbay/jetty/client/webdav/WebdavListener;","_needIntercept","Z"));
                code.visitJumpStmt(GOTO,-1,-1,L13);
                code.visitLabel(L19);
                code.visitFieldStmt(IPUT_BOOLEAN,3,4,new Field("Lorg/mortbay/jetty/client/webdav/WebdavListener;","_needIntercept","Z"));
                code.visitLabel(L20);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,2},new Method("Lorg/mortbay/jetty/client/webdav/WebdavListener;","setDelegatingResponses",new String[]{ "Z"},"V"));
                code.visitLabel(L21);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,2},new Method("Lorg/mortbay/jetty/client/webdav/WebdavListener;","setDelegatingRequests",new String[]{ "Z"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L13);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
