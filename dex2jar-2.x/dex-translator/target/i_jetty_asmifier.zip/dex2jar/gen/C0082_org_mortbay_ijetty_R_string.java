package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0082_org_mortbay_ijetty_R_string {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(ACC_PUBLIC|ACC_FINAL,"Lorg/mortbay/ijetty/R$string;","Ljava/lang/Object;",new String[]{ });
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("R.java");
        if(cv!=null){
            DexAnnotationVisitor av00 = cv.visitAnnotation("Ldalvik/annotation/EnclosingClass;", Visibility.SYSTEM);
            if(av00 != null) {
                av00.visit("value", new DexType("Lorg/mortbay/ijetty/R;"));
                av00.visitEnd();
            }
        }
        if(cv!=null){
            DexAnnotationVisitor av00 = cv.visitAnnotation("Ldalvik/annotation/InnerClass;", Visibility.SYSTEM);
            if(av00 != null) {
                av00.visit("accessFlags",  Integer.valueOf(25));
                av00.visit("name", "string");
                av00.visitEnd();
            }
        }
        f000_app_name(cv);
        f001_config_jetty(cv);
        f002_context_path(cv);
        f003_download_fail(cv);
        f004_download_success(cv);
        f005_download_webapp(cv);
        f006_edit_preferences(cv);
        f007_failure(cv);
        f008_interfaces(cv);
        f009_jetty_already_started(cv);
        f010_jetty_controller(cv);
        f011_jetty_downloader(cv);
        f012_jetty_not_running(cv);
        f013_jetty_not_started(cv);
        f014_jetty_not_stopped(cv);
        f015_jetty_started(cv);
        f016_jetty_stopped(cv);
        f017_loading(cv);
        f018_manage_jetty(cv);
        f019_no(cv);
        f020_overwrite(cv);
        f021_pref_console_pwd(cv);
        f022_pref_console_pwd_key(cv);
        f023_pref_console_pwd_title(cv);
        f024_pref_console_pwd_value(cv);
        f025_pref_nio_key(cv);
        f026_pref_nio_title(cv);
        f027_pref_nio_value(cv);
        f028_pref_port(cv);
        f029_pref_port_key(cv);
        f030_pref_port_title(cv);
        f031_pref_port_value(cv);
        f032_start_download(cv);
        f033_start_jetty(cv);
        f034_stop_jetty(cv);
        f035_success(cv);
        f036_url(cv);
        f037_webapp_exists(cv);
        f038_yes(cv);
        m000__init_(cv);
    }
    public static void f000_app_name(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/ijetty/R$string;","app_name","I"),  Integer.valueOf(2131099648));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f001_config_jetty(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/ijetty/R$string;","config_jetty","I"),  Integer.valueOf(2131099660));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f002_context_path(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/ijetty/R$string;","context_path","I"),  Integer.valueOf(2131099686));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f003_download_fail(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/ijetty/R$string;","download_fail","I"),  Integer.valueOf(2131099678));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f004_download_success(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/ijetty/R$string;","download_success","I"),  Integer.valueOf(2131099679));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f005_download_webapp(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/ijetty/R$string;","download_webapp","I"),  Integer.valueOf(2131099662));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f006_edit_preferences(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/ijetty/R$string;","edit_preferences","I"),  Integer.valueOf(2131099676));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f007_failure(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/ijetty/R$string;","failure","I"),  Integer.valueOf(2131099681));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f008_interfaces(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/ijetty/R$string;","interfaces","I"),  Integer.valueOf(2131099664));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f009_jetty_already_started(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/ijetty/R$string;","jetty_already_started","I"),  Integer.valueOf(2131099651));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f010_jetty_controller(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/ijetty/R$string;","jetty_controller","I"),  Integer.valueOf(2131099656));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f011_jetty_downloader(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/ijetty/R$string;","jetty_downloader","I"),  Integer.valueOf(2131099657));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f012_jetty_not_running(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/ijetty/R$string;","jetty_not_running","I"),  Integer.valueOf(2131099654));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f013_jetty_not_started(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/ijetty/R$string;","jetty_not_started","I"),  Integer.valueOf(2131099650));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f014_jetty_not_stopped(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/ijetty/R$string;","jetty_not_stopped","I"),  Integer.valueOf(2131099653));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f015_jetty_started(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/ijetty/R$string;","jetty_started","I"),  Integer.valueOf(2131099649));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f016_jetty_stopped(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/ijetty/R$string;","jetty_stopped","I"),  Integer.valueOf(2131099652));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f017_loading(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/ijetty/R$string;","loading","I"),  Integer.valueOf(2131099685));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f018_manage_jetty(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/ijetty/R$string;","manage_jetty","I"),  Integer.valueOf(2131099655));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f019_no(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/ijetty/R$string;","no","I"),  Integer.valueOf(2131099683));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f020_overwrite(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/ijetty/R$string;","overwrite","I"),  Integer.valueOf(2131099684));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f021_pref_console_pwd(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/ijetty/R$string;","pref_console_pwd","I"),  Integer.valueOf(2131099673));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f022_pref_console_pwd_key(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/ijetty/R$string;","pref_console_pwd_key","I"),  Integer.valueOf(2131099675));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f023_pref_console_pwd_title(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/ijetty/R$string;","pref_console_pwd_title","I"),  Integer.valueOf(2131099674));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f024_pref_console_pwd_value(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/ijetty/R$string;","pref_console_pwd_value","I"),  Integer.valueOf(2131099672));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f025_pref_nio_key(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/ijetty/R$string;","pref_nio_key","I"),  Integer.valueOf(2131099667));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f026_pref_nio_title(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/ijetty/R$string;","pref_nio_title","I"),  Integer.valueOf(2131099666));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f027_pref_nio_value(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/ijetty/R$string;","pref_nio_value","I"),  Integer.valueOf(2131099665));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f028_pref_port(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/ijetty/R$string;","pref_port","I"),  Integer.valueOf(2131099669));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f029_pref_port_key(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/ijetty/R$string;","pref_port_key","I"),  Integer.valueOf(2131099671));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f030_pref_port_title(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/ijetty/R$string;","pref_port_title","I"),  Integer.valueOf(2131099670));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f031_pref_port_value(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/ijetty/R$string;","pref_port_value","I"),  Integer.valueOf(2131099668));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f032_start_download(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/ijetty/R$string;","start_download","I"),  Integer.valueOf(2131099661));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f033_start_jetty(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/ijetty/R$string;","start_jetty","I"),  Integer.valueOf(2131099658));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f034_stop_jetty(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/ijetty/R$string;","stop_jetty","I"),  Integer.valueOf(2131099659));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f035_success(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/ijetty/R$string;","success","I"),  Integer.valueOf(2131099680));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f036_url(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/ijetty/R$string;","url","I"),  Integer.valueOf(2131099663));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f037_webapp_exists(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/ijetty/R$string;","webapp_exists","I"),  Integer.valueOf(2131099677));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f038_yes(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/ijetty/R$string;","yes","I"),  Integer.valueOf(2131099682));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void m000__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/ijetty/R$string;","<init>",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(1);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(39,L0);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/lang/Object;","<init>",new String[]{ },"V"));
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
