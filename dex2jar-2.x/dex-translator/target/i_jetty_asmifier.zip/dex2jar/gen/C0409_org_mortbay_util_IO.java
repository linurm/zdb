package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0409_org_mortbay_util_IO {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(ACC_PUBLIC,"Lorg/mortbay/util/IO;","Lorg/mortbay/thread/BoundedThreadPool;",new String[]{ });
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("IO.java");
        if(cv!=null){
            DexAnnotationVisitor av00 = cv.visitAnnotation("Ldalvik/annotation/MemberClasses;", Visibility.SYSTEM);
            if(av00 != null) {
                {
                    DexAnnotationVisitor av01 = av00.visitArray("value");
                    if(av01 != null) {
                        av01.visit(null, new DexType("Lorg/mortbay/util/IO$1;"));
                        av01.visit(null, new DexType("Lorg/mortbay/util/IO$NullWrite;"));
                        av01.visit(null, new DexType("Lorg/mortbay/util/IO$ClosedIS;"));
                        av01.visit(null, new DexType("Lorg/mortbay/util/IO$NullOS;"));
                        av01.visit(null, new DexType("Lorg/mortbay/util/IO$Job;"));
                        av01.visit(null, new DexType("Lorg/mortbay/util/IO$Singleton;"));
                        av01.visitEnd();
                    }
                }
                av00.visitEnd();
            }
        }
        f000_CRLF(cv);
        f001_CRLF_BYTES(cv);
        f002___closedStream(cv);
        f003___nullStream(cv);
        f004___nullWriter(cv);
        f005_bufferSize(cv);
        m000__clinit_(cv);
        m001__init_(cv);
        m002_close(cv);
        m003_close(cv);
        m004_copy(cv);
        m005_copy(cv);
        m006_copy(cv);
        m007_copy(cv);
        m008_copy(cv);
        m009_copyDir(cv);
        m010_copyFile(cv);
        m011_copyThread(cv);
        m012_copyThread(cv);
        m013_delete(cv);
        m014_getClosedStream(cv);
        m015_getNullStream(cv);
        m016_getNullWriter(cv);
        m017_instance(cv);
        m018_readBytes(cv);
        m019_toString(cv);
        m020_toString(cv);
        m021_toString(cv);
    }
    public static void f000_CRLF(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/util/IO;","CRLF","Ljava/lang/String;"), "\r\n");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f001_CRLF_BYTES(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/util/IO;","CRLF_BYTES","[B"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f002___closedStream(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE|ACC_STATIC, new Field("Lorg/mortbay/util/IO;","__closedStream","Lorg/mortbay/util/IO$ClosedIS;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f003___nullStream(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE|ACC_STATIC, new Field("Lorg/mortbay/util/IO;","__nullStream","Lorg/mortbay/util/IO$NullOS;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f004___nullWriter(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE|ACC_STATIC, new Field("Lorg/mortbay/util/IO;","__nullWriter","Lorg/mortbay/util/IO$NullWrite;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f005_bufferSize(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC, new Field("Lorg/mortbay/util/IO;","bufferSize","I"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void m000__clinit_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_STATIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/util/IO;","<clinit>",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(44,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(47,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(424,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(436,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(459,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(44,L6);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(2)); // int: 0x00000002  float:0.000000
                code.visitTypeStmt(NEW_ARRAY,0,0,"[B");
                code.visitFieldStmt(SPUT_OBJECT,0,-1,new Field("Lorg/mortbay/util/IO;","CRLF_BYTES","[B"));
                code.visitLabel(L2);
                code.visitConstStmt(CONST_16,0, Integer.valueOf(16384)); // int: 0x00004000  float:0.000000
                code.visitFieldStmt(SPUT,0,-1,new Field("Lorg/mortbay/util/IO;","bufferSize","I"));
                code.visitLabel(L3);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Lorg/mortbay/util/IO$NullOS;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1},new Method("Lorg/mortbay/util/IO$NullOS;","<init>",new String[]{ "Lorg/mortbay/util/IO$1;"},"V"));
                code.visitFieldStmt(SPUT_OBJECT,0,-1,new Field("Lorg/mortbay/util/IO;","__nullStream","Lorg/mortbay/util/IO$NullOS;"));
                code.visitLabel(L4);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Lorg/mortbay/util/IO$ClosedIS;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1},new Method("Lorg/mortbay/util/IO$ClosedIS;","<init>",new String[]{ "Lorg/mortbay/util/IO$1;"},"V"));
                code.visitFieldStmt(SPUT_OBJECT,0,-1,new Field("Lorg/mortbay/util/IO;","__closedStream","Lorg/mortbay/util/IO$ClosedIS;"));
                code.visitLabel(L5);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Lorg/mortbay/util/IO$NullWrite;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1},new Method("Lorg/mortbay/util/IO$NullWrite;","<init>",new String[]{ "Lorg/mortbay/util/IO$1;"},"V"));
                code.visitFieldStmt(SPUT_OBJECT,0,-1,new Field("Lorg/mortbay/util/IO;","__nullWriter","Lorg/mortbay/util/IO$NullWrite;"));
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L6);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/util/IO;","<init>",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(1);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(36,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(449,L1);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Lorg/mortbay/thread/BoundedThreadPool;","<init>",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m002_close(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Lorg/mortbay/util/IO;","close",new String[]{ "Ljava/io/InputStream;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ "Ljava/io/IOException;"});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"is");
                DexLabel L3=new DexLabel();
                ddv.visitPrologue(L3);
                ddv.visitLineNumber(359,L3);
                ddv.visitLineNumber(360,L0);
                ddv.visitLineNumber(366,L1);
                ddv.visitLineNumber(362,L2);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(364,L4);
                ddv.visitStartLocal(0,L4,"e","Ljava/io/IOException;",null);
                code.visitLabel(L3);
                code.visitJumpStmt(IF_EQZ,1,-1,L1);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/io/InputStream;","close",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,0);
                code.visitLabel(L4);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0},new Method("Lorg/mortbay/log/Log;","ignore",new String[]{ "Ljava/lang/Throwable;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L1);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m003_close(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Lorg/mortbay/util/IO;","close",new String[]{ "Ljava/io/OutputStream;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ "Ljava/io/IOException;"});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"os");
                DexLabel L3=new DexLabel();
                ddv.visitPrologue(L3);
                ddv.visitLineNumber(387,L3);
                ddv.visitLineNumber(388,L0);
                ddv.visitLineNumber(394,L1);
                ddv.visitLineNumber(390,L2);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(392,L4);
                ddv.visitStartLocal(0,L4,"e","Ljava/io/IOException;",null);
                code.visitLabel(L3);
                code.visitJumpStmt(IF_EQZ,1,-1,L1);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/io/OutputStream;","close",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,0);
                code.visitLabel(L4);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0},new Method("Lorg/mortbay/log/Log;","ignore",new String[]{ "Ljava/lang/Throwable;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L1);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m004_copy(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Lorg/mortbay/util/IO;","copy",new String[]{ "Ljava/io/File;","Ljava/io/File;"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"from");
                ddv.visitParameterName(1,"to");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(257,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(258,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(261,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(260,L3);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/io/File;","isDirectory",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_EQZ,0,-1,L3);
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1,2},new Method("Lorg/mortbay/util/IO;","copyDir",new String[]{ "Ljava/io/File;","Ljava/io/File;"},"V"));
                code.visitLabel(L2);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1,2},new Method("Lorg/mortbay/util/IO;","copyFile",new String[]{ "Ljava/io/File;","Ljava/io/File;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m005_copy(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Lorg/mortbay/util/IO;","copy",new String[]{ "Ljava/io/InputStream;","Ljava/io/OutputStream;"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"in");
                ddv.visitParameterName(1,"out");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(141,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(142,L1);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_WIDE_16,0,Long.valueOf(-1L)); // long: 0xffffffffffffffff  double:NaN
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 2,3,0,1},new Method("Lorg/mortbay/util/IO;","copy",new String[]{ "Ljava/io/InputStream;","Ljava/io/OutputStream;","J"},"V"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m006_copy(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Lorg/mortbay/util/IO;","copy",new String[]{ "Ljava/io/InputStream;","Ljava/io/OutputStream;","J"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(11);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"in");
                ddv.visitParameterName(1,"out");
                ddv.visitParameterName(2,"byteCount");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(179,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(180,L2);
                ddv.visitStartLocal(0,L2,"buffer","[B",null);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(182,L3);
                ddv.visitStartLocal(1,L3,"len","I",null);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(184,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(186,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(187,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(191,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(208,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(189,L9);
                DexLabel L10=new DexLabel();
                ddv.visitRestartLocal(1,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(194,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(195,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(205,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(202,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(203,L15);
                ddv.visitRestartLocal(1,L15);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_WIDE_16,5,Long.valueOf(0L)); // long: 0x0000000000000000  double:0.000000
                code.visitConstStmt(CONST_4,4, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L1);
                code.visitFieldStmt(SGET,2,-1,new Field("Lorg/mortbay/util/IO;","bufferSize","I"));
                code.visitTypeStmt(NEW_ARRAY,0,2,"[B");
                code.visitLabel(L2);
                code.visitFieldStmt(SGET,1,-1,new Field("Lorg/mortbay/util/IO;","bufferSize","I"));
                code.visitLabel(L3);
                code.visitStmt3R(CMP_LONG,2,9,5);
                code.visitJumpStmt(IF_LTZ,2,-1,L14);
                code.visitLabel(L4);
                code.visitStmt3R(CMP_LONG,2,9,5);
                code.visitJumpStmt(IF_LEZ,2,-1,L8);
                code.visitLabel(L5);
                code.visitFieldStmt(SGET,2,-1,new Field("Lorg/mortbay/util/IO;","bufferSize","I"));
                code.visitStmt2R(INT_TO_LONG,2,2);
                code.visitStmt3R(CMP_LONG,2,9,2);
                code.visitJumpStmt(IF_GEZ,2,-1,L9);
                code.visitLabel(L6);
                code.visitStmt2R(LONG_TO_INT,2,9);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7,0,4,2},new Method("Ljava/io/InputStream;","read",new String[]{ "[B","I","I"},"I"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitLabel(L7);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(-1)); // int: 0xffffffff  float:NaN
                code.visitJumpStmt(IF_NE,1,2,L11);
                code.visitLabel(L8);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L9);
                code.visitFieldStmt(SGET,2,-1,new Field("Lorg/mortbay/util/IO;","bufferSize","I"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7,0,4,2},new Method("Ljava/io/InputStream;","read",new String[]{ "[B","I","I"},"I"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitLabel(L10);
                code.visitJumpStmt(GOTO,-1,-1,L7);
                code.visitLabel(L11);
                code.visitStmt2R(INT_TO_LONG,2,1);
                code.visitStmt2R(SUB_LONG_2ADDR,9,2);
                code.visitLabel(L12);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8,0,4,1},new Method("Ljava/io/OutputStream;","write",new String[]{ "[B","I","I"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L4);
                code.visitLabel(L13);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8,0,4,1},new Method("Ljava/io/OutputStream;","write",new String[]{ "[B","I","I"},"V"));
                code.visitLabel(L14);
                code.visitFieldStmt(SGET,2,-1,new Field("Lorg/mortbay/util/IO;","bufferSize","I"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7,0,4,2},new Method("Ljava/io/InputStream;","read",new String[]{ "[B","I","I"},"I"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitLabel(L15);
                code.visitJumpStmt(IF_GEZ,1,-1,L13);
                code.visitJumpStmt(GOTO,-1,-1,L8);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m007_copy(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Lorg/mortbay/util/IO;","copy",new String[]{ "Ljava/io/Reader;","Ljava/io/Writer;"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"in");
                ddv.visitParameterName(1,"out");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(168,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(169,L1);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_WIDE_16,0,Long.valueOf(-1L)); // long: 0xffffffffffffffff  double:NaN
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 2,3,0,1},new Method("Lorg/mortbay/util/IO;","copy",new String[]{ "Ljava/io/Reader;","Ljava/io/Writer;","J"},"V"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m008_copy(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Lorg/mortbay/util/IO;","copy",new String[]{ "Ljava/io/Reader;","Ljava/io/Writer;","J"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(12);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"in");
                ddv.visitParameterName(1,"out");
                ddv.visitParameterName(2,"byteCount");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(218,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(219,L2);
                ddv.visitStartLocal(0,L2,"buffer","[C",null);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(221,L3);
                ddv.visitStartLocal(1,L3,"len","I",null);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(223,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(225,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(226,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(230,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(247,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(228,L9);
                DexLabel L10=new DexLabel();
                ddv.visitRestartLocal(1,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(233,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(234,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(244,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(241,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(242,L15);
                ddv.visitRestartLocal(1,L15);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_WIDE_16,6,Long.valueOf(0L)); // long: 0x0000000000000000  double:0.000000
                code.visitConstStmt(CONST_4,5, Integer.valueOf(-1)); // int: 0xffffffff  float:NaN
                code.visitConstStmt(CONST_4,4, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L1);
                code.visitFieldStmt(SGET,2,-1,new Field("Lorg/mortbay/util/IO;","bufferSize","I"));
                code.visitTypeStmt(NEW_ARRAY,0,2,"[C");
                code.visitLabel(L2);
                code.visitFieldStmt(SGET,1,-1,new Field("Lorg/mortbay/util/IO;","bufferSize","I"));
                code.visitLabel(L3);
                code.visitStmt3R(CMP_LONG,2,10,6);
                code.visitJumpStmt(IF_LTZ,2,-1,L14);
                code.visitLabel(L4);
                code.visitStmt3R(CMP_LONG,2,10,6);
                code.visitJumpStmt(IF_LEZ,2,-1,L8);
                code.visitLabel(L5);
                code.visitFieldStmt(SGET,2,-1,new Field("Lorg/mortbay/util/IO;","bufferSize","I"));
                code.visitStmt2R(INT_TO_LONG,2,2);
                code.visitStmt3R(CMP_LONG,2,10,2);
                code.visitJumpStmt(IF_GEZ,2,-1,L9);
                code.visitLabel(L6);
                code.visitStmt2R(LONG_TO_INT,2,10);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8,0,4,2},new Method("Ljava/io/Reader;","read",new String[]{ "[C","I","I"},"I"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitLabel(L7);
                code.visitJumpStmt(IF_NE,1,5,L11);
                code.visitLabel(L8);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L9);
                code.visitFieldStmt(SGET,2,-1,new Field("Lorg/mortbay/util/IO;","bufferSize","I"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8,0,4,2},new Method("Ljava/io/Reader;","read",new String[]{ "[C","I","I"},"I"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitLabel(L10);
                code.visitJumpStmt(GOTO,-1,-1,L7);
                code.visitLabel(L11);
                code.visitStmt2R(INT_TO_LONG,2,1);
                code.visitStmt2R(SUB_LONG_2ADDR,10,2);
                code.visitLabel(L12);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9,0,4,1},new Method("Ljava/io/Writer;","write",new String[]{ "[C","I","I"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L4);
                code.visitLabel(L13);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9,0,4,1},new Method("Ljava/io/Writer;","write",new String[]{ "[C","I","I"},"V"));
                code.visitLabel(L14);
                code.visitFieldStmt(SGET,2,-1,new Field("Lorg/mortbay/util/IO;","bufferSize","I"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8,0,4,2},new Method("Ljava/io/Reader;","read",new String[]{ "[C","I","I"},"I"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitLabel(L15);
                code.visitJumpStmt(IF_NE,1,5,L13);
                code.visitJumpStmt(GOTO,-1,-1,L8);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m009_copyDir(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Lorg/mortbay/util/IO;","copyDir",new String[]{ "Ljava/io/File;","Ljava/io/File;"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(7);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"from");
                ddv.visitParameterName(1,"to");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(266,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(268,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(269,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(272,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(274,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(275,L5);
                ddv.visitStartLocal(0,L5,"files","[Ljava/io/File;",null);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(277,L6);
                DexLabel L7=new DexLabel();
                ddv.visitStartLocal(1,L7,"i","I",null);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(279,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(280,L9);
                ddv.visitStartLocal(2,L9,"name","Ljava/lang/String;",null);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(277,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(282,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(285,L12);
                ddv.visitEndLocal(1,L12);
                ddv.visitEndLocal(2,L12);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Ljava/io/File;","exists",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitJumpStmt(IF_EQZ,3,-1,L3);
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Ljava/io/File;","isDirectory",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitJumpStmt(IF_NEZ,3,-1,L4);
                code.visitLabel(L2);
                code.visitTypeStmt(NEW_INSTANCE,3,-1,"Ljava/lang/IllegalArgumentException;");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Ljava/io/File;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 3,4},new Method("Ljava/lang/IllegalArgumentException;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitStmt1R(THROW,3);
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Ljava/io/File;","mkdirs",new String[]{ },"Z"));
                code.visitLabel(L4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Ljava/io/File;","listFiles",new String[]{ },"[Ljava/io/File;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L5);
                code.visitJumpStmt(IF_EQZ,0,-1,L12);
                code.visitLabel(L6);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L7);
                code.visitStmt2R(ARRAY_LENGTH,3,0);
                code.visitJumpStmt(IF_GE,1,3,L12);
                code.visitLabel(L8);
                code.visitStmt3R(AGET_OBJECT,3,0,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Ljava/io/File;","getName",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitLabel(L9);
                code.visitConstStmt(CONST_STRING,3,".");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,2},new Method("Ljava/lang/String;","equals",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitJumpStmt(IF_NEZ,3,-1,L10);
                code.visitConstStmt(CONST_STRING,3,"..");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,2},new Method("Ljava/lang/String;","equals",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitJumpStmt(IF_EQZ,3,-1,L11);
                code.visitLabel(L10);
                code.visitStmt2R1N(ADD_INT_LIT8,1,1,1);
                code.visitJumpStmt(GOTO,-1,-1,L7);
                code.visitLabel(L11);
                code.visitStmt3R(AGET_OBJECT,3,0,1);
                code.visitTypeStmt(NEW_INSTANCE,4,-1,"Ljava/io/File;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 4,6,2},new Method("Ljava/io/File;","<init>",new String[]{ "Ljava/io/File;","Ljava/lang/String;"},"V"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 3,4},new Method("Lorg/mortbay/util/IO;","copy",new String[]{ "Ljava/io/File;","Ljava/io/File;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L10);
                code.visitLabel(L12);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m010_copyFile(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Lorg/mortbay/util/IO;","copyFile",new String[]{ "Ljava/io/File;","Ljava/io/File;"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"from");
                ddv.visitParameterName(1,"to");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(290,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(291,L1);
                ddv.visitStartLocal(0,L1,"in","Ljava/io/FileInputStream;",null);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(292,L2);
                ddv.visitStartLocal(1,L2,"out","Ljava/io/FileOutputStream;",null);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(293,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(294,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(295,L5);
                code.visitLabel(L0);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/io/FileInputStream;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,2},new Method("Ljava/io/FileInputStream;","<init>",new String[]{ "Ljava/io/File;"},"V"));
                code.visitLabel(L1);
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Ljava/io/FileOutputStream;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1,3},new Method("Ljava/io/FileOutputStream;","<init>",new String[]{ "Ljava/io/File;"},"V"));
                code.visitLabel(L2);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0,1},new Method("Lorg/mortbay/util/IO;","copy",new String[]{ "Ljava/io/InputStream;","Ljava/io/OutputStream;"},"V"));
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/io/FileInputStream;","close",new String[]{ },"V"));
                code.visitLabel(L4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/io/FileOutputStream;","close",new String[]{ },"V"));
                code.visitLabel(L5);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m011_copyThread(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Lorg/mortbay/util/IO;","copyThread",new String[]{ "Ljava/io/InputStream;","Ljava/io/OutputStream;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ "Ljava/lang/Exception;"});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"in");
                ddv.visitParameterName(1,"out");
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(125,L0);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(126,L3);
                ddv.visitStartLocal(1,L3,"job","Lorg/mortbay/util/IO$Job;",null);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(127,L4);
                ddv.visitLineNumber(133,L1);
                ddv.visitEndLocal(1,L1);
                ddv.visitLineNumber(129,L2);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(131,L5);
                ddv.visitStartLocal(0,L5,"e","Ljava/lang/Exception;",null);
                code.visitLabel(L0);
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Lorg/mortbay/util/IO$Job;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1,3,4},new Method("Lorg/mortbay/util/IO$Job;","<init>",new String[]{ "Ljava/io/InputStream;","Ljava/io/OutputStream;"},"V"));
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Lorg/mortbay/util/IO;","instance",new String[]{ },"Lorg/mortbay/util/IO;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,1},new Method("Lorg/mortbay/util/IO;","dispatch",new String[]{ "Ljava/lang/Runnable;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitJumpStmt(IF_NEZ,2,-1,L1);
                code.visitLabel(L4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Lorg/mortbay/util/IO$Job;","run",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,2);
                code.visitStmt2R(MOVE_OBJECT,0,2);
                code.visitLabel(L5);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0},new Method("Lorg/mortbay/log/Log;","warn",new String[]{ "Ljava/lang/Throwable;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L1);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m012_copyThread(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Lorg/mortbay/util/IO;","copyThread",new String[]{ "Ljava/io/Reader;","Ljava/io/Writer;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ "Ljava/lang/Exception;"});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"in");
                ddv.visitParameterName(1,"out");
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(152,L0);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(153,L3);
                ddv.visitStartLocal(1,L3,"job","Lorg/mortbay/util/IO$Job;",null);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(154,L4);
                ddv.visitLineNumber(160,L1);
                ddv.visitEndLocal(1,L1);
                ddv.visitLineNumber(156,L2);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(158,L5);
                ddv.visitStartLocal(0,L5,"e","Ljava/lang/Exception;",null);
                code.visitLabel(L0);
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Lorg/mortbay/util/IO$Job;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1,3,4},new Method("Lorg/mortbay/util/IO$Job;","<init>",new String[]{ "Ljava/io/Reader;","Ljava/io/Writer;"},"V"));
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Lorg/mortbay/util/IO;","instance",new String[]{ },"Lorg/mortbay/util/IO;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,1},new Method("Lorg/mortbay/util/IO;","dispatch",new String[]{ "Ljava/lang/Runnable;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitJumpStmt(IF_NEZ,2,-1,L1);
                code.visitLabel(L4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Lorg/mortbay/util/IO$Job;","run",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,2);
                code.visitStmt2R(MOVE_OBJECT,0,2);
                code.visitLabel(L5);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0},new Method("Lorg/mortbay/log/Log;","warn",new String[]{ "Ljava/lang/Throwable;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L1);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m013_delete(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Lorg/mortbay/util/IO;","delete",new String[]{ "Ljava/io/File;"},"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"file");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(338,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(339,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(346,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(340,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(342,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(343,L5);
                ddv.visitStartLocal(0,L5,"files","[Ljava/io/File;",null);
                DexLabel L6=new DexLabel();
                ddv.visitStartLocal(1,L6,"i","I",null);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(344,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(343,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(346,L9);
                ddv.visitEndLocal(0,L9);
                ddv.visitEndLocal(1,L9);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Ljava/io/File;","exists",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitJumpStmt(IF_NEZ,2,-1,L3);
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L2);
                code.visitStmt1R(RETURN,2);
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Ljava/io/File;","isDirectory",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitJumpStmt(IF_EQZ,2,-1,L9);
                code.visitLabel(L4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Ljava/io/File;","listFiles",new String[]{ },"[Ljava/io/File;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L5);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L6);
                code.visitJumpStmt(IF_EQZ,0,-1,L9);
                code.visitStmt2R(ARRAY_LENGTH,2,0);
                code.visitJumpStmt(IF_GE,1,2,L9);
                code.visitLabel(L7);
                code.visitStmt3R(AGET_OBJECT,2,0,1);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 2},new Method("Lorg/mortbay/util/IO;","delete",new String[]{ "Ljava/io/File;"},"Z"));
                code.visitLabel(L8);
                code.visitStmt2R1N(ADD_INT_LIT8,1,1,1);
                code.visitJumpStmt(GOTO,-1,-1,L6);
                code.visitLabel(L9);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Ljava/io/File;","delete",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m014_getClosedStream(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Lorg/mortbay/util/IO;","getClosedStream",new String[]{ },"Ljava/io/InputStream;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(1);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(411,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(SGET_OBJECT,0,-1,new Field("Lorg/mortbay/util/IO;","__closedStream","Lorg/mortbay/util/IO$ClosedIS;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m015_getNullStream(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Lorg/mortbay/util/IO;","getNullStream",new String[]{ },"Ljava/io/OutputStream;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(1);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(402,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(SGET_OBJECT,0,-1,new Field("Lorg/mortbay/util/IO;","__nullStream","Lorg/mortbay/util/IO$NullOS;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m016_getNullWriter(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Lorg/mortbay/util/IO;","getNullWriter",new String[]{ },"Ljava/io/Writer;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(1);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(444,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(SGET_OBJECT,0,-1,new Field("Lorg/mortbay/util/IO;","__nullWriter","Lorg/mortbay/util/IO$NullWrite;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m017_instance(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Lorg/mortbay/util/IO;","instance",new String[]{ },"Lorg/mortbay/util/IO;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(1);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(63,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(SGET_OBJECT,0,-1,new Field("Lorg/mortbay/util/IO$Singleton;","__instance","Lorg/mortbay/util/IO;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m018_readBytes(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Lorg/mortbay/util/IO;","readBytes",new String[]{ "Ljava/io/InputStream;"},"[B"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"in");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(372,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(373,L1);
                ddv.visitStartLocal(0,L1,"bout","Ljava/io/ByteArrayOutputStream;",null);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(374,L2);
                code.visitLabel(L0);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/io/ByteArrayOutputStream;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/io/ByteArrayOutputStream;","<init>",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 2,0},new Method("Lorg/mortbay/util/IO;","copy",new String[]{ "Ljava/io/InputStream;","Ljava/io/OutputStream;"},"V"));
                code.visitLabel(L2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/io/ByteArrayOutputStream;","toByteArray",new String[]{ },"[B"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitStmt1R(RETURN_OBJECT,1);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m019_toString(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Lorg/mortbay/util/IO;","toString",new String[]{ "Ljava/io/InputStream;"},"Ljava/lang/String;"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"in");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(303,L0);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1,0},new Method("Lorg/mortbay/util/IO;","toString",new String[]{ "Ljava/io/InputStream;","Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m020_toString(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Lorg/mortbay/util/IO;","toString",new String[]{ "Ljava/io/InputStream;","Ljava/lang/String;"},"Ljava/lang/String;"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"in");
                ddv.visitParameterName(1,"encoding");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(312,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(313,L1);
                ddv.visitStartLocal(1,L1,"writer","Ljava/io/StringWriter;",null);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(315,L2);
                ddv.visitStartLocal(0,L2,"reader","Ljava/io/InputStreamReader;",null);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(316,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(313,L4);
                ddv.visitEndLocal(0,L4);
                code.visitLabel(L0);
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Ljava/io/StringWriter;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1},new Method("Ljava/io/StringWriter;","<init>",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitJumpStmt(IF_NEZ,4,-1,L4);
                code.visitTypeStmt(NEW_INSTANCE,2,-1,"Ljava/io/InputStreamReader;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2,3},new Method("Ljava/io/InputStreamReader;","<init>",new String[]{ "Ljava/io/InputStream;"},"V"));
                code.visitStmt2R(MOVE_OBJECT,0,2);
                code.visitLabel(L2);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0,1},new Method("Lorg/mortbay/util/IO;","copy",new String[]{ "Ljava/io/Reader;","Ljava/io/Writer;"},"V"));
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/io/StringWriter;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitStmt1R(RETURN_OBJECT,2);
                code.visitLabel(L4);
                code.visitTypeStmt(NEW_INSTANCE,2,-1,"Ljava/io/InputStreamReader;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2,3,4},new Method("Ljava/io/InputStreamReader;","<init>",new String[]{ "Ljava/io/InputStream;","Ljava/lang/String;"},"V"));
                code.visitStmt2R(MOVE_OBJECT,0,2);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m021_toString(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Lorg/mortbay/util/IO;","toString",new String[]{ "Ljava/io/Reader;"},"Ljava/lang/String;"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"in");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(325,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(326,L1);
                ddv.visitStartLocal(0,L1,"writer","Ljava/io/StringWriter;",null);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(327,L2);
                code.visitLabel(L0);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/io/StringWriter;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/io/StringWriter;","<init>",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 2,0},new Method("Lorg/mortbay/util/IO;","copy",new String[]{ "Ljava/io/Reader;","Ljava/io/Writer;"},"V"));
                code.visitLabel(L2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/io/StringWriter;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitStmt1R(RETURN_OBJECT,1);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
