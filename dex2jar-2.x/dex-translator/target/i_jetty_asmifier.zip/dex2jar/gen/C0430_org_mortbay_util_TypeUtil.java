package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0430_org_mortbay_util_TypeUtil {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(ACC_PUBLIC,"Lorg/mortbay/util/TypeUtil;","Ljava/lang/Object;",new String[]{ });
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("TypeUtil.java");
        f000_CR(cv);
        f001_LF(cv);
        f002_class2Name(cv);
        f003_class2Value(cv);
        f004_intCacheSize(cv);
        f005_integerCache(cv);
        f006_integerStrCache(cv);
        f007_longCache(cv);
        f008_longCacheSize(cv);
        f009_minusOne(cv);
        f010_minusOneL(cv);
        f011_name2Class(cv);
        f012_stringArg(cv);
        m000__clinit_(cv);
        m001__init_(cv);
        m002_convertHexDigit(cv);
        m003_dump(cv);
        m004_dump(cv);
        m005_fromHexString(cv);
        m006_fromName(cv);
        m007_jarFor(cv);
        m008_newInteger(cv);
        m009_newLong(cv);
        m010_parseBytes(cv);
        m011_parseInt(cv);
        m012_parseInt(cv);
        m013_readLine(cv);
        m014_toHexString(cv);
        m015_toHexString(cv);
        m016_toName(cv);
        m017_toString(cv);
        m018_toString(cv);
        m019_toString(cv);
        m020_valueOf(cv);
        m021_valueOf(cv);
    }
    public static void f000_CR(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC, new Field("Lorg/mortbay/util/TypeUtil;","CR","I"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f001_LF(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC, new Field("Lorg/mortbay/util/TypeUtil;","LF","I"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f002_class2Name(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/util/TypeUtil;","class2Name","Ljava/util/HashMap;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f003_class2Value(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/util/TypeUtil;","class2Value","Ljava/util/HashMap;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f004_intCacheSize(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE|ACC_STATIC, new Field("Lorg/mortbay/util/TypeUtil;","intCacheSize","I"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f005_integerCache(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE|ACC_STATIC, new Field("Lorg/mortbay/util/TypeUtil;","integerCache","[Ljava/lang/Integer;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f006_integerStrCache(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE|ACC_STATIC, new Field("Lorg/mortbay/util/TypeUtil;","integerStrCache","[Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f007_longCache(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE|ACC_STATIC, new Field("Lorg/mortbay/util/TypeUtil;","longCache","[Ljava/lang/Long;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f008_longCacheSize(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE|ACC_STATIC, new Field("Lorg/mortbay/util/TypeUtil;","longCacheSize","I"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f009_minusOne(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE|ACC_STATIC, new Field("Lorg/mortbay/util/TypeUtil;","minusOne","Ljava/lang/Integer;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f010_minusOneL(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE|ACC_STATIC, new Field("Lorg/mortbay/util/TypeUtil;","minusOneL","Ljava/lang/Long;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f011_name2Class(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/util/TypeUtil;","name2Class","Ljava/util/HashMap;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f012_stringArg(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE|ACC_STATIC, new Field("Lorg/mortbay/util/TypeUtil;","stringArg","[Ljava/lang/Class;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void m000__clinit_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_STATIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/util/TypeUtil;","<clinit>",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(9);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ "Ljava/lang/Exception;"});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L3=new DexLabel();
                ddv.visitPrologue(L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(38,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(39,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(42,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(45,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(46,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(47,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(48,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(49,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(50,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(51,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(52,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(53,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(55,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(56,L17);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(57,L18);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(58,L19);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(59,L20);
                DexLabel L21=new DexLabel();
                ddv.visitLineNumber(60,L21);
                DexLabel L22=new DexLabel();
                ddv.visitLineNumber(61,L22);
                DexLabel L23=new DexLabel();
                ddv.visitLineNumber(62,L23);
                DexLabel L24=new DexLabel();
                ddv.visitLineNumber(63,L24);
                DexLabel L25=new DexLabel();
                ddv.visitLineNumber(65,L25);
                DexLabel L26=new DexLabel();
                ddv.visitLineNumber(66,L26);
                DexLabel L27=new DexLabel();
                ddv.visitLineNumber(67,L27);
                DexLabel L28=new DexLabel();
                ddv.visitLineNumber(68,L28);
                DexLabel L29=new DexLabel();
                ddv.visitLineNumber(69,L29);
                DexLabel L30=new DexLabel();
                ddv.visitLineNumber(70,L30);
                DexLabel L31=new DexLabel();
                ddv.visitLineNumber(71,L31);
                DexLabel L32=new DexLabel();
                ddv.visitLineNumber(72,L32);
                DexLabel L33=new DexLabel();
                ddv.visitLineNumber(74,L33);
                DexLabel L34=new DexLabel();
                ddv.visitLineNumber(75,L34);
                DexLabel L35=new DexLabel();
                ddv.visitLineNumber(76,L35);
                DexLabel L36=new DexLabel();
                ddv.visitLineNumber(77,L36);
                DexLabel L37=new DexLabel();
                ddv.visitLineNumber(78,L37);
                DexLabel L38=new DexLabel();
                ddv.visitLineNumber(79,L38);
                DexLabel L39=new DexLabel();
                ddv.visitLineNumber(80,L39);
                DexLabel L40=new DexLabel();
                ddv.visitLineNumber(81,L40);
                DexLabel L41=new DexLabel();
                ddv.visitLineNumber(83,L41);
                DexLabel L42=new DexLabel();
                ddv.visitLineNumber(84,L42);
                DexLabel L43=new DexLabel();
                ddv.visitLineNumber(85,L43);
                DexLabel L44=new DexLabel();
                ddv.visitLineNumber(86,L44);
                DexLabel L45=new DexLabel();
                ddv.visitLineNumber(90,L45);
                DexLabel L46=new DexLabel();
                ddv.visitLineNumber(93,L46);
                DexLabel L47=new DexLabel();
                ddv.visitLineNumber(94,L47);
                DexLabel L48=new DexLabel();
                ddv.visitLineNumber(95,L48);
                DexLabel L49=new DexLabel();
                ddv.visitLineNumber(96,L49);
                DexLabel L50=new DexLabel();
                ddv.visitLineNumber(97,L50);
                DexLabel L51=new DexLabel();
                ddv.visitLineNumber(98,L51);
                DexLabel L52=new DexLabel();
                ddv.visitLineNumber(99,L52);
                DexLabel L53=new DexLabel();
                ddv.visitLineNumber(100,L53);
                DexLabel L54=new DexLabel();
                ddv.visitLineNumber(101,L54);
                DexLabel L55=new DexLabel();
                ddv.visitLineNumber(103,L55);
                DexLabel L56=new DexLabel();
                ddv.visitLineNumber(104,L56);
                DexLabel L57=new DexLabel();
                ddv.visitLineNumber(105,L57);
                DexLabel L58=new DexLabel();
                ddv.visitLineNumber(106,L58);
                DexLabel L59=new DexLabel();
                ddv.visitLineNumber(107,L59);
                DexLabel L60=new DexLabel();
                ddv.visitLineNumber(108,L60);
                DexLabel L61=new DexLabel();
                ddv.visitLineNumber(109,L61);
                DexLabel L62=new DexLabel();
                ddv.visitLineNumber(110,L62);
                DexLabel L63=new DexLabel();
                ddv.visitLineNumber(112,L63);
                DexLabel L64=new DexLabel();
                ddv.visitLineNumber(113,L64);
                DexLabel L65=new DexLabel();
                ddv.visitLineNumber(117,L65);
                DexLabel L66=new DexLabel();
                ddv.visitLineNumber(122,L66);
                DexLabel L67=new DexLabel();
                ddv.visitLineNumber(124,L67);
                ddv.visitStartLocal(1,L67,"s","[Ljava/lang/Class;",null);
                DexLabel L68=new DexLabel();
                ddv.visitLineNumber(126,L68);
                DexLabel L69=new DexLabel();
                ddv.visitLineNumber(128,L69);
                DexLabel L70=new DexLabel();
                ddv.visitLineNumber(130,L70);
                DexLabel L71=new DexLabel();
                ddv.visitLineNumber(132,L71);
                DexLabel L72=new DexLabel();
                ddv.visitLineNumber(134,L72);
                DexLabel L73=new DexLabel();
                ddv.visitLineNumber(136,L73);
                DexLabel L74=new DexLabel();
                ddv.visitLineNumber(139,L74);
                DexLabel L75=new DexLabel();
                ddv.visitLineNumber(141,L75);
                DexLabel L76=new DexLabel();
                ddv.visitLineNumber(143,L76);
                DexLabel L77=new DexLabel();
                ddv.visitLineNumber(145,L77);
                DexLabel L78=new DexLabel();
                ddv.visitLineNumber(147,L78);
                DexLabel L79=new DexLabel();
                ddv.visitLineNumber(149,L79);
                DexLabel L80=new DexLabel();
                ddv.visitLineNumber(151,L80);
                ddv.visitLineNumber(161,L1);
                ddv.visitEndLocal(1,L1);
                DexLabel L81=new DexLabel();
                ddv.visitLineNumber(164,L81);
                DexLabel L82=new DexLabel();
                ddv.visitLineNumber(166,L82);
                DexLabel L83=new DexLabel();
                ddv.visitLineNumber(167,L83);
                DexLabel L84=new DexLabel();
                ddv.visitLineNumber(168,L84);
                DexLabel L85=new DexLabel();
                ddv.visitLineNumber(169,L85);
                DexLabel L86=new DexLabel();
                ddv.visitLineNumber(171,L86);
                DexLabel L87=new DexLabel();
                ddv.visitLineNumber(172,L87);
                ddv.visitLineNumber(154,L2);
                DexLabel L88=new DexLabel();
                ddv.visitLineNumber(156,L88);
                ddv.visitStartLocal(0,L88,"e","Ljava/lang/Exception;",null);
                code.visitLabel(L3);
                code.visitConstStmt(CONST_CLASS,8,new DexType("Ljava/lang/Float;"));
                code.visitConstStmt(CONST_CLASS,7,new DexType("Ljava/lang/Double;"));
                code.visitConstStmt(CONST_CLASS,6,new DexType("Ljava/lang/Byte;"));
                code.visitConstStmt(CONST_CLASS,5,new DexType("Ljava/lang/Boolean;"));
                code.visitConstStmt(CONST_STRING,2,"valueOf");
                code.visitLabel(L4);
                code.visitConstStmt(CONST_16,2, Integer.valueOf(13)); // int: 0x0000000d  float:0.000000
                code.visitFieldStmt(SPUT,2,-1,new Field("Lorg/mortbay/util/TypeUtil;","CR","I"));
                code.visitLabel(L5);
                code.visitConstStmt(CONST_16,2, Integer.valueOf(10)); // int: 0x0000000a  float:0.000000
                code.visitFieldStmt(SPUT,2,-1,new Field("Lorg/mortbay/util/TypeUtil;","LF","I"));
                code.visitLabel(L6);
                code.visitTypeStmt(NEW_INSTANCE,2,-1,"Ljava/util/HashMap;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2},new Method("Ljava/util/HashMap;","<init>",new String[]{ },"V"));
                code.visitFieldStmt(SPUT_OBJECT,2,-1,new Field("Lorg/mortbay/util/TypeUtil;","name2Class","Ljava/util/HashMap;"));
                code.visitLabel(L7);
                code.visitFieldStmt(SGET_OBJECT,2,-1,new Field("Lorg/mortbay/util/TypeUtil;","name2Class","Ljava/util/HashMap;"));
                code.visitConstStmt(CONST_STRING,3,"boolean");
                code.visitFieldStmt(SGET_OBJECT,4,-1,new Field("Ljava/lang/Boolean;","TYPE","Ljava/lang/Class;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3,4},new Method("Ljava/util/HashMap;","put",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitLabel(L8);
                code.visitFieldStmt(SGET_OBJECT,2,-1,new Field("Lorg/mortbay/util/TypeUtil;","name2Class","Ljava/util/HashMap;"));
                code.visitConstStmt(CONST_STRING,3,"byte");
                code.visitFieldStmt(SGET_OBJECT,4,-1,new Field("Ljava/lang/Byte;","TYPE","Ljava/lang/Class;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3,4},new Method("Ljava/util/HashMap;","put",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitLabel(L9);
                code.visitFieldStmt(SGET_OBJECT,2,-1,new Field("Lorg/mortbay/util/TypeUtil;","name2Class","Ljava/util/HashMap;"));
                code.visitConstStmt(CONST_STRING,3,"char");
                code.visitFieldStmt(SGET_OBJECT,4,-1,new Field("Ljava/lang/Character;","TYPE","Ljava/lang/Class;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3,4},new Method("Ljava/util/HashMap;","put",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitLabel(L10);
                code.visitFieldStmt(SGET_OBJECT,2,-1,new Field("Lorg/mortbay/util/TypeUtil;","name2Class","Ljava/util/HashMap;"));
                code.visitConstStmt(CONST_STRING,3,"double");
                code.visitFieldStmt(SGET_OBJECT,4,-1,new Field("Ljava/lang/Double;","TYPE","Ljava/lang/Class;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3,4},new Method("Ljava/util/HashMap;","put",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitLabel(L11);
                code.visitFieldStmt(SGET_OBJECT,2,-1,new Field("Lorg/mortbay/util/TypeUtil;","name2Class","Ljava/util/HashMap;"));
                code.visitConstStmt(CONST_STRING,3,"float");
                code.visitFieldStmt(SGET_OBJECT,4,-1,new Field("Ljava/lang/Float;","TYPE","Ljava/lang/Class;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3,4},new Method("Ljava/util/HashMap;","put",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitLabel(L12);
                code.visitFieldStmt(SGET_OBJECT,2,-1,new Field("Lorg/mortbay/util/TypeUtil;","name2Class","Ljava/util/HashMap;"));
                code.visitConstStmt(CONST_STRING,3,"int");
                code.visitFieldStmt(SGET_OBJECT,4,-1,new Field("Ljava/lang/Integer;","TYPE","Ljava/lang/Class;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3,4},new Method("Ljava/util/HashMap;","put",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitLabel(L13);
                code.visitFieldStmt(SGET_OBJECT,2,-1,new Field("Lorg/mortbay/util/TypeUtil;","name2Class","Ljava/util/HashMap;"));
                code.visitConstStmt(CONST_STRING,3,"long");
                code.visitFieldStmt(SGET_OBJECT,4,-1,new Field("Ljava/lang/Long;","TYPE","Ljava/lang/Class;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3,4},new Method("Ljava/util/HashMap;","put",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitLabel(L14);
                code.visitFieldStmt(SGET_OBJECT,2,-1,new Field("Lorg/mortbay/util/TypeUtil;","name2Class","Ljava/util/HashMap;"));
                code.visitConstStmt(CONST_STRING,3,"short");
                code.visitFieldStmt(SGET_OBJECT,4,-1,new Field("Ljava/lang/Short;","TYPE","Ljava/lang/Class;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3,4},new Method("Ljava/util/HashMap;","put",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitLabel(L15);
                code.visitFieldStmt(SGET_OBJECT,2,-1,new Field("Lorg/mortbay/util/TypeUtil;","name2Class","Ljava/util/HashMap;"));
                code.visitConstStmt(CONST_STRING,3,"void");
                code.visitFieldStmt(SGET_OBJECT,4,-1,new Field("Ljava/lang/Void;","TYPE","Ljava/lang/Class;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3,4},new Method("Ljava/util/HashMap;","put",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitLabel(L16);
                code.visitFieldStmt(SGET_OBJECT,2,-1,new Field("Lorg/mortbay/util/TypeUtil;","name2Class","Ljava/util/HashMap;"));
                code.visitConstStmt(CONST_STRING,3,"java.lang.Boolean.TYPE");
                code.visitFieldStmt(SGET_OBJECT,4,-1,new Field("Ljava/lang/Boolean;","TYPE","Ljava/lang/Class;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3,4},new Method("Ljava/util/HashMap;","put",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitLabel(L17);
                code.visitFieldStmt(SGET_OBJECT,2,-1,new Field("Lorg/mortbay/util/TypeUtil;","name2Class","Ljava/util/HashMap;"));
                code.visitConstStmt(CONST_STRING,3,"java.lang.Byte.TYPE");
                code.visitFieldStmt(SGET_OBJECT,4,-1,new Field("Ljava/lang/Byte;","TYPE","Ljava/lang/Class;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3,4},new Method("Ljava/util/HashMap;","put",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitLabel(L18);
                code.visitFieldStmt(SGET_OBJECT,2,-1,new Field("Lorg/mortbay/util/TypeUtil;","name2Class","Ljava/util/HashMap;"));
                code.visitConstStmt(CONST_STRING,3,"java.lang.Character.TYPE");
                code.visitFieldStmt(SGET_OBJECT,4,-1,new Field("Ljava/lang/Character;","TYPE","Ljava/lang/Class;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3,4},new Method("Ljava/util/HashMap;","put",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitLabel(L19);
                code.visitFieldStmt(SGET_OBJECT,2,-1,new Field("Lorg/mortbay/util/TypeUtil;","name2Class","Ljava/util/HashMap;"));
                code.visitConstStmt(CONST_STRING,3,"java.lang.Double.TYPE");
                code.visitFieldStmt(SGET_OBJECT,4,-1,new Field("Ljava/lang/Double;","TYPE","Ljava/lang/Class;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3,4},new Method("Ljava/util/HashMap;","put",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitLabel(L20);
                code.visitFieldStmt(SGET_OBJECT,2,-1,new Field("Lorg/mortbay/util/TypeUtil;","name2Class","Ljava/util/HashMap;"));
                code.visitConstStmt(CONST_STRING,3,"java.lang.Float.TYPE");
                code.visitFieldStmt(SGET_OBJECT,4,-1,new Field("Ljava/lang/Float;","TYPE","Ljava/lang/Class;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3,4},new Method("Ljava/util/HashMap;","put",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitLabel(L21);
                code.visitFieldStmt(SGET_OBJECT,2,-1,new Field("Lorg/mortbay/util/TypeUtil;","name2Class","Ljava/util/HashMap;"));
                code.visitConstStmt(CONST_STRING,3,"java.lang.Integer.TYPE");
                code.visitFieldStmt(SGET_OBJECT,4,-1,new Field("Ljava/lang/Integer;","TYPE","Ljava/lang/Class;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3,4},new Method("Ljava/util/HashMap;","put",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitLabel(L22);
                code.visitFieldStmt(SGET_OBJECT,2,-1,new Field("Lorg/mortbay/util/TypeUtil;","name2Class","Ljava/util/HashMap;"));
                code.visitConstStmt(CONST_STRING,3,"java.lang.Long.TYPE");
                code.visitFieldStmt(SGET_OBJECT,4,-1,new Field("Ljava/lang/Long;","TYPE","Ljava/lang/Class;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3,4},new Method("Ljava/util/HashMap;","put",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitLabel(L23);
                code.visitFieldStmt(SGET_OBJECT,2,-1,new Field("Lorg/mortbay/util/TypeUtil;","name2Class","Ljava/util/HashMap;"));
                code.visitConstStmt(CONST_STRING,3,"java.lang.Short.TYPE");
                code.visitFieldStmt(SGET_OBJECT,4,-1,new Field("Ljava/lang/Short;","TYPE","Ljava/lang/Class;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3,4},new Method("Ljava/util/HashMap;","put",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitLabel(L24);
                code.visitFieldStmt(SGET_OBJECT,2,-1,new Field("Lorg/mortbay/util/TypeUtil;","name2Class","Ljava/util/HashMap;"));
                code.visitConstStmt(CONST_STRING,3,"java.lang.Void.TYPE");
                code.visitFieldStmt(SGET_OBJECT,4,-1,new Field("Ljava/lang/Void;","TYPE","Ljava/lang/Class;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3,4},new Method("Ljava/util/HashMap;","put",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitLabel(L25);
                code.visitFieldStmt(SGET_OBJECT,2,-1,new Field("Lorg/mortbay/util/TypeUtil;","name2Class","Ljava/util/HashMap;"));
                code.visitConstStmt(CONST_STRING,3,"java.lang.Boolean");
                code.visitConstStmt(CONST_CLASS,4,new DexType("Ljava/lang/Boolean;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3,5},new Method("Ljava/util/HashMap;","put",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitLabel(L26);
                code.visitFieldStmt(SGET_OBJECT,2,-1,new Field("Lorg/mortbay/util/TypeUtil;","name2Class","Ljava/util/HashMap;"));
                code.visitConstStmt(CONST_STRING,3,"java.lang.Byte");
                code.visitConstStmt(CONST_CLASS,4,new DexType("Ljava/lang/Byte;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3,6},new Method("Ljava/util/HashMap;","put",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitLabel(L27);
                code.visitFieldStmt(SGET_OBJECT,2,-1,new Field("Lorg/mortbay/util/TypeUtil;","name2Class","Ljava/util/HashMap;"));
                code.visitConstStmt(CONST_STRING,3,"java.lang.Character");
                code.visitConstStmt(CONST_CLASS,4,new DexType("Ljava/lang/Character;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3,4},new Method("Ljava/util/HashMap;","put",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitLabel(L28);
                code.visitFieldStmt(SGET_OBJECT,2,-1,new Field("Lorg/mortbay/util/TypeUtil;","name2Class","Ljava/util/HashMap;"));
                code.visitConstStmt(CONST_STRING,3,"java.lang.Double");
                code.visitConstStmt(CONST_CLASS,4,new DexType("Ljava/lang/Double;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3,7},new Method("Ljava/util/HashMap;","put",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitLabel(L29);
                code.visitFieldStmt(SGET_OBJECT,2,-1,new Field("Lorg/mortbay/util/TypeUtil;","name2Class","Ljava/util/HashMap;"));
                code.visitConstStmt(CONST_STRING,3,"java.lang.Float");
                code.visitConstStmt(CONST_CLASS,4,new DexType("Ljava/lang/Float;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3,8},new Method("Ljava/util/HashMap;","put",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitLabel(L30);
                code.visitFieldStmt(SGET_OBJECT,2,-1,new Field("Lorg/mortbay/util/TypeUtil;","name2Class","Ljava/util/HashMap;"));
                code.visitConstStmt(CONST_STRING,3,"java.lang.Integer");
                code.visitConstStmt(CONST_CLASS,4,new DexType("Ljava/lang/Integer;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3,4},new Method("Ljava/util/HashMap;","put",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitLabel(L31);
                code.visitFieldStmt(SGET_OBJECT,2,-1,new Field("Lorg/mortbay/util/TypeUtil;","name2Class","Ljava/util/HashMap;"));
                code.visitConstStmt(CONST_STRING,3,"java.lang.Long");
                code.visitConstStmt(CONST_CLASS,4,new DexType("Ljava/lang/Long;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3,4},new Method("Ljava/util/HashMap;","put",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitLabel(L32);
                code.visitFieldStmt(SGET_OBJECT,2,-1,new Field("Lorg/mortbay/util/TypeUtil;","name2Class","Ljava/util/HashMap;"));
                code.visitConstStmt(CONST_STRING,3,"java.lang.Short");
                code.visitConstStmt(CONST_CLASS,4,new DexType("Ljava/lang/Short;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3,4},new Method("Ljava/util/HashMap;","put",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitLabel(L33);
                code.visitFieldStmt(SGET_OBJECT,2,-1,new Field("Lorg/mortbay/util/TypeUtil;","name2Class","Ljava/util/HashMap;"));
                code.visitConstStmt(CONST_STRING,3,"Boolean");
                code.visitConstStmt(CONST_CLASS,4,new DexType("Ljava/lang/Boolean;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3,5},new Method("Ljava/util/HashMap;","put",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitLabel(L34);
                code.visitFieldStmt(SGET_OBJECT,2,-1,new Field("Lorg/mortbay/util/TypeUtil;","name2Class","Ljava/util/HashMap;"));
                code.visitConstStmt(CONST_STRING,3,"Byte");
                code.visitConstStmt(CONST_CLASS,4,new DexType("Ljava/lang/Byte;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3,6},new Method("Ljava/util/HashMap;","put",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitLabel(L35);
                code.visitFieldStmt(SGET_OBJECT,2,-1,new Field("Lorg/mortbay/util/TypeUtil;","name2Class","Ljava/util/HashMap;"));
                code.visitConstStmt(CONST_STRING,3,"Character");
                code.visitConstStmt(CONST_CLASS,4,new DexType("Ljava/lang/Character;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3,4},new Method("Ljava/util/HashMap;","put",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitLabel(L36);
                code.visitFieldStmt(SGET_OBJECT,2,-1,new Field("Lorg/mortbay/util/TypeUtil;","name2Class","Ljava/util/HashMap;"));
                code.visitConstStmt(CONST_STRING,3,"Double");
                code.visitConstStmt(CONST_CLASS,4,new DexType("Ljava/lang/Double;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3,7},new Method("Ljava/util/HashMap;","put",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitLabel(L37);
                code.visitFieldStmt(SGET_OBJECT,2,-1,new Field("Lorg/mortbay/util/TypeUtil;","name2Class","Ljava/util/HashMap;"));
                code.visitConstStmt(CONST_STRING,3,"Float");
                code.visitConstStmt(CONST_CLASS,4,new DexType("Ljava/lang/Float;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3,8},new Method("Ljava/util/HashMap;","put",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitLabel(L38);
                code.visitFieldStmt(SGET_OBJECT,2,-1,new Field("Lorg/mortbay/util/TypeUtil;","name2Class","Ljava/util/HashMap;"));
                code.visitConstStmt(CONST_STRING,3,"Integer");
                code.visitConstStmt(CONST_CLASS,4,new DexType("Ljava/lang/Integer;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3,4},new Method("Ljava/util/HashMap;","put",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitLabel(L39);
                code.visitFieldStmt(SGET_OBJECT,2,-1,new Field("Lorg/mortbay/util/TypeUtil;","name2Class","Ljava/util/HashMap;"));
                code.visitConstStmt(CONST_STRING,3,"Long");
                code.visitConstStmt(CONST_CLASS,4,new DexType("Ljava/lang/Long;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3,4},new Method("Ljava/util/HashMap;","put",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitLabel(L40);
                code.visitFieldStmt(SGET_OBJECT,2,-1,new Field("Lorg/mortbay/util/TypeUtil;","name2Class","Ljava/util/HashMap;"));
                code.visitConstStmt(CONST_STRING,3,"Short");
                code.visitConstStmt(CONST_CLASS,4,new DexType("Ljava/lang/Short;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3,4},new Method("Ljava/util/HashMap;","put",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitLabel(L41);
                code.visitFieldStmt(SGET_OBJECT,2,-1,new Field("Lorg/mortbay/util/TypeUtil;","name2Class","Ljava/util/HashMap;"));
                code.visitConstStmt(CONST_4,3, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(SGET_OBJECT,4,-1,new Field("Ljava/lang/Void;","TYPE","Ljava/lang/Class;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3,4},new Method("Ljava/util/HashMap;","put",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitLabel(L42);
                code.visitFieldStmt(SGET_OBJECT,2,-1,new Field("Lorg/mortbay/util/TypeUtil;","name2Class","Ljava/util/HashMap;"));
                code.visitConstStmt(CONST_STRING,3,"string");
                code.visitConstStmt(CONST_CLASS,4,new DexType("Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3,4},new Method("Ljava/util/HashMap;","put",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitLabel(L43);
                code.visitFieldStmt(SGET_OBJECT,2,-1,new Field("Lorg/mortbay/util/TypeUtil;","name2Class","Ljava/util/HashMap;"));
                code.visitConstStmt(CONST_STRING,3,"String");
                code.visitConstStmt(CONST_CLASS,4,new DexType("Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3,4},new Method("Ljava/util/HashMap;","put",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitLabel(L44);
                code.visitFieldStmt(SGET_OBJECT,2,-1,new Field("Lorg/mortbay/util/TypeUtil;","name2Class","Ljava/util/HashMap;"));
                code.visitConstStmt(CONST_STRING,3,"java.lang.String");
                code.visitConstStmt(CONST_CLASS,4,new DexType("Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3,4},new Method("Ljava/util/HashMap;","put",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitLabel(L45);
                code.visitTypeStmt(NEW_INSTANCE,2,-1,"Ljava/util/HashMap;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2},new Method("Ljava/util/HashMap;","<init>",new String[]{ },"V"));
                code.visitFieldStmt(SPUT_OBJECT,2,-1,new Field("Lorg/mortbay/util/TypeUtil;","class2Name","Ljava/util/HashMap;"));
                code.visitLabel(L46);
                code.visitFieldStmt(SGET_OBJECT,2,-1,new Field("Lorg/mortbay/util/TypeUtil;","class2Name","Ljava/util/HashMap;"));
                code.visitFieldStmt(SGET_OBJECT,3,-1,new Field("Ljava/lang/Boolean;","TYPE","Ljava/lang/Class;"));
                code.visitConstStmt(CONST_STRING,4,"boolean");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3,4},new Method("Ljava/util/HashMap;","put",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitLabel(L47);
                code.visitFieldStmt(SGET_OBJECT,2,-1,new Field("Lorg/mortbay/util/TypeUtil;","class2Name","Ljava/util/HashMap;"));
                code.visitFieldStmt(SGET_OBJECT,3,-1,new Field("Ljava/lang/Byte;","TYPE","Ljava/lang/Class;"));
                code.visitConstStmt(CONST_STRING,4,"byte");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3,4},new Method("Ljava/util/HashMap;","put",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitLabel(L48);
                code.visitFieldStmt(SGET_OBJECT,2,-1,new Field("Lorg/mortbay/util/TypeUtil;","class2Name","Ljava/util/HashMap;"));
                code.visitFieldStmt(SGET_OBJECT,3,-1,new Field("Ljava/lang/Character;","TYPE","Ljava/lang/Class;"));
                code.visitConstStmt(CONST_STRING,4,"char");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3,4},new Method("Ljava/util/HashMap;","put",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitLabel(L49);
                code.visitFieldStmt(SGET_OBJECT,2,-1,new Field("Lorg/mortbay/util/TypeUtil;","class2Name","Ljava/util/HashMap;"));
                code.visitFieldStmt(SGET_OBJECT,3,-1,new Field("Ljava/lang/Double;","TYPE","Ljava/lang/Class;"));
                code.visitConstStmt(CONST_STRING,4,"double");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3,4},new Method("Ljava/util/HashMap;","put",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitLabel(L50);
                code.visitFieldStmt(SGET_OBJECT,2,-1,new Field("Lorg/mortbay/util/TypeUtil;","class2Name","Ljava/util/HashMap;"));
                code.visitFieldStmt(SGET_OBJECT,3,-1,new Field("Ljava/lang/Float;","TYPE","Ljava/lang/Class;"));
                code.visitConstStmt(CONST_STRING,4,"float");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3,4},new Method("Ljava/util/HashMap;","put",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitLabel(L51);
                code.visitFieldStmt(SGET_OBJECT,2,-1,new Field("Lorg/mortbay/util/TypeUtil;","class2Name","Ljava/util/HashMap;"));
                code.visitFieldStmt(SGET_OBJECT,3,-1,new Field("Ljava/lang/Integer;","TYPE","Ljava/lang/Class;"));
                code.visitConstStmt(CONST_STRING,4,"int");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3,4},new Method("Ljava/util/HashMap;","put",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitLabel(L52);
                code.visitFieldStmt(SGET_OBJECT,2,-1,new Field("Lorg/mortbay/util/TypeUtil;","class2Name","Ljava/util/HashMap;"));
                code.visitFieldStmt(SGET_OBJECT,3,-1,new Field("Ljava/lang/Long;","TYPE","Ljava/lang/Class;"));
                code.visitConstStmt(CONST_STRING,4,"long");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3,4},new Method("Ljava/util/HashMap;","put",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitLabel(L53);
                code.visitFieldStmt(SGET_OBJECT,2,-1,new Field("Lorg/mortbay/util/TypeUtil;","class2Name","Ljava/util/HashMap;"));
                code.visitFieldStmt(SGET_OBJECT,3,-1,new Field("Ljava/lang/Short;","TYPE","Ljava/lang/Class;"));
                code.visitConstStmt(CONST_STRING,4,"short");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3,4},new Method("Ljava/util/HashMap;","put",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitLabel(L54);
                code.visitFieldStmt(SGET_OBJECT,2,-1,new Field("Lorg/mortbay/util/TypeUtil;","class2Name","Ljava/util/HashMap;"));
                code.visitFieldStmt(SGET_OBJECT,3,-1,new Field("Ljava/lang/Void;","TYPE","Ljava/lang/Class;"));
                code.visitConstStmt(CONST_STRING,4,"void");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3,4},new Method("Ljava/util/HashMap;","put",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitLabel(L55);
                code.visitFieldStmt(SGET_OBJECT,2,-1,new Field("Lorg/mortbay/util/TypeUtil;","class2Name","Ljava/util/HashMap;"));
                code.visitConstStmt(CONST_CLASS,3,new DexType("Ljava/lang/Boolean;"));
                code.visitConstStmt(CONST_STRING,3,"java.lang.Boolean");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,5,3},new Method("Ljava/util/HashMap;","put",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitLabel(L56);
                code.visitFieldStmt(SGET_OBJECT,2,-1,new Field("Lorg/mortbay/util/TypeUtil;","class2Name","Ljava/util/HashMap;"));
                code.visitConstStmt(CONST_CLASS,3,new DexType("Ljava/lang/Byte;"));
                code.visitConstStmt(CONST_STRING,3,"java.lang.Byte");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,6,3},new Method("Ljava/util/HashMap;","put",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitLabel(L57);
                code.visitFieldStmt(SGET_OBJECT,2,-1,new Field("Lorg/mortbay/util/TypeUtil;","class2Name","Ljava/util/HashMap;"));
                code.visitConstStmt(CONST_CLASS,3,new DexType("Ljava/lang/Character;"));
                code.visitConstStmt(CONST_STRING,4,"java.lang.Character");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3,4},new Method("Ljava/util/HashMap;","put",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitLabel(L58);
                code.visitFieldStmt(SGET_OBJECT,2,-1,new Field("Lorg/mortbay/util/TypeUtil;","class2Name","Ljava/util/HashMap;"));
                code.visitConstStmt(CONST_CLASS,3,new DexType("Ljava/lang/Double;"));
                code.visitConstStmt(CONST_STRING,3,"java.lang.Double");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,7,3},new Method("Ljava/util/HashMap;","put",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitLabel(L59);
                code.visitFieldStmt(SGET_OBJECT,2,-1,new Field("Lorg/mortbay/util/TypeUtil;","class2Name","Ljava/util/HashMap;"));
                code.visitConstStmt(CONST_CLASS,3,new DexType("Ljava/lang/Float;"));
                code.visitConstStmt(CONST_STRING,3,"java.lang.Float");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,8,3},new Method("Ljava/util/HashMap;","put",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitLabel(L60);
                code.visitFieldStmt(SGET_OBJECT,2,-1,new Field("Lorg/mortbay/util/TypeUtil;","class2Name","Ljava/util/HashMap;"));
                code.visitConstStmt(CONST_CLASS,3,new DexType("Ljava/lang/Integer;"));
                code.visitConstStmt(CONST_STRING,4,"java.lang.Integer");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3,4},new Method("Ljava/util/HashMap;","put",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitLabel(L61);
                code.visitFieldStmt(SGET_OBJECT,2,-1,new Field("Lorg/mortbay/util/TypeUtil;","class2Name","Ljava/util/HashMap;"));
                code.visitConstStmt(CONST_CLASS,3,new DexType("Ljava/lang/Long;"));
                code.visitConstStmt(CONST_STRING,4,"java.lang.Long");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3,4},new Method("Ljava/util/HashMap;","put",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitLabel(L62);
                code.visitFieldStmt(SGET_OBJECT,2,-1,new Field("Lorg/mortbay/util/TypeUtil;","class2Name","Ljava/util/HashMap;"));
                code.visitConstStmt(CONST_CLASS,3,new DexType("Ljava/lang/Short;"));
                code.visitConstStmt(CONST_STRING,4,"java.lang.Short");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3,4},new Method("Ljava/util/HashMap;","put",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitLabel(L63);
                code.visitFieldStmt(SGET_OBJECT,2,-1,new Field("Lorg/mortbay/util/TypeUtil;","class2Name","Ljava/util/HashMap;"));
                code.visitConstStmt(CONST_4,3, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitConstStmt(CONST_STRING,4,"void");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3,4},new Method("Ljava/util/HashMap;","put",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitLabel(L64);
                code.visitFieldStmt(SGET_OBJECT,2,-1,new Field("Lorg/mortbay/util/TypeUtil;","class2Name","Ljava/util/HashMap;"));
                code.visitConstStmt(CONST_CLASS,3,new DexType("Ljava/lang/String;"));
                code.visitConstStmt(CONST_STRING,4,"java.lang.String");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3,4},new Method("Ljava/util/HashMap;","put",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitLabel(L65);
                code.visitTypeStmt(NEW_INSTANCE,2,-1,"Ljava/util/HashMap;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2},new Method("Ljava/util/HashMap;","<init>",new String[]{ },"V"));
                code.visitFieldStmt(SPUT_OBJECT,2,-1,new Field("Lorg/mortbay/util/TypeUtil;","class2Value","Ljava/util/HashMap;"));
                code.visitLabel(L66);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitLabel(L0);
                code.visitTypeStmt(NEW_ARRAY,1,2,"[Ljava/lang/Class;");
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitConstStmt(CONST_CLASS,3,new DexType("Ljava/lang/String;"));
                code.visitStmt3R(APUT_OBJECT,3,1,2);
                code.visitLabel(L67);
                code.visitFieldStmt(SGET_OBJECT,2,-1,new Field("Lorg/mortbay/util/TypeUtil;","class2Value","Ljava/util/HashMap;"));
                code.visitFieldStmt(SGET_OBJECT,3,-1,new Field("Ljava/lang/Boolean;","TYPE","Ljava/lang/Class;"));
                code.visitConstStmt(CONST_CLASS,4,new DexType("Ljava/lang/Boolean;"));
                code.visitConstStmt(CONST_STRING,5,"valueOf");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,5,1},new Method("Ljava/lang/Class;","getMethod",new String[]{ "Ljava/lang/String;","[Ljava/lang/Class;"},"Ljava/lang/reflect/Method;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3,4},new Method("Ljava/util/HashMap;","put",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitLabel(L68);
                code.visitFieldStmt(SGET_OBJECT,2,-1,new Field("Lorg/mortbay/util/TypeUtil;","class2Value","Ljava/util/HashMap;"));
                code.visitFieldStmt(SGET_OBJECT,3,-1,new Field("Ljava/lang/Byte;","TYPE","Ljava/lang/Class;"));
                code.visitConstStmt(CONST_CLASS,4,new DexType("Ljava/lang/Byte;"));
                code.visitConstStmt(CONST_STRING,5,"valueOf");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,5,1},new Method("Ljava/lang/Class;","getMethod",new String[]{ "Ljava/lang/String;","[Ljava/lang/Class;"},"Ljava/lang/reflect/Method;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3,4},new Method("Ljava/util/HashMap;","put",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitLabel(L69);
                code.visitFieldStmt(SGET_OBJECT,2,-1,new Field("Lorg/mortbay/util/TypeUtil;","class2Value","Ljava/util/HashMap;"));
                code.visitFieldStmt(SGET_OBJECT,3,-1,new Field("Ljava/lang/Double;","TYPE","Ljava/lang/Class;"));
                code.visitConstStmt(CONST_CLASS,4,new DexType("Ljava/lang/Double;"));
                code.visitConstStmt(CONST_STRING,5,"valueOf");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,5,1},new Method("Ljava/lang/Class;","getMethod",new String[]{ "Ljava/lang/String;","[Ljava/lang/Class;"},"Ljava/lang/reflect/Method;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3,4},new Method("Ljava/util/HashMap;","put",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitLabel(L70);
                code.visitFieldStmt(SGET_OBJECT,2,-1,new Field("Lorg/mortbay/util/TypeUtil;","class2Value","Ljava/util/HashMap;"));
                code.visitFieldStmt(SGET_OBJECT,3,-1,new Field("Ljava/lang/Float;","TYPE","Ljava/lang/Class;"));
                code.visitConstStmt(CONST_CLASS,4,new DexType("Ljava/lang/Float;"));
                code.visitConstStmt(CONST_STRING,5,"valueOf");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,5,1},new Method("Ljava/lang/Class;","getMethod",new String[]{ "Ljava/lang/String;","[Ljava/lang/Class;"},"Ljava/lang/reflect/Method;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3,4},new Method("Ljava/util/HashMap;","put",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitLabel(L71);
                code.visitFieldStmt(SGET_OBJECT,2,-1,new Field("Lorg/mortbay/util/TypeUtil;","class2Value","Ljava/util/HashMap;"));
                code.visitFieldStmt(SGET_OBJECT,3,-1,new Field("Ljava/lang/Integer;","TYPE","Ljava/lang/Class;"));
                code.visitConstStmt(CONST_CLASS,4,new DexType("Ljava/lang/Integer;"));
                code.visitConstStmt(CONST_STRING,5,"valueOf");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,5,1},new Method("Ljava/lang/Class;","getMethod",new String[]{ "Ljava/lang/String;","[Ljava/lang/Class;"},"Ljava/lang/reflect/Method;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3,4},new Method("Ljava/util/HashMap;","put",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitLabel(L72);
                code.visitFieldStmt(SGET_OBJECT,2,-1,new Field("Lorg/mortbay/util/TypeUtil;","class2Value","Ljava/util/HashMap;"));
                code.visitFieldStmt(SGET_OBJECT,3,-1,new Field("Ljava/lang/Long;","TYPE","Ljava/lang/Class;"));
                code.visitConstStmt(CONST_CLASS,4,new DexType("Ljava/lang/Long;"));
                code.visitConstStmt(CONST_STRING,5,"valueOf");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,5,1},new Method("Ljava/lang/Class;","getMethod",new String[]{ "Ljava/lang/String;","[Ljava/lang/Class;"},"Ljava/lang/reflect/Method;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3,4},new Method("Ljava/util/HashMap;","put",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitLabel(L73);
                code.visitFieldStmt(SGET_OBJECT,2,-1,new Field("Lorg/mortbay/util/TypeUtil;","class2Value","Ljava/util/HashMap;"));
                code.visitFieldStmt(SGET_OBJECT,3,-1,new Field("Ljava/lang/Short;","TYPE","Ljava/lang/Class;"));
                code.visitConstStmt(CONST_CLASS,4,new DexType("Ljava/lang/Short;"));
                code.visitConstStmt(CONST_STRING,5,"valueOf");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,5,1},new Method("Ljava/lang/Class;","getMethod",new String[]{ "Ljava/lang/String;","[Ljava/lang/Class;"},"Ljava/lang/reflect/Method;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3,4},new Method("Ljava/util/HashMap;","put",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitLabel(L74);
                code.visitFieldStmt(SGET_OBJECT,2,-1,new Field("Lorg/mortbay/util/TypeUtil;","class2Value","Ljava/util/HashMap;"));
                code.visitConstStmt(CONST_CLASS,3,new DexType("Ljava/lang/Boolean;"));
                code.visitConstStmt(CONST_CLASS,4,new DexType("Ljava/lang/Boolean;"));
                code.visitConstStmt(CONST_STRING,5,"valueOf");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,5,1},new Method("Ljava/lang/Class;","getMethod",new String[]{ "Ljava/lang/String;","[Ljava/lang/Class;"},"Ljava/lang/reflect/Method;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3,4},new Method("Ljava/util/HashMap;","put",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitLabel(L75);
                code.visitFieldStmt(SGET_OBJECT,2,-1,new Field("Lorg/mortbay/util/TypeUtil;","class2Value","Ljava/util/HashMap;"));
                code.visitConstStmt(CONST_CLASS,3,new DexType("Ljava/lang/Byte;"));
                code.visitConstStmt(CONST_CLASS,4,new DexType("Ljava/lang/Byte;"));
                code.visitConstStmt(CONST_STRING,5,"valueOf");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,5,1},new Method("Ljava/lang/Class;","getMethod",new String[]{ "Ljava/lang/String;","[Ljava/lang/Class;"},"Ljava/lang/reflect/Method;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3,4},new Method("Ljava/util/HashMap;","put",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitLabel(L76);
                code.visitFieldStmt(SGET_OBJECT,2,-1,new Field("Lorg/mortbay/util/TypeUtil;","class2Value","Ljava/util/HashMap;"));
                code.visitConstStmt(CONST_CLASS,3,new DexType("Ljava/lang/Double;"));
                code.visitConstStmt(CONST_CLASS,4,new DexType("Ljava/lang/Double;"));
                code.visitConstStmt(CONST_STRING,5,"valueOf");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,5,1},new Method("Ljava/lang/Class;","getMethod",new String[]{ "Ljava/lang/String;","[Ljava/lang/Class;"},"Ljava/lang/reflect/Method;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3,4},new Method("Ljava/util/HashMap;","put",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitLabel(L77);
                code.visitFieldStmt(SGET_OBJECT,2,-1,new Field("Lorg/mortbay/util/TypeUtil;","class2Value","Ljava/util/HashMap;"));
                code.visitConstStmt(CONST_CLASS,3,new DexType("Ljava/lang/Float;"));
                code.visitConstStmt(CONST_CLASS,4,new DexType("Ljava/lang/Float;"));
                code.visitConstStmt(CONST_STRING,5,"valueOf");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,5,1},new Method("Ljava/lang/Class;","getMethod",new String[]{ "Ljava/lang/String;","[Ljava/lang/Class;"},"Ljava/lang/reflect/Method;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3,4},new Method("Ljava/util/HashMap;","put",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitLabel(L78);
                code.visitFieldStmt(SGET_OBJECT,2,-1,new Field("Lorg/mortbay/util/TypeUtil;","class2Value","Ljava/util/HashMap;"));
                code.visitConstStmt(CONST_CLASS,3,new DexType("Ljava/lang/Integer;"));
                code.visitConstStmt(CONST_CLASS,4,new DexType("Ljava/lang/Integer;"));
                code.visitConstStmt(CONST_STRING,5,"valueOf");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,5,1},new Method("Ljava/lang/Class;","getMethod",new String[]{ "Ljava/lang/String;","[Ljava/lang/Class;"},"Ljava/lang/reflect/Method;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3,4},new Method("Ljava/util/HashMap;","put",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitLabel(L79);
                code.visitFieldStmt(SGET_OBJECT,2,-1,new Field("Lorg/mortbay/util/TypeUtil;","class2Value","Ljava/util/HashMap;"));
                code.visitConstStmt(CONST_CLASS,3,new DexType("Ljava/lang/Long;"));
                code.visitConstStmt(CONST_CLASS,4,new DexType("Ljava/lang/Long;"));
                code.visitConstStmt(CONST_STRING,5,"valueOf");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,5,1},new Method("Ljava/lang/Class;","getMethod",new String[]{ "Ljava/lang/String;","[Ljava/lang/Class;"},"Ljava/lang/reflect/Method;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3,4},new Method("Ljava/util/HashMap;","put",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitLabel(L80);
                code.visitFieldStmt(SGET_OBJECT,2,-1,new Field("Lorg/mortbay/util/TypeUtil;","class2Value","Ljava/util/HashMap;"));
                code.visitConstStmt(CONST_CLASS,3,new DexType("Ljava/lang/Short;"));
                code.visitConstStmt(CONST_CLASS,4,new DexType("Ljava/lang/Short;"));
                code.visitConstStmt(CONST_STRING,5,"valueOf");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,5,1},new Method("Ljava/lang/Class;","getMethod",new String[]{ "Ljava/lang/String;","[Ljava/lang/Class;"},"Ljava/lang/reflect/Method;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3,4},new Method("Ljava/util/HashMap;","put",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitTypeStmt(NEW_ARRAY,2,2,"[Ljava/lang/Class;");
                code.visitConstStmt(CONST_4,3, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitConstStmt(CONST_CLASS,4,new DexType("Ljava/lang/String;"));
                code.visitStmt3R(APUT_OBJECT,4,2,3);
                code.visitFieldStmt(SPUT_OBJECT,2,-1,new Field("Lorg/mortbay/util/TypeUtil;","stringArg","[Ljava/lang/Class;"));
                code.visitLabel(L81);
                code.visitConstStmt(CONST_STRING,2,"org.mortbay.util.TypeUtil.IntegerCacheSize");
                code.visitConstStmt(CONST_16,3, Integer.valueOf(600)); // int: 0x00000258  float:0.000000
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 2,3},new Method("Ljava/lang/Integer;","getInteger",new String[]{ "Ljava/lang/String;","I"},"Ljava/lang/Integer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Ljava/lang/Integer;","intValue",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitFieldStmt(SPUT,2,-1,new Field("Lorg/mortbay/util/TypeUtil;","intCacheSize","I"));
                code.visitLabel(L82);
                code.visitFieldStmt(SGET,2,-1,new Field("Lorg/mortbay/util/TypeUtil;","intCacheSize","I"));
                code.visitTypeStmt(NEW_ARRAY,2,2,"[Ljava/lang/Integer;");
                code.visitFieldStmt(SPUT_OBJECT,2,-1,new Field("Lorg/mortbay/util/TypeUtil;","integerCache","[Ljava/lang/Integer;"));
                code.visitLabel(L83);
                code.visitFieldStmt(SGET,2,-1,new Field("Lorg/mortbay/util/TypeUtil;","intCacheSize","I"));
                code.visitTypeStmt(NEW_ARRAY,2,2,"[Ljava/lang/String;");
                code.visitFieldStmt(SPUT_OBJECT,2,-1,new Field("Lorg/mortbay/util/TypeUtil;","integerStrCache","[Ljava/lang/String;"));
                code.visitLabel(L84);
                code.visitTypeStmt(NEW_INSTANCE,2,-1,"Ljava/lang/Integer;");
                code.visitConstStmt(CONST_4,3, Integer.valueOf(-1)); // int: 0xffffffff  float:NaN
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2,3},new Method("Ljava/lang/Integer;","<init>",new String[]{ "I"},"V"));
                code.visitFieldStmt(SPUT_OBJECT,2,-1,new Field("Lorg/mortbay/util/TypeUtil;","minusOne","Ljava/lang/Integer;"));
                code.visitLabel(L85);
                code.visitConstStmt(CONST_STRING,2,"org.mortbay.util.TypeUtil.LongCacheSize");
                code.visitConstStmt(CONST_16,3, Integer.valueOf(64)); // int: 0x00000040  float:0.000000
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 2,3},new Method("Ljava/lang/Integer;","getInteger",new String[]{ "Ljava/lang/String;","I"},"Ljava/lang/Integer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Ljava/lang/Integer;","intValue",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitFieldStmt(SPUT,2,-1,new Field("Lorg/mortbay/util/TypeUtil;","longCacheSize","I"));
                code.visitLabel(L86);
                code.visitFieldStmt(SGET,2,-1,new Field("Lorg/mortbay/util/TypeUtil;","longCacheSize","I"));
                code.visitTypeStmt(NEW_ARRAY,2,2,"[Ljava/lang/Long;");
                code.visitFieldStmt(SPUT_OBJECT,2,-1,new Field("Lorg/mortbay/util/TypeUtil;","longCache","[Ljava/lang/Long;"));
                code.visitLabel(L87);
                code.visitTypeStmt(NEW_INSTANCE,2,-1,"Ljava/lang/Long;");
                code.visitConstStmt(CONST_WIDE_16,3,Long.valueOf(-1L)); // long: 0xffffffffffffffff  double:NaN
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2,3,4},new Method("Ljava/lang/Long;","<init>",new String[]{ "J"},"V"));
                code.visitFieldStmt(SPUT_OBJECT,2,-1,new Field("Lorg/mortbay/util/TypeUtil;","minusOneL","Ljava/lang/Long;"));
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,2);
                code.visitStmt2R(MOVE_OBJECT,0,2);
                code.visitLabel(L88);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/lang/Exception;","printStackTrace",new String[]{ },"V"));
                code.visitJumpStmt(GOTO,-1,-1,L1);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/util/TypeUtil;","<init>",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(1);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(36,L0);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/lang/Object;","<init>",new String[]{ },"V"));
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m002_convertHexDigit(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Lorg/mortbay/util/TypeUtil;","convertHexDigit",new String[]{ "B"},"B"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"b");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(421,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(424,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(422,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(423,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(424,L5);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_16,3, Integer.valueOf(97)); // int: 0x00000061  float:0.000000
                code.visitConstStmt(CONST_16,2, Integer.valueOf(65)); // int: 0x00000041  float:0.000000
                code.visitConstStmt(CONST_16,1, Integer.valueOf(48)); // int: 0x00000030  float:0.000000
                code.visitLabel(L1);
                code.visitJumpStmt(IF_LT,4,1,L3);
                code.visitConstStmt(CONST_16,0, Integer.valueOf(57)); // int: 0x00000039  float:0.000000
                code.visitJumpStmt(IF_GT,4,0,L3);
                code.visitStmt3R(SUB_INT,0,4,1);
                code.visitStmt2R(INT_TO_BYTE,0,0);
                code.visitLabel(L2);
                code.visitStmt1R(RETURN,0);
                code.visitLabel(L3);
                code.visitJumpStmt(IF_LT,4,3,L4);
                code.visitConstStmt(CONST_16,0, Integer.valueOf(102)); // int: 0x00000066  float:0.000000
                code.visitJumpStmt(IF_GT,4,0,L4);
                code.visitStmt3R(SUB_INT,0,4,3);
                code.visitStmt2R1N(ADD_INT_LIT8,0,0,10);
                code.visitStmt2R(INT_TO_BYTE,0,0);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitLabel(L4);
                code.visitJumpStmt(IF_LT,4,2,L5);
                code.visitConstStmt(CONST_16,0, Integer.valueOf(70)); // int: 0x00000046  float:0.000000
                code.visitJumpStmt(IF_GT,4,0,L5);
                code.visitStmt3R(SUB_INT,0,4,2);
                code.visitStmt2R1N(ADD_INT_LIT8,0,0,10);
                code.visitStmt2R(INT_TO_BYTE,0,0);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitLabel(L5);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m003_dump(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Lorg/mortbay/util/TypeUtil;","dump",new String[]{ "Ljava/lang/Class;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"c");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(482,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(483,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(484,L2);
                code.visitLabel(L0);
                code.visitFieldStmt(SGET_OBJECT,0,-1,new Field("Ljava/lang/System;","err","Ljava/io/PrintStream;"));
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,2,"Dump: ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,3},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/io/PrintStream;","println",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Ljava/lang/Class;","getClassLoader",new String[]{ },"Ljava/lang/ClassLoader;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0},new Method("Lorg/mortbay/util/TypeUtil;","dump",new String[]{ "Ljava/lang/ClassLoader;"},"V"));
                code.visitLabel(L2);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m004_dump(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Lorg/mortbay/util/TypeUtil;","dump",new String[]{ "Ljava/lang/ClassLoader;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"cl");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(488,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(489,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(491,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(492,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(494,L4);
                code.visitLabel(L0);
                code.visitFieldStmt(SGET_OBJECT,0,-1,new Field("Ljava/lang/System;","err","Ljava/io/PrintStream;"));
                code.visitConstStmt(CONST_STRING,1,"Dump Loaders:");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/io/PrintStream;","println",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L1);
                code.visitJumpStmt(IF_EQZ,3,-1,L4);
                code.visitLabel(L2);
                code.visitFieldStmt(SGET_OBJECT,0,-1,new Field("Ljava/lang/System;","err","Ljava/io/PrintStream;"));
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,2,"  loader ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,3},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/io/PrintStream;","println",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Ljava/lang/ClassLoader;","getParent",new String[]{ },"Ljava/lang/ClassLoader;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitJumpStmt(GOTO,-1,-1,L1);
                code.visitLabel(L4);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m005_fromHexString(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Lorg/mortbay/util/TypeUtil;","fromHexString",new String[]{ "Ljava/lang/String;"},"[B"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(6);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"s");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(468,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(469,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(470,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(471,L3);
                ddv.visitStartLocal(0,L3,"array","[B",null);
                DexLabel L4=new DexLabel();
                ddv.visitStartLocal(2,L4,"i","I",null);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(473,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(474,L6);
                ddv.visitStartLocal(1,L6,"b","I",null);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(471,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(476,L8);
                ddv.visitEndLocal(1,L8);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Ljava/lang/String;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitStmt2R1N(REM_INT_LIT8,3,3,2);
                code.visitJumpStmt(IF_EQZ,3,-1,L2);
                code.visitLabel(L1);
                code.visitTypeStmt(NEW_INSTANCE,3,-1,"Ljava/lang/IllegalArgumentException;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 3,5},new Method("Ljava/lang/IllegalArgumentException;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitStmt1R(THROW,3);
                code.visitLabel(L2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Ljava/lang/String;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitStmt2R1N(DIV_INT_LIT8,3,3,2);
                code.visitTypeStmt(NEW_ARRAY,0,3,"[B");
                code.visitLabel(L3);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L4);
                code.visitStmt2R(ARRAY_LENGTH,3,0);
                code.visitJumpStmt(IF_GE,2,3,L8);
                code.visitLabel(L5);
                code.visitStmt2R1N(MUL_INT_LIT8,3,2,2);
                code.visitStmt2R1N(MUL_INT_LIT8,4,2,2);
                code.visitStmt2R1N(ADD_INT_LIT8,4,4,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,3,4},new Method("Ljava/lang/String;","substring",new String[]{ "I","I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitConstStmt(CONST_16,4, Integer.valueOf(16)); // int: 0x00000010  float:0.000000
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 3,4},new Method("Ljava/lang/Integer;","parseInt",new String[]{ "Ljava/lang/String;","I"},"I"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitLabel(L6);
                code.visitStmt2R1N(AND_INT_LIT16,3,1,255);
                code.visitStmt2R(INT_TO_BYTE,3,3);
                code.visitStmt3R(APUT_BYTE,3,0,2);
                code.visitLabel(L7);
                code.visitStmt2R1N(ADD_INT_LIT8,2,2,1);
                code.visitJumpStmt(GOTO,-1,-1,L4);
                code.visitLabel(L8);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m006_fromName(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Lorg/mortbay/util/TypeUtil;","fromName",new String[]{ "Ljava/lang/String;"},"Ljava/lang/Class;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"name");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(181,L0);
                DexLabel L1=new DexLabel();
                ddv.visitEndLocal(1,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(SGET_OBJECT,0,-1,new Field("Lorg/mortbay/util/TypeUtil;","name2Class","Ljava/util/HashMap;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/util/HashMap;","get",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L1);
                code.visitTypeStmt(CHECK_CAST,1,-1,"Ljava/lang/Class;");
                code.visitStmt1R(RETURN_OBJECT,1);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m007_jarFor(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Lorg/mortbay/util/TypeUtil;","jarFor",new String[]{ "Ljava/lang/String;"},"Ljava/net/URL;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(8);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ "Ljava/lang/Exception;"});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"className");
                DexLabel L3=new DexLabel();
                ddv.visitPrologue(L3);
                ddv.visitLineNumber(552,L0);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(554,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(555,L5);
                ddv.visitStartLocal(2,L5,"url","Ljava/net/URL;",null);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(556,L6);
                ddv.visitStartLocal(1,L6,"s","Ljava/lang/String;",null);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(557,L7);
                ddv.visitLineNumber(563,L1);
                ddv.visitEndLocal(2,L1);
                ddv.visitEndLocal(1,L1);
                ddv.visitLineNumber(559,L2);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(561,L8);
                ddv.visitStartLocal(0,L8,"e","Ljava/lang/Exception;",null);
                DexLabel L9=new DexLabel();
                ddv.visitEndLocal(0,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(563,L10);
                code.visitLabel(L3);
                code.visitConstStmt(CONST_4,6, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L0);
                code.visitTypeStmt(NEW_INSTANCE,3,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 3},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_16,4, Integer.valueOf(46)); // int: 0x0000002e  float:0.000000
                code.visitConstStmt(CONST_16,5, Integer.valueOf(47)); // int: 0x0000002f  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7,4,5},new Method("Ljava/lang/String;","replace",new String[]{ "C","C"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,4},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitConstStmt(CONST_STRING,4,".class");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,4},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitLabel(L4);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitConstStmt(CONST_4,4, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 3,7,4},new Method("Lorg/mortbay/util/Loader;","getResource",new String[]{ "Ljava/lang/Class;","Ljava/lang/String;","Z"},"Ljava/net/URL;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitLabel(L5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Ljava/net/URL;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L6);
                code.visitConstStmt(CONST_STRING,3,"jar:file:");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,3},new Method("Ljava/lang/String;","startsWith",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitJumpStmt(IF_EQZ,3,-1,L9);
                code.visitLabel(L7);
                code.visitTypeStmt(NEW_INSTANCE,3,-1,"Ljava/net/URL;");
                code.visitConstStmt(CONST_4,4, Integer.valueOf(4)); // int: 0x00000004  float:0.000000
                code.visitConstStmt(CONST_STRING,5,"!/");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,5},new Method("Ljava/lang/String;","indexOf",new String[]{ "Ljava/lang/String;"},"I"));
                code.visitStmt1R(MOVE_RESULT,5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,4,5},new Method("Ljava/lang/String;","substring",new String[]{ "I","I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 3,4},new Method("Ljava/net/URL;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L1);
                code.visitStmt1R(RETURN_OBJECT,3);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,3);
                code.visitStmt2R(MOVE_OBJECT,0,3);
                code.visitLabel(L8);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0},new Method("Lorg/mortbay/log/Log;","ignore",new String[]{ "Ljava/lang/Throwable;"},"V"));
                code.visitLabel(L9);
                code.visitStmt2R(MOVE_OBJECT,3,6);
                code.visitLabel(L10);
                code.visitJumpStmt(GOTO,-1,-1,L1);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m008_newInteger(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Lorg/mortbay/util/TypeUtil;","newInteger",new String[]{ "I"},"Ljava/lang/Integer;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"i");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(255,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(257,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(258,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(259,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(263,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(261,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(262,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(263,L7);
                code.visitLabel(L0);
                code.visitJumpStmt(IF_LTZ,2,-1,L5);
                code.visitFieldStmt(SGET,0,-1,new Field("Lorg/mortbay/util/TypeUtil;","intCacheSize","I"));
                code.visitJumpStmt(IF_GE,2,0,L5);
                code.visitLabel(L1);
                code.visitFieldStmt(SGET_OBJECT,0,-1,new Field("Lorg/mortbay/util/TypeUtil;","integerCache","[Ljava/lang/Integer;"));
                code.visitStmt3R(AGET_OBJECT,0,0,2);
                code.visitJumpStmt(IF_NEZ,0,-1,L3);
                code.visitLabel(L2);
                code.visitFieldStmt(SGET_OBJECT,0,-1,new Field("Lorg/mortbay/util/TypeUtil;","integerCache","[Ljava/lang/Integer;"));
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Ljava/lang/Integer;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1,2},new Method("Ljava/lang/Integer;","<init>",new String[]{ "I"},"V"));
                code.visitStmt3R(APUT_OBJECT,1,0,2);
                code.visitLabel(L3);
                code.visitFieldStmt(SGET_OBJECT,0,-1,new Field("Lorg/mortbay/util/TypeUtil;","integerCache","[Ljava/lang/Integer;"));
                code.visitStmt3R(AGET_OBJECT,0,0,2);
                code.visitLabel(L4);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitLabel(L5);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(-1)); // int: 0xffffffff  float:NaN
                code.visitJumpStmt(IF_NE,2,0,L7);
                code.visitLabel(L6);
                code.visitFieldStmt(SGET_OBJECT,0,-1,new Field("Lorg/mortbay/util/TypeUtil;","minusOne","Ljava/lang/Integer;"));
                code.visitJumpStmt(GOTO,-1,-1,L4);
                code.visitLabel(L7);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/lang/Integer;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,2},new Method("Ljava/lang/Integer;","<init>",new String[]{ "I"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L4);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m009_newLong(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Lorg/mortbay/util/TypeUtil;","newLong",new String[]{ "J"},"Ljava/lang/Long;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"i");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(271,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(273,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(274,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(275,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(279,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(277,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(278,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(279,L7);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_WIDE_16,0,Long.valueOf(0L)); // long: 0x0000000000000000  double:0.000000
                code.visitStmt3R(CMP_LONG,0,3,0);
                code.visitJumpStmt(IF_LTZ,0,-1,L5);
                code.visitFieldStmt(SGET,0,-1,new Field("Lorg/mortbay/util/TypeUtil;","longCacheSize","I"));
                code.visitStmt2R(INT_TO_LONG,0,0);
                code.visitStmt3R(CMP_LONG,0,3,0);
                code.visitJumpStmt(IF_GEZ,0,-1,L5);
                code.visitLabel(L1);
                code.visitFieldStmt(SGET_OBJECT,0,-1,new Field("Lorg/mortbay/util/TypeUtil;","longCache","[Ljava/lang/Long;"));
                code.visitStmt2R(LONG_TO_INT,1,3);
                code.visitStmt3R(AGET_OBJECT,0,0,1);
                code.visitJumpStmt(IF_NEZ,0,-1,L3);
                code.visitLabel(L2);
                code.visitFieldStmt(SGET_OBJECT,0,-1,new Field("Lorg/mortbay/util/TypeUtil;","longCache","[Ljava/lang/Long;"));
                code.visitStmt2R(LONG_TO_INT,1,3);
                code.visitTypeStmt(NEW_INSTANCE,2,-1,"Ljava/lang/Long;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2,3,4},new Method("Ljava/lang/Long;","<init>",new String[]{ "J"},"V"));
                code.visitStmt3R(APUT_OBJECT,2,0,1);
                code.visitLabel(L3);
                code.visitFieldStmt(SGET_OBJECT,0,-1,new Field("Lorg/mortbay/util/TypeUtil;","longCache","[Ljava/lang/Long;"));
                code.visitStmt2R(LONG_TO_INT,1,3);
                code.visitStmt3R(AGET_OBJECT,0,0,1);
                code.visitLabel(L4);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitLabel(L5);
                code.visitConstStmt(CONST_WIDE_16,0,Long.valueOf(-1L)); // long: 0xffffffffffffffff  double:NaN
                code.visitStmt3R(CMP_LONG,0,3,0);
                code.visitJumpStmt(IF_NEZ,0,-1,L7);
                code.visitLabel(L6);
                code.visitFieldStmt(SGET_OBJECT,0,-1,new Field("Lorg/mortbay/util/TypeUtil;","minusOneL","Ljava/lang/Long;"));
                code.visitJumpStmt(GOTO,-1,-1,L4);
                code.visitLabel(L7);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/lang/Long;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,3,4},new Method("Ljava/lang/Long;","<init>",new String[]{ "J"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L4);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m010_parseBytes(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Lorg/mortbay/util/TypeUtil;","parseBytes",new String[]{ "Ljava/lang/String;","I"},"[B"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(6);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"s");
                ddv.visitParameterName(1,"base");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(389,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(390,L1);
                ddv.visitStartLocal(0,L1,"bytes","[B",null);
                DexLabel L2=new DexLabel();
                ddv.visitStartLocal(1,L2,"i","I",null);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(391,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(390,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(392,L5);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Ljava/lang/String;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitStmt2R1N(DIV_INT_LIT8,2,2,2);
                code.visitTypeStmt(NEW_ARRAY,0,2,"[B");
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Ljava/lang/String;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitJumpStmt(IF_GE,1,2,L5);
                code.visitLabel(L3);
                code.visitStmt2R1N(DIV_INT_LIT8,2,1,2);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(2)); // int: 0x00000002  float:0.000000
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 4,1,3,5},new Method("Lorg/mortbay/util/TypeUtil;","parseInt",new String[]{ "Ljava/lang/String;","I","I","I"},"I"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitStmt2R(INT_TO_BYTE,3,3);
                code.visitStmt3R(APUT_BYTE,3,0,2);
                code.visitLabel(L4);
                code.visitStmt2R1N(ADD_INT_LIT8,1,1,2);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitLabel(L5);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m011_parseInt(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Lorg/mortbay/util/TypeUtil;","parseInt",new String[]{ "Ljava/lang/String;","I","I","I"},"I"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/lang/NumberFormatException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(11);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"s");
                ddv.visitParameterName(1,"offset");
                ddv.visitParameterName(2,"length");
                ddv.visitParameterName(3,"base");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(328,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(330,L2);
                ddv.visitStartLocal(3,L2,"value","I",null);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(331,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(333,L4);
                DexLabel L5=new DexLabel();
                ddv.visitStartLocal(2,L5,"i","I",null);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(335,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(337,L7);
                ddv.visitStartLocal(0,L7,"c","C",null);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(338,L8);
                ddv.visitStartLocal(1,L8,"digit","I",null);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(340,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(341,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(342,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(344,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(345,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(346,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(333,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(348,L16);
                ddv.visitEndLocal(0,L16);
                ddv.visitEndLocal(1,L16);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_16,6, Integer.valueOf(10)); // int: 0x0000000a  float:0.000000
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L2);
                code.visitJumpStmt(IF_GEZ,9,-1,L4);
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7},new Method("Ljava/lang/String;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,4);
                code.visitStmt3R(SUB_INT,9,4,8);
                code.visitLabel(L4);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L5);
                code.visitJumpStmt(IF_GE,2,9,L16);
                code.visitLabel(L6);
                code.visitStmt3R(ADD_INT,4,8,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7,4},new Method("Ljava/lang/String;","charAt",new String[]{ "I"},"C"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitLabel(L7);
                code.visitConstStmt(CONST_16,4, Integer.valueOf(48)); // int: 0x00000030  float:0.000000
                code.visitStmt3R(SUB_INT,1,0,4);
                code.visitLabel(L8);
                code.visitJumpStmt(IF_LTZ,1,-1,L9);
                code.visitJumpStmt(IF_GE,1,10,L9);
                code.visitJumpStmt(IF_LT,1,6,L12);
                code.visitLabel(L9);
                code.visitStmt2R1N(ADD_INT_LIT8,4,0,10);
                code.visitConstStmt(CONST_16,5, Integer.valueOf(65)); // int: 0x00000041  float:0.000000
                code.visitStmt3R(SUB_INT,1,4,5);
                code.visitLabel(L10);
                code.visitJumpStmt(IF_LT,1,6,L11);
                code.visitJumpStmt(IF_LT,1,10,L12);
                code.visitLabel(L11);
                code.visitStmt2R1N(ADD_INT_LIT8,4,0,10);
                code.visitConstStmt(CONST_16,5, Integer.valueOf(97)); // int: 0x00000061  float:0.000000
                code.visitStmt3R(SUB_INT,1,4,5);
                code.visitLabel(L12);
                code.visitJumpStmt(IF_LTZ,1,-1,L13);
                code.visitJumpStmt(IF_LT,1,10,L14);
                code.visitLabel(L13);
                code.visitTypeStmt(NEW_INSTANCE,4,-1,"Ljava/lang/NumberFormatException;");
                code.visitStmt3R(ADD_INT,5,8,9);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7,8,5},new Method("Ljava/lang/String;","substring",new String[]{ "I","I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 4,5},new Method("Ljava/lang/NumberFormatException;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitStmt1R(THROW,4);
                code.visitLabel(L14);
                code.visitStmt3R(MUL_INT,4,3,10);
                code.visitStmt3R(ADD_INT,3,4,1);
                code.visitLabel(L15);
                code.visitStmt2R1N(ADD_INT_LIT8,2,2,1);
                code.visitJumpStmt(GOTO,-1,-1,L5);
                code.visitLabel(L16);
                code.visitStmt1R(RETURN,3);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m012_parseInt(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Lorg/mortbay/util/TypeUtil;","parseInt",new String[]{ "[B","I","I","I"},"I"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/lang/NumberFormatException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(11);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"b");
                ddv.visitParameterName(1,"offset");
                ddv.visitParameterName(2,"length");
                ddv.visitParameterName(3,"base");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(363,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(365,L2);
                ddv.visitStartLocal(3,L2,"value","I",null);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(366,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(368,L4);
                DexLabel L5=new DexLabel();
                ddv.visitStartLocal(2,L5,"i","I",null);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(370,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(372,L7);
                ddv.visitStartLocal(0,L7,"c","C",null);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(373,L8);
                ddv.visitStartLocal(1,L8,"digit","I",null);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(375,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(376,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(377,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(379,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(380,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(381,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(368,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(383,L16);
                ddv.visitEndLocal(0,L16);
                ddv.visitEndLocal(1,L16);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_16,6, Integer.valueOf(10)); // int: 0x0000000a  float:0.000000
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L2);
                code.visitJumpStmt(IF_GEZ,9,-1,L4);
                code.visitLabel(L3);
                code.visitStmt2R(ARRAY_LENGTH,4,7);
                code.visitStmt3R(SUB_INT,9,4,8);
                code.visitLabel(L4);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L5);
                code.visitJumpStmt(IF_GE,2,9,L16);
                code.visitLabel(L6);
                code.visitStmt3R(ADD_INT,4,8,2);
                code.visitStmt3R(AGET_BYTE,4,7,4);
                code.visitStmt2R1N(AND_INT_LIT16,4,4,255);
                code.visitStmt2R(INT_TO_CHAR,0,4);
                code.visitLabel(L7);
                code.visitConstStmt(CONST_16,4, Integer.valueOf(48)); // int: 0x00000030  float:0.000000
                code.visitStmt3R(SUB_INT,1,0,4);
                code.visitLabel(L8);
                code.visitJumpStmt(IF_LTZ,1,-1,L9);
                code.visitJumpStmt(IF_GE,1,10,L9);
                code.visitJumpStmt(IF_LT,1,6,L12);
                code.visitLabel(L9);
                code.visitStmt2R1N(ADD_INT_LIT8,4,0,10);
                code.visitConstStmt(CONST_16,5, Integer.valueOf(65)); // int: 0x00000041  float:0.000000
                code.visitStmt3R(SUB_INT,1,4,5);
                code.visitLabel(L10);
                code.visitJumpStmt(IF_LT,1,6,L11);
                code.visitJumpStmt(IF_LT,1,10,L12);
                code.visitLabel(L11);
                code.visitStmt2R1N(ADD_INT_LIT8,4,0,10);
                code.visitConstStmt(CONST_16,5, Integer.valueOf(97)); // int: 0x00000061  float:0.000000
                code.visitStmt3R(SUB_INT,1,4,5);
                code.visitLabel(L12);
                code.visitJumpStmt(IF_LTZ,1,-1,L13);
                code.visitJumpStmt(IF_LT,1,10,L14);
                code.visitLabel(L13);
                code.visitTypeStmt(NEW_INSTANCE,4,-1,"Ljava/lang/NumberFormatException;");
                code.visitTypeStmt(NEW_INSTANCE,5,-1,"Ljava/lang/String;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 5,7,8,9},new Method("Ljava/lang/String;","<init>",new String[]{ "[B","I","I"},"V"));
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 4,5},new Method("Ljava/lang/NumberFormatException;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitStmt1R(THROW,4);
                code.visitLabel(L14);
                code.visitStmt3R(MUL_INT,4,3,10);
                code.visitStmt3R(ADD_INT,3,4,1);
                code.visitLabel(L15);
                code.visitStmt2R1N(ADD_INT_LIT8,2,2,1);
                code.visitJumpStmt(GOTO,-1,-1,L5);
                code.visitLabel(L16);
                code.visitStmt1R(RETURN,3);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m013_readLine(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Lorg/mortbay/util/TypeUtil;","readLine",new String[]{ "Ljava/io/InputStream;"},"[B"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(10);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"in");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(500,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(502,L2);
                ddv.visitStartLocal(0,L2,"buf","[B",null);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(503,L3);
                ddv.visitStartLocal(2,L3,"i","I",null);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(504,L4);
                ddv.visitStartLocal(4,L4,"loops","I",null);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(508,L5);
                ddv.visitStartLocal(1,L5,"ch","I",null);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(509,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(529,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(530,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(545,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(511,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(514,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(517,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(520,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(522,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(523,L15);
                ddv.visitStartLocal(5,L15,"old_buf","[B",null);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(524,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(526,L17);
                ddv.visitEndLocal(5,L17);
                DexLabel L18=new DexLabel();
                ddv.visitStartLocal(3,L18,"i","I",null);
                DexLabel L19=new DexLabel();
                ddv.visitEndLocal(2,L19);
                DexLabel L20=new DexLabel();
                ddv.visitRestartLocal(2,L20);
                DexLabel L21=new DexLabel();
                ddv.visitLineNumber(533,L21);
                ddv.visitEndLocal(3,L21);
                DexLabel L22=new DexLabel();
                ddv.visitLineNumber(535,L22);
                DexLabel L23=new DexLabel();
                ddv.visitLineNumber(536,L23);
                DexLabel L24=new DexLabel();
                ddv.visitLineNumber(537,L24);
                ddv.visitRestartLocal(1,L24);
                DexLabel L25=new DexLabel();
                ddv.visitLineNumber(538,L25);
                DexLabel L26=new DexLabel();
                ddv.visitLineNumber(541,L26);
                DexLabel L27=new DexLabel();
                ddv.visitLineNumber(542,L27);
                ddv.visitRestartLocal(5,L27);
                DexLabel L28=new DexLabel();
                ddv.visitLineNumber(543,L28);
                ddv.visitRestartLocal(0,L28);
                DexLabel L29=new DexLabel();
                ddv.visitLineNumber(545,L29);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,8, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitConstStmt(CONST_4,7, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L1);
                code.visitConstStmt(CONST_16,6, Integer.valueOf(256)); // int: 0x00000100  float:0.000000
                code.visitTypeStmt(NEW_ARRAY,0,6,"[B");
                code.visitLabel(L2);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L3);
                code.visitConstStmt(CONST_4,4, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L4);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9},new Method("Ljava/io/InputStream;","read",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitLabel(L6);
                code.visitJumpStmt(IF_GEZ,1,-1,L10);
                code.visitLabel(L7);
                code.visitConstStmt(CONST_4,6, Integer.valueOf(-1)); // int: 0xffffffff  float:NaN
                code.visitJumpStmt(IF_NE,1,6,L21);
                code.visitJumpStmt(IF_NEZ,2,-1,L21);
                code.visitLabel(L8);
                code.visitConstStmt(CONST_4,6, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L9);
                code.visitStmt1R(RETURN_OBJECT,6);
                code.visitLabel(L10);
                code.visitStmt2R1N(ADD_INT_LIT8,4,4,1);
                code.visitLabel(L11);
                code.visitJumpStmt(IF_NE,4,8,L12);
                code.visitFieldStmt(SGET,6,-1,new Field("Lorg/mortbay/util/TypeUtil;","LF","I"));
                code.visitJumpStmt(IF_EQ,1,6,L5);
                code.visitLabel(L12);
                code.visitFieldStmt(SGET,6,-1,new Field("Lorg/mortbay/util/TypeUtil;","CR","I"));
                code.visitJumpStmt(IF_EQ,1,6,L7);
                code.visitFieldStmt(SGET,6,-1,new Field("Lorg/mortbay/util/TypeUtil;","LF","I"));
                code.visitJumpStmt(IF_EQ,1,6,L7);
                code.visitLabel(L13);
                code.visitStmt2R(ARRAY_LENGTH,6,0);
                code.visitJumpStmt(IF_LT,2,6,L17);
                code.visitLabel(L14);
                code.visitStmt2R(MOVE_OBJECT,5,0);
                code.visitLabel(L15);
                code.visitStmt2R(ARRAY_LENGTH,6,5);
                code.visitStmt2R1N(ADD_INT_LIT16,6,6,256);
                code.visitTypeStmt(NEW_ARRAY,0,6,"[B");
                code.visitLabel(L16);
                code.visitStmt2R(ARRAY_LENGTH,6,5);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 5,7,0,7,6},new Method("Ljava/lang/System;","arraycopy",new String[]{ "Ljava/lang/Object;","I","Ljava/lang/Object;","I","I"},"V"));
                code.visitLabel(L17);
                code.visitStmt2R1N(ADD_INT_LIT8,3,2,1);
                code.visitLabel(L18);
                code.visitStmt2R(INT_TO_BYTE,6,1);
                code.visitStmt3R(APUT_BYTE,6,0,2);
                code.visitLabel(L19);
                code.visitStmt2R(MOVE,2,3);
                code.visitLabel(L20);
                code.visitJumpStmt(GOTO,-1,-1,L5);
                code.visitLabel(L21);
                code.visitFieldStmt(SGET,6,-1,new Field("Lorg/mortbay/util/TypeUtil;","CR","I"));
                code.visitJumpStmt(IF_NE,1,6,L26);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9},new Method("Ljava/io/InputStream;","available",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,6);
                code.visitJumpStmt(IF_LT,6,8,L26);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9},new Method("Ljava/io/InputStream;","markSupported",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,6);
                code.visitJumpStmt(IF_EQZ,6,-1,L26);
                code.visitLabel(L22);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9,8},new Method("Ljava/io/InputStream;","mark",new String[]{ "I"},"V"));
                code.visitLabel(L23);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9},new Method("Ljava/io/InputStream;","read",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitLabel(L24);
                code.visitFieldStmt(SGET,6,-1,new Field("Lorg/mortbay/util/TypeUtil;","LF","I"));
                code.visitJumpStmt(IF_EQ,1,6,L26);
                code.visitLabel(L25);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9},new Method("Ljava/io/InputStream;","reset",new String[]{ },"V"));
                code.visitLabel(L26);
                code.visitStmt2R(MOVE_OBJECT,5,0);
                code.visitLabel(L27);
                code.visitTypeStmt(NEW_ARRAY,0,2,"[B");
                code.visitLabel(L28);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 5,7,0,7,2},new Method("Ljava/lang/System;","arraycopy",new String[]{ "Ljava/lang/Object;","I","Ljava/lang/Object;","I","I"},"V"));
                code.visitStmt2R(MOVE_OBJECT,6,0);
                code.visitLabel(L29);
                code.visitJumpStmt(GOTO,-1,-1,L9);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m014_toHexString(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Lorg/mortbay/util/TypeUtil;","toHexString",new String[]{ "[B"},"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(9);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"b");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(430,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(431,L2);
                ddv.visitStartLocal(1,L2,"buf","Ljava/lang/StringBuffer;",null);
                DexLabel L3=new DexLabel();
                ddv.visitStartLocal(3,L3,"i","I",null);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(433,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(434,L5);
                ddv.visitStartLocal(0,L5,"bi","I",null);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(435,L6);
                ddv.visitStartLocal(2,L6,"c","I",null);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(436,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(437,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(438,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(439,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(440,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(441,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(431,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(443,L14);
                ddv.visitEndLocal(0,L14);
                ddv.visitEndLocal(2,L14);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_16,7, Integer.valueOf(57)); // int: 0x00000039  float:0.000000
                code.visitConstStmt(CONST_16,6, Integer.valueOf(48)); // int: 0x00000030  float:0.000000
                code.visitConstStmt(CONST_16,5, Integer.valueOf(10)); // int: 0x0000000a  float:0.000000
                code.visitLabel(L1);
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Ljava/lang/StringBuffer;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1},new Method("Ljava/lang/StringBuffer;","<init>",new String[]{ },"V"));
                code.visitLabel(L2);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L3);
                code.visitStmt2R(ARRAY_LENGTH,4,8);
                code.visitJumpStmt(IF_GE,3,4,L14);
                code.visitLabel(L4);
                code.visitStmt3R(AGET_BYTE,4,8,3);
                code.visitStmt2R1N(AND_INT_LIT16,0,4,255);
                code.visitLabel(L5);
                code.visitStmt2R1N(DIV_INT_LIT8,4,0,16);
                code.visitStmt2R1N(REM_INT_LIT8,4,4,16);
                code.visitStmt2R1N(ADD_INT_LIT8,2,4,48);
                code.visitLabel(L6);
                code.visitJumpStmt(IF_LE,2,7,L8);
                code.visitLabel(L7);
                code.visitStmt3R(SUB_INT,4,2,6);
                code.visitStmt2R(SUB_INT_2ADDR,4,5);
                code.visitStmt2R1N(ADD_INT_LIT8,2,4,65);
                code.visitLabel(L8);
                code.visitStmt2R(INT_TO_CHAR,4,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,4},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "C"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L9);
                code.visitStmt2R1N(REM_INT_LIT8,4,0,16);
                code.visitStmt2R1N(ADD_INT_LIT8,2,4,48);
                code.visitLabel(L10);
                code.visitJumpStmt(IF_LE,2,7,L12);
                code.visitLabel(L11);
                code.visitStmt3R(SUB_INT,4,2,6);
                code.visitStmt2R(SUB_INT_2ADDR,4,5);
                code.visitStmt2R1N(ADD_INT_LIT8,2,4,97);
                code.visitLabel(L12);
                code.visitStmt2R(INT_TO_CHAR,4,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,4},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "C"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L13);
                code.visitStmt2R1N(ADD_INT_LIT8,3,3,1);
                code.visitJumpStmt(GOTO,-1,-1,L3);
                code.visitLabel(L14);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/lang/StringBuffer;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitStmt1R(RETURN_OBJECT,4);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m015_toHexString(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Lorg/mortbay/util/TypeUtil;","toHexString",new String[]{ "[B","I","I"},"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(11);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"b");
                ddv.visitParameterName(1,"offset");
                ddv.visitParameterName(2,"length");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(449,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(450,L2);
                ddv.visitStartLocal(1,L2,"buf","Ljava/lang/StringBuffer;",null);
                DexLabel L3=new DexLabel();
                ddv.visitStartLocal(3,L3,"i","I",null);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(452,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(453,L5);
                ddv.visitStartLocal(0,L5,"bi","I",null);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(454,L6);
                ddv.visitStartLocal(2,L6,"c","I",null);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(455,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(456,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(457,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(458,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(459,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(460,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(450,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(462,L14);
                ddv.visitEndLocal(0,L14);
                ddv.visitEndLocal(2,L14);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_16,7, Integer.valueOf(57)); // int: 0x00000039  float:0.000000
                code.visitConstStmt(CONST_16,6, Integer.valueOf(48)); // int: 0x00000030  float:0.000000
                code.visitConstStmt(CONST_16,5, Integer.valueOf(10)); // int: 0x0000000a  float:0.000000
                code.visitLabel(L1);
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Ljava/lang/StringBuffer;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1},new Method("Ljava/lang/StringBuffer;","<init>",new String[]{ },"V"));
                code.visitLabel(L2);
                code.visitStmt2R(MOVE,3,9);
                code.visitLabel(L3);
                code.visitStmt3R(ADD_INT,4,9,10);
                code.visitJumpStmt(IF_GE,3,4,L14);
                code.visitLabel(L4);
                code.visitStmt3R(AGET_BYTE,4,8,3);
                code.visitStmt2R1N(AND_INT_LIT16,0,4,255);
                code.visitLabel(L5);
                code.visitStmt2R1N(DIV_INT_LIT8,4,0,16);
                code.visitStmt2R1N(REM_INT_LIT8,4,4,16);
                code.visitStmt2R1N(ADD_INT_LIT8,2,4,48);
                code.visitLabel(L6);
                code.visitJumpStmt(IF_LE,2,7,L8);
                code.visitLabel(L7);
                code.visitStmt3R(SUB_INT,4,2,6);
                code.visitStmt2R(SUB_INT_2ADDR,4,5);
                code.visitStmt2R1N(ADD_INT_LIT8,2,4,65);
                code.visitLabel(L8);
                code.visitStmt2R(INT_TO_CHAR,4,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,4},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "C"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L9);
                code.visitStmt2R1N(REM_INT_LIT8,4,0,16);
                code.visitStmt2R1N(ADD_INT_LIT8,2,4,48);
                code.visitLabel(L10);
                code.visitJumpStmt(IF_LE,2,7,L12);
                code.visitLabel(L11);
                code.visitStmt3R(SUB_INT,4,2,6);
                code.visitStmt2R(SUB_INT_2ADDR,4,5);
                code.visitStmt2R1N(ADD_INT_LIT8,2,4,97);
                code.visitLabel(L12);
                code.visitStmt2R(INT_TO_CHAR,4,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,4},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "C"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L13);
                code.visitStmt2R1N(ADD_INT_LIT8,3,3,1);
                code.visitJumpStmt(GOTO,-1,-1,L3);
                code.visitLabel(L14);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/lang/StringBuffer;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitStmt1R(RETURN_OBJECT,4);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m016_toName(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Lorg/mortbay/util/TypeUtil;","toName",new String[]{ "Ljava/lang/Class;"},"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"type");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(191,L0);
                DexLabel L1=new DexLabel();
                ddv.visitEndLocal(1,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(SGET_OBJECT,0,-1,new Field("Lorg/mortbay/util/TypeUtil;","class2Name","Ljava/util/HashMap;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/util/HashMap;","get",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L1);
                code.visitTypeStmt(CHECK_CAST,1,-1,"Ljava/lang/String;");
                code.visitStmt1R(RETURN_OBJECT,1);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m017_toString(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Lorg/mortbay/util/TypeUtil;","toString",new String[]{ "I"},"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"i");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(288,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(290,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(291,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(292,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(296,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(294,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(295,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(296,L7);
                code.visitLabel(L0);
                code.visitJumpStmt(IF_LTZ,2,-1,L5);
                code.visitFieldStmt(SGET,0,-1,new Field("Lorg/mortbay/util/TypeUtil;","intCacheSize","I"));
                code.visitJumpStmt(IF_GE,2,0,L5);
                code.visitLabel(L1);
                code.visitFieldStmt(SGET_OBJECT,0,-1,new Field("Lorg/mortbay/util/TypeUtil;","integerStrCache","[Ljava/lang/String;"));
                code.visitStmt3R(AGET_OBJECT,0,0,2);
                code.visitJumpStmt(IF_NEZ,0,-1,L3);
                code.visitLabel(L2);
                code.visitFieldStmt(SGET_OBJECT,0,-1,new Field("Lorg/mortbay/util/TypeUtil;","integerStrCache","[Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 2},new Method("Ljava/lang/Integer;","toString",new String[]{ "I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitStmt3R(APUT_OBJECT,1,0,2);
                code.visitLabel(L3);
                code.visitFieldStmt(SGET_OBJECT,0,-1,new Field("Lorg/mortbay/util/TypeUtil;","integerStrCache","[Ljava/lang/String;"));
                code.visitStmt3R(AGET_OBJECT,0,0,2);
                code.visitLabel(L4);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitLabel(L5);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(-1)); // int: 0xffffffff  float:NaN
                code.visitJumpStmt(IF_NE,2,0,L7);
                code.visitLabel(L6);
                code.visitConstStmt(CONST_STRING,0,"-1");
                code.visitJumpStmt(GOTO,-1,-1,L4);
                code.visitLabel(L7);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 2},new Method("Ljava/lang/Integer;","toString",new String[]{ "I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitJumpStmt(GOTO,-1,-1,L4);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m018_toString(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Lorg/mortbay/util/TypeUtil;","toString",new String[]{ "J"},"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"i");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(304,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(306,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(307,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(308,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(312,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(310,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(311,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(312,L7);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_WIDE_16,0,Long.valueOf(0L)); // long: 0x0000000000000000  double:0.000000
                code.visitStmt3R(CMP_LONG,0,3,0);
                code.visitJumpStmt(IF_LTZ,0,-1,L5);
                code.visitFieldStmt(SGET,0,-1,new Field("Lorg/mortbay/util/TypeUtil;","intCacheSize","I"));
                code.visitStmt2R(INT_TO_LONG,0,0);
                code.visitStmt3R(CMP_LONG,0,3,0);
                code.visitJumpStmt(IF_GEZ,0,-1,L5);
                code.visitLabel(L1);
                code.visitFieldStmt(SGET_OBJECT,0,-1,new Field("Lorg/mortbay/util/TypeUtil;","integerStrCache","[Ljava/lang/String;"));
                code.visitStmt2R(LONG_TO_INT,1,3);
                code.visitStmt3R(AGET_OBJECT,0,0,1);
                code.visitJumpStmt(IF_NEZ,0,-1,L3);
                code.visitLabel(L2);
                code.visitFieldStmt(SGET_OBJECT,0,-1,new Field("Lorg/mortbay/util/TypeUtil;","integerStrCache","[Ljava/lang/String;"));
                code.visitStmt2R(LONG_TO_INT,1,3);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 3,4},new Method("Ljava/lang/Long;","toString",new String[]{ "J"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitStmt3R(APUT_OBJECT,2,0,1);
                code.visitLabel(L3);
                code.visitFieldStmt(SGET_OBJECT,0,-1,new Field("Lorg/mortbay/util/TypeUtil;","integerStrCache","[Ljava/lang/String;"));
                code.visitStmt2R(LONG_TO_INT,1,3);
                code.visitStmt3R(AGET_OBJECT,0,0,1);
                code.visitLabel(L4);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitLabel(L5);
                code.visitConstStmt(CONST_WIDE_16,0,Long.valueOf(-1L)); // long: 0xffffffffffffffff  double:NaN
                code.visitStmt3R(CMP_LONG,0,3,0);
                code.visitJumpStmt(IF_NEZ,0,-1,L7);
                code.visitLabel(L6);
                code.visitConstStmt(CONST_STRING,0,"-1");
                code.visitJumpStmt(GOTO,-1,-1,L4);
                code.visitLabel(L7);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 3,4},new Method("Ljava/lang/Long;","toString",new String[]{ "J"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitJumpStmt(GOTO,-1,-1,L4);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m019_toString(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Lorg/mortbay/util/TypeUtil;","toString",new String[]{ "[B","I"},"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(10);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"bytes");
                ddv.visitParameterName(1,"base");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(398,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(399,L2);
                ddv.visitStartLocal(1,L2,"buf","Ljava/lang/StringBuffer;",null);
                DexLabel L3=new DexLabel();
                ddv.visitStartLocal(3,L3,"i","I",null);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(401,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(402,L5);
                ddv.visitStartLocal(0,L5,"bi","I",null);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(403,L6);
                ddv.visitStartLocal(2,L6,"c","I",null);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(404,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(405,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(406,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(407,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(408,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(409,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(399,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(411,L14);
                ddv.visitEndLocal(0,L14);
                ddv.visitEndLocal(2,L14);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_16,7, Integer.valueOf(57)); // int: 0x00000039  float:0.000000
                code.visitConstStmt(CONST_16,6, Integer.valueOf(48)); // int: 0x00000030  float:0.000000
                code.visitConstStmt(CONST_16,5, Integer.valueOf(10)); // int: 0x0000000a  float:0.000000
                code.visitLabel(L1);
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Ljava/lang/StringBuffer;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1},new Method("Ljava/lang/StringBuffer;","<init>",new String[]{ },"V"));
                code.visitLabel(L2);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L3);
                code.visitStmt2R(ARRAY_LENGTH,4,8);
                code.visitJumpStmt(IF_GE,3,4,L14);
                code.visitLabel(L4);
                code.visitStmt3R(AGET_BYTE,4,8,3);
                code.visitStmt2R1N(AND_INT_LIT16,0,4,255);
                code.visitLabel(L5);
                code.visitStmt3R(DIV_INT,4,0,9);
                code.visitStmt2R(REM_INT_2ADDR,4,9);
                code.visitStmt2R1N(ADD_INT_LIT8,2,4,48);
                code.visitLabel(L6);
                code.visitJumpStmt(IF_LE,2,7,L8);
                code.visitLabel(L7);
                code.visitStmt3R(SUB_INT,4,2,6);
                code.visitStmt2R(SUB_INT_2ADDR,4,5);
                code.visitStmt2R1N(ADD_INT_LIT8,2,4,97);
                code.visitLabel(L8);
                code.visitStmt2R(INT_TO_CHAR,4,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,4},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "C"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L9);
                code.visitStmt3R(REM_INT,4,0,9);
                code.visitStmt2R1N(ADD_INT_LIT8,2,4,48);
                code.visitLabel(L10);
                code.visitJumpStmt(IF_LE,2,7,L12);
                code.visitLabel(L11);
                code.visitStmt3R(SUB_INT,4,2,6);
                code.visitStmt2R(SUB_INT_2ADDR,4,5);
                code.visitStmt2R1N(ADD_INT_LIT8,2,4,97);
                code.visitLabel(L12);
                code.visitStmt2R(INT_TO_CHAR,4,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,4},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "C"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L13);
                code.visitStmt2R1N(ADD_INT_LIT8,3,3,1);
                code.visitJumpStmt(GOTO,-1,-1,L3);
                code.visitLabel(L14);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/lang/StringBuffer;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitStmt1R(RETURN_OBJECT,4);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m020_valueOf(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Lorg/mortbay/util/TypeUtil;","valueOf",new String[]{ "Ljava/lang/Class;","Ljava/lang/String;"},"Ljava/lang/Object;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(9);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                DexLabel L3=new DexLabel();
                DexLabel L4=new DexLabel();
                DexLabel L5=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2,L3,L4,L5},new String[]{ "Ljava/lang/NoSuchMethodException;","Ljava/lang/IllegalAccessException;","Ljava/lang/InstantiationException;","Ljava/lang/reflect/InvocationTargetException;"});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"type");
                ddv.visitParameterName(1,"value");
                DexLabel L6=new DexLabel();
                ddv.visitPrologue(L6);
                ddv.visitLineNumber(204,L0);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(236,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(207,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(208,L9);
                ddv.visitStartLocal(2,L9,"m","Ljava/lang/reflect/Method;",null);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(209,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(211,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(213,L12);
                ddv.visitLineNumber(218,L2);
                ddv.visitEndLocal(2,L2);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(236,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(215,L14);
                ddv.visitRestartLocal(2,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(216,L15);
                ddv.visitStartLocal(0,L15,"c","Ljava/lang/reflect/Constructor;",null);
                ddv.visitLineNumber(230,L5);
                ddv.visitEndLocal(2,L5);
                ddv.visitEndLocal(0,L5);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(232,L16);
                ddv.visitStartLocal(1,L16,"e","Ljava/lang/reflect/InvocationTargetException;",null);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(233,L17);
                DexLabel L18=new DexLabel();
                ddv.visitEndLocal(7,L18);
                ddv.visitLineNumber(226,L4);
                ddv.visitEndLocal(1,L4);
                ddv.visitRestartLocal(7,L4);
                ddv.visitLineNumber(222,L3);
                code.visitLabel(L6);
                code.visitConstStmt(CONST_4,6, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L0);
                code.visitConstStmt(CONST_CLASS,3,new DexType("Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7,3},new Method("Ljava/lang/Object;","equals",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitJumpStmt(IF_EQZ,3,-1,L8);
                code.visitStmt2R(MOVE_OBJECT,3,8);
                code.visitLabel(L7);
                code.visitStmt1R(RETURN_OBJECT,3);
                code.visitLabel(L8);
                code.visitFieldStmt(SGET_OBJECT,3,-1,new Field("Lorg/mortbay/util/TypeUtil;","class2Value","Ljava/util/HashMap;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,7},new Method("Ljava/util/HashMap;","get",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitTypeStmt(CHECK_CAST,2,-1,"Ljava/lang/reflect/Method;");
                code.visitLabel(L9);
                code.visitJumpStmt(IF_EQZ,2,-1,L11);
                code.visitLabel(L10);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitConstStmt(CONST_4,4, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitTypeStmt(NEW_ARRAY,4,4,"[Ljava/lang/Object;");
                code.visitConstStmt(CONST_4,5, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitStmt3R(APUT_OBJECT,8,4,5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3,4},new Method("Ljava/lang/reflect/Method;","invoke",new String[]{ "Ljava/lang/Object;","[Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitJumpStmt(GOTO,-1,-1,L7);
                code.visitLabel(L11);
                code.visitFieldStmt(SGET_OBJECT,3,-1,new Field("Ljava/lang/Character;","TYPE","Ljava/lang/Class;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7,3},new Method("Ljava/lang/Object;","equals",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitJumpStmt(IF_NEZ,3,-1,L12);
                code.visitConstStmt(CONST_CLASS,3,new DexType("Ljava/lang/Character;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7,3},new Method("Ljava/lang/Object;","equals",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitJumpStmt(IF_EQZ,3,-1,L14);
                code.visitLabel(L12);
                code.visitTypeStmt(NEW_INSTANCE,3,-1,"Ljava/lang/Character;");
                code.visitConstStmt(CONST_4,4, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8,4},new Method("Ljava/lang/String;","charAt",new String[]{ "I"},"C"));
                code.visitStmt1R(MOVE_RESULT,4);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 3,4},new Method("Ljava/lang/Character;","<init>",new String[]{ "C"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L7);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,3);
                DexLabel L19=new DexLabel();
                code.visitLabel(L19);
                code.visitStmt2R(MOVE_OBJECT,3,6);
                code.visitLabel(L13);
                code.visitJumpStmt(GOTO,-1,-1,L7);
                code.visitLabel(L14);
                code.visitFieldStmt(SGET_OBJECT,3,-1,new Field("Lorg/mortbay/util/TypeUtil;","stringArg","[Ljava/lang/Class;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7,3},new Method("Ljava/lang/Class;","getConstructor",new String[]{ "[Ljava/lang/Class;"},"Ljava/lang/reflect/Constructor;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L15);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitTypeStmt(NEW_ARRAY,3,3,"[Ljava/lang/Object;");
                code.visitConstStmt(CONST_4,4, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitStmt3R(APUT_OBJECT,8,3,4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,3},new Method("Ljava/lang/reflect/Constructor;","newInstance",new String[]{ "[Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitLabel(L1);
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitJumpStmt(GOTO,-1,-1,L7);
                code.visitLabel(L5);
                code.visitStmt1R(MOVE_EXCEPTION,3);
                code.visitStmt2R(MOVE_OBJECT,1,3);
                code.visitLabel(L16);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/lang/reflect/InvocationTargetException;","getTargetException",new String[]{ },"Ljava/lang/Throwable;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitTypeStmt(INSTANCE_OF,3,3,"Ljava/lang/Error;");
                code.visitJumpStmt(IF_EQZ,3,-1,L19);
                code.visitLabel(L17);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/lang/reflect/InvocationTargetException;","getTargetException",new String[]{ },"Ljava/lang/Throwable;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitLabel(L18);
                code.visitTypeStmt(CHECK_CAST,7,-1,"Ljava/lang/Error;");
                code.visitTypeStmt(CHECK_CAST,7,-1,"Ljava/lang/Error;");
                code.visitStmt1R(THROW,7);
                code.visitLabel(L4);
                code.visitStmt1R(MOVE_EXCEPTION,3);
                code.visitJumpStmt(GOTO,-1,-1,L19);
                code.visitLabel(L3);
                code.visitStmt1R(MOVE_EXCEPTION,3);
                code.visitJumpStmt(GOTO,-1,-1,L19);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m021_valueOf(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Lorg/mortbay/util/TypeUtil;","valueOf",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"Ljava/lang/Object;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"type");
                ddv.visitParameterName(1,"value");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(247,L0);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1},new Method("Lorg/mortbay/util/TypeUtil;","fromName",new String[]{ "Ljava/lang/String;"},"Ljava/lang/Class;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0,2},new Method("Lorg/mortbay/util/TypeUtil;","valueOf",new String[]{ "Ljava/lang/Class;","Ljava/lang/String;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
