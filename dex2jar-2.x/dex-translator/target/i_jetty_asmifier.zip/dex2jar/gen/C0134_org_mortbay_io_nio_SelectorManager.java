package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0134_org_mortbay_io_nio_SelectorManager {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(ACC_PUBLIC|ACC_ABSTRACT,"Lorg/mortbay/io/nio/SelectorManager;","Lorg/mortbay/component/AbstractLifeCycle;",new String[]{ });
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("SelectorManager.java");
        if(cv!=null){
            DexAnnotationVisitor av00 = cv.visitAnnotation("Ldalvik/annotation/MemberClasses;", Visibility.SYSTEM);
            if(av00 != null) {
                {
                    DexAnnotationVisitor av01 = av00.visitArray("value");
                    if(av01 != null) {
                        av01.visit(null, new DexType("Lorg/mortbay/io/nio/SelectorManager$SelectSet;"));
                        av01.visitEnd();
                    }
                }
                av00.visitEnd();
            }
        }
        f000__delaySelectKeyUpdate(cv);
        f001__lowResourcesConnections(cv);
        f002__lowResourcesMaxIdleTime(cv);
        f003__maxIdleTime(cv);
        f004__selectSet(cv);
        f005__selectSets(cv);
        f006__set(cv);
        m000__init_(cv);
        m001_access$000(cv);
        m002_access$100(cv);
        m003_access$200(cv);
        m004_access$300(cv);
        m005_acceptChannel(cv);
        m006_connectionFailed(cv);
        m007_dispatch(cv);
        m008_doSelect(cv);
        m009_doStart(cv);
        m010_doStop(cv);
        m011_endPointClosed(cv);
        m012_endPointOpened(cv);
        m013_getLowResourcesConnections(cv);
        m014_getLowResourcesMaxIdleTime(cv);
        m015_getMaxIdleTime(cv);
        m016_getSelectSets(cv);
        m017_isDelaySelectKeyUpdate(cv);
        m018_newConnection(cv);
        m019_newEndPoint(cv);
        m020_register(cv);
        m021_register(cv);
        m022_setDelaySelectKeyUpdate(cv);
        m023_setLowResourcesConnections(cv);
        m024_setLowResourcesMaxIdleTime(cv);
        m025_setMaxIdleTime(cv);
        m026_setSelectSets(cv);
    }
    public static void f000__delaySelectKeyUpdate(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/io/nio/SelectorManager;","_delaySelectKeyUpdate","Z"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f001__lowResourcesConnections(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/io/nio/SelectorManager;","_lowResourcesConnections","J"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f002__lowResourcesMaxIdleTime(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/io/nio/SelectorManager;","_lowResourcesMaxIdleTime","J"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f003__maxIdleTime(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/io/nio/SelectorManager;","_maxIdleTime","J"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f004__selectSet(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE|ACC_TRANSIENT, new Field("Lorg/mortbay/io/nio/SelectorManager;","_selectSet","[Lorg/mortbay/io/nio/SelectorManager$SelectSet;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f005__selectSets(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/io/nio/SelectorManager;","_selectSets","I"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f006__set(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE|ACC_VOLATILE, new Field("Lorg/mortbay/io/nio/SelectorManager;","_set","I"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void m000__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/io/nio/SelectorManager;","<init>",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(43,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(45,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(50,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(272,L4);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1},new Method("Lorg/mortbay/component/AbstractLifeCycle;","<init>",new String[]{ },"V"));
                code.visitLabel(L2);
                code.visitFieldStmt(IPUT_BOOLEAN,0,1,new Field("Lorg/mortbay/io/nio/SelectorManager;","_delaySelectKeyUpdate","Z"));
                code.visitLabel(L3);
                code.visitFieldStmt(IPUT,0,1,new Field("Lorg/mortbay/io/nio/SelectorManager;","_selectSets","I"));
                code.visitLabel(L4);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001_access$000(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_STATIC|ACC_SYNTHETIC, new Method("Lorg/mortbay/io/nio/SelectorManager;","access$000",new String[]{ "Lorg/mortbay/io/nio/SelectorManager;"},"J"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"x0");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(43,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_WIDE,0,2,new Field("Lorg/mortbay/io/nio/SelectorManager;","_lowResourcesConnections","J"));
                code.visitStmt1R(RETURN_WIDE,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m002_access$100(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_STATIC|ACC_SYNTHETIC, new Method("Lorg/mortbay/io/nio/SelectorManager;","access$100",new String[]{ "Lorg/mortbay/io/nio/SelectorManager;"},"J"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"x0");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(43,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_WIDE,0,2,new Field("Lorg/mortbay/io/nio/SelectorManager;","_lowResourcesMaxIdleTime","J"));
                code.visitStmt1R(RETURN_WIDE,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m003_access$200(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_STATIC|ACC_SYNTHETIC, new Method("Lorg/mortbay/io/nio/SelectorManager;","access$200",new String[]{ "Lorg/mortbay/io/nio/SelectorManager;"},"J"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"x0");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(43,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_WIDE,0,2,new Field("Lorg/mortbay/io/nio/SelectorManager;","_maxIdleTime","J"));
                code.visitStmt1R(RETURN_WIDE,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m004_access$300(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_STATIC|ACC_SYNTHETIC, new Method("Lorg/mortbay/io/nio/SelectorManager;","access$300",new String[]{ "Lorg/mortbay/io/nio/SelectorManager;"},"[Lorg/mortbay/io/nio/SelectorManager$SelectSet;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"x0");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(43,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/io/nio/SelectorManager;","_selectSet","[Lorg/mortbay/io/nio/SelectorManager$SelectSet;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m005_acceptChannel(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED|ACC_ABSTRACT, new Method("Lorg/mortbay/io/nio/SelectorManager;","acceptChannel",new String[]{ "Ljava/nio/channels/SelectionKey;"},"Ljava/nio/channels/SocketChannel;"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            mv.visitEnd();
        }
    }
    public static void m006_connectionFailed(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Lorg/mortbay/io/nio/SelectorManager;","connectionFailed",new String[]{ "Ljava/nio/channels/SocketChannel;","Ljava/lang/Throwable;","Ljava/lang/Object;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"channel");
                ddv.visitParameterName(1,"ex");
                ddv.visitParameterName(2,"attachment");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(266,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(267,L1);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 2},new Method("Lorg/mortbay/log/Log;","warn",new String[]{ "Ljava/lang/Throwable;"},"V"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m007_dispatch(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Lorg/mortbay/io/nio/SelectorManager;","dispatch",new String[]{ "Ljava/lang/Runnable;"},"Z"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            mv.visitEnd();
        }
    }
    public static void m008_doSelect(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/io/nio/SelectorManager;","doSelect",new String[]{ "I"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"acceptorID");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(183,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(184,L1);
                ddv.visitStartLocal(0,L1,"sets","[Lorg/mortbay/io/nio/SelectorManager$SelectSet;",null);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(185,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(186,L3);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/io/nio/SelectorManager;","_selectSet","[Lorg/mortbay/io/nio/SelectorManager$SelectSet;"));
                code.visitLabel(L1);
                code.visitJumpStmt(IF_EQZ,0,-1,L3);
                code.visitStmt2R(ARRAY_LENGTH,1,0);
                code.visitJumpStmt(IF_LE,1,3,L3);
                code.visitStmt3R(AGET_OBJECT,1,0,3);
                code.visitJumpStmt(IF_EQZ,1,-1,L3);
                code.visitLabel(L2);
                code.visitStmt3R(AGET_OBJECT,1,0,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Lorg/mortbay/io/nio/SelectorManager$SelectSet;","doSelect",new String[]{ },"V"));
                code.visitLabel(L3);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m009_doStart(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Lorg/mortbay/io/nio/SelectorManager;","doStart",new String[]{ },"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/lang/Exception;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(215,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(216,L1);
                DexLabel L2=new DexLabel();
                ddv.visitStartLocal(0,L2,"i","I",null);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(217,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(216,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(219,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(220,L6);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET,1,3,new Field("Lorg/mortbay/io/nio/SelectorManager;","_selectSets","I"));
                code.visitTypeStmt(NEW_ARRAY,1,1,"[Lorg/mortbay/io/nio/SelectorManager$SelectSet;");
                code.visitFieldStmt(IPUT_OBJECT,1,3,new Field("Lorg/mortbay/io/nio/SelectorManager;","_selectSet","[Lorg/mortbay/io/nio/SelectorManager$SelectSet;"));
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L2);
                code.visitFieldStmt(IGET_OBJECT,1,3,new Field("Lorg/mortbay/io/nio/SelectorManager;","_selectSet","[Lorg/mortbay/io/nio/SelectorManager$SelectSet;"));
                code.visitStmt2R(ARRAY_LENGTH,1,1);
                code.visitJumpStmt(IF_GE,0,1,L5);
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,1,3,new Field("Lorg/mortbay/io/nio/SelectorManager;","_selectSet","[Lorg/mortbay/io/nio/SelectorManager$SelectSet;"));
                code.visitTypeStmt(NEW_INSTANCE,2,-1,"Lorg/mortbay/io/nio/SelectorManager$SelectSet;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2,3,0},new Method("Lorg/mortbay/io/nio/SelectorManager$SelectSet;","<init>",new String[]{ "Lorg/mortbay/io/nio/SelectorManager;","I"},"V"));
                code.visitStmt3R(APUT_OBJECT,2,1,0);
                code.visitLabel(L4);
                code.visitStmt2R1N(ADD_INT_LIT8,0,0,1);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitLabel(L5);
                code.visitMethodStmt(INVOKE_SUPER,new int[]{ 3},new Method("Lorg/mortbay/component/AbstractLifeCycle;","doStart",new String[]{ },"V"));
                code.visitLabel(L6);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m010_doStop(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Lorg/mortbay/io/nio/SelectorManager;","doStop",new String[]{ },"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/lang/Exception;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(226,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(227,L1);
                ddv.visitStartLocal(2,L1,"sets","[Lorg/mortbay/io/nio/SelectorManager$SelectSet;",null);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(228,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(229,L3);
                DexLabel L4=new DexLabel();
                ddv.visitStartLocal(0,L4,"i","I",null);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(231,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(232,L6);
                ddv.visitStartLocal(1,L6,"set","Lorg/mortbay/io/nio/SelectorManager$SelectSet;",null);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(233,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(229,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(235,L9);
                ddv.visitEndLocal(0,L9);
                ddv.visitEndLocal(1,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(236,L10);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,2,4,new Field("Lorg/mortbay/io/nio/SelectorManager;","_selectSet","[Lorg/mortbay/io/nio/SelectorManager$SelectSet;"));
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT_OBJECT,3,4,new Field("Lorg/mortbay/io/nio/SelectorManager;","_selectSet","[Lorg/mortbay/io/nio/SelectorManager$SelectSet;"));
                code.visitLabel(L2);
                code.visitJumpStmt(IF_EQZ,2,-1,L9);
                code.visitLabel(L3);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L4);
                code.visitStmt2R(ARRAY_LENGTH,3,2);
                code.visitJumpStmt(IF_GE,0,3,L9);
                code.visitLabel(L5);
                code.visitStmt3R(AGET_OBJECT,1,2,0);
                code.visitLabel(L6);
                code.visitJumpStmt(IF_EQZ,1,-1,L8);
                code.visitLabel(L7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Lorg/mortbay/io/nio/SelectorManager$SelectSet;","stop",new String[]{ },"V"));
                code.visitLabel(L8);
                code.visitStmt2R1N(ADD_INT_LIT8,0,0,1);
                code.visitJumpStmt(GOTO,-1,-1,L4);
                code.visitLabel(L9);
                code.visitMethodStmt(INVOKE_SUPER,new int[]{ 4},new Method("Lorg/mortbay/component/AbstractLifeCycle;","doStop",new String[]{ },"V"));
                code.visitLabel(L10);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m011_endPointClosed(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED|ACC_ABSTRACT, new Method("Lorg/mortbay/io/nio/SelectorManager;","endPointClosed",new String[]{ "Lorg/mortbay/io/nio/SelectChannelEndPoint;"},"V"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m012_endPointOpened(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED|ACC_ABSTRACT, new Method("Lorg/mortbay/io/nio/SelectorManager;","endPointOpened",new String[]{ "Lorg/mortbay/io/nio/SelectChannelEndPoint;"},"V"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m013_getLowResourcesConnections(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/io/nio/SelectorManager;","getLowResourcesConnections",new String[]{ },"J"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(142,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_WIDE,0,4,new Field("Lorg/mortbay/io/nio/SelectorManager;","_lowResourcesConnections","J"));
                code.visitFieldStmt(IGET,2,4,new Field("Lorg/mortbay/io/nio/SelectorManager;","_selectSets","I"));
                code.visitStmt2R(INT_TO_LONG,2,2);
                code.visitStmt2R(MUL_LONG_2ADDR,0,2);
                code.visitStmt1R(RETURN_WIDE,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m014_getLowResourcesMaxIdleTime(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/io/nio/SelectorManager;","getLowResourcesMaxIdleTime",new String[]{ },"J"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(163,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_WIDE,0,2,new Field("Lorg/mortbay/io/nio/SelectorManager;","_lowResourcesMaxIdleTime","J"));
                code.visitStmt1R(RETURN_WIDE,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m015_getMaxIdleTime(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/io/nio/SelectorManager;","getMaxIdleTime",new String[]{ },"J"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(81,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_WIDE,0,2,new Field("Lorg/mortbay/io/nio/SelectorManager;","_maxIdleTime","J"));
                code.visitStmt1R(RETURN_WIDE,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m016_getSelectSets(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/io/nio/SelectorManager;","getSelectSets",new String[]{ },"I"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(90,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET,0,1,new Field("Lorg/mortbay/io/nio/SelectorManager;","_selectSets","I"));
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m017_isDelaySelectKeyUpdate(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/io/nio/SelectorManager;","isDelaySelectKeyUpdate",new String[]{ },"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(99,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_BOOLEAN,0,1,new Field("Lorg/mortbay/io/nio/SelectorManager;","_delaySelectKeyUpdate","Z"));
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m018_newConnection(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED|ACC_ABSTRACT, new Method("Lorg/mortbay/io/nio/SelectorManager;","newConnection",new String[]{ "Ljava/nio/channels/SocketChannel;","Lorg/mortbay/io/nio/SelectChannelEndPoint;"},"Lorg/mortbay/io/Connection;"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m019_newEndPoint(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED|ACC_ABSTRACT, new Method("Lorg/mortbay/io/nio/SelectorManager;","newEndPoint",new String[]{ "Ljava/nio/channels/SocketChannel;","Lorg/mortbay/io/nio/SelectorManager$SelectSet;","Ljava/nio/channels/SelectionKey;"},"Lorg/mortbay/io/nio/SelectChannelEndPoint;"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            mv.visitEnd();
        }
    }
    public static void m020_register(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/io/nio/SelectorManager;","register",new String[]{ "Ljava/nio/channels/ServerSocketChannel;"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"acceptChannel");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(129,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(130,L1);
                ddv.visitStartLocal(0,L1,"s","I",null);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(131,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(132,L3);
                ddv.visitStartLocal(1,L3,"set","Lorg/mortbay/io/nio/SelectorManager$SelectSet;",null);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(133,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(134,L5);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET,0,3,new Field("Lorg/mortbay/io/nio/SelectorManager;","_set","I"));
                code.visitStmt2R1N(ADD_INT_LIT8,2,0,1);
                code.visitFieldStmt(IPUT,2,3,new Field("Lorg/mortbay/io/nio/SelectorManager;","_set","I"));
                code.visitLabel(L1);
                code.visitFieldStmt(IGET,2,3,new Field("Lorg/mortbay/io/nio/SelectorManager;","_selectSets","I"));
                code.visitStmt2R(REM_INT_2ADDR,0,2);
                code.visitLabel(L2);
                code.visitFieldStmt(IGET_OBJECT,2,3,new Field("Lorg/mortbay/io/nio/SelectorManager;","_selectSet","[Lorg/mortbay/io/nio/SelectorManager$SelectSet;"));
                code.visitStmt3R(AGET_OBJECT,1,2,0);
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,4},new Method("Lorg/mortbay/io/nio/SelectorManager$SelectSet;","addChange",new String[]{ "Ljava/lang/Object;"},"V"));
                code.visitLabel(L4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Lorg/mortbay/io/nio/SelectorManager$SelectSet;","wakeup",new String[]{ },"V"));
                code.visitLabel(L5);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m021_register(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/io/nio/SelectorManager;","register",new String[]{ "Ljava/nio/channels/SocketChannel;","Ljava/lang/Object;"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(7);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"channel");
                ddv.visitParameterName(1,"att");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(110,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(111,L1);
                ddv.visitStartLocal(0,L1,"s","I",null);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(112,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(113,L3);
                ddv.visitStartLocal(2,L3,"sets","[Lorg/mortbay/io/nio/SelectorManager$SelectSet;",null);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(115,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(116,L5);
                ddv.visitStartLocal(1,L5,"set","Lorg/mortbay/io/nio/SelectorManager$SelectSet;",null);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(117,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(119,L7);
                ddv.visitEndLocal(1,L7);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET,0,4,new Field("Lorg/mortbay/io/nio/SelectorManager;","_set","I"));
                code.visitStmt2R1N(ADD_INT_LIT8,3,0,1);
                code.visitFieldStmt(IPUT,3,4,new Field("Lorg/mortbay/io/nio/SelectorManager;","_set","I"));
                code.visitLabel(L1);
                code.visitFieldStmt(IGET,3,4,new Field("Lorg/mortbay/io/nio/SelectorManager;","_selectSets","I"));
                code.visitStmt2R(REM_INT_2ADDR,0,3);
                code.visitLabel(L2);
                code.visitFieldStmt(IGET_OBJECT,2,4,new Field("Lorg/mortbay/io/nio/SelectorManager;","_selectSet","[Lorg/mortbay/io/nio/SelectorManager$SelectSet;"));
                code.visitLabel(L3);
                code.visitJumpStmt(IF_EQZ,2,-1,L7);
                code.visitLabel(L4);
                code.visitStmt3R(AGET_OBJECT,1,2,0);
                code.visitLabel(L5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,5,6},new Method("Lorg/mortbay/io/nio/SelectorManager$SelectSet;","addChange",new String[]{ "Ljava/nio/channels/SocketChannel;","Ljava/lang/Object;"},"V"));
                code.visitLabel(L6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Lorg/mortbay/io/nio/SelectorManager$SelectSet;","wakeup",new String[]{ },"V"));
                code.visitLabel(L7);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m022_setDelaySelectKeyUpdate(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/io/nio/SelectorManager;","setDelaySelectKeyUpdate",new String[]{ "Z"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"delaySelectKeyUpdate");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(195,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(196,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_BOOLEAN,1,0,new Field("Lorg/mortbay/io/nio/SelectorManager;","_delaySelectKeyUpdate","Z"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m023_setLowResourcesConnections(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/io/nio/SelectorManager;","setLowResourcesConnections",new String[]{ "J"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(7);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"lowResourcesConnections");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(154,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(155,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET,0,4,new Field("Lorg/mortbay/io/nio/SelectorManager;","_selectSets","I"));
                code.visitStmt2R(INT_TO_LONG,0,0);
                code.visitStmt2R(ADD_LONG_2ADDR,0,5);
                code.visitConstStmt(CONST_WIDE_16,2,Long.valueOf(1L)); // long: 0x0000000000000001  double:0.000000
                code.visitStmt2R(SUB_LONG_2ADDR,0,2);
                code.visitFieldStmt(IGET,2,4,new Field("Lorg/mortbay/io/nio/SelectorManager;","_selectSets","I"));
                code.visitStmt2R(INT_TO_LONG,2,2);
                code.visitStmt2R(DIV_LONG_2ADDR,0,2);
                code.visitFieldStmt(IPUT_WIDE,0,4,new Field("Lorg/mortbay/io/nio/SelectorManager;","_lowResourcesConnections","J"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m024_setLowResourcesMaxIdleTime(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/io/nio/SelectorManager;","setLowResourcesMaxIdleTime",new String[]{ "J"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"lowResourcesMaxIdleTime");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(173,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(174,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_WIDE,1,0,new Field("Lorg/mortbay/io/nio/SelectorManager;","_lowResourcesMaxIdleTime","J"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m025_setMaxIdleTime(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/io/nio/SelectorManager;","setMaxIdleTime",new String[]{ "J"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"maxIdleTime");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(61,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(62,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_WIDE,1,0,new Field("Lorg/mortbay/io/nio/SelectorManager;","_maxIdleTime","J"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m026_setSelectSets(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/io/nio/SelectorManager;","setSelectSets",new String[]{ "I"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(8);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"selectSets");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(70,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(71,L1);
                ddv.visitStartLocal(0,L1,"lrc","J",null);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(72,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(73,L3);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_WIDE,2,6,new Field("Lorg/mortbay/io/nio/SelectorManager;","_lowResourcesConnections","J"));
                code.visitFieldStmt(IGET,4,6,new Field("Lorg/mortbay/io/nio/SelectorManager;","_selectSets","I"));
                code.visitStmt2R(INT_TO_LONG,4,4);
                code.visitStmt3R(MUL_LONG,0,2,4);
                code.visitLabel(L1);
                code.visitFieldStmt(IPUT,7,6,new Field("Lorg/mortbay/io/nio/SelectorManager;","_selectSets","I"));
                code.visitLabel(L2);
                code.visitFieldStmt(IGET,2,6,new Field("Lorg/mortbay/io/nio/SelectorManager;","_selectSets","I"));
                code.visitStmt2R(INT_TO_LONG,2,2);
                code.visitStmt3R(DIV_LONG,2,0,2);
                code.visitFieldStmt(IPUT_WIDE,2,6,new Field("Lorg/mortbay/io/nio/SelectorManager;","_lowResourcesConnections","J"));
                code.visitLabel(L3);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
