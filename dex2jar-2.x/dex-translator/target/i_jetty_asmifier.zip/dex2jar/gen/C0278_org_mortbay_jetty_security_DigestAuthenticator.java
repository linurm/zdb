package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0278_org_mortbay_jetty_security_DigestAuthenticator {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(ACC_PUBLIC,"Lorg/mortbay/jetty/security/DigestAuthenticator;","Ljava/lang/Object;",new String[]{ "Lorg/mortbay/jetty/security/Authenticator;"});
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("DigestAuthenticator.java");
        if(cv!=null){
            DexAnnotationVisitor av00 = cv.visitAnnotation("Ldalvik/annotation/MemberClasses;", Visibility.SYSTEM);
            if(av00 != null) {
                {
                    DexAnnotationVisitor av01 = av00.visitArray("value");
                    if(av01 != null) {
                        av01.visit(null, new DexType("Lorg/mortbay/jetty/security/DigestAuthenticator$Digest;"));
                        av01.visitEnd();
                    }
                }
                av00.visitEnd();
            }
        }
        f000_maxNonceAge(cv);
        f001_nonceSecret(cv);
        f002_useStale(cv);
        m000__init_(cv);
        m001_authenticate(cv);
        m002_checkNonce(cv);
        m003_getAuthMethod(cv);
        m004_getMaxNonceAge(cv);
        m005_getNonceSecret(cv);
        m006_getUseStale(cv);
        m007_newNonce(cv);
        m008_sendChallenge(cv);
        m009_setMaxNonceAge(cv);
        m010_setNonceSecret(cv);
        m011_setUseStale(cv);
    }
    public static void f000_maxNonceAge(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PROTECTED, new Field("Lorg/mortbay/jetty/security/DigestAuthenticator;","maxNonceAge","J"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f001_nonceSecret(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PROTECTED, new Field("Lorg/mortbay/jetty/security/DigestAuthenticator;","nonceSecret","J"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f002_useStale(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PROTECTED, new Field("Lorg/mortbay/jetty/security/DigestAuthenticator;","useStale","Z"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void m000__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/jetty/security/DigestAuthenticator;","<init>",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(36,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(38,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(39,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(40,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(259,L4);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 4},new Method("Ljava/lang/Object;","<init>",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitConstStmt(CONST_WIDE_16,0,Long.valueOf(0L)); // long: 0x0000000000000000  double:0.000000
                code.visitFieldStmt(IPUT_WIDE,0,4,new Field("Lorg/mortbay/jetty/security/DigestAuthenticator;","maxNonceAge","J"));
                code.visitLabel(L2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Ljava/lang/Object;","hashCode",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitStmt2R(INT_TO_LONG,0,0);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Ljava/lang/System;","currentTimeMillis",new String[]{ },"J"));
                code.visitStmt1R(MOVE_RESULT_WIDE,2);
                code.visitStmt2R(XOR_LONG_2ADDR,0,2);
                code.visitFieldStmt(IPUT_WIDE,0,4,new Field("Lorg/mortbay/jetty/security/DigestAuthenticator;","nonceSecret","J"));
                code.visitLabel(L3);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT_BOOLEAN,0,4,new Field("Lorg/mortbay/jetty/security/DigestAuthenticator;","useStale","Z"));
                code.visitLabel(L4);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001_authenticate(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/security/DigestAuthenticator;","authenticate",new String[]{ "Lorg/mortbay/jetty/security/UserRealm;","Ljava/lang/String;","Lorg/mortbay/jetty/Request;","Lorg/mortbay/jetty/Response;"},"Ljava/security/Principal;"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(23);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"realm");
                ddv.visitParameterName(1,"pathInContext");
                ddv.visitParameterName(2,"request");
                ddv.visitParameterName(3,"response");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(57,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(58,L1);
                ddv.visitStartLocal(11,L1,"stale","Z",null);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(59,L2);
                ddv.visitStartLocal(14,L2,"user","Ljava/security/Principal;",null);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(61,L3);
                ddv.visitStartLocal(6,L3,"credentials","Ljava/lang/String;",null);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(63,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(64,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(68,L6);
                ddv.visitStartLocal(13,L6,"tokenizer","Lorg/mortbay/util/QuotedStringTokenizer;",null);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(69,L7);
                ddv.visitStartLocal(7,L7,"digest","Lorg/mortbay/jetty/security/DigestAuthenticator$Digest;",null);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(70,L8);
                ddv.visitStartLocal(8,L8,"last","Ljava/lang/String;",null);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(73,L9);
                ddv.visitStartLocal(10,L9,"name","Ljava/lang/String;",null);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(75,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(76,L11);
                ddv.visitStartLocal(12,L11,"tok","Ljava/lang/String;",null);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(78,L12);
                ddv.visitStartLocal(5,L12,"c","C",null);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(90,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(91,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(93,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(94,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(76,L17);
                ddv.visitEndLocal(5,L17);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(81,L18);
                ddv.visitRestartLocal(5,L18);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(82,L19);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(83,L20);
                DexLabel L21=new DexLabel();
                ddv.visitLineNumber(85,L21);
                DexLabel L22=new DexLabel();
                ddv.visitLineNumber(95,L22);
                DexLabel L23=new DexLabel();
                ddv.visitLineNumber(96,L23);
                DexLabel L24=new DexLabel();
                ddv.visitLineNumber(97,L24);
                DexLabel L25=new DexLabel();
                ddv.visitLineNumber(98,L25);
                DexLabel L26=new DexLabel();
                ddv.visitLineNumber(99,L26);
                DexLabel L27=new DexLabel();
                ddv.visitLineNumber(100,L27);
                DexLabel L28=new DexLabel();
                ddv.visitLineNumber(101,L28);
                DexLabel L29=new DexLabel();
                ddv.visitLineNumber(102,L29);
                DexLabel L30=new DexLabel();
                ddv.visitLineNumber(103,L30);
                DexLabel L31=new DexLabel();
                ddv.visitLineNumber(104,L31);
                DexLabel L32=new DexLabel();
                ddv.visitLineNumber(105,L32);
                DexLabel L33=new DexLabel();
                ddv.visitLineNumber(106,L33);
                DexLabel L34=new DexLabel();
                ddv.visitLineNumber(107,L34);
                DexLabel L35=new DexLabel();
                ddv.visitLineNumber(108,L35);
                DexLabel L36=new DexLabel();
                ddv.visitLineNumber(114,L36);
                ddv.visitEndLocal(12,L36);
                ddv.visitEndLocal(5,L36);
                DexLabel L37=new DexLabel();
                ddv.visitLineNumber(115,L37);
                ddv.visitStartLocal(9,L37,"n","I",null);
                DexLabel L38=new DexLabel();
                ddv.visitLineNumber(116,L38);
                DexLabel L39=new DexLabel();
                ddv.visitLineNumber(120,L39);
                DexLabel L40=new DexLabel();
                ddv.visitLineNumber(121,L40);
                DexLabel L41=new DexLabel();
                ddv.visitLineNumber(130,L41);
                ddv.visitEndLocal(13,L41);
                ddv.visitEndLocal(7,L41);
                ddv.visitEndLocal(8,L41);
                ddv.visitEndLocal(10,L41);
                ddv.visitEndLocal(9,L41);
                DexLabel L42=new DexLabel();
                ddv.visitLineNumber(131,L42);
                DexLabel L43=new DexLabel();
                ddv.visitLineNumber(133,L43);
                DexLabel L44=new DexLabel();
                ddv.visitLineNumber(117,L44);
                ddv.visitRestartLocal(7,L44);
                ddv.visitRestartLocal(8,L44);
                ddv.visitRestartLocal(9,L44);
                ddv.visitRestartLocal(10,L44);
                ddv.visitRestartLocal(13,L44);
                DexLabel L45=new DexLabel();
                ddv.visitLineNumber(118,L45);
                DexLabel L46=new DexLabel();
                ddv.visitLineNumber(124,L46);
                DexLabel L47=new DexLabel();
                ddv.visitLineNumber(125,L47);
                DexLabel L48=new DexLabel();
                ddv.visitLineNumber(78,L48);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,11, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,14, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L2);
                code.visitConstStmt(CONST_STRING,15,"Authorization");
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,21);
                code.visitStmt2R(MOVE_OBJECT,1,15);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Lorg/mortbay/jetty/Request;","getHeader",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitLabel(L3);
                code.visitJumpStmt(IF_EQZ,6,-1,L41);
                code.visitLabel(L4);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Lorg/mortbay/log/Log;","isDebugEnabled",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,15);
                code.visitJumpStmt(IF_EQZ,15,-1,L5);
                code.visitTypeStmt(NEW_INSTANCE,15,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 15},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,16,"Credentials: ");
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 15,16},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,15);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 15,6},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,15);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 15},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,15);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 15},new Method("Lorg/mortbay/log/Log;","debug",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L5);
                code.visitTypeStmt(NEW_INSTANCE,13,-1,"Lorg/mortbay/util/QuotedStringTokenizer;");
                code.visitConstStmt(CONST_STRING,15,"=, ");
                code.visitConstStmt(CONST_16,16, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitConstStmt(CONST_16,17, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitStmt2R(MOVE_OBJECT,0,13);
                code.visitStmt2R(MOVE_OBJECT,1,6);
                code.visitStmt2R(MOVE_OBJECT,2,15);
                code.visitStmt2R(MOVE_FROM16,3,16);
                code.visitStmt2R(MOVE_FROM16,4,17);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1,2,3,4},new Method("Lorg/mortbay/util/QuotedStringTokenizer;","<init>",new String[]{ "Ljava/lang/String;","Ljava/lang/String;","Z","Z"},"V"));
                code.visitLabel(L6);
                code.visitTypeStmt(NEW_INSTANCE,7,-1,"Lorg/mortbay/jetty/security/DigestAuthenticator$Digest;");
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 21},new Method("Lorg/mortbay/jetty/Request;","getMethod",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,15);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 7,15},new Method("Lorg/mortbay/jetty/security/DigestAuthenticator$Digest;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L7);
                code.visitConstStmt(CONST_4,8, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L8);
                code.visitConstStmt(CONST_4,10, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L9);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 13},new Method("Lorg/mortbay/util/QuotedStringTokenizer;","hasMoreTokens",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,15);
                code.visitJumpStmt(IF_EQZ,15,-1,L36);
                code.visitLabel(L10);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 13},new Method("Lorg/mortbay/util/QuotedStringTokenizer;","nextToken",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,12);
                code.visitLabel(L11);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 12},new Method("Ljava/lang/String;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,15);
                code.visitConstStmt(CONST_16,16, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitStmt2R(MOVE,0,15);
                code.visitStmt2R(MOVE_FROM16,1,16);
                code.visitJumpStmt(IF_NE,0,1,L17);
                code.visitConstStmt(CONST_4,15, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 12,15},new Method("Ljava/lang/String;","charAt",new String[]{ "I"},"C"));
                code.visitStmt1R(MOVE_RESULT,15);
                code.visitStmt2R(MOVE,5,15);
                code.visitLabel(L12);
                code.visitSparseSwitchStmt(SPARSE_SWITCH,5,new int[]{ 32,44,61},new DexLabel[]{L9,L21,L18});
                code.visitLabel(L13);
                code.visitStmt2R(MOVE_OBJECT,8,12);
                code.visitLabel(L14);
                code.visitJumpStmt(IF_EQZ,10,-1,L9);
                code.visitLabel(L15);
                code.visitConstStmt(CONST_STRING,15,"username");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 15,10},new Method("Ljava/lang/String;","equalsIgnoreCase",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,15);
                code.visitJumpStmt(IF_EQZ,15,-1,L22);
                code.visitLabel(L16);
                code.visitFieldStmt(IPUT_OBJECT,12,7,new Field("Lorg/mortbay/jetty/security/DigestAuthenticator$Digest;","username","Ljava/lang/String;"));
                code.visitJumpStmt(GOTO,-1,-1,L9);
                code.visitLabel(L17);
                code.visitConstStmt(CONST_4,15, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitStmt2R(MOVE,5,15);
                code.visitJumpStmt(GOTO,-1,-1,L12);
                code.visitLabel(L18);
                code.visitStmt2R(MOVE_OBJECT,10,8);
                code.visitLabel(L19);
                code.visitStmt2R(MOVE_OBJECT,8,12);
                code.visitLabel(L20);
                code.visitJumpStmt(GOTO,-1,-1,L9);
                code.visitLabel(L21);
                code.visitConstStmt(CONST_4,10, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L9);
                code.visitLabel(L22);
                code.visitConstStmt(CONST_STRING,15,"realm");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 15,10},new Method("Ljava/lang/String;","equalsIgnoreCase",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,15);
                code.visitJumpStmt(IF_EQZ,15,-1,L24);
                code.visitLabel(L23);
                code.visitFieldStmt(IPUT_OBJECT,12,7,new Field("Lorg/mortbay/jetty/security/DigestAuthenticator$Digest;","realm","Ljava/lang/String;"));
                code.visitJumpStmt(GOTO,-1,-1,L9);
                code.visitLabel(L24);
                code.visitConstStmt(CONST_STRING,15,"nonce");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 15,10},new Method("Ljava/lang/String;","equalsIgnoreCase",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,15);
                code.visitJumpStmt(IF_EQZ,15,-1,L26);
                code.visitLabel(L25);
                code.visitFieldStmt(IPUT_OBJECT,12,7,new Field("Lorg/mortbay/jetty/security/DigestAuthenticator$Digest;","nonce","Ljava/lang/String;"));
                code.visitJumpStmt(GOTO,-1,-1,L9);
                code.visitLabel(L26);
                code.visitConstStmt(CONST_STRING,15,"nc");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 15,10},new Method("Ljava/lang/String;","equalsIgnoreCase",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,15);
                code.visitJumpStmt(IF_EQZ,15,-1,L28);
                code.visitLabel(L27);
                code.visitFieldStmt(IPUT_OBJECT,12,7,new Field("Lorg/mortbay/jetty/security/DigestAuthenticator$Digest;","nc","Ljava/lang/String;"));
                code.visitJumpStmt(GOTO,-1,-1,L9);
                code.visitLabel(L28);
                code.visitConstStmt(CONST_STRING,15,"cnonce");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 15,10},new Method("Ljava/lang/String;","equalsIgnoreCase",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,15);
                code.visitJumpStmt(IF_EQZ,15,-1,L30);
                code.visitLabel(L29);
                code.visitFieldStmt(IPUT_OBJECT,12,7,new Field("Lorg/mortbay/jetty/security/DigestAuthenticator$Digest;","cnonce","Ljava/lang/String;"));
                code.visitJumpStmt(GOTO,-1,-1,L9);
                code.visitLabel(L30);
                code.visitConstStmt(CONST_STRING,15,"qop");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 15,10},new Method("Ljava/lang/String;","equalsIgnoreCase",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,15);
                code.visitJumpStmt(IF_EQZ,15,-1,L32);
                code.visitLabel(L31);
                code.visitFieldStmt(IPUT_OBJECT,12,7,new Field("Lorg/mortbay/jetty/security/DigestAuthenticator$Digest;","qop","Ljava/lang/String;"));
                code.visitJumpStmt(GOTO,-1,-1,L9);
                code.visitLabel(L32);
                code.visitConstStmt(CONST_STRING,15,"uri");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 15,10},new Method("Ljava/lang/String;","equalsIgnoreCase",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,15);
                code.visitJumpStmt(IF_EQZ,15,-1,L34);
                code.visitLabel(L33);
                code.visitFieldStmt(IPUT_OBJECT,12,7,new Field("Lorg/mortbay/jetty/security/DigestAuthenticator$Digest;","uri","Ljava/lang/String;"));
                code.visitJumpStmt(GOTO,-1,-1,L9);
                code.visitLabel(L34);
                code.visitConstStmt(CONST_STRING,15,"response");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 15,10},new Method("Ljava/lang/String;","equalsIgnoreCase",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,15);
                code.visitJumpStmt(IF_EQZ,15,-1,L9);
                code.visitLabel(L35);
                code.visitFieldStmt(IPUT_OBJECT,12,7,new Field("Lorg/mortbay/jetty/security/DigestAuthenticator$Digest;","response","Ljava/lang/String;"));
                code.visitJumpStmt(GOTO,-1,-1,L9);
                code.visitLabel(L36);
                code.visitFieldStmt(IGET_OBJECT,15,7,new Field("Lorg/mortbay/jetty/security/DigestAuthenticator$Digest;","nonce","Ljava/lang/String;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,18);
                code.visitStmt2R(MOVE_OBJECT,1,15);
                code.visitStmt2R(MOVE_OBJECT_FROM16,2,21);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1,2},new Method("Lorg/mortbay/jetty/security/DigestAuthenticator;","checkNonce",new String[]{ "Ljava/lang/String;","Lorg/mortbay/jetty/Request;"},"I"));
                code.visitStmt1R(MOVE_RESULT,9);
                code.visitLabel(L37);
                code.visitJumpStmt(IF_LEZ,9,-1,L44);
                code.visitLabel(L38);
                code.visitFieldStmt(IGET_OBJECT,15,7,new Field("Lorg/mortbay/jetty/security/DigestAuthenticator$Digest;","username","Ljava/lang/String;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,19);
                code.visitStmt2R(MOVE_OBJECT,1,15);
                code.visitStmt2R(MOVE_OBJECT,2,7);
                code.visitStmt2R(MOVE_OBJECT_FROM16,3,21);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,1,2,3},new Method("Lorg/mortbay/jetty/security/UserRealm;","authenticate",new String[]{ "Ljava/lang/String;","Ljava/lang/Object;","Lorg/mortbay/jetty/Request;"},"Ljava/security/Principal;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,14);
                code.visitLabel(L39);
                code.visitJumpStmt(IF_NEZ,14,-1,L46);
                code.visitLabel(L40);
                code.visitTypeStmt(NEW_INSTANCE,15,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 15},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,16,"AUTH FAILURE: user ");
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 15,16},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,15);
                code.visitStmt2R(MOVE_OBJECT,0,7);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/security/DigestAuthenticator$Digest;","username","Ljava/lang/String;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,16,0);
                code.visitMethodStmt(INVOKE_STATIC_RANGE,new int[]{ 16},new Method("Lorg/mortbay/util/StringUtil;","printable",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,16);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 15,16},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,15);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 15},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,15);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 15},new Method("Lorg/mortbay/log/Log;","warn",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L41);
                code.visitJumpStmt(IF_NEZ,14,-1,L43);
                code.visitJumpStmt(IF_EQZ,22,-1,L43);
                code.visitLabel(L42);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,18);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,19);
                code.visitStmt2R(MOVE_OBJECT_FROM16,2,21);
                code.visitStmt2R(MOVE_OBJECT_FROM16,3,22);
                code.visitStmt2R(MOVE,4,11);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1,2,3,4},new Method("Lorg/mortbay/jetty/security/DigestAuthenticator;","sendChallenge",new String[]{ "Lorg/mortbay/jetty/security/UserRealm;","Lorg/mortbay/jetty/Request;","Lorg/mortbay/jetty/Response;","Z"},"V"));
                code.visitLabel(L43);
                code.visitStmt1R(RETURN_OBJECT,14);
                code.visitLabel(L44);
                code.visitJumpStmt(IF_NEZ,9,-1,L39);
                code.visitLabel(L45);
                code.visitConstStmt(CONST_4,11, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L39);
                code.visitLabel(L46);
                code.visitConstStmt(CONST_STRING,15,"DIGEST");
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,21);
                code.visitStmt2R(MOVE_OBJECT,1,15);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Lorg/mortbay/jetty/Request;","setAuthType",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L47);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,21);
                code.visitStmt2R(MOVE_OBJECT,1,14);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Lorg/mortbay/jetty/Request;","setUserPrincipal",new String[]{ "Ljava/security/Principal;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L41);
                code.visitLabel(L48);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m002_checkNonce(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/security/DigestAuthenticator;","checkNonce",new String[]{ "Ljava/lang/String;","Lorg/mortbay/jetty/Request;"},"I"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(26);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ "Ljava/lang/Exception;"});
                DexLabel L3=new DexLabel();
                DexLabel L4=new DexLabel();
                DexLabel L5=new DexLabel();
                code.visitTryCatch(L3,L4,new DexLabel[]{L5},new String[]{ "Ljava/lang/Exception;"});
                DexLabel L6=new DexLabel();
                DexLabel L7=new DexLabel();
                code.visitTryCatch(L6,L7,new DexLabel[]{L2},new String[]{ "Ljava/lang/Exception;"});
                DexLabel L8=new DexLabel();
                DexLabel L9=new DexLabel();
                code.visitTryCatch(L8,L9,new DexLabel[]{L2},new String[]{ "Ljava/lang/Exception;"});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"nonce");
                ddv.visitParameterName(1,"request");
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(209,L0);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(210,L10);
                ddv.visitStartLocal(11,L10,"n","[B",null);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(211,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(253,L12);
                ddv.visitEndLocal(11,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(213,L13);
                ddv.visitRestartLocal(11,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(214,L14);
                ddv.visitStartLocal(15,L14,"ts","J",null);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(215,L15);
                ddv.visitStartLocal(13,L15,"sk","J",null);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(216,L16);
                ddv.visitStartLocal(12,L16,"n2","[B",null);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(217,L17);
                DexLabel L18=new DexLabel();
                ddv.visitStartLocal(9,L18,"i","I",null);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(219,L19);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(220,L20);
                DexLabel L21=new DexLabel();
                ddv.visitLineNumber(221,L21);
                DexLabel L22=new DexLabel();
                ddv.visitLineNumber(217,L22);
                DexLabel L23=new DexLabel();
                ddv.visitLineNumber(224,L23);
                DexLabel L24=new DexLabel();
                ddv.visitLineNumber(225,L24);
                ddv.visitStartLocal(5,L24,"age","J",null);
                ddv.visitLineNumber(227,L1);
                ddv.visitLineNumber(230,L3);
                ddv.visitStartLocal(8,L3,"hash","[B",null);
                DexLabel L25=new DexLabel();
                ddv.visitLineNumber(231,L25);
                ddv.visitStartLocal(10,L25,"md","Ljava/security/MessageDigest;",null);
                DexLabel L26=new DexLabel();
                ddv.visitLineNumber(232,L26);
                DexLabel L27=new DexLabel();
                ddv.visitLineNumber(233,L27);
                DexLabel L28=new DexLabel();
                ddv.visitLineNumber(240,L28);
                ddv.visitEndLocal(10,L28);
                DexLabel L29=new DexLabel();
                ddv.visitLineNumber(241,L29);
                DexLabel L30=new DexLabel();
                ddv.visitLineNumber(242,L30);
                ddv.visitLineNumber(235,L5);
                DexLabel L31=new DexLabel();
                ddv.visitLineNumber(237,L31);
                ddv.visitStartLocal(7,L31,"e","Ljava/lang/Exception;",null);
                ddv.visitLineNumber(249,L2);
                ddv.visitEndLocal(11,L2);
                ddv.visitEndLocal(15,L2);
                ddv.visitEndLocal(13,L2);
                ddv.visitEndLocal(12,L2);
                ddv.visitEndLocal(9,L2);
                ddv.visitEndLocal(5,L2);
                ddv.visitEndLocal(8,L2);
                ddv.visitEndLocal(7,L2);
                DexLabel L32=new DexLabel();
                ddv.visitLineNumber(251,L32);
                ddv.visitRestartLocal(7,L32);
                DexLabel L33=new DexLabel();
                ddv.visitLineNumber(253,L33);
                DexLabel L34=new DexLabel();
                ddv.visitLineNumber(240,L34);
                ddv.visitEndLocal(7,L34);
                ddv.visitRestartLocal(5,L34);
                ddv.visitRestartLocal(8,L34);
                ddv.visitRestartLocal(9,L34);
                ddv.visitRestartLocal(11,L34);
                ddv.visitRestartLocal(12,L34);
                ddv.visitRestartLocal(13,L34);
                ddv.visitRestartLocal(15,L34);
                ddv.visitLineNumber(244,L8);
                DexLabel L35=new DexLabel();
                ddv.visitLineNumber(245,L35);
                DexLabel L36=new DexLabel();
                ddv.visitLineNumber(247,L36);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 24},new Method("Ljava/lang/String;","toCharArray",new String[]{ },"[C"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,17);
                code.visitMethodStmt(INVOKE_STATIC_RANGE,new int[]{ 17},new Method("Lorg/mortbay/jetty/security/B64Code;","decode",new String[]{ "[C"},"[B"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,11);
                code.visitLabel(L10);
                code.visitStmt2R(MOVE_OBJECT,0,11);
                code.visitStmt2R(ARRAY_LENGTH,0,0);
                code.visitStmt2R(MOVE_FROM16,17,0);
                code.visitConstStmt(CONST_16,18, Integer.valueOf(24)); // int: 0x00000018  float:0.000000
                code.visitStmt2R(MOVE_FROM16,0,17);
                code.visitStmt2R(MOVE_FROM16,1,18);
                code.visitJumpStmt(IF_EQ,0,1,L13);
                code.visitLabel(L11);
                code.visitConstStmt(CONST_16,17, Integer.valueOf(-1)); // int: 0xffffffff  float:NaN
                code.visitLabel(L12);
                code.visitStmt1R(RETURN,17);
                code.visitLabel(L13);
                code.visitConstStmt(CONST_WIDE_16,15,Long.valueOf(0L)); // long: 0x0000000000000000  double:0.000000
                code.visitLabel(L14);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,23);
                code.visitFieldStmt(IGET_WIDE,0,0,new Field("Lorg/mortbay/jetty/security/DigestAuthenticator;","nonceSecret","J"));
                code.visitStmt2R(MOVE_WIDE,13,0);
                code.visitLabel(L15);
                code.visitConstStmt(CONST_16,17, Integer.valueOf(16)); // int: 0x00000010  float:0.000000
                code.visitStmt2R(MOVE_FROM16,0,17);
                code.visitTypeStmt(NEW_ARRAY,0,0,"[B");
                code.visitStmt2R(MOVE_OBJECT,12,0);
                code.visitLabel(L16);
                code.visitConstStmt(CONST_16,17, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitConstStmt(CONST_16,18, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitConstStmt(CONST_16,19, Integer.valueOf(8)); // int: 0x00000008  float:0.000000
                code.visitStmt2R(MOVE_OBJECT,0,11);
                code.visitStmt2R(MOVE_FROM16,1,17);
                code.visitStmt2R(MOVE_OBJECT,2,12);
                code.visitStmt2R(MOVE_FROM16,3,18);
                code.visitStmt2R(MOVE_FROM16,4,19);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0,1,2,3,4},new Method("Ljava/lang/System;","arraycopy",new String[]{ "Ljava/lang/Object;","I","Ljava/lang/Object;","I","I"},"V"));
                code.visitLabel(L17);
                code.visitConstStmt(CONST_4,9, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L18);
                code.visitConstStmt(CONST_16,17, Integer.valueOf(8)); // int: 0x00000008  float:0.000000
                code.visitStmt2R(MOVE,0,9);
                code.visitStmt2R(MOVE_FROM16,1,17);
                code.visitJumpStmt(IF_GE,0,1,L23);
                code.visitLabel(L19);
                code.visitStmt2R1N(ADD_INT_LIT8,17,9,8);
                code.visitConstStmt(CONST_WIDE_16,18,Long.valueOf(255L)); // long: 0x00000000000000ff  double:0.000000
                code.visitStmt3R(AND_LONG,18,18,13);
                code.visitStmt2R(MOVE_WIDE_FROM16,0,18);
                code.visitStmt2R(LONG_TO_INT,0,0);
                code.visitStmt2R(MOVE_FROM16,18,0);
                code.visitStmt2R(MOVE_FROM16,0,18);
                code.visitStmt2R(INT_TO_BYTE,0,0);
                code.visitStmt2R(MOVE_FROM16,18,0);
                code.visitStmt3R(APUT_BYTE,18,12,17);
                code.visitLabel(L20);
                code.visitConstStmt(CONST_16,17, Integer.valueOf(8)); // int: 0x00000008  float:0.000000
                code.visitStmt3R(SHR_LONG,13,13,17);
                code.visitLabel(L21);
                code.visitConstStmt(CONST_16,17, Integer.valueOf(8)); // int: 0x00000008  float:0.000000
                code.visitStmt3R(SHL_LONG,17,15,17);
                code.visitConstStmt(CONST_WIDE_16,19,Long.valueOf(255L)); // long: 0x00000000000000ff  double:0.000000
                code.visitConstStmt(CONST_16,21, Integer.valueOf(7)); // int: 0x00000007  float:0.000000
                code.visitStmt3R(SUB_INT,21,21,9);
                code.visitStmt3R(AGET_BYTE,21,11,21);
                code.visitStmt2R(MOVE_FROM16,0,21);
                code.visitStmt2R(INT_TO_LONG,0,0);
                code.visitStmt2R(MOVE_WIDE_FROM16,21,0);
                code.visitStmt3R(AND_LONG,19,19,21);
                code.visitStmt3R(ADD_LONG,15,17,19);
                code.visitLabel(L22);
                code.visitStmt2R1N(ADD_INT_LIT8,9,9,1);
                code.visitJumpStmt(GOTO,-1,-1,L18);
                code.visitLabel(L23);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 25},new Method("Lorg/mortbay/jetty/Request;","getTimeStamp",new String[]{ },"J"));
                code.visitStmt1R(MOVE_RESULT_WIDE,17);
                code.visitStmt3R(SUB_LONG,5,17,15);
                code.visitLabel(L24);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Lorg/mortbay/log/Log;","isDebugEnabled",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,17);
                code.visitJumpStmt(IF_EQZ,17,-1,L1);
                code.visitTypeStmt(NEW_INSTANCE,17,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT_RANGE,new int[]{ 17},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,18,"age=");
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 17,18},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,17);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,17);
                code.visitStmt2R(MOVE_WIDE,1,5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1,2},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "J"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,17);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 17},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,17);
                code.visitMethodStmt(INVOKE_STATIC_RANGE,new int[]{ 17},new Method("Lorg/mortbay/log/Log;","debug",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,8, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L3);
                code.visitConstStmt(CONST_STRING,17,"MD5");
                code.visitMethodStmt(INVOKE_STATIC_RANGE,new int[]{ 17},new Method("Ljava/security/MessageDigest;","getInstance",new String[]{ "Ljava/lang/String;"},"Ljava/security/MessageDigest;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,10);
                code.visitLabel(L25);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10},new Method("Ljava/security/MessageDigest;","reset",new String[]{ },"V"));
                code.visitLabel(L26);
                code.visitConstStmt(CONST_16,17, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitConstStmt(CONST_16,18, Integer.valueOf(16)); // int: 0x00000010  float:0.000000
                code.visitStmt2R(MOVE_OBJECT,0,10);
                code.visitStmt2R(MOVE_OBJECT,1,12);
                code.visitStmt2R(MOVE_FROM16,2,17);
                code.visitStmt2R(MOVE_FROM16,3,18);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1,2,3},new Method("Ljava/security/MessageDigest;","update",new String[]{ "[B","I","I"},"V"));
                code.visitLabel(L27);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10},new Method("Ljava/security/MessageDigest;","digest",new String[]{ },"[B"));
                code.visitLabel(L4);
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitLabel(L28);
                code.visitConstStmt(CONST_4,9, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                DexLabel L37=new DexLabel();
                code.visitLabel(L37);
                code.visitConstStmt(CONST_16,17, Integer.valueOf(16)); // int: 0x00000010  float:0.000000
                code.visitStmt2R(MOVE,0,9);
                code.visitStmt2R(MOVE_FROM16,1,17);
                code.visitJumpStmt(IF_GE,0,1,L8);
                code.visitLabel(L29);
                code.visitStmt2R1N(ADD_INT_LIT8,17,9,8);
                code.visitLabel(L6);
                code.visitStmt3R(AGET_BYTE,17,11,17);
                code.visitStmt3R(AGET_BYTE,18,8,9);
                code.visitStmt2R(MOVE_FROM16,0,17);
                code.visitStmt2R(MOVE_FROM16,1,18);
                code.visitJumpStmt(IF_EQ,0,1,L34);
                code.visitLabel(L30);
                code.visitConstStmt(CONST_16,17, Integer.valueOf(-1)); // int: 0xffffffff  float:NaN
                code.visitJumpStmt(GOTO_16,-1,-1,L12);
                code.visitLabel(L5);
                code.visitStmt1R(MOVE_EXCEPTION,17);
                code.visitStmt2R(MOVE_OBJECT_FROM16,7,17);
                code.visitLabel(L31);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 7},new Method("Lorg/mortbay/log/Log;","warn",new String[]{ "Ljava/lang/Throwable;"},"V"));
                code.visitLabel(L7);
                code.visitJumpStmt(GOTO,-1,-1,L28);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,17);
                code.visitStmt2R(MOVE_OBJECT_FROM16,7,17);
                code.visitLabel(L32);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 7},new Method("Lorg/mortbay/log/Log;","ignore",new String[]{ "Ljava/lang/Throwable;"},"V"));
                code.visitLabel(L33);
                code.visitConstStmt(CONST_16,17, Integer.valueOf(-1)); // int: 0xffffffff  float:NaN
                code.visitJumpStmt(GOTO_16,-1,-1,L12);
                code.visitLabel(L34);
                code.visitStmt2R1N(ADD_INT_LIT8,9,9,1);
                code.visitJumpStmt(GOTO,-1,-1,L37);
                code.visitLabel(L8);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,23);
                code.visitFieldStmt(IGET_WIDE,0,0,new Field("Lorg/mortbay/jetty/security/DigestAuthenticator;","maxNonceAge","J"));
                code.visitStmt2R(MOVE_WIDE_FROM16,17,0);
                code.visitConstStmt(CONST_WIDE_16,19,Long.valueOf(0L)); // long: 0x0000000000000000  double:0.000000
                code.visitStmt3R(CMP_LONG,17,17,19);
                code.visitJumpStmt(IF_LEZ,17,-1,L36);
                code.visitConstStmt(CONST_WIDE_16,17,Long.valueOf(0L)); // long: 0x0000000000000000  double:0.000000
                code.visitStmt3R(CMP_LONG,17,5,17);
                code.visitJumpStmt(IF_LTZ,17,-1,L35);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,23);
                code.visitFieldStmt(IGET_WIDE,0,0,new Field("Lorg/mortbay/jetty/security/DigestAuthenticator;","maxNonceAge","J"));
                code.visitStmt2R(MOVE_WIDE_FROM16,17,0);
                code.visitLabel(L9);
                code.visitStmt3R(CMP_LONG,17,5,17);
                code.visitJumpStmt(IF_LEZ,17,-1,L36);
                code.visitLabel(L35);
                code.visitConstStmt(CONST_16,17, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitJumpStmt(GOTO_16,-1,-1,L12);
                code.visitLabel(L36);
                code.visitConstStmt(CONST_16,17, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitJumpStmt(GOTO_16,-1,-1,L12);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m003_getAuthMethod(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/security/DigestAuthenticator;","getAuthMethod",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(139,L0);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_STRING,0,"DIGEST");
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m004_getMaxNonceAge(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/security/DigestAuthenticator;","getMaxNonceAge",new String[]{ },"J"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(354,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_WIDE,0,2,new Field("Lorg/mortbay/jetty/security/DigestAuthenticator;","maxNonceAge","J"));
                code.visitStmt1R(RETURN_WIDE,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m005_getNonceSecret(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/security/DigestAuthenticator;","getNonceSecret",new String[]{ },"J"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(368,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_WIDE,0,2,new Field("Lorg/mortbay/jetty/security/DigestAuthenticator;","nonceSecret","J"));
                code.visitStmt1R(RETURN_WIDE,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m006_getUseStale(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/security/DigestAuthenticator;","getUseStale",new String[]{ },"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(385,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_BOOLEAN,0,1,new Field("Lorg/mortbay/jetty/security/DigestAuthenticator;","useStale","Z"));
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m007_newNonce(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/security/DigestAuthenticator;","newNonce",new String[]{ "Lorg/mortbay/jetty/Request;"},"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(14);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ "Ljava/lang/Exception;"});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"request");
                DexLabel L3=new DexLabel();
                ddv.visitPrologue(L3);
                ddv.visitLineNumber(164,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(165,L4);
                ddv.visitStartLocal(7,L4,"ts","J",null);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(167,L5);
                ddv.visitStartLocal(5,L5,"sk","J",null);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(168,L6);
                ddv.visitStartLocal(4,L6,"nounce","[B",null);
                DexLabel L7=new DexLabel();
                ddv.visitStartLocal(2,L7,"i","I",null);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(170,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(171,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(172,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(173,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(168,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(176,L13);
                ddv.visitLineNumber(179,L0);
                ddv.visitStartLocal(1,L0,"hash","[B",null);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(180,L14);
                ddv.visitStartLocal(3,L14,"md","Ljava/security/MessageDigest;",null);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(181,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(182,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(189,L17);
                ddv.visitEndLocal(3,L17);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(191,L18);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(192,L19);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(196,L20);
                ddv.visitLineNumber(184,L2);
                DexLabel L21=new DexLabel();
                ddv.visitLineNumber(186,L21);
                ddv.visitStartLocal(0,L21,"e","Ljava/lang/Exception;",null);
                DexLabel L22=new DexLabel();
                ddv.visitLineNumber(189,L22);
                ddv.visitEndLocal(0,L22);
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 13},new Method("Lorg/mortbay/jetty/Request;","getTimeStamp",new String[]{ },"J"));
                code.visitStmt1R(MOVE_RESULT_WIDE,7);
                code.visitLabel(L4);
                code.visitFieldStmt(IGET_WIDE,5,12,new Field("Lorg/mortbay/jetty/security/DigestAuthenticator;","nonceSecret","J"));
                code.visitLabel(L5);
                code.visitConstStmt(CONST_16,9, Integer.valueOf(24)); // int: 0x00000018  float:0.000000
                code.visitTypeStmt(NEW_ARRAY,4,9,"[B");
                code.visitLabel(L6);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L7);
                code.visitConstStmt(CONST_16,9, Integer.valueOf(8)); // int: 0x00000008  float:0.000000
                code.visitJumpStmt(IF_GE,2,9,L13);
                code.visitLabel(L8);
                code.visitConstStmt(CONST_WIDE_16,9,Long.valueOf(255L)); // long: 0x00000000000000ff  double:0.000000
                code.visitStmt2R(AND_LONG_2ADDR,9,7);
                code.visitStmt2R(LONG_TO_INT,9,9);
                code.visitStmt2R(INT_TO_BYTE,9,9);
                code.visitStmt3R(APUT_BYTE,9,4,2);
                code.visitLabel(L9);
                code.visitConstStmt(CONST_16,9, Integer.valueOf(8)); // int: 0x00000008  float:0.000000
                code.visitStmt2R(SHR_LONG_2ADDR,7,9);
                code.visitLabel(L10);
                code.visitStmt2R1N(ADD_INT_LIT8,9,2,8);
                code.visitConstStmt(CONST_WIDE_16,10,Long.valueOf(255L)); // long: 0x00000000000000ff  double:0.000000
                code.visitStmt2R(AND_LONG_2ADDR,10,5);
                code.visitStmt2R(LONG_TO_INT,10,10);
                code.visitStmt2R(INT_TO_BYTE,10,10);
                code.visitStmt3R(APUT_BYTE,10,4,9);
                code.visitLabel(L11);
                code.visitConstStmt(CONST_16,9, Integer.valueOf(8)); // int: 0x00000008  float:0.000000
                code.visitStmt2R(SHR_LONG_2ADDR,5,9);
                code.visitLabel(L12);
                code.visitStmt2R1N(ADD_INT_LIT8,2,2,1);
                code.visitJumpStmt(GOTO,-1,-1,L7);
                code.visitLabel(L13);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L0);
                code.visitConstStmt(CONST_STRING,9,"MD5");
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 9},new Method("Ljava/security/MessageDigest;","getInstance",new String[]{ "Ljava/lang/String;"},"Ljava/security/MessageDigest;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitLabel(L14);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Ljava/security/MessageDigest;","reset",new String[]{ },"V"));
                code.visitLabel(L15);
                code.visitConstStmt(CONST_4,9, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitConstStmt(CONST_16,10, Integer.valueOf(16)); // int: 0x00000010  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,4,9,10},new Method("Ljava/security/MessageDigest;","update",new String[]{ "[B","I","I"},"V"));
                code.visitLabel(L16);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Ljava/security/MessageDigest;","digest",new String[]{ },"[B"));
                code.visitLabel(L1);
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L17);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                DexLabel L23=new DexLabel();
                code.visitLabel(L23);
                code.visitStmt2R(ARRAY_LENGTH,9,1);
                code.visitJumpStmt(IF_GE,2,9,L20);
                code.visitLabel(L18);
                code.visitStmt2R1N(ADD_INT_LIT8,9,2,8);
                code.visitStmt3R(AGET_BYTE,10,1,2);
                code.visitStmt3R(APUT_BYTE,10,4,9);
                code.visitLabel(L19);
                code.visitConstStmt(CONST_16,9, Integer.valueOf(23)); // int: 0x00000017  float:0.000000
                code.visitJumpStmt(IF_NE,2,9,L22);
                code.visitLabel(L20);
                code.visitTypeStmt(NEW_INSTANCE,9,-1,"Ljava/lang/String;");
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 4},new Method("Lorg/mortbay/jetty/security/B64Code;","encode",new String[]{ "[B"},"[C"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,10);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 9,10},new Method("Ljava/lang/String;","<init>",new String[]{ "[C"},"V"));
                code.visitStmt1R(RETURN_OBJECT,9);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,9);
                code.visitStmt2R(MOVE_OBJECT,0,9);
                code.visitLabel(L21);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0},new Method("Lorg/mortbay/log/Log;","warn",new String[]{ "Ljava/lang/Throwable;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L17);
                code.visitLabel(L22);
                code.visitStmt2R1N(ADD_INT_LIT8,2,2,1);
                code.visitJumpStmt(GOTO,-1,-1,L23);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m008_sendChallenge(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/security/DigestAuthenticator;","sendChallenge",new String[]{ "Lorg/mortbay/jetty/security/UserRealm;","Lorg/mortbay/jetty/Request;","Lorg/mortbay/jetty/Response;","Z"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(10);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"realm");
                ddv.visitParameterName(1,"request");
                ddv.visitParameterName(2,"response");
                ddv.visitParameterName(3,"stale");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(149,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(150,L1);
                ddv.visitStartLocal(0,L1,"domain","Ljava/lang/String;",null);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(151,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(152,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(158,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(159,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(152,L6);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7},new Method("Lorg/mortbay/jetty/Request;","getContextPath",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L1);
                code.visitJumpStmt(IF_NEZ,0,-1,L3);
                code.visitLabel(L2);
                code.visitConstStmt(CONST_STRING,0,"/");
                code.visitLabel(L3);
                code.visitConstStmt(CONST_STRING,1,"WWW-Authenticate");
                code.visitTypeStmt(NEW_INSTANCE,2,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,3,"Digest realm=\"");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 6},new Method("Lorg/mortbay/jetty/security/UserRealm;","getName",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitConstStmt(CONST_STRING,3,"\", domain=\"");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,0},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitConstStmt(CONST_STRING,3,"\", nonce=\"");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,7},new Method("Lorg/mortbay/jetty/security/DigestAuthenticator;","newNonce",new String[]{ "Lorg/mortbay/jetty/Request;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitConstStmt(CONST_STRING,3,"\", algorithm=MD5, qop=\"auth\"");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitFieldStmt(IGET_BOOLEAN,3,5,new Field("Lorg/mortbay/jetty/security/DigestAuthenticator;","useStale","Z"));
                code.visitJumpStmt(IF_EQZ,3,-1,L6);
                code.visitTypeStmt(NEW_INSTANCE,3,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 3},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,4," stale=");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,4},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,9},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Z"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                DexLabel L7=new DexLabel();
                code.visitLabel(L7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8,1,2},new Method("Lorg/mortbay/jetty/Response;","setHeader",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"V"));
                code.visitLabel(L4);
                code.visitConstStmt(CONST_16,1, Integer.valueOf(401)); // int: 0x00000191  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8,1},new Method("Lorg/mortbay/jetty/Response;","sendError",new String[]{ "I"},"V"));
                code.visitLabel(L5);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L6);
                code.visitConstStmt(CONST_STRING,3,"");
                code.visitJumpStmt(GOTO,-1,-1,L7);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m009_setMaxNonceAge(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/security/DigestAuthenticator;","setMaxNonceAge",new String[]{ "J"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"maxNonceAge");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(361,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(362,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_WIDE,1,0,new Field("Lorg/mortbay/jetty/security/DigestAuthenticator;","maxNonceAge","J"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m010_setNonceSecret(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/security/DigestAuthenticator;","setNonceSecret",new String[]{ "J"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"nonceSecret");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(375,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(376,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_WIDE,1,0,new Field("Lorg/mortbay/jetty/security/DigestAuthenticator;","nonceSecret","J"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m011_setUseStale(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/security/DigestAuthenticator;","setUseStale",new String[]{ "Z"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"us");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(380,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(381,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_BOOLEAN,1,0,new Field("Lorg/mortbay/jetty/security/DigestAuthenticator;","useStale","Z"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
