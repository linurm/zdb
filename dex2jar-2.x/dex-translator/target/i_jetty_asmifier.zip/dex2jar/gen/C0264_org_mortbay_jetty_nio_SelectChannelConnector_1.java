package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0264_org_mortbay_jetty_nio_SelectChannelConnector_1 {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(0,"Lorg/mortbay/jetty/nio/SelectChannelConnector$1;","Lorg/mortbay/io/nio/SelectorManager;",new String[]{ });
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("SelectChannelConnector.java");
        if(cv!=null){
            DexAnnotationVisitor av00 = cv.visitAnnotation("Ldalvik/annotation/EnclosingClass;", Visibility.SYSTEM);
            if(av00 != null) {
                av00.visit("value", new DexType("Lorg/mortbay/jetty/nio/SelectChannelConnector;"));
                av00.visitEnd();
            }
        }
        if(cv!=null){
            DexAnnotationVisitor av00 = cv.visitAnnotation("Ldalvik/annotation/InnerClass;", Visibility.SYSTEM);
            if(av00 != null) {
                av00.visit("accessFlags",  Integer.valueOf(0));
                av00.visit("name", null);
                av00.visitEnd();
            }
        }
        f000_this$0(cv);
        m000__init_(cv);
        m001_acceptChannel(cv);
        m002_dispatch(cv);
        m003_endPointClosed(cv);
        m004_endPointOpened(cv);
        m005_newConnection(cv);
        m006_newEndPoint(cv);
    }
    public static void f000_this$0(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_FINAL|ACC_SYNTHETIC, new Field("Lorg/mortbay/jetty/nio/SelectChannelConnector$1;","this$0","Lorg/mortbay/jetty/nio/SelectChannelConnector;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void m000__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_CONSTRUCTOR, new Method("Lorg/mortbay/jetty/nio/SelectChannelConnector$1;","<init>",new String[]{ "Lorg/mortbay/jetty/nio/SelectChannelConnector;"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(106,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_OBJECT,1,0,new Field("Lorg/mortbay/jetty/nio/SelectChannelConnector$1;","this$0","Lorg/mortbay/jetty/nio/SelectChannelConnector;"));
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Lorg/mortbay/io/nio/SelectorManager;","<init>",new String[]{ },"V"));
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001_acceptChannel(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Lorg/mortbay/jetty/nio/SelectChannelConnector$1;","acceptChannel",new String[]{ "Ljava/nio/channels/SelectionKey;"},"Ljava/nio/channels/SocketChannel;"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"key");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(75,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(76,L1);
                ddv.visitStartLocal(0,L1,"channel","Ljava/nio/channels/SocketChannel;",null);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(77,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(81,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(78,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(79,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(80,L6);
                ddv.visitStartLocal(1,L6,"socket","Ljava/net/Socket;",null);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(81,L7);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Ljava/nio/channels/SelectionKey;","channel",new String[]{ },"Ljava/nio/channels/SelectableChannel;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitTypeStmt(CHECK_CAST,2,-1,"Ljava/nio/channels/ServerSocketChannel;");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Ljava/nio/channels/ServerSocketChannel;","accept",new String[]{ },"Ljava/nio/channels/SocketChannel;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L1);
                code.visitJumpStmt(IF_NEZ,0,-1,L4);
                code.visitLabel(L2);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L3);
                code.visitStmt1R(RETURN_OBJECT,2);
                code.visitLabel(L4);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,2},new Method("Ljava/nio/channels/SocketChannel;","configureBlocking",new String[]{ "Z"},"Ljava/nio/channels/SelectableChannel;"));
                code.visitLabel(L5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/nio/channels/SocketChannel;","socket",new String[]{ },"Ljava/net/Socket;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L6);
                code.visitFieldStmt(IGET_OBJECT,2,3,new Field("Lorg/mortbay/jetty/nio/SelectChannelConnector$1;","this$0","Lorg/mortbay/jetty/nio/SelectChannelConnector;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 2,1},new Method("Lorg/mortbay/jetty/nio/SelectChannelConnector;","access$000",new String[]{ "Lorg/mortbay/jetty/nio/SelectChannelConnector;","Ljava/net/Socket;"},"V"));
                code.visitStmt2R(MOVE_OBJECT,2,0);
                code.visitLabel(L7);
                code.visitJumpStmt(GOTO,-1,-1,L3);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m002_dispatch(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/nio/SelectChannelConnector$1;","dispatch",new String[]{ "Ljava/lang/Runnable;"},"Z"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"task");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(86,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/nio/SelectChannelConnector$1;","this$0","Lorg/mortbay/jetty/nio/SelectChannelConnector;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/jetty/nio/SelectChannelConnector;","getThreadPool",new String[]{ },"Lorg/mortbay/thread/ThreadPool;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,2},new Method("Lorg/mortbay/thread/ThreadPool;","dispatch",new String[]{ "Ljava/lang/Runnable;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m003_endPointClosed(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Lorg/mortbay/jetty/nio/SelectChannelConnector$1;","endPointClosed",new String[]{ "Lorg/mortbay/io/nio/SelectChannelEndPoint;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"endpoint");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(92,L0);
                DexLabel L1=new DexLabel();
                ddv.visitEndLocal(1,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(93,L2);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/nio/SelectChannelConnector$1;","this$0","Lorg/mortbay/jetty/nio/SelectChannelConnector;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/io/nio/SelectChannelEndPoint;","getConnection",new String[]{ },"Lorg/mortbay/io/Connection;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L1);
                code.visitTypeStmt(CHECK_CAST,1,-1,"Lorg/mortbay/jetty/HttpConnection;");
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0,1},new Method("Lorg/mortbay/jetty/nio/SelectChannelConnector;","access$100",new String[]{ "Lorg/mortbay/jetty/nio/SelectChannelConnector;","Lorg/mortbay/jetty/HttpConnection;"},"V"));
                code.visitLabel(L2);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m004_endPointOpened(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Lorg/mortbay/jetty/nio/SelectChannelConnector$1;","endPointOpened",new String[]{ "Lorg/mortbay/io/nio/SelectChannelEndPoint;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"endpoint");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(98,L0);
                DexLabel L1=new DexLabel();
                ddv.visitEndLocal(1,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(99,L2);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/nio/SelectChannelConnector$1;","this$0","Lorg/mortbay/jetty/nio/SelectChannelConnector;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/io/nio/SelectChannelEndPoint;","getConnection",new String[]{ },"Lorg/mortbay/io/Connection;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L1);
                code.visitTypeStmt(CHECK_CAST,1,-1,"Lorg/mortbay/jetty/HttpConnection;");
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0,1},new Method("Lorg/mortbay/jetty/nio/SelectChannelConnector;","access$200",new String[]{ "Lorg/mortbay/jetty/nio/SelectChannelConnector;","Lorg/mortbay/jetty/HttpConnection;"},"V"));
                code.visitLabel(L2);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m005_newConnection(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Lorg/mortbay/jetty/nio/SelectChannelConnector$1;","newConnection",new String[]{ "Ljava/nio/channels/SocketChannel;","Lorg/mortbay/io/nio/SelectChannelEndPoint;"},"Lorg/mortbay/io/Connection;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"channel");
                ddv.visitParameterName(1,"endpoint");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(103,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/nio/SelectChannelConnector$1;","this$0","Lorg/mortbay/jetty/nio/SelectChannelConnector;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,2,3},new Method("Lorg/mortbay/jetty/nio/SelectChannelConnector;","newConnection",new String[]{ "Ljava/nio/channels/SocketChannel;","Lorg/mortbay/io/nio/SelectChannelEndPoint;"},"Lorg/mortbay/io/Connection;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m006_newEndPoint(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Lorg/mortbay/jetty/nio/SelectChannelConnector$1;","newEndPoint",new String[]{ "Ljava/nio/channels/SocketChannel;","Lorg/mortbay/io/nio/SelectorManager$SelectSet;","Ljava/nio/channels/SelectionKey;"},"Lorg/mortbay/io/nio/SelectChannelEndPoint;"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"channel");
                ddv.visitParameterName(1,"selectSet");
                ddv.visitParameterName(2,"sKey");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(108,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/nio/SelectChannelConnector$1;","this$0","Lorg/mortbay/jetty/nio/SelectChannelConnector;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,2,3,4},new Method("Lorg/mortbay/jetty/nio/SelectChannelConnector;","newEndPoint",new String[]{ "Ljava/nio/channels/SocketChannel;","Lorg/mortbay/io/nio/SelectorManager$SelectSet;","Ljava/nio/channels/SelectionKey;"},"Lorg/mortbay/io/nio/SelectChannelEndPoint;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
