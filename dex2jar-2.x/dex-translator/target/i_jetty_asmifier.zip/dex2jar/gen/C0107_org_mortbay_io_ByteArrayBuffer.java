package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0107_org_mortbay_io_ByteArrayBuffer {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(ACC_PUBLIC,"Lorg/mortbay/io/ByteArrayBuffer;","Lorg/mortbay/io/AbstractBuffer;",new String[]{ });
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("ByteArrayBuffer.java");
        if(cv!=null){
            DexAnnotationVisitor av00 = cv.visitAnnotation("Ldalvik/annotation/MemberClasses;", Visibility.SYSTEM);
            if(av00 != null) {
                {
                    DexAnnotationVisitor av01 = av00.visitArray("value");
                    if(av01 != null) {
                        av01.visit(null, new DexType("Lorg/mortbay/io/ByteArrayBuffer$CaseInsensitive;"));
                        av01.visitEnd();
                    }
                }
                av00.visitEnd();
            }
        }
        f000__bytes(cv);
        m000__init_(cv);
        m001__init_(cv);
        m002__init_(cv);
        m003__init_(cv);
        m004__init_(cv);
        m005__init_(cv);
        m006__init_(cv);
        m007__init_(cv);
        m008_array(cv);
        m009_capacity(cv);
        m010_compact(cv);
        m011_equals(cv);
        m012_equalsIgnoreCase(cv);
        m013_get(cv);
        m014_hashCode(cv);
        m015_peek(cv);
        m016_peek(cv);
        m017_poke(cv);
        m018_poke(cv);
        m019_poke(cv);
        m020_readFrom(cv);
        m021_space(cv);
        m022_wrap(cv);
        m023_wrap(cv);
        m024_writeTo(cv);
    }
    public static void f000__bytes(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PROTECTED, new Field("Lorg/mortbay/io/ByteArrayBuffer;","_bytes","[B"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void m000__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/io/ByteArrayBuffer;","<init>",new String[]{ "I"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"size");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(66,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(67,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(68,L3);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L1);
                code.visitTypeStmt(NEW_ARRAY,0,4,"[B");
                code.visitConstStmt(CONST_4,1, Integer.valueOf(2)); // int: 0x00000002  float:0.000000
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 3,0,2,4,1},new Method("Lorg/mortbay/io/ByteArrayBuffer;","<init>",new String[]{ "[B","I","I","I"},"V"));
                code.visitLabel(L2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,2},new Method("Lorg/mortbay/io/ByteArrayBuffer;","setPutIndex",new String[]{ "I"},"V"));
                code.visitLabel(L3);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/io/ByteArrayBuffer;","<init>",new String[]{ "I","Z"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"access");
                ddv.visitParameterName(1,"isVolatile");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(33,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(34,L1);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1,2},new Method("Lorg/mortbay/io/AbstractBuffer;","<init>",new String[]{ "I","Z"},"V"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m002__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/io/ByteArrayBuffer;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"value");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(72,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(73,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(74,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(75,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(76,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(77,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(78,L7);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(2)); // int: 0x00000002  float:0.000000
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2,0,1},new Method("Lorg/mortbay/io/AbstractBuffer;","<init>",new String[]{ "I","Z"},"V"));
                code.visitLabel(L2);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 3},new Method("Lorg/mortbay/io/Portable;","getBytes",new String[]{ "Ljava/lang/String;"},"[B"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(IPUT_OBJECT,0,2,new Field("Lorg/mortbay/io/ByteArrayBuffer;","_bytes","[B"));
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,1},new Method("Lorg/mortbay/io/ByteArrayBuffer;","setGetIndex",new String[]{ "I"},"V"));
                code.visitLabel(L4);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/io/ByteArrayBuffer;","_bytes","[B"));
                code.visitStmt2R(ARRAY_LENGTH,0,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,0},new Method("Lorg/mortbay/io/ByteArrayBuffer;","setPutIndex",new String[]{ "I"},"V"));
                code.visitLabel(L5);
                code.visitFieldStmt(IPUT,1,2,new Field("Lorg/mortbay/io/ByteArrayBuffer;","_access","I"));
                code.visitLabel(L6);
                code.visitFieldStmt(IPUT_OBJECT,3,2,new Field("Lorg/mortbay/io/ByteArrayBuffer;","_string","Ljava/lang/String;"));
                code.visitLabel(L7);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m003__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/io/ByteArrayBuffer;","<init>",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/UnsupportedEncodingException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"value");
                ddv.visitParameterName(1,"encoding");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(82,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(83,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(84,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(85,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(86,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(87,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(88,L7);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(2)); // int: 0x00000002  float:0.000000
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2,0,1},new Method("Lorg/mortbay/io/AbstractBuffer;","<init>",new String[]{ "I","Z"},"V"));
                code.visitLabel(L2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,4},new Method("Ljava/lang/String;","getBytes",new String[]{ "Ljava/lang/String;"},"[B"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(IPUT_OBJECT,0,2,new Field("Lorg/mortbay/io/ByteArrayBuffer;","_bytes","[B"));
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,1},new Method("Lorg/mortbay/io/ByteArrayBuffer;","setGetIndex",new String[]{ "I"},"V"));
                code.visitLabel(L4);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/io/ByteArrayBuffer;","_bytes","[B"));
                code.visitStmt2R(ARRAY_LENGTH,0,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,0},new Method("Lorg/mortbay/io/ByteArrayBuffer;","setPutIndex",new String[]{ "I"},"V"));
                code.visitLabel(L5);
                code.visitFieldStmt(IPUT,1,2,new Field("Lorg/mortbay/io/ByteArrayBuffer;","_access","I"));
                code.visitLabel(L6);
                code.visitFieldStmt(IPUT_OBJECT,3,2,new Field("Lorg/mortbay/io/ByteArrayBuffer;","_string","Ljava/lang/String;"));
                code.visitLabel(L7);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m004__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/io/ByteArrayBuffer;","<init>",new String[]{ "[B"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"bytes");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(38,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(39,L1);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitStmt2R(ARRAY_LENGTH,1,4);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(2)); // int: 0x00000002  float:0.000000
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 3,4,0,1,2},new Method("Lorg/mortbay/io/ByteArrayBuffer;","<init>",new String[]{ "[B","I","I","I"},"V"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m005__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/io/ByteArrayBuffer;","<init>",new String[]{ "[B","I","I"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"bytes");
                ddv.visitParameterName(1,"index");
                ddv.visitParameterName(2,"length");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(43,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(44,L1);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(2)); // int: 0x00000002  float:0.000000
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1,2,3,4,0},new Method("Lorg/mortbay/io/ByteArrayBuffer;","<init>",new String[]{ "[B","I","I","I"},"V"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m006__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/io/ByteArrayBuffer;","<init>",new String[]{ "[B","I","I","I"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(7);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"bytes");
                ddv.visitParameterName(1,"index");
                ddv.visitParameterName(2,"length");
                ddv.visitParameterName(3,"access");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(48,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(49,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(50,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(51,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(52,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(53,L5);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(2)); // int: 0x00000002  float:0.000000
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2,0,1},new Method("Lorg/mortbay/io/AbstractBuffer;","<init>",new String[]{ "I","Z"},"V"));
                code.visitLabel(L1);
                code.visitFieldStmt(IPUT_OBJECT,3,2,new Field("Lorg/mortbay/io/ByteArrayBuffer;","_bytes","[B"));
                code.visitLabel(L2);
                code.visitStmt3R(ADD_INT,0,4,5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,0},new Method("Lorg/mortbay/io/ByteArrayBuffer;","setPutIndex",new String[]{ "I"},"V"));
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,4},new Method("Lorg/mortbay/io/ByteArrayBuffer;","setGetIndex",new String[]{ "I"},"V"));
                code.visitLabel(L4);
                code.visitFieldStmt(IPUT,6,2,new Field("Lorg/mortbay/io/ByteArrayBuffer;","_access","I"));
                code.visitLabel(L5);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m007__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/io/ByteArrayBuffer;","<init>",new String[]{ "[B","I","I","I","Z"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(7);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"bytes");
                ddv.visitParameterName(1,"index");
                ddv.visitParameterName(2,"length");
                ddv.visitParameterName(3,"access");
                ddv.visitParameterName(4,"isVolatile");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(57,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(58,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(59,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(60,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(61,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(62,L5);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(2)); // int: 0x00000002  float:0.000000
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1,0,6},new Method("Lorg/mortbay/io/AbstractBuffer;","<init>",new String[]{ "I","Z"},"V"));
                code.visitLabel(L1);
                code.visitFieldStmt(IPUT_OBJECT,2,1,new Field("Lorg/mortbay/io/ByteArrayBuffer;","_bytes","[B"));
                code.visitLabel(L2);
                code.visitStmt3R(ADD_INT,0,3,4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,0},new Method("Lorg/mortbay/io/ByteArrayBuffer;","setPutIndex",new String[]{ "I"},"V"));
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,3},new Method("Lorg/mortbay/io/ByteArrayBuffer;","setGetIndex",new String[]{ "I"},"V"));
                code.visitLabel(L4);
                code.visitFieldStmt(IPUT,5,1,new Field("Lorg/mortbay/io/ByteArrayBuffer;","_access","I"));
                code.visitLabel(L5);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m008_array(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/io/ByteArrayBuffer;","array",new String[]{ },"[B"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(92,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/io/ByteArrayBuffer;","_bytes","[B"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m009_capacity(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/io/ByteArrayBuffer;","capacity",new String[]{ },"I"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(97,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/io/ByteArrayBuffer;","_bytes","[B"));
                code.visitStmt2R(ARRAY_LENGTH,0,0);
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m010_compact(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/io/ByteArrayBuffer;","compact",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(6);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(102,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(103,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(104,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(105,L3);
                ddv.visitStartLocal(1,L3,"s","I",null);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(107,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(108,L5);
                ddv.visitStartLocal(0,L5,"length","I",null);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(110,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(112,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(113,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(114,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(116,L10);
                ddv.visitEndLocal(0,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(104,L11);
                ddv.visitEndLocal(1,L11);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Lorg/mortbay/io/ByteArrayBuffer;","isReadOnly",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitJumpStmt(IF_EQZ,2,-1,L2);
                code.visitLabel(L1);
                code.visitTypeStmt(NEW_INSTANCE,2,-1,"Ljava/lang/IllegalStateException;");
                code.visitConstStmt(CONST_STRING,3,"READONLY");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2,3},new Method("Ljava/lang/IllegalStateException;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitStmt1R(THROW,2);
                code.visitLabel(L2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Lorg/mortbay/io/ByteArrayBuffer;","markIndex",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitJumpStmt(IF_LTZ,2,-1,L11);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Lorg/mortbay/io/ByteArrayBuffer;","markIndex",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitStmt2R(MOVE,1,2);
                code.visitLabel(L3);
                code.visitJumpStmt(IF_LEZ,1,-1,L10);
                code.visitLabel(L4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Lorg/mortbay/io/ByteArrayBuffer;","putIndex",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitStmt3R(SUB_INT,0,2,1);
                code.visitLabel(L5);
                code.visitJumpStmt(IF_LEZ,0,-1,L7);
                code.visitLabel(L6);
                code.visitFieldStmt(IGET_OBJECT,2,5,new Field("Lorg/mortbay/io/ByteArrayBuffer;","_bytes","[B"));
                code.visitFieldStmt(IGET_OBJECT,3,5,new Field("Lorg/mortbay/io/ByteArrayBuffer;","_bytes","[B"));
                code.visitConstStmt(CONST_4,4, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 2,1,3,4,0},new Method("Lorg/mortbay/io/Portable;","arraycopy",new String[]{ "[B","I","[B","I","I"},"V"));
                code.visitLabel(L7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Lorg/mortbay/io/ByteArrayBuffer;","markIndex",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitJumpStmt(IF_LEZ,2,-1,L8);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Lorg/mortbay/io/ByteArrayBuffer;","markIndex",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitStmt2R(SUB_INT_2ADDR,2,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,2},new Method("Lorg/mortbay/io/ByteArrayBuffer;","setMarkIndex",new String[]{ "I"},"V"));
                code.visitLabel(L8);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Lorg/mortbay/io/ByteArrayBuffer;","getIndex",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitStmt2R(SUB_INT_2ADDR,2,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,2},new Method("Lorg/mortbay/io/ByteArrayBuffer;","setGetIndex",new String[]{ "I"},"V"));
                code.visitLabel(L9);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Lorg/mortbay/io/ByteArrayBuffer;","putIndex",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitStmt2R(SUB_INT_2ADDR,2,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,2},new Method("Lorg/mortbay/io/ByteArrayBuffer;","setPutIndex",new String[]{ "I"},"V"));
                code.visitLabel(L10);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L11);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Lorg/mortbay/io/ByteArrayBuffer;","getIndex",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitStmt2R(MOVE,1,2);
                code.visitJumpStmt(GOTO,-1,-1,L3);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m011_equals(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/io/ByteArrayBuffer;","equals",new String[]{ "Ljava/lang/Object;"},"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(15);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"obj");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(121,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(154,L2);
                ddv.visitEndLocal(14,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(124,L3);
                ddv.visitRestartLocal(14,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(125,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(127,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(128,L6);
                DexLabel L7=new DexLabel();
                ddv.visitEndLocal(14,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(131,L8);
                ddv.visitRestartLocal(14,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(134,L9);
                ddv.visitStartLocal(2,L9,"b","Lorg/mortbay/io/Buffer;",null);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(135,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(138,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(140,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(141,L13);
                ddv.visitStartLocal(1,L13,"ab","Lorg/mortbay/io/AbstractBuffer;",null);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(142,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(146,L15);
                ddv.visitEndLocal(1,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(147,L16);
                ddv.visitStartLocal(6,L16,"get","I",null);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(148,L17);
                ddv.visitStartLocal(5,L17,"bi","I",null);
                DexLabel L18=new DexLabel();
                ddv.visitStartLocal(7,L18,"i","I",null);
                DexLabel L19=new DexLabel();
                ddv.visitEndLocal(7,L19);
                ddv.visitStartLocal(8,L19,"i","I",null);
                DexLabel L20=new DexLabel();
                ddv.visitRestartLocal(7,L20);
                DexLabel L21=new DexLabel();
                ddv.visitLineNumber(150,L21);
                ddv.visitEndLocal(8,L21);
                DexLabel L22=new DexLabel();
                ddv.visitLineNumber(151,L22);
                ddv.visitStartLocal(3,L22,"b1","B",null);
                DexLabel L23=new DexLabel();
                ddv.visitLineNumber(152,L23);
                ddv.visitStartLocal(4,L23,"b2","B",null);
                DexLabel L24=new DexLabel();
                ddv.visitLineNumber(153,L24);
                ddv.visitRestartLocal(8,L24);
                DexLabel L25=new DexLabel();
                ddv.visitEndLocal(3,L25);
                ddv.visitEndLocal(4,L25);
                ddv.visitEndLocal(8,L25);
                DexLabel L26=new DexLabel();
                ddv.visitLineNumber(154,L26);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,12, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitConstStmt(CONST_4,11, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L1);
                code.visitJumpStmt(IF_NE,14,13,L3);
                code.visitStmt2R(MOVE,9,12);
                code.visitLabel(L2);
                code.visitStmt1R(RETURN,9);
                code.visitLabel(L3);
                DexLabel L27=new DexLabel();
                code.visitJumpStmt(IF_EQZ,14,-1,L27);
                code.visitTypeStmt(INSTANCE_OF,9,14,"Lorg/mortbay/io/Buffer;");
                code.visitJumpStmt(IF_NEZ,9,-1,L5);
                code.visitLabel(L27);
                code.visitStmt2R(MOVE,9,11);
                code.visitLabel(L4);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitLabel(L5);
                code.visitTypeStmt(INSTANCE_OF,9,14,"Lorg/mortbay/io/Buffer$CaseInsensitve;");
                code.visitJumpStmt(IF_EQZ,9,-1,L8);
                code.visitLabel(L6);
                code.visitTypeStmt(CHECK_CAST,14,-1,"Lorg/mortbay/io/Buffer;");
                code.visitLabel(L7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 13,14},new Method("Lorg/mortbay/io/ByteArrayBuffer;","equalsIgnoreCase",new String[]{ "Lorg/mortbay/io/Buffer;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,9);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitLabel(L8);
                code.visitStmt2R(MOVE_OBJECT,0,14);
                code.visitTypeStmt(CHECK_CAST,0,-1,"Lorg/mortbay/io/Buffer;");
                code.visitStmt2R(MOVE_OBJECT,2,0);
                code.visitLabel(L9);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 2},new Method("Lorg/mortbay/io/Buffer;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,9);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 13},new Method("Lorg/mortbay/io/ByteArrayBuffer;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,10);
                code.visitJumpStmt(IF_EQ,9,10,L11);
                code.visitStmt2R(MOVE,9,11);
                code.visitLabel(L10);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitLabel(L11);
                code.visitFieldStmt(IGET,9,13,new Field("Lorg/mortbay/io/ByteArrayBuffer;","_hash","I"));
                code.visitJumpStmt(IF_EQZ,9,-1,L15);
                code.visitTypeStmt(INSTANCE_OF,9,14,"Lorg/mortbay/io/AbstractBuffer;");
                code.visitJumpStmt(IF_EQZ,9,-1,L15);
                code.visitLabel(L12);
                code.visitStmt2R(MOVE_OBJECT,0,14);
                code.visitTypeStmt(CHECK_CAST,0,-1,"Lorg/mortbay/io/AbstractBuffer;");
                code.visitStmt2R(MOVE_OBJECT,1,0);
                code.visitLabel(L13);
                code.visitFieldStmt(IGET,9,1,new Field("Lorg/mortbay/io/AbstractBuffer;","_hash","I"));
                code.visitJumpStmt(IF_EQZ,9,-1,L15);
                code.visitFieldStmt(IGET,9,13,new Field("Lorg/mortbay/io/ByteArrayBuffer;","_hash","I"));
                code.visitFieldStmt(IGET,10,1,new Field("Lorg/mortbay/io/AbstractBuffer;","_hash","I"));
                code.visitJumpStmt(IF_EQ,9,10,L15);
                code.visitStmt2R(MOVE,9,11);
                code.visitLabel(L14);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitLabel(L15);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 13},new Method("Lorg/mortbay/io/ByteArrayBuffer;","getIndex",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,6);
                code.visitLabel(L16);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 2},new Method("Lorg/mortbay/io/Buffer;","putIndex",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,5);
                code.visitLabel(L17);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 13},new Method("Lorg/mortbay/io/ByteArrayBuffer;","putIndex",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,7);
                code.visitLabel(L18);
                code.visitStmt2R(MOVE,8,7);
                code.visitLabel(L19);
                code.visitStmt3R(SUB_INT,7,8,12);
                code.visitLabel(L20);
                code.visitJumpStmt(IF_LE,8,6,L25);
                code.visitLabel(L21);
                code.visitFieldStmt(IGET_OBJECT,9,13,new Field("Lorg/mortbay/io/ByteArrayBuffer;","_bytes","[B"));
                code.visitStmt3R(AGET_BYTE,3,9,7);
                code.visitLabel(L22);
                code.visitStmt2R1N(ADD_INT_LIT8,5,5,-1);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 2,5},new Method("Lorg/mortbay/io/Buffer;","peek",new String[]{ "I"},"B"));
                code.visitStmt1R(MOVE_RESULT,4);
                code.visitLabel(L23);
                DexLabel L28=new DexLabel();
                code.visitJumpStmt(IF_EQ,3,4,L28);
                code.visitStmt2R(MOVE,9,11);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitLabel(L28);
                code.visitStmt2R(MOVE,8,7);
                code.visitLabel(L24);
                code.visitJumpStmt(GOTO,-1,-1,L19);
                code.visitLabel(L25);
                code.visitStmt2R(MOVE,9,12);
                code.visitLabel(L26);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m012_equalsIgnoreCase(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/io/ByteArrayBuffer;","equalsIgnoreCase",new String[]{ "Lorg/mortbay/io/Buffer;"},"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(18);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"b");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(160,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(206,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(164,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(165,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(168,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(170,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(171,L7);
                ddv.visitStartLocal(2,L7,"ab","Lorg/mortbay/io/AbstractBuffer;",null);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(175,L8);
                ddv.visitEndLocal(2,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(176,L9);
                ddv.visitStartLocal(7,L9,"get","I",null);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(177,L10);
                ddv.visitStartLocal(6,L10,"bi","I",null);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(178,L11);
                ddv.visitStartLocal(5,L11,"barray","[B",null);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(180,L12);
                DexLabel L13=new DexLabel();
                ddv.visitStartLocal(8,L13,"i","I",null);
                DexLabel L14=new DexLabel();
                ddv.visitEndLocal(8,L14);
                ddv.visitStartLocal(9,L14,"i","I",null);
                DexLabel L15=new DexLabel();
                ddv.visitRestartLocal(8,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(182,L16);
                ddv.visitEndLocal(9,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(183,L17);
                ddv.visitStartLocal(3,L17,"b1","B",null);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(184,L18);
                ddv.visitStartLocal(4,L18,"b2","B",null);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(186,L19);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(187,L20);
                DexLabel L21=new DexLabel();
                ddv.visitLineNumber(188,L21);
                DexLabel L22=new DexLabel();
                ddv.visitLineNumber(190,L22);
                ddv.visitRestartLocal(9,L22);
                DexLabel L23=new DexLabel();
                ddv.visitLineNumber(194,L23);
                ddv.visitEndLocal(8,L23);
                ddv.visitEndLocal(3,L23);
                ddv.visitEndLocal(4,L23);
                ddv.visitEndLocal(9,L23);
                DexLabel L24=new DexLabel();
                ddv.visitRestartLocal(8,L24);
                DexLabel L25=new DexLabel();
                ddv.visitEndLocal(8,L25);
                ddv.visitRestartLocal(9,L25);
                DexLabel L26=new DexLabel();
                ddv.visitRestartLocal(8,L26);
                DexLabel L27=new DexLabel();
                ddv.visitLineNumber(196,L27);
                ddv.visitEndLocal(9,L27);
                DexLabel L28=new DexLabel();
                ddv.visitLineNumber(197,L28);
                ddv.visitRestartLocal(3,L28);
                DexLabel L29=new DexLabel();
                ddv.visitLineNumber(198,L29);
                ddv.visitRestartLocal(4,L29);
                DexLabel L30=new DexLabel();
                ddv.visitLineNumber(200,L30);
                DexLabel L31=new DexLabel();
                ddv.visitLineNumber(201,L31);
                DexLabel L32=new DexLabel();
                ddv.visitLineNumber(202,L32);
                DexLabel L33=new DexLabel();
                ddv.visitLineNumber(204,L33);
                ddv.visitRestartLocal(9,L33);
                DexLabel L34=new DexLabel();
                ddv.visitEndLocal(3,L34);
                ddv.visitEndLocal(4,L34);
                ddv.visitEndLocal(9,L34);
                DexLabel L35=new DexLabel();
                ddv.visitLineNumber(206,L35);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_16,15, Integer.valueOf(122)); // int: 0x0000007a  float:0.000000
                code.visitConstStmt(CONST_4,14, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitConstStmt(CONST_4,13, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitConstStmt(CONST_16,12, Integer.valueOf(97)); // int: 0x00000061  float:0.000000
                code.visitLabel(L1);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,17);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,16);
                code.visitJumpStmt(IF_NE,0,1,L3);
                code.visitStmt2R(MOVE,10,14);
                code.visitLabel(L2);
                code.visitStmt1R(RETURN,10);
                code.visitLabel(L3);
                DexLabel L36=new DexLabel();
                code.visitJumpStmt(IF_EQZ,17,-1,L36);
                code.visitMethodStmt(INVOKE_INTERFACE_RANGE,new int[]{ 17},new Method("Lorg/mortbay/io/Buffer;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,10);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 16},new Method("Lorg/mortbay/io/ByteArrayBuffer;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,11);
                code.visitJumpStmt(IF_EQ,10,11,L5);
                code.visitLabel(L36);
                code.visitStmt2R(MOVE,10,13);
                code.visitLabel(L4);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitLabel(L5);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,16);
                code.visitFieldStmt(IGET,0,0,new Field("Lorg/mortbay/io/ByteArrayBuffer;","_hash","I"));
                code.visitStmt2R(MOVE,10,0);
                code.visitJumpStmt(IF_EQZ,10,-1,L8);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,17);
                code.visitTypeStmt(INSTANCE_OF,0,0,"Lorg/mortbay/io/AbstractBuffer;");
                code.visitStmt2R(MOVE,10,0);
                code.visitJumpStmt(IF_EQZ,10,-1,L8);
                code.visitLabel(L6);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,17);
                code.visitTypeStmt(CHECK_CAST,0,-1,"Lorg/mortbay/io/AbstractBuffer;");
                code.visitStmt2R(MOVE_OBJECT,2,0);
                code.visitLabel(L7);
                code.visitFieldStmt(IGET,10,2,new Field("Lorg/mortbay/io/AbstractBuffer;","_hash","I"));
                code.visitJumpStmt(IF_EQZ,10,-1,L8);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,16);
                code.visitFieldStmt(IGET,0,0,new Field("Lorg/mortbay/io/ByteArrayBuffer;","_hash","I"));
                code.visitStmt2R(MOVE,10,0);
                code.visitFieldStmt(IGET,11,2,new Field("Lorg/mortbay/io/AbstractBuffer;","_hash","I"));
                code.visitJumpStmt(IF_EQ,10,11,L8);
                code.visitStmt2R(MOVE,10,13);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitLabel(L8);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 16},new Method("Lorg/mortbay/io/ByteArrayBuffer;","getIndex",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,7);
                code.visitLabel(L9);
                code.visitMethodStmt(INVOKE_INTERFACE_RANGE,new int[]{ 17},new Method("Lorg/mortbay/io/Buffer;","putIndex",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,6);
                code.visitLabel(L10);
                code.visitMethodStmt(INVOKE_INTERFACE_RANGE,new int[]{ 17},new Method("Lorg/mortbay/io/Buffer;","array",new String[]{ },"[B"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitLabel(L11);
                code.visitJumpStmt(IF_NEZ,5,-1,L23);
                code.visitLabel(L12);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 16},new Method("Lorg/mortbay/io/ByteArrayBuffer;","putIndex",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,8);
                code.visitLabel(L13);
                code.visitStmt2R(MOVE,9,8);
                code.visitLabel(L14);
                code.visitStmt3R(SUB_INT,8,9,14);
                code.visitLabel(L15);
                code.visitJumpStmt(IF_LE,9,7,L34);
                code.visitLabel(L16);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,16);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/io/ByteArrayBuffer;","_bytes","[B"));
                code.visitStmt2R(MOVE_OBJECT,10,0);
                code.visitStmt3R(AGET_BYTE,3,10,8);
                code.visitLabel(L17);
                code.visitStmt2R1N(ADD_INT_LIT8,6,6,-1);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,17);
                code.visitStmt2R(MOVE,1,6);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,1},new Method("Lorg/mortbay/io/Buffer;","peek",new String[]{ "I"},"B"));
                code.visitStmt1R(MOVE_RESULT,4);
                code.visitLabel(L18);
                DexLabel L37=new DexLabel();
                code.visitJumpStmt(IF_EQ,3,4,L37);
                code.visitLabel(L19);
                code.visitJumpStmt(IF_GT,12,3,L20);
                code.visitJumpStmt(IF_GT,3,15,L20);
                code.visitStmt3R(SUB_INT,10,3,12);
                code.visitStmt2R1N(ADD_INT_LIT8,10,10,65);
                code.visitStmt2R(INT_TO_BYTE,3,10);
                code.visitLabel(L20);
                code.visitJumpStmt(IF_GT,12,4,L21);
                code.visitJumpStmt(IF_GT,4,15,L21);
                code.visitStmt3R(SUB_INT,10,4,12);
                code.visitStmt2R1N(ADD_INT_LIT8,10,10,65);
                code.visitStmt2R(INT_TO_BYTE,4,10);
                code.visitLabel(L21);
                code.visitJumpStmt(IF_EQ,3,4,L37);
                code.visitStmt2R(MOVE,10,13);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitLabel(L37);
                code.visitStmt2R(MOVE,9,8);
                code.visitLabel(L22);
                code.visitJumpStmt(GOTO,-1,-1,L14);
                code.visitLabel(L23);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 16},new Method("Lorg/mortbay/io/ByteArrayBuffer;","putIndex",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,8);
                code.visitLabel(L24);
                code.visitStmt2R(MOVE,9,8);
                code.visitLabel(L25);
                code.visitStmt3R(SUB_INT,8,9,14);
                code.visitLabel(L26);
                code.visitJumpStmt(IF_LE,9,7,L34);
                code.visitLabel(L27);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,16);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/io/ByteArrayBuffer;","_bytes","[B"));
                code.visitStmt2R(MOVE_OBJECT,10,0);
                code.visitStmt3R(AGET_BYTE,3,10,8);
                code.visitLabel(L28);
                code.visitStmt2R1N(ADD_INT_LIT8,6,6,-1);
                code.visitStmt3R(AGET_BYTE,4,5,6);
                code.visitLabel(L29);
                DexLabel L38=new DexLabel();
                code.visitJumpStmt(IF_EQ,3,4,L38);
                code.visitLabel(L30);
                code.visitJumpStmt(IF_GT,12,3,L31);
                code.visitJumpStmt(IF_GT,3,15,L31);
                code.visitStmt3R(SUB_INT,10,3,12);
                code.visitStmt2R1N(ADD_INT_LIT8,10,10,65);
                code.visitStmt2R(INT_TO_BYTE,3,10);
                code.visitLabel(L31);
                code.visitJumpStmt(IF_GT,12,4,L32);
                code.visitJumpStmt(IF_GT,4,15,L32);
                code.visitStmt3R(SUB_INT,10,4,12);
                code.visitStmt2R1N(ADD_INT_LIT8,10,10,65);
                code.visitStmt2R(INT_TO_BYTE,4,10);
                code.visitLabel(L32);
                code.visitJumpStmt(IF_EQ,3,4,L38);
                code.visitStmt2R(MOVE,10,13);
                code.visitJumpStmt(GOTO_16,-1,-1,L2);
                code.visitLabel(L38);
                code.visitStmt2R(MOVE,9,8);
                code.visitLabel(L33);
                code.visitJumpStmt(GOTO,-1,-1,L25);
                code.visitLabel(L34);
                code.visitStmt2R(MOVE,10,14);
                code.visitLabel(L35);
                code.visitJumpStmt(GOTO_16,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m013_get(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/io/ByteArrayBuffer;","get",new String[]{ },"B"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(211,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,3,new Field("Lorg/mortbay/io/ByteArrayBuffer;","_bytes","[B"));
                code.visitFieldStmt(IGET,1,3,new Field("Lorg/mortbay/io/ByteArrayBuffer;","_get","I"));
                code.visitStmt2R1N(ADD_INT_LIT8,2,1,1);
                code.visitFieldStmt(IPUT,2,3,new Field("Lorg/mortbay/io/ByteArrayBuffer;","_get","I"));
                code.visitStmt3R(AGET_BYTE,0,0,1);
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m014_hashCode(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/io/ByteArrayBuffer;","hashCode",new String[]{ },"I"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(8);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(216,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(218,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(219,L3);
                ddv.visitStartLocal(1,L3,"get","I",null);
                DexLabel L4=new DexLabel();
                ddv.visitStartLocal(2,L4,"i","I",null);
                DexLabel L5=new DexLabel();
                ddv.visitEndLocal(2,L5);
                ddv.visitStartLocal(3,L5,"i","I",null);
                DexLabel L6=new DexLabel();
                ddv.visitRestartLocal(2,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(221,L7);
                ddv.visitEndLocal(3,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(222,L8);
                ddv.visitStartLocal(0,L8,"b","B",null);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(223,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(224,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(225,L11);
                ddv.visitRestartLocal(3,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(226,L12);
                ddv.visitEndLocal(0,L12);
                ddv.visitEndLocal(3,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(227,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(228,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(229,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(231,L16);
                ddv.visitEndLocal(1,L16);
                ddv.visitEndLocal(2,L16);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_16,6, Integer.valueOf(97)); // int: 0x00000061  float:0.000000
                code.visitLabel(L1);
                code.visitFieldStmt(IGET,4,7,new Field("Lorg/mortbay/io/ByteArrayBuffer;","_hash","I"));
                code.visitJumpStmt(IF_EQZ,4,-1,L2);
                code.visitFieldStmt(IGET,4,7,new Field("Lorg/mortbay/io/ByteArrayBuffer;","_hashGet","I"));
                code.visitFieldStmt(IGET,5,7,new Field("Lorg/mortbay/io/ByteArrayBuffer;","_get","I"));
                code.visitJumpStmt(IF_NE,4,5,L2);
                code.visitFieldStmt(IGET,4,7,new Field("Lorg/mortbay/io/ByteArrayBuffer;","_hashPut","I"));
                code.visitFieldStmt(IGET,5,7,new Field("Lorg/mortbay/io/ByteArrayBuffer;","_put","I"));
                code.visitJumpStmt(IF_EQ,4,5,L16);
                code.visitLabel(L2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7},new Method("Lorg/mortbay/io/ByteArrayBuffer;","getIndex",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7},new Method("Lorg/mortbay/io/ByteArrayBuffer;","putIndex",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitLabel(L4);
                code.visitStmt2R(MOVE,3,2);
                code.visitLabel(L5);
                code.visitConstStmt(CONST_4,4, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitStmt3R(SUB_INT,2,3,4);
                code.visitLabel(L6);
                code.visitJumpStmt(IF_LE,3,1,L12);
                code.visitLabel(L7);
                code.visitFieldStmt(IGET_OBJECT,4,7,new Field("Lorg/mortbay/io/ByteArrayBuffer;","_bytes","[B"));
                code.visitStmt3R(AGET_BYTE,0,4,2);
                code.visitLabel(L8);
                code.visitJumpStmt(IF_GT,6,0,L10);
                code.visitConstStmt(CONST_16,4, Integer.valueOf(122)); // int: 0x0000007a  float:0.000000
                code.visitJumpStmt(IF_GT,0,4,L10);
                code.visitLabel(L9);
                code.visitStmt3R(SUB_INT,4,0,6);
                code.visitStmt2R1N(ADD_INT_LIT8,4,4,65);
                code.visitStmt2R(INT_TO_BYTE,0,4);
                code.visitLabel(L10);
                code.visitFieldStmt(IGET,4,7,new Field("Lorg/mortbay/io/ByteArrayBuffer;","_hash","I"));
                code.visitStmt2R1N(MUL_INT_LIT8,4,4,31);
                code.visitStmt2R(ADD_INT_2ADDR,4,0);
                code.visitFieldStmt(IPUT,4,7,new Field("Lorg/mortbay/io/ByteArrayBuffer;","_hash","I"));
                code.visitStmt2R(MOVE,3,2);
                code.visitLabel(L11);
                code.visitJumpStmt(GOTO,-1,-1,L5);
                code.visitLabel(L12);
                code.visitFieldStmt(IGET,4,7,new Field("Lorg/mortbay/io/ByteArrayBuffer;","_hash","I"));
                code.visitJumpStmt(IF_NEZ,4,-1,L14);
                code.visitLabel(L13);
                code.visitConstStmt(CONST_4,4, Integer.valueOf(-1)); // int: 0xffffffff  float:NaN
                code.visitFieldStmt(IPUT,4,7,new Field("Lorg/mortbay/io/ByteArrayBuffer;","_hash","I"));
                code.visitLabel(L14);
                code.visitFieldStmt(IGET,4,7,new Field("Lorg/mortbay/io/ByteArrayBuffer;","_get","I"));
                code.visitFieldStmt(IPUT,4,7,new Field("Lorg/mortbay/io/ByteArrayBuffer;","_hashGet","I"));
                code.visitLabel(L15);
                code.visitFieldStmt(IGET,4,7,new Field("Lorg/mortbay/io/ByteArrayBuffer;","_put","I"));
                code.visitFieldStmt(IPUT,4,7,new Field("Lorg/mortbay/io/ByteArrayBuffer;","_hashPut","I"));
                code.visitLabel(L16);
                code.visitFieldStmt(IGET,4,7,new Field("Lorg/mortbay/io/ByteArrayBuffer;","_hash","I"));
                code.visitStmt1R(RETURN,4);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m015_peek(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/io/ByteArrayBuffer;","peek",new String[]{ "I"},"B"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"index");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(237,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/io/ByteArrayBuffer;","_bytes","[B"));
                code.visitStmt3R(AGET_BYTE,0,0,2);
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m016_peek(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/io/ByteArrayBuffer;","peek",new String[]{ "I","[B","I","I"},"I"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(9);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"index");
                ddv.visitParameterName(1,"b");
                ddv.visitParameterName(2,"offset");
                ddv.visitParameterName(3,"length");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(242,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(243,L2);
                ddv.visitStartLocal(0,L2,"l","I",null);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(245,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(246,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(254,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(250,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(251,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(253,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(254,L9);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(-1)); // int: 0xffffffff  float:NaN
                code.visitLabel(L1);
                code.visitStmt2R(MOVE,0,8);
                code.visitLabel(L2);
                code.visitStmt3R(ADD_INT,1,5,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Lorg/mortbay/io/ByteArrayBuffer;","capacity",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitJumpStmt(IF_LE,1,2,L6);
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Lorg/mortbay/io/ByteArrayBuffer;","capacity",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitStmt3R(SUB_INT,0,1,5);
                code.visitLabel(L4);
                code.visitJumpStmt(IF_NEZ,0,-1,L6);
                code.visitStmt2R(MOVE,1,3);
                code.visitLabel(L5);
                code.visitStmt1R(RETURN,1);
                code.visitLabel(L6);
                code.visitJumpStmt(IF_GEZ,0,-1,L8);
                code.visitStmt2R(MOVE,1,3);
                code.visitLabel(L7);
                code.visitJumpStmt(GOTO,-1,-1,L5);
                code.visitLabel(L8);
                code.visitFieldStmt(IGET_OBJECT,1,4,new Field("Lorg/mortbay/io/ByteArrayBuffer;","_bytes","[B"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1,5,6,7,0},new Method("Lorg/mortbay/io/Portable;","arraycopy",new String[]{ "[B","I","[B","I","I"},"V"));
                code.visitStmt2R(MOVE,1,0);
                code.visitLabel(L9);
                code.visitJumpStmt(GOTO,-1,-1,L5);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m017_poke(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/io/ByteArrayBuffer;","poke",new String[]{ "I","Lorg/mortbay/io/Buffer;"},"I"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(11);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"index");
                ddv.visitParameterName(1,"src");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(273,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(282,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(283,L2);
                ddv.visitStartLocal(2,L2,"length","I",null);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(285,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(292,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(293,L5);
                ddv.visitStartLocal(5,L5,"src_array","[B",null);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(294,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(308,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(295,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(297,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(298,L10);
                ddv.visitStartLocal(3,L10,"s","I",null);
                DexLabel L11=new DexLabel();
                ddv.visitStartLocal(0,L11,"i","I",null);
                DexLabel L12=new DexLabel();
                ddv.visitStartLocal(4,L12,"s","I",null);
                DexLabel L13=new DexLabel();
                ddv.visitEndLocal(9,L13);
                ddv.visitEndLocal(3,L13);
                ddv.visitStartLocal(1,L13,"index","I",null);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(299,L14);
                DexLabel L15=new DexLabel();
                ddv.visitRestartLocal(9,L15);
                DexLabel L16=new DexLabel();
                ddv.visitRestartLocal(3,L16);
                DexLabel L17=new DexLabel();
                ddv.visitEndLocal(4,L17);
                ddv.visitEndLocal(1,L17);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(298,L18);
                DexLabel L19=new DexLabel();
                ddv.visitRestartLocal(4,L19);
                DexLabel L20=new DexLabel();
                ddv.visitRestartLocal(1,L20);
                DexLabel L21=new DexLabel();
                ddv.visitEndLocal(9,L21);
                ddv.visitEndLocal(3,L21);
                DexLabel L22=new DexLabel();
                ddv.visitLineNumber(300,L22);
                ddv.visitRestartLocal(9,L22);
                DexLabel L23=new DexLabel();
                ddv.visitLineNumber(303,L23);
                ddv.visitEndLocal(0,L23);
                ddv.visitEndLocal(4,L23);
                ddv.visitEndLocal(1,L23);
                DexLabel L24=new DexLabel();
                ddv.visitLineNumber(304,L24);
                ddv.visitRestartLocal(3,L24);
                DexLabel L25=new DexLabel();
                ddv.visitRestartLocal(0,L25);
                DexLabel L26=new DexLabel();
                ddv.visitRestartLocal(4,L26);
                DexLabel L27=new DexLabel();
                ddv.visitEndLocal(9,L27);
                ddv.visitEndLocal(3,L27);
                ddv.visitRestartLocal(1,L27);
                DexLabel L28=new DexLabel();
                ddv.visitLineNumber(305,L28);
                DexLabel L29=new DexLabel();
                ddv.visitRestartLocal(9,L29);
                DexLabel L30=new DexLabel();
                ddv.visitRestartLocal(3,L30);
                DexLabel L31=new DexLabel();
                ddv.visitEndLocal(4,L31);
                ddv.visitEndLocal(1,L31);
                DexLabel L32=new DexLabel();
                ddv.visitLineNumber(304,L32);
                DexLabel L33=new DexLabel();
                ddv.visitRestartLocal(4,L33);
                DexLabel L34=new DexLabel();
                ddv.visitRestartLocal(1,L34);
                DexLabel L35=new DexLabel();
                ddv.visitEndLocal(9,L35);
                ddv.visitEndLocal(3,L35);
                DexLabel L36=new DexLabel();
                ddv.visitRestartLocal(9,L36);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,6, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT,6,8,new Field("Lorg/mortbay/io/ByteArrayBuffer;","_hash","I"));
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 10},new Method("Lorg/mortbay/io/Buffer;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitLabel(L2);
                code.visitStmt3R(ADD_INT,6,9,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8},new Method("Lorg/mortbay/io/ByteArrayBuffer;","capacity",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,7);
                code.visitJumpStmt(IF_LE,6,7,L4);
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8},new Method("Lorg/mortbay/io/ByteArrayBuffer;","capacity",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,6);
                code.visitStmt3R(SUB_INT,2,6,9);
                code.visitLabel(L4);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 10},new Method("Lorg/mortbay/io/Buffer;","array",new String[]{ },"[B"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitLabel(L5);
                code.visitJumpStmt(IF_EQZ,5,-1,L8);
                code.visitLabel(L6);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 10},new Method("Lorg/mortbay/io/Buffer;","getIndex",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,6);
                code.visitFieldStmt(IGET_OBJECT,7,8,new Field("Lorg/mortbay/io/ByteArrayBuffer;","_bytes","[B"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 5,6,7,9,2},new Method("Lorg/mortbay/io/Portable;","arraycopy",new String[]{ "[B","I","[B","I","I"},"V"));
                code.visitLabel(L7);
                code.visitStmt1R(RETURN,2);
                code.visitLabel(L8);
                code.visitJumpStmt(IF_EQZ,5,-1,L23);
                code.visitLabel(L9);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 10},new Method("Lorg/mortbay/io/Buffer;","getIndex",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitLabel(L10);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L11);
                code.visitStmt2R(MOVE,4,3);
                code.visitLabel(L12);
                code.visitStmt2R(MOVE,1,9);
                code.visitLabel(L13);
                code.visitJumpStmt(IF_GE,0,2,L21);
                code.visitLabel(L14);
                code.visitStmt2R1N(ADD_INT_LIT8,9,1,1);
                code.visitLabel(L15);
                code.visitStmt2R1N(ADD_INT_LIT8,3,4,1);
                code.visitLabel(L16);
                code.visitStmt3R(AGET_BYTE,6,5,4);
                code.visitLabel(L17);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8,1,6},new Method("Lorg/mortbay/io/ByteArrayBuffer;","poke",new String[]{ "I","B"},"V"));
                code.visitLabel(L18);
                code.visitStmt2R1N(ADD_INT_LIT8,0,0,1);
                code.visitStmt2R(MOVE,4,3);
                code.visitLabel(L19);
                code.visitStmt2R(MOVE,1,9);
                code.visitLabel(L20);
                code.visitJumpStmt(GOTO,-1,-1,L13);
                code.visitLabel(L21);
                code.visitStmt2R(MOVE,9,1);
                code.visitLabel(L22);
                code.visitJumpStmt(GOTO,-1,-1,L7);
                code.visitLabel(L23);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 10},new Method("Lorg/mortbay/io/Buffer;","getIndex",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitLabel(L24);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L25);
                code.visitStmt2R(MOVE,4,3);
                code.visitLabel(L26);
                code.visitStmt2R(MOVE,1,9);
                code.visitLabel(L27);
                code.visitJumpStmt(IF_GE,0,2,L35);
                code.visitLabel(L28);
                code.visitFieldStmt(IGET_OBJECT,6,8,new Field("Lorg/mortbay/io/ByteArrayBuffer;","_bytes","[B"));
                code.visitStmt2R1N(ADD_INT_LIT8,9,1,1);
                code.visitLabel(L29);
                code.visitStmt2R1N(ADD_INT_LIT8,3,4,1);
                code.visitLabel(L30);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 10,4},new Method("Lorg/mortbay/io/Buffer;","peek",new String[]{ "I"},"B"));
                code.visitLabel(L31);
                code.visitStmt1R(MOVE_RESULT,7);
                code.visitStmt3R(APUT_BYTE,7,6,1);
                code.visitLabel(L32);
                code.visitStmt2R1N(ADD_INT_LIT8,0,0,1);
                code.visitStmt2R(MOVE,4,3);
                code.visitLabel(L33);
                code.visitStmt2R(MOVE,1,9);
                code.visitLabel(L34);
                code.visitJumpStmt(GOTO,-1,-1,L27);
                code.visitLabel(L35);
                code.visitStmt2R(MOVE,9,1);
                code.visitLabel(L36);
                code.visitJumpStmt(GOTO,-1,-1,L7);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m018_poke(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/io/ByteArrayBuffer;","poke",new String[]{ "I","[B","I","I"},"I"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(7);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"index");
                ddv.visitParameterName(1,"b");
                ddv.visitParameterName(2,"offset");
                ddv.visitParameterName(3,"length");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(314,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(322,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(324,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(330,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(332,L4);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT,0,2,new Field("Lorg/mortbay/io/ByteArrayBuffer;","_hash","I"));
                code.visitLabel(L1);
                code.visitStmt3R(ADD_INT,0,3,6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/io/ByteArrayBuffer;","capacity",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitJumpStmt(IF_LE,0,1,L3);
                code.visitLabel(L2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/io/ByteArrayBuffer;","capacity",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitStmt3R(SUB_INT,6,0,3);
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/io/ByteArrayBuffer;","_bytes","[B"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 4,5,0,3,6},new Method("Lorg/mortbay/io/Portable;","arraycopy",new String[]{ "[B","I","[B","I","I"},"V"));
                code.visitLabel(L4);
                code.visitStmt1R(RETURN,6);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m019_poke(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/io/ByteArrayBuffer;","poke",new String[]{ "I","B"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"index");
                ddv.visitParameterName(1,"b");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(268,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(269,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/io/ByteArrayBuffer;","_bytes","[B"));
                code.visitStmt3R(APUT_BYTE,3,0,2);
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m020_readFrom(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/io/ByteArrayBuffer;","readFrom",new String[]{ "Ljava/io/InputStream;","I"},"I"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(8);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"in");
                ddv.visitParameterName(1,"max");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(375,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(376,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(377,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(379,L3);
                ddv.visitStartLocal(2,L3,"p","I",null);
                DexLabel L4=new DexLabel();
                ddv.visitStartLocal(1,L4,"len","I",null);
                DexLabel L5=new DexLabel();
                ddv.visitStartLocal(3,L5,"total","I",null);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(380,L6);
                ddv.visitStartLocal(0,L6,"available","I",null);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(382,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(383,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(395,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(396,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(397,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(385,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(387,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(388,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(389,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(390,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(392,L17);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(397,L18);
                code.visitLabel(L0);
                code.visitJumpStmt(IF_LTZ,7,-1,L1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Lorg/mortbay/io/ByteArrayBuffer;","space",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,4);
                code.visitJumpStmt(IF_LE,7,4,L2);
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Lorg/mortbay/io/ByteArrayBuffer;","space",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,7);
                code.visitLabel(L2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Lorg/mortbay/io/ByteArrayBuffer;","putIndex",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitLabel(L3);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L4);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L5);
                code.visitStmt2R(MOVE,0,7);
                code.visitLabel(L6);
                code.visitJumpStmt(IF_GE,3,7,L9);
                code.visitLabel(L7);
                code.visitFieldStmt(IGET_OBJECT,4,5,new Field("Lorg/mortbay/io/ByteArrayBuffer;","_bytes","[B"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,4,2,0},new Method("Ljava/io/InputStream;","read",new String[]{ "[B","I","I"},"I"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitLabel(L8);
                code.visitJumpStmt(IF_GEZ,1,-1,L12);
                code.visitLabel(L9);
                DexLabel L19=new DexLabel();
                code.visitJumpStmt(IF_GEZ,1,-1,L19);
                code.visitJumpStmt(IF_NEZ,3,-1,L19);
                code.visitLabel(L10);
                code.visitConstStmt(CONST_4,4, Integer.valueOf(-1)); // int: 0xffffffff  float:NaN
                code.visitLabel(L11);
                code.visitStmt1R(RETURN,4);
                code.visitLabel(L12);
                code.visitJumpStmt(IF_LEZ,1,-1,L17);
                code.visitLabel(L13);
                code.visitStmt2R(ADD_INT_2ADDR,2,1);
                code.visitLabel(L14);
                code.visitStmt2R(ADD_INT_2ADDR,3,1);
                code.visitLabel(L15);
                code.visitStmt2R(SUB_INT_2ADDR,0,1);
                code.visitLabel(L16);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,2},new Method("Lorg/mortbay/io/ByteArrayBuffer;","setPutIndex",new String[]{ "I"},"V"));
                code.visitLabel(L17);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Ljava/io/InputStream;","available",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,4);
                code.visitJumpStmt(IF_GTZ,4,-1,L6);
                code.visitJumpStmt(GOTO,-1,-1,L9);
                code.visitLabel(L19);
                code.visitStmt2R(MOVE,4,3);
                code.visitLabel(L18);
                code.visitJumpStmt(GOTO,-1,-1,L11);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m021_space(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/io/ByteArrayBuffer;","space",new String[]{ },"I"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(403,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/io/ByteArrayBuffer;","_bytes","[B"));
                code.visitStmt2R(ARRAY_LENGTH,0,0);
                code.visitFieldStmt(IGET,1,2,new Field("Lorg/mortbay/io/ByteArrayBuffer;","_put","I"));
                code.visitStmt2R(SUB_INT_2ADDR,0,1);
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m022_wrap(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/io/ByteArrayBuffer;","wrap",new String[]{ "[B"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"b");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(357,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(358,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(359,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(360,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(361,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(362,L5);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/io/ByteArrayBuffer;","isReadOnly",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_EQZ,0,-1,L1);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/lang/IllegalStateException;");
                code.visitConstStmt(CONST_STRING,1,"READONLY");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1},new Method("Ljava/lang/IllegalStateException;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitStmt1R(THROW,0);
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/io/ByteArrayBuffer;","isImmutable",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_EQZ,0,-1,L2);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/lang/IllegalStateException;");
                code.visitConstStmt(CONST_STRING,1,"IMMUTABLE");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1},new Method("Ljava/lang/IllegalStateException;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitStmt1R(THROW,0);
                code.visitLabel(L2);
                code.visitFieldStmt(IPUT_OBJECT,3,2,new Field("Lorg/mortbay/io/ByteArrayBuffer;","_bytes","[B"));
                code.visitLabel(L3);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,0},new Method("Lorg/mortbay/io/ByteArrayBuffer;","setGetIndex",new String[]{ "I"},"V"));
                code.visitLabel(L4);
                code.visitStmt2R(ARRAY_LENGTH,0,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,0},new Method("Lorg/mortbay/io/ByteArrayBuffer;","setPutIndex",new String[]{ "I"},"V"));
                code.visitLabel(L5);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m023_wrap(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/io/ByteArrayBuffer;","wrap",new String[]{ "[B","I","I"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(6);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"b");
                ddv.visitParameterName(1,"off");
                ddv.visitParameterName(2,"len");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(343,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(344,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(345,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(346,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(347,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(348,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(349,L6);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/io/ByteArrayBuffer;","isReadOnly",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_EQZ,0,-1,L1);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/lang/IllegalStateException;");
                code.visitConstStmt(CONST_STRING,1,"READONLY");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1},new Method("Ljava/lang/IllegalStateException;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitStmt1R(THROW,0);
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/io/ByteArrayBuffer;","isImmutable",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_EQZ,0,-1,L2);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/lang/IllegalStateException;");
                code.visitConstStmt(CONST_STRING,1,"IMMUTABLE");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1},new Method("Ljava/lang/IllegalStateException;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitStmt1R(THROW,0);
                code.visitLabel(L2);
                code.visitFieldStmt(IPUT_OBJECT,3,2,new Field("Lorg/mortbay/io/ByteArrayBuffer;","_bytes","[B"));
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/io/ByteArrayBuffer;","clear",new String[]{ },"V"));
                code.visitLabel(L4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,4},new Method("Lorg/mortbay/io/ByteArrayBuffer;","setGetIndex",new String[]{ "I"},"V"));
                code.visitLabel(L5);
                code.visitStmt3R(ADD_INT,0,4,5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,0},new Method("Lorg/mortbay/io/ByteArrayBuffer;","setPutIndex",new String[]{ "I"},"V"));
                code.visitLabel(L6);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m024_writeTo(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/io/ByteArrayBuffer;","writeTo",new String[]{ "Ljava/io/OutputStream;"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"out");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(368,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(369,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(370,L2);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,3,new Field("Lorg/mortbay/io/ByteArrayBuffer;","_bytes","[B"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Lorg/mortbay/io/ByteArrayBuffer;","getIndex",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Lorg/mortbay/io/ByteArrayBuffer;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,0,1,2},new Method("Ljava/io/OutputStream;","write",new String[]{ "[B","I","I"},"V"));
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Lorg/mortbay/io/ByteArrayBuffer;","clear",new String[]{ },"V"));
                code.visitLabel(L2);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
