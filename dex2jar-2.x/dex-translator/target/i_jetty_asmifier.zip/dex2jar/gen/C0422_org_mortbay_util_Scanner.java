package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0422_org_mortbay_util_Scanner {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(ACC_PUBLIC,"Lorg/mortbay/util/Scanner;","Ljava/lang/Object;",new String[]{ });
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("Scanner.java");
        if(cv!=null){
            DexAnnotationVisitor av00 = cv.visitAnnotation("Ldalvik/annotation/MemberClasses;", Visibility.SYSTEM);
            if(av00 != null) {
                {
                    DexAnnotationVisitor av01 = av00.visitArray("value");
                    if(av01 != null) {
                        av01.visit(null, new DexType("Lorg/mortbay/util/Scanner$BulkListener;"));
                        av01.visit(null, new DexType("Lorg/mortbay/util/Scanner$DiscreteListener;"));
                        av01.visit(null, new DexType("Lorg/mortbay/util/Scanner$Listener;"));
                        av01.visitEnd();
                    }
                }
                av00.visitEnd();
            }
        }
        f000__currentScan(cv);
        f001__filter(cv);
        f002__listeners(cv);
        f003__prevScan(cv);
        f004__recursive(cv);
        f005__reportExisting(cv);
        f006__running(cv);
        f007__scanDirs(cv);
        f008__scanInterval(cv);
        f009__task(cv);
        f010__timer(cv);
        m000__init_(cv);
        m001_reportAddition(cv);
        m002_reportBulkChanges(cv);
        m003_reportChange(cv);
        m004_reportRemoval(cv);
        m005_scanFile(cv);
        m006_warn(cv);
        m007_addListener(cv);
        m008_getFilenameFilter(cv);
        m009_getRecursive(cv);
        m010_getScanDir(cv);
        m011_getScanDirs(cv);
        m012_getScanInterval(cv);
        m013_newTimer(cv);
        m014_newTimerTask(cv);
        m015_removeListener(cv);
        m016_reportDifferences(cv);
        m017_scan(cv);
        m018_scanFiles(cv);
        m019_schedule(cv);
        m020_setFilenameFilter(cv);
        m021_setRecursive(cv);
        m022_setReportExistingFilesOnStartup(cv);
        m023_setScanDir(cv);
        m024_setScanDirs(cv);
        m025_setScanInterval(cv);
        m026_start(cv);
        m027_stop(cv);
    }
    public static void f000__currentScan(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/util/Scanner;","_currentScan","Ljava/util/Map;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f001__filter(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/util/Scanner;","_filter","Ljava/io/FilenameFilter;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f002__listeners(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/util/Scanner;","_listeners","Ljava/util/List;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f003__prevScan(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/util/Scanner;","_prevScan","Ljava/util/Map;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f004__recursive(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/util/Scanner;","_recursive","Z"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f005__reportExisting(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/util/Scanner;","_reportExisting","Z"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f006__running(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE|ACC_VOLATILE, new Field("Lorg/mortbay/util/Scanner;","_running","Z"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f007__scanDirs(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/util/Scanner;","_scanDirs","Ljava/util/List;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f008__scanInterval(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/util/Scanner;","_scanInterval","I"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f009__task(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/util/Scanner;","_task","Ljava/util/TimerTask;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f010__timer(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/util/Scanner;","_timer","Ljava/util/Timer;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void m000__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/util/Scanner;","<init>",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(87,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(47,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(48,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(49,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(52,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(53,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(56,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(88,L8);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2},new Method("Ljava/lang/Object;","<init>",new String[]{ },"V"));
                code.visitLabel(L2);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/util/ArrayList;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/util/ArrayList;","<init>",new String[]{ },"V"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0},new Method("Ljava/util/Collections;","synchronizedList",new String[]{ "Ljava/util/List;"},"Ljava/util/List;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(IPUT_OBJECT,0,2,new Field("Lorg/mortbay/util/Scanner;","_listeners","Ljava/util/List;"));
                code.visitLabel(L3);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/util/HashMap;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/util/HashMap;","<init>",new String[]{ },"V"));
                code.visitFieldStmt(IPUT_OBJECT,0,2,new Field("Lorg/mortbay/util/Scanner;","_prevScan","Ljava/util/Map;"));
                code.visitLabel(L4);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/util/HashMap;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/util/HashMap;","<init>",new String[]{ },"V"));
                code.visitFieldStmt(IPUT_OBJECT,0,2,new Field("Lorg/mortbay/util/Scanner;","_currentScan","Ljava/util/Map;"));
                code.visitLabel(L5);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT_BOOLEAN,0,2,new Field("Lorg/mortbay/util/Scanner;","_running","Z"));
                code.visitLabel(L6);
                code.visitFieldStmt(IPUT_BOOLEAN,1,2,new Field("Lorg/mortbay/util/Scanner;","_reportExisting","Z"));
                code.visitLabel(L7);
                code.visitFieldStmt(IPUT_BOOLEAN,1,2,new Field("Lorg/mortbay/util/Scanner;","_recursive","Z"));
                code.visitLabel(L8);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001_reportAddition(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PRIVATE, new Method("Lorg/mortbay/util/Scanner;","reportAddition",new String[]{ "Ljava/lang/String;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(7);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                DexLabel L3=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2,L3},new String[]{ "Ljava/lang/Exception;","Ljava/lang/Error;"});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"filename");
                DexLabel L4=new DexLabel();
                ddv.visitPrologue(L4);
                ddv.visitLineNumber(403,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(404,L5);
                ddv.visitStartLocal(2,L5,"itor","Ljava/util/Iterator;",null);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(406,L6);
                ddv.visitLineNumber(409,L0);
                ddv.visitStartLocal(3,L0,"l","Ljava/lang/Object;",null);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(410,L7);
                ddv.visitLineNumber(412,L2);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(414,L8);
                ddv.visitStartLocal(1,L8,"e","Ljava/lang/Exception;",null);
                ddv.visitLineNumber(416,L3);
                ddv.visitEndLocal(1,L3);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(418,L9);
                ddv.visitStartLocal(1,L9,"e","Ljava/lang/Error;",null);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(421,L10);
                ddv.visitEndLocal(3,L10);
                ddv.visitEndLocal(1,L10);
                code.visitLabel(L4);
                code.visitFieldStmt(IGET_OBJECT,4,5,new Field("Lorg/mortbay/util/Scanner;","_listeners","Ljava/util/List;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 4},new Method("Ljava/util/List;","iterator",new String[]{ },"Ljava/util/Iterator;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitLabel(L5);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 2},new Method("Ljava/util/Iterator;","hasNext",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,4);
                code.visitJumpStmt(IF_EQZ,4,-1,L10);
                code.visitLabel(L6);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 2},new Method("Ljava/util/Iterator;","next",new String[]{ },"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitLabel(L0);
                code.visitTypeStmt(INSTANCE_OF,4,3,"Lorg/mortbay/util/Scanner$DiscreteListener;");
                code.visitJumpStmt(IF_EQZ,4,-1,L5);
                code.visitLabel(L7);
                code.visitStmt2R(MOVE_OBJECT,0,3);
                code.visitTypeStmt(CHECK_CAST,0,-1,"Lorg/mortbay/util/Scanner$DiscreteListener;");
                code.visitStmt2R(MOVE_OBJECT,4,0);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 4,6},new Method("Lorg/mortbay/util/Scanner$DiscreteListener;","fileAdded",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L1);
                code.visitJumpStmt(GOTO,-1,-1,L5);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,4);
                code.visitStmt2R(MOVE_OBJECT,1,4);
                code.visitLabel(L8);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 5,3,6,1},new Method("Lorg/mortbay/util/Scanner;","warn",new String[]{ "Ljava/lang/Object;","Ljava/lang/String;","Ljava/lang/Throwable;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L5);
                code.visitLabel(L3);
                code.visitStmt1R(MOVE_EXCEPTION,4);
                code.visitStmt2R(MOVE_OBJECT,1,4);
                code.visitLabel(L9);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 5,3,6,1},new Method("Lorg/mortbay/util/Scanner;","warn",new String[]{ "Ljava/lang/Object;","Ljava/lang/String;","Ljava/lang/Throwable;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L5);
                code.visitLabel(L10);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m002_reportBulkChanges(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PRIVATE, new Method("Lorg/mortbay/util/Scanner;","reportBulkChanges",new String[]{ "Ljava/util/List;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(7);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                DexLabel L3=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2,L3},new String[]{ "Ljava/lang/Exception;","Ljava/lang/Error;"});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"filenames");
                DexLabel L4=new DexLabel();
                ddv.visitPrologue(L4);
                ddv.visitLineNumber(479,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(480,L5);
                ddv.visitStartLocal(2,L5,"itor","Ljava/util/Iterator;",null);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(482,L6);
                ddv.visitLineNumber(485,L0);
                ddv.visitStartLocal(3,L0,"l","Ljava/lang/Object;",null);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(486,L7);
                ddv.visitLineNumber(488,L2);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(490,L8);
                ddv.visitStartLocal(1,L8,"e","Ljava/lang/Exception;",null);
                ddv.visitLineNumber(492,L3);
                ddv.visitEndLocal(1,L3);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(494,L9);
                ddv.visitStartLocal(1,L9,"e","Ljava/lang/Error;",null);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(497,L10);
                ddv.visitEndLocal(3,L10);
                ddv.visitEndLocal(1,L10);
                code.visitLabel(L4);
                code.visitFieldStmt(IGET_OBJECT,4,5,new Field("Lorg/mortbay/util/Scanner;","_listeners","Ljava/util/List;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 4},new Method("Ljava/util/List;","iterator",new String[]{ },"Ljava/util/Iterator;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitLabel(L5);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 2},new Method("Ljava/util/Iterator;","hasNext",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,4);
                code.visitJumpStmt(IF_EQZ,4,-1,L10);
                code.visitLabel(L6);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 2},new Method("Ljava/util/Iterator;","next",new String[]{ },"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitLabel(L0);
                code.visitTypeStmt(INSTANCE_OF,4,3,"Lorg/mortbay/util/Scanner$BulkListener;");
                code.visitJumpStmt(IF_EQZ,4,-1,L5);
                code.visitLabel(L7);
                code.visitStmt2R(MOVE_OBJECT,0,3);
                code.visitTypeStmt(CHECK_CAST,0,-1,"Lorg/mortbay/util/Scanner$BulkListener;");
                code.visitStmt2R(MOVE_OBJECT,4,0);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 4,6},new Method("Lorg/mortbay/util/Scanner$BulkListener;","filesChanged",new String[]{ "Ljava/util/List;"},"V"));
                code.visitLabel(L1);
                code.visitJumpStmt(GOTO,-1,-1,L5);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,4);
                code.visitStmt2R(MOVE_OBJECT,1,4);
                code.visitLabel(L8);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Ljava/lang/Object;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 5,3,4,1},new Method("Lorg/mortbay/util/Scanner;","warn",new String[]{ "Ljava/lang/Object;","Ljava/lang/String;","Ljava/lang/Throwable;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L5);
                code.visitLabel(L3);
                code.visitStmt1R(MOVE_EXCEPTION,4);
                code.visitStmt2R(MOVE_OBJECT,1,4);
                code.visitLabel(L9);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Ljava/lang/Object;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 5,3,4,1},new Method("Lorg/mortbay/util/Scanner;","warn",new String[]{ "Ljava/lang/Object;","Ljava/lang/String;","Ljava/lang/Throwable;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L5);
                code.visitLabel(L10);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m003_reportChange(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PRIVATE, new Method("Lorg/mortbay/util/Scanner;","reportChange",new String[]{ "Ljava/lang/String;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(7);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                DexLabel L3=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2,L3},new String[]{ "Ljava/lang/Exception;","Ljava/lang/Error;"});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"filename");
                DexLabel L4=new DexLabel();
                ddv.visitPrologue(L4);
                ddv.visitLineNumber(457,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(458,L5);
                ddv.visitStartLocal(2,L5,"itor","Ljava/util/Iterator;",null);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(460,L6);
                ddv.visitLineNumber(463,L0);
                ddv.visitStartLocal(3,L0,"l","Ljava/lang/Object;",null);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(464,L7);
                ddv.visitLineNumber(466,L2);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(468,L8);
                ddv.visitStartLocal(1,L8,"e","Ljava/lang/Exception;",null);
                ddv.visitLineNumber(470,L3);
                ddv.visitEndLocal(1,L3);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(472,L9);
                ddv.visitStartLocal(1,L9,"e","Ljava/lang/Error;",null);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(475,L10);
                ddv.visitEndLocal(3,L10);
                ddv.visitEndLocal(1,L10);
                code.visitLabel(L4);
                code.visitFieldStmt(IGET_OBJECT,4,5,new Field("Lorg/mortbay/util/Scanner;","_listeners","Ljava/util/List;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 4},new Method("Ljava/util/List;","iterator",new String[]{ },"Ljava/util/Iterator;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitLabel(L5);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 2},new Method("Ljava/util/Iterator;","hasNext",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,4);
                code.visitJumpStmt(IF_EQZ,4,-1,L10);
                code.visitLabel(L6);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 2},new Method("Ljava/util/Iterator;","next",new String[]{ },"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitLabel(L0);
                code.visitTypeStmt(INSTANCE_OF,4,3,"Lorg/mortbay/util/Scanner$DiscreteListener;");
                code.visitJumpStmt(IF_EQZ,4,-1,L5);
                code.visitLabel(L7);
                code.visitStmt2R(MOVE_OBJECT,0,3);
                code.visitTypeStmt(CHECK_CAST,0,-1,"Lorg/mortbay/util/Scanner$DiscreteListener;");
                code.visitStmt2R(MOVE_OBJECT,4,0);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 4,6},new Method("Lorg/mortbay/util/Scanner$DiscreteListener;","fileChanged",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L1);
                code.visitJumpStmt(GOTO,-1,-1,L5);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,4);
                code.visitStmt2R(MOVE_OBJECT,1,4);
                code.visitLabel(L8);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 5,3,6,1},new Method("Lorg/mortbay/util/Scanner;","warn",new String[]{ "Ljava/lang/Object;","Ljava/lang/String;","Ljava/lang/Throwable;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L5);
                code.visitLabel(L3);
                code.visitStmt1R(MOVE_EXCEPTION,4);
                code.visitStmt2R(MOVE_OBJECT,1,4);
                code.visitLabel(L9);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 5,3,6,1},new Method("Lorg/mortbay/util/Scanner;","warn",new String[]{ "Ljava/lang/Object;","Ljava/lang/String;","Ljava/lang/Throwable;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L5);
                code.visitLabel(L10);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m004_reportRemoval(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PRIVATE, new Method("Lorg/mortbay/util/Scanner;","reportRemoval",new String[]{ "Ljava/lang/String;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(7);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                DexLabel L3=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2,L3},new String[]{ "Ljava/lang/Exception;","Ljava/lang/Error;"});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"filename");
                DexLabel L4=new DexLabel();
                ddv.visitPrologue(L4);
                ddv.visitLineNumber(430,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(431,L5);
                ddv.visitStartLocal(2,L5,"itor","Ljava/util/Iterator;",null);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(433,L6);
                ddv.visitLineNumber(436,L0);
                ddv.visitStartLocal(3,L0,"l","Ljava/lang/Object;",null);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(437,L7);
                ddv.visitLineNumber(439,L2);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(441,L8);
                ddv.visitStartLocal(1,L8,"e","Ljava/lang/Exception;",null);
                ddv.visitLineNumber(443,L3);
                ddv.visitEndLocal(1,L3);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(445,L9);
                ddv.visitStartLocal(1,L9,"e","Ljava/lang/Error;",null);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(448,L10);
                ddv.visitEndLocal(3,L10);
                ddv.visitEndLocal(1,L10);
                code.visitLabel(L4);
                code.visitFieldStmt(IGET_OBJECT,4,5,new Field("Lorg/mortbay/util/Scanner;","_listeners","Ljava/util/List;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 4},new Method("Ljava/util/List;","iterator",new String[]{ },"Ljava/util/Iterator;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitLabel(L5);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 2},new Method("Ljava/util/Iterator;","hasNext",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,4);
                code.visitJumpStmt(IF_EQZ,4,-1,L10);
                code.visitLabel(L6);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 2},new Method("Ljava/util/Iterator;","next",new String[]{ },"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitLabel(L0);
                code.visitTypeStmt(INSTANCE_OF,4,3,"Lorg/mortbay/util/Scanner$DiscreteListener;");
                code.visitJumpStmt(IF_EQZ,4,-1,L5);
                code.visitLabel(L7);
                code.visitStmt2R(MOVE_OBJECT,0,3);
                code.visitTypeStmt(CHECK_CAST,0,-1,"Lorg/mortbay/util/Scanner$DiscreteListener;");
                code.visitStmt2R(MOVE_OBJECT,4,0);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 4,6},new Method("Lorg/mortbay/util/Scanner$DiscreteListener;","fileRemoved",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L1);
                code.visitJumpStmt(GOTO,-1,-1,L5);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,4);
                code.visitStmt2R(MOVE_OBJECT,1,4);
                code.visitLabel(L8);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 5,3,6,1},new Method("Lorg/mortbay/util/Scanner;","warn",new String[]{ "Ljava/lang/Object;","Ljava/lang/String;","Ljava/lang/Throwable;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L5);
                code.visitLabel(L3);
                code.visitStmt1R(MOVE_EXCEPTION,4);
                code.visitStmt2R(MOVE_OBJECT,1,4);
                code.visitLabel(L9);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 5,3,6,1},new Method("Lorg/mortbay/util/Scanner;","warn",new String[]{ "Ljava/lang/Object;","Ljava/lang/String;","Ljava/lang/Throwable;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L5);
                code.visitLabel(L10);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m005_scanFile(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PRIVATE, new Method("Lorg/mortbay/util/Scanner;","scanFile",new String[]{ "Ljava/io/File;","Ljava/util/Map;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(12);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ "Ljava/io/IOException;"});
                DexLabel L3=new DexLabel();
                DexLabel L4=new DexLabel();
                code.visitTryCatch(L3,L4,new DexLabel[]{L2},new String[]{ "Ljava/io/IOException;"});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"f");
                ddv.visitParameterName(1,"scanInfoMap");
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(366,L0);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(389,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(369,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(371,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(373,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(374,L9);
                ddv.visitStartLocal(5,L9,"name","Ljava/lang/String;",null);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(375,L10);
                ddv.visitStartLocal(3,L10,"lastModified","J",null);
                ddv.visitLineNumber(385,L2);
                ddv.visitEndLocal(5,L2);
                ddv.visitEndLocal(3,L2);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(387,L11);
                ddv.visitStartLocal(0,L11,"e","Ljava/io/IOException;",null);
                ddv.visitLineNumber(378,L3);
                ddv.visitEndLocal(0,L3);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(380,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(381,L13);
                ddv.visitStartLocal(1,L13,"files","[Ljava/io/File;",null);
                DexLabel L14=new DexLabel();
                ddv.visitStartLocal(2,L14,"i","I",null);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(382,L15);
                ddv.visitLineNumber(381,L4);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10},new Method("Ljava/io/File;","exists",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,6);
                code.visitJumpStmt(IF_NEZ,6,-1,L6);
                code.visitLabel(L5);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10},new Method("Ljava/io/File;","isFile",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,6);
                code.visitJumpStmt(IF_EQZ,6,-1,L3);
                code.visitLabel(L7);
                code.visitFieldStmt(IGET_OBJECT,6,9,new Field("Lorg/mortbay/util/Scanner;","_filter","Ljava/io/FilenameFilter;"));
                code.visitJumpStmt(IF_EQZ,6,-1,L8);
                code.visitFieldStmt(IGET_OBJECT,6,9,new Field("Lorg/mortbay/util/Scanner;","_filter","Ljava/io/FilenameFilter;"));
                code.visitJumpStmt(IF_EQZ,6,-1,L5);
                code.visitFieldStmt(IGET_OBJECT,6,9,new Field("Lorg/mortbay/util/Scanner;","_filter","Ljava/io/FilenameFilter;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10},new Method("Ljava/io/File;","getParentFile",new String[]{ },"Ljava/io/File;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10},new Method("Ljava/io/File;","getName",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 6,7,8},new Method("Ljava/io/FilenameFilter;","accept",new String[]{ "Ljava/io/File;","Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,6);
                code.visitJumpStmt(IF_EQZ,6,-1,L5);
                code.visitLabel(L8);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10},new Method("Ljava/io/File;","getCanonicalPath",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitLabel(L9);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10},new Method("Ljava/io/File;","lastModified",new String[]{ },"J"));
                code.visitStmt1R(MOVE_RESULT_WIDE,3);
                code.visitLabel(L10);
                code.visitTypeStmt(NEW_INSTANCE,6,-1,"Ljava/lang/Long;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 6,3,4},new Method("Ljava/lang/Long;","<init>",new String[]{ "J"},"V"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 11,5,6},new Method("Ljava/util/Map;","put",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitLabel(L1);
                code.visitJumpStmt(GOTO,-1,-1,L5);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,6);
                code.visitStmt2R(MOVE_OBJECT,0,6);
                code.visitLabel(L11);
                code.visitConstStmt(CONST_STRING,6,"Error scanning watched files");
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 6,0},new Method("Lorg/mortbay/log/Log;","warn",new String[]{ "Ljava/lang/String;","Ljava/lang/Throwable;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L5);
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10},new Method("Ljava/io/File;","isDirectory",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,6);
                code.visitJumpStmt(IF_EQZ,6,-1,L5);
                code.visitFieldStmt(IGET_BOOLEAN,6,9,new Field("Lorg/mortbay/util/Scanner;","_recursive","Z"));
                code.visitJumpStmt(IF_NEZ,6,-1,L12);
                code.visitFieldStmt(IGET_OBJECT,6,9,new Field("Lorg/mortbay/util/Scanner;","_scanDirs","Ljava/util/List;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 6,10},new Method("Ljava/util/List;","contains",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,6);
                code.visitJumpStmt(IF_EQZ,6,-1,L5);
                code.visitLabel(L12);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10},new Method("Ljava/io/File;","listFiles",new String[]{ },"[Ljava/io/File;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L13);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L14);
                code.visitStmt2R(ARRAY_LENGTH,6,1);
                code.visitJumpStmt(IF_GE,2,6,L5);
                code.visitLabel(L15);
                code.visitStmt3R(AGET_OBJECT,6,1,2);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 9,6,11},new Method("Lorg/mortbay/util/Scanner;","scanFile",new String[]{ "Ljava/io/File;","Ljava/util/Map;"},"V"));
                code.visitLabel(L4);
                code.visitStmt2R1N(ADD_INT_LIT8,2,2,1);
                code.visitJumpStmt(GOTO,-1,-1,L14);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m006_warn(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PRIVATE, new Method("Lorg/mortbay/util/Scanner;","warn",new String[]{ "Ljava/lang/Object;","Ljava/lang/String;","Ljava/lang/Throwable;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(6);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"listener");
                ddv.visitParameterName(1,"filename");
                ddv.visitParameterName(2,"th");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(393,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(394,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(395,L2);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 5},new Method("Lorg/mortbay/log/Log;","warn",new String[]{ "Ljava/lang/Throwable;"},"V"));
                code.visitLabel(L1);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,3},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitConstStmt(CONST_STRING,1," failed on \'");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,4},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0},new Method("Lorg/mortbay/log/Log;","warn",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L2);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m007_addListener(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/util/Scanner;","addListener",new String[]{ "Lorg/mortbay/util/Scanner$Listener;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"listener");
                DexLabel L3=new DexLabel();
                ddv.visitPrologue(L3);
                ddv.visitLineNumber(185,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(188,L4);
                ddv.visitLineNumber(187,L0);
                ddv.visitLineNumber(185,L2);
                code.visitLabel(L3);
                code.visitStmt1R(MONITOR_ENTER,1);
                code.visitJumpStmt(IF_NEZ,2,-1,L0);
                code.visitLabel(L4);
                code.visitStmt1R(MONITOR_EXIT,1);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/util/Scanner;","_listeners","Ljava/util/List;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,2},new Method("Ljava/util/List;","add",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitLabel(L1);
                code.visitJumpStmt(GOTO,-1,-1,L4);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,0);
                code.visitStmt1R(MONITOR_EXIT,1);
                code.visitStmt1R(THROW,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m008_getFilenameFilter(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/util/Scanner;","getFilenameFilter",new String[]{ },"Ljava/io/FilenameFilter;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(165,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/util/Scanner;","_filter","Ljava/io/FilenameFilter;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m009_getRecursive(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/util/Scanner;","getRecursive",new String[]{ },"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(147,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_BOOLEAN,0,1,new Field("Lorg/mortbay/util/Scanner;","_recursive","Z"));
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m010_getScanDir(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/util/Scanner;","getScanDir",new String[]{ },"Ljava/io/File;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(127,L0);
                DexLabel L1=new DexLabel();
                ddv.visitEndLocal(2,L1);
                DexLabel L2=new DexLabel();
                ddv.visitRestartLocal(2,L2);
                DexLabel L3=new DexLabel();
                ddv.visitEndLocal(2,L3);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/util/Scanner;","_scanDirs","Ljava/util/List;"));
                code.visitJumpStmt(IF_NEZ,0,-1,L2);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L1);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitLabel(L2);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/util/Scanner;","_scanDirs","Ljava/util/List;"));
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,1},new Method("Ljava/util/List;","get",new String[]{ "I"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitLabel(L3);
                code.visitTypeStmt(CHECK_CAST,2,-1,"Ljava/io/File;");
                code.visitStmt2R(MOVE_OBJECT,0,2);
                code.visitJumpStmt(GOTO,-1,-1,L1);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m011_getScanDirs(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/util/Scanner;","getScanDirs",new String[]{ },"Ljava/util/List;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(137,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/util/Scanner;","_scanDirs","Ljava/util/List;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m012_getScanInterval(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/util/Scanner;","getScanInterval",new String[]{ },"I"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(96,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET,0,1,new Field("Lorg/mortbay/util/Scanner;","_scanInterval","I"));
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m013_newTimer(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/util/Scanner;","newTimer",new String[]{ },"Ljava/util/Timer;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(238,L0);
                code.visitLabel(L0);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/util/Timer;");
                code.visitConstStmt(CONST_4,1, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1},new Method("Ljava/util/Timer;","<init>",new String[]{ "Z"},"V"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m014_newTimerTask(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/util/Scanner;","newTimerTask",new String[]{ },"Ljava/util/TimerTask;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(230,L0);
                code.visitLabel(L0);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Lorg/mortbay/util/Scanner$1;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1},new Method("Lorg/mortbay/util/Scanner$1;","<init>",new String[]{ "Lorg/mortbay/util/Scanner;"},"V"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m015_removeListener(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/util/Scanner;","removeListener",new String[]{ "Lorg/mortbay/util/Scanner$Listener;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"listener");
                DexLabel L3=new DexLabel();
                ddv.visitPrologue(L3);
                ddv.visitLineNumber(198,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(201,L4);
                ddv.visitLineNumber(200,L0);
                ddv.visitLineNumber(198,L2);
                code.visitLabel(L3);
                code.visitStmt1R(MONITOR_ENTER,1);
                code.visitJumpStmt(IF_NEZ,2,-1,L0);
                code.visitLabel(L4);
                code.visitStmt1R(MONITOR_EXIT,1);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/util/Scanner;","_listeners","Ljava/util/List;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,2},new Method("Ljava/util/List;","remove",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitLabel(L1);
                code.visitJumpStmt(GOTO,-1,-1,L4);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,0);
                code.visitStmt1R(MONITOR_EXIT,1);
                code.visitStmt1R(THROW,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m016_reportDifferences(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/util/Scanner;","reportDifferences",new String[]{ "Ljava/util/Map;","Ljava/util/Map;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(11);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"currentScan");
                ddv.visitParameterName(1,"oldScan");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(314,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(316,L1);
                ddv.visitStartLocal(0,L1,"bulkChanges","Ljava/util/List;",null);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(317,L2);
                ddv.visitStartLocal(5,L2,"oldScanKeys","Ljava/util/Set;",null);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(318,L3);
                ddv.visitStartLocal(3,L3,"itor","Ljava/util/Iterator;",null);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(320,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(321,L5);
                ddv.visitStartLocal(1,L5,"entry","Ljava/util/Map$Entry;",null);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(323,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(324,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(325,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(327,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(329,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(330,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(331,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(332,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(335,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(338,L15);
                ddv.visitEndLocal(1,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(341,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(342,L17);
                ddv.visitStartLocal(4,L17,"keyItor","Ljava/util/Iterator;",null);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(344,L18);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(345,L19);
                ddv.visitStartLocal(2,L19,"filename","Ljava/lang/String;",null);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(346,L20);
                DexLabel L21=new DexLabel();
                ddv.visitLineNumber(347,L21);
                DexLabel L22=new DexLabel();
                ddv.visitLineNumber(351,L22);
                ddv.visitEndLocal(4,L22);
                ddv.visitEndLocal(2,L22);
                DexLabel L23=new DexLabel();
                ddv.visitLineNumber(352,L23);
                DexLabel L24=new DexLabel();
                ddv.visitLineNumber(353,L24);
                code.visitLabel(L0);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/util/ArrayList;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/util/ArrayList;","<init>",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitTypeStmt(NEW_INSTANCE,5,-1,"Ljava/util/HashSet;");
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 10},new Method("Ljava/util/Map;","keySet",new String[]{ },"Ljava/util/Set;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 5,6},new Method("Ljava/util/HashSet;","<init>",new String[]{ "Ljava/util/Collection;"},"V"));
                code.visitLabel(L2);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 9},new Method("Ljava/util/Map;","entrySet",new String[]{ },"Ljava/util/Set;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 6},new Method("Ljava/util/Set;","iterator",new String[]{ },"Ljava/util/Iterator;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 3},new Method("Ljava/util/Iterator;","hasNext",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,6);
                code.visitJumpStmt(IF_EQZ,6,-1,L15);
                code.visitLabel(L4);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 3},new Method("Ljava/util/Iterator;","next",new String[]{ },"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitTypeStmt(CHECK_CAST,1,-1,"Ljava/util/Map$Entry;");
                code.visitLabel(L5);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 1},new Method("Ljava/util/Map$Entry;","getKey",new String[]{ },"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 5,6},new Method("Ljava/util/Set;","contains",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,6);
                code.visitJumpStmt(IF_NEZ,6,-1,L9);
                code.visitLabel(L6);
                code.visitTypeStmt(NEW_INSTANCE,6,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 6},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,7,"File added: ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,7},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 1},new Method("Ljava/util/Map$Entry;","getKey",new String[]{ },"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,7},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 6},new Method("Lorg/mortbay/log/Log;","debug",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L7);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 1},new Method("Ljava/util/Map$Entry;","getKey",new String[]{ },"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitTypeStmt(CHECK_CAST,6,-1,"Ljava/lang/String;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 8,6},new Method("Lorg/mortbay/util/Scanner;","reportAddition",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L8);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 1},new Method("Ljava/util/Map$Entry;","getKey",new String[]{ },"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,6},new Method("Ljava/util/List;","add",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitJumpStmt(GOTO,-1,-1,L3);
                code.visitLabel(L9);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 1},new Method("Ljava/util/Map$Entry;","getKey",new String[]{ },"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 10,6},new Method("Ljava/util/Map;","get",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 1},new Method("Ljava/util/Map$Entry;","getValue",new String[]{ },"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,7},new Method("Ljava/lang/Object;","equals",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,6);
                code.visitJumpStmt(IF_NEZ,6,-1,L14);
                code.visitLabel(L10);
                code.visitTypeStmt(NEW_INSTANCE,6,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 6},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,7,"File changed: ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,7},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 1},new Method("Ljava/util/Map$Entry;","getKey",new String[]{ },"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,7},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 6},new Method("Lorg/mortbay/log/Log;","debug",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L11);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 1},new Method("Ljava/util/Map$Entry;","getKey",new String[]{ },"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitTypeStmt(CHECK_CAST,6,-1,"Ljava/lang/String;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 8,6},new Method("Lorg/mortbay/util/Scanner;","reportChange",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L12);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 1},new Method("Ljava/util/Map$Entry;","getKey",new String[]{ },"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 5,6},new Method("Ljava/util/Set;","remove",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitLabel(L13);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 1},new Method("Ljava/util/Map$Entry;","getKey",new String[]{ },"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,6},new Method("Ljava/util/List;","add",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitJumpStmt(GOTO_16,-1,-1,L3);
                code.visitLabel(L14);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 1},new Method("Ljava/util/Map$Entry;","getKey",new String[]{ },"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 5,6},new Method("Ljava/util/Set;","remove",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitJumpStmt(GOTO_16,-1,-1,L3);
                code.visitLabel(L15);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 5},new Method("Ljava/util/Set;","isEmpty",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,6);
                code.visitJumpStmt(IF_NEZ,6,-1,L22);
                code.visitLabel(L16);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 5},new Method("Ljava/util/Set;","iterator",new String[]{ },"Ljava/util/Iterator;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitLabel(L17);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 4},new Method("Ljava/util/Iterator;","hasNext",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,6);
                code.visitJumpStmt(IF_EQZ,6,-1,L22);
                code.visitLabel(L18);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 4},new Method("Ljava/util/Iterator;","next",new String[]{ },"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitTypeStmt(CHECK_CAST,2,-1,"Ljava/lang/String;");
                code.visitLabel(L19);
                code.visitTypeStmt(NEW_INSTANCE,6,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 6},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,7,"File removed: ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,7},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,2},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 6},new Method("Lorg/mortbay/log/Log;","debug",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L20);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 8,2},new Method("Lorg/mortbay/util/Scanner;","reportRemoval",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L21);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,2},new Method("Ljava/util/List;","add",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitJumpStmt(GOTO,-1,-1,L17);
                code.visitLabel(L22);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0},new Method("Ljava/util/List;","isEmpty",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,6);
                code.visitJumpStmt(IF_NEZ,6,-1,L24);
                code.visitLabel(L23);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 8,0},new Method("Lorg/mortbay/util/Scanner;","reportBulkChanges",new String[]{ "Ljava/util/List;"},"V"));
                code.visitLabel(L24);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m017_scan(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/util/Scanner;","scan",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(279,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(280,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(281,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(282,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(283,L4);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/util/Scanner;","scanFiles",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/util/Scanner;","_currentScan","Ljava/util/Map;"));
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/util/Scanner;","_prevScan","Ljava/util/Map;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,0,1},new Method("Lorg/mortbay/util/Scanner;","reportDifferences",new String[]{ "Ljava/util/Map;","Ljava/util/Map;"},"V"));
                code.visitLabel(L2);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/util/Scanner;","_prevScan","Ljava/util/Map;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0},new Method("Ljava/util/Map;","clear",new String[]{ },"V"));
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/util/Scanner;","_prevScan","Ljava/util/Map;"));
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/util/Scanner;","_currentScan","Ljava/util/Map;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,1},new Method("Ljava/util/Map;","putAll",new String[]{ "Ljava/util/Map;"},"V"));
                code.visitLabel(L4);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m018_scanFiles(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/util/Scanner;","scanFiles",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(291,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(303,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(294,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(295,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(296,L4);
                ddv.visitStartLocal(1,L4,"itor","Ljava/util/Iterator;",null);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(298,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(300,L6);
                ddv.visitStartLocal(0,L6,"dir","Ljava/io/File;",null);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(301,L7);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,2,3,new Field("Lorg/mortbay/util/Scanner;","_scanDirs","Ljava/util/List;"));
                code.visitJumpStmt(IF_NEZ,2,-1,L2);
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L2);
                code.visitFieldStmt(IGET_OBJECT,2,3,new Field("Lorg/mortbay/util/Scanner;","_currentScan","Ljava/util/Map;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 2},new Method("Ljava/util/Map;","clear",new String[]{ },"V"));
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,2,3,new Field("Lorg/mortbay/util/Scanner;","_scanDirs","Ljava/util/List;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 2},new Method("Ljava/util/List;","iterator",new String[]{ },"Ljava/util/Iterator;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L4);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 1},new Method("Ljava/util/Iterator;","hasNext",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitJumpStmt(IF_EQZ,2,-1,L1);
                code.visitLabel(L5);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 1},new Method("Ljava/util/Iterator;","next",new String[]{ },"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitTypeStmt(CHECK_CAST,0,-1,"Ljava/io/File;");
                code.visitLabel(L6);
                code.visitJumpStmt(IF_EQZ,0,-1,L4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/io/File;","exists",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitJumpStmt(IF_EQZ,2,-1,L4);
                code.visitLabel(L7);
                code.visitFieldStmt(IGET_OBJECT,2,3,new Field("Lorg/mortbay/util/Scanner;","_currentScan","Ljava/util/Map;"));
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 3,0,2},new Method("Lorg/mortbay/util/Scanner;","scanFile",new String[]{ "Ljava/io/File;","Ljava/util/Map;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L4);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m019_schedule(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/util/Scanner;","schedule",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(9);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(243,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(245,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(246,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(247,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(248,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(249,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(251,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(252,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(253,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(256,L10);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_WIDE_16,6,Long.valueOf(1000L)); // long: 0x00000000000003e8  double:0.000000
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_BOOLEAN,0,8,new Field("Lorg/mortbay/util/Scanner;","_running","Z"));
                code.visitJumpStmt(IF_EQZ,0,-1,L10);
                code.visitLabel(L2);
                code.visitFieldStmt(IGET_OBJECT,0,8,new Field("Lorg/mortbay/util/Scanner;","_timer","Ljava/util/Timer;"));
                code.visitJumpStmt(IF_EQZ,0,-1,L4);
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,0,8,new Field("Lorg/mortbay/util/Scanner;","_timer","Ljava/util/Timer;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/util/Timer;","cancel",new String[]{ },"V"));
                code.visitLabel(L4);
                code.visitFieldStmt(IGET_OBJECT,0,8,new Field("Lorg/mortbay/util/Scanner;","_task","Ljava/util/TimerTask;"));
                code.visitJumpStmt(IF_EQZ,0,-1,L6);
                code.visitLabel(L5);
                code.visitFieldStmt(IGET_OBJECT,0,8,new Field("Lorg/mortbay/util/Scanner;","_task","Ljava/util/TimerTask;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/util/TimerTask;","cancel",new String[]{ },"Z"));
                code.visitLabel(L6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8},new Method("Lorg/mortbay/util/Scanner;","getScanInterval",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_LEZ,0,-1,L10);
                code.visitLabel(L7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8},new Method("Lorg/mortbay/util/Scanner;","newTimer",new String[]{ },"Ljava/util/Timer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(IPUT_OBJECT,0,8,new Field("Lorg/mortbay/util/Scanner;","_timer","Ljava/util/Timer;"));
                code.visitLabel(L8);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8},new Method("Lorg/mortbay/util/Scanner;","newTimerTask",new String[]{ },"Ljava/util/TimerTask;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(IPUT_OBJECT,0,8,new Field("Lorg/mortbay/util/Scanner;","_task","Ljava/util/TimerTask;"));
                code.visitLabel(L9);
                code.visitFieldStmt(IGET_OBJECT,0,8,new Field("Lorg/mortbay/util/Scanner;","_timer","Ljava/util/Timer;"));
                code.visitFieldStmt(IGET_OBJECT,1,8,new Field("Lorg/mortbay/util/Scanner;","_task","Ljava/util/TimerTask;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8},new Method("Lorg/mortbay/util/Scanner;","getScanInterval",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitStmt2R(INT_TO_LONG,2,2);
                code.visitStmt2R(MUL_LONG_2ADDR,2,6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8},new Method("Lorg/mortbay/util/Scanner;","getScanInterval",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,4);
                code.visitStmt2R(INT_TO_LONG,4,4);
                code.visitStmt2R(MUL_LONG_2ADDR,4,6);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 0,1,2,3,4,5},new Method("Ljava/util/Timer;","schedule",new String[]{ "Ljava/util/TimerTask;","J","J"},"V"));
                code.visitLabel(L10);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m020_setFilenameFilter(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/util/Scanner;","setFilenameFilter",new String[]{ "Ljava/io/FilenameFilter;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"filter");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(156,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(157,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_OBJECT,1,0,new Field("Lorg/mortbay/util/Scanner;","_filter","Ljava/io/FilenameFilter;"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m021_setRecursive(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/util/Scanner;","setRecursive",new String[]{ "Z"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"recursive");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(142,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(143,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_BOOLEAN,1,0,new Field("Lorg/mortbay/util/Scanner;","_recursive","Z"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m022_setReportExistingFilesOnStartup(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/util/Scanner;","setReportExistingFilesOnStartup",new String[]{ "Z"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"reportExisting");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(176,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(177,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_BOOLEAN,1,0,new Field("Lorg/mortbay/util/Scanner;","_reportExisting","Z"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m023_setScanDir(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/util/Scanner;","setScanDir",new String[]{ "Ljava/io/File;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"dir");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(116,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(117,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(118,L2);
                code.visitLabel(L0);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/util/ArrayList;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/util/ArrayList;","<init>",new String[]{ },"V"));
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/util/Scanner;","_scanDirs","Ljava/util/List;"));
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/util/Scanner;","_scanDirs","Ljava/util/List;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,2},new Method("Ljava/util/List;","add",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitLabel(L2);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m024_setScanDirs(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/util/Scanner;","setScanDirs",new String[]{ "Ljava/util/List;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"dirs");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(132,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(133,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_OBJECT,1,0,new Field("Lorg/mortbay/util/Scanner;","_scanDirs","Ljava/util/List;"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m025_setScanInterval(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/util/Scanner;","setScanInterval",new String[]{ "I"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"scanInterval");
                DexLabel L3=new DexLabel();
                ddv.visitPrologue(L3);
                ddv.visitLineNumber(105,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(106,L4);
                ddv.visitLineNumber(107,L1);
                ddv.visitLineNumber(105,L2);
                code.visitLabel(L3);
                code.visitStmt1R(MONITOR_ENTER,1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT,2,1,new Field("Lorg/mortbay/util/Scanner;","_scanInterval","I"));
                code.visitLabel(L4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Lorg/mortbay/util/Scanner;","schedule",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitStmt1R(MONITOR_EXIT,1);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,0);
                code.visitStmt1R(MONITOR_EXIT,1);
                code.visitStmt1R(THROW,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m026_start(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/util/Scanner;","start",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexLabel L3=new DexLabel();
                DexLabel L4=new DexLabel();
                code.visitTryCatch(L3,L4,new DexLabel[]{L2},new String[]{ null});
                DexLabel L5=new DexLabel();
                DexLabel L6=new DexLabel();
                code.visitTryCatch(L5,L6,new DexLabel[]{L2},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L7=new DexLabel();
                ddv.visitPrologue(L7);
                ddv.visitLineNumber(209,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(226,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(212,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(214,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(217,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(225,L12);
                ddv.visitLineNumber(209,L2);
                ddv.visitLineNumber(222,L5);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(223,L13);
                code.visitLabel(L7);
                code.visitStmt1R(MONITOR_ENTER,2);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_BOOLEAN,0,2,new Field("Lorg/mortbay/util/Scanner;","_running","Z"));
                code.visitLabel(L1);
                code.visitJumpStmt(IF_EQZ,0,-1,L9);
                code.visitLabel(L8);
                code.visitStmt1R(MONITOR_EXIT,2);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L9);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitLabel(L3);
                code.visitFieldStmt(IPUT_BOOLEAN,0,2,new Field("Lorg/mortbay/util/Scanner;","_running","Z"));
                code.visitLabel(L10);
                code.visitFieldStmt(IGET_BOOLEAN,0,2,new Field("Lorg/mortbay/util/Scanner;","_reportExisting","Z"));
                code.visitJumpStmt(IF_EQZ,0,-1,L5);
                code.visitLabel(L11);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/util/Scanner;","scan",new String[]{ },"V"));
                code.visitLabel(L12);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/util/Scanner;","schedule",new String[]{ },"V"));
                code.visitLabel(L4);
                code.visitJumpStmt(GOTO,-1,-1,L8);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,0);
                code.visitStmt1R(MONITOR_EXIT,2);
                code.visitStmt1R(THROW,0);
                code.visitLabel(L5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/util/Scanner;","scanFiles",new String[]{ },"V"));
                code.visitLabel(L13);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/util/Scanner;","_prevScan","Ljava/util/Map;"));
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/util/Scanner;","_currentScan","Ljava/util/Map;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,1},new Method("Ljava/util/Map;","putAll",new String[]{ "Ljava/util/Map;"},"V"));
                code.visitLabel(L6);
                code.visitJumpStmt(GOTO,-1,-1,L12);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m027_stop(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/util/Scanner;","stop",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L3=new DexLabel();
                ddv.visitPrologue(L3);
                ddv.visitLineNumber(262,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(264,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(265,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(266,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(267,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(268,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(269,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(270,L10);
                ddv.visitLineNumber(272,L1);
                ddv.visitLineNumber(262,L2);
                code.visitLabel(L3);
                code.visitStmt1R(MONITOR_ENTER,1);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_BOOLEAN,0,1,new Field("Lorg/mortbay/util/Scanner;","_running","Z"));
                code.visitJumpStmt(IF_EQZ,0,-1,L1);
                code.visitLabel(L4);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT_BOOLEAN,0,1,new Field("Lorg/mortbay/util/Scanner;","_running","Z"));
                code.visitLabel(L5);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/util/Scanner;","_timer","Ljava/util/Timer;"));
                code.visitJumpStmt(IF_EQZ,0,-1,L7);
                code.visitLabel(L6);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/util/Scanner;","_timer","Ljava/util/Timer;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/util/Timer;","cancel",new String[]{ },"V"));
                code.visitLabel(L7);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/util/Scanner;","_task","Ljava/util/TimerTask;"));
                code.visitJumpStmt(IF_EQZ,0,-1,L9);
                code.visitLabel(L8);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/util/Scanner;","_task","Ljava/util/TimerTask;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/util/TimerTask;","cancel",new String[]{ },"Z"));
                code.visitLabel(L9);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/util/Scanner;","_task","Ljava/util/TimerTask;"));
                code.visitLabel(L10);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/util/Scanner;","_timer","Ljava/util/Timer;"));
                code.visitLabel(L1);
                code.visitStmt1R(MONITOR_EXIT,1);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,0);
                code.visitStmt1R(MONITOR_EXIT,1);
                code.visitStmt1R(THROW,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
