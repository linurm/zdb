package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0195_org_mortbay_jetty_handler_AbstractHandlerContainer {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(ACC_PUBLIC|ACC_ABSTRACT,"Lorg/mortbay/jetty/handler/AbstractHandlerContainer;","Lorg/mortbay/jetty/handler/AbstractHandler;",new String[]{ "Lorg/mortbay/jetty/HandlerContainer;"});
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("AbstractHandlerContainer.java");
        m000__init_(cv);
        m001_expandChildren(cv);
        m002_expandHandler(cv);
        m003_getChildHandlerByClass(cv);
        m004_getChildHandlers(cv);
        m005_getChildHandlersByClass(cv);
    }
    public static void m000__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/jetty/handler/AbstractHandlerContainer;","<init>",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(1);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(38,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(39,L1);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Lorg/mortbay/jetty/handler/AbstractHandler;","<init>",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001_expandChildren(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Lorg/mortbay/jetty/handler/AbstractHandlerContainer;","expandChildren",new String[]{ "Ljava/lang/Object;","Ljava/lang/Class;"},"Ljava/lang/Object;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"list");
                ddv.visitParameterName(1,"byClass");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(68,L0);
                code.visitLabel(L0);
                code.visitStmt1R(RETURN_OBJECT,1);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m002_expandHandler(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Lorg/mortbay/jetty/handler/AbstractHandlerContainer;","expandHandler",new String[]{ "Lorg/mortbay/jetty/Handler;","Ljava/lang/Object;","Ljava/lang/Class;"},"Ljava/lang/Object;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(9);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"handler");
                ddv.visitParameterName(1,"list");
                ddv.visitParameterName(2,"byClass");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(74,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(89,L1);
                ddv.visitEndLocal(6,L1);
                ddv.visitEndLocal(7,L1);
                ddv.visitStartLocal(3,L1,"list","Ljava/lang/Object;",null);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(77,L2);
                ddv.visitEndLocal(3,L2);
                ddv.visitRestartLocal(6,L2);
                ddv.visitRestartLocal(7,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(78,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(80,L4);
                ddv.visitRestartLocal(7,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(81,L5);
                DexLabel L6=new DexLabel();
                ddv.visitEndLocal(6,L6);
                DexLabel L7=new DexLabel();
                ddv.visitRestartLocal(7,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(89,L8);
                ddv.visitRestartLocal(3,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(82,L9);
                ddv.visitEndLocal(3,L9);
                ddv.visitRestartLocal(6,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(84,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(85,L11);
                ddv.visitStartLocal(1,L11,"container","Lorg/mortbay/jetty/HandlerContainer;",null);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(86,L12);
                ddv.visitStartLocal(2,L12,"handlers","[Lorg/mortbay/jetty/Handler;",null);
                DexLabel L13=new DexLabel();
                ddv.visitRestartLocal(7,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(85,L14);
                ddv.visitEndLocal(2,L14);
                code.visitLabel(L0);
                code.visitJumpStmt(IF_NEZ,6,-1,L2);
                code.visitStmt2R(MOVE_OBJECT,3,7);
                code.visitLabel(L1);
                code.visitStmt1R(RETURN_OBJECT,3);
                code.visitLabel(L2);
                code.visitJumpStmt(IF_EQZ,6,-1,L4);
                code.visitJumpStmt(IF_EQZ,8,-1,L3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Ljava/lang/Object;","getClass",new String[]{ },"Ljava/lang/Class;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8,4},new Method("Ljava/lang/Class;","isAssignableFrom",new String[]{ "Ljava/lang/Class;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,4);
                code.visitJumpStmt(IF_EQZ,4,-1,L4);
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 7,6},new Method("Lorg/mortbay/util/LazyList;","add",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitLabel(L4);
                code.visitTypeStmt(INSTANCE_OF,4,6,"Lorg/mortbay/jetty/handler/AbstractHandlerContainer;");
                code.visitJumpStmt(IF_EQZ,4,-1,L9);
                code.visitLabel(L5);
                code.visitTypeStmt(CHECK_CAST,6,-1,"Lorg/mortbay/jetty/handler/AbstractHandlerContainer;");
                code.visitLabel(L6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,7,8},new Method("Lorg/mortbay/jetty/handler/AbstractHandlerContainer;","expandChildren",new String[]{ "Ljava/lang/Object;","Ljava/lang/Class;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitLabel(L7);
                code.visitStmt2R(MOVE_OBJECT,3,7);
                code.visitLabel(L8);
                code.visitJumpStmt(GOTO,-1,-1,L1);
                code.visitLabel(L9);
                code.visitTypeStmt(INSTANCE_OF,4,6,"Lorg/mortbay/jetty/HandlerContainer;");
                code.visitJumpStmt(IF_EQZ,4,-1,L7);
                code.visitLabel(L10);
                code.visitStmt2R(MOVE_OBJECT,0,6);
                code.visitTypeStmt(CHECK_CAST,0,-1,"Lorg/mortbay/jetty/HandlerContainer;");
                code.visitStmt2R(MOVE_OBJECT,1,0);
                code.visitLabel(L11);
                code.visitJumpStmt(IF_NEZ,8,-1,L14);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 1},new Method("Lorg/mortbay/jetty/HandlerContainer;","getChildHandlers",new String[]{ },"[Lorg/mortbay/jetty/Handler;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitStmt2R(MOVE_OBJECT,2,4);
                code.visitLabel(L12);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 7,2},new Method("Lorg/mortbay/util/LazyList;","addArray",new String[]{ "Ljava/lang/Object;","[Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitLabel(L13);
                code.visitJumpStmt(GOTO,-1,-1,L7);
                code.visitLabel(L14);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 1,8},new Method("Lorg/mortbay/jetty/HandlerContainer;","getChildHandlersByClass",new String[]{ "Ljava/lang/Class;"},"[Lorg/mortbay/jetty/Handler;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitStmt2R(MOVE_OBJECT,2,4);
                code.visitJumpStmt(GOTO,-1,-1,L12);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m003_getChildHandlerByClass(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/handler/AbstractHandlerContainer;","getChildHandlerByClass",new String[]{ "Ljava/lang/Class;"},"Lorg/mortbay/jetty/Handler;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"byclass");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(59,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(60,L2);
                ddv.visitStartLocal(0,L2,"list","Ljava/lang/Object;",null);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(62,L3);
                ddv.visitEndLocal(2,L3);
                DexLabel L4=new DexLabel();
                ddv.visitRestartLocal(2,L4);
                DexLabel L5=new DexLabel();
                ddv.visitEndLocal(2,L5);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,1,3},new Method("Lorg/mortbay/jetty/handler/AbstractHandlerContainer;","expandChildren",new String[]{ "Ljava/lang/Object;","Ljava/lang/Class;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L2);
                code.visitJumpStmt(IF_NEZ,0,-1,L4);
                code.visitLabel(L3);
                code.visitStmt1R(RETURN_OBJECT,1);
                code.visitLabel(L4);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0,1},new Method("Lorg/mortbay/util/LazyList;","get",new String[]{ "Ljava/lang/Object;","I"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitLabel(L5);
                code.visitTypeStmt(CHECK_CAST,2,-1,"Lorg/mortbay/jetty/Handler;");
                code.visitStmt2R(MOVE_OBJECT,1,2);
                code.visitJumpStmt(GOTO,-1,-1,L3);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m004_getChildHandlers(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/handler/AbstractHandlerContainer;","getChildHandlers",new String[]{ },"[Lorg/mortbay/jetty/Handler;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(44,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(45,L2);
                ddv.visitStartLocal(0,L2,"list","Ljava/lang/Object;",null);
                DexLabel L3=new DexLabel();
                ddv.visitEndLocal(2,L3);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,1,1},new Method("Lorg/mortbay/jetty/handler/AbstractHandlerContainer;","expandChildren",new String[]{ "Ljava/lang/Object;","Ljava/lang/Class;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L2);
                code.visitConstStmt(CONST_CLASS,1,new DexType("Lorg/mortbay/jetty/Handler;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0,1},new Method("Lorg/mortbay/util/LazyList;","toArray",new String[]{ "Ljava/lang/Object;","Ljava/lang/Class;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitLabel(L3);
                code.visitTypeStmt(CHECK_CAST,2,-1,"[Lorg/mortbay/jetty/Handler;");
                code.visitTypeStmt(CHECK_CAST,2,-1,"[Lorg/mortbay/jetty/Handler;");
                code.visitStmt1R(RETURN_OBJECT,2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m005_getChildHandlersByClass(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/handler/AbstractHandlerContainer;","getChildHandlersByClass",new String[]{ "Ljava/lang/Class;"},"[Lorg/mortbay/jetty/Handler;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"byclass");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(51,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(52,L1);
                ddv.visitStartLocal(0,L1,"list","Ljava/lang/Object;",null);
                DexLabel L2=new DexLabel();
                ddv.visitEndLocal(2,L2);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,1,3},new Method("Lorg/mortbay/jetty/handler/AbstractHandlerContainer;","expandChildren",new String[]{ "Ljava/lang/Object;","Ljava/lang/Class;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L1);
                code.visitConstStmt(CONST_CLASS,1,new DexType("Lorg/mortbay/jetty/Handler;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0,1},new Method("Lorg/mortbay/util/LazyList;","toArray",new String[]{ "Ljava/lang/Object;","Ljava/lang/Class;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitLabel(L2);
                code.visitTypeStmt(CHECK_CAST,2,-1,"[Lorg/mortbay/jetty/Handler;");
                code.visitTypeStmt(CHECK_CAST,2,-1,"[Lorg/mortbay/jetty/Handler;");
                code.visitStmt1R(RETURN_OBJECT,2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
