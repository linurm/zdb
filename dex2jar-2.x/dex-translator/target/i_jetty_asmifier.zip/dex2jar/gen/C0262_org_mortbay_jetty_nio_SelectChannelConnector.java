package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0262_org_mortbay_jetty_nio_SelectChannelConnector {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(ACC_PUBLIC,"Lorg/mortbay/jetty/nio/SelectChannelConnector;","Lorg/mortbay/jetty/nio/AbstractNIOConnector;",new String[]{ });
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("SelectChannelConnector.java");
        if(cv!=null){
            DexAnnotationVisitor av00 = cv.visitAnnotation("Ldalvik/annotation/MemberClasses;", Visibility.SYSTEM);
            if(av00 != null) {
                {
                    DexAnnotationVisitor av01 = av00.visitArray("value");
                    if(av01 != null) {
                        av01.visit(null, new DexType("Lorg/mortbay/jetty/nio/SelectChannelConnector$RetryContinuation;"));
                        av01.visit(null, new DexType("Lorg/mortbay/jetty/nio/SelectChannelConnector$ConnectorEndPoint;"));
                        av01.visitEnd();
                    }
                }
                av00.visitEnd();
            }
        }
        f000__acceptChannel(cv);
        f001__lowResourcesConnections(cv);
        f002__lowResourcesMaxIdleTime(cv);
        f003__manager(cv);
        m000__init_(cv);
        m001_access$000(cv);
        m002_access$100(cv);
        m003_access$200(cv);
        m004_accept(cv);
        m005_close(cv);
        m006_customize(cv);
        m007_doStart(cv);
        m008_doStop(cv);
        m009_getConnection(cv);
        m010_getDelaySelectKeyUpdate(cv);
        m011_getLocalPort(cv);
        m012_getLowResourcesConnections(cv);
        m013_getLowResourcesMaxIdleTime(cv);
        m014_newConnection(cv);
        m015_newContinuation(cv);
        m016_newEndPoint(cv);
        m017_open(cv);
        m018_persist(cv);
        m019_setDelaySelectKeyUpdate(cv);
        m020_setLowResourceMaxIdleTime(cv);
        m021_setLowResourcesConnections(cv);
        m022_setLowResourcesMaxIdleTime(cv);
        m023_setMaxIdleTime(cv);
    }
    public static void f000__acceptChannel(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PROTECTED|ACC_TRANSIENT, new Field("Lorg/mortbay/jetty/nio/SelectChannelConnector;","_acceptChannel","Ljava/nio/channels/ServerSocketChannel;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f001__lowResourcesConnections(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/nio/SelectChannelConnector;","_lowResourcesConnections","J"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f002__lowResourcesMaxIdleTime(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/nio/SelectChannelConnector;","_lowResourcesMaxIdleTime","J"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f003__manager(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/nio/SelectChannelConnector;","_manager","Lorg/mortbay/io/nio/SelectorManager;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void m000__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/jetty/nio/SelectChannelConnector;","<init>",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(118,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(70,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(119,L2);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1},new Method("Lorg/mortbay/jetty/nio/AbstractNIOConnector;","<init>",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Lorg/mortbay/jetty/nio/SelectChannelConnector$1;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1},new Method("Lorg/mortbay/jetty/nio/SelectChannelConnector$1;","<init>",new String[]{ "Lorg/mortbay/jetty/nio/SelectChannelConnector;"},"V"));
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/jetty/nio/SelectChannelConnector;","_manager","Lorg/mortbay/io/nio/SelectorManager;"));
                code.visitLabel(L2);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001_access$000(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_STATIC|ACC_SYNTHETIC, new Method("Lorg/mortbay/jetty/nio/SelectChannelConnector;","access$000",new String[]{ "Lorg/mortbay/jetty/nio/SelectChannelConnector;","Ljava/net/Socket;"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"x0");
                ddv.visitParameterName(1,"x1");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(64,L0);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Lorg/mortbay/jetty/nio/SelectChannelConnector;","configure",new String[]{ "Ljava/net/Socket;"},"V"));
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m002_access$100(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_STATIC|ACC_SYNTHETIC, new Method("Lorg/mortbay/jetty/nio/SelectChannelConnector;","access$100",new String[]{ "Lorg/mortbay/jetty/nio/SelectChannelConnector;","Lorg/mortbay/jetty/HttpConnection;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"x0");
                ddv.visitParameterName(1,"x1");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(64,L0);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Lorg/mortbay/jetty/nio/SelectChannelConnector;","connectionClosed",new String[]{ "Lorg/mortbay/jetty/HttpConnection;"},"V"));
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m003_access$200(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_STATIC|ACC_SYNTHETIC, new Method("Lorg/mortbay/jetty/nio/SelectChannelConnector;","access$200",new String[]{ "Lorg/mortbay/jetty/nio/SelectChannelConnector;","Lorg/mortbay/jetty/HttpConnection;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"x0");
                ddv.visitParameterName(1,"x1");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(64,L0);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Lorg/mortbay/jetty/nio/SelectChannelConnector;","connectionOpened",new String[]{ "Lorg/mortbay/jetty/HttpConnection;"},"V"));
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m004_accept(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/nio/SelectChannelConnector;","accept",new String[]{ "I"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"acceptorID");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(124,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(125,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/nio/SelectChannelConnector;","_manager","Lorg/mortbay/io/nio/SelectorManager;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,2},new Method("Lorg/mortbay/io/nio/SelectorManager;","doSelect",new String[]{ "I"},"V"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m005_close(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/nio/SelectChannelConnector;","close",new String[]{ },"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexLabel L3=new DexLabel();
                DexLabel L4=new DexLabel();
                DexLabel L5=new DexLabel();
                code.visitTryCatch(L3,L4,new DexLabel[]{L5,L2},new String[]{ "Ljava/lang/Exception;",null});
                DexLabel L6=new DexLabel();
                code.visitTryCatch(L4,L6,new DexLabel[]{L2},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L7=new DexLabel();
                ddv.visitPrologue(L7);
                ddv.visitLineNumber(130,L7);
                ddv.visitLineNumber(132,L0);
                ddv.visitLineNumber(136,L3);
                ddv.visitLineNumber(143,L4);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(144,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(145,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(146,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(147,L11);
                ddv.visitLineNumber(138,L5);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(140,L12);
                ddv.visitStartLocal(0,L12,"e","Ljava/lang/Exception;",null);
                ddv.visitLineNumber(146,L2);
                ddv.visitEndLocal(0,L2);
                code.visitLabel(L7);
                code.visitStmt1R(MONITOR_ENTER,2);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/jetty/nio/SelectChannelConnector;","_manager","Lorg/mortbay/io/nio/SelectorManager;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Lorg/mortbay/io/nio/SelectorManager;","isRunning",new String[]{ },"Z"));
                code.visitLabel(L1);
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitJumpStmt(IF_EQZ,1,-1,L4);
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/jetty/nio/SelectChannelConnector;","_manager","Lorg/mortbay/io/nio/SelectorManager;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Lorg/mortbay/io/nio/SelectorManager;","stop",new String[]{ },"V"));
                code.visitLabel(L4);
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/jetty/nio/SelectChannelConnector;","_acceptChannel","Ljava/nio/channels/ServerSocketChannel;"));
                code.visitJumpStmt(IF_EQZ,1,-1,L9);
                code.visitLabel(L8);
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/jetty/nio/SelectChannelConnector;","_acceptChannel","Ljava/nio/channels/ServerSocketChannel;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/nio/channels/ServerSocketChannel;","close",new String[]{ },"V"));
                code.visitLabel(L9);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT_OBJECT,1,2,new Field("Lorg/mortbay/jetty/nio/SelectChannelConnector;","_acceptChannel","Ljava/nio/channels/ServerSocketChannel;"));
                code.visitLabel(L10);
                code.visitStmt1R(MONITOR_EXIT,2);
                code.visitLabel(L11);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L5);
                code.visitStmt1R(MOVE_EXCEPTION,1);
                code.visitStmt2R(MOVE_OBJECT,0,1);
                code.visitLabel(L12);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0},new Method("Lorg/mortbay/log/Log;","warn",new String[]{ "Ljava/lang/Throwable;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L4);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,1);
                code.visitStmt1R(MONITOR_EXIT,2);
                code.visitLabel(L6);
                code.visitStmt1R(THROW,1);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m006_customize(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/nio/SelectChannelConnector;","customize",new String[]{ "Lorg/mortbay/io/EndPoint;","Lorg/mortbay/jetty/Request;"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(7);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"endpoint");
                ddv.visitParameterName(1,"request");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(152,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(153,L1);
                ddv.visitStartLocal(1,L1,"cep","Lorg/mortbay/jetty/nio/SelectChannelConnector$ConnectorEndPoint;",null);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(154,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(155,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(156,L4);
                code.visitLabel(L0);
                code.visitStmt2R(MOVE_OBJECT,0,5);
                code.visitTypeStmt(CHECK_CAST,0,-1,"Lorg/mortbay/jetty/nio/SelectChannelConnector$ConnectorEndPoint;");
                code.visitStmt2R(MOVE_OBJECT,1,0);
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Lorg/mortbay/jetty/nio/SelectChannelConnector$ConnectorEndPoint;","cancelIdle",new String[]{ },"V"));
                code.visitLabel(L2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Lorg/mortbay/jetty/nio/SelectChannelConnector$ConnectorEndPoint;","getSelectSet",new String[]{ },"Lorg/mortbay/io/nio/SelectorManager$SelectSet;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/io/nio/SelectorManager$SelectSet;","getNow",new String[]{ },"J"));
                code.visitStmt1R(MOVE_RESULT_WIDE,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,2,3},new Method("Lorg/mortbay/jetty/Request;","setTimeStamp",new String[]{ "J"},"V"));
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_SUPER,new int[]{ 4,5,6},new Method("Lorg/mortbay/jetty/nio/AbstractNIOConnector;","customize",new String[]{ "Lorg/mortbay/io/EndPoint;","Lorg/mortbay/jetty/Request;"},"V"));
                code.visitLabel(L4);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m007_doStart(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Lorg/mortbay/jetty/nio/SelectChannelConnector;","doStart",new String[]{ },"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/lang/Exception;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(310,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(311,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(312,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(313,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(314,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(315,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(316,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(317,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(318,L8);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,3,new Field("Lorg/mortbay/jetty/nio/SelectChannelConnector;","_manager","Lorg/mortbay/io/nio/SelectorManager;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Lorg/mortbay/jetty/nio/SelectChannelConnector;","getAcceptors",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Lorg/mortbay/io/nio/SelectorManager;","setSelectSets",new String[]{ "I"},"V"));
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,0,3,new Field("Lorg/mortbay/jetty/nio/SelectChannelConnector;","_manager","Lorg/mortbay/io/nio/SelectorManager;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Lorg/mortbay/jetty/nio/SelectChannelConnector;","getMaxIdleTime",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitStmt2R(INT_TO_LONG,1,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1,2},new Method("Lorg/mortbay/io/nio/SelectorManager;","setMaxIdleTime",new String[]{ "J"},"V"));
                code.visitLabel(L2);
                code.visitFieldStmt(IGET_OBJECT,0,3,new Field("Lorg/mortbay/jetty/nio/SelectChannelConnector;","_manager","Lorg/mortbay/io/nio/SelectorManager;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Lorg/mortbay/jetty/nio/SelectChannelConnector;","getLowResourcesConnections",new String[]{ },"J"));
                code.visitStmt1R(MOVE_RESULT_WIDE,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1,2},new Method("Lorg/mortbay/io/nio/SelectorManager;","setLowResourcesConnections",new String[]{ "J"},"V"));
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,0,3,new Field("Lorg/mortbay/jetty/nio/SelectChannelConnector;","_manager","Lorg/mortbay/io/nio/SelectorManager;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Lorg/mortbay/jetty/nio/SelectChannelConnector;","getLowResourcesMaxIdleTime",new String[]{ },"J"));
                code.visitStmt1R(MOVE_RESULT_WIDE,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1,2},new Method("Lorg/mortbay/io/nio/SelectorManager;","setLowResourcesMaxIdleTime",new String[]{ "J"},"V"));
                code.visitLabel(L4);
                code.visitFieldStmt(IGET_OBJECT,0,3,new Field("Lorg/mortbay/jetty/nio/SelectChannelConnector;","_manager","Lorg/mortbay/io/nio/SelectorManager;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/io/nio/SelectorManager;","start",new String[]{ },"V"));
                code.visitLabel(L5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Lorg/mortbay/jetty/nio/SelectChannelConnector;","open",new String[]{ },"V"));
                code.visitLabel(L6);
                code.visitFieldStmt(IGET_OBJECT,0,3,new Field("Lorg/mortbay/jetty/nio/SelectChannelConnector;","_manager","Lorg/mortbay/io/nio/SelectorManager;"));
                code.visitFieldStmt(IGET_OBJECT,1,3,new Field("Lorg/mortbay/jetty/nio/SelectChannelConnector;","_acceptChannel","Ljava/nio/channels/ServerSocketChannel;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Lorg/mortbay/io/nio/SelectorManager;","register",new String[]{ "Ljava/nio/channels/ServerSocketChannel;"},"V"));
                code.visitLabel(L7);
                code.visitMethodStmt(INVOKE_SUPER,new int[]{ 3},new Method("Lorg/mortbay/jetty/nio/AbstractNIOConnector;","doStart",new String[]{ },"V"));
                code.visitLabel(L8);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m008_doStop(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Lorg/mortbay/jetty/nio/SelectChannelConnector;","doStop",new String[]{ },"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/lang/Exception;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(1);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(326,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(327,L1);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_SUPER,new int[]{ 0},new Method("Lorg/mortbay/jetty/nio/AbstractNIOConnector;","doStop",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m009_getConnection(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/nio/SelectChannelConnector;","getConnection",new String[]{ },"Ljava/lang/Object;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(168,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/nio/SelectChannelConnector;","_acceptChannel","Ljava/nio/channels/ServerSocketChannel;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m010_getDelaySelectKeyUpdate(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/nio/SelectChannelConnector;","getDelaySelectKeyUpdate",new String[]{ },"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(180,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/nio/SelectChannelConnector;","_manager","Lorg/mortbay/io/nio/SelectorManager;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/io/nio/SelectorManager;","isDelaySelectKeyUpdate",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m011_getLocalPort(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/nio/SelectChannelConnector;","getLocalPort",new String[]{ },"I"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L3=new DexLabel();
                ddv.visitPrologue(L3);
                ddv.visitLineNumber(186,L3);
                ddv.visitLineNumber(188,L0);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(189,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(190,L5);
                ddv.visitLineNumber(191,L2);
                code.visitLabel(L3);
                code.visitStmt1R(MONITOR_ENTER,1);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/nio/SelectChannelConnector;","_acceptChannel","Ljava/nio/channels/ServerSocketChannel;"));
                code.visitJumpStmt(IF_EQZ,0,-1,L4);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/nio/SelectChannelConnector;","_acceptChannel","Ljava/nio/channels/ServerSocketChannel;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/nio/channels/ServerSocketChannel;","isOpen",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                DexLabel L6=new DexLabel();
                code.visitJumpStmt(IF_NEZ,0,-1,L6);
                code.visitLabel(L4);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(-1)); // int: 0xffffffff  float:NaN
                code.visitStmt1R(MONITOR_EXIT,1);
                code.visitLabel(L5);
                code.visitStmt1R(RETURN,0);
                code.visitLabel(L6);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/nio/SelectChannelConnector;","_acceptChannel","Ljava/nio/channels/ServerSocketChannel;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/nio/channels/ServerSocketChannel;","socket",new String[]{ },"Ljava/net/ServerSocket;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/net/ServerSocket;","getLocalPort",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitStmt1R(MONITOR_EXIT,1);
                code.visitJumpStmt(GOTO,-1,-1,L5);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,0);
                code.visitStmt1R(MONITOR_EXIT,1);
                code.visitLabel(L1);
                code.visitStmt1R(THROW,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m012_getLowResourcesConnections(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/nio/SelectChannelConnector;","getLowResourcesConnections",new String[]{ },"J"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(251,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_WIDE,0,2,new Field("Lorg/mortbay/jetty/nio/SelectChannelConnector;","_lowResourcesConnections","J"));
                code.visitStmt1R(RETURN_WIDE,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m013_getLowResourcesMaxIdleTime(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/nio/SelectChannelConnector;","getLowResourcesMaxIdleTime",new String[]{ },"J"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(272,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_WIDE,0,2,new Field("Lorg/mortbay/jetty/nio/SelectChannelConnector;","_lowResourcesMaxIdleTime","J"));
                code.visitStmt1R(RETURN_WIDE,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m014_newConnection(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Lorg/mortbay/jetty/nio/SelectChannelConnector;","newConnection",new String[]{ "Ljava/nio/channels/SocketChannel;","Lorg/mortbay/io/nio/SelectChannelEndPoint;"},"Lorg/mortbay/io/Connection;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"channel");
                ddv.visitParameterName(1,"endpoint");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(338,L0);
                code.visitLabel(L0);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Lorg/mortbay/jetty/HttpConnection;");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/jetty/nio/SelectChannelConnector;","getServer",new String[]{ },"Lorg/mortbay/jetty/Server;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,2,4,1},new Method("Lorg/mortbay/jetty/HttpConnection;","<init>",new String[]{ "Lorg/mortbay/jetty/Connector;","Lorg/mortbay/io/EndPoint;","Lorg/mortbay/jetty/Server;"},"V"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m015_newContinuation(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/nio/SelectChannelConnector;","newContinuation",new String[]{ },"Lorg/mortbay/util/ajax/Continuation;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(200,L0);
                code.visitLabel(L0);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Lorg/mortbay/jetty/nio/SelectChannelConnector$RetryContinuation;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Lorg/mortbay/jetty/nio/SelectChannelConnector$RetryContinuation;","<init>",new String[]{ },"V"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m016_newEndPoint(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Lorg/mortbay/jetty/nio/SelectChannelConnector;","newEndPoint",new String[]{ "Ljava/nio/channels/SocketChannel;","Lorg/mortbay/io/nio/SelectorManager$SelectSet;","Ljava/nio/channels/SelectionKey;"},"Lorg/mortbay/io/nio/SelectChannelEndPoint;"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"channel");
                ddv.visitParameterName(1,"selectSet");
                ddv.visitParameterName(2,"key");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(332,L0);
                code.visitLabel(L0);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Lorg/mortbay/jetty/nio/SelectChannelConnector$ConnectorEndPoint;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,2,3,4},new Method("Lorg/mortbay/jetty/nio/SelectChannelConnector$ConnectorEndPoint;","<init>",new String[]{ "Ljava/nio/channels/SocketChannel;","Lorg/mortbay/io/nio/SelectorManager$SelectSet;","Ljava/nio/channels/SelectionKey;"},"V"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m017_open(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/nio/SelectChannelConnector;","open",new String[]{ },"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L3=new DexLabel();
                ddv.visitPrologue(L3);
                ddv.visitLineNumber(206,L3);
                ddv.visitLineNumber(208,L0);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(211,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(214,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(215,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(216,L7);
                ddv.visitStartLocal(0,L7,"addr","Ljava/net/InetSocketAddress;",null);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(219,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(222,L9);
                ddv.visitEndLocal(0,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(223,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(215,L11);
                ddv.visitLineNumber(222,L2);
                code.visitLabel(L3);
                code.visitStmt1R(MONITOR_ENTER,4);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,1,4,new Field("Lorg/mortbay/jetty/nio/SelectChannelConnector;","_acceptChannel","Ljava/nio/channels/ServerSocketChannel;"));
                code.visitJumpStmt(IF_NEZ,1,-1,L9);
                code.visitLabel(L4);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Ljava/nio/channels/ServerSocketChannel;","open",new String[]{ },"Ljava/nio/channels/ServerSocketChannel;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitFieldStmt(IPUT_OBJECT,1,4,new Field("Lorg/mortbay/jetty/nio/SelectChannelConnector;","_acceptChannel","Ljava/nio/channels/ServerSocketChannel;"));
                code.visitLabel(L5);
                code.visitFieldStmt(IGET_OBJECT,1,4,new Field("Lorg/mortbay/jetty/nio/SelectChannelConnector;","_acceptChannel","Ljava/nio/channels/ServerSocketChannel;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/nio/channels/ServerSocketChannel;","socket",new String[]{ },"Ljava/net/ServerSocket;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Lorg/mortbay/jetty/nio/SelectChannelConnector;","getReuseAddress",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2},new Method("Ljava/net/ServerSocket;","setReuseAddress",new String[]{ "Z"},"V"));
                code.visitLabel(L6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Lorg/mortbay/jetty/nio/SelectChannelConnector;","getHost",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitJumpStmt(IF_NEZ,1,-1,L11);
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Ljava/net/InetSocketAddress;");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Lorg/mortbay/jetty/nio/SelectChannelConnector;","getPort",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1,2},new Method("Ljava/net/InetSocketAddress;","<init>",new String[]{ "I"},"V"));
                code.visitStmt2R(MOVE_OBJECT,0,1);
                code.visitLabel(L7);
                code.visitFieldStmt(IGET_OBJECT,1,4,new Field("Lorg/mortbay/jetty/nio/SelectChannelConnector;","_acceptChannel","Ljava/nio/channels/ServerSocketChannel;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/nio/channels/ServerSocketChannel;","socket",new String[]{ },"Ljava/net/ServerSocket;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Lorg/mortbay/jetty/nio/SelectChannelConnector;","getAcceptQueueSize",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,0,2},new Method("Ljava/net/ServerSocket;","bind",new String[]{ "Ljava/net/SocketAddress;","I"},"V"));
                code.visitLabel(L8);
                code.visitFieldStmt(IGET_OBJECT,1,4,new Field("Lorg/mortbay/jetty/nio/SelectChannelConnector;","_acceptChannel","Ljava/nio/channels/ServerSocketChannel;"));
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2},new Method("Ljava/nio/channels/ServerSocketChannel;","configureBlocking",new String[]{ "Z"},"Ljava/nio/channels/SelectableChannel;"));
                code.visitLabel(L9);
                code.visitStmt1R(MONITOR_EXIT,4);
                code.visitLabel(L10);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L11);
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Ljava/net/InetSocketAddress;");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Lorg/mortbay/jetty/nio/SelectChannelConnector;","getHost",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Lorg/mortbay/jetty/nio/SelectChannelConnector;","getPort",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1,2,3},new Method("Ljava/net/InetSocketAddress;","<init>",new String[]{ "Ljava/lang/String;","I"},"V"));
                code.visitStmt2R(MOVE_OBJECT,0,1);
                code.visitJumpStmt(GOTO,-1,-1,L7);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,1);
                code.visitStmt1R(MONITOR_EXIT,4);
                code.visitLabel(L1);
                code.visitStmt1R(THROW,1);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m018_persist(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/nio/SelectChannelConnector;","persist",new String[]{ "Lorg/mortbay/io/EndPoint;"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"endpoint");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(161,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(162,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(163,L2);
                code.visitLabel(L0);
                code.visitStmt2R(MOVE_OBJECT,0,3);
                code.visitTypeStmt(CHECK_CAST,0,-1,"Lorg/mortbay/jetty/nio/SelectChannelConnector$ConnectorEndPoint;");
                code.visitStmt2R(MOVE_OBJECT,1,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Lorg/mortbay/jetty/nio/SelectChannelConnector$ConnectorEndPoint;","scheduleIdle",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_SUPER,new int[]{ 2,3},new Method("Lorg/mortbay/jetty/nio/AbstractNIOConnector;","persist",new String[]{ "Lorg/mortbay/io/EndPoint;"},"V"));
                code.visitLabel(L2);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m019_setDelaySelectKeyUpdate(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/nio/SelectChannelConnector;","setDelaySelectKeyUpdate",new String[]{ "Z"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"delay");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(234,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(235,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/nio/SelectChannelConnector;","_manager","Lorg/mortbay/io/nio/SelectorManager;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,2},new Method("Lorg/mortbay/io/nio/SelectorManager;","setDelaySelectKeyUpdate",new String[]{ "Z"},"V"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m020_setLowResourceMaxIdleTime(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/nio/SelectChannelConnector;","setLowResourceMaxIdleTime",new String[]{ "I"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"lowResourcesMaxIdleTime");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(300,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(301,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(302,L2);
                code.visitLabel(L0);
                code.visitStmt2R(INT_TO_LONG,0,3);
                code.visitFieldStmt(IPUT_WIDE,0,2,new Field("Lorg/mortbay/jetty/nio/SelectChannelConnector;","_lowResourcesMaxIdleTime","J"));
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_SUPER,new int[]{ 2,3},new Method("Lorg/mortbay/jetty/nio/AbstractNIOConnector;","setLowResourceMaxIdleTime",new String[]{ "I"},"V"));
                code.visitLabel(L2);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m021_setLowResourcesConnections(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/nio/SelectChannelConnector;","setLowResourcesConnections",new String[]{ "J"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"lowResourcesConnections");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(263,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(264,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_WIDE,1,0,new Field("Lorg/mortbay/jetty/nio/SelectChannelConnector;","_lowResourcesConnections","J"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m022_setLowResourcesMaxIdleTime(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/nio/SelectChannelConnector;","setLowResourcesMaxIdleTime",new String[]{ "J"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"lowResourcesMaxIdleTime");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(286,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(287,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(288,L2);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_WIDE,2,1,new Field("Lorg/mortbay/jetty/nio/SelectChannelConnector;","_lowResourcesMaxIdleTime","J"));
                code.visitLabel(L1);
                code.visitStmt2R(LONG_TO_INT,0,2);
                code.visitMethodStmt(INVOKE_SUPER,new int[]{ 1,0},new Method("Lorg/mortbay/jetty/nio/AbstractNIOConnector;","setLowResourceMaxIdleTime",new String[]{ "I"},"V"));
                code.visitLabel(L2);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m023_setMaxIdleTime(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/nio/SelectChannelConnector;","setMaxIdleTime",new String[]{ "I"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"maxIdleTime");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(240,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(241,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(242,L2);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,3,new Field("Lorg/mortbay/jetty/nio/SelectChannelConnector;","_manager","Lorg/mortbay/io/nio/SelectorManager;"));
                code.visitStmt2R(INT_TO_LONG,1,4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1,2},new Method("Lorg/mortbay/io/nio/SelectorManager;","setMaxIdleTime",new String[]{ "J"},"V"));
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_SUPER,new int[]{ 3,4},new Method("Lorg/mortbay/jetty/nio/AbstractNIOConnector;","setMaxIdleTime",new String[]{ "I"},"V"));
                code.visitLabel(L2);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
