package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0276_org_mortbay_jetty_security_Credential_MD5 {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(ACC_PUBLIC,"Lorg/mortbay/jetty/security/Credential$MD5;","Lorg/mortbay/jetty/security/Credential;",new String[]{ });
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("Credential.java");
        if(cv!=null){
            DexAnnotationVisitor av00 = cv.visitAnnotation("Ldalvik/annotation/EnclosingClass;", Visibility.SYSTEM);
            if(av00 != null) {
                av00.visit("value", new DexType("Lorg/mortbay/jetty/security/Credential;"));
                av00.visitEnd();
            }
        }
        if(cv!=null){
            DexAnnotationVisitor av00 = cv.visitAnnotation("Ldalvik/annotation/InnerClass;", Visibility.SYSTEM);
            if(av00 != null) {
                av00.visit("accessFlags",  Integer.valueOf(9));
                av00.visit("name", "MD5");
                av00.visitEnd();
            }
        }
        f000___TYPE(cv);
        f001___md(cv);
        f002___md5Lock(cv);
        f003__digest(cv);
        m000__clinit_(cv);
        m001__init_(cv);
        m002_digest(cv);
        m003_check(cv);
        m004_getDigest(cv);
    }
    public static void f000___TYPE(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/security/Credential$MD5;","__TYPE","Ljava/lang/String;"), "MD5:");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f001___md(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE|ACC_STATIC, new Field("Lorg/mortbay/jetty/security/Credential$MD5;","__md","Ljava/security/MessageDigest;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f002___md5Lock(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/security/Credential$MD5;","__md5Lock","Ljava/lang/Object;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f003__digest(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/security/Credential$MD5;","_digest","[B"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void m000__clinit_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_STATIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/jetty/security/Credential$MD5;","<clinit>",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(1);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(106,L0);
                code.visitLabel(L0);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/lang/Object;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/lang/Object;","<init>",new String[]{ },"V"));
                code.visitFieldStmt(SPUT_OBJECT,0,-1,new Field("Lorg/mortbay/jetty/security/Credential$MD5;","__md5Lock","Ljava/lang/Object;"));
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_CONSTRUCTOR, new Method("Lorg/mortbay/jetty/security/Credential$MD5;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"digest");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(113,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(114,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(117,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(118,L4);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_STRING,1,"MD5:");
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2},new Method("Lorg/mortbay/jetty/security/Credential;","<init>",new String[]{ },"V"));
                code.visitLabel(L2);
                code.visitConstStmt(CONST_STRING,0,"MD5:");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,1},new Method("Ljava/lang/String;","startsWith",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_EQZ,0,-1,L3);
                code.visitConstStmt(CONST_STRING,0,"MD5:");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/lang/String;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,0},new Method("Ljava/lang/String;","substring",new String[]{ "I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitStmt2R(MOVE_OBJECT,3,0);
                code.visitLabel(L3);
                code.visitConstStmt(CONST_16,0, Integer.valueOf(16)); // int: 0x00000010  float:0.000000
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 3,0},new Method("Lorg/mortbay/util/TypeUtil;","parseBytes",new String[]{ "Ljava/lang/String;","I"},"[B"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(IPUT_OBJECT,0,2,new Field("Lorg/mortbay/jetty/security/Credential$MD5;","_digest","[B"));
                code.visitLabel(L4);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m002_digest(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Lorg/mortbay/jetty/security/Credential$MD5;","digest",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(7);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ "Ljava/lang/Exception;"});
                DexLabel L3=new DexLabel();
                DexLabel L4=new DexLabel();
                code.visitTryCatch(L1,L3,new DexLabel[]{L4},new String[]{ null});
                DexLabel L5=new DexLabel();
                DexLabel L6=new DexLabel();
                DexLabel L7=new DexLabel();
                code.visitTryCatch(L5,L6,new DexLabel[]{L7,L4},new String[]{ "Ljava/lang/Exception;",null});
                DexLabel L8=new DexLabel();
                code.visitTryCatch(L6,L8,new DexLabel[]{L4},new String[]{ null});
                DexLabel L9=new DexLabel();
                code.visitTryCatch(L8,L9,new DexLabel[]{L2},new String[]{ "Ljava/lang/Exception;"});
                DexLabel L10=new DexLabel();
                DexLabel L11=new DexLabel();
                code.visitTryCatch(L10,L11,new DexLabel[]{L4},new String[]{ null});
                code.visitTryCatch(L11,L2,new DexLabel[]{L2},new String[]{ "Ljava/lang/Exception;"});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"password");
                DexLabel L12=new DexLabel();
                ddv.visitPrologue(L12);
                ddv.visitLineNumber(186,L0);
                ddv.visitLineNumber(188,L1);
                ddv.visitLineNumber(190,L5);
                ddv.visitLineNumber(194,L6);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(195,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(196,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(197,L15);
                ddv.visitStartLocal(0,L15,"digest","[B",null);
                ddv.visitLineNumber(199,L8);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(204,L16);
                ddv.visitEndLocal(0,L16);
                ddv.visitLineNumber(191,L7);
                ddv.visitStartLocal(1,L10,"e","Ljava/lang/Exception;",null);
                ddv.visitLineNumber(197,L4);
                ddv.visitEndLocal(1,L4);
                ddv.visitLineNumber(201,L2);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(203,L17);
                ddv.visitRestartLocal(1,L17);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(204,L18);
                code.visitLabel(L12);
                code.visitConstStmt(CONST_4,5, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L0);
                code.visitFieldStmt(SGET_OBJECT,2,-1,new Field("Lorg/mortbay/jetty/security/Credential$MD5;","__md5Lock","Ljava/lang/Object;"));
                code.visitStmt1R(MONITOR_ENTER,2);
                code.visitLabel(L1);
                code.visitFieldStmt(SGET_OBJECT,3,-1,new Field("Lorg/mortbay/jetty/security/Credential$MD5;","__md","Ljava/security/MessageDigest;"));
                code.visitLabel(L3);
                code.visitJumpStmt(IF_NEZ,3,-1,L6);
                code.visitLabel(L5);
                code.visitConstStmt(CONST_STRING,3,"MD5");
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 3},new Method("Ljava/security/MessageDigest;","getInstance",new String[]{ "Ljava/lang/String;"},"Ljava/security/MessageDigest;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitFieldStmt(SPUT_OBJECT,3,-1,new Field("Lorg/mortbay/jetty/security/Credential$MD5;","__md","Ljava/security/MessageDigest;"));
                code.visitLabel(L6);
                code.visitFieldStmt(SGET_OBJECT,3,-1,new Field("Lorg/mortbay/jetty/security/Credential$MD5;","__md","Ljava/security/MessageDigest;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Ljava/security/MessageDigest;","reset",new String[]{ },"V"));
                code.visitLabel(L13);
                code.visitFieldStmt(SGET_OBJECT,3,-1,new Field("Lorg/mortbay/jetty/security/Credential$MD5;","__md","Ljava/security/MessageDigest;"));
                code.visitFieldStmt(SGET_OBJECT,4,-1,new Field("Lorg/mortbay/util/StringUtil;","__ISO_8859_1","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,4},new Method("Ljava/lang/String;","getBytes",new String[]{ "Ljava/lang/String;"},"[B"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,4},new Method("Ljava/security/MessageDigest;","update",new String[]{ "[B"},"V"));
                code.visitLabel(L14);
                code.visitFieldStmt(SGET_OBJECT,3,-1,new Field("Lorg/mortbay/jetty/security/Credential$MD5;","__md","Ljava/security/MessageDigest;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Ljava/security/MessageDigest;","digest",new String[]{ },"[B"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L15);
                code.visitStmt1R(MONITOR_EXIT,2);
                code.visitLabel(L8);
                code.visitTypeStmt(NEW_INSTANCE,2,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,3,"MD5:");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitConstStmt(CONST_16,3, Integer.valueOf(16)); // int: 0x00000010  float:0.000000
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0,3},new Method("Lorg/mortbay/util/TypeUtil;","toString",new String[]{ "[B","I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitLabel(L9);
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitLabel(L16);
                code.visitStmt1R(RETURN_OBJECT,2);
                code.visitLabel(L7);
                code.visitStmt1R(MOVE_EXCEPTION,3);
                code.visitStmt2R(MOVE_OBJECT,1,3);
                code.visitLabel(L10);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1},new Method("Lorg/mortbay/log/Log;","warn",new String[]{ "Ljava/lang/Throwable;"},"V"));
                code.visitStmt1R(MONITOR_EXIT,2);
                code.visitStmt2R(MOVE_OBJECT,2,5);
                code.visitJumpStmt(GOTO,-1,-1,L16);
                code.visitLabel(L4);
                code.visitStmt1R(MOVE_EXCEPTION,3);
                code.visitStmt1R(MONITOR_EXIT,2);
                code.visitLabel(L11);
                code.visitStmt1R(THROW,3);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,2);
                code.visitStmt2R(MOVE_OBJECT,1,2);
                code.visitLabel(L17);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1},new Method("Lorg/mortbay/log/Log;","warn",new String[]{ "Ljava/lang/Throwable;"},"V"));
                code.visitStmt2R(MOVE_OBJECT,2,5);
                code.visitLabel(L18);
                code.visitJumpStmt(GOTO,-1,-1,L16);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m003_check(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/security/Credential$MD5;","check",new String[]{ "Ljava/lang/Object;"},"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(13);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ "Ljava/lang/Exception;"});
                DexLabel L3=new DexLabel();
                DexLabel L4=new DexLabel();
                code.visitTryCatch(L1,L3,new DexLabel[]{L4},new String[]{ null});
                DexLabel L5=new DexLabel();
                DexLabel L6=new DexLabel();
                code.visitTryCatch(L5,L6,new DexLabel[]{L2},new String[]{ "Ljava/lang/Exception;"});
                DexLabel L7=new DexLabel();
                DexLabel L8=new DexLabel();
                code.visitTryCatch(L7,L8,new DexLabel[]{L4},new String[]{ null});
                code.visitTryCatch(L8,L2,new DexLabel[]{L2},new String[]{ "Ljava/lang/Exception;"});
                DexLabel L9=new DexLabel();
                DexLabel L10=new DexLabel();
                code.visitTryCatch(L9,L10,new DexLabel[]{L2},new String[]{ "Ljava/lang/Exception;"});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"credentials");
                DexLabel L11=new DexLabel();
                ddv.visitPrologue(L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(131,L12);
                ddv.visitLineNumber(133,L0);
                ddv.visitStartLocal(1,L0,"digest","[B",null);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(136,L13);
                ddv.visitLineNumber(138,L1);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(139,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(140,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(141,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(142,L17);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(143,L18);
                ddv.visitLineNumber(144,L3);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(176,L19);
                ddv.visitEndLocal(12,L19);
                ddv.visitLineNumber(143,L4);
                ddv.visitRestartLocal(12,L4);
                ddv.visitLineNumber(173,L2);
                ddv.visitEndLocal(12,L2);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(175,L20);
                ddv.visitStartLocal(2,L20,"e","Ljava/lang/Exception;",null);
                DexLabel L21=new DexLabel();
                ddv.visitLineNumber(176,L21);
                DexLabel L22=new DexLabel();
                ddv.visitLineNumber(146,L22);
                ddv.visitEndLocal(2,L22);
                ddv.visitRestartLocal(12,L22);
                ddv.visitStartLocal(3,L9,"i","I",null);
                DexLabel L23=new DexLabel();
                ddv.visitLineNumber(147,L23);
                DexLabel L24=new DexLabel();
                ddv.visitLineNumber(148,L24);
                DexLabel L25=new DexLabel();
                ddv.visitLineNumber(146,L25);
                DexLabel L26=new DexLabel();
                ddv.visitLineNumber(149,L26);
                DexLabel L27=new DexLabel();
                ddv.visitLineNumber(151,L27);
                ddv.visitEndLocal(3,L27);
                DexLabel L28=new DexLabel();
                ddv.visitLineNumber(153,L28);
                DexLabel L29=new DexLabel();
                ddv.visitLineNumber(154,L29);
                ddv.visitStartLocal(4,L29,"md5","Lorg/mortbay/jetty/security/Credential$MD5;",null);
                DexLabel L30=new DexLabel();
                ddv.visitLineNumber(155,L30);
                DexLabel L31=new DexLabel();
                ddv.visitLineNumber(156,L31);
                DexLabel L32=new DexLabel();
                ddv.visitRestartLocal(3,L32);
                DexLabel L33=new DexLabel();
                ddv.visitLineNumber(157,L33);
                DexLabel L34=new DexLabel();
                ddv.visitLineNumber(158,L34);
                DexLabel L35=new DexLabel();
                ddv.visitLineNumber(156,L35);
                DexLabel L36=new DexLabel();
                ddv.visitLineNumber(159,L36);
                DexLabel L37=new DexLabel();
                ddv.visitLineNumber(161,L37);
                ddv.visitEndLocal(4,L37);
                ddv.visitEndLocal(3,L37);
                DexLabel L38=new DexLabel();
                ddv.visitLineNumber(165,L38);
                DexLabel L39=new DexLabel();
                ddv.visitEndLocal(12,L39);
                DexLabel L40=new DexLabel();
                ddv.visitLineNumber(169,L40);
                ddv.visitRestartLocal(12,L40);
                DexLabel L41=new DexLabel();
                ddv.visitLineNumber(170,L41);
                code.visitLabel(L11);
                code.visitConstStmt(CONST_4,10, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitConstStmt(CONST_4,9, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L12);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L0);
                code.visitTypeStmt(INSTANCE_OF,5,12,"Lorg/mortbay/jetty/security/Password;");
                code.visitJumpStmt(IF_NEZ,5,-1,L13);
                code.visitTypeStmt(INSTANCE_OF,5,12,"Ljava/lang/String;");
                code.visitJumpStmt(IF_EQZ,5,-1,L27);
                code.visitLabel(L13);
                code.visitFieldStmt(SGET_OBJECT,5,-1,new Field("Lorg/mortbay/jetty/security/Credential$MD5;","__md5Lock","Ljava/lang/Object;"));
                code.visitStmt1R(MONITOR_ENTER,5);
                code.visitLabel(L1);
                code.visitFieldStmt(SGET_OBJECT,6,-1,new Field("Lorg/mortbay/jetty/security/Credential$MD5;","__md","Ljava/security/MessageDigest;"));
                code.visitJumpStmt(IF_NEZ,6,-1,L15);
                code.visitLabel(L14);
                code.visitConstStmt(CONST_STRING,6,"MD5");
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 6},new Method("Ljava/security/MessageDigest;","getInstance",new String[]{ "Ljava/lang/String;"},"Ljava/security/MessageDigest;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitFieldStmt(SPUT_OBJECT,6,-1,new Field("Lorg/mortbay/jetty/security/Credential$MD5;","__md","Ljava/security/MessageDigest;"));
                code.visitLabel(L15);
                code.visitFieldStmt(SGET_OBJECT,6,-1,new Field("Lorg/mortbay/jetty/security/Credential$MD5;","__md","Ljava/security/MessageDigest;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Ljava/security/MessageDigest;","reset",new String[]{ },"V"));
                code.visitLabel(L16);
                code.visitFieldStmt(SGET_OBJECT,6,-1,new Field("Lorg/mortbay/jetty/security/Credential$MD5;","__md","Ljava/security/MessageDigest;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 12},new Method("Ljava/lang/Object;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitFieldStmt(SGET_OBJECT,8,-1,new Field("Lorg/mortbay/util/StringUtil;","__ISO_8859_1","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7,8},new Method("Ljava/lang/String;","getBytes",new String[]{ "Ljava/lang/String;"},"[B"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,7},new Method("Ljava/security/MessageDigest;","update",new String[]{ "[B"},"V"));
                code.visitLabel(L17);
                code.visitFieldStmt(SGET_OBJECT,6,-1,new Field("Lorg/mortbay/jetty/security/Credential$MD5;","__md","Ljava/security/MessageDigest;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Ljava/security/MessageDigest;","digest",new String[]{ },"[B"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L18);
                code.visitStmt1R(MONITOR_EXIT,5);
                code.visitLabel(L3);
                DexLabel L42=new DexLabel();
                code.visitJumpStmt(IF_EQZ,1,-1,L42);
                code.visitLabel(L5);
                code.visitStmt2R(ARRAY_LENGTH,5,1);
                code.visitFieldStmt(IGET_OBJECT,6,11,new Field("Lorg/mortbay/jetty/security/Credential$MD5;","_digest","[B"));
                code.visitStmt2R(ARRAY_LENGTH,6,6);
                code.visitLabel(L6);
                code.visitJumpStmt(IF_EQ,5,6,L22);
                code.visitLabel(L42);
                code.visitStmt2R(MOVE,5,9);
                code.visitLabel(L19);
                code.visitStmt1R(RETURN,5);
                code.visitLabel(L4);
                code.visitStmt1R(MOVE_EXCEPTION,6);
                code.visitLabel(L7);
                code.visitStmt1R(MONITOR_EXIT,5);
                code.visitLabel(L8);
                code.visitStmt1R(THROW,6);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,5);
                code.visitStmt2R(MOVE_OBJECT,2,5);
                code.visitLabel(L20);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 2},new Method("Lorg/mortbay/log/Log;","warn",new String[]{ "Ljava/lang/Throwable;"},"V"));
                code.visitStmt2R(MOVE,5,9);
                code.visitLabel(L21);
                code.visitJumpStmt(GOTO,-1,-1,L19);
                code.visitLabel(L22);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L9);
                code.visitStmt2R(ARRAY_LENGTH,5,1);
                DexLabel L43=new DexLabel();
                code.visitJumpStmt(IF_GE,3,5,L43);
                code.visitLabel(L23);
                code.visitStmt3R(AGET_BYTE,5,1,3);
                code.visitFieldStmt(IGET_OBJECT,6,11,new Field("Lorg/mortbay/jetty/security/Credential$MD5;","_digest","[B"));
                code.visitStmt3R(AGET_BYTE,6,6,3);
                code.visitJumpStmt(IF_EQ,5,6,L25);
                code.visitStmt2R(MOVE,5,9);
                code.visitLabel(L24);
                code.visitJumpStmt(GOTO,-1,-1,L19);
                code.visitLabel(L25);
                code.visitStmt2R1N(ADD_INT_LIT8,3,3,1);
                code.visitJumpStmt(GOTO,-1,-1,L9);
                code.visitLabel(L43);
                code.visitStmt2R(MOVE,5,10);
                code.visitLabel(L26);
                code.visitJumpStmt(GOTO,-1,-1,L19);
                code.visitLabel(L27);
                code.visitTypeStmt(INSTANCE_OF,5,12,"Lorg/mortbay/jetty/security/Credential$MD5;");
                code.visitJumpStmt(IF_EQZ,5,-1,L37);
                code.visitLabel(L28);
                code.visitStmt2R(MOVE_OBJECT,0,12);
                code.visitTypeStmt(CHECK_CAST,0,-1,"Lorg/mortbay/jetty/security/Credential$MD5;");
                code.visitStmt2R(MOVE_OBJECT,4,0);
                code.visitLabel(L29);
                code.visitFieldStmt(IGET_OBJECT,5,11,new Field("Lorg/mortbay/jetty/security/Credential$MD5;","_digest","[B"));
                code.visitStmt2R(ARRAY_LENGTH,5,5);
                code.visitFieldStmt(IGET_OBJECT,6,4,new Field("Lorg/mortbay/jetty/security/Credential$MD5;","_digest","[B"));
                code.visitStmt2R(ARRAY_LENGTH,6,6);
                code.visitJumpStmt(IF_EQ,5,6,L31);
                code.visitStmt2R(MOVE,5,9);
                code.visitLabel(L30);
                code.visitJumpStmt(GOTO,-1,-1,L19);
                code.visitLabel(L31);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L32);
                code.visitFieldStmt(IGET_OBJECT,5,11,new Field("Lorg/mortbay/jetty/security/Credential$MD5;","_digest","[B"));
                code.visitStmt2R(ARRAY_LENGTH,5,5);
                DexLabel L44=new DexLabel();
                code.visitJumpStmt(IF_GE,3,5,L44);
                code.visitLabel(L33);
                code.visitFieldStmt(IGET_OBJECT,5,11,new Field("Lorg/mortbay/jetty/security/Credential$MD5;","_digest","[B"));
                code.visitStmt3R(AGET_BYTE,5,5,3);
                code.visitFieldStmt(IGET_OBJECT,6,4,new Field("Lorg/mortbay/jetty/security/Credential$MD5;","_digest","[B"));
                code.visitStmt3R(AGET_BYTE,6,6,3);
                code.visitJumpStmt(IF_EQ,5,6,L35);
                code.visitStmt2R(MOVE,5,9);
                code.visitLabel(L34);
                code.visitJumpStmt(GOTO,-1,-1,L19);
                code.visitLabel(L35);
                code.visitStmt2R1N(ADD_INT_LIT8,3,3,1);
                code.visitJumpStmt(GOTO,-1,-1,L32);
                code.visitLabel(L44);
                code.visitStmt2R(MOVE,5,10);
                code.visitLabel(L36);
                code.visitJumpStmt(GOTO,-1,-1,L19);
                code.visitLabel(L37);
                code.visitTypeStmt(INSTANCE_OF,5,12,"Lorg/mortbay/jetty/security/Credential;");
                code.visitJumpStmt(IF_EQZ,5,-1,L40);
                code.visitLabel(L38);
                code.visitTypeStmt(CHECK_CAST,12,-1,"Lorg/mortbay/jetty/security/Credential;");
                code.visitLabel(L39);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 12,11},new Method("Lorg/mortbay/jetty/security/Credential;","check",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,5);
                code.visitJumpStmt(GOTO,-1,-1,L19);
                code.visitLabel(L40);
                code.visitTypeStmt(NEW_INSTANCE,5,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 5},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,6,"Can\'t check ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,6},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 12},new Method("Ljava/lang/Object;","getClass",new String[]{ },"Ljava/lang/Class;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,6},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitConstStmt(CONST_STRING,6," against MD5");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,6},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 5},new Method("Lorg/mortbay/log/Log;","warn",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L10);
                code.visitStmt2R(MOVE,5,9);
                code.visitLabel(L41);
                code.visitJumpStmt(GOTO,-1,-1,L19);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m004_getDigest(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/security/Credential$MD5;","getDigest",new String[]{ },"[B"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(123,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/security/Credential$MD5;","_digest","[B"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
