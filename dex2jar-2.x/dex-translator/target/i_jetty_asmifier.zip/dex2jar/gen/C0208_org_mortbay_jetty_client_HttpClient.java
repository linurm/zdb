package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0208_org_mortbay_jetty_client_HttpClient {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(ACC_PUBLIC,"Lorg/mortbay/jetty/client/HttpClient;","Lorg/mortbay/jetty/AbstractBuffers;",new String[]{ "Lorg/mortbay/util/Attributes;"});
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("HttpClient.java");
        if(cv!=null){
            DexAnnotationVisitor av00 = cv.visitAnnotation("Ldalvik/annotation/MemberClasses;", Visibility.SYSTEM);
            if(av00 != null) {
                {
                    DexAnnotationVisitor av01 = av00.visitArray("value");
                    if(av01 != null) {
                        av01.visit(null, new DexType("Lorg/mortbay/jetty/client/HttpClient$Connector;"));
                        av01.visitEnd();
                    }
                }
                av00.visitEnd();
            }
        }
        f000_CONNECTOR_SELECT_CHANNEL(cv);
        f001_CONNECTOR_SOCKET(cv);
        f002__attributes(cv);
        f003__connector(cv);
        f004__connectorType(cv);
        f005__destinations(cv);
        f006__idleTimeout(cv);
        f007__keyManagerAlgorithm(cv);
        f008__keyManagerPassword(cv);
        f009__keyStoreLocation(cv);
        f010__keyStorePassword(cv);
        f011__keyStoreType(cv);
        f012__maxConnectionsPerAddress(cv);
        f013__maxRetries(cv);
        f014__noProxy(cv);
        f015__protocol(cv);
        f016__provider(cv);
        f017__proxy(cv);
        f018__proxyAuthentication(cv);
        f019__realmResolver(cv);
        f020__registeredListeners(cv);
        f021__secureRandomAlgorithm(cv);
        f022__soTimeout(cv);
        f023__sslContext(cv);
        f024__threadPool(cv);
        f025__timeout(cv);
        f026__timeoutQ(cv);
        f027__trustManagerAlgorithm(cv);
        f028__trustStoreLocation(cv);
        f029__trustStorePassword(cv);
        f030__trustStoreType(cv);
        f031__useDirectBuffers(cv);
        m000__init_(cv);
        m001_access$000(cv);
        m002_cancel(cv);
        m003_clearAttributes(cv);
        m004_doStart(cv);
        m005_doStop(cv);
        m006_dump(cv);
        m007_getAttribute(cv);
        m008_getAttributeNames(cv);
        m009_getConnectorType(cv);
        m010_getDestination(cv);
        m011_getIdleTimeout(cv);
        m012_getKeyStoreLocation(cv);
        m013_getLooseSSLContext(cv);
        m014_getMaxConnectionsPerAddress(cv);
        m015_getNoProxy(cv);
        m016_getProxy(cv);
        m017_getProxyAuthentication(cv);
        m018_getRealmResolver(cv);
        m019_getRegisteredListeners(cv);
        m020_getSSLContext(cv);
        m021_getSoTimeout(cv);
        m022_getStrictSSLContext(cv);
        m023_getThreadPool(cv);
        m024_getTimeout(cv);
        m025_getTrustStoreLocation(cv);
        m026_getUseDirectBuffers(cv);
        m027_hasRealms(cv);
        m028_isProxied(cv);
        m029_maxRetries(cv);
        m030_newBuffer(cv);
        m031_registerListener(cv);
        m032_removeAttribute(cv);
        m033_schedule(cv);
        m034_send(cv);
        m035_setAttribute(cv);
        m036_setConnectorType(cv);
        m037_setIdleTimeout(cv);
        m038_setKeyManagerPassword(cv);
        m039_setKeyStoreLocation(cv);
        m040_setKeyStorePassword(cv);
        m041_setMaxConnectionsPerAddress(cv);
        m042_setMaxRetries(cv);
        m043_setNoProxy(cv);
        m044_setProxy(cv);
        m045_setProxyAuthentication(cv);
        m046_setRealmResolver(cv);
        m047_setSoTimeout(cv);
        m048_setThreadPool(cv);
        m049_setTimeout(cv);
        m050_setTrustStoreLocation(cv);
        m051_setTrustStorePassword(cv);
        m052_setUseDirectBuffers(cv);
    }
    public static void f000_CONNECTOR_SELECT_CHANNEL(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/client/HttpClient;","CONNECTOR_SELECT_CHANNEL","I"),  Integer.valueOf(2));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f001_CONNECTOR_SOCKET(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/client/HttpClient;","CONNECTOR_SOCKET","I"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f002__attributes(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/client/HttpClient;","_attributes","Lorg/mortbay/util/AttributesMap;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f003__connector(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(0, new Field("Lorg/mortbay/jetty/client/HttpClient;","_connector","Lorg/mortbay/jetty/client/HttpClient$Connector;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f004__connectorType(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/client/HttpClient;","_connectorType","I"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f005__destinations(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/client/HttpClient;","_destinations","Ljava/util/Map;"), null);
        if(fv != null) {
            if(fv!=null){
                DexAnnotationVisitor av00 = fv.visitAnnotation("Ldalvik/annotation/Signature;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, "Ljava/util/Map");
                            av01.visit(null, "<");
                            av01.visit(null, "Lorg/mortbay/jetty/client/Address;");
                            av01.visit(null, "Lorg/mortbay/jetty/client/HttpDestination;");
                            av01.visit(null, ">;");
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            fv.visitEnd();
        }
    }
    public static void f006__idleTimeout(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/client/HttpClient;","_idleTimeout","J"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f007__keyManagerAlgorithm(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/client/HttpClient;","_keyManagerAlgorithm","Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f008__keyManagerPassword(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/client/HttpClient;","_keyManagerPassword","Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f009__keyStoreLocation(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/client/HttpClient;","_keyStoreLocation","Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f010__keyStorePassword(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/client/HttpClient;","_keyStorePassword","Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f011__keyStoreType(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/client/HttpClient;","_keyStoreType","Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f012__maxConnectionsPerAddress(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/client/HttpClient;","_maxConnectionsPerAddress","I"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f013__maxRetries(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/client/HttpClient;","_maxRetries","I"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f014__noProxy(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/client/HttpClient;","_noProxy","Ljava/util/Set;"), null);
        if(fv != null) {
            if(fv!=null){
                DexAnnotationVisitor av00 = fv.visitAnnotation("Ldalvik/annotation/Signature;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, "Ljava/util/Set");
                            av01.visit(null, "<");
                            av01.visit(null, "Ljava/lang/String;");
                            av01.visit(null, ">;");
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            fv.visitEnd();
        }
    }
    public static void f015__protocol(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/client/HttpClient;","_protocol","Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f016__provider(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/client/HttpClient;","_provider","Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f017__proxy(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/client/HttpClient;","_proxy","Lorg/mortbay/jetty/client/Address;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f018__proxyAuthentication(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/client/HttpClient;","_proxyAuthentication","Lorg/mortbay/jetty/client/security/Authorization;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f019__realmResolver(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/client/HttpClient;","_realmResolver","Lorg/mortbay/jetty/client/security/RealmResolver;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f020__registeredListeners(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/client/HttpClient;","_registeredListeners","Ljava/util/LinkedList;"), null);
        if(fv != null) {
            if(fv!=null){
                DexAnnotationVisitor av00 = fv.visitAnnotation("Ldalvik/annotation/Signature;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, "Ljava/util/LinkedList");
                            av01.visit(null, "<");
                            av01.visit(null, "Ljava/lang/String;");
                            av01.visit(null, ">;");
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            fv.visitEnd();
        }
    }
    public static void f021__secureRandomAlgorithm(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/client/HttpClient;","_secureRandomAlgorithm","Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f022__soTimeout(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/client/HttpClient;","_soTimeout","I"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f023__sslContext(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/client/HttpClient;","_sslContext","Ljavax/net/ssl/SSLContext;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f024__threadPool(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(0, new Field("Lorg/mortbay/jetty/client/HttpClient;","_threadPool","Lorg/mortbay/thread/ThreadPool;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f025__timeout(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/client/HttpClient;","_timeout","J"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f026__timeoutQ(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/client/HttpClient;","_timeoutQ","Lorg/mortbay/thread/Timeout;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f027__trustManagerAlgorithm(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/client/HttpClient;","_trustManagerAlgorithm","Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f028__trustStoreLocation(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/client/HttpClient;","_trustStoreLocation","Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f029__trustStorePassword(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/client/HttpClient;","_trustStorePassword","Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f030__trustStoreType(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/client/HttpClient;","_trustStoreType","Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f031__useDirectBuffers(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/client/HttpClient;","_useDirectBuffers","Z"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void m000__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/jetty/client/HttpClient;","<init>",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(82,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(87,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(88,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(89,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(90,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(93,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(94,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(95,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(96,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(100,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(105,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(107,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(110,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(112,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(116,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(122,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(451,L17);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_STRING,3,"SunX509");
                code.visitConstStmt(CONST_STRING,2,"JKS");
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 4},new Method("Lorg/mortbay/jetty/AbstractBuffers;","<init>",new String[]{ },"V"));
                code.visitLabel(L2);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(2)); // int: 0x00000002  float:0.000000
                code.visitFieldStmt(IPUT,0,4,new Field("Lorg/mortbay/jetty/client/HttpClient;","_connectorType","I"));
                code.visitLabel(L3);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitFieldStmt(IPUT_BOOLEAN,0,4,new Field("Lorg/mortbay/jetty/client/HttpClient;","_useDirectBuffers","Z"));
                code.visitLabel(L4);
                code.visitConstStmt(CONST_16,0, Integer.valueOf(32)); // int: 0x00000020  float:0.000000
                code.visitFieldStmt(IPUT,0,4,new Field("Lorg/mortbay/jetty/client/HttpClient;","_maxConnectionsPerAddress","I"));
                code.visitLabel(L5);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/util/HashMap;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/util/HashMap;","<init>",new String[]{ },"V"));
                code.visitFieldStmt(IPUT_OBJECT,0,4,new Field("Lorg/mortbay/jetty/client/HttpClient;","_destinations","Ljava/util/Map;"));
                code.visitLabel(L6);
                code.visitConstStmt(CONST_WIDE_16,0,Long.valueOf(20000L)); // long: 0x0000000000004e20  double:0.000000
                code.visitFieldStmt(IPUT_WIDE,0,4,new Field("Lorg/mortbay/jetty/client/HttpClient;","_idleTimeout","J"));
                code.visitLabel(L7);
                code.visitConstStmt(CONST_WIDE_32,0,Long.valueOf(320000L)); // long: 0x000000000004e200  double:0.000000
                code.visitFieldStmt(IPUT_WIDE,0,4,new Field("Lorg/mortbay/jetty/client/HttpClient;","_timeout","J"));
                code.visitLabel(L8);
                code.visitConstStmt(CONST_16,0, Integer.valueOf(10000)); // int: 0x00002710  float:0.000000
                code.visitFieldStmt(IPUT,0,4,new Field("Lorg/mortbay/jetty/client/HttpClient;","_soTimeout","I"));
                code.visitLabel(L9);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Lorg/mortbay/thread/Timeout;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Lorg/mortbay/thread/Timeout;","<init>",new String[]{ },"V"));
                code.visitFieldStmt(IPUT_OBJECT,0,4,new Field("Lorg/mortbay/jetty/client/HttpClient;","_timeoutQ","Lorg/mortbay/thread/Timeout;"));
                code.visitLabel(L10);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(3)); // int: 0x00000003  float:0.000000
                code.visitFieldStmt(IPUT,0,4,new Field("Lorg/mortbay/jetty/client/HttpClient;","_maxRetries","I"));
                code.visitLabel(L11);
                code.visitConstStmt(CONST_STRING,0,"JKS");
                code.visitFieldStmt(IPUT_OBJECT,2,4,new Field("Lorg/mortbay/jetty/client/HttpClient;","_keyStoreType","Ljava/lang/String;"));
                code.visitLabel(L12);
                code.visitConstStmt(CONST_STRING,0,"SunX509");
                code.visitFieldStmt(IPUT_OBJECT,3,4,new Field("Lorg/mortbay/jetty/client/HttpClient;","_keyManagerAlgorithm","Ljava/lang/String;"));
                code.visitLabel(L13);
                code.visitConstStmt(CONST_STRING,0,"JKS");
                code.visitFieldStmt(IPUT_OBJECT,2,4,new Field("Lorg/mortbay/jetty/client/HttpClient;","_trustStoreType","Ljava/lang/String;"));
                code.visitLabel(L14);
                code.visitConstStmt(CONST_STRING,0,"SunX509");
                code.visitFieldStmt(IPUT_OBJECT,3,4,new Field("Lorg/mortbay/jetty/client/HttpClient;","_trustManagerAlgorithm","Ljava/lang/String;"));
                code.visitLabel(L15);
                code.visitConstStmt(CONST_STRING,0,"TLS");
                code.visitFieldStmt(IPUT_OBJECT,0,4,new Field("Lorg/mortbay/jetty/client/HttpClient;","_protocol","Ljava/lang/String;"));
                code.visitLabel(L16);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Lorg/mortbay/util/AttributesMap;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Lorg/mortbay/util/AttributesMap;","<init>",new String[]{ },"V"));
                code.visitFieldStmt(IPUT_OBJECT,0,4,new Field("Lorg/mortbay/jetty/client/HttpClient;","_attributes","Lorg/mortbay/util/AttributesMap;"));
                code.visitLabel(L17);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001_access$000(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_STATIC|ACC_SYNTHETIC, new Method("Lorg/mortbay/jetty/client/HttpClient;","access$000",new String[]{ "Lorg/mortbay/jetty/client/HttpClient;"},"Lorg/mortbay/thread/Timeout;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"x0");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(82,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/client/HttpClient;","_timeoutQ","Lorg/mortbay/thread/Timeout;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m002_cancel(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/client/HttpClient;","cancel",new String[]{ "Lorg/mortbay/thread/Timeout$Task;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"task");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(248,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(249,L1);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Lorg/mortbay/thread/Timeout$Task;","cancel",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m003_clearAttributes(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/client/HttpClient;","clearAttributes",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(212,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(213,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/client/HttpClient;","_attributes","Lorg/mortbay/util/AttributesMap;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/util/AttributesMap;","clearAttributes",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m004_doStart(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Lorg/mortbay/jetty/client/HttpClient;","doStart",new String[]{ },"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/lang/Exception;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(379,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(381,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(382,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(384,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(386,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(387,L5);
                ddv.visitStartLocal(0,L5,"pool","Lorg/mortbay/thread/QueuedThreadPool;",null);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(388,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(389,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(390,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(393,L9);
                ddv.visitEndLocal(0,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(395,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(399,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(402,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(408,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(410,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(430,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(406,L16);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_SUPER,new int[]{ 4},new Method("Lorg/mortbay/jetty/AbstractBuffers;","doStart",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,1,4,new Field("Lorg/mortbay/jetty/client/HttpClient;","_timeoutQ","Lorg/mortbay/thread/Timeout;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Lorg/mortbay/thread/Timeout;","setNow",new String[]{ },"J"));
                code.visitLabel(L2);
                code.visitFieldStmt(IGET_OBJECT,1,4,new Field("Lorg/mortbay/jetty/client/HttpClient;","_timeoutQ","Lorg/mortbay/thread/Timeout;"));
                code.visitFieldStmt(IGET_WIDE,2,4,new Field("Lorg/mortbay/jetty/client/HttpClient;","_timeout","J"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2,3},new Method("Lorg/mortbay/thread/Timeout;","setDuration",new String[]{ "J"},"V"));
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,1,4,new Field("Lorg/mortbay/jetty/client/HttpClient;","_threadPool","Lorg/mortbay/thread/ThreadPool;"));
                code.visitJumpStmt(IF_NEZ,1,-1,L9);
                code.visitLabel(L4);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Lorg/mortbay/thread/QueuedThreadPool;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Lorg/mortbay/thread/QueuedThreadPool;","<init>",new String[]{ },"V"));
                code.visitLabel(L5);
                code.visitConstStmt(CONST_16,1, Integer.valueOf(16)); // int: 0x00000010  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Lorg/mortbay/thread/QueuedThreadPool;","setMaxThreads",new String[]{ "I"},"V"));
                code.visitLabel(L6);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Lorg/mortbay/thread/QueuedThreadPool;","setDaemon",new String[]{ "Z"},"V"));
                code.visitLabel(L7);
                code.visitConstStmt(CONST_STRING,1,"HttpClient");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Lorg/mortbay/thread/QueuedThreadPool;","setName",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L8);
                code.visitFieldStmt(IPUT_OBJECT,0,4,new Field("Lorg/mortbay/jetty/client/HttpClient;","_threadPool","Lorg/mortbay/thread/ThreadPool;"));
                code.visitLabel(L9);
                code.visitFieldStmt(IGET_OBJECT,1,4,new Field("Lorg/mortbay/jetty/client/HttpClient;","_threadPool","Lorg/mortbay/thread/ThreadPool;"));
                code.visitTypeStmt(INSTANCE_OF,1,1,"Lorg/mortbay/component/LifeCycle;");
                code.visitJumpStmt(IF_EQZ,1,-1,L11);
                code.visitLabel(L10);
                code.visitFieldStmt(IGET_OBJECT,1,4,new Field("Lorg/mortbay/jetty/client/HttpClient;","_threadPool","Lorg/mortbay/thread/ThreadPool;"));
                code.visitTypeStmt(CHECK_CAST,1,-1,"Lorg/mortbay/component/LifeCycle;");
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 1},new Method("Lorg/mortbay/component/LifeCycle;","start",new String[]{ },"V"));
                code.visitLabel(L11);
                code.visitFieldStmt(IGET,1,4,new Field("Lorg/mortbay/jetty/client/HttpClient;","_connectorType","I"));
                code.visitConstStmt(CONST_4,2, Integer.valueOf(2)); // int: 0x00000002  float:0.000000
                code.visitJumpStmt(IF_NE,1,2,L16);
                code.visitLabel(L12);
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Lorg/mortbay/jetty/client/SelectConnector;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1,4},new Method("Lorg/mortbay/jetty/client/SelectConnector;","<init>",new String[]{ "Lorg/mortbay/jetty/client/HttpClient;"},"V"));
                code.visitFieldStmt(IPUT_OBJECT,1,4,new Field("Lorg/mortbay/jetty/client/HttpClient;","_connector","Lorg/mortbay/jetty/client/HttpClient$Connector;"));
                code.visitLabel(L13);
                code.visitFieldStmt(IGET_OBJECT,1,4,new Field("Lorg/mortbay/jetty/client/HttpClient;","_connector","Lorg/mortbay/jetty/client/HttpClient$Connector;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 1},new Method("Lorg/mortbay/jetty/client/HttpClient$Connector;","start",new String[]{ },"V"));
                code.visitLabel(L14);
                code.visitFieldStmt(IGET_OBJECT,1,4,new Field("Lorg/mortbay/jetty/client/HttpClient;","_threadPool","Lorg/mortbay/thread/ThreadPool;"));
                code.visitTypeStmt(NEW_INSTANCE,2,-1,"Lorg/mortbay/jetty/client/HttpClient$1;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2,4},new Method("Lorg/mortbay/jetty/client/HttpClient$1;","<init>",new String[]{ "Lorg/mortbay/jetty/client/HttpClient;"},"V"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 1,2},new Method("Lorg/mortbay/thread/ThreadPool;","dispatch",new String[]{ "Ljava/lang/Runnable;"},"Z"));
                code.visitLabel(L15);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L16);
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Lorg/mortbay/jetty/client/SocketConnector;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1,4},new Method("Lorg/mortbay/jetty/client/SocketConnector;","<init>",new String[]{ "Lorg/mortbay/jetty/client/HttpClient;"},"V"));
                code.visitFieldStmt(IPUT_OBJECT,1,4,new Field("Lorg/mortbay/jetty/client/HttpClient;","_connector","Lorg/mortbay/jetty/client/HttpClient$Connector;"));
                code.visitJumpStmt(GOTO,-1,-1,L13);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m005_doStop(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Lorg/mortbay/jetty/client/HttpClient;","doStop",new String[]{ },"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/lang/Exception;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(435,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(436,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(437,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(439,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(441,L4);
                DexLabel L5=new DexLabel();
                ddv.visitStartLocal(1,L5,"i$","Ljava/util/Iterator;",null);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(443,L6);
                ddv.visitStartLocal(0,L6,"destination","Lorg/mortbay/jetty/client/HttpDestination;",null);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(446,L7);
                ddv.visitEndLocal(0,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(447,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(448,L9);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,2,3,new Field("Lorg/mortbay/jetty/client/HttpClient;","_connector","Lorg/mortbay/jetty/client/HttpClient$Connector;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 2},new Method("Lorg/mortbay/jetty/client/HttpClient$Connector;","stop",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT_OBJECT,2,3,new Field("Lorg/mortbay/jetty/client/HttpClient;","_connector","Lorg/mortbay/jetty/client/HttpClient$Connector;"));
                code.visitLabel(L2);
                code.visitFieldStmt(IGET_OBJECT,2,3,new Field("Lorg/mortbay/jetty/client/HttpClient;","_threadPool","Lorg/mortbay/thread/ThreadPool;"));
                code.visitTypeStmt(INSTANCE_OF,2,2,"Lorg/mortbay/component/LifeCycle;");
                code.visitJumpStmt(IF_EQZ,2,-1,L4);
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,2,3,new Field("Lorg/mortbay/jetty/client/HttpClient;","_threadPool","Lorg/mortbay/thread/ThreadPool;"));
                code.visitTypeStmt(CHECK_CAST,2,-1,"Lorg/mortbay/component/LifeCycle;");
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 2},new Method("Lorg/mortbay/component/LifeCycle;","stop",new String[]{ },"V"));
                code.visitLabel(L4);
                code.visitFieldStmt(IGET_OBJECT,2,3,new Field("Lorg/mortbay/jetty/client/HttpClient;","_destinations","Ljava/util/Map;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 2},new Method("Ljava/util/Map;","values",new String[]{ },"Ljava/util/Collection;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 2},new Method("Ljava/util/Collection;","iterator",new String[]{ },"Ljava/util/Iterator;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L5);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 1},new Method("Ljava/util/Iterator;","hasNext",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitJumpStmt(IF_EQZ,2,-1,L7);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 1},new Method("Ljava/util/Iterator;","next",new String[]{ },"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitTypeStmt(CHECK_CAST,0,-1,"Lorg/mortbay/jetty/client/HttpDestination;");
                code.visitLabel(L6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/jetty/client/HttpDestination;","close",new String[]{ },"V"));
                code.visitJumpStmt(GOTO,-1,-1,L5);
                code.visitLabel(L7);
                code.visitFieldStmt(IGET_OBJECT,2,3,new Field("Lorg/mortbay/jetty/client/HttpClient;","_timeoutQ","Lorg/mortbay/thread/Timeout;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/thread/Timeout;","cancelAll",new String[]{ },"V"));
                code.visitLabel(L8);
                code.visitMethodStmt(INVOKE_SUPER,new int[]{ 3},new Method("Lorg/mortbay/jetty/AbstractBuffers;","doStop",new String[]{ },"V"));
                code.visitLabel(L9);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m006_dump(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/client/HttpClient;","dump",new String[]{ },"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(6);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(127,L0);
                DexLabel L1=new DexLabel();
                ddv.visitEndLocal(5,L1);
                ddv.visitStartLocal(1,L1,"i$","Ljava/util/Iterator;",null);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(129,L2);
                ddv.visitStartLocal(0,L2,"entry","Ljava/util/Map$Entry;","Ljava/util/Map$Entry<Lorg/mortbay/jetty/client/Address;Lorg/mortbay/jetty/client/HttpDestination;>;");
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(130,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(132,L4);
                ddv.visitEndLocal(0,L4);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,2,5,new Field("Lorg/mortbay/jetty/client/HttpClient;","_destinations","Ljava/util/Map;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 2},new Method("Ljava/util/Map;","entrySet",new String[]{ },"Ljava/util/Set;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 2},new Method("Ljava/util/Set;","iterator",new String[]{ },"Ljava/util/Iterator;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 1},new Method("Ljava/util/Iterator;","hasNext",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitJumpStmt(IF_EQZ,2,-1,L4);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 1},new Method("Ljava/util/Iterator;","next",new String[]{ },"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitTypeStmt(CHECK_CAST,0,-1,"Ljava/util/Map$Entry;");
                code.visitLabel(L2);
                code.visitFieldStmt(SGET_OBJECT,2,-1,new Field("Ljava/lang/System;","err","Ljava/io/PrintStream;"));
                code.visitTypeStmt(NEW_INSTANCE,3,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 3},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,4,"\n");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,4},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0},new Method("Ljava/util/Map$Entry;","getKey",new String[]{ },"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,4},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitConstStmt(CONST_STRING,4,":");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,4},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3},new Method("Ljava/io/PrintStream;","println",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0},new Method("Ljava/util/Map$Entry;","getValue",new String[]{ },"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitTypeStmt(CHECK_CAST,5,-1,"Lorg/mortbay/jetty/client/HttpDestination;");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Lorg/mortbay/jetty/client/HttpDestination;","dump",new String[]{ },"V"));
                code.visitJumpStmt(GOTO,-1,-1,L1);
                code.visitLabel(L4);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m007_getAttribute(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/client/HttpClient;","getAttribute",new String[]{ "Ljava/lang/String;"},"Ljava/lang/Object;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"name");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(171,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/client/HttpClient;","_attributes","Lorg/mortbay/util/AttributesMap;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,2},new Method("Lorg/mortbay/util/AttributesMap;","getAttribute",new String[]{ "Ljava/lang/String;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m008_getAttributeNames(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/client/HttpClient;","getAttributeNames",new String[]{ },"Ljava/util/Enumeration;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(180,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/client/HttpClient;","_attributes","Lorg/mortbay/util/AttributesMap;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/util/AttributesMap;","getAttributeNames",new String[]{ },"Ljava/util/Enumeration;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m009_getConnectorType(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/client/HttpClient;","getConnectorType",new String[]{ },"I"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(330,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET,0,1,new Field("Lorg/mortbay/jetty/client/HttpClient;","_connectorType","I"));
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m010_getDestination(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/client/HttpClient;","getDestination",new String[]{ "Lorg/mortbay/jetty/client/Address;","Z"},"Lorg/mortbay/jetty/client/HttpDestination;"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/net/UnknownHostException;"));
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(7);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"remote");
                ddv.visitParameterName(1,"ssl");
                DexLabel L3=new DexLabel();
                ddv.visitPrologue(L3);
                ddv.visitLineNumber(218,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(219,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(221,L5);
                ddv.visitLineNumber(223,L0);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(224,L6);
                ddv.visitStartLocal(0,L6,"destination","Lorg/mortbay/jetty/client/HttpDestination;",null);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(226,L7);
                DexLabel L8=new DexLabel();
                ddv.visitEndLocal(0,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(227,L9);
                ddv.visitRestartLocal(0,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(229,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(230,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(231,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(233,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(235,L14);
                ddv.visitLineNumber(236,L2);
                ddv.visitEndLocal(0,L2);
                code.visitLabel(L3);
                code.visitJumpStmt(IF_NEZ,5,-1,L5);
                code.visitLabel(L4);
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Ljava/net/UnknownHostException;");
                code.visitConstStmt(CONST_STRING,2,"Remote socket address cannot be null.");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1,2},new Method("Ljava/net/UnknownHostException;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitStmt1R(THROW,1);
                code.visitLabel(L5);
                code.visitFieldStmt(IGET_OBJECT,1,4,new Field("Lorg/mortbay/jetty/client/HttpClient;","_destinations","Ljava/util/Map;"));
                code.visitStmt1R(MONITOR_ENTER,1);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,2,4,new Field("Lorg/mortbay/jetty/client/HttpClient;","_destinations","Ljava/util/Map;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 2,5},new Method("Ljava/util/Map;","get",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitTypeStmt(CHECK_CAST,0,-1,"Lorg/mortbay/jetty/client/HttpDestination;");
                code.visitLabel(L6);
                code.visitJumpStmt(IF_NEZ,0,-1,L14);
                code.visitLabel(L7);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Lorg/mortbay/jetty/client/HttpDestination;");
                code.visitLabel(L8);
                code.visitFieldStmt(IGET,2,4,new Field("Lorg/mortbay/jetty/client/HttpClient;","_maxConnectionsPerAddress","I"));
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,4,5,6,2},new Method("Lorg/mortbay/jetty/client/HttpDestination;","<init>",new String[]{ "Lorg/mortbay/jetty/client/HttpClient;","Lorg/mortbay/jetty/client/Address;","Z","I"},"V"));
                code.visitLabel(L9);
                code.visitFieldStmt(IGET_OBJECT,2,4,new Field("Lorg/mortbay/jetty/client/HttpClient;","_proxy","Lorg/mortbay/jetty/client/Address;"));
                code.visitJumpStmt(IF_EQZ,2,-1,L13);
                code.visitFieldStmt(IGET_OBJECT,2,4,new Field("Lorg/mortbay/jetty/client/HttpClient;","_noProxy","Ljava/util/Set;"));
                code.visitJumpStmt(IF_EQZ,2,-1,L10);
                code.visitFieldStmt(IGET_OBJECT,2,4,new Field("Lorg/mortbay/jetty/client/HttpClient;","_noProxy","Ljava/util/Set;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Lorg/mortbay/jetty/client/Address;","getHost",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 2,3},new Method("Ljava/util/Set;","contains",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitJumpStmt(IF_NEZ,2,-1,L13);
                code.visitLabel(L10);
                code.visitFieldStmt(IGET_OBJECT,2,4,new Field("Lorg/mortbay/jetty/client/HttpClient;","_proxy","Lorg/mortbay/jetty/client/Address;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,2},new Method("Lorg/mortbay/jetty/client/HttpDestination;","setProxy",new String[]{ "Lorg/mortbay/jetty/client/Address;"},"V"));
                code.visitLabel(L11);
                code.visitFieldStmt(IGET_OBJECT,2,4,new Field("Lorg/mortbay/jetty/client/HttpClient;","_proxyAuthentication","Lorg/mortbay/jetty/client/security/Authorization;"));
                code.visitJumpStmt(IF_EQZ,2,-1,L13);
                code.visitLabel(L12);
                code.visitFieldStmt(IGET_OBJECT,2,4,new Field("Lorg/mortbay/jetty/client/HttpClient;","_proxyAuthentication","Lorg/mortbay/jetty/client/security/Authorization;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,2},new Method("Lorg/mortbay/jetty/client/HttpDestination;","setProxyAuthentication",new String[]{ "Lorg/mortbay/jetty/client/security/Authorization;"},"V"));
                code.visitLabel(L13);
                code.visitFieldStmt(IGET_OBJECT,2,4,new Field("Lorg/mortbay/jetty/client/HttpClient;","_destinations","Ljava/util/Map;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 2,5,0},new Method("Ljava/util/Map;","put",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitLabel(L14);
                code.visitStmt1R(MONITOR_EXIT,1);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,2);
                code.visitStmt1R(MONITOR_EXIT,1);
                code.visitLabel(L1);
                code.visitStmt1R(THROW,2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m011_getIdleTimeout(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/client/HttpClient;","getIdleTimeout",new String[]{ },"J"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(576,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_WIDE,0,2,new Field("Lorg/mortbay/jetty/client/HttpClient;","_idleTimeout","J"));
                code.visitStmt1R(RETURN_WIDE,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m012_getKeyStoreLocation(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/client/HttpClient;","getKeyStoreLocation",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(687,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/client/HttpClient;","_keyStoreLocation","Ljava/lang/String;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m013_getLooseSSLContext(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Lorg/mortbay/jetty/client/HttpClient;","getLooseSSLContext",new String[]{ },"Ljavax/net/ssl/SSLContext;"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(7);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ "Ljava/lang/Exception;"});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L3=new DexLabel();
                ddv.visitPrologue(L3);
                ddv.visitLineNumber(530,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(546,L4);
                ddv.visitStartLocal(3,L4,"trustAllCerts","[Ljavax/net/ssl/TrustManager;",null);
                ddv.visitLineNumber(559,L0);
                ddv.visitStartLocal(1,L0,"hostnameVerifier","Ljavax/net/ssl/HostnameVerifier;",null);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(560,L5);
                ddv.visitStartLocal(2,L5,"sslContext","Ljavax/net/ssl/SSLContext;",null);
                ddv.visitLineNumber(561,L1);
                ddv.visitLineNumber(563,L2);
                ddv.visitEndLocal(2,L2);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(565,L6);
                ddv.visitStartLocal(0,L6,"e","Ljava/lang/Exception;",null);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(566,L7);
                code.visitLabel(L3);
                code.visitConstStmt(CONST_4,4, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitTypeStmt(NEW_ARRAY,3,4,"[Ljavax/net/ssl/TrustManager;");
                code.visitConstStmt(CONST_4,4, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitTypeStmt(NEW_INSTANCE,5,-1,"Lorg/mortbay/jetty/client/HttpClient$2;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 5,6},new Method("Lorg/mortbay/jetty/client/HttpClient$2;","<init>",new String[]{ "Lorg/mortbay/jetty/client/HttpClient;"},"V"));
                code.visitStmt3R(APUT_OBJECT,5,3,4);
                code.visitLabel(L4);
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Lorg/mortbay/jetty/client/HttpClient$3;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1,6},new Method("Lorg/mortbay/jetty/client/HttpClient$3;","<init>",new String[]{ "Lorg/mortbay/jetty/client/HttpClient;"},"V"));
                code.visitLabel(L0);
                code.visitConstStmt(CONST_STRING,4,"SSL");
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 4},new Method("Ljavax/net/ssl/SSLContext;","getInstance",new String[]{ "Ljava/lang/String;"},"Ljavax/net/ssl/SSLContext;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitLabel(L5);
                code.visitConstStmt(CONST_4,4, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitTypeStmt(NEW_INSTANCE,5,-1,"Ljava/security/SecureRandom;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 5},new Method("Ljava/security/SecureRandom;","<init>",new String[]{ },"V"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,4,3,5},new Method("Ljavax/net/ssl/SSLContext;","init",new String[]{ "[Ljavax/net/ssl/KeyManager;","[Ljavax/net/ssl/TrustManager;","Ljava/security/SecureRandom;"},"V"));
                code.visitLabel(L1);
                code.visitStmt1R(RETURN_OBJECT,2);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,4);
                code.visitStmt2R(MOVE_OBJECT,0,4);
                code.visitLabel(L6);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0},new Method("Lorg/mortbay/log/Log;","debug",new String[]{ "Ljava/lang/Throwable;"},"V"));
                code.visitLabel(L7);
                code.visitTypeStmt(NEW_INSTANCE,4,-1,"Ljava/io/IOException;");
                code.visitConstStmt(CONST_STRING,5,"issue ignoring certs");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 4,5},new Method("Ljava/io/IOException;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitStmt1R(THROW,4);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m014_getMaxConnectionsPerAddress(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/client/HttpClient;","getMaxConnectionsPerAddress",new String[]{ },"I"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(367,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET,0,1,new Field("Lorg/mortbay/jetty/client/HttpClient;","_maxConnectionsPerAddress","I"));
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m015_getNoProxy(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/client/HttpClient;","getNoProxy",new String[]{ },"Ljava/util/Set;"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Signature;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, "()");
                            av01.visit(null, "Ljava/util/Set");
                            av01.visit(null, "<");
                            av01.visit(null, "Ljava/lang/String;");
                            av01.visit(null, ">;");
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(651,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/client/HttpClient;","_noProxy","Ljava/util/Set;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m016_getProxy(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/client/HttpClient;","getProxy",new String[]{ },"Lorg/mortbay/jetty/client/Address;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(621,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/client/HttpClient;","_proxy","Lorg/mortbay/jetty/client/Address;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m017_getProxyAuthentication(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/client/HttpClient;","getProxyAuthentication",new String[]{ },"Lorg/mortbay/jetty/client/security/Authorization;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(633,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/client/HttpClient;","_proxyAuthentication","Lorg/mortbay/jetty/client/security/Authorization;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m018_getRealmResolver(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/client/HttpClient;","getRealmResolver",new String[]{ },"Lorg/mortbay/jetty/client/security/RealmResolver;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(274,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/client/HttpClient;","_realmResolver","Lorg/mortbay/jetty/client/security/RealmResolver;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m019_getRegisteredListeners(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/client/HttpClient;","getRegisteredListeners",new String[]{ },"Ljava/util/LinkedList;"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Signature;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, "()");
                            av01.visit(null, "Ljava/util/LinkedList");
                            av01.visit(null, "<");
                            av01.visit(null, "Ljava/lang/String;");
                            av01.visit(null, ">;");
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(306,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/client/HttpClient;","_registeredListeners","Ljava/util/LinkedList;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m020_getSSLContext(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Lorg/mortbay/jetty/client/HttpClient;","getSSLContext",new String[]{ },"Ljavax/net/ssl/SSLContext;"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(466,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(468,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(470,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(477,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(474,L4);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/client/HttpClient;","_sslContext","Ljavax/net/ssl/SSLContext;"));
                code.visitJumpStmt(IF_NEZ,0,-1,L3);
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/client/HttpClient;","_keyStoreLocation","Ljava/lang/String;"));
                code.visitJumpStmt(IF_NEZ,0,-1,L4);
                code.visitLabel(L2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Lorg/mortbay/jetty/client/HttpClient;","getLooseSSLContext",new String[]{ },"Ljavax/net/ssl/SSLContext;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/jetty/client/HttpClient;","_sslContext","Ljavax/net/ssl/SSLContext;"));
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/client/HttpClient;","_sslContext","Ljavax/net/ssl/SSLContext;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitLabel(L4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Lorg/mortbay/jetty/client/HttpClient;","getStrictSSLContext",new String[]{ },"Ljavax/net/ssl/SSLContext;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/jetty/client/HttpClient;","_sslContext","Ljavax/net/ssl/SSLContext;"));
                code.visitJumpStmt(GOTO,-1,-1,L3);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m021_getSoTimeout(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/client/HttpClient;","getSoTimeout",new String[]{ },"I"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(591,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET,0,1,new Field("Lorg/mortbay/jetty/client/HttpClient;","_soTimeout","I"));
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m022_getStrictSSLContext(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Lorg/mortbay/jetty/client/HttpClient;","getStrictSSLContext",new String[]{ },"Ljavax/net/ssl/SSLContext;"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(15);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ "Ljava/lang/Exception;"});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L3=new DexLabel();
                ddv.visitPrologue(L3);
                ddv.visitLineNumber(485,L0);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(487,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(488,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(491,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(492,L7);
                ddv.visitStartLocal(3,L7,"keyManagers","[Ljavax/net/ssl/KeyManager;",null);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(494,L8);
                ddv.visitStartLocal(5,L8,"keystoreInputStream","Ljava/io/InputStream;",null);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(495,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(496,L10);
                ddv.visitStartLocal(4,L10,"keyStore","Ljava/security/KeyStore;",null);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(498,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(499,L12);
                ddv.visitStartLocal(2,L12,"keyManagerFactory","Ljavax/net/ssl/KeyManagerFactory;",null);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(500,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(502,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(503,L15);
                ddv.visitStartLocal(8,L15,"trustManagers","[Ljavax/net/ssl/TrustManager;",null);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(505,L16);
                ddv.visitStartLocal(10,L16,"truststoreInputStream","Ljava/io/InputStream;",null);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(506,L17);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(507,L18);
                ddv.visitStartLocal(9,L18,"trustStore","Ljava/security/KeyStore;",null);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(509,L19);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(510,L20);
                ddv.visitStartLocal(7,L20,"trustManagerFactory","Ljavax/net/ssl/TrustManagerFactory;",null);
                DexLabel L21=new DexLabel();
                ddv.visitLineNumber(511,L21);
                DexLabel L22=new DexLabel();
                ddv.visitLineNumber(513,L22);
                DexLabel L23=new DexLabel();
                ddv.visitLineNumber(514,L23);
                ddv.visitStartLocal(6,L23,"secureRandom","Ljava/security/SecureRandom;",null);
                DexLabel L24=new DexLabel();
                ddv.visitLineNumber(515,L24);
                ddv.visitStartLocal(0,L24,"context","Ljavax/net/ssl/SSLContext;",null);
                DexLabel L25=new DexLabel();
                ddv.visitLineNumber(516,L25);
                DexLabel L26=new DexLabel();
                ddv.visitLineNumber(496,L26);
                ddv.visitEndLocal(2,L26);
                ddv.visitEndLocal(10,L26);
                ddv.visitEndLocal(9,L26);
                ddv.visitEndLocal(7,L26);
                ddv.visitEndLocal(8,L26);
                ddv.visitEndLocal(6,L26);
                ddv.visitEndLocal(0,L26);
                DexLabel L27=new DexLabel();
                ddv.visitLineNumber(499,L27);
                ddv.visitRestartLocal(2,L27);
                DexLabel L28=new DexLabel();
                ddv.visitLineNumber(507,L28);
                ddv.visitRestartLocal(8,L28);
                ddv.visitRestartLocal(9,L28);
                ddv.visitRestartLocal(10,L28);
                DexLabel L29=new DexLabel();
                ddv.visitLineNumber(513,L29);
                ddv.visitRestartLocal(7,L29);
                DexLabel L30=new DexLabel();
                ddv.visitLineNumber(514,L30);
                ddv.visitRestartLocal(6,L30);
                ddv.visitLineNumber(518,L2);
                ddv.visitEndLocal(5,L2);
                ddv.visitEndLocal(4,L2);
                ddv.visitEndLocal(3,L2);
                ddv.visitEndLocal(2,L2);
                ddv.visitEndLocal(8,L2);
                ddv.visitEndLocal(9,L2);
                ddv.visitEndLocal(10,L2);
                ddv.visitEndLocal(7,L2);
                ddv.visitEndLocal(6,L2);
                DexLabel L31=new DexLabel();
                ddv.visitLineNumber(520,L31);
                ddv.visitStartLocal(1,L31,"e","Ljava/lang/Exception;",null);
                DexLabel L32=new DexLabel();
                ddv.visitLineNumber(521,L32);
                code.visitLabel(L3);
                code.visitConstStmt(CONST_4,12, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,11,14,new Field("Lorg/mortbay/jetty/client/HttpClient;","_trustStoreLocation","Ljava/lang/String;"));
                code.visitJumpStmt(IF_NEZ,11,-1,L6);
                code.visitLabel(L4);
                code.visitFieldStmt(IGET_OBJECT,11,14,new Field("Lorg/mortbay/jetty/client/HttpClient;","_keyStoreLocation","Ljava/lang/String;"));
                code.visitFieldStmt(IPUT_OBJECT,11,14,new Field("Lorg/mortbay/jetty/client/HttpClient;","_trustStoreLocation","Ljava/lang/String;"));
                code.visitLabel(L5);
                code.visitFieldStmt(IGET_OBJECT,11,14,new Field("Lorg/mortbay/jetty/client/HttpClient;","_keyStoreType","Ljava/lang/String;"));
                code.visitFieldStmt(IPUT_OBJECT,11,14,new Field("Lorg/mortbay/jetty/client/HttpClient;","_trustStoreType","Ljava/lang/String;"));
                code.visitLabel(L6);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L7);
                code.visitConstStmt(CONST_4,5, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L8);
                code.visitFieldStmt(IGET_OBJECT,11,14,new Field("Lorg/mortbay/jetty/client/HttpClient;","_keyStoreLocation","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 11},new Method("Lorg/mortbay/resource/Resource;","newResource",new String[]{ "Ljava/lang/String;"},"Lorg/mortbay/resource/Resource;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,11);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 11},new Method("Lorg/mortbay/resource/Resource;","getInputStream",new String[]{ },"Ljava/io/InputStream;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitLabel(L9);
                code.visitFieldStmt(IGET_OBJECT,11,14,new Field("Lorg/mortbay/jetty/client/HttpClient;","_keyStoreType","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 11},new Method("Ljava/security/KeyStore;","getInstance",new String[]{ "Ljava/lang/String;"},"Ljava/security/KeyStore;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitLabel(L10);
                code.visitFieldStmt(IGET_OBJECT,11,14,new Field("Lorg/mortbay/jetty/client/HttpClient;","_keyStorePassword","Ljava/lang/String;"));
                code.visitJumpStmt(IF_NEZ,11,-1,L26);
                code.visitStmt2R(MOVE_OBJECT,11,12);
                DexLabel L33=new DexLabel();
                code.visitLabel(L33);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,5,11},new Method("Ljava/security/KeyStore;","load",new String[]{ "Ljava/io/InputStream;","[C"},"V"));
                code.visitLabel(L11);
                code.visitFieldStmt(IGET_OBJECT,11,14,new Field("Lorg/mortbay/jetty/client/HttpClient;","_keyManagerAlgorithm","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 11},new Method("Ljavax/net/ssl/KeyManagerFactory;","getInstance",new String[]{ "Ljava/lang/String;"},"Ljavax/net/ssl/KeyManagerFactory;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitLabel(L12);
                code.visitFieldStmt(IGET_OBJECT,11,14,new Field("Lorg/mortbay/jetty/client/HttpClient;","_keyManagerPassword","Ljava/lang/String;"));
                code.visitJumpStmt(IF_NEZ,11,-1,L27);
                code.visitStmt2R(MOVE_OBJECT,11,12);
                DexLabel L34=new DexLabel();
                code.visitLabel(L34);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,4,11},new Method("Ljavax/net/ssl/KeyManagerFactory;","init",new String[]{ "Ljava/security/KeyStore;","[C"},"V"));
                code.visitLabel(L13);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Ljavax/net/ssl/KeyManagerFactory;","getKeyManagers",new String[]{ },"[Ljavax/net/ssl/KeyManager;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitLabel(L14);
                code.visitConstStmt(CONST_4,8, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L15);
                code.visitConstStmt(CONST_4,10, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L16);
                code.visitFieldStmt(IGET_OBJECT,11,14,new Field("Lorg/mortbay/jetty/client/HttpClient;","_trustStoreLocation","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 11},new Method("Lorg/mortbay/resource/Resource;","newResource",new String[]{ "Ljava/lang/String;"},"Lorg/mortbay/resource/Resource;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,11);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 11},new Method("Lorg/mortbay/resource/Resource;","getInputStream",new String[]{ },"Ljava/io/InputStream;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,10);
                code.visitLabel(L17);
                code.visitFieldStmt(IGET_OBJECT,11,14,new Field("Lorg/mortbay/jetty/client/HttpClient;","_trustStoreType","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 11},new Method("Ljava/security/KeyStore;","getInstance",new String[]{ "Ljava/lang/String;"},"Ljava/security/KeyStore;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,9);
                code.visitLabel(L18);
                code.visitFieldStmt(IGET_OBJECT,11,14,new Field("Lorg/mortbay/jetty/client/HttpClient;","_trustStorePassword","Ljava/lang/String;"));
                code.visitJumpStmt(IF_NEZ,11,-1,L28);
                code.visitStmt2R(MOVE_OBJECT,11,12);
                DexLabel L35=new DexLabel();
                code.visitLabel(L35);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9,10,11},new Method("Ljava/security/KeyStore;","load",new String[]{ "Ljava/io/InputStream;","[C"},"V"));
                code.visitLabel(L19);
                code.visitFieldStmt(IGET_OBJECT,11,14,new Field("Lorg/mortbay/jetty/client/HttpClient;","_trustManagerAlgorithm","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 11},new Method("Ljavax/net/ssl/TrustManagerFactory;","getInstance",new String[]{ "Ljava/lang/String;"},"Ljavax/net/ssl/TrustManagerFactory;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitLabel(L20);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7,9},new Method("Ljavax/net/ssl/TrustManagerFactory;","init",new String[]{ "Ljava/security/KeyStore;"},"V"));
                code.visitLabel(L21);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7},new Method("Ljavax/net/ssl/TrustManagerFactory;","getTrustManagers",new String[]{ },"[Ljavax/net/ssl/TrustManager;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitLabel(L22);
                code.visitFieldStmt(IGET_OBJECT,11,14,new Field("Lorg/mortbay/jetty/client/HttpClient;","_secureRandomAlgorithm","Ljava/lang/String;"));
                code.visitJumpStmt(IF_NEZ,11,-1,L29);
                code.visitStmt2R(MOVE_OBJECT,6,12);
                code.visitLabel(L23);
                code.visitFieldStmt(IGET_OBJECT,11,14,new Field("Lorg/mortbay/jetty/client/HttpClient;","_provider","Ljava/lang/String;"));
                code.visitJumpStmt(IF_NEZ,11,-1,L30);
                code.visitFieldStmt(IGET_OBJECT,11,14,new Field("Lorg/mortbay/jetty/client/HttpClient;","_protocol","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 11},new Method("Ljavax/net/ssl/SSLContext;","getInstance",new String[]{ "Ljava/lang/String;"},"Ljavax/net/ssl/SSLContext;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,11);
                code.visitStmt2R(MOVE_OBJECT,0,11);
                code.visitLabel(L24);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,3,8,6},new Method("Ljavax/net/ssl/SSLContext;","init",new String[]{ "[Ljavax/net/ssl/KeyManager;","[Ljavax/net/ssl/TrustManager;","Ljava/security/SecureRandom;"},"V"));
                code.visitLabel(L25);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitLabel(L26);
                code.visitFieldStmt(IGET_OBJECT,11,14,new Field("Lorg/mortbay/jetty/client/HttpClient;","_keyStorePassword","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 11},new Method("Ljava/lang/String;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,11);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 11},new Method("Ljava/lang/String;","toCharArray",new String[]{ },"[C"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,11);
                code.visitJumpStmt(GOTO,-1,-1,L33);
                code.visitLabel(L27);
                code.visitFieldStmt(IGET_OBJECT,11,14,new Field("Lorg/mortbay/jetty/client/HttpClient;","_keyManagerPassword","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 11},new Method("Ljava/lang/String;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,11);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 11},new Method("Ljava/lang/String;","toCharArray",new String[]{ },"[C"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,11);
                code.visitJumpStmt(GOTO,-1,-1,L34);
                code.visitLabel(L28);
                code.visitFieldStmt(IGET_OBJECT,11,14,new Field("Lorg/mortbay/jetty/client/HttpClient;","_trustStorePassword","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 11},new Method("Ljava/lang/String;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,11);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 11},new Method("Ljava/lang/String;","toCharArray",new String[]{ },"[C"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,11);
                code.visitJumpStmt(GOTO,-1,-1,L35);
                code.visitLabel(L29);
                code.visitFieldStmt(IGET_OBJECT,11,14,new Field("Lorg/mortbay/jetty/client/HttpClient;","_secureRandomAlgorithm","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 11},new Method("Ljava/security/SecureRandom;","getInstance",new String[]{ "Ljava/lang/String;"},"Ljava/security/SecureRandom;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,11);
                code.visitStmt2R(MOVE_OBJECT,6,11);
                code.visitJumpStmt(GOTO,-1,-1,L23);
                code.visitLabel(L30);
                code.visitFieldStmt(IGET_OBJECT,11,14,new Field("Lorg/mortbay/jetty/client/HttpClient;","_protocol","Ljava/lang/String;"));
                code.visitFieldStmt(IGET_OBJECT,12,14,new Field("Lorg/mortbay/jetty/client/HttpClient;","_provider","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 11,12},new Method("Ljavax/net/ssl/SSLContext;","getInstance",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"Ljavax/net/ssl/SSLContext;"));
                code.visitLabel(L1);
                code.visitStmt1R(MOVE_RESULT_OBJECT,11);
                code.visitStmt2R(MOVE_OBJECT,0,11);
                code.visitJumpStmt(GOTO,-1,-1,L24);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,11);
                code.visitStmt2R(MOVE_OBJECT,1,11);
                code.visitLabel(L31);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1},new Method("Lorg/mortbay/log/Log;","debug",new String[]{ "Ljava/lang/Throwable;"},"V"));
                code.visitLabel(L32);
                code.visitTypeStmt(NEW_INSTANCE,11,-1,"Ljava/io/IOException;");
                code.visitTypeStmt(NEW_INSTANCE,12,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 12},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,13,"error generating ssl context for ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 12,13},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,12);
                code.visitFieldStmt(IGET_OBJECT,13,14,new Field("Lorg/mortbay/jetty/client/HttpClient;","_keyStoreLocation","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 12,13},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,12);
                code.visitConstStmt(CONST_STRING,13," ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 12,13},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,12);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/lang/Exception;","getMessage",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,13);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 12,13},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,12);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 12},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,12);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 11,12},new Method("Ljava/io/IOException;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitStmt1R(THROW,11);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m023_getThreadPool(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/client/HttpClient;","getThreadPool",new String[]{ },"Lorg/mortbay/thread/ThreadPool;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(151,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/client/HttpClient;","_threadPool","Lorg/mortbay/thread/ThreadPool;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m024_getTimeout(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/client/HttpClient;","getTimeout",new String[]{ },"J"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(606,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_WIDE,0,2,new Field("Lorg/mortbay/jetty/client/HttpClient;","_timeout","J"));
                code.visitStmt1R(RETURN_WIDE,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m025_getTrustStoreLocation(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/client/HttpClient;","getTrustStoreLocation",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(675,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/client/HttpClient;","_trustStoreLocation","Ljava/lang/String;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m026_getUseDirectBuffers(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/client/HttpClient;","getUseDirectBuffers",new String[]{ },"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(257,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_BOOLEAN,0,1,new Field("Lorg/mortbay/jetty/client/HttpClient;","_useDirectBuffers","Z"));
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m027_hasRealms(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/client/HttpClient;","hasRealms",new String[]{ },"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(280,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/client/HttpClient;","_realmResolver","Lorg/mortbay/jetty/client/security/RealmResolver;"));
                DexLabel L1=new DexLabel();
                code.visitJumpStmt(IF_NEZ,0,-1,L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                DexLabel L2=new DexLabel();
                code.visitLabel(L2);
                code.visitStmt1R(RETURN,0);
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m028_isProxied(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/client/HttpClient;","isProxied",new String[]{ },"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(645,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/client/HttpClient;","_proxy","Lorg/mortbay/jetty/client/Address;"));
                DexLabel L1=new DexLabel();
                code.visitJumpStmt(IF_EQZ,0,-1,L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                DexLabel L2=new DexLabel();
                code.visitLabel(L2);
                code.visitStmt1R(RETURN,0);
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m029_maxRetries(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/client/HttpClient;","maxRetries",new String[]{ },"I"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(663,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET,0,1,new Field("Lorg/mortbay/jetty/client/HttpClient;","_maxRetries","I"));
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m030_newBuffer(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Lorg/mortbay/jetty/client/HttpClient;","newBuffer",new String[]{ "I"},"Lorg/mortbay/io/Buffer;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"size");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(347,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(349,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(350,L2);
                ddv.visitStartLocal(0,L2,"buf","Lorg/mortbay/io/Buffer;",null);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(351,L3);
                DexLabel L4=new DexLabel();
                ddv.visitEndLocal(0,L4);
                DexLabel L5=new DexLabel();
                ddv.visitRestartLocal(0,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(360,L6);
                ddv.visitEndLocal(0,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(352,L7);
                ddv.visitRestartLocal(0,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(353,L8);
                DexLabel L9=new DexLabel();
                ddv.visitEndLocal(0,L9);
                DexLabel L10=new DexLabel();
                ddv.visitRestartLocal(0,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(355,L11);
                DexLabel L12=new DexLabel();
                ddv.visitEndLocal(0,L12);
                DexLabel L13=new DexLabel();
                ddv.visitRestartLocal(0,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(360,L14);
                ddv.visitEndLocal(0,L14);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET,1,2,new Field("Lorg/mortbay/jetty/client/HttpClient;","_connectorType","I"));
                code.visitJumpStmt(IF_EQZ,1,-1,L14);
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/jetty/client/HttpClient;","getHeaderBufferSize",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitJumpStmt(IF_NE,3,1,L7);
                code.visitLabel(L3);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Lorg/mortbay/io/nio/IndirectNIOBuffer;");
                code.visitLabel(L4);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,3},new Method("Lorg/mortbay/io/nio/IndirectNIOBuffer;","<init>",new String[]{ "I"},"V"));
                code.visitLabel(L5);
                code.visitStmt2R(MOVE_OBJECT,1,0);
                code.visitLabel(L6);
                code.visitStmt1R(RETURN_OBJECT,1);
                code.visitLabel(L7);
                code.visitFieldStmt(IGET_BOOLEAN,1,2,new Field("Lorg/mortbay/jetty/client/HttpClient;","_useDirectBuffers","Z"));
                code.visitJumpStmt(IF_EQZ,1,-1,L11);
                code.visitLabel(L8);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Lorg/mortbay/io/nio/DirectNIOBuffer;");
                code.visitLabel(L9);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,3},new Method("Lorg/mortbay/io/nio/DirectNIOBuffer;","<init>",new String[]{ "I"},"V"));
                code.visitLabel(L10);
                code.visitJumpStmt(GOTO,-1,-1,L5);
                code.visitLabel(L11);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Lorg/mortbay/io/nio/IndirectNIOBuffer;");
                code.visitLabel(L12);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,3},new Method("Lorg/mortbay/io/nio/IndirectNIOBuffer;","<init>",new String[]{ "I"},"V"));
                code.visitLabel(L13);
                code.visitJumpStmt(GOTO,-1,-1,L5);
                code.visitLabel(L14);
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Lorg/mortbay/io/ByteArrayBuffer;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1,3},new Method("Lorg/mortbay/io/ByteArrayBuffer;","<init>",new String[]{ "I"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L6);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m031_registerListener(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/client/HttpClient;","registerListener",new String[]{ "Ljava/lang/String;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"listenerClass");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(297,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(299,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(301,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(302,L3);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/client/HttpClient;","_registeredListeners","Ljava/util/LinkedList;"));
                code.visitJumpStmt(IF_NEZ,0,-1,L2);
                code.visitLabel(L1);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/util/LinkedList;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/util/LinkedList;","<init>",new String[]{ },"V"));
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/jetty/client/HttpClient;","_registeredListeners","Ljava/util/LinkedList;"));
                code.visitLabel(L2);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/client/HttpClient;","_registeredListeners","Ljava/util/LinkedList;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,2},new Method("Ljava/util/LinkedList;","add",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitLabel(L3);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m032_removeAttribute(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/client/HttpClient;","removeAttribute",new String[]{ "Ljava/lang/String;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"name");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(189,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(190,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/client/HttpClient;","_attributes","Lorg/mortbay/util/AttributesMap;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,2},new Method("Lorg/mortbay/util/AttributesMap;","removeAttribute",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m033_schedule(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/client/HttpClient;","schedule",new String[]{ "Lorg/mortbay/thread/Timeout$Task;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"task");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(242,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(243,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/client/HttpClient;","_timeoutQ","Lorg/mortbay/thread/Timeout;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,2},new Method("Lorg/mortbay/thread/Timeout;","schedule",new String[]{ "Lorg/mortbay/thread/Timeout$Task;"},"V"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m034_send(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/client/HttpClient;","send",new String[]{ "Lorg/mortbay/jetty/client/HttpExchange;"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(6);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"exchange");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(137,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(138,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(139,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(140,L3);
                ddv.visitStartLocal(1,L3,"ssl","Z",null);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(141,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(142,L5);
                ddv.visitStartLocal(0,L5,"destination","Lorg/mortbay/jetty/client/HttpDestination;",null);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(143,L6);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Lorg/mortbay/jetty/client/HttpClient;","isStarted",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitJumpStmt(IF_NEZ,2,-1,L2);
                code.visitLabel(L1);
                code.visitTypeStmt(NEW_INSTANCE,2,-1,"Ljava/lang/IllegalStateException;");
                code.visitConstStmt(CONST_STRING,3,"!started");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2,3},new Method("Ljava/lang/IllegalStateException;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitStmt1R(THROW,2);
                code.visitLabel(L2);
                code.visitFieldStmt(SGET_OBJECT,2,-1,new Field("Lorg/mortbay/jetty/HttpSchemes;","HTTPS_BUFFER","Lorg/mortbay/io/Buffer;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Lorg/mortbay/jetty/client/HttpExchange;","getScheme",new String[]{ },"Lorg/mortbay/io/Buffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 2,3},new Method("Lorg/mortbay/io/Buffer;","equalsIgnoreCase",new String[]{ "Lorg/mortbay/io/Buffer;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitLabel(L3);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,2},new Method("Lorg/mortbay/jetty/client/HttpExchange;","setStatus",new String[]{ "I"},"V"));
                code.visitLabel(L4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Lorg/mortbay/jetty/client/HttpExchange;","getAddress",new String[]{ },"Lorg/mortbay/jetty/client/Address;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,2,1},new Method("Lorg/mortbay/jetty/client/HttpClient;","getDestination",new String[]{ "Lorg/mortbay/jetty/client/Address;","Z"},"Lorg/mortbay/jetty/client/HttpDestination;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,5},new Method("Lorg/mortbay/jetty/client/HttpDestination;","send",new String[]{ "Lorg/mortbay/jetty/client/HttpExchange;"},"V"));
                code.visitLabel(L6);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m035_setAttribute(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/client/HttpClient;","setAttribute",new String[]{ "Ljava/lang/String;","Ljava/lang/Object;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"name");
                ddv.visitParameterName(1,"attribute");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(202,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(203,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/client/HttpClient;","_attributes","Lorg/mortbay/util/AttributesMap;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,2,3},new Method("Lorg/mortbay/util/AttributesMap;","setAttribute",new String[]{ "Ljava/lang/String;","Ljava/lang/Object;"},"V"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m036_setConnectorType(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/client/HttpClient;","setConnectorType",new String[]{ "I"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"connectorType");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(336,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(337,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT,1,0,new Field("Lorg/mortbay/jetty/client/HttpClient;","_connectorType","I"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m037_setIdleTimeout(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/client/HttpClient;","setIdleTimeout",new String[]{ "J"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"ms");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(585,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(586,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_WIDE,1,0,new Field("Lorg/mortbay/jetty/client/HttpClient;","_idleTimeout","J"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m038_setKeyManagerPassword(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/client/HttpClient;","setKeyManagerPassword",new String[]{ "Ljava/lang/String;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"_keyManagerPassword");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(705,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(706,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_OBJECT,1,0,new Field("Lorg/mortbay/jetty/client/HttpClient;","_keyManagerPassword","Ljava/lang/String;"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m039_setKeyStoreLocation(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/client/HttpClient;","setKeyStoreLocation",new String[]{ "Ljava/lang/String;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"keyStoreLocation");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(693,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(694,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_OBJECT,1,0,new Field("Lorg/mortbay/jetty/client/HttpClient;","_keyStoreLocation","Ljava/lang/String;"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m040_setKeyStorePassword(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/client/HttpClient;","setKeyStorePassword",new String[]{ "Ljava/lang/String;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"_keyStorePassword");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(699,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(700,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_OBJECT,1,0,new Field("Lorg/mortbay/jetty/client/HttpClient;","_keyStorePassword","Ljava/lang/String;"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m041_setMaxConnectionsPerAddress(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/client/HttpClient;","setMaxConnectionsPerAddress",new String[]{ "I"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"maxConnectionsPerAddress");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(373,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(374,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT,1,0,new Field("Lorg/mortbay/jetty/client/HttpClient;","_maxConnectionsPerAddress","I"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m042_setMaxRetries(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/client/HttpClient;","setMaxRetries",new String[]{ "I"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"retries");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(669,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(670,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT,1,0,new Field("Lorg/mortbay/jetty/client/HttpClient;","_maxRetries","I"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m043_setNoProxy(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/client/HttpClient;","setNoProxy",new String[]{ "Ljava/util/Set;"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Signature;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, "(");
                            av01.visit(null, "Ljava/util/Set");
                            av01.visit(null, "<");
                            av01.visit(null, "Ljava/lang/String;");
                            av01.visit(null, ">;)V");
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitStartLocal(1,L0,"noProxyAddresses","Ljava/util/Set;","Ljava/util/Set<Ljava/lang/String;>;");
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(657,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(658,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_OBJECT,1,0,new Field("Lorg/mortbay/jetty/client/HttpClient;","_noProxy","Ljava/util/Set;"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m044_setProxy(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/client/HttpClient;","setProxy",new String[]{ "Lorg/mortbay/jetty/client/Address;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"proxy");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(627,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(628,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_OBJECT,1,0,new Field("Lorg/mortbay/jetty/client/HttpClient;","_proxy","Lorg/mortbay/jetty/client/Address;"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m045_setProxyAuthentication(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/client/HttpClient;","setProxyAuthentication",new String[]{ "Lorg/mortbay/jetty/client/security/Authorization;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"authentication");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(639,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(640,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_OBJECT,1,0,new Field("Lorg/mortbay/jetty/client/HttpClient;","_proxyAuthentication","Lorg/mortbay/jetty/client/security/Authorization;"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m046_setRealmResolver(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/client/HttpClient;","setRealmResolver",new String[]{ "Lorg/mortbay/jetty/client/security/RealmResolver;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"resolver");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(263,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(264,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_OBJECT,1,0,new Field("Lorg/mortbay/jetty/client/HttpClient;","_realmResolver","Lorg/mortbay/jetty/client/security/RealmResolver;"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m047_setSoTimeout(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/client/HttpClient;","setSoTimeout",new String[]{ "I"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"so");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(597,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(598,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT,1,0,new Field("Lorg/mortbay/jetty/client/HttpClient;","_soTimeout","I"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m048_setThreadPool(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/client/HttpClient;","setThreadPool",new String[]{ "Lorg/mortbay/thread/ThreadPool;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"threadPool");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(160,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(161,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_OBJECT,1,0,new Field("Lorg/mortbay/jetty/client/HttpClient;","_threadPool","Lorg/mortbay/thread/ThreadPool;"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m049_setTimeout(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/client/HttpClient;","setTimeout",new String[]{ "J"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"ms");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(615,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(616,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_WIDE,1,0,new Field("Lorg/mortbay/jetty/client/HttpClient;","_timeout","J"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m050_setTrustStoreLocation(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/client/HttpClient;","setTrustStoreLocation",new String[]{ "Ljava/lang/String;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"trustStoreLocation");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(681,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(682,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_OBJECT,1,0,new Field("Lorg/mortbay/jetty/client/HttpClient;","_trustStoreLocation","Ljava/lang/String;"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m051_setTrustStorePassword(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/client/HttpClient;","setTrustStorePassword",new String[]{ "Ljava/lang/String;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"_trustStorePassword");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(711,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(712,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_OBJECT,1,0,new Field("Lorg/mortbay/jetty/client/HttpClient;","_trustStorePassword","Ljava/lang/String;"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m052_setUseDirectBuffers(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/client/HttpClient;","setUseDirectBuffers",new String[]{ "Z"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"direct");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(321,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(322,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_BOOLEAN,1,0,new Field("Lorg/mortbay/jetty/client/HttpClient;","_useDirectBuffers","Z"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
