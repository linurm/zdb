package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0175_org_mortbay_jetty_HttpTokens {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(ACC_PUBLIC|ACC_INTERFACE|ACC_ABSTRACT,"Lorg/mortbay/jetty/HttpTokens;","Ljava/lang/Object;",new String[]{ });
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("HttpTokens.java");
        f000_CARRIAGE_RETURN(cv);
        f001_CHUNKED_CONTENT(cv);
        f002_COLON(cv);
        f003_CRLF(cv);
        f004_EOF_CONTENT(cv);
        f005_LINE_FEED(cv);
        f006_NO_CONTENT(cv);
        f007_SELF_DEFINING_CONTENT(cv);
        f008_SEMI_COLON(cv);
        f009_SPACE(cv);
        f010_TAB(cv);
        f011_UNKNOWN_CONTENT(cv);
        m000__clinit_(cv);
    }
    public static void f000_CARRIAGE_RETURN(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpTokens;","CARRIAGE_RETURN","B"), Byte.valueOf((byte)13));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f001_CHUNKED_CONTENT(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpTokens;","CHUNKED_CONTENT","I"),  Integer.valueOf(-2));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f002_COLON(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpTokens;","COLON","B"), Byte.valueOf((byte)58));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f003_CRLF(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpTokens;","CRLF","[B"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f004_EOF_CONTENT(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpTokens;","EOF_CONTENT","I"),  Integer.valueOf(-1));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f005_LINE_FEED(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpTokens;","LINE_FEED","B"), Byte.valueOf((byte)10));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f006_NO_CONTENT(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpTokens;","NO_CONTENT","I"),  Integer.valueOf(0));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f007_SELF_DEFINING_CONTENT(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpTokens;","SELF_DEFINING_CONTENT","I"),  Integer.valueOf(-4));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f008_SEMI_COLON(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpTokens;","SEMI_COLON","B"), Byte.valueOf((byte)59));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f009_SPACE(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpTokens;","SPACE","B"), Byte.valueOf((byte)32));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f010_TAB(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpTokens;","TAB","B"), Byte.valueOf((byte)9));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f011_UNKNOWN_CONTENT(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpTokens;","UNKNOWN_CONTENT","I"),  Integer.valueOf(-3));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void m000__clinit_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_STATIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/jetty/HttpTokens;","<clinit>",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(1);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(28,L0);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(2)); // int: 0x00000002  float:0.000000
                code.visitTypeStmt(NEW_ARRAY,0,0,"[B");
                code.visitFieldStmt(SPUT_OBJECT,0,-1,new Field("Lorg/mortbay/jetty/HttpTokens;","CRLF","[B"));
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
