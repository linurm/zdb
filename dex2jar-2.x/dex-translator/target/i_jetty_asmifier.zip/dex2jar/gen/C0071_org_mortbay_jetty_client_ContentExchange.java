package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0071_org_mortbay_jetty_client_ContentExchange {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(ACC_PUBLIC,"Lorg/mortbay/jetty/client/ContentExchange;","Lorg/mortbay/jetty/client/CachedExchange;",new String[]{ });
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("ContentExchange.java");
        f000__contentLength(cv);
        f001__encoding(cv);
        f002__fileForUpload(cv);
        f003__responseContent(cv);
        f004__responseStatus(cv);
        m000__init_(cv);
        m001__init_(cv);
        m002_getInputStream(cv);
        m003_getFileForUpload(cv);
        m004_getResponseBytes(cv);
        m005_getResponseContent(cv);
        m006_getResponseStatus(cv);
        m007_onResponseContent(cv);
        m008_onResponseHeader(cv);
        m009_onResponseStatus(cv);
        m010_onRetry(cv);
        m011_setFileForUpload(cv);
        m012_writeResponseBytesTo(cv);
    }
    public static void f000__contentLength(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PROTECTED, new Field("Lorg/mortbay/jetty/client/ContentExchange;","_contentLength","I"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f001__encoding(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PROTECTED, new Field("Lorg/mortbay/jetty/client/ContentExchange;","_encoding","Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f002__fileForUpload(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PROTECTED, new Field("Lorg/mortbay/jetty/client/ContentExchange;","_fileForUpload","Ljava/io/File;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f003__responseContent(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PROTECTED, new Field("Lorg/mortbay/jetty/client/ContentExchange;","_responseContent","Lorg/mortbay/util/ByteArrayOutputStream2;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f004__responseStatus(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PROTECTED, new Field("Lorg/mortbay/jetty/client/ContentExchange;","_responseStatus","I"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void m000__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/jetty/client/ContentExchange;","<init>",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(47,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(38,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(39,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(48,L3);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1,0},new Method("Lorg/mortbay/jetty/client/CachedExchange;","<init>",new String[]{ "Z"},"V"));
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(-1)); // int: 0xffffffff  float:NaN
                code.visitFieldStmt(IPUT,0,1,new Field("Lorg/mortbay/jetty/client/ContentExchange;","_contentLength","I"));
                code.visitLabel(L2);
                code.visitConstStmt(CONST_STRING,0,"utf-8");
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/jetty/client/ContentExchange;","_encoding","Ljava/lang/String;"));
                code.visitLabel(L3);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/jetty/client/ContentExchange;","<init>",new String[]{ "Z"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"keepHeaders");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(53,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(38,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(39,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(54,L3);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1,2},new Method("Lorg/mortbay/jetty/client/CachedExchange;","<init>",new String[]{ "Z"},"V"));
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(-1)); // int: 0xffffffff  float:NaN
                code.visitFieldStmt(IPUT,0,1,new Field("Lorg/mortbay/jetty/client/ContentExchange;","_contentLength","I"));
                code.visitLabel(L2);
                code.visitConstStmt(CONST_STRING,0,"utf-8");
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/jetty/client/ContentExchange;","_encoding","Ljava/lang/String;"));
                code.visitLabel(L3);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m002_getInputStream(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PRIVATE, new Method("Lorg/mortbay/jetty/client/ContentExchange;","getInputStream",new String[]{ },"Ljava/io/InputStream;"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(166,L0);
                code.visitLabel(L0);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/io/FileInputStream;");
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/jetty/client/ContentExchange;","_fileForUpload","Ljava/io/File;"));
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1},new Method("Ljava/io/FileInputStream;","<init>",new String[]{ "Ljava/io/File;"},"V"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m003_getFileForUpload(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/client/ContentExchange;","getFileForUpload",new String[]{ },"Ljava/io/File;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(172,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/client/ContentExchange;","_fileForUpload","Ljava/io/File;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m004_getResponseBytes(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/client/ContentExchange;","getResponseBytes",new String[]{ },"[B"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(83,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(85,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(86,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(89,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(87,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(89,L5);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/jetty/client/ContentExchange;","_responseContent","Lorg/mortbay/util/ByteArrayOutputStream2;"));
                code.visitJumpStmt(IF_EQZ,0,-1,L5);
                code.visitLabel(L1);
                code.visitFieldStmt(IGET,0,2,new Field("Lorg/mortbay/jetty/client/ContentExchange;","_contentLength","I"));
                code.visitJumpStmt(IF_LTZ,0,-1,L4);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/jetty/client/ContentExchange;","_responseContent","Lorg/mortbay/util/ByteArrayOutputStream2;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/util/ByteArrayOutputStream2;","getBuf",new String[]{ },"[B"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitStmt2R(ARRAY_LENGTH,0,0);
                code.visitFieldStmt(IGET,1,2,new Field("Lorg/mortbay/jetty/client/ContentExchange;","_contentLength","I"));
                code.visitJumpStmt(IF_NE,0,1,L4);
                code.visitLabel(L2);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/jetty/client/ContentExchange;","_responseContent","Lorg/mortbay/util/ByteArrayOutputStream2;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/util/ByteArrayOutputStream2;","getBuf",new String[]{ },"[B"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L3);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitLabel(L4);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/jetty/client/ContentExchange;","_responseContent","Lorg/mortbay/util/ByteArrayOutputStream2;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/util/ByteArrayOutputStream2;","toByteArray",new String[]{ },"[B"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitJumpStmt(GOTO,-1,-1,L3);
                code.visitLabel(L5);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L3);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m005_getResponseContent(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/client/ContentExchange;","getResponseContent",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/UnsupportedEncodingException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(72,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(73,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(74,L2);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/jetty/client/ContentExchange;","_responseContent","Lorg/mortbay/util/ByteArrayOutputStream2;"));
                DexLabel L3=new DexLabel();
                code.visitJumpStmt(IF_EQZ,0,-1,L3);
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/jetty/client/ContentExchange;","_responseContent","Lorg/mortbay/util/ByteArrayOutputStream2;"));
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/jetty/client/ContentExchange;","_encoding","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Lorg/mortbay/util/ByteArrayOutputStream2;","toString",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L2);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitLabel(L3);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m006_getResponseStatus(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/client/ContentExchange;","getResponseStatus",new String[]{ },"I"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(59,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(60,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(61,L2);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/jetty/client/ContentExchange;","getStatus",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(5)); // int: 0x00000005  float:0.000000
                code.visitJumpStmt(IF_GE,0,1,L2);
                code.visitLabel(L1);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/lang/IllegalStateException;");
                code.visitConstStmt(CONST_STRING,1,"Response not received");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1},new Method("Ljava/lang/IllegalStateException;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitStmt1R(THROW,0);
                code.visitLabel(L2);
                code.visitFieldStmt(IGET,0,2,new Field("Lorg/mortbay/jetty/client/ContentExchange;","_responseStatus","I"));
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m007_onResponseContent(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Lorg/mortbay/jetty/client/ContentExchange;","onResponseContent",new String[]{ "Lorg/mortbay/io/Buffer;"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"content");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(140,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(141,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(142,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(144,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(145,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(142,L5);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_SUPER,new int[]{ 2,3},new Method("Lorg/mortbay/jetty/client/CachedExchange;","onResponseContent",new String[]{ "Lorg/mortbay/io/Buffer;"},"V"));
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/jetty/client/ContentExchange;","_responseContent","Lorg/mortbay/util/ByteArrayOutputStream2;"));
                code.visitJumpStmt(IF_NEZ,0,-1,L3);
                code.visitLabel(L2);
                code.visitFieldStmt(IGET,0,2,new Field("Lorg/mortbay/jetty/client/ContentExchange;","_contentLength","I"));
                code.visitJumpStmt(IF_LTZ,0,-1,L5);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Lorg/mortbay/util/ByteArrayOutputStream2;");
                code.visitFieldStmt(IGET,1,2,new Field("Lorg/mortbay/jetty/client/ContentExchange;","_contentLength","I"));
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1},new Method("Lorg/mortbay/util/ByteArrayOutputStream2;","<init>",new String[]{ "I"},"V"));
                DexLabel L6=new DexLabel();
                code.visitLabel(L6);
                code.visitFieldStmt(IPUT_OBJECT,0,2,new Field("Lorg/mortbay/jetty/client/ContentExchange;","_responseContent","Lorg/mortbay/util/ByteArrayOutputStream2;"));
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/jetty/client/ContentExchange;","_responseContent","Lorg/mortbay/util/ByteArrayOutputStream2;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 3,0},new Method("Lorg/mortbay/io/Buffer;","writeTo",new String[]{ "Ljava/io/OutputStream;"},"V"));
                code.visitLabel(L4);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L5);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Lorg/mortbay/util/ByteArrayOutputStream2;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Lorg/mortbay/util/ByteArrayOutputStream2;","<init>",new String[]{ },"V"));
                code.visitJumpStmt(GOTO,-1,-1,L6);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m008_onResponseHeader(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Lorg/mortbay/jetty/client/ContentExchange;","onResponseHeader",new String[]{ "Lorg/mortbay/io/Buffer;","Lorg/mortbay/io/Buffer;"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(7);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"name");
                ddv.visitParameterName(1,"value");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(113,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(114,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(115,L2);
                ddv.visitStartLocal(0,L2,"header","I",null);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(135,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(118,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(122,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(123,L6);
                ddv.visitStartLocal(2,L6,"mime","Ljava/lang/String;",null);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(124,L7);
                ddv.visitStartLocal(1,L7,"i","I",null);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(126,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(127,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(128,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(129,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(131,L12);
                ddv.visitRestartLocal(2,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(132,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(115,L14);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_SUPER,new int[]{ 4,5,6},new Method("Lorg/mortbay/jetty/client/CachedExchange;","onResponseHeader",new String[]{ "Lorg/mortbay/io/Buffer;","Lorg/mortbay/io/Buffer;"},"V"));
                code.visitLabel(L1);
                code.visitFieldStmt(SGET_OBJECT,3,-1,new Field("Lorg/mortbay/jetty/HttpHeaders;","CACHE","Lorg/mortbay/jetty/HttpHeaders;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,6},new Method("Lorg/mortbay/jetty/HttpHeaders;","getOrdinal",new String[]{ "Lorg/mortbay/io/Buffer;"},"I"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitLabel(L2);
                code.visitSparseSwitchStmt(SPARSE_SWITCH,0,new int[]{ 12,16},new DexLabel[]{L4,L5});
                code.visitLabel(L3);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L4);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 6},new Method("Lorg/mortbay/io/BufferUtil;","toInt",new String[]{ "Lorg/mortbay/io/Buffer;"},"I"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitFieldStmt(IPUT,3,4,new Field("Lorg/mortbay/jetty/client/ContentExchange;","_contentLength","I"));
                code.visitJumpStmt(GOTO,-1,-1,L3);
                code.visitLabel(L5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Ljava/lang/Object;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 3},new Method("Lorg/mortbay/util/StringUtil;","asciiToLowerCase",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitLabel(L6);
                code.visitConstStmt(CONST_STRING,3,"charset=");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3},new Method("Ljava/lang/String;","indexOf",new String[]{ "Ljava/lang/String;"},"I"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitLabel(L7);
                code.visitJumpStmt(IF_LEZ,1,-1,L12);
                code.visitLabel(L8);
                code.visitStmt2R1N(ADD_INT_LIT8,3,1,8);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3},new Method("Ljava/lang/String;","substring",new String[]{ "I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitLabel(L9);
                code.visitConstStmt(CONST_16,3, Integer.valueOf(59)); // int: 0x0000003b  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3},new Method("Ljava/lang/String;","indexOf",new String[]{ "I"},"I"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitLabel(L10);
                code.visitJumpStmt(IF_LEZ,1,-1,L12);
                code.visitLabel(L11);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3,1},new Method("Ljava/lang/String;","substring",new String[]{ "I","I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitLabel(L12);
                code.visitJumpStmt(IF_EQZ,2,-1,L3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Ljava/lang/String;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitJumpStmt(IF_LEZ,3,-1,L3);
                code.visitLabel(L13);
                code.visitFieldStmt(IPUT_OBJECT,2,4,new Field("Lorg/mortbay/jetty/client/ContentExchange;","_encoding","Ljava/lang/String;"));
                code.visitJumpStmt(GOTO,-1,-1,L3);
                code.visitLabel(L14);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m009_onResponseStatus(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Lorg/mortbay/jetty/client/ContentExchange;","onResponseStatus",new String[]{ "Lorg/mortbay/io/Buffer;","I","Lorg/mortbay/io/Buffer;"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"version");
                ddv.visitParameterName(1,"status");
                ddv.visitParameterName(2,"reason");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(106,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(107,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(108,L2);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT,2,0,new Field("Lorg/mortbay/jetty/client/ContentExchange;","_responseStatus","I"));
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_SUPER,new int[]{ 0,1,2,3},new Method("Lorg/mortbay/jetty/client/CachedExchange;","onResponseStatus",new String[]{ "Lorg/mortbay/io/Buffer;","I","Lorg/mortbay/io/Buffer;"},"V"));
                code.visitLabel(L2);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m010_onRetry(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Lorg/mortbay/jetty/client/ContentExchange;","onRetry",new String[]{ },"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(150,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(152,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(153,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(160,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(161,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(155,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(157,L6);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/jetty/client/ContentExchange;","_fileForUpload","Ljava/io/File;"));
                code.visitJumpStmt(IF_EQZ,0,-1,L5);
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT_OBJECT,0,2,new Field("Lorg/mortbay/jetty/client/ContentExchange;","_requestContent","Lorg/mortbay/io/Buffer;"));
                code.visitLabel(L2);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2},new Method("Lorg/mortbay/jetty/client/ContentExchange;","getInputStream",new String[]{ },"Ljava/io/InputStream;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(IPUT_OBJECT,0,2,new Field("Lorg/mortbay/jetty/client/ContentExchange;","_requestContentSource","Ljava/io/InputStream;"));
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_SUPER,new int[]{ 2},new Method("Lorg/mortbay/jetty/client/CachedExchange;","onRetry",new String[]{ },"V"));
                code.visitLabel(L4);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L5);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/jetty/client/ContentExchange;","_requestContentSource","Ljava/io/InputStream;"));
                code.visitJumpStmt(IF_EQZ,0,-1,L3);
                code.visitLabel(L6);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/io/IOException;");
                code.visitConstStmt(CONST_STRING,1,"Unsupported Retry attempt, no registered file for upload.");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1},new Method("Ljava/io/IOException;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitStmt1R(THROW,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m011_setFileForUpload(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/client/ContentExchange;","setFileForUpload",new String[]{ "Ljava/io/File;"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"fileForUpload");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(178,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(179,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(180,L2);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_OBJECT,2,1,new Field("Lorg/mortbay/jetty/client/ContentExchange;","_fileForUpload","Ljava/io/File;"));
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1},new Method("Lorg/mortbay/jetty/client/ContentExchange;","getInputStream",new String[]{ },"Ljava/io/InputStream;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/jetty/client/ContentExchange;","_requestContentSource","Ljava/io/InputStream;"));
                code.visitLabel(L2);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m012_writeResponseBytesTo(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/client/ContentExchange;","writeResponseBytesTo",new String[]{ "Ljava/io/OutputStream;"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"out");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(99,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(100,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(101,L2);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,3,new Field("Lorg/mortbay/jetty/client/ContentExchange;","_responseContent","Lorg/mortbay/util/ByteArrayOutputStream2;"));
                code.visitJumpStmt(IF_EQZ,0,-1,L2);
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,0,3,new Field("Lorg/mortbay/jetty/client/ContentExchange;","_responseContent","Lorg/mortbay/util/ByteArrayOutputStream2;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/util/ByteArrayOutputStream2;","getBuf",new String[]{ },"[B"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IGET_OBJECT,2,3,new Field("Lorg/mortbay/jetty/client/ContentExchange;","_responseContent","Lorg/mortbay/util/ByteArrayOutputStream2;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/util/ByteArrayOutputStream2;","getCount",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,0,1,2},new Method("Ljava/io/OutputStream;","write",new String[]{ "[B","I","I"},"V"));
                code.visitLabel(L2);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
