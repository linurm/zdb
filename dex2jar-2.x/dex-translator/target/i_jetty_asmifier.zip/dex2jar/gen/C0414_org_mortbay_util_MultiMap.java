package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0414_org_mortbay_util_MultiMap {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(ACC_PUBLIC,"Lorg/mortbay/util/MultiMap;","Ljava/util/HashMap;",new String[]{ "Ljava/lang/Cloneable;"});
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("MultiMap.java");
        m000__init_(cv);
        m001__init_(cv);
        m002__init_(cv);
        m003_add(cv);
        m004_addValues(cv);
        m005_addValues(cv);
        m006_clone(cv);
        m007_get(cv);
        m008_getString(cv);
        m009_getValue(cv);
        m010_getValues(cv);
        m011_put(cv);
        m012_putAll(cv);
        m013_putValues(cv);
        m014_putValues(cv);
        m015_removeValue(cv);
        m016_toStringArrayMap(cv);
    }
    public static void m000__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/util/MultiMap;","<init>",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(1);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(40,L0);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/util/HashMap;","<init>",new String[]{ },"V"));
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/util/MultiMap;","<init>",new String[]{ "I"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"size");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(48,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(49,L1);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1},new Method("Ljava/util/HashMap;","<init>",new String[]{ "I"},"V"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m002__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/util/MultiMap;","<init>",new String[]{ "Ljava/util/Map;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"map");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(57,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(58,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(59,L2);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 2},new Method("Ljava/util/Map;","size",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitStmt2R1N(MUL_INT_LIT8,0,0,3);
                code.visitStmt2R1N(DIV_INT_LIT8,0,0,2);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1,0},new Method("Ljava/util/HashMap;","<init>",new String[]{ "I"},"V"));
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2},new Method("Lorg/mortbay/util/MultiMap;","putAll",new String[]{ "Ljava/util/Map;"},"V"));
                code.visitLabel(L2);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m003_add(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/util/MultiMap;","add",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"name");
                ddv.visitParameterName(1,"value");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(188,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(189,L1);
                ddv.visitStartLocal(1,L1,"lo","Ljava/lang/Object;",null);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(190,L2);
                ddv.visitStartLocal(0,L2,"ln","Ljava/lang/Object;",null);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(191,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(192,L4);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_SUPER,new int[]{ 2,3},new Method("Ljava/util/HashMap;","get",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1,4},new Method("Lorg/mortbay/util/LazyList;","add",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L2);
                code.visitJumpStmt(IF_EQ,1,0,L4);
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_SUPER,new int[]{ 2,3,0},new Method("Ljava/util/HashMap;","put",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitLabel(L4);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m004_addValues(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/util/MultiMap;","addValues",new String[]{ "Ljava/lang/Object;","Ljava/util/List;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"name");
                ddv.visitParameterName(1,"values");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(203,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(204,L1);
                ddv.visitStartLocal(1,L1,"lo","Ljava/lang/Object;",null);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(205,L2);
                ddv.visitStartLocal(0,L2,"ln","Ljava/lang/Object;",null);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(206,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(207,L4);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_SUPER,new int[]{ 2,3},new Method("Ljava/util/HashMap;","get",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1,4},new Method("Lorg/mortbay/util/LazyList;","addCollection",new String[]{ "Ljava/lang/Object;","Ljava/util/Collection;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L2);
                code.visitJumpStmt(IF_EQ,1,0,L4);
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_SUPER,new int[]{ 2,3,0},new Method("Ljava/util/HashMap;","put",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitLabel(L4);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m005_addValues(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/util/MultiMap;","addValues",new String[]{ "Ljava/lang/Object;","[Ljava/lang/String;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(6);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"name");
                ddv.visitParameterName(1,"values");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(218,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(219,L1);
                ddv.visitStartLocal(1,L1,"lo","Ljava/lang/Object;",null);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(220,L2);
                ddv.visitStartLocal(0,L2,"ln","Ljava/lang/Object;",null);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(221,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(222,L4);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_SUPER,new int[]{ 3,4},new Method("Ljava/util/HashMap;","get",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 5},new Method("Ljava/util/Arrays;","asList",new String[]{ "[Ljava/lang/Object;"},"Ljava/util/List;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1,2},new Method("Lorg/mortbay/util/LazyList;","addCollection",new String[]{ "Ljava/lang/Object;","Ljava/util/Collection;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L2);
                code.visitJumpStmt(IF_EQ,1,0,L4);
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_SUPER,new int[]{ 3,4,0},new Method("Ljava/util/HashMap;","put",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitLabel(L4);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m006_clone(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/util/MultiMap;","clone",new String[]{ },"Ljava/lang/Object;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(290,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(292,L1);
                ddv.visitStartLocal(2,L1,"mm","Lorg/mortbay/util/MultiMap;",null);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(293,L2);
                ddv.visitStartLocal(1,L2,"iter","Ljava/util/Iterator;",null);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(295,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(296,L4);
                ddv.visitStartLocal(0,L4,"entry","Ljava/util/Map$Entry;",null);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(299,L5);
                ddv.visitEndLocal(0,L5);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_SUPER,new int[]{ 4},new Method("Ljava/util/HashMap;","clone",new String[]{ },"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitTypeStmt(CHECK_CAST,2,-1,"Lorg/mortbay/util/MultiMap;");
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/util/MultiMap;","entrySet",new String[]{ },"Ljava/util/Set;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 3},new Method("Ljava/util/Set;","iterator",new String[]{ },"Ljava/util/Iterator;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L2);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 1},new Method("Ljava/util/Iterator;","hasNext",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitJumpStmt(IF_EQZ,3,-1,L5);
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 1},new Method("Ljava/util/Iterator;","next",new String[]{ },"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitTypeStmt(CHECK_CAST,0,-1,"Ljava/util/Map$Entry;");
                code.visitLabel(L4);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0},new Method("Ljava/util/Map$Entry;","getValue",new String[]{ },"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 3},new Method("Lorg/mortbay/util/LazyList;","clone",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,3},new Method("Ljava/util/Map$Entry;","setValue",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitLabel(L5);
                code.visitStmt1R(RETURN_OBJECT,2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m007_get(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/util/MultiMap;","get",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/Object;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"name");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(129,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(130,L1);
                ddv.visitStartLocal(0,L1,"l","Ljava/lang/Object;",null);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(138,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(133,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(135,L4);
                DexLabel L5=new DexLabel();
                ddv.visitStartLocal(1,L5,"o","Ljava/lang/Object;",null);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(136,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(130,L7);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_SUPER,new int[]{ 3,4},new Method("Ljava/util/HashMap;","get",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0},new Method("Lorg/mortbay/util/LazyList;","size",new String[]{ "Ljava/lang/Object;"},"I"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitSparseSwitchStmt(PACKED_SWITCH,2,0,new DexLabel[]{L3,L4});
                code.visitLabel(L2);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0,2},new Method("Lorg/mortbay/util/LazyList;","getList",new String[]{ "Ljava/lang/Object;","Z"},"Ljava/util/List;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                DexLabel L8=new DexLabel();
                code.visitLabel(L8);
                code.visitStmt1R(RETURN_OBJECT,2);
                code.visitLabel(L3);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L8);
                code.visitLabel(L4);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0,2},new Method("Lorg/mortbay/util/LazyList;","get",new String[]{ "Ljava/lang/Object;","I"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L5);
                code.visitStmt2R(MOVE_OBJECT,2,1);
                code.visitLabel(L6);
                code.visitJumpStmt(GOTO,-1,-1,L8);
                code.visitLabel(L7);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m008_getString(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/util/MultiMap;","getString",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(9);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexLabel L3=new DexLabel();
                DexLabel L4=new DexLabel();
                code.visitTryCatch(L3,L4,new DexLabel[]{L2},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"name");
                DexLabel L5=new DexLabel();
                ddv.visitPrologue(L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(99,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(100,L7);
                ddv.visitStartLocal(2,L7,"l","Ljava/lang/Object;",null);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(108,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(109,L9);
                ddv.visitStartLocal(4,L9,"values","Ljava/lang/StringBuffer;",null);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(111,L10);
                ddv.visitStartLocal(1,L0,"i","I",null);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(113,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(114,L12);
                ddv.visitStartLocal(0,L12,"e","Ljava/lang/Object;",null);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(116,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(117,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(118,L15);
                ddv.visitLineNumber(111,L1);
                DexLabel L16=new DexLabel();
                ddv.visitEndLocal(4,L16);
                ddv.visitEndLocal(1,L16);
                ddv.visitEndLocal(0,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(121,L17);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(105,L18);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(106,L19);
                ddv.visitStartLocal(3,L19,"o","Ljava/lang/Object;",null);
                ddv.visitLineNumber(121,L3);
                ddv.visitEndLocal(3,L3);
                ddv.visitRestartLocal(1,L3);
                ddv.visitRestartLocal(4,L3);
                ddv.visitLineNumber(122,L2);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(100,L20);
                code.visitLabel(L5);
                code.visitConstStmt(CONST_4,6, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L6);
                code.visitMethodStmt(INVOKE_SUPER,new int[]{ 7,8},new Method("Ljava/util/HashMap;","get",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitLabel(L7);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 2},new Method("Lorg/mortbay/util/LazyList;","size",new String[]{ "Ljava/lang/Object;"},"I"));
                code.visitStmt1R(MOVE_RESULT,5);
                code.visitSparseSwitchStmt(PACKED_SWITCH,5,0,new DexLabel[]{L16,L18});
                code.visitLabel(L8);
                code.visitTypeStmt(NEW_INSTANCE,4,-1,"Ljava/lang/StringBuffer;");
                code.visitConstStmt(CONST_16,5, Integer.valueOf(128)); // int: 0x00000080  float:0.000000
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 4,5},new Method("Ljava/lang/StringBuffer;","<init>",new String[]{ "I"},"V"));
                code.visitLabel(L9);
                code.visitStmt1R(MONITOR_ENTER,4);
                code.visitLabel(L10);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 2},new Method("Lorg/mortbay/util/LazyList;","size",new String[]{ "Ljava/lang/Object;"},"I"));
                code.visitStmt1R(MOVE_RESULT,5);
                code.visitJumpStmt(IF_GE,1,5,L3);
                code.visitLabel(L11);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 2,1},new Method("Lorg/mortbay/util/LazyList;","get",new String[]{ "Ljava/lang/Object;","I"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L12);
                code.visitJumpStmt(IF_EQZ,0,-1,L1);
                code.visitLabel(L13);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Ljava/lang/StringBuffer;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,5);
                code.visitJumpStmt(IF_LEZ,5,-1,L15);
                code.visitLabel(L14);
                code.visitConstStmt(CONST_16,5, Integer.valueOf(44)); // int: 0x0000002c  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,5},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "C"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L15);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/lang/Object;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,5},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L1);
                code.visitStmt2R1N(ADD_INT_LIT8,1,1,1);
                code.visitJumpStmt(GOTO,-1,-1,L0);
                code.visitLabel(L16);
                code.visitStmt2R(MOVE_OBJECT,5,6);
                code.visitLabel(L17);
                code.visitStmt1R(RETURN_OBJECT,5);
                code.visitLabel(L18);
                code.visitConstStmt(CONST_4,5, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 2,5},new Method("Lorg/mortbay/util/LazyList;","get",new String[]{ "Ljava/lang/Object;","I"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitLabel(L19);
                DexLabel L21=new DexLabel();
                code.visitJumpStmt(IF_NEZ,3,-1,L21);
                code.visitStmt2R(MOVE_OBJECT,5,6);
                code.visitJumpStmt(GOTO,-1,-1,L17);
                code.visitLabel(L21);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Ljava/lang/Object;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitJumpStmt(GOTO,-1,-1,L17);
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Ljava/lang/StringBuffer;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitStmt1R(MONITOR_EXIT,4);
                code.visitJumpStmt(GOTO,-1,-1,L17);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,5);
                code.visitStmt1R(MONITOR_EXIT,4);
                code.visitLabel(L4);
                code.visitStmt1R(THROW,5);
                code.visitLabel(L20);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m009_getValue(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/util/MultiMap;","getValue",new String[]{ "Ljava/lang/Object;","I"},"Ljava/lang/Object;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"name");
                ddv.visitParameterName(1,"i");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(82,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(83,L1);
                ddv.visitStartLocal(0,L1,"l","Ljava/lang/Object;",null);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(84,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(85,L3);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_SUPER,new int[]{ 2,3},new Method("Ljava/util/HashMap;","get",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L1);
                DexLabel L4=new DexLabel();
                code.visitJumpStmt(IF_NEZ,4,-1,L4);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0},new Method("Lorg/mortbay/util/LazyList;","size",new String[]{ "Ljava/lang/Object;"},"I"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitJumpStmt(IF_NEZ,1,-1,L4);
                code.visitLabel(L2);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L3);
                code.visitStmt1R(RETURN_OBJECT,1);
                code.visitLabel(L4);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0,4},new Method("Lorg/mortbay/util/LazyList;","get",new String[]{ "Ljava/lang/Object;","I"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitJumpStmt(GOTO,-1,-1,L3);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m010_getValues(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/util/MultiMap;","getValues",new String[]{ "Ljava/lang/Object;"},"Ljava/util/List;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"name");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(69,L0);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_SUPER,new int[]{ 2,3},new Method("Ljava/util/HashMap;","get",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0,1},new Method("Lorg/mortbay/util/LazyList;","getList",new String[]{ "Ljava/lang/Object;","Z"},"Ljava/util/List;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m011_put(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/util/MultiMap;","put",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"name");
                ddv.visitParameterName(1,"value");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(150,L0);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0,3},new Method("Lorg/mortbay/util/LazyList;","add",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_SUPER,new int[]{ 1,2,0},new Method("Ljava/util/HashMap;","put",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m012_putAll(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/util/MultiMap;","putAll",new String[]{ "Ljava/util/Map;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(7);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"m");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(252,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(253,L1);
                ddv.visitStartLocal(1,L1,"i","Ljava/util/Iterator;",null);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(254,L2);
                ddv.visitStartLocal(2,L2,"multi","Z",null);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(256,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(258,L4);
                ddv.visitStartLocal(0,L4,"entry","Ljava/util/Map$Entry;",null);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(259,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(261,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(263,L7);
                ddv.visitEndLocal(0,L7);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 6},new Method("Ljava/util/Map;","entrySet",new String[]{ },"Ljava/util/Set;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 3},new Method("Ljava/util/Set;","iterator",new String[]{ },"Ljava/util/Iterator;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L1);
                code.visitTypeStmt(INSTANCE_OF,2,6,"Lorg/mortbay/util/MultiMap;");
                code.visitLabel(L2);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 1},new Method("Ljava/util/Iterator;","hasNext",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitJumpStmt(IF_EQZ,3,-1,L7);
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 1},new Method("Ljava/util/Iterator;","next",new String[]{ },"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitTypeStmt(CHECK_CAST,0,-1,"Ljava/util/Map$Entry;");
                code.visitLabel(L4);
                code.visitJumpStmt(IF_EQZ,2,-1,L6);
                code.visitLabel(L5);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0},new Method("Ljava/util/Map$Entry;","getKey",new String[]{ },"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0},new Method("Ljava/util/Map$Entry;","getValue",new String[]{ },"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 4},new Method("Lorg/mortbay/util/LazyList;","clone",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitMethodStmt(INVOKE_SUPER,new int[]{ 5,3,4},new Method("Ljava/util/HashMap;","put",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitLabel(L6);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0},new Method("Ljava/util/Map$Entry;","getKey",new String[]{ },"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0},new Method("Ljava/util/Map$Entry;","getValue",new String[]{ },"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,3,4},new Method("Lorg/mortbay/util/MultiMap;","put",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitLabel(L7);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m013_putValues(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/util/MultiMap;","putValues",new String[]{ "Ljava/lang/Object;","Ljava/util/List;"},"Ljava/lang/Object;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"name");
                ddv.visitParameterName(1,"values");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(161,L0);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_SUPER,new int[]{ 1,2,3},new Method("Ljava/util/HashMap;","put",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m014_putValues(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/util/MultiMap;","putValues",new String[]{ "Ljava/lang/Object;","[Ljava/lang/String;"},"Ljava/lang/Object;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(6);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"name");
                ddv.visitParameterName(1,"values");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(172,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(173,L1);
                ddv.visitStartLocal(1,L1,"list","Ljava/lang/Object;",null);
                DexLabel L2=new DexLabel();
                ddv.visitEndLocal(1,L2);
                ddv.visitStartLocal(0,L2,"i","I",null);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(174,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(173,L4);
                ddv.visitStartLocal(1,L4,"list","Ljava/lang/Object;",null);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(175,L5);
                ddv.visitEndLocal(1,L5);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L2);
                code.visitStmt2R(ARRAY_LENGTH,2,5);
                code.visitJumpStmt(IF_GE,0,2,L5);
                code.visitLabel(L3);
                code.visitStmt3R(AGET_OBJECT,2,5,0);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1,2},new Method("Lorg/mortbay/util/LazyList;","add",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L4);
                code.visitStmt2R1N(ADD_INT_LIT8,0,0,1);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitLabel(L5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,4,1},new Method("Lorg/mortbay/util/MultiMap;","put",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitStmt1R(RETURN_OBJECT,2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m015_removeValue(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/util/MultiMap;","removeValue",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;"},"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(7);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"name");
                ddv.visitParameterName(1,"value");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(232,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(233,L1);
                ddv.visitStartLocal(1,L1,"lo","Ljava/lang/Object;",null);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(234,L2);
                ddv.visitStartLocal(0,L2,"ln","Ljava/lang/Object;",null);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(235,L3);
                ddv.visitStartLocal(2,L3,"s","I",null);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(237,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(238,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(239,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(243,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(241,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(243,L9);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_SUPER,new int[]{ 4,5},new Method("Ljava/util/HashMap;","get",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L1);
                code.visitStmt2R(MOVE_OBJECT,0,1);
                code.visitLabel(L2);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1},new Method("Lorg/mortbay/util/LazyList;","size",new String[]{ "Ljava/lang/Object;"},"I"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitLabel(L3);
                code.visitJumpStmt(IF_LEZ,2,-1,L7);
                code.visitLabel(L4);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1,6},new Method("Lorg/mortbay/util/LazyList;","remove",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L5);
                code.visitJumpStmt(IF_NEZ,0,-1,L8);
                code.visitLabel(L6);
                code.visitMethodStmt(INVOKE_SUPER,new int[]{ 4,5},new Method("Ljava/util/HashMap;","remove",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitLabel(L7);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0},new Method("Lorg/mortbay/util/LazyList;","size",new String[]{ "Ljava/lang/Object;"},"I"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitJumpStmt(IF_EQ,3,2,L9);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                DexLabel L10=new DexLabel();
                code.visitLabel(L10);
                code.visitStmt1R(RETURN,3);
                code.visitLabel(L8);
                code.visitMethodStmt(INVOKE_SUPER,new int[]{ 4,5,0},new Method("Ljava/util/HashMap;","put",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitJumpStmt(GOTO,-1,-1,L7);
                code.visitLabel(L9);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L10);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m016_toStringArrayMap(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/util/MultiMap;","toStringArrayMap",new String[]{ },"Ljava/util/Map;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(7);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(271,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(273,L1);
                ddv.visitStartLocal(4,L1,"map","Ljava/util/HashMap;",null);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(274,L2);
                ddv.visitStartLocal(2,L2,"i","Ljava/util/Iterator;",null);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(276,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(277,L4);
                ddv.visitStartLocal(1,L4,"entry","Ljava/util/Map$Entry;",null);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(278,L5);
                ddv.visitStartLocal(3,L5,"l","Ljava/lang/Object;",null);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(282,L6);
                ddv.visitStartLocal(0,L6,"a","[Ljava/lang/String;",null);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(284,L7);
                ddv.visitEndLocal(1,L7);
                ddv.visitEndLocal(3,L7);
                ddv.visitEndLocal(0,L7);
                code.visitLabel(L0);
                code.visitTypeStmt(NEW_INSTANCE,4,-1,"Ljava/util/HashMap;");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Lorg/mortbay/util/MultiMap;","size",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,5);
                code.visitStmt2R1N(MUL_INT_LIT8,5,5,3);
                code.visitStmt2R1N(DIV_INT_LIT8,5,5,2);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 4,5},new Method("Ljava/util/HashMap;","<init>",new String[]{ "I"},"V"));
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_SUPER,new int[]{ 6},new Method("Ljava/util/HashMap;","entrySet",new String[]{ },"Ljava/util/Set;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 5},new Method("Ljava/util/Set;","iterator",new String[]{ },"Ljava/util/Iterator;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitLabel(L2);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 2},new Method("Ljava/util/Iterator;","hasNext",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,5);
                code.visitJumpStmt(IF_EQZ,5,-1,L7);
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 2},new Method("Ljava/util/Iterator;","next",new String[]{ },"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitTypeStmt(CHECK_CAST,1,-1,"Ljava/util/Map$Entry;");
                code.visitLabel(L4);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 1},new Method("Ljava/util/Map$Entry;","getValue",new String[]{ },"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitLabel(L5);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 3},new Method("Lorg/mortbay/util/LazyList;","toStringArray",new String[]{ "Ljava/lang/Object;"},"[Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L6);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 1},new Method("Ljava/util/Map$Entry;","getKey",new String[]{ },"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,5,0},new Method("Ljava/util/HashMap;","put",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitLabel(L7);
                code.visitStmt1R(RETURN_OBJECT,4);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
