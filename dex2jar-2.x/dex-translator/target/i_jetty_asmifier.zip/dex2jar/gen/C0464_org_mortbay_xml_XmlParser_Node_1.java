package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0464_org_mortbay_xml_XmlParser_Node_1 {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(0,"Lorg/mortbay/xml/XmlParser$Node$1;","Ljava/lang/Object;",new String[]{ "Ljava/util/Iterator;"});
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("XmlParser.java");
        if(cv!=null){
            DexAnnotationVisitor av00 = cv.visitAnnotation("Ldalvik/annotation/EnclosingMethod;", Visibility.SYSTEM);
            if(av00 != null) {
                av00.visit("value", new Method("Lorg/mortbay/xml/XmlParser$Node;","iterator",new String[]{ "Ljava/lang/String;"},"Ljava/util/Iterator;"));
                av00.visitEnd();
            }
        }
        if(cv!=null){
            DexAnnotationVisitor av00 = cv.visitAnnotation("Ldalvik/annotation/InnerClass;", Visibility.SYSTEM);
            if(av00 != null) {
                av00.visit("accessFlags",  Integer.valueOf(0));
                av00.visit("name", null);
                av00.visitEnd();
            }
        }
        f000__node(cv);
        f001_c(cv);
        f002_this$0(cv);
        f003_val$tag(cv);
        m000__init_(cv);
        m001_hasNext(cv);
        m002_next(cv);
        m003_remove(cv);
    }
    public static void f000__node(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(0, new Field("Lorg/mortbay/xml/XmlParser$Node$1;","_node","Lorg/mortbay/xml/XmlParser$Node;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f001_c(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(0, new Field("Lorg/mortbay/xml/XmlParser$Node$1;","c","I"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f002_this$0(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_FINAL|ACC_SYNTHETIC, new Field("Lorg/mortbay/xml/XmlParser$Node$1;","this$0","Lorg/mortbay/xml/XmlParser$Node;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f003_val$tag(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_FINAL|ACC_SYNTHETIC, new Field("Lorg/mortbay/xml/XmlParser$Node$1;","val$tag","Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void m000__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_CONSTRUCTOR, new Method("Lorg/mortbay/xml/XmlParser$Node$1;","<init>",new String[]{ "Lorg/mortbay/xml/XmlParser$Node;","Ljava/lang/String;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(793,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(751,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_OBJECT,2,1,new Field("Lorg/mortbay/xml/XmlParser$Node$1;","this$0","Lorg/mortbay/xml/XmlParser$Node;"));
                code.visitFieldStmt(IPUT_OBJECT,3,1,new Field("Lorg/mortbay/xml/XmlParser$Node$1;","val$tag","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1},new Method("Ljava/lang/Object;","<init>",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT,0,1,new Field("Lorg/mortbay/xml/XmlParser$Node$1;","c","I"));
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001_hasNext(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/xml/XmlParser$Node$1;","hasNext",new String[]{ },"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(7);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(757,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(773,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(771,L3);
                ddv.visitStartLocal(2,L3,"o","Ljava/lang/Object;",null);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(759,L4);
                ddv.visitEndLocal(2,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(761,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(762,L6);
                ddv.visitRestartLocal(2,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(764,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(765,L8);
                ddv.visitStartLocal(1,L8,"n","Lorg/mortbay/xml/XmlParser$Node;",null);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(767,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(768,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(773,L11);
                ddv.visitEndLocal(2,L11);
                ddv.visitEndLocal(1,L11);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,5, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,3,6,new Field("Lorg/mortbay/xml/XmlParser$Node$1;","_node","Lorg/mortbay/xml/XmlParser$Node;"));
                code.visitJumpStmt(IF_EQZ,3,-1,L4);
                code.visitStmt2R(MOVE,3,5);
                code.visitLabel(L2);
                code.visitStmt1R(RETURN,3);
                code.visitLabel(L3);
                code.visitFieldStmt(IGET,3,6,new Field("Lorg/mortbay/xml/XmlParser$Node$1;","c","I"));
                code.visitStmt2R1N(ADD_INT_LIT8,3,3,1);
                code.visitFieldStmt(IPUT,3,6,new Field("Lorg/mortbay/xml/XmlParser$Node$1;","c","I"));
                code.visitLabel(L4);
                code.visitFieldStmt(IGET_OBJECT,3,6,new Field("Lorg/mortbay/xml/XmlParser$Node$1;","this$0","Lorg/mortbay/xml/XmlParser$Node;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 3},new Method("Lorg/mortbay/xml/XmlParser$Node;","access$600",new String[]{ "Lorg/mortbay/xml/XmlParser$Node;"},"Ljava/util/ArrayList;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitJumpStmt(IF_EQZ,3,-1,L11);
                code.visitFieldStmt(IGET,3,6,new Field("Lorg/mortbay/xml/XmlParser$Node$1;","c","I"));
                code.visitFieldStmt(IGET_OBJECT,4,6,new Field("Lorg/mortbay/xml/XmlParser$Node$1;","this$0","Lorg/mortbay/xml/XmlParser$Node;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 4},new Method("Lorg/mortbay/xml/XmlParser$Node;","access$600",new String[]{ "Lorg/mortbay/xml/XmlParser$Node;"},"Ljava/util/ArrayList;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Ljava/util/ArrayList;","size",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,4);
                code.visitJumpStmt(IF_GE,3,4,L11);
                code.visitLabel(L5);
                code.visitFieldStmt(IGET_OBJECT,3,6,new Field("Lorg/mortbay/xml/XmlParser$Node$1;","this$0","Lorg/mortbay/xml/XmlParser$Node;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 3},new Method("Lorg/mortbay/xml/XmlParser$Node;","access$600",new String[]{ "Lorg/mortbay/xml/XmlParser$Node;"},"Ljava/util/ArrayList;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitFieldStmt(IGET,4,6,new Field("Lorg/mortbay/xml/XmlParser$Node$1;","c","I"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,4},new Method("Ljava/util/ArrayList;","get",new String[]{ "I"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitLabel(L6);
                code.visitTypeStmt(INSTANCE_OF,3,2,"Lorg/mortbay/xml/XmlParser$Node;");
                code.visitJumpStmt(IF_EQZ,3,-1,L3);
                code.visitLabel(L7);
                code.visitStmt2R(MOVE_OBJECT,0,2);
                code.visitTypeStmt(CHECK_CAST,0,-1,"Lorg/mortbay/xml/XmlParser$Node;");
                code.visitStmt2R(MOVE_OBJECT,1,0);
                code.visitLabel(L8);
                code.visitFieldStmt(IGET_OBJECT,3,6,new Field("Lorg/mortbay/xml/XmlParser$Node$1;","val$tag","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1},new Method("Lorg/mortbay/xml/XmlParser$Node;","access$700",new String[]{ "Lorg/mortbay/xml/XmlParser$Node;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,4},new Method("Ljava/lang/String;","equals",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitJumpStmt(IF_EQZ,3,-1,L3);
                code.visitLabel(L9);
                code.visitFieldStmt(IPUT_OBJECT,1,6,new Field("Lorg/mortbay/xml/XmlParser$Node$1;","_node","Lorg/mortbay/xml/XmlParser$Node;"));
                code.visitStmt2R(MOVE,3,5);
                code.visitLabel(L10);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitLabel(L11);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m002_next(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/xml/XmlParser$Node$1;","next",new String[]{ },"Ljava/lang/Object;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexLabel L3=new DexLabel();
                code.visitTryCatch(L3,L2,new DexLabel[]{L2},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L4=new DexLabel();
                ddv.visitPrologue(L4);
                ddv.visitLineNumber(781,L0);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(782,L5);
                ddv.visitLineNumber(787,L1);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(788,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(782,L7);
                ddv.visitLineNumber(783,L3);
                ddv.visitLineNumber(787,L2);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(788,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(787,L9);
                code.visitLabel(L4);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/xml/XmlParser$Node$1;","hasNext",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_EQZ,0,-1,L3);
                code.visitLabel(L5);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/xml/XmlParser$Node$1;","_node","Lorg/mortbay/xml/XmlParser$Node;"));
                code.visitLabel(L1);
                code.visitFieldStmt(IPUT_OBJECT,1,2,new Field("Lorg/mortbay/xml/XmlParser$Node$1;","_node","Lorg/mortbay/xml/XmlParser$Node;"));
                code.visitLabel(L6);
                code.visitFieldStmt(IGET,1,2,new Field("Lorg/mortbay/xml/XmlParser$Node$1;","c","I"));
                code.visitStmt2R1N(ADD_INT_LIT8,1,1,1);
                code.visitFieldStmt(IPUT,1,2,new Field("Lorg/mortbay/xml/XmlParser$Node$1;","c","I"));
                code.visitLabel(L7);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitLabel(L3);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/util/NoSuchElementException;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/util/NoSuchElementException;","<init>",new String[]{ },"V"));
                code.visitStmt1R(THROW,0);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,0);
                code.visitFieldStmt(IPUT_OBJECT,1,2,new Field("Lorg/mortbay/xml/XmlParser$Node$1;","_node","Lorg/mortbay/xml/XmlParser$Node;"));
                code.visitLabel(L8);
                code.visitFieldStmt(IGET,1,2,new Field("Lorg/mortbay/xml/XmlParser$Node$1;","c","I"));
                code.visitStmt2R1N(ADD_INT_LIT8,1,1,1);
                code.visitFieldStmt(IPUT,1,2,new Field("Lorg/mortbay/xml/XmlParser$Node$1;","c","I"));
                code.visitLabel(L9);
                code.visitStmt1R(THROW,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m003_remove(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/xml/XmlParser$Node$1;","remove",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(795,L0);
                code.visitLabel(L0);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/lang/UnsupportedOperationException;");
                code.visitConstStmt(CONST_STRING,1,"Not supported");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1},new Method("Ljava/lang/UnsupportedOperationException;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitStmt1R(THROW,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
