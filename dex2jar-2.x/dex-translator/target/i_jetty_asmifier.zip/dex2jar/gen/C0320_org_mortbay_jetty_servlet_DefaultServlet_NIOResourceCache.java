package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0320_org_mortbay_jetty_servlet_DefaultServlet_NIOResourceCache {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(0,"Lorg/mortbay/jetty/servlet/DefaultServlet$NIOResourceCache;","Lorg/mortbay/jetty/ResourceCache;",new String[]{ });
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("DefaultServlet.java");
        if(cv!=null){
            DexAnnotationVisitor av00 = cv.visitAnnotation("Ldalvik/annotation/EnclosingClass;", Visibility.SYSTEM);
            if(av00 != null) {
                av00.visit("value", new DexType("Lorg/mortbay/jetty/servlet/DefaultServlet;"));
                av00.visitEnd();
            }
        }
        if(cv!=null){
            DexAnnotationVisitor av00 = cv.visitAnnotation("Ldalvik/annotation/InnerClass;", Visibility.SYSTEM);
            if(av00 != null) {
                av00.visit("accessFlags",  Integer.valueOf(0));
                av00.visit("name", "NIOResourceCache");
                av00.visitEnd();
            }
        }
        f000_this$0(cv);
        m000__init_(cv);
        m001_fill(cv);
    }
    public static void f000_this$0(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_FINAL|ACC_SYNTHETIC, new Field("Lorg/mortbay/jetty/servlet/DefaultServlet$NIOResourceCache;","this$0","Lorg/mortbay/jetty/servlet/DefaultServlet;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void m000__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/jetty/servlet/DefaultServlet$NIOResourceCache;","<init>",new String[]{ "Lorg/mortbay/jetty/servlet/DefaultServlet;","Lorg/mortbay/jetty/MimeTypes;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(1,"mimeTypes");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(918,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(919,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(920,L2);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_OBJECT,1,0,new Field("Lorg/mortbay/jetty/servlet/DefaultServlet$NIOResourceCache;","this$0","Lorg/mortbay/jetty/servlet/DefaultServlet;"));
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,2},new Method("Lorg/mortbay/jetty/ResourceCache;","<init>",new String[]{ "Lorg/mortbay/jetty/MimeTypes;"},"V"));
                code.visitLabel(L2);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001_fill(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Lorg/mortbay/jetty/servlet/DefaultServlet$NIOResourceCache;","fill",new String[]{ "Lorg/mortbay/jetty/ResourceCache$Content;"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(11);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ "Ljava/lang/OutOfMemoryError;"});
                DexLabel L3=new DexLabel();
                DexLabel L4=new DexLabel();
                code.visitTryCatch(L3,L4,new DexLabel[]{L2},new String[]{ "Ljava/lang/OutOfMemoryError;"});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"content");
                DexLabel L5=new DexLabel();
                ddv.visitPrologue(L5);
                ddv.visitLineNumber(925,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(926,L6);
                ddv.visitStartLocal(0,L6,"buffer","Lorg/mortbay/io/Buffer;",null);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(927,L7);
                ddv.visitStartLocal(6,L7,"resource","Lorg/mortbay/resource/Resource;",null);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(929,L8);
                ddv.visitStartLocal(4,L8,"length","J",null);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(931,L9);
                DexLabel L10=new DexLabel();
                ddv.visitEndLocal(0,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(953,L11);
                ddv.visitRestartLocal(0,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(954,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(935,L13);
                ddv.visitLineNumber(938,L0);
                ddv.visitStartLocal(3,L0,"is","Ljava/io/InputStream;",null);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(939,L14);
                ddv.visitStartLocal(1,L14,"connector","Lorg/mortbay/jetty/Connector;",null);
                DexLabel L15=new DexLabel();
                ddv.visitEndLocal(1,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(950,L16);
                ddv.visitRestartLocal(0,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(951,L17);
                ddv.visitLineNumber(939,L3);
                ddv.visitLineNumber(944,L2);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(946,L18);
                ddv.visitStartLocal(2,L18,"e","Ljava/lang/OutOfMemoryError;",null);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(947,L19);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(948,L20);
                DexLabel L21=new DexLabel();
                ddv.visitEndLocal(0,L21);
                DexLabel L22=new DexLabel();
                ddv.visitRestartLocal(0,L22);
                code.visitLabel(L5);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10},new Method("Lorg/mortbay/jetty/ResourceCache$Content;","getResource",new String[]{ },"Lorg/mortbay/resource/Resource;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitLabel(L7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Lorg/mortbay/resource/Resource;","length",new String[]{ },"J"));
                code.visitStmt1R(MOVE_RESULT_WIDE,4);
                code.visitLabel(L8);
                code.visitFieldStmt(IGET_OBJECT,7,9,new Field("Lorg/mortbay/jetty/servlet/DefaultServlet$NIOResourceCache;","this$0","Lorg/mortbay/jetty/servlet/DefaultServlet;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 7},new Method("Lorg/mortbay/jetty/servlet/DefaultServlet;","access$100",new String[]{ "Lorg/mortbay/jetty/servlet/DefaultServlet;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,7);
                code.visitJumpStmt(IF_EQZ,7,-1,L13);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Lorg/mortbay/resource/Resource;","getFile",new String[]{ },"Ljava/io/File;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitJumpStmt(IF_EQZ,7,-1,L13);
                code.visitLabel(L9);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Lorg/mortbay/io/nio/DirectNIOBuffer;");
                code.visitLabel(L10);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Lorg/mortbay/resource/Resource;","getFile",new String[]{ },"Ljava/io/File;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,7},new Method("Lorg/mortbay/io/nio/DirectNIOBuffer;","<init>",new String[]{ "Ljava/io/File;"},"V"));
                code.visitLabel(L11);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10,0},new Method("Lorg/mortbay/jetty/ResourceCache$Content;","setBuffer",new String[]{ "Lorg/mortbay/io/Buffer;"},"V"));
                code.visitLabel(L12);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L13);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Lorg/mortbay/resource/Resource;","getInputStream",new String[]{ },"Ljava/io/InputStream;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Lorg/mortbay/jetty/HttpConnection;","getCurrentConnection",new String[]{ },"Lorg/mortbay/jetty/HttpConnection;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7},new Method("Lorg/mortbay/jetty/HttpConnection;","getConnector",new String[]{ },"Lorg/mortbay/jetty/Connector;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L14);
                code.visitTypeStmt(CHECK_CAST,1,-1,"Lorg/mortbay/jetty/nio/NIOConnector;");
                code.visitLabel(L15);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 1},new Method("Lorg/mortbay/jetty/nio/NIOConnector;","getUseDirectBuffers",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,7);
                code.visitJumpStmt(IF_EQZ,7,-1,L3);
                code.visitTypeStmt(NEW_INSTANCE,7,-1,"Lorg/mortbay/io/nio/DirectNIOBuffer;");
                code.visitStmt2R(LONG_TO_INT,8,4);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 7,8},new Method("Lorg/mortbay/io/nio/DirectNIOBuffer;","<init>",new String[]{ "I"},"V"));
                code.visitLabel(L1);
                code.visitStmt2R(MOVE_OBJECT,0,7);
                code.visitLabel(L16);
                code.visitStmt2R(LONG_TO_INT,7,4);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,3,7},new Method("Lorg/mortbay/io/Buffer;","readFrom",new String[]{ "Ljava/io/InputStream;","I"},"I"));
                code.visitLabel(L17);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Ljava/io/InputStream;","close",new String[]{ },"V"));
                code.visitJumpStmt(GOTO,-1,-1,L11);
                code.visitLabel(L3);
                code.visitTypeStmt(NEW_INSTANCE,7,-1,"Lorg/mortbay/io/nio/IndirectNIOBuffer;");
                code.visitStmt2R(LONG_TO_INT,8,4);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 7,8},new Method("Lorg/mortbay/io/nio/IndirectNIOBuffer;","<init>",new String[]{ "I"},"V"));
                code.visitLabel(L4);
                code.visitStmt2R(MOVE_OBJECT,0,7);
                code.visitJumpStmt(GOTO,-1,-1,L16);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,7);
                code.visitStmt2R(MOVE_OBJECT,2,7);
                code.visitLabel(L18);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Ljava/lang/OutOfMemoryError;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 7},new Method("Lorg/mortbay/log/Log;","warn",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L19);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 2},new Method("Lorg/mortbay/log/Log;","debug",new String[]{ "Ljava/lang/Throwable;"},"V"));
                code.visitLabel(L20);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Lorg/mortbay/io/nio/IndirectNIOBuffer;");
                code.visitLabel(L21);
                code.visitStmt2R(LONG_TO_INT,7,4);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,7},new Method("Lorg/mortbay/io/nio/IndirectNIOBuffer;","<init>",new String[]{ "I"},"V"));
                code.visitLabel(L22);
                code.visitJumpStmt(GOTO,-1,-1,L16);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
