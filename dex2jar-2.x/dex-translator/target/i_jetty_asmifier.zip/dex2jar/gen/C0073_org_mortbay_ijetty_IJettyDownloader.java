package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0073_org_mortbay_ijetty_IJettyDownloader {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(ACC_PUBLIC,"Lorg/mortbay/ijetty/IJettyDownloader;","Landroid/app/Activity;",new String[]{ });
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("IJettyDownloader.java");
        f000___MSG_DOWNLOAD_FAILED(cv);
        f001___MSG_DOWNLOAD_SUCCEEDED(cv);
        f002___MSG_PROGRESS(cv);
        f003__progressBar(cv);
        f004_client(cv);
        f005_fileInProgress(cv);
        f006_mHandler(cv);
        f007_tmpDir(cv);
        m000__init_(cv);
        m001_access$000(cv);
        m002_access$102(cv);
        m003_access$200(cv);
        m004_doDownload(cv);
        m005_getWarFileName(cv);
        m006_install(cv);
        m007_onCreate(cv);
        m008_onPause(cv);
        m009_onStop(cv);
        m010_startDownload(cv);
    }
    public static void f000___MSG_DOWNLOAD_FAILED(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/ijetty/IJettyDownloader;","__MSG_DOWNLOAD_FAILED","I"),  Integer.valueOf(1));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f001___MSG_DOWNLOAD_SUCCEEDED(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/ijetty/IJettyDownloader;","__MSG_DOWNLOAD_SUCCEEDED","I"),  Integer.valueOf(0));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f002___MSG_PROGRESS(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/ijetty/IJettyDownloader;","__MSG_PROGRESS","I"),  Integer.valueOf(2));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f003__progressBar(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/ijetty/IJettyDownloader;","_progressBar","Landroid/widget/ProgressBar;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f004_client(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/ijetty/IJettyDownloader;","client","Lorg/mortbay/jetty/client/HttpClient;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f005_fileInProgress(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/ijetty/IJettyDownloader;","fileInProgress","Ljava/io/File;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f006_mHandler(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE|ACC_FINAL, new Field("Lorg/mortbay/ijetty/IJettyDownloader;","mHandler","Landroid/os/Handler;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f007_tmpDir(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/ijetty/IJettyDownloader;","tmpDir","Ljava/io/File;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void m000__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/ijetty/IJettyDownloader;","<init>",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(111,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(58,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(60,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(112,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(113,L4);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2},new Method("Landroid/app/Activity;","<init>",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT_OBJECT,0,2,new Field("Lorg/mortbay/ijetty/IJettyDownloader;","fileInProgress","Ljava/io/File;"));
                code.visitLabel(L2);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Lorg/mortbay/ijetty/IJettyDownloader$1;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,2},new Method("Lorg/mortbay/ijetty/IJettyDownloader$1;","<init>",new String[]{ "Lorg/mortbay/ijetty/IJettyDownloader;"},"V"));
                code.visitFieldStmt(IPUT_OBJECT,0,2,new Field("Lorg/mortbay/ijetty/IJettyDownloader;","mHandler","Landroid/os/Handler;"));
                code.visitLabel(L3);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/io/File;");
                code.visitConstStmt(CONST_STRING,1,"/sdcard/jetty/tmp");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1},new Method("Ljava/io/File;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitFieldStmt(IPUT_OBJECT,0,2,new Field("Lorg/mortbay/ijetty/IJettyDownloader;","tmpDir","Ljava/io/File;"));
                code.visitLabel(L4);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001_access$000(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_STATIC|ACC_SYNTHETIC, new Method("Lorg/mortbay/ijetty/IJettyDownloader;","access$000",new String[]{ "Lorg/mortbay/ijetty/IJettyDownloader;"},"Landroid/widget/ProgressBar;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"x0");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(48,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/ijetty/IJettyDownloader;","_progressBar","Landroid/widget/ProgressBar;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m002_access$102(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_STATIC|ACC_SYNTHETIC, new Method("Lorg/mortbay/ijetty/IJettyDownloader;","access$102",new String[]{ "Lorg/mortbay/ijetty/IJettyDownloader;","Ljava/io/File;"},"Ljava/io/File;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"x0");
                ddv.visitParameterName(1,"x1");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(48,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_OBJECT,1,0,new Field("Lorg/mortbay/ijetty/IJettyDownloader;","fileInProgress","Ljava/io/File;"));
                code.visitStmt1R(RETURN_OBJECT,1);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m003_access$200(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_STATIC|ACC_SYNTHETIC, new Method("Lorg/mortbay/ijetty/IJettyDownloader;","access$200",new String[]{ "Lorg/mortbay/ijetty/IJettyDownloader;"},"Landroid/os/Handler;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"x0");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(48,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/ijetty/IJettyDownloader;","mHandler","Landroid/os/Handler;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m004_doDownload(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/ijetty/IJettyDownloader;","doDownload",new String[]{ "Ljava/lang/String;","Ljava/io/File;","Ljava/lang/String;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(11);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ "Ljava/lang/Exception;"});
                DexLabel L3=new DexLabel();
                DexLabel L4=new DexLabel();
                DexLabel L5=new DexLabel();
                code.visitTryCatch(L3,L4,new DexLabel[]{L5},new String[]{ "Ljava/lang/Exception;"});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"url");
                ddv.visitParameterName(1,"warFile");
                ddv.visitParameterName(2,"path");
                DexLabel L6=new DexLabel();
                ddv.visitPrologue(L6);
                ddv.visitLineNumber(281,L0);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(283,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(284,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(285,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(286,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(289,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(290,L12);
                ddv.visitLineNumber(300,L1);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(301,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(302,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(303,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(304,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(306,L17);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(386,L18);
                ddv.visitStartLocal(1,L18,"exchange","Lorg/mortbay/jetty/client/ContentExchange;",null);
                ddv.visitLineNumber(389,L3);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(390,L19);
                ddv.visitLineNumber(396,L4);
                ddv.visitEndLocal(1,L4);
                ddv.visitLineNumber(292,L2);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(294,L20);
                ddv.visitStartLocal(0,L20,"e","Ljava/lang/Exception;",null);
                DexLabel L21=new DexLabel();
                ddv.visitLineNumber(295,L21);
                ddv.visitLineNumber(392,L5);
                ddv.visitEndLocal(0,L5);
                ddv.visitRestartLocal(1,L5);
                DexLabel L22=new DexLabel();
                ddv.visitLineNumber(394,L22);
                ddv.visitRestartLocal(0,L22);
                code.visitLabel(L6);
                code.visitConstStmt(CONST_4,5, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitConstStmt(CONST_4,4, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitConstStmt(CONST_STRING,6,"Jetty");
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,2,7,new Field("Lorg/mortbay/ijetty/IJettyDownloader;","client","Lorg/mortbay/jetty/client/HttpClient;"));
                code.visitJumpStmt(IF_NEZ,2,-1,L11);
                code.visitLabel(L7);
                code.visitTypeStmt(NEW_INSTANCE,2,-1,"Lorg/mortbay/jetty/client/HttpClient;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2},new Method("Lorg/mortbay/jetty/client/HttpClient;","<init>",new String[]{ },"V"));
                code.visitFieldStmt(IPUT_OBJECT,2,7,new Field("Lorg/mortbay/ijetty/IJettyDownloader;","client","Lorg/mortbay/jetty/client/HttpClient;"));
                code.visitLabel(L8);
                code.visitFieldStmt(IGET_OBJECT,2,7,new Field("Lorg/mortbay/ijetty/IJettyDownloader;","client","Lorg/mortbay/jetty/client/HttpClient;"));
                code.visitConstStmt(CONST_4,3, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3},new Method("Lorg/mortbay/jetty/client/HttpClient;","setConnectorType",new String[]{ "I"},"V"));
                code.visitLabel(L9);
                code.visitFieldStmt(IGET_OBJECT,2,7,new Field("Lorg/mortbay/ijetty/IJettyDownloader;","client","Lorg/mortbay/jetty/client/HttpClient;"));
                code.visitConstStmt(CONST_4,3, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3},new Method("Lorg/mortbay/jetty/client/HttpClient;","setMaxConnectionsPerAddress",new String[]{ "I"},"V"));
                code.visitLabel(L10);
                code.visitFieldStmt(IGET_OBJECT,2,7,new Field("Lorg/mortbay/ijetty/IJettyDownloader;","client","Lorg/mortbay/jetty/client/HttpClient;"));
                code.visitConstStmt(CONST_4,3, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3},new Method("Lorg/mortbay/jetty/client/HttpClient;","setUseDirectBuffers",new String[]{ "Z"},"V"));
                code.visitLabel(L11);
                code.visitFieldStmt(IGET_OBJECT,2,7,new Field("Lorg/mortbay/ijetty/IJettyDownloader;","client","Lorg/mortbay/jetty/client/HttpClient;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/jetty/client/HttpClient;","isRunning",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitJumpStmt(IF_NEZ,2,-1,L1);
                code.visitLabel(L12);
                code.visitFieldStmt(IGET_OBJECT,2,7,new Field("Lorg/mortbay/ijetty/IJettyDownloader;","client","Lorg/mortbay/jetty/client/HttpClient;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/jetty/client/HttpClient;","start",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitFieldStmt(IPUT_OBJECT,9,7,new Field("Lorg/mortbay/ijetty/IJettyDownloader;","fileInProgress","Ljava/io/File;"));
                code.visitLabel(L13);
                code.visitFieldStmt(IGET_OBJECT,2,7,new Field("Lorg/mortbay/ijetty/IJettyDownloader;","_progressBar","Landroid/widget/ProgressBar;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,4},new Method("Landroid/widget/ProgressBar;","setVisibility",new String[]{ "I"},"V"));
                code.visitLabel(L14);
                code.visitFieldStmt(IGET_OBJECT,2,7,new Field("Lorg/mortbay/ijetty/IJettyDownloader;","_progressBar","Landroid/widget/ProgressBar;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,4},new Method("Landroid/widget/ProgressBar;","setProgress",new String[]{ "I"},"V"));
                code.visitLabel(L15);
                code.visitFieldStmt(IGET_OBJECT,2,7,new Field("Lorg/mortbay/ijetty/IJettyDownloader;","_progressBar","Landroid/widget/ProgressBar;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,5},new Method("Landroid/widget/ProgressBar;","setIndeterminate",new String[]{ "Z"},"V"));
                code.visitLabel(L16);
                code.visitConstStmt(CONST,2, Integer.valueOf(2131165194)); // int: 0x7f07000a  float:179445982255059680000000000000000000000.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7,2},new Method("Lorg/mortbay/ijetty/IJettyDownloader;","findViewById",new String[]{ "I"},"Landroid/view/View;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitTypeStmt(CHECK_CAST,2,-1,"Landroid/widget/TextView;");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,4},new Method("Landroid/widget/TextView;","setVisibility",new String[]{ "I"},"V"));
                code.visitLabel(L17);
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Lorg/mortbay/ijetty/IJettyDownloader$6;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1,7,9,10,8},new Method("Lorg/mortbay/ijetty/IJettyDownloader$6;","<init>",new String[]{ "Lorg/mortbay/ijetty/IJettyDownloader;","Ljava/io/File;","Ljava/lang/String;","Ljava/lang/String;"},"V"));
                code.visitLabel(L18);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,8},new Method("Lorg/mortbay/jetty/client/ContentExchange;","setURL",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L3);
                code.visitConstStmt(CONST_STRING,2,"Jetty");
                code.visitTypeStmt(NEW_INSTANCE,3,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 3},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,4,"Downloading ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,4},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,8},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 2,3},new Method("Landroid/util/Log;","i",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"I"));
                code.visitLabel(L19);
                code.visitFieldStmt(IGET_OBJECT,2,7,new Field("Lorg/mortbay/ijetty/IJettyDownloader;","client","Lorg/mortbay/jetty/client/HttpClient;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,1},new Method("Lorg/mortbay/jetty/client/HttpClient;","send",new String[]{ "Lorg/mortbay/jetty/client/HttpExchange;"},"V"));
                code.visitLabel(L4);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,2);
                code.visitStmt2R(MOVE_OBJECT,0,2);
                code.visitLabel(L20);
                code.visitConstStmt(CONST_STRING,2,"Jetty");
                code.visitConstStmt(CONST_STRING,2,"Error starting client");
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 6,2,0},new Method("Landroid/util/Log;","e",new String[]{ "Ljava/lang/String;","Ljava/lang/String;","Ljava/lang/Throwable;"},"I"));
                code.visitLabel(L21);
                code.visitFieldStmt(IGET_OBJECT,2,7,new Field("Lorg/mortbay/ijetty/IJettyDownloader;","mHandler","Landroid/os/Handler;"));
                code.visitFieldStmt(IGET_OBJECT,3,7,new Field("Lorg/mortbay/ijetty/IJettyDownloader;","mHandler","Landroid/os/Handler;"));
                code.visitConstStmt(CONST_STRING,4,"Failed to start client");
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 3,5,4},new Method("Landroid/os/Message;","obtain",new String[]{ "Landroid/os/Handler;","I","Ljava/lang/Object;"},"Landroid/os/Message;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3},new Method("Landroid/os/Handler;","sendMessage",new String[]{ "Landroid/os/Message;"},"Z"));
                code.visitJumpStmt(GOTO,-1,-1,L4);
                code.visitLabel(L5);
                code.visitStmt1R(MOVE_EXCEPTION,2);
                code.visitStmt2R(MOVE_OBJECT,0,2);
                code.visitLabel(L22);
                code.visitConstStmt(CONST_STRING,2,"Jetty");
                code.visitTypeStmt(NEW_INSTANCE,2,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,3,"Download failed for ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,8},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 6,2},new Method("Landroid/util/Log;","e",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"I"));
                code.visitJumpStmt(GOTO,-1,-1,L4);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m005_getWarFileName(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/ijetty/IJettyDownloader;","getWarFileName",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(9);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ "Ljava/lang/Exception;"});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"url");
                DexLabel L3=new DexLabel();
                ddv.visitPrologue(L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(400,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(414,L5);
                ddv.visitLineNumber(405,L0);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(406,L6);
                ddv.visitStartLocal(0,L6,"dot","I",null);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(407,L7);
                ddv.visitStartLocal(2,L7,"war","Ljava/lang/String;",null);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(408,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(409,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(406,L10);
                ddv.visitEndLocal(2,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(408,L11);
                ddv.visitRestartLocal(2,L11);
                ddv.visitLineNumber(411,L2);
                ddv.visitEndLocal(0,L2);
                ddv.visitEndLocal(2,L2);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(413,L12);
                ddv.visitStartLocal(1,L12,"e","Ljava/lang/Exception;",null);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(414,L13);
                code.visitLabel(L3);
                code.visitConstStmt(CONST_4,6, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L4);
                code.visitJumpStmt(IF_NEZ,8,-1,L0);
                code.visitStmt2R(MOVE_OBJECT,3,6);
                code.visitLabel(L5);
                code.visitStmt1R(RETURN_OBJECT,3);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_STRING,3,"?");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8,3},new Method("Ljava/lang/String;","lastIndexOf",new String[]{ "Ljava/lang/String;"},"I"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitLabel(L6);
                code.visitJumpStmt(IF_GEZ,0,-1,L10);
                code.visitStmt2R(MOVE_OBJECT,2,8);
                code.visitLabel(L7);
                code.visitConstStmt(CONST_16,3, Integer.valueOf(47)); // int: 0x0000002f  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8,3},new Method("Ljava/lang/String;","lastIndexOf",new String[]{ "I"},"I"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitLabel(L8);
                code.visitJumpStmt(IF_GEZ,0,-1,L11);
                code.visitStmt2R(MOVE_OBJECT,2,8);
                DexLabel L14=new DexLabel();
                code.visitLabel(L14);
                code.visitStmt2R(MOVE_OBJECT,3,2);
                code.visitLabel(L9);
                code.visitJumpStmt(GOTO,-1,-1,L5);
                code.visitLabel(L10);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8,3,0},new Method("Ljava/lang/String;","substring",new String[]{ "I","I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitStmt2R(MOVE_OBJECT,2,3);
                code.visitJumpStmt(GOTO,-1,-1,L7);
                code.visitLabel(L11);
                code.visitStmt2R1N(ADD_INT_LIT8,3,0,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8,3},new Method("Ljava/lang/String;","substring",new String[]{ "I"},"Ljava/lang/String;"));
                code.visitLabel(L1);
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitStmt2R(MOVE_OBJECT,2,3);
                code.visitJumpStmt(GOTO,-1,-1,L14);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,3);
                code.visitStmt2R(MOVE_OBJECT,1,3);
                code.visitLabel(L12);
                code.visitConstStmt(CONST_STRING,3,"Jetty");
                code.visitTypeStmt(NEW_INSTANCE,4,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 4},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,5,"Bad url ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,5},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,8},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 3,4},new Method("Landroid/util/Log;","e",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"I"));
                code.visitStmt2R(MOVE_OBJECT,3,6);
                code.visitLabel(L13);
                code.visitJumpStmt(GOTO,-1,-1,L5);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m006_install(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/ijetty/IJettyDownloader;","install",new String[]{ "Ljava/io/File;","Ljava/lang/String;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(10);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ "Ljava/lang/Exception;"});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"file");
                ddv.visitParameterName(1,"path");
                DexLabel L3=new DexLabel();
                ddv.visitPrologue(L3);
                ddv.visitLineNumber(423,L0);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(424,L4);
                ddv.visitStartLocal(2,L4,"webappDir","Ljava/io/File;",null);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(425,L5);
                ddv.visitStartLocal(1,L5,"name","Ljava/lang/String;",null);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(426,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(428,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(429,L8);
                ddv.visitLineNumber(436,L1);
                ddv.visitEndLocal(2,L1);
                ddv.visitEndLocal(1,L1);
                ddv.visitLineNumber(431,L2);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(433,L9);
                ddv.visitStartLocal(0,L9,"e","Ljava/lang/Exception;",null);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(434,L10);
                code.visitLabel(L3);
                code.visitConstStmt(CONST_4,6, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitLabel(L0);
                code.visitTypeStmt(NEW_INSTANCE,2,-1,"Ljava/io/File;");
                code.visitConstStmt(CONST_STRING,3,"/sdcard/jetty/webapps");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2,3},new Method("Ljava/io/File;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8},new Method("Ljava/io/File;","getName",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L5);
                code.visitConstStmt(CONST_STRING,3,".war");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,3},new Method("Ljava/lang/String;","endsWith",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitJumpStmt(IF_NEZ,3,-1,L6);
                code.visitConstStmt(CONST_STRING,3,".jar");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,3},new Method("Ljava/lang/String;","endsWith",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitJumpStmt(IF_EQZ,3,-1,L7);
                code.visitLabel(L6);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/lang/String;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,4);
                code.visitConstStmt(CONST_4,5, Integer.valueOf(4)); // int: 0x00000004  float:0.000000
                code.visitStmt2R(SUB_INT_2ADDR,4,5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,3,4},new Method("Ljava/lang/String;","substring",new String[]{ "I","I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L7);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 8,9,2,1,3},new Method("Lorg/mortbay/ijetty/Installer;","install",new String[]{ "Ljava/io/File;","Ljava/lang/String;","Ljava/io/File;","Ljava/lang/String;","Z"},"V"));
                code.visitLabel(L8);
                code.visitFieldStmt(IGET_OBJECT,3,7,new Field("Lorg/mortbay/ijetty/IJettyDownloader;","mHandler","Landroid/os/Handler;"));
                code.visitFieldStmt(IGET_OBJECT,4,7,new Field("Lorg/mortbay/ijetty/IJettyDownloader;","mHandler","Landroid/os/Handler;"));
                code.visitConstStmt(CONST_4,5, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 4,5},new Method("Landroid/os/Message;","obtain",new String[]{ "Landroid/os/Handler;","I"},"Landroid/os/Message;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,4},new Method("Landroid/os/Handler;","sendMessage",new String[]{ "Landroid/os/Message;"},"Z"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,3);
                code.visitStmt2R(MOVE_OBJECT,0,3);
                code.visitLabel(L9);
                code.visitConstStmt(CONST_STRING,3,"Jetty");
                code.visitConstStmt(CONST_STRING,4,"Bad resource");
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 3,4,0},new Method("Landroid/util/Log;","e",new String[]{ "Ljava/lang/String;","Ljava/lang/String;","Ljava/lang/Throwable;"},"I"));
                code.visitLabel(L10);
                code.visitFieldStmt(IGET_OBJECT,3,7,new Field("Lorg/mortbay/ijetty/IJettyDownloader;","mHandler","Landroid/os/Handler;"));
                code.visitFieldStmt(IGET_OBJECT,4,7,new Field("Lorg/mortbay/ijetty/IJettyDownloader;","mHandler","Landroid/os/Handler;"));
                code.visitConstStmt(CONST_STRING,5,"Exception");
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 4,6,5},new Method("Landroid/os/Message;","obtain",new String[]{ "Landroid/os/Handler;","I","Ljava/lang/Object;"},"Landroid/os/Message;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,4},new Method("Landroid/os/Handler;","sendMessage",new String[]{ "Landroid/os/Message;"},"Z"));
                code.visitJumpStmt(GOTO,-1,-1,L1);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m007_onCreate(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Lorg/mortbay/ijetty/IJettyDownloader;","onCreate",new String[]{ "Landroid/os/Bundle;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"savedInstanceState");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(123,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(125,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(126,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(128,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(129,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(130,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(131,L6);
                ddv.visitStartLocal(0,L6,"startDownloadButton","Landroid/widget/Button;",null);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(149,L7);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_SUPER,new int[]{ 2,3},new Method("Landroid/app/Activity;","onCreate",new String[]{ "Landroid/os/Bundle;"},"V"));
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/ijetty/IJettyDownloader;","tmpDir","Ljava/io/File;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/io/File;","exists",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitJumpStmt(IF_NEZ,1,-1,L3);
                code.visitLabel(L2);
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/ijetty/IJettyDownloader;","tmpDir","Ljava/io/File;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/io/File;","mkdirs",new String[]{ },"Z"));
                code.visitLabel(L3);
                code.visitConstStmt(CONST,1, Integer.valueOf(2130903041)); // int: 0x7f030001  float:174128887730233600000000000000000000000.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,1},new Method("Lorg/mortbay/ijetty/IJettyDownloader;","setContentView",new String[]{ "I"},"V"));
                code.visitLabel(L4);
                code.visitConstStmt(CONST,1, Integer.valueOf(2131165193)); // int: 0x7f070009  float:179445961972650080000000000000000000000.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,1},new Method("Lorg/mortbay/ijetty/IJettyDownloader;","findViewById",new String[]{ "I"},"Landroid/view/View;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitTypeStmt(CHECK_CAST,1,-1,"Landroid/widget/ProgressBar;");
                code.visitFieldStmt(IPUT_OBJECT,1,2,new Field("Lorg/mortbay/ijetty/IJettyDownloader;","_progressBar","Landroid/widget/ProgressBar;"));
                code.visitLabel(L5);
                code.visitConstStmt(CONST,1, Integer.valueOf(2131165192)); // int: 0x7f070008  float:179445941690240470000000000000000000000.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,1},new Method("Lorg/mortbay/ijetty/IJettyDownloader;","findViewById",new String[]{ "I"},"Landroid/view/View;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitTypeStmt(CHECK_CAST,0,-1,"Landroid/widget/Button;");
                code.visitLabel(L6);
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Lorg/mortbay/ijetty/IJettyDownloader$2;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1,2},new Method("Lorg/mortbay/ijetty/IJettyDownloader$2;","<init>",new String[]{ "Lorg/mortbay/ijetty/IJettyDownloader;"},"V"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Landroid/widget/Button;","setOnClickListener",new String[]{ "Landroid/view/View$OnClickListener;"},"V"));
                code.visitLabel(L7);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m008_onPause(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Lorg/mortbay/ijetty/IJettyDownloader;","onPause",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(9);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                DexLabel L3=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2,L3},new String[]{ "Ljava/lang/Exception;",null});
                DexLabel L4=new DexLabel();
                DexLabel L5=new DexLabel();
                code.visitTryCatch(L4,L5,new DexLabel[]{L3},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L6=new DexLabel();
                ddv.visitPrologue(L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(160,L7);
                ddv.visitLineNumber(163,L0);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(165,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(166,L9);
                ddv.visitLineNumber(175,L1);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(176,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(178,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(179,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(180,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(181,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(184,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(185,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(186,L17);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(189,L18);
                ddv.visitLineNumber(169,L2);
                ddv.visitLineNumber(171,L4);
                ddv.visitStartLocal(0,L4,"e","Ljava/lang/Exception;",null);
                ddv.visitLineNumber(175,L5);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(176,L19);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(178,L20);
                DexLabel L21=new DexLabel();
                ddv.visitLineNumber(179,L21);
                DexLabel L22=new DexLabel();
                ddv.visitLineNumber(180,L22);
                DexLabel L23=new DexLabel();
                ddv.visitLineNumber(181,L23);
                DexLabel L24=new DexLabel();
                ddv.visitLineNumber(184,L24);
                DexLabel L25=new DexLabel();
                ddv.visitLineNumber(185,L25);
                ddv.visitLineNumber(175,L3);
                ddv.visitEndLocal(0,L3);
                DexLabel L26=new DexLabel();
                ddv.visitLineNumber(176,L26);
                DexLabel L27=new DexLabel();
                ddv.visitLineNumber(178,L27);
                DexLabel L28=new DexLabel();
                ddv.visitLineNumber(179,L28);
                DexLabel L29=new DexLabel();
                ddv.visitLineNumber(180,L29);
                DexLabel L30=new DexLabel();
                ddv.visitLineNumber(181,L30);
                DexLabel L31=new DexLabel();
                ddv.visitLineNumber(184,L31);
                DexLabel L32=new DexLabel();
                ddv.visitLineNumber(185,L32);
                DexLabel L33=new DexLabel();
                ddv.visitLineNumber(186,L33);
                DexLabel L34=new DexLabel();
                ddv.visitLineNumber(175,L34);
                code.visitLabel(L6);
                code.visitConstStmt(CONST,7, Integer.valueOf(2131165191)); // int: 0x7f070007  float:179445921407830870000000000000000000000.000000
                code.visitConstStmt(CONST,6, Integer.valueOf(2131165190)); // int: 0x7f070006  float:179445901125421260000000000000000000000.000000
                code.visitConstStmt(CONST_4,4, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitConstStmt(CONST_4,3, Integer.valueOf(4)); // int: 0x00000004  float:0.000000
                code.visitConstStmt(CONST_STRING,5,"");
                code.visitLabel(L7);
                code.visitMethodStmt(INVOKE_SUPER,new int[]{ 8},new Method("Landroid/app/Activity;","onPause",new String[]{ },"V"));
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,1,8,new Field("Lorg/mortbay/ijetty/IJettyDownloader;","client","Lorg/mortbay/jetty/client/HttpClient;"));
                code.visitJumpStmt(IF_EQZ,1,-1,L1);
                code.visitLabel(L8);
                code.visitFieldStmt(IGET_OBJECT,1,8,new Field("Lorg/mortbay/ijetty/IJettyDownloader;","client","Lorg/mortbay/jetty/client/HttpClient;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Lorg/mortbay/jetty/client/HttpClient;","stop",new String[]{ },"V"));
                code.visitLabel(L9);
                code.visitConstStmt(CONST_STRING,1,"Jetty");
                code.visitConstStmt(CONST_STRING,2,"Stopped httpclient");
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1,2},new Method("Landroid/util/Log;","i",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"I"));
                code.visitLabel(L1);
                code.visitFieldStmt(IPUT_OBJECT,4,8,new Field("Lorg/mortbay/ijetty/IJettyDownloader;","client","Lorg/mortbay/jetty/client/HttpClient;"));
                code.visitLabel(L10);
                code.visitFieldStmt(IGET_OBJECT,1,8,new Field("Lorg/mortbay/ijetty/IJettyDownloader;","fileInProgress","Ljava/io/File;"));
                code.visitJumpStmt(IF_EQZ,1,-1,L18);
                code.visitLabel(L11);
                code.visitFieldStmt(IGET_OBJECT,1,8,new Field("Lorg/mortbay/ijetty/IJettyDownloader;","_progressBar","Landroid/widget/ProgressBar;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,3},new Method("Landroid/widget/ProgressBar;","setVisibility",new String[]{ "I"},"V"));
                code.visitLabel(L12);
                code.visitConstStmt(CONST,1, Integer.valueOf(2131165194)); // int: 0x7f07000a  float:179445982255059680000000000000000000000.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8,1},new Method("Lorg/mortbay/ijetty/IJettyDownloader;","findViewById",new String[]{ "I"},"Landroid/view/View;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitTypeStmt(CHECK_CAST,1,-1,"Landroid/widget/TextView;");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,3},new Method("Landroid/widget/TextView;","setVisibility",new String[]{ "I"},"V"));
                code.visitLabel(L13);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8,6},new Method("Lorg/mortbay/ijetty/IJettyDownloader;","findViewById",new String[]{ "I"},"Landroid/view/View;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitTypeStmt(CHECK_CAST,1,-1,"Landroid/widget/EditText;");
                code.visitConstStmt(CONST_STRING,2,"");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,5},new Method("Landroid/widget/EditText;","setText",new String[]{ "Ljava/lang/CharSequence;"},"V"));
                code.visitLabel(L14);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8,7},new Method("Lorg/mortbay/ijetty/IJettyDownloader;","findViewById",new String[]{ "I"},"Landroid/view/View;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitTypeStmt(CHECK_CAST,1,-1,"Landroid/widget/EditText;");
                code.visitConstStmt(CONST_STRING,2,"");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,5},new Method("Landroid/widget/EditText;","setText",new String[]{ "Ljava/lang/CharSequence;"},"V"));
                code.visitLabel(L15);
                code.visitFieldStmt(IGET_OBJECT,1,8,new Field("Lorg/mortbay/ijetty/IJettyDownloader;","fileInProgress","Ljava/io/File;"));
                code.visitJumpStmt(IF_EQZ,1,-1,L17);
                code.visitLabel(L16);
                code.visitFieldStmt(IGET_OBJECT,1,8,new Field("Lorg/mortbay/ijetty/IJettyDownloader;","fileInProgress","Ljava/io/File;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1},new Method("Lorg/mortbay/ijetty/Installer;","clean",new String[]{ "Ljava/io/File;"},"V"));
                code.visitLabel(L17);
                code.visitFieldStmt(IPUT_OBJECT,4,8,new Field("Lorg/mortbay/ijetty/IJettyDownloader;","fileInProgress","Ljava/io/File;"));
                code.visitLabel(L18);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,1);
                code.visitStmt2R(MOVE_OBJECT,0,1);
                code.visitLabel(L4);
                code.visitConstStmt(CONST_STRING,1,"Jetty");
                code.visitConstStmt(CONST_STRING,2,"Error stopping httpclient ");
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1,2,0},new Method("Landroid/util/Log;","e",new String[]{ "Ljava/lang/String;","Ljava/lang/String;","Ljava/lang/Throwable;"},"I"));
                code.visitLabel(L5);
                code.visitFieldStmt(IPUT_OBJECT,4,8,new Field("Lorg/mortbay/ijetty/IJettyDownloader;","client","Lorg/mortbay/jetty/client/HttpClient;"));
                code.visitLabel(L19);
                code.visitFieldStmt(IGET_OBJECT,1,8,new Field("Lorg/mortbay/ijetty/IJettyDownloader;","fileInProgress","Ljava/io/File;"));
                code.visitJumpStmt(IF_EQZ,1,-1,L18);
                code.visitLabel(L20);
                code.visitFieldStmt(IGET_OBJECT,1,8,new Field("Lorg/mortbay/ijetty/IJettyDownloader;","_progressBar","Landroid/widget/ProgressBar;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,3},new Method("Landroid/widget/ProgressBar;","setVisibility",new String[]{ "I"},"V"));
                code.visitLabel(L21);
                code.visitConstStmt(CONST,1, Integer.valueOf(2131165194)); // int: 0x7f07000a  float:179445982255059680000000000000000000000.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8,1},new Method("Lorg/mortbay/ijetty/IJettyDownloader;","findViewById",new String[]{ "I"},"Landroid/view/View;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitTypeStmt(CHECK_CAST,1,-1,"Landroid/widget/TextView;");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,3},new Method("Landroid/widget/TextView;","setVisibility",new String[]{ "I"},"V"));
                code.visitLabel(L22);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8,6},new Method("Lorg/mortbay/ijetty/IJettyDownloader;","findViewById",new String[]{ "I"},"Landroid/view/View;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitTypeStmt(CHECK_CAST,1,-1,"Landroid/widget/EditText;");
                code.visitConstStmt(CONST_STRING,2,"");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,5},new Method("Landroid/widget/EditText;","setText",new String[]{ "Ljava/lang/CharSequence;"},"V"));
                code.visitLabel(L23);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8,7},new Method("Lorg/mortbay/ijetty/IJettyDownloader;","findViewById",new String[]{ "I"},"Landroid/view/View;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitTypeStmt(CHECK_CAST,1,-1,"Landroid/widget/EditText;");
                code.visitConstStmt(CONST_STRING,2,"");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,5},new Method("Landroid/widget/EditText;","setText",new String[]{ "Ljava/lang/CharSequence;"},"V"));
                code.visitLabel(L24);
                code.visitFieldStmt(IGET_OBJECT,1,8,new Field("Lorg/mortbay/ijetty/IJettyDownloader;","fileInProgress","Ljava/io/File;"));
                code.visitJumpStmt(IF_EQZ,1,-1,L17);
                code.visitLabel(L25);
                code.visitFieldStmt(IGET_OBJECT,1,8,new Field("Lorg/mortbay/ijetty/IJettyDownloader;","fileInProgress","Ljava/io/File;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1},new Method("Lorg/mortbay/ijetty/Installer;","clean",new String[]{ "Ljava/io/File;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L17);
                code.visitLabel(L3);
                code.visitStmt1R(MOVE_EXCEPTION,1);
                code.visitStmt2R(MOVE_OBJECT,2,1);
                code.visitFieldStmt(IPUT_OBJECT,4,8,new Field("Lorg/mortbay/ijetty/IJettyDownloader;","client","Lorg/mortbay/jetty/client/HttpClient;"));
                code.visitLabel(L26);
                code.visitFieldStmt(IGET_OBJECT,1,8,new Field("Lorg/mortbay/ijetty/IJettyDownloader;","fileInProgress","Ljava/io/File;"));
                code.visitJumpStmt(IF_EQZ,1,-1,L34);
                code.visitLabel(L27);
                code.visitFieldStmt(IGET_OBJECT,1,8,new Field("Lorg/mortbay/ijetty/IJettyDownloader;","_progressBar","Landroid/widget/ProgressBar;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,3},new Method("Landroid/widget/ProgressBar;","setVisibility",new String[]{ "I"},"V"));
                code.visitLabel(L28);
                code.visitConstStmt(CONST,1, Integer.valueOf(2131165194)); // int: 0x7f07000a  float:179445982255059680000000000000000000000.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8,1},new Method("Lorg/mortbay/ijetty/IJettyDownloader;","findViewById",new String[]{ "I"},"Landroid/view/View;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitTypeStmt(CHECK_CAST,1,-1,"Landroid/widget/TextView;");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,3},new Method("Landroid/widget/TextView;","setVisibility",new String[]{ "I"},"V"));
                code.visitLabel(L29);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8,6},new Method("Lorg/mortbay/ijetty/IJettyDownloader;","findViewById",new String[]{ "I"},"Landroid/view/View;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitTypeStmt(CHECK_CAST,1,-1,"Landroid/widget/EditText;");
                code.visitConstStmt(CONST_STRING,3,"");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,5},new Method("Landroid/widget/EditText;","setText",new String[]{ "Ljava/lang/CharSequence;"},"V"));
                code.visitLabel(L30);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8,7},new Method("Lorg/mortbay/ijetty/IJettyDownloader;","findViewById",new String[]{ "I"},"Landroid/view/View;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitTypeStmt(CHECK_CAST,1,-1,"Landroid/widget/EditText;");
                code.visitConstStmt(CONST_STRING,3,"");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,5},new Method("Landroid/widget/EditText;","setText",new String[]{ "Ljava/lang/CharSequence;"},"V"));
                code.visitLabel(L31);
                code.visitFieldStmt(IGET_OBJECT,1,8,new Field("Lorg/mortbay/ijetty/IJettyDownloader;","fileInProgress","Ljava/io/File;"));
                code.visitJumpStmt(IF_EQZ,1,-1,L33);
                code.visitLabel(L32);
                code.visitFieldStmt(IGET_OBJECT,1,8,new Field("Lorg/mortbay/ijetty/IJettyDownloader;","fileInProgress","Ljava/io/File;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1},new Method("Lorg/mortbay/ijetty/Installer;","clean",new String[]{ "Ljava/io/File;"},"V"));
                code.visitLabel(L33);
                code.visitFieldStmt(IPUT_OBJECT,4,8,new Field("Lorg/mortbay/ijetty/IJettyDownloader;","fileInProgress","Ljava/io/File;"));
                code.visitLabel(L34);
                code.visitStmt1R(THROW,2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m009_onStop(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Lorg/mortbay/ijetty/IJettyDownloader;","onStop",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                DexLabel L3=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2,L3},new String[]{ "Ljava/lang/Exception;",null});
                DexLabel L4=new DexLabel();
                DexLabel L5=new DexLabel();
                code.visitTryCatch(L4,L5,new DexLabel[]{L3},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L6=new DexLabel();
                ddv.visitPrologue(L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(201,L7);
                ddv.visitLineNumber(204,L0);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(206,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(207,L9);
                ddv.visitLineNumber(216,L1);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(217,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(219,L11);
                ddv.visitLineNumber(210,L2);
                ddv.visitLineNumber(212,L4);
                ddv.visitStartLocal(0,L4,"e","Ljava/lang/Exception;",null);
                ddv.visitLineNumber(216,L5);
                ddv.visitEndLocal(0,L3);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(217,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(216,L13);
                code.visitLabel(L6);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitConstStmt(CONST_STRING,1,"Jetty");
                code.visitLabel(L7);
                code.visitMethodStmt(INVOKE_SUPER,new int[]{ 4},new Method("Landroid/app/Activity;","onStop",new String[]{ },"V"));
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,1,4,new Field("Lorg/mortbay/ijetty/IJettyDownloader;","client","Lorg/mortbay/jetty/client/HttpClient;"));
                code.visitJumpStmt(IF_EQZ,1,-1,L1);
                code.visitLabel(L8);
                code.visitFieldStmt(IGET_OBJECT,1,4,new Field("Lorg/mortbay/ijetty/IJettyDownloader;","client","Lorg/mortbay/jetty/client/HttpClient;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Lorg/mortbay/jetty/client/HttpClient;","stop",new String[]{ },"V"));
                code.visitLabel(L9);
                code.visitConstStmt(CONST_STRING,1,"Jetty");
                code.visitConstStmt(CONST_STRING,2,"Stopped httpclient");
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1,2},new Method("Landroid/util/Log;","i",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"I"));
                code.visitLabel(L1);
                code.visitFieldStmt(IPUT_OBJECT,3,4,new Field("Lorg/mortbay/ijetty/IJettyDownloader;","client","Lorg/mortbay/jetty/client/HttpClient;"));
                code.visitLabel(L10);
                code.visitFieldStmt(IPUT_OBJECT,3,4,new Field("Lorg/mortbay/ijetty/IJettyDownloader;","fileInProgress","Ljava/io/File;"));
                code.visitLabel(L11);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,1);
                code.visitStmt2R(MOVE_OBJECT,0,1);
                code.visitLabel(L4);
                code.visitConstStmt(CONST_STRING,1,"Jetty");
                code.visitConstStmt(CONST_STRING,2,"Error stopping httpclient ");
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1,2,0},new Method("Landroid/util/Log;","e",new String[]{ "Ljava/lang/String;","Ljava/lang/String;","Ljava/lang/Throwable;"},"I"));
                code.visitLabel(L5);
                code.visitFieldStmt(IPUT_OBJECT,3,4,new Field("Lorg/mortbay/ijetty/IJettyDownloader;","client","Lorg/mortbay/jetty/client/HttpClient;"));
                code.visitJumpStmt(GOTO,-1,-1,L10);
                code.visitLabel(L3);
                code.visitStmt1R(MOVE_EXCEPTION,1);
                code.visitFieldStmt(IPUT_OBJECT,3,4,new Field("Lorg/mortbay/ijetty/IJettyDownloader;","client","Lorg/mortbay/jetty/client/HttpClient;"));
                code.visitLabel(L12);
                code.visitFieldStmt(IPUT_OBJECT,3,4,new Field("Lorg/mortbay/ijetty/IJettyDownloader;","fileInProgress","Ljava/io/File;"));
                code.visitLabel(L13);
                code.visitStmt1R(THROW,1);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m010_startDownload(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/ijetty/IJettyDownloader;","startDownload",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(11);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ "Ljava/lang/Exception;"});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"url");
                ddv.visitParameterName(1,"path");
                DexLabel L3=new DexLabel();
                ddv.visitPrologue(L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(227,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(228,L5);
                ddv.visitStartLocal(2,L5,"war","Ljava/lang/String;",null);
                ddv.visitLineNumber(231,L0);
                ddv.visitStartLocal(3,L0,"warFile","Ljava/io/File;",null);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(233,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(234,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(235,L8);
                ddv.visitStartLocal(0,L8,"builder","Landroid/app/AlertDialog$Builder;",null);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(236,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(237,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(239,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(246,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(252,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(258,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(268,L15);
                ddv.visitEndLocal(0,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(261,L16);
                ddv.visitLineNumber(263,L2);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(265,L17);
                ddv.visitStartLocal(1,L17,"e","Ljava/lang/Exception;",null);
                code.visitLabel(L3);
                code.visitConstStmt(CONST_STRING,7,"Jetty");
                code.visitLabel(L4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8,9},new Method("Lorg/mortbay/ijetty/IJettyDownloader;","getWarFileName",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitLabel(L5);
                code.visitTypeStmt(NEW_INSTANCE,3,-1,"Ljava/io/File;");
                code.visitFieldStmt(IGET_OBJECT,4,8,new Field("Lorg/mortbay/ijetty/IJettyDownloader;","tmpDir","Ljava/io/File;"));
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 3,4,2},new Method("Ljava/io/File;","<init>",new String[]{ "Ljava/io/File;","Ljava/lang/String;"},"V"));
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Ljava/io/File;","createNewFile",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,4);
                code.visitJumpStmt(IF_NEZ,4,-1,L16);
                code.visitLabel(L6);
                code.visitConstStmt(CONST_STRING,4,"Jetty");
                code.visitTypeStmt(NEW_INSTANCE,5,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 5},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,2},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitConstStmt(CONST_STRING,6,": File exists");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,6},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 4,5},new Method("Landroid/util/Log;","i",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"I"));
                code.visitLabel(L7);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Landroid/app/AlertDialog$Builder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,8},new Method("Landroid/app/AlertDialog$Builder;","<init>",new String[]{ "Landroid/content/Context;"},"V"));
                code.visitLabel(L8);
                code.visitConstStmt(CONST_4,4, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,4},new Method("Landroid/app/AlertDialog$Builder;","setCancelable",new String[]{ "Z"},"Landroid/app/AlertDialog$Builder;"));
                code.visitLabel(L9);
                code.visitConstStmt(CONST,4, Integer.valueOf(2131099684)); // int: 0x7f060024  float:178117281601924460000000000000000000000.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,4},new Method("Landroid/app/AlertDialog$Builder;","setMessage",new String[]{ "I"},"Landroid/app/AlertDialog$Builder;"));
                code.visitLabel(L10);
                code.visitConstStmt(CONST,4, Integer.valueOf(2131099677)); // int: 0x7f06001d  float:178117139625057230000000000000000000000.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,4},new Method("Landroid/app/AlertDialog$Builder;","setTitle",new String[]{ "I"},"Landroid/app/AlertDialog$Builder;"));
                code.visitLabel(L11);
                code.visitConstStmt(CONST,4, Integer.valueOf(2131099682)); // int: 0x7f060022  float:178117241037105250000000000000000000000.000000
                code.visitTypeStmt(NEW_INSTANCE,5,-1,"Lorg/mortbay/ijetty/IJettyDownloader$3;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 5,8,3,9,10},new Method("Lorg/mortbay/ijetty/IJettyDownloader$3;","<init>",new String[]{ "Lorg/mortbay/ijetty/IJettyDownloader;","Ljava/io/File;","Ljava/lang/String;","Ljava/lang/String;"},"V"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,4,5},new Method("Landroid/app/AlertDialog$Builder;","setPositiveButton",new String[]{ "I","Landroid/content/DialogInterface$OnClickListener;"},"Landroid/app/AlertDialog$Builder;"));
                code.visitLabel(L12);
                code.visitConstStmt(CONST,4, Integer.valueOf(2131099683)); // int: 0x7f060023  float:178117261319514850000000000000000000000.000000
                code.visitTypeStmt(NEW_INSTANCE,5,-1,"Lorg/mortbay/ijetty/IJettyDownloader$4;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 5,8},new Method("Lorg/mortbay/ijetty/IJettyDownloader$4;","<init>",new String[]{ "Lorg/mortbay/ijetty/IJettyDownloader;"},"V"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,4,5},new Method("Landroid/app/AlertDialog$Builder;","setNegativeButton",new String[]{ "I","Landroid/content/DialogInterface$OnClickListener;"},"Landroid/app/AlertDialog$Builder;"));
                code.visitLabel(L13);
                code.visitTypeStmt(NEW_INSTANCE,4,-1,"Lorg/mortbay/ijetty/IJettyDownloader$5;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 4,8},new Method("Lorg/mortbay/ijetty/IJettyDownloader$5;","<init>",new String[]{ "Lorg/mortbay/ijetty/IJettyDownloader;"},"V"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,4},new Method("Landroid/app/AlertDialog$Builder;","setOnCancelListener",new String[]{ "Landroid/content/DialogInterface$OnCancelListener;"},"Landroid/app/AlertDialog$Builder;"));
                code.visitLabel(L14);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Landroid/app/AlertDialog$Builder;","show",new String[]{ },"Landroid/app/AlertDialog;"));
                code.visitLabel(L15);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L16);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8,9,3,10},new Method("Lorg/mortbay/ijetty/IJettyDownloader;","doDownload",new String[]{ "Ljava/lang/String;","Ljava/io/File;","Ljava/lang/String;"},"V"));
                code.visitLabel(L1);
                code.visitJumpStmt(GOTO,-1,-1,L15);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,4);
                code.visitStmt2R(MOVE_OBJECT,1,4);
                code.visitLabel(L17);
                code.visitConstStmt(CONST_STRING,4,"Jetty");
                code.visitTypeStmt(NEW_INSTANCE,4,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 4},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,5,"Error creating file ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,5},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,2},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 7,4,1},new Method("Landroid/util/Log;","e",new String[]{ "Ljava/lang/String;","Ljava/lang/String;","Ljava/lang/Throwable;"},"I"));
                code.visitJumpStmt(GOTO,-1,-1,L15);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
