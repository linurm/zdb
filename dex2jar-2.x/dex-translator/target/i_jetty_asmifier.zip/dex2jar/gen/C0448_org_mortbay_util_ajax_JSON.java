package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0448_org_mortbay_util_ajax_JSON {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(ACC_PUBLIC,"Lorg/mortbay/util/ajax/JSON;","Ljava/lang/Object;",new String[]{ });
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("JSON.java");
        if(cv!=null){
            DexAnnotationVisitor av00 = cv.visitAnnotation("Ldalvik/annotation/MemberClasses;", Visibility.SYSTEM);
            if(av00 != null) {
                {
                    DexAnnotationVisitor av01 = av00.visitArray("value");
                    if(av01 != null) {
                        av01.visit(null, new DexType("Lorg/mortbay/util/ajax/JSON$Literal;"));
                        av01.visit(null, new DexType("Lorg/mortbay/util/ajax/JSON$Generator;"));
                        av01.visit(null, new DexType("Lorg/mortbay/util/ajax/JSON$Convertor;"));
                        av01.visit(null, new DexType("Lorg/mortbay/util/ajax/JSON$Convertible;"));
                        av01.visit(null, new DexType("Lorg/mortbay/util/ajax/JSON$Output;"));
                        av01.visit(null, new DexType("Lorg/mortbay/util/ajax/JSON$ReaderSource;"));
                        av01.visit(null, new DexType("Lorg/mortbay/util/ajax/JSON$StringSource;"));
                        av01.visit(null, new DexType("Lorg/mortbay/util/ajax/JSON$Source;"));
                        av01.visitEnd();
                    }
                }
                av00.visitEnd();
            }
        }
        f000___default(cv);
        f001__convertors(cv);
        f002__stringBufferSize(cv);
        m000__clinit_(cv);
        m001__init_(cv);
        m002_complete(cv);
        m003_getDefault(cv);
        m004_parse(cv);
        m005_parse(cv);
        m006_parse(cv);
        m007_parse(cv);
        m008_parse(cv);
        m009_parse(cv);
        m010_registerConvertor(cv);
        m011_setDefault(cv);
        m012_toString(cv);
        m013_toString(cv);
        m014_toString(cv);
        m015_addConvertor(cv);
        m016_append(cv);
        m017_appendArray(cv);
        m018_appendArray(cv);
        m019_appendBoolean(cv);
        m020_appendJSON(cv);
        m021_appendJSON(cv);
        m022_appendJSON(cv);
        m023_appendMap(cv);
        m024_appendNull(cv);
        m025_appendNumber(cv);
        m026_appendString(cv);
        m027_contextFor(cv);
        m028_contextForArray(cv);
        m029_convertTo(cv);
        m030_fromJSON(cv);
        m031_getConvertor(cv);
        m032_getStringBufferSize(cv);
        m033_handleUnknown(cv);
        m034_newArray(cv);
        m035_newMap(cv);
        m036_parse(cv);
        m037_parse(cv);
        m038_parseArray(cv);
        m039_parseNumber(cv);
        m040_parseObject(cv);
        m041_parseString(cv);
        m042_seekTo(cv);
        m043_seekTo(cv);
        m044_setStringBufferSize(cv);
        m045_toJSON(cv);
        m046_toString(cv);
    }
    public static void f000___default(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE|ACC_STATIC, new Field("Lorg/mortbay/util/ajax/JSON;","__default","Lorg/mortbay/util/ajax/JSON;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f001__convertors(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/util/ajax/JSON;","_convertors","Ljava/util/Map;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f002__stringBufferSize(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/util/ajax/JSON;","_stringBufferSize","I"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void m000__clinit_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_STATIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/util/ajax/JSON;","<clinit>",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(1);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(75,L0);
                code.visitLabel(L0);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Lorg/mortbay/util/ajax/JSON;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Lorg/mortbay/util/ajax/JSON;","<init>",new String[]{ },"V"));
                code.visitFieldStmt(SPUT_OBJECT,0,-1,new Field("Lorg/mortbay/util/ajax/JSON;","__default","Lorg/mortbay/util/ajax/JSON;"));
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/util/ajax/JSON;","<init>",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(82,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(77,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(78,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(83,L3);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1},new Method("Ljava/lang/Object;","<init>",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/util/HashMap;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/util/HashMap;","<init>",new String[]{ },"V"));
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/util/ajax/JSON;","_convertors","Ljava/util/Map;"));
                code.visitLabel(L2);
                code.visitConstStmt(CONST_16,0, Integer.valueOf(256)); // int: 0x00000100  float:0.000000
                code.visitFieldStmt(IPUT,0,1,new Field("Lorg/mortbay/util/ajax/JSON;","_stringBufferSize","I"));
                code.visitLabel(L3);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m002_complete(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED|ACC_STATIC, new Method("Lorg/mortbay/util/ajax/JSON;","complete",new String[]{ "Ljava/lang/String;","Lorg/mortbay/util/ajax/JSON$Source;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(9);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"seek");
                ddv.visitParameterName(1,"source");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(1152,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(1153,L2);
                ddv.visitStartLocal(1,L2,"i","I",null);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(1155,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(1156,L4);
                ddv.visitStartLocal(0,L4,"c","C",null);
                DexLabel L5=new DexLabel();
                ddv.visitStartLocal(2,L5,"i","I",null);
                DexLabel L6=new DexLabel();
                ddv.visitEndLocal(1,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(1157,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(1158,L8);
                ddv.visitRestartLocal(1,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(1160,L9);
                ddv.visitEndLocal(0,L9);
                ddv.visitEndLocal(2,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(1161,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(1162,L11);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_STRING,6,"\"");
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L2);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 8},new Method("Lorg/mortbay/util/ajax/JSON$Source;","hasNext",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitJumpStmt(IF_EQZ,3,-1,L9);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7},new Method("Ljava/lang/String;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitJumpStmt(IF_GE,1,3,L9);
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 8},new Method("Lorg/mortbay/util/ajax/JSON$Source;","next",new String[]{ },"C"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitLabel(L4);
                code.visitStmt2R1N(ADD_INT_LIT8,2,1,1);
                code.visitLabel(L5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7,1},new Method("Ljava/lang/String;","charAt",new String[]{ "I"},"C"));
                code.visitLabel(L6);
                code.visitStmt1R(MOVE_RESULT,3);
                DexLabel L12=new DexLabel();
                code.visitJumpStmt(IF_EQ,0,3,L12);
                code.visitLabel(L7);
                code.visitTypeStmt(NEW_INSTANCE,3,-1,"Ljava/lang/IllegalStateException;");
                code.visitTypeStmt(NEW_INSTANCE,4,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 4},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,5,"Unexpected \'");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,5},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,0},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "C"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitConstStmt(CONST_STRING,5," while seeking  \"");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,5},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,7},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitConstStmt(CONST_STRING,5,"\"");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,6},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 3,4},new Method("Ljava/lang/IllegalStateException;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitStmt1R(THROW,3);
                code.visitLabel(L12);
                code.visitStmt2R(MOVE,1,2);
                code.visitLabel(L8);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitLabel(L9);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7},new Method("Ljava/lang/String;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitJumpStmt(IF_GE,1,3,L11);
                code.visitLabel(L10);
                code.visitTypeStmt(NEW_INSTANCE,3,-1,"Ljava/lang/IllegalStateException;");
                code.visitTypeStmt(NEW_INSTANCE,4,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 4},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,5,"Expected \"");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,5},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,7},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitConstStmt(CONST_STRING,5,"\"");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,6},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 3,4},new Method("Ljava/lang/IllegalStateException;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitStmt1R(THROW,3);
                code.visitLabel(L11);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m003_getDefault(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Lorg/mortbay/util/ajax/JSON;","getDefault",new String[]{ },"Lorg/mortbay/util/ajax/JSON;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(1);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(120,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(SGET_OBJECT,0,-1,new Field("Lorg/mortbay/util/ajax/JSON;","__default","Lorg/mortbay/util/ajax/JSON;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m004_parse(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Lorg/mortbay/util/ajax/JSON;","parse",new String[]{ "Ljava/io/InputStream;"},"Ljava/lang/Object;"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"in");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(203,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(SGET_OBJECT,0,-1,new Field("Lorg/mortbay/util/ajax/JSON;","__default","Lorg/mortbay/util/ajax/JSON;"));
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Lorg/mortbay/util/ajax/JSON$StringSource;");
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 3},new Method("Lorg/mortbay/util/IO;","toString",new String[]{ "Ljava/io/InputStream;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1,2},new Method("Lorg/mortbay/util/ajax/JSON$StringSource;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1,2},new Method("Lorg/mortbay/util/ajax/JSON;","parse",new String[]{ "Lorg/mortbay/util/ajax/JSON$Source;","Z"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m005_parse(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Lorg/mortbay/util/ajax/JSON;","parse",new String[]{ "Ljava/io/InputStream;","Z"},"Ljava/lang/Object;"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"in");
                ddv.visitParameterName(1,"stripOuterComment");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(214,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(SGET_OBJECT,0,-1,new Field("Lorg/mortbay/util/ajax/JSON;","__default","Lorg/mortbay/util/ajax/JSON;"));
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Lorg/mortbay/util/ajax/JSON$StringSource;");
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 3},new Method("Lorg/mortbay/util/IO;","toString",new String[]{ "Ljava/io/InputStream;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1,2},new Method("Lorg/mortbay/util/ajax/JSON$StringSource;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1,4},new Method("Lorg/mortbay/util/ajax/JSON;","parse",new String[]{ "Lorg/mortbay/util/ajax/JSON$Source;","Z"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m006_parse(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Lorg/mortbay/util/ajax/JSON;","parse",new String[]{ "Ljava/io/Reader;"},"Ljava/lang/Object;"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"in");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(183,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(SGET_OBJECT,0,-1,new Field("Lorg/mortbay/util/ajax/JSON;","__default","Lorg/mortbay/util/ajax/JSON;"));
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Lorg/mortbay/util/ajax/JSON$ReaderSource;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1,3},new Method("Lorg/mortbay/util/ajax/JSON$ReaderSource;","<init>",new String[]{ "Ljava/io/Reader;"},"V"));
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1,2},new Method("Lorg/mortbay/util/ajax/JSON;","parse",new String[]{ "Lorg/mortbay/util/ajax/JSON$Source;","Z"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m007_parse(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Lorg/mortbay/util/ajax/JSON;","parse",new String[]{ "Ljava/io/Reader;","Z"},"Ljava/lang/Object;"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"in");
                ddv.visitParameterName(1,"stripOuterComment");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(193,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(SGET_OBJECT,0,-1,new Field("Lorg/mortbay/util/ajax/JSON;","__default","Lorg/mortbay/util/ajax/JSON;"));
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Lorg/mortbay/util/ajax/JSON$ReaderSource;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1,2},new Method("Lorg/mortbay/util/ajax/JSON$ReaderSource;","<init>",new String[]{ "Ljava/io/Reader;"},"V"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1,3},new Method("Lorg/mortbay/util/ajax/JSON;","parse",new String[]{ "Lorg/mortbay/util/ajax/JSON$Source;","Z"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m008_parse(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Lorg/mortbay/util/ajax/JSON;","parse",new String[]{ "Ljava/lang/String;"},"Ljava/lang/Object;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"s");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(164,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(SGET_OBJECT,0,-1,new Field("Lorg/mortbay/util/ajax/JSON;","__default","Lorg/mortbay/util/ajax/JSON;"));
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Lorg/mortbay/util/ajax/JSON$StringSource;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1,3},new Method("Lorg/mortbay/util/ajax/JSON$StringSource;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1,2},new Method("Lorg/mortbay/util/ajax/JSON;","parse",new String[]{ "Lorg/mortbay/util/ajax/JSON$Source;","Z"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m009_parse(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Lorg/mortbay/util/ajax/JSON;","parse",new String[]{ "Ljava/lang/String;","Z"},"Ljava/lang/Object;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"s");
                ddv.visitParameterName(1,"stripOuterComment");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(174,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(SGET_OBJECT,0,-1,new Field("Lorg/mortbay/util/ajax/JSON;","__default","Lorg/mortbay/util/ajax/JSON;"));
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Lorg/mortbay/util/ajax/JSON$StringSource;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1,2},new Method("Lorg/mortbay/util/ajax/JSON$StringSource;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1,3},new Method("Lorg/mortbay/util/ajax/JSON;","parse",new String[]{ "Lorg/mortbay/util/ajax/JSON$Source;","Z"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m010_registerConvertor(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Lorg/mortbay/util/ajax/JSON;","registerConvertor",new String[]{ "Ljava/lang/Class;","Lorg/mortbay/util/ajax/JSON$Convertor;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"forClass");
                ddv.visitParameterName(1,"convertor");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(115,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(116,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(SGET_OBJECT,0,-1,new Field("Lorg/mortbay/util/ajax/JSON;","__default","Lorg/mortbay/util/ajax/JSON;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1,2},new Method("Lorg/mortbay/util/ajax/JSON;","addConvertor",new String[]{ "Ljava/lang/Class;","Lorg/mortbay/util/ajax/JSON$Convertor;"},"V"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m011_setDefault(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Lorg/mortbay/util/ajax/JSON;","setDefault",new String[]{ "Lorg/mortbay/util/ajax/JSON;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(1);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"json");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(125,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(126,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(SPUT_OBJECT,0,-1,new Field("Lorg/mortbay/util/ajax/JSON;","__default","Lorg/mortbay/util/ajax/JSON;"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m012_toString(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Lorg/mortbay/util/ajax/JSON;","toString",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"object");
                DexLabel L3=new DexLabel();
                ddv.visitPrologue(L3);
                ddv.visitLineNumber(130,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(131,L4);
                ddv.visitStartLocal(0,L4,"buffer","Ljava/lang/StringBuffer;",null);
                ddv.visitLineNumber(133,L0);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(134,L5);
                ddv.visitLineNumber(135,L2);
                code.visitLabel(L3);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/lang/StringBuffer;");
                code.visitFieldStmt(SGET_OBJECT,1,-1,new Field("Lorg/mortbay/util/ajax/JSON;","__default","Lorg/mortbay/util/ajax/JSON;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Lorg/mortbay/util/ajax/JSON;","getStringBufferSize",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1},new Method("Ljava/lang/StringBuffer;","<init>",new String[]{ "I"},"V"));
                code.visitLabel(L4);
                code.visitStmt1R(MONITOR_ENTER,0);
                code.visitLabel(L0);
                code.visitFieldStmt(SGET_OBJECT,1,-1,new Field("Lorg/mortbay/util/ajax/JSON;","__default","Lorg/mortbay/util/ajax/JSON;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,0,2},new Method("Lorg/mortbay/util/ajax/JSON;","append",new String[]{ "Ljava/lang/StringBuffer;","Ljava/lang/Object;"},"V"));
                code.visitLabel(L5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/lang/StringBuffer;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitStmt1R(MONITOR_EXIT,0);
                code.visitStmt1R(RETURN_OBJECT,1);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,1);
                code.visitStmt1R(MONITOR_EXIT,0);
                code.visitLabel(L1);
                code.visitStmt1R(THROW,1);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m013_toString(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Lorg/mortbay/util/ajax/JSON;","toString",new String[]{ "Ljava/util/Map;"},"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"object");
                DexLabel L3=new DexLabel();
                ddv.visitPrologue(L3);
                ddv.visitLineNumber(140,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(141,L4);
                ddv.visitStartLocal(0,L4,"buffer","Ljava/lang/StringBuffer;",null);
                ddv.visitLineNumber(143,L0);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(144,L5);
                ddv.visitLineNumber(145,L2);
                code.visitLabel(L3);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/lang/StringBuffer;");
                code.visitFieldStmt(SGET_OBJECT,1,-1,new Field("Lorg/mortbay/util/ajax/JSON;","__default","Lorg/mortbay/util/ajax/JSON;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Lorg/mortbay/util/ajax/JSON;","getStringBufferSize",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1},new Method("Ljava/lang/StringBuffer;","<init>",new String[]{ "I"},"V"));
                code.visitLabel(L4);
                code.visitStmt1R(MONITOR_ENTER,0);
                code.visitLabel(L0);
                code.visitFieldStmt(SGET_OBJECT,1,-1,new Field("Lorg/mortbay/util/ajax/JSON;","__default","Lorg/mortbay/util/ajax/JSON;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,0,2},new Method("Lorg/mortbay/util/ajax/JSON;","appendMap",new String[]{ "Ljava/lang/StringBuffer;","Ljava/util/Map;"},"V"));
                code.visitLabel(L5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/lang/StringBuffer;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitStmt1R(MONITOR_EXIT,0);
                code.visitStmt1R(RETURN_OBJECT,1);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,1);
                code.visitStmt1R(MONITOR_EXIT,0);
                code.visitLabel(L1);
                code.visitStmt1R(THROW,1);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m014_toString(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Lorg/mortbay/util/ajax/JSON;","toString",new String[]{ "[Ljava/lang/Object;"},"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"array");
                DexLabel L3=new DexLabel();
                ddv.visitPrologue(L3);
                ddv.visitLineNumber(150,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(151,L4);
                ddv.visitStartLocal(0,L4,"buffer","Ljava/lang/StringBuffer;",null);
                ddv.visitLineNumber(153,L0);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(154,L5);
                ddv.visitLineNumber(155,L2);
                code.visitLabel(L3);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/lang/StringBuffer;");
                code.visitFieldStmt(SGET_OBJECT,1,-1,new Field("Lorg/mortbay/util/ajax/JSON;","__default","Lorg/mortbay/util/ajax/JSON;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Lorg/mortbay/util/ajax/JSON;","getStringBufferSize",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1},new Method("Ljava/lang/StringBuffer;","<init>",new String[]{ "I"},"V"));
                code.visitLabel(L4);
                code.visitStmt1R(MONITOR_ENTER,0);
                code.visitLabel(L0);
                code.visitFieldStmt(SGET_OBJECT,1,-1,new Field("Lorg/mortbay/util/ajax/JSON;","__default","Lorg/mortbay/util/ajax/JSON;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,0,2},new Method("Lorg/mortbay/util/ajax/JSON;","appendArray",new String[]{ "Ljava/lang/StringBuffer;","Ljava/lang/Object;"},"V"));
                code.visitLabel(L5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/lang/StringBuffer;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitStmt1R(MONITOR_EXIT,0);
                code.visitStmt1R(RETURN_OBJECT,1);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,1);
                code.visitStmt1R(MONITOR_EXIT,0);
                code.visitLabel(L1);
                code.visitStmt1R(THROW,1);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m015_addConvertor(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/util/ajax/JSON;","addConvertor",new String[]{ "Ljava/lang/Class;","Lorg/mortbay/util/ajax/JSON$Convertor;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"forClass");
                ddv.visitParameterName(1,"convertor");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(541,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(542,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/util/ajax/JSON;","_convertors","Ljava/util/Map;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,2,3},new Method("Ljava/util/Map;","put",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m016_append(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/util/ajax/JSON;","append",new String[]{ "Ljava/lang/StringBuffer;","Ljava/lang/Object;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"buffer");
                ddv.visitParameterName(1,"object");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(250,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(251,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(276,L2);
                ddv.visitEndLocal(4,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(252,L3);
                ddv.visitRestartLocal(4,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(253,L4);
                DexLabel L5=new DexLabel();
                ddv.visitEndLocal(4,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(254,L6);
                ddv.visitRestartLocal(4,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(255,L7);
                DexLabel L8=new DexLabel();
                ddv.visitEndLocal(4,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(256,L9);
                ddv.visitRestartLocal(4,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(257,L10);
                DexLabel L11=new DexLabel();
                ddv.visitEndLocal(4,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(258,L12);
                ddv.visitRestartLocal(4,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(259,L13);
                DexLabel L14=new DexLabel();
                ddv.visitEndLocal(4,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(260,L15);
                ddv.visitRestartLocal(4,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(261,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(262,L17);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(263,L18);
                DexLabel L19=new DexLabel();
                ddv.visitEndLocal(4,L19);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(264,L20);
                ddv.visitRestartLocal(4,L20);
                DexLabel L21=new DexLabel();
                ddv.visitLineNumber(265,L21);
                DexLabel L22=new DexLabel();
                ddv.visitEndLocal(4,L22);
                DexLabel L23=new DexLabel();
                ddv.visitLineNumber(266,L23);
                ddv.visitRestartLocal(4,L23);
                DexLabel L24=new DexLabel();
                ddv.visitLineNumber(267,L24);
                DexLabel L25=new DexLabel();
                ddv.visitEndLocal(4,L25);
                DexLabel L26=new DexLabel();
                ddv.visitLineNumber(270,L26);
                ddv.visitRestartLocal(4,L26);
                DexLabel L27=new DexLabel();
                ddv.visitLineNumber(271,L27);
                ddv.visitStartLocal(0,L27,"convertor","Lorg/mortbay/util/ajax/JSON$Convertor;",null);
                DexLabel L28=new DexLabel();
                ddv.visitLineNumber(272,L28);
                DexLabel L29=new DexLabel();
                ddv.visitLineNumber(274,L29);
                code.visitLabel(L0);
                code.visitJumpStmt(IF_NEZ,4,-1,L3);
                code.visitLabel(L1);
                code.visitConstStmt(CONST_STRING,1,"null");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,1},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L2);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L3);
                code.visitTypeStmt(INSTANCE_OF,1,4,"Lorg/mortbay/util/ajax/JSON$Convertible;");
                code.visitJumpStmt(IF_EQZ,1,-1,L6);
                code.visitLabel(L4);
                code.visitTypeStmt(CHECK_CAST,4,-1,"Lorg/mortbay/util/ajax/JSON$Convertible;");
                code.visitLabel(L5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3,4},new Method("Lorg/mortbay/util/ajax/JSON;","appendJSON",new String[]{ "Ljava/lang/StringBuffer;","Lorg/mortbay/util/ajax/JSON$Convertible;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitLabel(L6);
                code.visitTypeStmt(INSTANCE_OF,1,4,"Lorg/mortbay/util/ajax/JSON$Generator;");
                code.visitJumpStmt(IF_EQZ,1,-1,L9);
                code.visitLabel(L7);
                code.visitTypeStmt(CHECK_CAST,4,-1,"Lorg/mortbay/util/ajax/JSON$Generator;");
                code.visitLabel(L8);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3,4},new Method("Lorg/mortbay/util/ajax/JSON;","appendJSON",new String[]{ "Ljava/lang/StringBuffer;","Lorg/mortbay/util/ajax/JSON$Generator;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitLabel(L9);
                code.visitTypeStmt(INSTANCE_OF,1,4,"Ljava/util/Map;");
                code.visitJumpStmt(IF_EQZ,1,-1,L12);
                code.visitLabel(L10);
                code.visitTypeStmt(CHECK_CAST,4,-1,"Ljava/util/Map;");
                code.visitLabel(L11);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3,4},new Method("Lorg/mortbay/util/ajax/JSON;","appendMap",new String[]{ "Ljava/lang/StringBuffer;","Ljava/util/Map;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitLabel(L12);
                code.visitTypeStmt(INSTANCE_OF,1,4,"Ljava/util/Collection;");
                code.visitJumpStmt(IF_EQZ,1,-1,L15);
                code.visitLabel(L13);
                code.visitTypeStmt(CHECK_CAST,4,-1,"Ljava/util/Collection;");
                code.visitLabel(L14);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3,4},new Method("Lorg/mortbay/util/ajax/JSON;","appendArray",new String[]{ "Ljava/lang/StringBuffer;","Ljava/util/Collection;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitLabel(L15);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Ljava/lang/Object;","getClass",new String[]{ },"Ljava/lang/Class;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/lang/Class;","isArray",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitJumpStmt(IF_EQZ,1,-1,L17);
                code.visitLabel(L16);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3,4},new Method("Lorg/mortbay/util/ajax/JSON;","appendArray",new String[]{ "Ljava/lang/StringBuffer;","Ljava/lang/Object;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitLabel(L17);
                code.visitTypeStmt(INSTANCE_OF,1,4,"Ljava/lang/Number;");
                code.visitJumpStmt(IF_EQZ,1,-1,L20);
                code.visitLabel(L18);
                code.visitTypeStmt(CHECK_CAST,4,-1,"Ljava/lang/Number;");
                code.visitLabel(L19);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3,4},new Method("Lorg/mortbay/util/ajax/JSON;","appendNumber",new String[]{ "Ljava/lang/StringBuffer;","Ljava/lang/Number;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitLabel(L20);
                code.visitTypeStmt(INSTANCE_OF,1,4,"Ljava/lang/Boolean;");
                code.visitJumpStmt(IF_EQZ,1,-1,L23);
                code.visitLabel(L21);
                code.visitTypeStmt(CHECK_CAST,4,-1,"Ljava/lang/Boolean;");
                code.visitLabel(L22);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3,4},new Method("Lorg/mortbay/util/ajax/JSON;","appendBoolean",new String[]{ "Ljava/lang/StringBuffer;","Ljava/lang/Boolean;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitLabel(L23);
                code.visitTypeStmt(INSTANCE_OF,1,4,"Ljava/lang/String;");
                code.visitJumpStmt(IF_EQZ,1,-1,L26);
                code.visitLabel(L24);
                code.visitTypeStmt(CHECK_CAST,4,-1,"Ljava/lang/String;");
                code.visitLabel(L25);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3,4},new Method("Lorg/mortbay/util/ajax/JSON;","appendString",new String[]{ "Ljava/lang/StringBuffer;","Ljava/lang/String;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitLabel(L26);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Ljava/lang/Object;","getClass",new String[]{ },"Ljava/lang/Class;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,1},new Method("Lorg/mortbay/util/ajax/JSON;","getConvertor",new String[]{ "Ljava/lang/Class;"},"Lorg/mortbay/util/ajax/JSON$Convertor;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L27);
                code.visitJumpStmt(IF_EQZ,0,-1,L29);
                code.visitLabel(L28);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3,0,4},new Method("Lorg/mortbay/util/ajax/JSON;","appendJSON",new String[]{ "Ljava/lang/StringBuffer;","Lorg/mortbay/util/ajax/JSON$Convertor;","Ljava/lang/Object;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitLabel(L29);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Ljava/lang/Object;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3,1},new Method("Lorg/mortbay/util/ajax/JSON;","appendString",new String[]{ "Ljava/lang/StringBuffer;","Ljava/lang/String;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m017_appendArray(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/util/ajax/JSON;","appendArray",new String[]{ "Ljava/lang/StringBuffer;","Ljava/lang/Object;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(6);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"buffer");
                ddv.visitParameterName(1,"array");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(426,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(428,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(443,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(432,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(433,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(435,L5);
                ddv.visitStartLocal(1,L5,"length","I",null);
                DexLabel L6=new DexLabel();
                ddv.visitStartLocal(0,L6,"i","I",null);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(437,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(438,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(439,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(435,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(442,L11);
                code.visitLabel(L0);
                code.visitJumpStmt(IF_NEZ,5,-1,L3);
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,4},new Method("Lorg/mortbay/util/ajax/JSON;","appendNull",new String[]{ "Ljava/lang/StringBuffer;"},"V"));
                code.visitLabel(L2);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L3);
                code.visitConstStmt(CONST_16,2, Integer.valueOf(91)); // int: 0x0000005b  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,2},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "C"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L4);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 5},new Method("Ljava/lang/reflect/Array;","getLength",new String[]{ "Ljava/lang/Object;"},"I"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitLabel(L5);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L6);
                code.visitJumpStmt(IF_GE,0,1,L11);
                code.visitLabel(L7);
                code.visitJumpStmt(IF_EQZ,0,-1,L9);
                code.visitLabel(L8);
                code.visitConstStmt(CONST_16,2, Integer.valueOf(44)); // int: 0x0000002c  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,2},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "C"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L9);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 5,0},new Method("Ljava/lang/reflect/Array;","get",new String[]{ "Ljava/lang/Object;","I"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,4,2},new Method("Lorg/mortbay/util/ajax/JSON;","append",new String[]{ "Ljava/lang/StringBuffer;","Ljava/lang/Object;"},"V"));
                code.visitLabel(L10);
                code.visitStmt2R1N(ADD_INT_LIT8,0,0,1);
                code.visitJumpStmt(GOTO,-1,-1,L6);
                code.visitLabel(L11);
                code.visitConstStmt(CONST_16,2, Integer.valueOf(93)); // int: 0x0000005d  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,2},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "C"},"Ljava/lang/StringBuffer;"));
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m018_appendArray(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/util/ajax/JSON;","appendArray",new String[]{ "Ljava/lang/StringBuffer;","Ljava/util/Collection;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(6);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"buffer");
                ddv.visitParameterName(1,"collection");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(403,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(405,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(422,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(409,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(410,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(411,L5);
                ddv.visitStartLocal(1,L5,"iter","Ljava/util/Iterator;",null);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(412,L6);
                ddv.visitStartLocal(0,L6,"first","Z",null);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(414,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(415,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(417,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(418,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(421,L11);
                code.visitLabel(L0);
                code.visitJumpStmt(IF_NEZ,5,-1,L3);
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,4},new Method("Lorg/mortbay/util/ajax/JSON;","appendNull",new String[]{ "Ljava/lang/StringBuffer;"},"V"));
                code.visitLabel(L2);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L3);
                code.visitConstStmt(CONST_16,2, Integer.valueOf(91)); // int: 0x0000005b  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,2},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "C"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L4);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 5},new Method("Ljava/util/Collection;","iterator",new String[]{ },"Ljava/util/Iterator;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L5);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitLabel(L6);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 1},new Method("Ljava/util/Iterator;","hasNext",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitJumpStmt(IF_EQZ,2,-1,L11);
                code.visitLabel(L7);
                code.visitJumpStmt(IF_NEZ,0,-1,L9);
                code.visitLabel(L8);
                code.visitConstStmt(CONST_16,2, Integer.valueOf(44)); // int: 0x0000002c  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,2},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "C"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L9);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L10);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 1},new Method("Ljava/util/Iterator;","next",new String[]{ },"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,4,2},new Method("Lorg/mortbay/util/ajax/JSON;","append",new String[]{ "Ljava/lang/StringBuffer;","Ljava/lang/Object;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L6);
                code.visitLabel(L11);
                code.visitConstStmt(CONST_16,2, Integer.valueOf(93)); // int: 0x0000005d  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,2},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "C"},"Ljava/lang/StringBuffer;"));
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m019_appendBoolean(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/util/ajax/JSON;","appendBoolean",new String[]{ "Ljava/lang/StringBuffer;","Ljava/lang/Boolean;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"buffer");
                ddv.visitParameterName(1,"b");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(447,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(449,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(453,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(452,L3);
                code.visitLabel(L0);
                code.visitJumpStmt(IF_NEZ,3,-1,L3);
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2},new Method("Lorg/mortbay/util/ajax/JSON;","appendNull",new String[]{ "Ljava/lang/StringBuffer;"},"V"));
                code.visitLabel(L2);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Ljava/lang/Boolean;","booleanValue",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                DexLabel L4=new DexLabel();
                code.visitJumpStmt(IF_EQZ,0,-1,L4);
                code.visitConstStmt(CONST_STRING,0,"true");
                DexLabel L5=new DexLabel();
                code.visitLabel(L5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,0},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuffer;"));
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitLabel(L4);
                code.visitConstStmt(CONST_STRING,0,"false");
                code.visitJumpStmt(GOTO,-1,-1,L5);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m020_appendJSON(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/util/ajax/JSON;","appendJSON",new String[]{ "Ljava/lang/StringBuffer;","Lorg/mortbay/util/ajax/JSON$Convertible;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(7);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"buffer");
                ddv.visitParameterName(1,"converter");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(300,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(302,L2);
                ddv.visitStartLocal(0,L2,"c","[C",null);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(367,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(368,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(371,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(369,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(370,L7);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_16,3, Integer.valueOf(123)); // int: 0x0000007b  float:0.000000
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitTypeStmt(NEW_ARRAY,0,1,"[C");
                code.visitStmt3R(APUT_CHAR,3,0,2);
                code.visitLabel(L2);
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Lorg/mortbay/util/ajax/JSON$2;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1,4,0,5},new Method("Lorg/mortbay/util/ajax/JSON$2;","<init>",new String[]{ "Lorg/mortbay/util/ajax/JSON;","[C","Ljava/lang/StringBuffer;"},"V"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 6,1},new Method("Lorg/mortbay/util/ajax/JSON$Convertible;","toJSON",new String[]{ "Lorg/mortbay/util/ajax/JSON$Output;"},"V"));
                code.visitLabel(L3);
                code.visitStmt3R(AGET_CHAR,1,0,2);
                code.visitJumpStmt(IF_NE,1,3,L6);
                code.visitLabel(L4);
                code.visitConstStmt(CONST_STRING,1,"{}");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,1},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L5);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L6);
                code.visitStmt3R(AGET_CHAR,1,0,2);
                code.visitJumpStmt(IF_EQZ,1,-1,L5);
                code.visitLabel(L7);
                code.visitConstStmt(CONST_STRING,1,"}");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,1},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuffer;"));
                code.visitJumpStmt(GOTO,-1,-1,L5);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m021_appendJSON(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/util/ajax/JSON;","appendJSON",new String[]{ "Ljava/lang/StringBuffer;","Lorg/mortbay/util/ajax/JSON$Convertor;","Ljava/lang/Object;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"buffer");
                ddv.visitParameterName(1,"convertor");
                ddv.visitParameterName(2,"object");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(285,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(296,L1);
                code.visitLabel(L0);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Lorg/mortbay/util/ajax/JSON$1;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1,3,4},new Method("Lorg/mortbay/util/ajax/JSON$1;","<init>",new String[]{ "Lorg/mortbay/util/ajax/JSON;","Lorg/mortbay/util/ajax/JSON$Convertor;","Ljava/lang/Object;"},"V"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2,0},new Method("Lorg/mortbay/util/ajax/JSON;","appendJSON",new String[]{ "Ljava/lang/StringBuffer;","Lorg/mortbay/util/ajax/JSON$Convertible;"},"V"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m022_appendJSON(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/util/ajax/JSON;","appendJSON",new String[]{ "Ljava/lang/StringBuffer;","Lorg/mortbay/util/ajax/JSON$Generator;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"buffer");
                ddv.visitParameterName(1,"generator");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(375,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(376,L1);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 2,1},new Method("Lorg/mortbay/util/ajax/JSON$Generator;","addJSON",new String[]{ "Ljava/lang/StringBuffer;"},"V"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m023_appendMap(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/util/ajax/JSON;","appendMap",new String[]{ "Ljava/lang/StringBuffer;","Ljava/util/Map;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(6);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"buffer");
                ddv.visitParameterName(1,"object");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(380,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(382,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(399,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(386,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(387,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(388,L5);
                ddv.visitStartLocal(1,L5,"iter","Ljava/util/Iterator;",null);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(390,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(391,L7);
                ddv.visitStartLocal(0,L7,"entry","Ljava/util/Map$Entry;",null);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(392,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(393,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(394,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(395,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(398,L12);
                ddv.visitEndLocal(0,L12);
                code.visitLabel(L0);
                code.visitJumpStmt(IF_NEZ,5,-1,L3);
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,4},new Method("Lorg/mortbay/util/ajax/JSON;","appendNull",new String[]{ "Ljava/lang/StringBuffer;"},"V"));
                code.visitLabel(L2);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L3);
                code.visitConstStmt(CONST_16,2, Integer.valueOf(123)); // int: 0x0000007b  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,2},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "C"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L4);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 5},new Method("Ljava/util/Map;","entrySet",new String[]{ },"Ljava/util/Set;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 2},new Method("Ljava/util/Set;","iterator",new String[]{ },"Ljava/util/Iterator;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L5);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 1},new Method("Ljava/util/Iterator;","hasNext",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitJumpStmt(IF_EQZ,2,-1,L12);
                code.visitLabel(L6);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 1},new Method("Ljava/util/Iterator;","next",new String[]{ },"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitTypeStmt(CHECK_CAST,0,-1,"Ljava/util/Map$Entry;");
                code.visitLabel(L7);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0},new Method("Ljava/util/Map$Entry;","getKey",new String[]{ },"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Ljava/lang/Object;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 4,2},new Method("Lorg/mortbay/util/QuotedStringTokenizer;","quote",new String[]{ "Ljava/lang/StringBuffer;","Ljava/lang/String;"},"V"));
                code.visitLabel(L8);
                code.visitConstStmt(CONST_16,2, Integer.valueOf(58)); // int: 0x0000003a  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,2},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "C"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L9);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0},new Method("Ljava/util/Map$Entry;","getValue",new String[]{ },"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,4,2},new Method("Lorg/mortbay/util/ajax/JSON;","append",new String[]{ "Ljava/lang/StringBuffer;","Ljava/lang/Object;"},"V"));
                code.visitLabel(L10);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 1},new Method("Ljava/util/Iterator;","hasNext",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitJumpStmt(IF_EQZ,2,-1,L5);
                code.visitLabel(L11);
                code.visitConstStmt(CONST_16,2, Integer.valueOf(44)); // int: 0x0000002c  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,2},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "C"},"Ljava/lang/StringBuffer;"));
                code.visitJumpStmt(GOTO,-1,-1,L5);
                code.visitLabel(L12);
                code.visitConstStmt(CONST_16,2, Integer.valueOf(125)); // int: 0x0000007d  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,2},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "C"},"Ljava/lang/StringBuffer;"));
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m024_appendNull(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/util/ajax/JSON;","appendNull",new String[]{ "Ljava/lang/StringBuffer;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"buffer");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(280,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(281,L1);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_STRING,0,"null");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,0},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m025_appendNumber(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/util/ajax/JSON;","appendNumber",new String[]{ "Ljava/lang/StringBuffer;","Ljava/lang/Number;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"buffer");
                ddv.visitParameterName(1,"number");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(457,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(459,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(463,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(462,L3);
                code.visitLabel(L0);
                code.visitJumpStmt(IF_NEZ,2,-1,L3);
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Lorg/mortbay/util/ajax/JSON;","appendNull",new String[]{ "Ljava/lang/StringBuffer;"},"V"));
                code.visitLabel(L2);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/StringBuffer;"));
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m026_appendString(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/util/ajax/JSON;","appendString",new String[]{ "Ljava/lang/StringBuffer;","Ljava/lang/String;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"buffer");
                ddv.visitParameterName(1,"string");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(467,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(469,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(474,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(473,L3);
                code.visitLabel(L0);
                code.visitJumpStmt(IF_NEZ,2,-1,L3);
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Lorg/mortbay/util/ajax/JSON;","appendNull",new String[]{ "Ljava/lang/StringBuffer;"},"V"));
                code.visitLabel(L2);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1,2},new Method("Lorg/mortbay/util/QuotedStringTokenizer;","quote",new String[]{ "Ljava/lang/StringBuffer;","Ljava/lang/String;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m027_contextFor(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Lorg/mortbay/util/ajax/JSON;","contextFor",new String[]{ "Ljava/lang/String;"},"Lorg/mortbay/util/ajax/JSON;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"field");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(506,L0);
                code.visitLabel(L0);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m028_contextForArray(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Lorg/mortbay/util/ajax/JSON;","contextForArray",new String[]{ },"Lorg/mortbay/util/ajax/JSON;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(1);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(501,L0);
                code.visitLabel(L0);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m029_convertTo(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Lorg/mortbay/util/ajax/JSON;","convertTo",new String[]{ "Ljava/lang/Class;","Ljava/util/Map;"},"Ljava/lang/Object;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(7);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ "Ljava/lang/Exception;"});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"type");
                ddv.visitParameterName(1,"map");
                DexLabel L3=new DexLabel();
                ddv.visitPrologue(L3);
                ddv.visitLineNumber(511,L3);
                ddv.visitLineNumber(515,L0);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(516,L4);
                ddv.visitStartLocal(0,L4,"conv","Lorg/mortbay/util/ajax/JSON$Convertible;",null);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(530,L5);
                ddv.visitEndLocal(0,L5);
                ddv.visitLineNumber(519,L2);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(521,L6);
                ddv.visitStartLocal(2,L6,"e","Ljava/lang/Exception;",null);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(525,L7);
                ddv.visitEndLocal(2,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(526,L8);
                ddv.visitStartLocal(1,L8,"convertor","Lorg/mortbay/util/ajax/JSON$Convertor;",null);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(528,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(530,L10);
                code.visitLabel(L3);
                code.visitJumpStmt(IF_EQZ,5,-1,L7);
                code.visitConstStmt(CONST_CLASS,3,new DexType("Lorg/mortbay/util/ajax/JSON$Convertible;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,5},new Method("Ljava/lang/Class;","isAssignableFrom",new String[]{ "Ljava/lang/Class;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitJumpStmt(IF_EQZ,3,-1,L7);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Ljava/lang/Class;","newInstance",new String[]{ },"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitTypeStmt(CHECK_CAST,0,-1,"Lorg/mortbay/util/ajax/JSON$Convertible;");
                code.visitLabel(L4);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,6},new Method("Lorg/mortbay/util/ajax/JSON$Convertible;","fromJSON",new String[]{ "Ljava/util/Map;"},"V"));
                code.visitLabel(L1);
                code.visitStmt2R(MOVE_OBJECT,3,0);
                code.visitLabel(L5);
                code.visitStmt1R(RETURN_OBJECT,3);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,3);
                code.visitStmt2R(MOVE_OBJECT,2,3);
                code.visitLabel(L6);
                code.visitTypeStmt(NEW_INSTANCE,3,-1,"Ljava/lang/RuntimeException;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 3,2},new Method("Ljava/lang/RuntimeException;","<init>",new String[]{ "Ljava/lang/Throwable;"},"V"));
                code.visitStmt1R(THROW,3);
                code.visitLabel(L7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,5},new Method("Lorg/mortbay/util/ajax/JSON;","getConvertor",new String[]{ "Ljava/lang/Class;"},"Lorg/mortbay/util/ajax/JSON$Convertor;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L8);
                DexLabel L11=new DexLabel();
                code.visitJumpStmt(IF_EQZ,1,-1,L11);
                code.visitLabel(L9);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 1,6},new Method("Lorg/mortbay/util/ajax/JSON$Convertor;","fromJSON",new String[]{ "Ljava/util/Map;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitJumpStmt(GOTO,-1,-1,L5);
                code.visitLabel(L11);
                code.visitStmt2R(MOVE_OBJECT,3,6);
                code.visitLabel(L10);
                code.visitJumpStmt(GOTO,-1,-1,L5);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m030_fromJSON(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/util/ajax/JSON;","fromJSON",new String[]{ "Ljava/lang/String;"},"Ljava/lang/Object;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"json");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(239,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(240,L1);
                ddv.visitStartLocal(0,L1,"source","Lorg/mortbay/util/ajax/JSON$Source;",null);
                code.visitLabel(L0);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Lorg/mortbay/util/ajax/JSON$StringSource;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,3},new Method("Lorg/mortbay/util/ajax/JSON$StringSource;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,0},new Method("Lorg/mortbay/util/ajax/JSON;","parse",new String[]{ "Lorg/mortbay/util/ajax/JSON$Source;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitStmt1R(RETURN_OBJECT,1);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m031_getConvertor(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Lorg/mortbay/util/ajax/JSON;","getConvertor",new String[]{ "Ljava/lang/Class;"},"Lorg/mortbay/util/ajax/JSON$Convertor;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(9);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"forClass");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(554,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(555,L1);
                ddv.visitStartLocal(0,L1,"c","Ljava/lang/Class;",null);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(556,L2);
                ddv.visitStartLocal(1,L2,"convertor","Lorg/mortbay/util/ajax/JSON$Convertor;",null);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(557,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(559,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(561,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(562,L6);
                ddv.visitStartLocal(4,L6,"ifs","[Ljava/lang/Class;",null);
                DexLabel L7=new DexLabel();
                ddv.visitStartLocal(2,L7,"i","I",null);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(563,L8);
                ddv.visitEndLocal(2,L8);
                ddv.visitStartLocal(3,L8,"i","I",null);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(564,L9);
                DexLabel L10=new DexLabel();
                ddv.visitRestartLocal(2,L10);
                DexLabel L11=new DexLabel();
                ddv.visitEndLocal(3,L11);
                DexLabel L12=new DexLabel();
                ddv.visitEndLocal(1,L12);
                DexLabel L13=new DexLabel();
                ddv.visitRestartLocal(1,L13);
                DexLabel L14=new DexLabel();
                ddv.visitRestartLocal(3,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(565,L15);
                ddv.visitEndLocal(2,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(567,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(568,L17);
                DexLabel L18=new DexLabel();
                ddv.visitEndLocal(1,L18);
                DexLabel L19=new DexLabel();
                ddv.visitRestartLocal(1,L19);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(571,L20);
                ddv.visitEndLocal(4,L20);
                ddv.visitEndLocal(3,L20);
                code.visitLabel(L0);
                code.visitStmt2R(MOVE_OBJECT,0,8);
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,5,7,new Field("Lorg/mortbay/util/ajax/JSON;","_convertors","Ljava/util/Map;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 5,0},new Method("Ljava/util/Map;","get",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitTypeStmt(CHECK_CAST,1,-1,"Lorg/mortbay/util/ajax/JSON$Convertor;");
                code.visitLabel(L2);
                code.visitJumpStmt(IF_NEZ,1,-1,L4);
                code.visitFieldStmt(SGET_OBJECT,5,-1,new Field("Lorg/mortbay/util/ajax/JSON;","__default","Lorg/mortbay/util/ajax/JSON;"));
                code.visitJumpStmt(IF_EQ,7,5,L4);
                code.visitLabel(L3);
                code.visitFieldStmt(SGET_OBJECT,5,-1,new Field("Lorg/mortbay/util/ajax/JSON;","__default","Lorg/mortbay/util/ajax/JSON;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,8},new Method("Lorg/mortbay/util/ajax/JSON;","getConvertor",new String[]{ "Ljava/lang/Class;"},"Lorg/mortbay/util/ajax/JSON$Convertor;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L4);
                code.visitJumpStmt(IF_NEZ,1,-1,L20);
                code.visitJumpStmt(IF_EQZ,0,-1,L20);
                code.visitConstStmt(CONST_CLASS,5,new DexType("Ljava/lang/Object;"));
                code.visitJumpStmt(IF_EQ,0,5,L20);
                code.visitLabel(L5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/lang/Class;","getInterfaces",new String[]{ },"[Ljava/lang/Class;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitLabel(L6);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L7);
                code.visitStmt2R(MOVE,3,2);
                code.visitLabel(L8);
                code.visitJumpStmt(IF_NEZ,1,-1,L15);
                code.visitJumpStmt(IF_EQZ,4,-1,L15);
                code.visitStmt2R(ARRAY_LENGTH,5,4);
                code.visitJumpStmt(IF_GE,3,5,L15);
                code.visitLabel(L9);
                code.visitFieldStmt(IGET_OBJECT,5,7,new Field("Lorg/mortbay/util/ajax/JSON;","_convertors","Ljava/util/Map;"));
                code.visitStmt2R1N(ADD_INT_LIT8,2,3,1);
                code.visitLabel(L10);
                code.visitStmt3R(AGET_OBJECT,6,4,3);
                code.visitLabel(L11);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 5,6},new Method("Ljava/util/Map;","get",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L12);
                code.visitTypeStmt(CHECK_CAST,1,-1,"Lorg/mortbay/util/ajax/JSON$Convertor;");
                code.visitLabel(L13);
                code.visitStmt2R(MOVE,3,2);
                code.visitLabel(L14);
                code.visitJumpStmt(GOTO,-1,-1,L8);
                code.visitLabel(L15);
                code.visitJumpStmt(IF_NEZ,1,-1,L4);
                code.visitLabel(L16);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/lang/Class;","getSuperclass",new String[]{ },"Ljava/lang/Class;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L17);
                code.visitFieldStmt(IGET_OBJECT,5,7,new Field("Lorg/mortbay/util/ajax/JSON;","_convertors","Ljava/util/Map;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 5,0},new Method("Ljava/util/Map;","get",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L18);
                code.visitTypeStmt(CHECK_CAST,1,-1,"Lorg/mortbay/util/ajax/JSON$Convertor;");
                code.visitLabel(L19);
                code.visitJumpStmt(GOTO,-1,-1,L4);
                code.visitLabel(L20);
                code.visitStmt1R(RETURN_OBJECT,1);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m032_getStringBufferSize(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/util/ajax/JSON;","getStringBufferSize",new String[]{ },"I"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(91,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET,0,1,new Field("Lorg/mortbay/util/ajax/JSON;","_stringBufferSize","I"));
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m033_handleUnknown(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Lorg/mortbay/util/ajax/JSON;","handleUnknown",new String[]{ "Lorg/mortbay/util/ajax/JSON$Source;","C"},"Ljava/lang/Object;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(6);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"source");
                ddv.visitParameterName(1,"c");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(762,L0);
                code.visitLabel(L0);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/lang/IllegalStateException;");
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,2,"unknown char \'");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,5},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "C"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitConstStmt(CONST_STRING,2,"\'(");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,5},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "I"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitConstStmt(CONST_STRING,2,") in ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,4},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1},new Method("Ljava/lang/IllegalStateException;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitStmt1R(THROW,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m034_newArray(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Lorg/mortbay/util/ajax/JSON;","newArray",new String[]{ "I"},"[Ljava/lang/Object;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"size");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(496,L0);
                code.visitLabel(L0);
                code.visitTypeStmt(NEW_ARRAY,0,2,"[Ljava/lang/Object;");
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m035_newMap(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Lorg/mortbay/util/ajax/JSON;","newMap",new String[]{ },"Ljava/util/Map;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(491,L0);
                code.visitLabel(L0);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/util/HashMap;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/util/HashMap;","<init>",new String[]{ },"V"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m036_parse(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/util/ajax/JSON;","parse",new String[]{ "Lorg/mortbay/util/ajax/JSON$Source;"},"Ljava/lang/Object;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(7);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"source");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(666,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(668,L2);
                ddv.visitStartLocal(1,L2,"comment_state","I",null);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(670,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(673,L4);
                ddv.visitStartLocal(0,L4,"c","C",null);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(675,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(754,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(678,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(679,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(681,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(685,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(687,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(699,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(690,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(691,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(693,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(694,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(696,L17);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(697,L18);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(703,L19);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(705,L20);
                DexLabel L21=new DexLabel();
                ddv.visitLineNumber(709,L21);
                DexLabel L22=new DexLabel();
                ddv.visitLineNumber(710,L22);
                DexLabel L23=new DexLabel();
                ddv.visitLineNumber(718,L23);
                DexLabel L24=new DexLabel();
                ddv.visitLineNumber(747,L24);
                DexLabel L25=new DexLabel();
                ddv.visitLineNumber(748,L25);
                DexLabel L26=new DexLabel();
                ddv.visitLineNumber(757,L26);
                ddv.visitEndLocal(0,L26);
                DexLabel L27=new DexLabel();
                ddv.visitLineNumber(721,L27);
                ddv.visitRestartLocal(0,L27);
                DexLabel L28=new DexLabel();
                ddv.visitLineNumber(723,L28);
                DexLabel L29=new DexLabel();
                ddv.visitLineNumber(725,L29);
                DexLabel L30=new DexLabel();
                ddv.visitLineNumber(727,L30);
                DexLabel L31=new DexLabel();
                ddv.visitLineNumber(730,L31);
                DexLabel L32=new DexLabel();
                ddv.visitLineNumber(731,L32);
                DexLabel L33=new DexLabel();
                ddv.visitLineNumber(733,L33);
                DexLabel L34=new DexLabel();
                ddv.visitLineNumber(734,L34);
                DexLabel L35=new DexLabel();
                ddv.visitLineNumber(736,L35);
                DexLabel L36=new DexLabel();
                ddv.visitLineNumber(737,L36);
                DexLabel L37=new DexLabel();
                ddv.visitLineNumber(739,L37);
                DexLabel L38=new DexLabel();
                ddv.visitLineNumber(740,L38);
                DexLabel L39=new DexLabel();
                ddv.visitLineNumber(743,L39);
                DexLabel L40=new DexLabel();
                ddv.visitLineNumber(744,L40);
                DexLabel L41=new DexLabel();
                ddv.visitLineNumber(749,L41);
                DexLabel L42=new DexLabel();
                ddv.visitLineNumber(751,L42);
                DexLabel L43=new DexLabel();
                ddv.visitEndLocal(0,L43);
                DexLabel L44=new DexLabel();
                ddv.visitLineNumber(757,L44);
                DexLabel L45=new DexLabel();
                ddv.visitLineNumber(675,L45);
                DexLabel L46=new DexLabel();
                ddv.visitLineNumber(687,L46);
                DexLabel L47=new DexLabel();
                ddv.visitLineNumber(705,L47);
                DexLabel L48=new DexLabel();
                ddv.visitLineNumber(718,L48);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,4, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitConstStmt(CONST_4,3, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L2);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 6},new Method("Lorg/mortbay/util/ajax/JSON$Source;","hasNext",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitJumpStmt(IF_EQZ,2,-1,L43);
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 6},new Method("Lorg/mortbay/util/ajax/JSON$Source;","peek",new String[]{ },"C"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitLabel(L4);
                code.visitJumpStmt(IF_NE,1,4,L10);
                code.visitLabel(L5);
                code.visitSparseSwitchStmt(SPARSE_SWITCH,0,new int[]{ 42,47},new DexLabel[]{L9,L7});
                code.visitLabel(L6);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 6},new Method("Lorg/mortbay/util/ajax/JSON$Source;","next",new String[]{ },"C"));
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitLabel(L7);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(-1)); // int: 0xffffffff  float:NaN
                code.visitLabel(L8);
                code.visitJumpStmt(GOTO,-1,-1,L6);
                code.visitLabel(L9);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(2)); // int: 0x00000002  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L6);
                code.visitLabel(L10);
                code.visitJumpStmt(IF_LE,1,4,L19);
                code.visitLabel(L11);
                code.visitSparseSwitchStmt(SPARSE_SWITCH,0,new int[]{ 42,47},new DexLabel[]{L13,L15});
                code.visitLabel(L12);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(2)); // int: 0x00000002  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L6);
                code.visitLabel(L13);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(3)); // int: 0x00000003  float:0.000000
                code.visitLabel(L14);
                code.visitJumpStmt(GOTO,-1,-1,L6);
                code.visitLabel(L15);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(3)); // int: 0x00000003  float:0.000000
                code.visitJumpStmt(IF_NE,1,2,L17);
                code.visitLabel(L16);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L6);
                code.visitLabel(L17);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(2)); // int: 0x00000002  float:0.000000
                code.visitLabel(L18);
                code.visitJumpStmt(GOTO,-1,-1,L6);
                code.visitLabel(L19);
                code.visitJumpStmt(IF_GEZ,1,-1,L23);
                code.visitLabel(L20);
                DexLabel L49=new DexLabel();
                code.visitSparseSwitchStmt(PACKED_SWITCH,0,10,new DexLabel[]{L21,L49,L49,L21});
                code.visitLabel(L49);
                code.visitJumpStmt(GOTO,-1,-1,L6);
                code.visitLabel(L21);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L22);
                code.visitJumpStmt(GOTO,-1,-1,L6);
                code.visitLabel(L23);
                code.visitSparseSwitchStmt(SPARSE_SWITCH,0,new int[]{ 34,45,47,91,102,110,116,117,123},new DexLabel[]{L29,L30,L39,L28,L35,L31,L33,L37,L27});
                code.visitLabel(L24);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0},new Method("Ljava/lang/Character;","isDigit",new String[]{ "C"},"Z"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitJumpStmt(IF_EQZ,2,-1,L41);
                code.visitLabel(L25);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,6},new Method("Lorg/mortbay/util/ajax/JSON;","parseNumber",new String[]{ "Lorg/mortbay/util/ajax/JSON$Source;"},"Ljava/lang/Number;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitLabel(L26);
                code.visitStmt1R(RETURN_OBJECT,2);
                code.visitLabel(L27);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,6},new Method("Lorg/mortbay/util/ajax/JSON;","parseObject",new String[]{ "Lorg/mortbay/util/ajax/JSON$Source;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitJumpStmt(GOTO,-1,-1,L26);
                code.visitLabel(L28);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,6},new Method("Lorg/mortbay/util/ajax/JSON;","parseArray",new String[]{ "Lorg/mortbay/util/ajax/JSON$Source;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitJumpStmt(GOTO,-1,-1,L26);
                code.visitLabel(L29);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,6},new Method("Lorg/mortbay/util/ajax/JSON;","parseString",new String[]{ "Lorg/mortbay/util/ajax/JSON$Source;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitJumpStmt(GOTO,-1,-1,L26);
                code.visitLabel(L30);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,6},new Method("Lorg/mortbay/util/ajax/JSON;","parseNumber",new String[]{ "Lorg/mortbay/util/ajax/JSON$Source;"},"Ljava/lang/Number;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitJumpStmt(GOTO,-1,-1,L26);
                code.visitLabel(L31);
                code.visitConstStmt(CONST_STRING,2,"null");
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 2,6},new Method("Lorg/mortbay/util/ajax/JSON;","complete",new String[]{ "Ljava/lang/String;","Lorg/mortbay/util/ajax/JSON$Source;"},"V"));
                code.visitStmt2R(MOVE_OBJECT,2,3);
                code.visitLabel(L32);
                code.visitJumpStmt(GOTO,-1,-1,L26);
                code.visitLabel(L33);
                code.visitConstStmt(CONST_STRING,2,"true");
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 2,6},new Method("Lorg/mortbay/util/ajax/JSON;","complete",new String[]{ "Ljava/lang/String;","Lorg/mortbay/util/ajax/JSON$Source;"},"V"));
                code.visitLabel(L34);
                code.visitFieldStmt(SGET_OBJECT,2,-1,new Field("Ljava/lang/Boolean;","TRUE","Ljava/lang/Boolean;"));
                code.visitJumpStmt(GOTO,-1,-1,L26);
                code.visitLabel(L35);
                code.visitConstStmt(CONST_STRING,2,"false");
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 2,6},new Method("Lorg/mortbay/util/ajax/JSON;","complete",new String[]{ "Ljava/lang/String;","Lorg/mortbay/util/ajax/JSON$Source;"},"V"));
                code.visitLabel(L36);
                code.visitFieldStmt(SGET_OBJECT,2,-1,new Field("Ljava/lang/Boolean;","FALSE","Ljava/lang/Boolean;"));
                code.visitJumpStmt(GOTO,-1,-1,L26);
                code.visitLabel(L37);
                code.visitConstStmt(CONST_STRING,2,"undefined");
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 2,6},new Method("Lorg/mortbay/util/ajax/JSON;","complete",new String[]{ "Ljava/lang/String;","Lorg/mortbay/util/ajax/JSON$Source;"},"V"));
                code.visitStmt2R(MOVE_OBJECT,2,3);
                code.visitLabel(L38);
                code.visitJumpStmt(GOTO,-1,-1,L26);
                code.visitLabel(L39);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitLabel(L40);
                code.visitJumpStmt(GOTO,-1,-1,L6);
                code.visitLabel(L41);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0},new Method("Ljava/lang/Character;","isWhitespace",new String[]{ "C"},"Z"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitJumpStmt(IF_NEZ,2,-1,L6);
                code.visitLabel(L42);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,6,0},new Method("Lorg/mortbay/util/ajax/JSON;","handleUnknown",new String[]{ "Lorg/mortbay/util/ajax/JSON$Source;","C"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitJumpStmt(GOTO,-1,-1,L26);
                code.visitLabel(L43);
                code.visitStmt2R(MOVE_OBJECT,2,3);
                code.visitLabel(L44);
                code.visitJumpStmt(GOTO,-1,-1,L26);
                code.visitLabel(L45);
                code.visitLabel(L46);
                code.visitLabel(L47);
                code.visitLabel(L48);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m037_parse(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/util/ajax/JSON;","parse",new String[]{ "Lorg/mortbay/util/ajax/JSON$Source;","Z"},"Ljava/lang/Object;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(10);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"source");
                ddv.visitParameterName(1,"stripOuterComment");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(578,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(579,L2);
                ddv.visitStartLocal(1,L2,"comment_state","I",null);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(580,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(660,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(582,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(584,L6);
                ddv.visitStartLocal(3,L6,"strip_state","I",null);
                DexLabel L7=new DexLabel();
                ddv.visitStartLocal(2,L7,"o","Ljava/lang/Object;",null);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(585,L8);
                ddv.visitEndLocal(2,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(587,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(590,L10);
                ddv.visitStartLocal(0,L10,"c","C",null);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(592,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(657,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(595,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(596,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(598,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(599,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(601,L17);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(602,L18);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(607,L19);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(609,L20);
                DexLabel L21=new DexLabel();
                ddv.visitLineNumber(625,L21);
                DexLabel L22=new DexLabel();
                ddv.visitLineNumber(612,L22);
                DexLabel L23=new DexLabel();
                ddv.visitLineNumber(613,L23);
                DexLabel L24=new DexLabel();
                ddv.visitLineNumber(615,L24);
                DexLabel L25=new DexLabel();
                ddv.visitLineNumber(617,L25);
                DexLabel L26=new DexLabel();
                ddv.visitLineNumber(618,L26);
                DexLabel L27=new DexLabel();
                ddv.visitLineNumber(622,L27);
                DexLabel L28=new DexLabel();
                ddv.visitLineNumber(623,L28);
                DexLabel L29=new DexLabel();
                ddv.visitLineNumber(629,L29);
                DexLabel L30=new DexLabel();
                ddv.visitLineNumber(631,L30);
                DexLabel L31=new DexLabel();
                ddv.visitLineNumber(635,L31);
                DexLabel L32=new DexLabel();
                ddv.visitLineNumber(643,L32);
                DexLabel L33=new DexLabel();
                ddv.visitLineNumber(645,L33);
                DexLabel L34=new DexLabel();
                ddv.visitLineNumber(646,L34);
                DexLabel L35=new DexLabel();
                ddv.visitLineNumber(647,L35);
                DexLabel L36=new DexLabel();
                ddv.visitLineNumber(648,L36);
                DexLabel L37=new DexLabel();
                ddv.visitLineNumber(649,L37);
                DexLabel L38=new DexLabel();
                ddv.visitLineNumber(651,L38);
                DexLabel L39=new DexLabel();
                ddv.visitStartLocal(2,L39,"o","Ljava/lang/Object;",null);
                DexLabel L40=new DexLabel();
                ddv.visitLineNumber(652,L40);
                DexLabel L41=new DexLabel();
                ddv.visitLineNumber(592,L41);
                DexLabel L42=new DexLabel();
                ddv.visitLineNumber(609,L42);
                DexLabel L43=new DexLabel();
                ddv.visitLineNumber(631,L43);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,6, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L2);
                code.visitJumpStmt(IF_NEZ,9,-1,L5);
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7,8},new Method("Lorg/mortbay/util/ajax/JSON;","parse",new String[]{ "Lorg/mortbay/util/ajax/JSON$Source;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitLabel(L4);
                code.visitStmt1R(RETURN_OBJECT,4);
                code.visitLabel(L5);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitLabel(L6);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L7);
                code.visitStmt2R(MOVE_OBJECT,4,2);
                code.visitLabel(L8);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 8},new Method("Lorg/mortbay/util/ajax/JSON$Source;","hasNext",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,5);
                code.visitJumpStmt(IF_EQZ,5,-1,L4);
                code.visitLabel(L9);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 8},new Method("Lorg/mortbay/util/ajax/JSON$Source;","peek",new String[]{ },"C"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitLabel(L10);
                code.visitJumpStmt(IF_NE,1,6,L19);
                code.visitLabel(L11);
                code.visitSparseSwitchStmt(SPARSE_SWITCH,0,new int[]{ 42,47},new DexLabel[]{L15,L13});
                code.visitLabel(L12);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 8},new Method("Lorg/mortbay/util/ajax/JSON$Source;","next",new String[]{ },"C"));
                code.visitJumpStmt(GOTO,-1,-1,L8);
                code.visitLabel(L13);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(-1)); // int: 0xffffffff  float:NaN
                code.visitLabel(L14);
                code.visitJumpStmt(GOTO,-1,-1,L12);
                code.visitLabel(L15);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(2)); // int: 0x00000002  float:0.000000
                code.visitLabel(L16);
                code.visitJumpStmt(IF_NE,3,6,L12);
                code.visitLabel(L17);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L18);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(2)); // int: 0x00000002  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L12);
                code.visitLabel(L19);
                code.visitJumpStmt(IF_LE,1,6,L29);
                code.visitLabel(L20);
                code.visitSparseSwitchStmt(SPARSE_SWITCH,0,new int[]{ 42,47},new DexLabel[]{L22,L24});
                code.visitLabel(L21);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(2)); // int: 0x00000002  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L12);
                code.visitLabel(L22);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(3)); // int: 0x00000003  float:0.000000
                code.visitLabel(L23);
                code.visitJumpStmt(GOTO,-1,-1,L12);
                code.visitLabel(L24);
                code.visitConstStmt(CONST_4,5, Integer.valueOf(3)); // int: 0x00000003  float:0.000000
                code.visitJumpStmt(IF_NE,1,5,L27);
                code.visitLabel(L25);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L26);
                code.visitConstStmt(CONST_4,5, Integer.valueOf(2)); // int: 0x00000002  float:0.000000
                code.visitJumpStmt(IF_NE,3,5,L12);
                code.visitJumpStmt(GOTO,-1,-1,L4);
                code.visitLabel(L27);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(2)); // int: 0x00000002  float:0.000000
                code.visitLabel(L28);
                code.visitJumpStmt(GOTO,-1,-1,L12);
                code.visitLabel(L29);
                code.visitJumpStmt(IF_GEZ,1,-1,L32);
                code.visitLabel(L30);
                DexLabel L44=new DexLabel();
                code.visitSparseSwitchStmt(PACKED_SWITCH,0,10,new DexLabel[]{L31,L44,L44,L31});
                code.visitLabel(L44);
                code.visitJumpStmt(GOTO,-1,-1,L12);
                code.visitLabel(L31);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L12);
                code.visitLabel(L32);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0},new Method("Ljava/lang/Character;","isWhitespace",new String[]{ "C"},"Z"));
                code.visitStmt1R(MOVE_RESULT,5);
                code.visitJumpStmt(IF_NEZ,5,-1,L12);
                code.visitLabel(L33);
                code.visitConstStmt(CONST_16,5, Integer.valueOf(47)); // int: 0x0000002f  float:0.000000
                code.visitJumpStmt(IF_NE,0,5,L35);
                code.visitLabel(L34);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L12);
                code.visitLabel(L35);
                code.visitConstStmt(CONST_16,5, Integer.valueOf(42)); // int: 0x0000002a  float:0.000000
                code.visitJumpStmt(IF_NE,0,5,L37);
                code.visitLabel(L36);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(3)); // int: 0x00000003  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L12);
                code.visitLabel(L37);
                code.visitJumpStmt(IF_NEZ,4,-1,L12);
                code.visitLabel(L38);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7,8},new Method("Lorg/mortbay/util/ajax/JSON;","parse",new String[]{ "Lorg/mortbay/util/ajax/JSON$Source;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitLabel(L39);
                code.visitStmt2R(MOVE_OBJECT,4,2);
                code.visitLabel(L40);
                code.visitJumpStmt(GOTO,-1,-1,L8);
                code.visitLabel(L41);
                code.visitLabel(L42);
                code.visitLabel(L43);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m038_parseArray(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Lorg/mortbay/util/ajax/JSON;","parseArray",new String[]{ "Lorg/mortbay/util/ajax/JSON$Source;"},"Ljava/lang/Object;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(12);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"source");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(815,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(816,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(818,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(819,L4);
                ddv.visitStartLocal(5,L4,"size","I",null);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(820,L5);
                ddv.visitStartLocal(4,L5,"list","Ljava/util/ArrayList;",null);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(821,L6);
                ddv.visitStartLocal(3,L6,"item","Ljava/lang/Object;",null);
                DexLabel L7=new DexLabel();
                ddv.visitStartLocal(2,L7,"coma","Z",null);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(823,L8);
                ddv.visitEndLocal(3,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(825,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(826,L10);
                ddv.visitStartLocal(1,L10,"c","C",null);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(850,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(851,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(829,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(830,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(839,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(833,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(835,L17);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(836,L18);
                ddv.visitStartLocal(0,L18,"array","[Ljava/lang/Object;",null);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(837,L19);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(843,L20);
                ddv.visitEndLocal(0,L20);
                DexLabel L21=new DexLabel();
                ddv.visitLineNumber(844,L21);
                DexLabel L22=new DexLabel();
                ddv.visitLineNumber(845,L22);
                DexLabel L23=new DexLabel();
                ddv.visitLineNumber(846,L23);
                DexLabel L24=new DexLabel();
                ddv.visitLineNumber(854,L24);
                DexLabel L25=new DexLabel();
                ddv.visitLineNumber(855,L25);
                DexLabel L26=new DexLabel();
                ddv.visitStartLocal(6,L26,"size","I",null);
                DexLabel L27=new DexLabel();
                ddv.visitLineNumber(856,L27);
                ddv.visitEndLocal(5,L27);
                DexLabel L28=new DexLabel();
                ddv.visitStartLocal(3,L28,"item","Ljava/lang/Object;",null);
                DexLabel L29=new DexLabel();
                ddv.visitRestartLocal(5,L29);
                DexLabel L30=new DexLabel();
                ddv.visitLineNumber(857,L30);
                ddv.visitEndLocal(3,L30);
                ddv.visitEndLocal(5,L30);
                DexLabel L31=new DexLabel();
                ddv.visitLineNumber(859,L31);
                DexLabel L32=new DexLabel();
                ddv.visitEndLocal(4,L32);
                DexLabel L33=new DexLabel();
                ddv.visitLineNumber(860,L33);
                ddv.visitRestartLocal(4,L33);
                DexLabel L34=new DexLabel();
                ddv.visitLineNumber(861,L34);
                DexLabel L35=new DexLabel();
                ddv.visitLineNumber(862,L35);
                ddv.visitRestartLocal(3,L35);
                DexLabel L36=new DexLabel();
                ddv.visitLineNumber(863,L36);
                DexLabel L37=new DexLabel();
                ddv.visitStartLocal(3,L37,"item","Ljava/lang/Object;",null);
                DexLabel L38=new DexLabel();
                ddv.visitRestartLocal(5,L38);
                DexLabel L39=new DexLabel();
                ddv.visitLineNumber(867,L39);
                ddv.visitEndLocal(3,L39);
                ddv.visitEndLocal(5,L39);
                DexLabel L40=new DexLabel();
                ddv.visitLineNumber(868,L40);
                ddv.visitStartLocal(3,L40,"item","Ljava/lang/Object;",null);
                DexLabel L41=new DexLabel();
                ddv.visitLineNumber(869,L41);
                DexLabel L42=new DexLabel();
                ddv.visitStartLocal(3,L42,"item","Ljava/lang/Object;",null);
                DexLabel L43=new DexLabel();
                ddv.visitRestartLocal(5,L43);
                DexLabel L44=new DexLabel();
                ddv.visitLineNumber(876,L44);
                ddv.visitEndLocal(1,L44);
                ddv.visitEndLocal(6,L44);
                ddv.visitEndLocal(3,L44);
                DexLabel L45=new DexLabel();
                ddv.visitLineNumber(826,L45);
                DexLabel L46=new DexLabel();
                ddv.visitLineNumber(830,L46);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,9, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 11},new Method("Lorg/mortbay/util/ajax/JSON$Source;","next",new String[]{ },"C"));
                code.visitStmt1R(MOVE_RESULT,7);
                code.visitConstStmt(CONST_16,8, Integer.valueOf(91)); // int: 0x0000005b  float:0.000000
                code.visitJumpStmt(IF_EQ,7,8,L3);
                code.visitLabel(L2);
                code.visitTypeStmt(NEW_INSTANCE,7,-1,"Ljava/lang/IllegalStateException;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 7},new Method("Ljava/lang/IllegalStateException;","<init>",new String[]{ },"V"));
                code.visitStmt1R(THROW,7);
                code.visitLabel(L3);
                code.visitConstStmt(CONST_4,5, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L4);
                code.visitConstStmt(CONST_4,4, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L5);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L6);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitLabel(L7);
                code.visitStmt2R(MOVE_OBJECT,7,3);
                code.visitLabel(L8);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 11},new Method("Lorg/mortbay/util/ajax/JSON$Source;","hasNext",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,8);
                code.visitJumpStmt(IF_EQZ,8,-1,L44);
                code.visitLabel(L9);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 11},new Method("Lorg/mortbay/util/ajax/JSON$Source;","peek",new String[]{ },"C"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitLabel(L10);
                code.visitSparseSwitchStmt(SPARSE_SWITCH,1,new int[]{ 44,93},new DexLabel[]{L20,L13});
                code.visitLabel(L11);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1},new Method("Ljava/lang/Character;","isWhitespace",new String[]{ "C"},"Z"));
                code.visitStmt1R(MOVE_RESULT,8);
                code.visitJumpStmt(IF_EQZ,8,-1,L24);
                code.visitLabel(L12);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 11},new Method("Lorg/mortbay/util/ajax/JSON$Source;","next",new String[]{ },"C"));
                code.visitJumpStmt(GOTO,-1,-1,L8);
                code.visitLabel(L13);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 11},new Method("Lorg/mortbay/util/ajax/JSON$Source;","next",new String[]{ },"C"));
                code.visitLabel(L14);
                code.visitSparseSwitchStmt(PACKED_SWITCH,5,0,new DexLabel[]{L16,L17});
                code.visitLabel(L15);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Ljava/util/ArrayList;","size",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10,7},new Method("Lorg/mortbay/util/ajax/JSON;","newArray",new String[]{ "I"},"[Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,7},new Method("Ljava/util/ArrayList;","toArray",new String[]{ "[Ljava/lang/Object;"},"[Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                DexLabel L47=new DexLabel();
                code.visitLabel(L47);
                code.visitStmt1R(RETURN_OBJECT,7);
                code.visitLabel(L16);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10,9},new Method("Lorg/mortbay/util/ajax/JSON;","newArray",new String[]{ "I"},"[Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitJumpStmt(GOTO,-1,-1,L47);
                code.visitLabel(L17);
                code.visitConstStmt(CONST_4,8, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10,8},new Method("Lorg/mortbay/util/ajax/JSON;","newArray",new String[]{ "I"},"[Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L18);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0,9,7},new Method("Ljava/lang/reflect/Array;","set",new String[]{ "Ljava/lang/Object;","I","Ljava/lang/Object;"},"V"));
                code.visitStmt2R(MOVE_OBJECT,7,0);
                code.visitLabel(L19);
                code.visitJumpStmt(GOTO,-1,-1,L47);
                code.visitLabel(L20);
                code.visitJumpStmt(IF_EQZ,2,-1,L22);
                code.visitLabel(L21);
                code.visitTypeStmt(NEW_INSTANCE,7,-1,"Ljava/lang/IllegalStateException;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 7},new Method("Ljava/lang/IllegalStateException;","<init>",new String[]{ },"V"));
                code.visitStmt1R(THROW,7);
                code.visitLabel(L22);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitLabel(L23);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 11},new Method("Lorg/mortbay/util/ajax/JSON$Source;","next",new String[]{ },"C"));
                code.visitJumpStmt(GOTO,-1,-1,L8);
                code.visitLabel(L24);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L25);
                code.visitStmt2R1N(ADD_INT_LIT8,6,5,1);
                code.visitLabel(L26);
                code.visitJumpStmt(IF_NEZ,5,-1,L30);
                code.visitLabel(L27);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10},new Method("Lorg/mortbay/util/ajax/JSON;","contextForArray",new String[]{ },"Lorg/mortbay/util/ajax/JSON;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7,11},new Method("Lorg/mortbay/util/ajax/JSON;","parse",new String[]{ "Lorg/mortbay/util/ajax/JSON$Source;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitLabel(L28);
                code.visitStmt2R(MOVE_OBJECT,7,3);
                code.visitStmt2R(MOVE,5,6);
                code.visitLabel(L29);
                code.visitJumpStmt(GOTO,-1,-1,L8);
                code.visitLabel(L30);
                code.visitJumpStmt(IF_NEZ,4,-1,L39);
                code.visitLabel(L31);
                code.visitTypeStmt(NEW_INSTANCE,4,-1,"Ljava/util/ArrayList;");
                code.visitLabel(L32);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 4},new Method("Ljava/util/ArrayList;","<init>",new String[]{ },"V"));
                code.visitLabel(L33);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,7},new Method("Ljava/util/ArrayList;","add",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitLabel(L34);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10},new Method("Lorg/mortbay/util/ajax/JSON;","contextForArray",new String[]{ },"Lorg/mortbay/util/ajax/JSON;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7,11},new Method("Lorg/mortbay/util/ajax/JSON;","parse",new String[]{ "Lorg/mortbay/util/ajax/JSON$Source;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitLabel(L35);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,3},new Method("Ljava/util/ArrayList;","add",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitLabel(L36);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L37);
                code.visitStmt2R(MOVE_OBJECT,7,3);
                code.visitStmt2R(MOVE,5,6);
                code.visitLabel(L38);
                code.visitJumpStmt(GOTO,-1,-1,L8);
                code.visitLabel(L39);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10},new Method("Lorg/mortbay/util/ajax/JSON;","contextForArray",new String[]{ },"Lorg/mortbay/util/ajax/JSON;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7,11},new Method("Lorg/mortbay/util/ajax/JSON;","parse",new String[]{ "Lorg/mortbay/util/ajax/JSON$Source;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitLabel(L40);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,3},new Method("Ljava/util/ArrayList;","add",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitLabel(L41);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L42);
                code.visitStmt2R(MOVE_OBJECT,7,3);
                code.visitStmt2R(MOVE,5,6);
                code.visitLabel(L43);
                code.visitJumpStmt(GOTO,-1,-1,L8);
                code.visitLabel(L44);
                code.visitTypeStmt(NEW_INSTANCE,7,-1,"Ljava/lang/IllegalStateException;");
                code.visitConstStmt(CONST_STRING,8,"unexpected end of array");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 7,8},new Method("Ljava/lang/IllegalStateException;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitStmt1R(THROW,7);
                code.visitLabel(L45);
                code.visitLabel(L46);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m039_parseNumber(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/util/ajax/JSON;","parseNumber",new String[]{ "Lorg/mortbay/util/ajax/JSON$Source;"},"Ljava/lang/Number;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(11);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexLabel L3=new DexLabel();
                DexLabel L4=new DexLabel();
                code.visitTryCatch(L3,L4,new DexLabel[]{L2},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"source");
                DexLabel L5=new DexLabel();
                ddv.visitPrologue(L5);
                ddv.visitLineNumber(1032,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(1033,L6);
                ddv.visitStartLocal(2,L6,"minus","Z",null);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(1034,L7);
                ddv.visitStartLocal(3,L7,"number","J",null);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(1036,L8);
                ddv.visitStartLocal(0,L8,"buffer","Ljava/lang/StringBuffer;",null);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(1038,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(1039,L10);
                ddv.visitStartLocal(1,L10,"c","C",null);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(1079,L11);
                ddv.visitEndLocal(1,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(1080,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(1112,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(1051,L14);
                ddv.visitRestartLocal(1,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(1052,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(1057,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(1058,L17);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(1059,L18);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(1060,L19);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(1066,L20);
                DexLabel L21=new DexLabel();
                ddv.visitEndLocal(0,L21);
                DexLabel L22=new DexLabel();
                ddv.visitLineNumber(1067,L22);
                ddv.visitRestartLocal(0,L22);
                DexLabel L23=new DexLabel();
                ddv.visitLineNumber(1068,L23);
                DexLabel L24=new DexLabel();
                ddv.visitLineNumber(1069,L24);
                DexLabel L25=new DexLabel();
                ddv.visitLineNumber(1070,L25);
                DexLabel L26=new DexLabel();
                ddv.visitLineNumber(1071,L26);
                DexLabel L27=new DexLabel();
                ddv.visitEndLocal(1,L27);
                DexLabel L28=new DexLabel();
                ddv.visitLineNumber(1080,L28);
                DexLabel L29=new DexLabel();
                ddv.visitLineNumber(1082,L29);
                ddv.visitLineNumber(1084,L0);
                DexLabel L30=new DexLabel();
                ddv.visitLineNumber(1086,L30);
                DexLabel L31=new DexLabel();
                ddv.visitLineNumber(1087,L31);
                ddv.visitRestartLocal(1,L31);
                DexLabel L32=new DexLabel();
                ddv.visitLineNumber(1112,L32);
                ddv.visitEndLocal(1,L32);
                ddv.visitLineNumber(1113,L2);
                ddv.visitLineNumber(1104,L3);
                ddv.visitRestartLocal(1,L3);
                DexLabel L33=new DexLabel();
                ddv.visitLineNumber(1105,L33);
                DexLabel L34=new DexLabel();
                ddv.visitLineNumber(1039,L34);
                DexLabel L35=new DexLabel();
                ddv.visitLineNumber(1087,L35);
                code.visitLabel(L5);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L6);
                code.visitConstStmt(CONST_WIDE_16,3,Long.valueOf(0L)); // long: 0x0000000000000000  double:0.000000
                code.visitLabel(L7);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L8);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 10},new Method("Lorg/mortbay/util/ajax/JSON$Source;","hasNext",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,5);
                code.visitJumpStmt(IF_EQZ,5,-1,L11);
                code.visitLabel(L9);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 10},new Method("Lorg/mortbay/util/ajax/JSON$Source;","peek",new String[]{ },"C"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitLabel(L10);
                code.visitSparseSwitchStmt(SPARSE_SWITCH,1,new int[]{ 43,45,46,48,49,50,51,52,53,54,55,56,57,69,101},new DexLabel[]{L16,L16,L20,L14,L14,L14,L14,L14,L14,L14,L14,L14,L14,L20,L20});
                code.visitLabel(L11);
                code.visitJumpStmt(IF_NEZ,0,-1,L29);
                code.visitLabel(L12);
                code.visitJumpStmt(IF_EQZ,2,-1,L27);
                code.visitConstStmt(CONST_WIDE_16,5,Long.valueOf(-1L)); // long: 0xffffffffffffffff  double:NaN
                code.visitStmt2R(MUL_LONG_2ADDR,5,3);
                DexLabel L36=new DexLabel();
                code.visitLabel(L36);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 5,6},new Method("Lorg/mortbay/util/TypeUtil;","newLong",new String[]{ "J"},"Ljava/lang/Long;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitLabel(L13);
                code.visitStmt1R(RETURN_OBJECT,5);
                code.visitLabel(L14);
                code.visitConstStmt(CONST_WIDE_16,5,Long.valueOf(10L)); // long: 0x000000000000000a  double:0.000000
                code.visitStmt2R(MUL_LONG_2ADDR,5,3);
                code.visitConstStmt(CONST_16,7, Integer.valueOf(48)); // int: 0x00000030  float:0.000000
                code.visitStmt3R(SUB_INT,7,1,7);
                code.visitStmt2R(INT_TO_LONG,7,7);
                code.visitStmt3R(ADD_LONG,3,5,7);
                code.visitLabel(L15);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 10},new Method("Lorg/mortbay/util/ajax/JSON$Source;","next",new String[]{ },"C"));
                code.visitJumpStmt(GOTO,-1,-1,L8);
                code.visitLabel(L16);
                code.visitConstStmt(CONST_WIDE_16,5,Long.valueOf(0L)); // long: 0x0000000000000000  double:0.000000
                code.visitStmt3R(CMP_LONG,5,3,5);
                code.visitJumpStmt(IF_EQZ,5,-1,L18);
                code.visitLabel(L17);
                code.visitTypeStmt(NEW_INSTANCE,5,-1,"Ljava/lang/IllegalStateException;");
                code.visitConstStmt(CONST_STRING,6,"bad number");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 5,6},new Method("Ljava/lang/IllegalStateException;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitStmt1R(THROW,5);
                code.visitLabel(L18);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitLabel(L19);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 10},new Method("Lorg/mortbay/util/ajax/JSON$Source;","next",new String[]{ },"C"));
                code.visitJumpStmt(GOTO,-1,-1,L8);
                code.visitLabel(L20);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/lang/StringBuffer;");
                code.visitLabel(L21);
                code.visitConstStmt(CONST_16,5, Integer.valueOf(16)); // int: 0x00000010  float:0.000000
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,5},new Method("Ljava/lang/StringBuffer;","<init>",new String[]{ "I"},"V"));
                code.visitLabel(L22);
                code.visitJumpStmt(IF_EQZ,2,-1,L24);
                code.visitLabel(L23);
                code.visitConstStmt(CONST_16,5, Integer.valueOf(45)); // int: 0x0000002d  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,5},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "C"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L24);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,3,4},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "J"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L25);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "C"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L26);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 10},new Method("Lorg/mortbay/util/ajax/JSON$Source;","next",new String[]{ },"C"));
                code.visitJumpStmt(GOTO,-1,-1,L11);
                code.visitLabel(L27);
                code.visitStmt2R(MOVE_WIDE,5,3);
                code.visitLabel(L28);
                code.visitJumpStmt(GOTO,-1,-1,L36);
                code.visitLabel(L29);
                code.visitStmt1R(MONITOR_ENTER,0);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 10},new Method("Lorg/mortbay/util/ajax/JSON$Source;","hasNext",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,5);
                code.visitJumpStmt(IF_EQZ,5,-1,L32);
                code.visitLabel(L30);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 10},new Method("Lorg/mortbay/util/ajax/JSON$Source;","peek",new String[]{ },"C"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitLabel(L31);
                code.visitSparseSwitchStmt(SPARSE_SWITCH,1,new int[]{ 43,45,46,48,49,50,51,52,53,54,55,56,57,69,101},new DexLabel[]{L3,L3,L3,L3,L3,L3,L3,L3,L3,L3,L3,L3,L3,L3,L3});
                code.visitLabel(L32);
                code.visitTypeStmt(NEW_INSTANCE,5,-1,"Ljava/lang/Double;");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/lang/StringBuffer;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 5,6},new Method("Ljava/lang/Double;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitStmt1R(MONITOR_EXIT,0);
                code.visitJumpStmt(GOTO,-1,-1,L13);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,5);
                code.visitStmt1R(MONITOR_EXIT,0);
                code.visitLabel(L1);
                code.visitStmt1R(THROW,5);
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "C"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L33);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 10},new Method("Lorg/mortbay/util/ajax/JSON$Source;","next",new String[]{ },"C"));
                code.visitLabel(L4);
                code.visitJumpStmt(GOTO,-1,-1,L0);
                code.visitLabel(L34);
                code.visitLabel(L35);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m040_parseObject(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Lorg/mortbay/util/ajax/JSON;","parseObject",new String[]{ "Lorg/mortbay/util/ajax/JSON$Source;"},"Ljava/lang/Object;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(13);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ "Ljava/lang/ClassNotFoundException;"});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"source");
                DexLabel L3=new DexLabel();
                ddv.visitPrologue(L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(767,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(768,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(769,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(771,L7);
                ddv.visitStartLocal(3,L7,"map","Ljava/util/Map;",null);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(773,L8);
                ddv.visitStartLocal(5,L8,"next","C",null);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(775,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(777,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(796,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(797,L12);
                ddv.visitStartLocal(1,L12,"classname","Ljava/lang/String;",null);
                ddv.visitLineNumber(801,L0);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(802,L13);
                ddv.visitStartLocal(0,L13,"c","Ljava/lang/Class;",null);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(809,L14);
                ddv.visitEndLocal(0,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(781,L15);
                ddv.visitEndLocal(1,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(782,L16);
                ddv.visitStartLocal(4,L16,"name","Ljava/lang/String;",null);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(783,L17);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(785,L18);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(786,L19);
                ddv.visitStartLocal(6,L19,"value","Ljava/lang/Object;",null);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(788,L20);
                DexLabel L21=new DexLabel();
                ddv.visitLineNumber(789,L21);
                DexLabel L22=new DexLabel();
                ddv.visitLineNumber(790,L22);
                DexLabel L23=new DexLabel();
                ddv.visitLineNumber(793,L23);
                DexLabel L24=new DexLabel();
                ddv.visitLineNumber(794,L24);
                ddv.visitRestartLocal(5,L24);
                ddv.visitLineNumber(804,L2);
                ddv.visitEndLocal(4,L2);
                ddv.visitEndLocal(6,L2);
                ddv.visitRestartLocal(1,L2);
                DexLabel L25=new DexLabel();
                ddv.visitLineNumber(806,L25);
                ddv.visitStartLocal(2,L25,"e","Ljava/lang/ClassNotFoundException;",null);
                DexLabel L26=new DexLabel();
                ddv.visitEndLocal(2,L26);
                DexLabel L27=new DexLabel();
                ddv.visitLineNumber(809,L27);
                code.visitLabel(L3);
                code.visitConstStmt(CONST_16,9, Integer.valueOf(125)); // int: 0x0000007d  float:0.000000
                code.visitConstStmt(CONST_STRING,10,"\"}");
                code.visitLabel(L4);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 12},new Method("Lorg/mortbay/util/ajax/JSON$Source;","next",new String[]{ },"C"));
                code.visitStmt1R(MOVE_RESULT,7);
                code.visitConstStmt(CONST_16,8, Integer.valueOf(123)); // int: 0x0000007b  float:0.000000
                code.visitJumpStmt(IF_EQ,7,8,L6);
                code.visitLabel(L5);
                code.visitTypeStmt(NEW_INSTANCE,7,-1,"Ljava/lang/IllegalStateException;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 7},new Method("Ljava/lang/IllegalStateException;","<init>",new String[]{ },"V"));
                code.visitStmt1R(THROW,7);
                code.visitLabel(L6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 11},new Method("Lorg/mortbay/util/ajax/JSON;","newMap",new String[]{ },"Ljava/util/Map;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitLabel(L7);
                code.visitConstStmt(CONST_STRING,7,"\"}");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 11,10,12},new Method("Lorg/mortbay/util/ajax/JSON;","seekTo",new String[]{ "Ljava/lang/String;","Lorg/mortbay/util/ajax/JSON$Source;"},"C"));
                code.visitStmt1R(MOVE_RESULT,5);
                code.visitLabel(L8);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 12},new Method("Lorg/mortbay/util/ajax/JSON$Source;","hasNext",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,7);
                code.visitJumpStmt(IF_EQZ,7,-1,L11);
                code.visitLabel(L9);
                code.visitJumpStmt(IF_NE,5,9,L15);
                code.visitLabel(L10);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 12},new Method("Lorg/mortbay/util/ajax/JSON$Source;","next",new String[]{ },"C"));
                code.visitLabel(L11);
                code.visitConstStmt(CONST_STRING,7,"class");
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 3,7},new Method("Ljava/util/Map;","get",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitTypeStmt(CHECK_CAST,1,-1,"Ljava/lang/String;");
                code.visitLabel(L12);
                code.visitJumpStmt(IF_EQZ,1,-1,L26);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_CLASS,7,new DexType("Lorg/mortbay/util/ajax/JSON;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 7,1},new Method("Lorg/mortbay/util/Loader;","loadClass",new String[]{ "Ljava/lang/Class;","Ljava/lang/String;"},"Ljava/lang/Class;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L13);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 11,0,3},new Method("Lorg/mortbay/util/ajax/JSON;","convertTo",new String[]{ "Ljava/lang/Class;","Ljava/util/Map;"},"Ljava/lang/Object;"));
                code.visitLabel(L1);
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitLabel(L14);
                code.visitStmt1R(RETURN_OBJECT,7);
                code.visitLabel(L15);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 11,12},new Method("Lorg/mortbay/util/ajax/JSON;","parseString",new String[]{ "Lorg/mortbay/util/ajax/JSON$Source;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitLabel(L16);
                code.visitConstStmt(CONST_16,7, Integer.valueOf(58)); // int: 0x0000003a  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 11,7,12},new Method("Lorg/mortbay/util/ajax/JSON;","seekTo",new String[]{ "C","Lorg/mortbay/util/ajax/JSON$Source;"},"V"));
                code.visitLabel(L17);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 12},new Method("Lorg/mortbay/util/ajax/JSON$Source;","next",new String[]{ },"C"));
                code.visitLabel(L18);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 11,4},new Method("Lorg/mortbay/util/ajax/JSON;","contextFor",new String[]{ "Ljava/lang/String;"},"Lorg/mortbay/util/ajax/JSON;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7,12},new Method("Lorg/mortbay/util/ajax/JSON;","parse",new String[]{ "Lorg/mortbay/util/ajax/JSON$Source;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitLabel(L19);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 3,4,6},new Method("Ljava/util/Map;","put",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitLabel(L20);
                code.visitConstStmt(CONST_STRING,7,",}");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 11,7,12},new Method("Lorg/mortbay/util/ajax/JSON;","seekTo",new String[]{ "Ljava/lang/String;","Lorg/mortbay/util/ajax/JSON$Source;"},"C"));
                code.visitLabel(L21);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 12},new Method("Lorg/mortbay/util/ajax/JSON$Source;","next",new String[]{ },"C"));
                code.visitStmt1R(MOVE_RESULT,5);
                code.visitLabel(L22);
                code.visitJumpStmt(IF_EQ,5,9,L11);
                code.visitLabel(L23);
                code.visitConstStmt(CONST_STRING,7,"\"}");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 11,10,12},new Method("Lorg/mortbay/util/ajax/JSON;","seekTo",new String[]{ "Ljava/lang/String;","Lorg/mortbay/util/ajax/JSON$Source;"},"C"));
                code.visitStmt1R(MOVE_RESULT,5);
                code.visitLabel(L24);
                code.visitJumpStmt(GOTO,-1,-1,L8);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,7);
                code.visitStmt2R(MOVE_OBJECT,2,7);
                code.visitLabel(L25);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Ljava/lang/ClassNotFoundException;","printStackTrace",new String[]{ },"V"));
                code.visitLabel(L26);
                code.visitStmt2R(MOVE_OBJECT,7,3);
                code.visitLabel(L27);
                code.visitJumpStmt(GOTO,-1,-1,L14);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m041_parseString(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Lorg/mortbay/util/ajax/JSON;","parseString",new String[]{ "Lorg/mortbay/util/ajax/JSON$Source;"},"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(16);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexLabel L3=new DexLabel();
                DexLabel L4=new DexLabel();
                code.visitTryCatch(L3,L4,new DexLabel[]{L2},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"source");
                DexLabel L5=new DexLabel();
                ddv.visitPrologue(L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(882,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(883,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(885,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(887,L9);
                ddv.visitStartLocal(2,L9,"escape","Z",null);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(888,L10);
                ddv.visitStartLocal(0,L10,"b","Ljava/lang/StringBuffer;",null);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(890,L11);
                ddv.visitStartLocal(5,L11,"scratch","[C",null);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(892,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(893,L13);
                ddv.visitStartLocal(3,L13,"i","I",null);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(895,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(899,L15);
                DexLabel L16=new DexLabel();
                ddv.visitEndLocal(0,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(900,L17);
                ddv.visitRestartLocal(0,L17);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(961,L18);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(962,L19);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(1026,L20);
                ddv.visitEndLocal(3,L20);
                DexLabel L21=new DexLabel();
                ddv.visitLineNumber(904,L21);
                ddv.visitRestartLocal(3,L21);
                DexLabel L22=new DexLabel();
                ddv.visitLineNumber(906,L22);
                ddv.visitStartLocal(1,L22,"c","C",null);
                DexLabel L23=new DexLabel();
                ddv.visitLineNumber(908,L23);
                DexLabel L24=new DexLabel();
                ddv.visitLineNumber(909,L24);
                DexLabel L25=new DexLabel();
                ddv.visitLineNumber(943,L25);
                DexLabel L26=new DexLabel();
                ddv.visitStartLocal(4,L26,"i","I",null);
                DexLabel L27=new DexLabel();
                ddv.visitEndLocal(3,L27);
                DexLabel L28=new DexLabel();
                ddv.visitRestartLocal(3,L28);
                DexLabel L29=new DexLabel();
                ddv.visitLineNumber(912,L29);
                ddv.visitEndLocal(4,L29);
                DexLabel L30=new DexLabel();
                ddv.visitRestartLocal(4,L30);
                DexLabel L31=new DexLabel();
                ddv.visitEndLocal(3,L31);
                DexLabel L32=new DexLabel();
                ddv.visitLineNumber(913,L32);
                ddv.visitRestartLocal(3,L32);
                DexLabel L33=new DexLabel();
                ddv.visitLineNumber(915,L33);
                ddv.visitEndLocal(4,L33);
                DexLabel L34=new DexLabel();
                ddv.visitRestartLocal(4,L34);
                DexLabel L35=new DexLabel();
                ddv.visitEndLocal(3,L35);
                DexLabel L36=new DexLabel();
                ddv.visitLineNumber(916,L36);
                ddv.visitRestartLocal(3,L36);
                DexLabel L37=new DexLabel();
                ddv.visitLineNumber(918,L37);
                ddv.visitEndLocal(4,L37);
                DexLabel L38=new DexLabel();
                ddv.visitRestartLocal(4,L38);
                DexLabel L39=new DexLabel();
                ddv.visitEndLocal(3,L39);
                DexLabel L40=new DexLabel();
                ddv.visitLineNumber(919,L40);
                ddv.visitRestartLocal(3,L40);
                DexLabel L41=new DexLabel();
                ddv.visitLineNumber(921,L41);
                ddv.visitEndLocal(4,L41);
                DexLabel L42=new DexLabel();
                ddv.visitRestartLocal(4,L42);
                DexLabel L43=new DexLabel();
                ddv.visitEndLocal(3,L43);
                DexLabel L44=new DexLabel();
                ddv.visitLineNumber(922,L44);
                ddv.visitRestartLocal(3,L44);
                DexLabel L45=new DexLabel();
                ddv.visitLineNumber(924,L45);
                ddv.visitEndLocal(4,L45);
                DexLabel L46=new DexLabel();
                ddv.visitRestartLocal(4,L46);
                DexLabel L47=new DexLabel();
                ddv.visitEndLocal(3,L47);
                DexLabel L48=new DexLabel();
                ddv.visitLineNumber(925,L48);
                ddv.visitRestartLocal(3,L48);
                DexLabel L49=new DexLabel();
                ddv.visitLineNumber(927,L49);
                ddv.visitEndLocal(4,L49);
                DexLabel L50=new DexLabel();
                ddv.visitRestartLocal(4,L50);
                DexLabel L51=new DexLabel();
                ddv.visitEndLocal(3,L51);
                DexLabel L52=new DexLabel();
                ddv.visitLineNumber(928,L52);
                ddv.visitRestartLocal(3,L52);
                DexLabel L53=new DexLabel();
                ddv.visitLineNumber(930,L53);
                ddv.visitEndLocal(4,L53);
                DexLabel L54=new DexLabel();
                ddv.visitRestartLocal(4,L54);
                DexLabel L55=new DexLabel();
                ddv.visitEndLocal(3,L55);
                DexLabel L56=new DexLabel();
                ddv.visitLineNumber(931,L56);
                ddv.visitRestartLocal(3,L56);
                DexLabel L57=new DexLabel();
                ddv.visitLineNumber(933,L57);
                ddv.visitEndLocal(4,L57);
                DexLabel L58=new DexLabel();
                ddv.visitRestartLocal(4,L58);
                DexLabel L59=new DexLabel();
                ddv.visitEndLocal(3,L59);
                DexLabel L60=new DexLabel();
                ddv.visitLineNumber(934,L60);
                ddv.visitRestartLocal(3,L60);
                DexLabel L61=new DexLabel();
                ddv.visitLineNumber(936,L61);
                ddv.visitEndLocal(4,L61);
                DexLabel L62=new DexLabel();
                ddv.visitLineNumber(940,L62);
                ddv.visitStartLocal(6,L62,"uc","C",null);
                DexLabel L63=new DexLabel();
                ddv.visitRestartLocal(4,L63);
                DexLabel L64=new DexLabel();
                ddv.visitEndLocal(3,L64);
                DexLabel L65=new DexLabel();
                ddv.visitLineNumber(941,L65);
                ddv.visitRestartLocal(3,L65);
                DexLabel L66=new DexLabel();
                ddv.visitLineNumber(946,L66);
                ddv.visitEndLocal(6,L66);
                ddv.visitEndLocal(4,L66);
                DexLabel L67=new DexLabel();
                ddv.visitLineNumber(948,L67);
                DexLabel L68=new DexLabel();
                ddv.visitLineNumber(949,L68);
                DexLabel L69=new DexLabel();
                ddv.visitLineNumber(951,L69);
                DexLabel L70=new DexLabel();
                ddv.visitLineNumber(954,L70);
                DexLabel L71=new DexLabel();
                ddv.visitLineNumber(957,L71);
                DexLabel L72=new DexLabel();
                ddv.visitRestartLocal(4,L72);
                DexLabel L73=new DexLabel();
                ddv.visitLineNumber(965,L73);
                ddv.visitEndLocal(1,L73);
                ddv.visitEndLocal(3,L73);
                ddv.visitEndLocal(4,L73);
                DexLabel L74=new DexLabel();
                ddv.visitEndLocal(0,L74);
                DexLabel L75=new DexLabel();
                ddv.visitLineNumber(969,L75);
                ddv.visitRestartLocal(0,L75);
                ddv.visitLineNumber(971,L0);
                DexLabel L76=new DexLabel();
                ddv.visitLineNumber(973,L76);
                DexLabel L77=new DexLabel();
                ddv.visitLineNumber(975,L77);
                ddv.visitRestartLocal(1,L77);
                DexLabel L78=new DexLabel();
                ddv.visitLineNumber(977,L78);
                DexLabel L79=new DexLabel();
                ddv.visitLineNumber(978,L79);
                DexLabel L80=new DexLabel();
                ddv.visitLineNumber(1012,L80);
                ddv.visitLineNumber(1027,L2);
                ddv.visitEndLocal(1,L2);
                DexLabel L81=new DexLabel();
                ddv.visitLineNumber(981,L81);
                ddv.visitRestartLocal(1,L81);
                DexLabel L82=new DexLabel();
                ddv.visitLineNumber(984,L82);
                DexLabel L83=new DexLabel();
                ddv.visitLineNumber(987,L83);
                DexLabel L84=new DexLabel();
                ddv.visitLineNumber(990,L84);
                DexLabel L85=new DexLabel();
                ddv.visitLineNumber(993,L85);
                DexLabel L86=new DexLabel();
                ddv.visitLineNumber(996,L86);
                DexLabel L87=new DexLabel();
                ddv.visitLineNumber(999,L87);
                DexLabel L88=new DexLabel();
                ddv.visitLineNumber(1002,L88);
                DexLabel L89=new DexLabel();
                ddv.visitLineNumber(1005,L89);
                DexLabel L90=new DexLabel();
                ddv.visitLineNumber(1009,L90);
                ddv.visitRestartLocal(6,L90);
                DexLabel L91=new DexLabel();
                ddv.visitLineNumber(1015,L91);
                ddv.visitEndLocal(6,L91);
                DexLabel L92=new DexLabel();
                ddv.visitLineNumber(1017,L92);
                DexLabel L93=new DexLabel();
                ddv.visitLineNumber(1018,L93);
                DexLabel L94=new DexLabel();
                ddv.visitLineNumber(1020,L94);
                DexLabel L95=new DexLabel();
                ddv.visitLineNumber(1026,L95);
                ddv.visitEndLocal(1,L95);
                DexLabel L96=new DexLabel();
                ddv.visitLineNumber(1023,L96);
                ddv.visitRestartLocal(1,L96);
                DexLabel L97=new DexLabel();
                ddv.visitLineNumber(909,L97);
                DexLabel L98=new DexLabel();
                ddv.visitLineNumber(978,L98);
                code.visitLabel(L5);
                code.visitConstStmt(CONST_16,13, Integer.valueOf(9)); // int: 0x00000009  float:0.000000
                code.visitConstStmt(CONST_16,12, Integer.valueOf(8)); // int: 0x00000008  float:0.000000
                code.visitConstStmt(CONST_4,11, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitConstStmt(CONST_16,10, Integer.valueOf(92)); // int: 0x0000005c  float:0.000000
                code.visitConstStmt(CONST_16,9, Integer.valueOf(34)); // int: 0x00000022  float:0.000000
                code.visitLabel(L6);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 15},new Method("Lorg/mortbay/util/ajax/JSON$Source;","next",new String[]{ },"C"));
                code.visitStmt1R(MOVE_RESULT,7);
                code.visitJumpStmt(IF_EQ,7,9,L8);
                code.visitLabel(L7);
                code.visitTypeStmt(NEW_INSTANCE,7,-1,"Ljava/lang/IllegalStateException;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 7},new Method("Ljava/lang/IllegalStateException;","<init>",new String[]{ },"V"));
                code.visitStmt1R(THROW,7);
                code.visitLabel(L8);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L9);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L10);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 15},new Method("Lorg/mortbay/util/ajax/JSON$Source;","scratchBuffer",new String[]{ },"[C"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitLabel(L11);
                code.visitJumpStmt(IF_EQZ,5,-1,L73);
                code.visitLabel(L12);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L13);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 15},new Method("Lorg/mortbay/util/ajax/JSON$Source;","hasNext",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,7);
                code.visitJumpStmt(IF_EQZ,7,-1,L18);
                code.visitLabel(L14);
                code.visitStmt2R(ARRAY_LENGTH,7,5);
                code.visitJumpStmt(IF_LT,3,7,L21);
                code.visitLabel(L15);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/lang/StringBuffer;");
                code.visitLabel(L16);
                code.visitStmt2R(ARRAY_LENGTH,7,5);
                code.visitStmt2R1N(MUL_INT_LIT8,7,7,2);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,7},new Method("Ljava/lang/StringBuffer;","<init>",new String[]{ "I"},"V"));
                code.visitLabel(L17);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,5,11,3},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "[C","I","I"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L18);
                code.visitJumpStmt(IF_NEZ,0,-1,L75);
                code.visitLabel(L19);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 14,5,11,3},new Method("Lorg/mortbay/util/ajax/JSON;","toString",new String[]{ "[C","I","I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitLabel(L20);
                code.visitStmt1R(RETURN_OBJECT,7);
                code.visitLabel(L21);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 15},new Method("Lorg/mortbay/util/ajax/JSON$Source;","next",new String[]{ },"C"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitLabel(L22);
                code.visitJumpStmt(IF_EQZ,2,-1,L66);
                code.visitLabel(L23);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L24);
                code.visitSparseSwitchStmt(SPARSE_SWITCH,1,new int[]{ 34,47,92,98,102,110,114,116,117},new DexLabel[]{L29,L37,L33,L41,L45,L49,L53,L57,L61});
                code.visitLabel(L25);
                code.visitStmt2R1N(ADD_INT_LIT8,4,3,1);
                code.visitLabel(L26);
                code.visitStmt3R(APUT_CHAR,1,5,3);
                code.visitLabel(L27);
                code.visitStmt2R(MOVE,3,4);
                code.visitLabel(L28);
                code.visitJumpStmt(GOTO,-1,-1,L13);
                code.visitLabel(L29);
                code.visitStmt2R1N(ADD_INT_LIT8,4,3,1);
                code.visitLabel(L30);
                code.visitStmt3R(APUT_CHAR,9,5,3);
                code.visitLabel(L31);
                code.visitStmt2R(MOVE,3,4);
                code.visitLabel(L32);
                code.visitJumpStmt(GOTO,-1,-1,L13);
                code.visitLabel(L33);
                code.visitStmt2R1N(ADD_INT_LIT8,4,3,1);
                code.visitLabel(L34);
                code.visitStmt3R(APUT_CHAR,10,5,3);
                code.visitLabel(L35);
                code.visitStmt2R(MOVE,3,4);
                code.visitLabel(L36);
                code.visitJumpStmt(GOTO,-1,-1,L13);
                code.visitLabel(L37);
                code.visitStmt2R1N(ADD_INT_LIT8,4,3,1);
                code.visitLabel(L38);
                code.visitConstStmt(CONST_16,7, Integer.valueOf(47)); // int: 0x0000002f  float:0.000000
                code.visitStmt3R(APUT_CHAR,7,5,3);
                code.visitLabel(L39);
                code.visitStmt2R(MOVE,3,4);
                code.visitLabel(L40);
                code.visitJumpStmt(GOTO,-1,-1,L13);
                code.visitLabel(L41);
                code.visitStmt2R1N(ADD_INT_LIT8,4,3,1);
                code.visitLabel(L42);
                code.visitStmt3R(APUT_CHAR,12,5,3);
                code.visitLabel(L43);
                code.visitStmt2R(MOVE,3,4);
                code.visitLabel(L44);
                code.visitJumpStmt(GOTO,-1,-1,L13);
                code.visitLabel(L45);
                code.visitStmt2R1N(ADD_INT_LIT8,4,3,1);
                code.visitLabel(L46);
                code.visitConstStmt(CONST_16,7, Integer.valueOf(12)); // int: 0x0000000c  float:0.000000
                code.visitStmt3R(APUT_CHAR,7,5,3);
                code.visitLabel(L47);
                code.visitStmt2R(MOVE,3,4);
                code.visitLabel(L48);
                code.visitJumpStmt(GOTO,-1,-1,L13);
                code.visitLabel(L49);
                code.visitStmt2R1N(ADD_INT_LIT8,4,3,1);
                code.visitLabel(L50);
                code.visitConstStmt(CONST_16,7, Integer.valueOf(10)); // int: 0x0000000a  float:0.000000
                code.visitStmt3R(APUT_CHAR,7,5,3);
                code.visitLabel(L51);
                code.visitStmt2R(MOVE,3,4);
                code.visitLabel(L52);
                code.visitJumpStmt(GOTO,-1,-1,L13);
                code.visitLabel(L53);
                code.visitStmt2R1N(ADD_INT_LIT8,4,3,1);
                code.visitLabel(L54);
                code.visitConstStmt(CONST_16,7, Integer.valueOf(13)); // int: 0x0000000d  float:0.000000
                code.visitStmt3R(APUT_CHAR,7,5,3);
                code.visitLabel(L55);
                code.visitStmt2R(MOVE,3,4);
                code.visitLabel(L56);
                code.visitJumpStmt(GOTO,-1,-1,L13);
                code.visitLabel(L57);
                code.visitStmt2R1N(ADD_INT_LIT8,4,3,1);
                code.visitLabel(L58);
                code.visitStmt3R(APUT_CHAR,13,5,3);
                code.visitLabel(L59);
                code.visitStmt2R(MOVE,3,4);
                code.visitLabel(L60);
                code.visitJumpStmt(GOTO,-1,-1,L13);
                code.visitLabel(L61);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 15},new Method("Lorg/mortbay/util/ajax/JSON$Source;","next",new String[]{ },"C"));
                code.visitStmt1R(MOVE_RESULT,7);
                code.visitStmt2R(INT_TO_BYTE,7,7);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 7},new Method("Lorg/mortbay/util/TypeUtil;","convertHexDigit",new String[]{ "B"},"B"));
                code.visitStmt1R(MOVE_RESULT,7);
                code.visitStmt2R1N(SHL_INT_LIT8,7,7,12);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 15},new Method("Lorg/mortbay/util/ajax/JSON$Source;","next",new String[]{ },"C"));
                code.visitStmt1R(MOVE_RESULT,8);
                code.visitStmt2R(INT_TO_BYTE,8,8);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 8},new Method("Lorg/mortbay/util/TypeUtil;","convertHexDigit",new String[]{ "B"},"B"));
                code.visitStmt1R(MOVE_RESULT,8);
                code.visitStmt2R1N(SHL_INT_LIT8,8,8,8);
                code.visitStmt2R(ADD_INT_2ADDR,7,8);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 15},new Method("Lorg/mortbay/util/ajax/JSON$Source;","next",new String[]{ },"C"));
                code.visitStmt1R(MOVE_RESULT,8);
                code.visitStmt2R(INT_TO_BYTE,8,8);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 8},new Method("Lorg/mortbay/util/TypeUtil;","convertHexDigit",new String[]{ "B"},"B"));
                code.visitStmt1R(MOVE_RESULT,8);
                code.visitStmt2R1N(SHL_INT_LIT8,8,8,4);
                code.visitStmt2R(ADD_INT_2ADDR,7,8);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 15},new Method("Lorg/mortbay/util/ajax/JSON$Source;","next",new String[]{ },"C"));
                code.visitStmt1R(MOVE_RESULT,8);
                code.visitStmt2R(INT_TO_BYTE,8,8);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 8},new Method("Lorg/mortbay/util/TypeUtil;","convertHexDigit",new String[]{ "B"},"B"));
                code.visitStmt1R(MOVE_RESULT,8);
                code.visitStmt2R(ADD_INT_2ADDR,7,8);
                code.visitStmt2R(INT_TO_CHAR,6,7);
                code.visitLabel(L62);
                code.visitStmt2R1N(ADD_INT_LIT8,4,3,1);
                code.visitLabel(L63);
                code.visitStmt3R(APUT_CHAR,6,5,3);
                code.visitLabel(L64);
                code.visitStmt2R(MOVE,3,4);
                code.visitLabel(L65);
                code.visitJumpStmt(GOTO_16,-1,-1,L13);
                code.visitLabel(L66);
                code.visitJumpStmt(IF_NE,1,10,L69);
                code.visitLabel(L67);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitLabel(L68);
                code.visitJumpStmt(GOTO_16,-1,-1,L13);
                code.visitLabel(L69);
                code.visitJumpStmt(IF_NE,1,9,L71);
                code.visitLabel(L70);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 14,5,11,3},new Method("Lorg/mortbay/util/ajax/JSON;","toString",new String[]{ "[C","I","I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitJumpStmt(GOTO_16,-1,-1,L20);
                code.visitLabel(L71);
                code.visitStmt2R1N(ADD_INT_LIT8,4,3,1);
                code.visitLabel(L72);
                code.visitStmt3R(APUT_CHAR,1,5,3);
                code.visitJumpStmt(GOTO,-1,-1,L27);
                code.visitLabel(L73);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/lang/StringBuffer;");
                code.visitLabel(L74);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 14},new Method("Lorg/mortbay/util/ajax/JSON;","getStringBufferSize",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,7);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,7},new Method("Ljava/lang/StringBuffer;","<init>",new String[]{ "I"},"V"));
                code.visitLabel(L75);
                code.visitStmt1R(MONITOR_ENTER,0);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 15},new Method("Lorg/mortbay/util/ajax/JSON$Source;","hasNext",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,7);
                code.visitJumpStmt(IF_EQZ,7,-1,L95);
                code.visitLabel(L76);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 15},new Method("Lorg/mortbay/util/ajax/JSON$Source;","next",new String[]{ },"C"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitLabel(L77);
                code.visitJumpStmt(IF_EQZ,2,-1,L91);
                code.visitLabel(L78);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L79);
                code.visitSparseSwitchStmt(SPARSE_SWITCH,1,new int[]{ 34,47,92,98,102,110,114,116,117},new DexLabel[]{L81,L83,L82,L84,L85,L86,L87,L88,L89});
                code.visitLabel(L80);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "C"},"Ljava/lang/StringBuffer;"));
                code.visitJumpStmt(GOTO,-1,-1,L0);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,7);
                code.visitStmt1R(MONITOR_EXIT,0);
                code.visitLabel(L1);
                code.visitStmt1R(THROW,7);
                code.visitLabel(L81);
                code.visitConstStmt(CONST_16,7, Integer.valueOf(34)); // int: 0x00000022  float:0.000000
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,7},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "C"},"Ljava/lang/StringBuffer;"));
                code.visitJumpStmt(GOTO,-1,-1,L0);
                code.visitLabel(L82);
                code.visitConstStmt(CONST_16,7, Integer.valueOf(92)); // int: 0x0000005c  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,7},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "C"},"Ljava/lang/StringBuffer;"));
                code.visitJumpStmt(GOTO,-1,-1,L0);
                code.visitLabel(L83);
                code.visitConstStmt(CONST_16,7, Integer.valueOf(47)); // int: 0x0000002f  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,7},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "C"},"Ljava/lang/StringBuffer;"));
                code.visitJumpStmt(GOTO,-1,-1,L0);
                code.visitLabel(L84);
                code.visitConstStmt(CONST_16,7, Integer.valueOf(8)); // int: 0x00000008  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,7},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "C"},"Ljava/lang/StringBuffer;"));
                code.visitJumpStmt(GOTO,-1,-1,L0);
                code.visitLabel(L85);
                code.visitConstStmt(CONST_16,7, Integer.valueOf(12)); // int: 0x0000000c  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,7},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "C"},"Ljava/lang/StringBuffer;"));
                code.visitJumpStmt(GOTO,-1,-1,L0);
                code.visitLabel(L86);
                code.visitConstStmt(CONST_16,7, Integer.valueOf(10)); // int: 0x0000000a  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,7},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "C"},"Ljava/lang/StringBuffer;"));
                code.visitJumpStmt(GOTO,-1,-1,L0);
                code.visitLabel(L87);
                code.visitConstStmt(CONST_16,7, Integer.valueOf(13)); // int: 0x0000000d  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,7},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "C"},"Ljava/lang/StringBuffer;"));
                code.visitJumpStmt(GOTO,-1,-1,L0);
                code.visitLabel(L88);
                code.visitConstStmt(CONST_16,7, Integer.valueOf(9)); // int: 0x00000009  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,7},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "C"},"Ljava/lang/StringBuffer;"));
                code.visitJumpStmt(GOTO,-1,-1,L0);
                code.visitLabel(L89);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 15},new Method("Lorg/mortbay/util/ajax/JSON$Source;","next",new String[]{ },"C"));
                code.visitStmt1R(MOVE_RESULT,7);
                code.visitStmt2R(INT_TO_BYTE,7,7);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 7},new Method("Lorg/mortbay/util/TypeUtil;","convertHexDigit",new String[]{ "B"},"B"));
                code.visitStmt1R(MOVE_RESULT,7);
                code.visitStmt2R1N(SHL_INT_LIT8,7,7,12);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 15},new Method("Lorg/mortbay/util/ajax/JSON$Source;","next",new String[]{ },"C"));
                code.visitStmt1R(MOVE_RESULT,8);
                code.visitStmt2R(INT_TO_BYTE,8,8);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 8},new Method("Lorg/mortbay/util/TypeUtil;","convertHexDigit",new String[]{ "B"},"B"));
                code.visitStmt1R(MOVE_RESULT,8);
                code.visitStmt2R1N(SHL_INT_LIT8,8,8,8);
                code.visitStmt2R(ADD_INT_2ADDR,7,8);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 15},new Method("Lorg/mortbay/util/ajax/JSON$Source;","next",new String[]{ },"C"));
                code.visitStmt1R(MOVE_RESULT,8);
                code.visitStmt2R(INT_TO_BYTE,8,8);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 8},new Method("Lorg/mortbay/util/TypeUtil;","convertHexDigit",new String[]{ "B"},"B"));
                code.visitStmt1R(MOVE_RESULT,8);
                code.visitStmt2R1N(SHL_INT_LIT8,8,8,4);
                code.visitStmt2R(ADD_INT_2ADDR,7,8);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 15},new Method("Lorg/mortbay/util/ajax/JSON$Source;","next",new String[]{ },"C"));
                code.visitStmt1R(MOVE_RESULT,8);
                code.visitStmt2R(INT_TO_BYTE,8,8);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 8},new Method("Lorg/mortbay/util/TypeUtil;","convertHexDigit",new String[]{ "B"},"B"));
                code.visitStmt1R(MOVE_RESULT,8);
                code.visitStmt2R(ADD_INT_2ADDR,7,8);
                code.visitStmt2R(INT_TO_CHAR,6,7);
                code.visitLabel(L90);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,6},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "C"},"Ljava/lang/StringBuffer;"));
                code.visitJumpStmt(GOTO,-1,-1,L0);
                code.visitLabel(L91);
                code.visitJumpStmt(IF_NE,1,10,L94);
                code.visitLabel(L92);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitLabel(L93);
                code.visitJumpStmt(GOTO,-1,-1,L0);
                code.visitLabel(L94);
                code.visitJumpStmt(IF_NE,1,9,L96);
                code.visitLabel(L95);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/lang/StringBuffer;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitStmt1R(MONITOR_EXIT,0);
                code.visitJumpStmt(GOTO_16,-1,-1,L20);
                code.visitLabel(L96);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "C"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L4);
                code.visitJumpStmt(GOTO_16,-1,-1,L0);
                code.visitLabel(L97);
                code.visitLabel(L98);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m042_seekTo(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Lorg/mortbay/util/ajax/JSON;","seekTo",new String[]{ "Ljava/lang/String;","Lorg/mortbay/util/ajax/JSON$Source;"},"C"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(8);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"seek");
                ddv.visitParameterName(1,"source");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(1134,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(1136,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(1137,L3);
                ddv.visitStartLocal(0,L3,"c","C",null);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(1139,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(1142,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(1143,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(1144,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(1147,L8);
                ddv.visitEndLocal(0,L8);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_STRING,4,"\'");
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 7},new Method("Lorg/mortbay/util/ajax/JSON$Source;","hasNext",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitJumpStmt(IF_EQZ,1,-1,L8);
                code.visitLabel(L2);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 7},new Method("Lorg/mortbay/util/ajax/JSON$Source;","peek",new String[]{ },"C"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,0},new Method("Ljava/lang/String;","indexOf",new String[]{ "I"},"I"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitJumpStmt(IF_LTZ,1,-1,L5);
                code.visitLabel(L4);
                code.visitStmt1R(RETURN,0);
                code.visitLabel(L5);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0},new Method("Ljava/lang/Character;","isWhitespace",new String[]{ "C"},"Z"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitJumpStmt(IF_NEZ,1,-1,L7);
                code.visitLabel(L6);
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Ljava/lang/IllegalStateException;");
                code.visitTypeStmt(NEW_INSTANCE,2,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,3,"Unexpected \'");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,0},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "C"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitConstStmt(CONST_STRING,3,"\' while seeking one of \'");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,6},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitConstStmt(CONST_STRING,3,"\'");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,4},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1,2},new Method("Ljava/lang/IllegalStateException;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitStmt1R(THROW,1);
                code.visitLabel(L7);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 7},new Method("Lorg/mortbay/util/ajax/JSON$Source;","next",new String[]{ },"C"));
                code.visitJumpStmt(GOTO,-1,-1,L1);
                code.visitLabel(L8);
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Ljava/lang/IllegalStateException;");
                code.visitTypeStmt(NEW_INSTANCE,2,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,3,"Expected one of \'");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,6},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitConstStmt(CONST_STRING,3,"\'");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,4},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1,2},new Method("Ljava/lang/IllegalStateException;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitStmt1R(THROW,1);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m043_seekTo(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Lorg/mortbay/util/ajax/JSON;","seekTo",new String[]{ "C","Lorg/mortbay/util/ajax/JSON$Source;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(8);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"seek");
                ddv.visitParameterName(1,"source");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(1118,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(1120,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(1121,L3);
                ddv.visitStartLocal(0,L3,"c","C",null);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(1122,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(1124,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(1125,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(1126,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(1129,L8);
                ddv.visitEndLocal(0,L8);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_STRING,4,"\'");
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 7},new Method("Lorg/mortbay/util/ajax/JSON$Source;","hasNext",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitJumpStmt(IF_EQZ,1,-1,L8);
                code.visitLabel(L2);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 7},new Method("Lorg/mortbay/util/ajax/JSON$Source;","peek",new String[]{ },"C"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitLabel(L3);
                code.visitJumpStmt(IF_NE,0,6,L5);
                code.visitLabel(L4);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L5);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0},new Method("Ljava/lang/Character;","isWhitespace",new String[]{ "C"},"Z"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitJumpStmt(IF_NEZ,1,-1,L7);
                code.visitLabel(L6);
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Ljava/lang/IllegalStateException;");
                code.visitTypeStmt(NEW_INSTANCE,2,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,3,"Unexpected \'");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,0},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "C"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitConstStmt(CONST_STRING,3," while seeking \'");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,6},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "C"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitConstStmt(CONST_STRING,3,"\'");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,4},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1,2},new Method("Ljava/lang/IllegalStateException;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitStmt1R(THROW,1);
                code.visitLabel(L7);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 7},new Method("Lorg/mortbay/util/ajax/JSON$Source;","next",new String[]{ },"C"));
                code.visitJumpStmt(GOTO,-1,-1,L1);
                code.visitLabel(L8);
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Ljava/lang/IllegalStateException;");
                code.visitTypeStmt(NEW_INSTANCE,2,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,3,"Expected \'");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,6},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "C"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitConstStmt(CONST_STRING,3,"\'");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,4},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1,2},new Method("Ljava/lang/IllegalStateException;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitStmt1R(THROW,1);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m044_setStringBufferSize(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/util/ajax/JSON;","setStringBufferSize",new String[]{ "I"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"stringBufferSize");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(102,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(103,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT,1,0,new Field("Lorg/mortbay/util/ajax/JSON;","_stringBufferSize","I"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m045_toJSON(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/util/ajax/JSON;","toJSON",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"object");
                DexLabel L3=new DexLabel();
                ddv.visitPrologue(L3);
                ddv.visitLineNumber(224,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(225,L4);
                ddv.visitStartLocal(0,L4,"buffer","Ljava/lang/StringBuffer;",null);
                ddv.visitLineNumber(227,L0);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(228,L5);
                ddv.visitLineNumber(229,L2);
                code.visitLabel(L3);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/lang/StringBuffer;");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/util/ajax/JSON;","getStringBufferSize",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1},new Method("Ljava/lang/StringBuffer;","<init>",new String[]{ "I"},"V"));
                code.visitLabel(L4);
                code.visitStmt1R(MONITOR_ENTER,0);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,0,3},new Method("Lorg/mortbay/util/ajax/JSON;","append",new String[]{ "Ljava/lang/StringBuffer;","Ljava/lang/Object;"},"V"));
                code.visitLabel(L5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/lang/StringBuffer;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitStmt1R(MONITOR_EXIT,0);
                code.visitStmt1R(RETURN_OBJECT,1);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,1);
                code.visitStmt1R(MONITOR_EXIT,0);
                code.visitLabel(L1);
                code.visitStmt1R(THROW,1);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m046_toString(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Lorg/mortbay/util/ajax/JSON;","toString",new String[]{ "[C","I","I"},"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"buffer");
                ddv.visitParameterName(1,"offset");
                ddv.visitParameterName(2,"length");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(486,L0);
                code.visitLabel(L0);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/lang/String;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,2,3,4},new Method("Ljava/lang/String;","<init>",new String[]{ "[C","I","I"},"V"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
