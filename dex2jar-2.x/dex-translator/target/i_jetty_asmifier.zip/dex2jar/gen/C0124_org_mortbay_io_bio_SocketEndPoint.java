package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0124_org_mortbay_io_bio_SocketEndPoint {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(ACC_PUBLIC,"Lorg/mortbay/io/bio/SocketEndPoint;","Lorg/mortbay/io/bio/StreamEndPoint;",new String[]{ });
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("SocketEndPoint.java");
        f000__local(cv);
        f001__remote(cv);
        f002__socket(cv);
        m000__init_(cv);
        m001_close(cv);
        m002_getLocalAddr(cv);
        m003_getLocalHost(cv);
        m004_getLocalPort(cv);
        m005_getRemoteAddr(cv);
        m006_getRemoteHost(cv);
        m007_getRemotePort(cv);
        m008_getTransport(cv);
        m009_isOpen(cv);
    }
    public static void f000__local(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(0, new Field("Lorg/mortbay/io/bio/SocketEndPoint;","_local","Ljava/net/InetSocketAddress;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f001__remote(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(0, new Field("Lorg/mortbay/io/bio/SocketEndPoint;","_remote","Ljava/net/InetSocketAddress;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f002__socket(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(0, new Field("Lorg/mortbay/io/bio/SocketEndPoint;","_socket","Ljava/net/Socket;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void m000__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/io/bio/SocketEndPoint;","<init>",new String[]{ "Ljava/net/Socket;"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"socket");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(44,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(45,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(46,L2);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Ljava/net/Socket;","getInputStream",new String[]{ },"Ljava/io/InputStream;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Ljava/net/Socket;","getOutputStream",new String[]{ },"Ljava/io/OutputStream;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2,0,1},new Method("Lorg/mortbay/io/bio/StreamEndPoint;","<init>",new String[]{ "Ljava/io/InputStream;","Ljava/io/OutputStream;"},"V"));
                code.visitLabel(L1);
                code.visitFieldStmt(IPUT_OBJECT,3,2,new Field("Lorg/mortbay/io/bio/SocketEndPoint;","_socket","Ljava/net/Socket;"));
                code.visitLabel(L2);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001_close(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/io/bio/SocketEndPoint;","close",new String[]{ },"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                DexLabel L3=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2,L3},new String[]{ "Ljava/io/IOException;","Ljava/lang/UnsupportedOperationException;"});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L4=new DexLabel();
                ddv.visitPrologue(L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(61,L5);
                ddv.visitLineNumber(65,L0);
                ddv.visitLineNumber(76,L1);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(77,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(78,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(80,L8);
                ddv.visitLineNumber(67,L2);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(69,L9);
                ddv.visitStartLocal(0,L9,"e","Ljava/io/IOException;",null);
                ddv.visitLineNumber(71,L3);
                ddv.visitEndLocal(0,L3);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(73,L10);
                ddv.visitStartLocal(0,L10,"e","Ljava/lang/UnsupportedOperationException;",null);
                code.visitLabel(L4);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L5);
                code.visitFieldStmt(IGET_OBJECT,1,3,new Field("Lorg/mortbay/io/bio/SocketEndPoint;","_socket","Ljava/net/Socket;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/net/Socket;","isClosed",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitJumpStmt(IF_NEZ,1,-1,L1);
                code.visitFieldStmt(IGET_OBJECT,1,3,new Field("Lorg/mortbay/io/bio/SocketEndPoint;","_socket","Ljava/net/Socket;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/net/Socket;","isOutputShutdown",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitJumpStmt(IF_NEZ,1,-1,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,1,3,new Field("Lorg/mortbay/io/bio/SocketEndPoint;","_socket","Ljava/net/Socket;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/net/Socket;","shutdownOutput",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,1,3,new Field("Lorg/mortbay/io/bio/SocketEndPoint;","_socket","Ljava/net/Socket;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/net/Socket;","close",new String[]{ },"V"));
                code.visitLabel(L6);
                code.visitFieldStmt(IPUT_OBJECT,2,3,new Field("Lorg/mortbay/io/bio/SocketEndPoint;","_in","Ljava/io/InputStream;"));
                code.visitLabel(L7);
                code.visitFieldStmt(IPUT_OBJECT,2,3,new Field("Lorg/mortbay/io/bio/SocketEndPoint;","_out","Ljava/io/OutputStream;"));
                code.visitLabel(L8);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,1);
                code.visitStmt2R(MOVE_OBJECT,0,1);
                code.visitLabel(L9);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0},new Method("Lorg/mortbay/log/Log;","ignore",new String[]{ "Ljava/lang/Throwable;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L1);
                code.visitLabel(L3);
                code.visitStmt1R(MOVE_EXCEPTION,1);
                code.visitStmt2R(MOVE_OBJECT,0,1);
                code.visitLabel(L10);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0},new Method("Lorg/mortbay/log/Log;","ignore",new String[]{ "Ljava/lang/Throwable;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L1);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m002_getLocalAddr(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/io/bio/SocketEndPoint;","getLocalAddr",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(89,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(90,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(92,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(93,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(95,L4);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/io/bio/SocketEndPoint;","_local","Ljava/net/InetSocketAddress;"));
                code.visitJumpStmt(IF_NEZ,0,-1,L2);
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/io/bio/SocketEndPoint;","_socket","Ljava/net/Socket;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/net/Socket;","getLocalSocketAddress",new String[]{ },"Ljava/net/SocketAddress;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitTypeStmt(CHECK_CAST,0,-1,"Ljava/net/InetSocketAddress;");
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/io/bio/SocketEndPoint;","_local","Ljava/net/InetSocketAddress;"));
                code.visitLabel(L2);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/io/bio/SocketEndPoint;","_local","Ljava/net/InetSocketAddress;"));
                code.visitJumpStmt(IF_EQZ,0,-1,L3);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/io/bio/SocketEndPoint;","_local","Ljava/net/InetSocketAddress;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/net/InetSocketAddress;","getAddress",new String[]{ },"Ljava/net/InetAddress;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitJumpStmt(IF_EQZ,0,-1,L3);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/io/bio/SocketEndPoint;","_local","Ljava/net/InetSocketAddress;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/net/InetSocketAddress;","getAddress",new String[]{ },"Ljava/net/InetAddress;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/net/InetAddress;","isAnyLocalAddress",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                DexLabel L5=new DexLabel();
                code.visitJumpStmt(IF_EQZ,0,-1,L5);
                code.visitLabel(L3);
                code.visitConstStmt(CONST_STRING,0,"0.0.0.0");
                code.visitLabel(L4);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitLabel(L5);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/io/bio/SocketEndPoint;","_local","Ljava/net/InetSocketAddress;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/net/InetSocketAddress;","getAddress",new String[]{ },"Ljava/net/InetAddress;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/net/InetAddress;","getHostAddress",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitJumpStmt(GOTO,-1,-1,L4);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m003_getLocalHost(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/io/bio/SocketEndPoint;","getLocalHost",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(104,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(105,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(107,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(108,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(110,L4);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/io/bio/SocketEndPoint;","_local","Ljava/net/InetSocketAddress;"));
                code.visitJumpStmt(IF_NEZ,0,-1,L2);
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/io/bio/SocketEndPoint;","_socket","Ljava/net/Socket;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/net/Socket;","getLocalSocketAddress",new String[]{ },"Ljava/net/SocketAddress;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitTypeStmt(CHECK_CAST,0,-1,"Ljava/net/InetSocketAddress;");
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/io/bio/SocketEndPoint;","_local","Ljava/net/InetSocketAddress;"));
                code.visitLabel(L2);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/io/bio/SocketEndPoint;","_local","Ljava/net/InetSocketAddress;"));
                code.visitJumpStmt(IF_EQZ,0,-1,L3);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/io/bio/SocketEndPoint;","_local","Ljava/net/InetSocketAddress;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/net/InetSocketAddress;","getAddress",new String[]{ },"Ljava/net/InetAddress;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitJumpStmt(IF_EQZ,0,-1,L3);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/io/bio/SocketEndPoint;","_local","Ljava/net/InetSocketAddress;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/net/InetSocketAddress;","getAddress",new String[]{ },"Ljava/net/InetAddress;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/net/InetAddress;","isAnyLocalAddress",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                DexLabel L5=new DexLabel();
                code.visitJumpStmt(IF_EQZ,0,-1,L5);
                code.visitLabel(L3);
                code.visitConstStmt(CONST_STRING,0,"0.0.0.0");
                code.visitLabel(L4);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitLabel(L5);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/io/bio/SocketEndPoint;","_local","Ljava/net/InetSocketAddress;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/net/InetSocketAddress;","getAddress",new String[]{ },"Ljava/net/InetAddress;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/net/InetAddress;","getCanonicalHostName",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitJumpStmt(GOTO,-1,-1,L4);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m004_getLocalPort(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/io/bio/SocketEndPoint;","getLocalPort",new String[]{ },"I"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(119,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(120,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(121,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(122,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(123,L4);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/io/bio/SocketEndPoint;","_local","Ljava/net/InetSocketAddress;"));
                code.visitJumpStmt(IF_NEZ,0,-1,L2);
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/io/bio/SocketEndPoint;","_socket","Ljava/net/Socket;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/net/Socket;","getLocalSocketAddress",new String[]{ },"Ljava/net/SocketAddress;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitTypeStmt(CHECK_CAST,0,-1,"Ljava/net/InetSocketAddress;");
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/io/bio/SocketEndPoint;","_local","Ljava/net/InetSocketAddress;"));
                code.visitLabel(L2);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/io/bio/SocketEndPoint;","_local","Ljava/net/InetSocketAddress;"));
                DexLabel L5=new DexLabel();
                code.visitJumpStmt(IF_NEZ,0,-1,L5);
                code.visitLabel(L3);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(-1)); // int: 0xffffffff  float:NaN
                code.visitLabel(L4);
                code.visitStmt1R(RETURN,0);
                code.visitLabel(L5);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/io/bio/SocketEndPoint;","_local","Ljava/net/InetSocketAddress;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/net/InetSocketAddress;","getPort",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(GOTO,-1,-1,L4);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m005_getRemoteAddr(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/io/bio/SocketEndPoint;","getRemoteAddr",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(132,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(133,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(134,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(137,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(136,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(137,L6);
                ddv.visitStartLocal(0,L6,"addr","Ljava/net/InetAddress;",null);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,1,3,new Field("Lorg/mortbay/io/bio/SocketEndPoint;","_remote","Ljava/net/InetSocketAddress;"));
                code.visitJumpStmt(IF_NEZ,1,-1,L3);
                code.visitLabel(L2);
                code.visitFieldStmt(IGET_OBJECT,1,3,new Field("Lorg/mortbay/io/bio/SocketEndPoint;","_socket","Ljava/net/Socket;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/net/Socket;","getRemoteSocketAddress",new String[]{ },"Ljava/net/SocketAddress;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitTypeStmt(CHECK_CAST,1,-1,"Ljava/net/InetSocketAddress;");
                code.visitFieldStmt(IPUT_OBJECT,1,3,new Field("Lorg/mortbay/io/bio/SocketEndPoint;","_remote","Ljava/net/InetSocketAddress;"));
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,1,3,new Field("Lorg/mortbay/io/bio/SocketEndPoint;","_remote","Ljava/net/InetSocketAddress;"));
                code.visitJumpStmt(IF_NEZ,1,-1,L5);
                code.visitStmt2R(MOVE_OBJECT,1,2);
                code.visitLabel(L4);
                code.visitStmt1R(RETURN_OBJECT,1);
                code.visitLabel(L5);
                code.visitFieldStmt(IGET_OBJECT,1,3,new Field("Lorg/mortbay/io/bio/SocketEndPoint;","_remote","Ljava/net/InetSocketAddress;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/net/InetSocketAddress;","getAddress",new String[]{ },"Ljava/net/InetAddress;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L6);
                DexLabel L7=new DexLabel();
                code.visitJumpStmt(IF_NEZ,0,-1,L7);
                code.visitStmt2R(MOVE_OBJECT,1,2);
                code.visitJumpStmt(GOTO,-1,-1,L4);
                code.visitLabel(L7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/net/InetAddress;","getHostAddress",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitJumpStmt(GOTO,-1,-1,L4);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m006_getRemoteHost(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/io/bio/SocketEndPoint;","getRemoteHost",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(146,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(147,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(148,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(149,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(150,L4);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/io/bio/SocketEndPoint;","_remote","Ljava/net/InetSocketAddress;"));
                code.visitJumpStmt(IF_NEZ,0,-1,L2);
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/io/bio/SocketEndPoint;","_socket","Ljava/net/Socket;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/net/Socket;","getRemoteSocketAddress",new String[]{ },"Ljava/net/SocketAddress;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitTypeStmt(CHECK_CAST,0,-1,"Ljava/net/InetSocketAddress;");
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/io/bio/SocketEndPoint;","_remote","Ljava/net/InetSocketAddress;"));
                code.visitLabel(L2);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/io/bio/SocketEndPoint;","_remote","Ljava/net/InetSocketAddress;"));
                DexLabel L5=new DexLabel();
                code.visitJumpStmt(IF_NEZ,0,-1,L5);
                code.visitLabel(L3);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L4);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitLabel(L5);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/io/bio/SocketEndPoint;","_remote","Ljava/net/InetSocketAddress;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/net/InetSocketAddress;","getAddress",new String[]{ },"Ljava/net/InetAddress;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/net/InetAddress;","getCanonicalHostName",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitJumpStmt(GOTO,-1,-1,L4);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m007_getRemotePort(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/io/bio/SocketEndPoint;","getRemotePort",new String[]{ },"I"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(159,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(160,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(161,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(162,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(163,L4);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/io/bio/SocketEndPoint;","_remote","Ljava/net/InetSocketAddress;"));
                code.visitJumpStmt(IF_NEZ,0,-1,L2);
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/io/bio/SocketEndPoint;","_socket","Ljava/net/Socket;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/net/Socket;","getRemoteSocketAddress",new String[]{ },"Ljava/net/SocketAddress;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitTypeStmt(CHECK_CAST,0,-1,"Ljava/net/InetSocketAddress;");
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/io/bio/SocketEndPoint;","_remote","Ljava/net/InetSocketAddress;"));
                code.visitLabel(L2);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/io/bio/SocketEndPoint;","_remote","Ljava/net/InetSocketAddress;"));
                DexLabel L5=new DexLabel();
                code.visitJumpStmt(IF_NEZ,0,-1,L5);
                code.visitLabel(L3);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(-1)); // int: 0xffffffff  float:NaN
                code.visitLabel(L4);
                code.visitStmt1R(RETURN,0);
                code.visitLabel(L5);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/io/bio/SocketEndPoint;","_remote","Ljava/net/InetSocketAddress;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/net/InetSocketAddress;","getPort",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(GOTO,-1,-1,L4);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m008_getTransport(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/io/bio/SocketEndPoint;","getTransport",new String[]{ },"Ljava/lang/Object;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(172,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/io/bio/SocketEndPoint;","_socket","Ljava/net/Socket;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m009_isOpen(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/io/bio/SocketEndPoint;","isOpen",new String[]{ },"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(53,L0);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_SUPER,new int[]{ 1},new Method("Lorg/mortbay/io/bio/StreamEndPoint;","isOpen",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                DexLabel L1=new DexLabel();
                code.visitJumpStmt(IF_EQZ,0,-1,L1);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/io/bio/SocketEndPoint;","_socket","Ljava/net/Socket;"));
                code.visitJumpStmt(IF_EQZ,0,-1,L1);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/io/bio/SocketEndPoint;","_socket","Ljava/net/Socket;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/net/Socket;","isClosed",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_NEZ,0,-1,L1);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/io/bio/SocketEndPoint;","_socket","Ljava/net/Socket;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/net/Socket;","isInputShutdown",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_NEZ,0,-1,L1);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/io/bio/SocketEndPoint;","_socket","Ljava/net/Socket;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/net/Socket;","isOutputShutdown",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_NEZ,0,-1,L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                DexLabel L2=new DexLabel();
                code.visitLabel(L2);
                code.visitStmt1R(RETURN,0);
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
