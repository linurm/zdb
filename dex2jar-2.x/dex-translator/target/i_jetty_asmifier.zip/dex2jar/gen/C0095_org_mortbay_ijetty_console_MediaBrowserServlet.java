package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0095_org_mortbay_ijetty_console_MediaBrowserServlet {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(ACC_PUBLIC,"Lorg/mortbay/ijetty/console/MediaBrowserServlet;","Ljavax/servlet/http/HttpServlet;",new String[]{ });
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("MediaBrowserServlet.java");
        f000___MEDIA_LABELS(cv);
        f001___MEDIA_URIS(cv);
        f002_resolver(cv);
        m000__init_(cv);
        m001_doBody(cv);
        m002_doGet(cv);
        m003_getContentResolver(cv);
        m004_init(cv);
    }
    public static void f000___MEDIA_LABELS(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/ijetty/console/MediaBrowserServlet;","__MEDIA_LABELS","[Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f001___MEDIA_URIS(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/ijetty/console/MediaBrowserServlet;","__MEDIA_URIS","[Landroid/net/Uri;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f002_resolver(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/ijetty/console/MediaBrowserServlet;","resolver","Landroid/content/ContentResolver;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void m000__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/ijetty/console/MediaBrowserServlet;","<init>",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(8);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(45,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(47,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(56,L3);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,6, Integer.valueOf(3)); // int: 0x00000003  float:0.000000
                code.visitConstStmt(CONST_4,5, Integer.valueOf(2)); // int: 0x00000002  float:0.000000
                code.visitConstStmt(CONST_4,4, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitConstStmt(CONST_4,3, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 7},new Method("Ljavax/servlet/http/HttpServlet;","<init>",new String[]{ },"V"));
                code.visitLabel(L2);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(6)); // int: 0x00000006  float:0.000000
                code.visitTypeStmt(NEW_ARRAY,0,0,"[Landroid/net/Uri;");
                code.visitFieldStmt(SGET_OBJECT,1,-1,new Field("Landroid/provider/MediaStore$Images$Media;","EXTERNAL_CONTENT_URI","Landroid/net/Uri;"));
                code.visitStmt3R(APUT_OBJECT,1,0,3);
                code.visitFieldStmt(SGET_OBJECT,1,-1,new Field("Landroid/provider/MediaStore$Images$Media;","INTERNAL_CONTENT_URI","Landroid/net/Uri;"));
                code.visitStmt3R(APUT_OBJECT,1,0,4);
                code.visitFieldStmt(SGET_OBJECT,1,-1,new Field("Landroid/provider/MediaStore$Audio$Media;","EXTERNAL_CONTENT_URI","Landroid/net/Uri;"));
                code.visitStmt3R(APUT_OBJECT,1,0,5);
                code.visitFieldStmt(SGET_OBJECT,1,-1,new Field("Landroid/provider/MediaStore$Audio$Media;","INTERNAL_CONTENT_URI","Landroid/net/Uri;"));
                code.visitStmt3R(APUT_OBJECT,1,0,6);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(4)); // int: 0x00000004  float:0.000000
                code.visitFieldStmt(SGET_OBJECT,2,-1,new Field("Landroid/provider/MediaStore$Video$Media;","EXTERNAL_CONTENT_URI","Landroid/net/Uri;"));
                code.visitStmt3R(APUT_OBJECT,2,0,1);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(5)); // int: 0x00000005  float:0.000000
                code.visitFieldStmt(SGET_OBJECT,2,-1,new Field("Landroid/provider/MediaStore$Video$Media;","INTERNAL_CONTENT_URI","Landroid/net/Uri;"));
                code.visitStmt3R(APUT_OBJECT,2,0,1);
                code.visitFieldStmt(IPUT_OBJECT,0,7,new Field("Lorg/mortbay/ijetty/console/MediaBrowserServlet;","__MEDIA_URIS","[Landroid/net/Uri;"));
                code.visitLabel(L3);
                code.visitTypeStmt(NEW_ARRAY,0,6,"[Ljava/lang/String;");
                code.visitConstStmt(CONST_STRING,1,"Images");
                code.visitStmt3R(APUT_OBJECT,1,0,3);
                code.visitConstStmt(CONST_STRING,1,"Audio");
                code.visitStmt3R(APUT_OBJECT,1,0,4);
                code.visitConstStmt(CONST_STRING,1,"Video");
                code.visitStmt3R(APUT_OBJECT,1,0,5);
                code.visitFieldStmt(IPUT_OBJECT,0,7,new Field("Lorg/mortbay/ijetty/console/MediaBrowserServlet;","__MEDIA_LABELS","[Ljava/lang/String;"));
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001_doBody(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Lorg/mortbay/ijetty/console/MediaBrowserServlet;","doBody",new String[]{ "Ljavax/servlet/http/HttpServletRequest;","Ljavax/servlet/http/HttpServletResponse;"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljavax/servlet/ServletException;"));
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(22);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"request");
                ddv.visitParameterName(1,"response");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(120,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(121,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(122,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(123,L3);
                ddv.visitStartLocal(18,L3,"writer","Ljava/io/PrintWriter;",null);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(124,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(126,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(128,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(129,L7);
                ddv.visitStartLocal(17,L7,"type","Ljava/lang/Integer;",null);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(130,L8);
                ddv.visitStartLocal(10,L8,"count","I",null);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(132,L9);
                ddv.visitStartLocal(15,L9,"new_list","Z",null);
                DexLabel L10=new DexLabel();
                ddv.visitStartLocal(9,L10,"arr$","[Landroid/net/Uri;",null);
                DexLabel L11=new DexLabel();
                ddv.visitStartLocal(13,L11,"len$","I",null);
                DexLabel L12=new DexLabel();
                ddv.visitStartLocal(12,L12,"i$","I",null);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(134,L13);
                ddv.visitStartLocal(4,L13,"contenturi","Landroid/net/Uri;",null);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(136,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(137,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(140,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(141,L17);
                ddv.visitEndLocal(4,L17);
                ddv.visitStartLocal(11,L17,"cur","Landroid/database/Cursor;",null);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(143,L18);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(144,L19);
                ddv.visitStartLocal(16,L19,"rowid","Ljava/lang/Long;",null);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(146,L20);
                ddv.visitStartLocal(14,L20,"name","Ljava/lang/String;",null);
                DexLabel L21=new DexLabel();
                ddv.visitLineNumber(147,L21);
                DexLabel L22=new DexLabel();
                ddv.visitLineNumber(148,L22);
                DexLabel L23=new DexLabel();
                ddv.visitLineNumber(150,L23);
                ddv.visitEndLocal(16,L23);
                ddv.visitEndLocal(14,L23);
                DexLabel L24=new DexLabel();
                ddv.visitLineNumber(152,L24);
                DexLabel L25=new DexLabel();
                ddv.visitLineNumber(154,L25);
                DexLabel L26=new DexLabel();
                ddv.visitLineNumber(155,L26);
                DexLabel L27=new DexLabel();
                ddv.visitLineNumber(156,L27);
                DexLabel L28=new DexLabel();
                ddv.visitLineNumber(158,L28);
                DexLabel L29=new DexLabel();
                ddv.visitLineNumber(132,L29);
                DexLabel L30=new DexLabel();
                ddv.visitLineNumber(162,L30);
                ddv.visitEndLocal(11,L30);
                DexLabel L31=new DexLabel();
                ddv.visitLineNumber(164,L31);
                DexLabel L32=new DexLabel();
                ddv.visitLineNumber(165,L32);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_STRING,3,"text/html");
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,21);
                code.visitStmt2R(MOVE_OBJECT,1,3);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,1},new Method("Ljavax/servlet/http/HttpServletResponse;","setContentType",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L1);
                code.visitConstStmt(CONST_16,3, Integer.valueOf(200)); // int: 0x000000c8  float:0.000000
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,21);
                code.visitStmt2R(MOVE,1,3);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,1},new Method("Ljavax/servlet/http/HttpServletResponse;","setStatus",new String[]{ "I"},"V"));
                code.visitLabel(L2);
                code.visitMethodStmt(INVOKE_INTERFACE_RANGE,new int[]{ 21},new Method("Ljavax/servlet/http/HttpServletResponse;","getWriter",new String[]{ },"Ljava/io/PrintWriter;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,18);
                code.visitLabel(L3);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,18);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,20);
                code.visitStmt2R(MOVE_OBJECT_FROM16,2,21);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0,1,2},new Method("Lorg/mortbay/ijetty/console/HTMLHelper;","doHeader",new String[]{ "Ljava/io/PrintWriter;","Ljavax/servlet/http/HttpServletRequest;","Ljavax/servlet/http/HttpServletResponse;"},"V"));
                code.visitLabel(L4);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,18);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,20);
                code.visitStmt2R(MOVE_OBJECT_FROM16,2,21);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0,1,2},new Method("Lorg/mortbay/ijetty/console/HTMLHelper;","doMenuBar",new String[]{ "Ljava/io/PrintWriter;","Ljavax/servlet/http/HttpServletRequest;","Ljavax/servlet/http/HttpServletResponse;"},"V"));
                code.visitLabel(L5);
                code.visitConstStmt(CONST_STRING,3,"<h1 class=\'pageheader\'>Media</h1><div id=\'content\'>");
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,18);
                code.visitStmt2R(MOVE_OBJECT,1,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/io/PrintWriter;","println",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L6);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 3},new Method("Ljava/lang/Integer;","valueOf",new String[]{ "I"},"Ljava/lang/Integer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,17);
                code.visitLabel(L7);
                code.visitConstStmt(CONST_4,10, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L8);
                code.visitConstStmt(CONST_4,15, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitLabel(L9);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,19);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/ijetty/console/MediaBrowserServlet;","__MEDIA_URIS","[Landroid/net/Uri;"));
                code.visitStmt2R(MOVE_OBJECT,9,0);
                code.visitLabel(L10);
                code.visitStmt2R(ARRAY_LENGTH,13,9);
                code.visitLabel(L11);
                code.visitConstStmt(CONST_4,12, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L12);
                code.visitJumpStmt(IF_GE,12,13,L30);
                code.visitStmt3R(AGET_OBJECT,4,9,12);
                code.visitLabel(L13);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 17},new Method("Ljava/lang/Integer;","intValue",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitStmt2R1N(REM_INT_LIT8,3,3,2);
                code.visitJumpStmt(IF_NEZ,3,-1,L16);
                code.visitLabel(L14);
                code.visitTypeStmt(NEW_INSTANCE,3,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 3},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,5,"<h2>");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,5},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,19);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/ijetty/console/MediaBrowserServlet;","__MEDIA_LABELS","[Ljava/lang/String;"));
                code.visitStmt2R(MOVE_OBJECT,5,0);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 17},new Method("Ljava/lang/Integer;","intValue",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,6);
                code.visitStmt2R1N(DIV_INT_LIT8,6,6,2);
                code.visitStmt3R(AGET_OBJECT,5,5,6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,5},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitConstStmt(CONST_STRING,5,"</h2>");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,5},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,18);
                code.visitStmt2R(MOVE_OBJECT,1,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/io/PrintWriter;","println",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L15);
                code.visitConstStmt(CONST_STRING,3,"<ul>");
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,18);
                code.visitStmt2R(MOVE_OBJECT,1,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/io/PrintWriter;","println",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L16);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,19);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/ijetty/console/MediaBrowserServlet;","resolver","Landroid/content/ContentResolver;"));
                code.visitStmt2R(MOVE_OBJECT,3,0);
                code.visitConstStmt(CONST_4,5, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitConstStmt(CONST_4,6, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitConstStmt(CONST_4,7, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitConstStmt(CONST_4,8, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 3,4,5,6,7,8},new Method("Landroid/content/ContentResolver;","query",new String[]{ "Landroid/net/Uri;","[Ljava/lang/String;","Ljava/lang/String;","[Ljava/lang/String;","Ljava/lang/String;"},"Landroid/database/Cursor;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,11);
                code.visitLabel(L17);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 11},new Method("Landroid/database/Cursor;","moveToNext",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitJumpStmt(IF_EQZ,3,-1,L23);
                code.visitLabel(L18);
                code.visitConstStmt(CONST_STRING,3,"_id");
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 11,3},new Method("Landroid/database/Cursor;","getColumnIndexOrThrow",new String[]{ "Ljava/lang/String;"},"I"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 11,3},new Method("Landroid/database/Cursor;","getLong",new String[]{ "I"},"J"));
                code.visitStmt1R(MOVE_RESULT_WIDE,5);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 5,6},new Method("Ljava/lang/Long;","valueOf",new String[]{ "J"},"Ljava/lang/Long;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,16);
                code.visitLabel(L19);
                code.visitConstStmt(CONST_STRING,3,"_display_name");
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 11,3},new Method("Landroid/database/Cursor;","getColumnIndexOrThrow",new String[]{ "Ljava/lang/String;"},"I"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 11,3},new Method("Landroid/database/Cursor;","getString",new String[]{ "I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,14);
                code.visitLabel(L20);
                code.visitTypeStmt(NEW_INSTANCE,3,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 3},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,4,"<li><a href=\'/console/media/");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,4},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 17},new Method("Ljava/lang/Integer;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,4},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitConstStmt(CONST_STRING,4,"/");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,4},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 16},new Method("Ljava/lang/Long;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,4},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitConstStmt(CONST_STRING,4,"\'>");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,4},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,14},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitConstStmt(CONST_STRING,4,"</a></li>");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,4},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,18);
                code.visitStmt2R(MOVE_OBJECT,1,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/io/PrintWriter;","println",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L21);
                code.visitStmt2R1N(ADD_INT_LIT8,10,10,1);
                code.visitLabel(L22);
                code.visitJumpStmt(GOTO,-1,-1,L17);
                code.visitLabel(L23);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 17},new Method("Ljava/lang/Integer;","intValue",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitStmt2R1N(ADD_INT_LIT8,3,3,1);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 3},new Method("Ljava/lang/Integer;","valueOf",new String[]{ "I"},"Ljava/lang/Integer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,17);
                code.visitLabel(L24);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 17},new Method("Ljava/lang/Integer;","intValue",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitStmt2R1N(REM_INT_LIT8,3,3,2);
                code.visitJumpStmt(IF_NEZ,3,-1,L29);
                code.visitLabel(L25);
                code.visitJumpStmt(IF_NEZ,10,-1,L27);
                code.visitLabel(L26);
                code.visitConstStmt(CONST_STRING,3,"<li>No media items found on this phone.</li>");
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,18);
                code.visitStmt2R(MOVE_OBJECT,1,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/io/PrintWriter;","println",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L27);
                code.visitConstStmt(CONST_4,10, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L28);
                code.visitConstStmt(CONST_STRING,3,"</ul>");
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,18);
                code.visitStmt2R(MOVE_OBJECT,1,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/io/PrintWriter;","println",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L29);
                code.visitStmt2R1N(ADD_INT_LIT8,12,12,1);
                code.visitJumpStmt(GOTO_16,-1,-1,L12);
                code.visitLabel(L30);
                code.visitConstStmt(CONST_STRING,3,"</div>");
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,18);
                code.visitStmt2R(MOVE_OBJECT,1,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/io/PrintWriter;","println",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L31);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,18);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,20);
                code.visitStmt2R(MOVE_OBJECT_FROM16,2,21);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0,1,2},new Method("Lorg/mortbay/ijetty/console/HTMLHelper;","doFooter",new String[]{ "Ljava/io/PrintWriter;","Ljavax/servlet/http/HttpServletRequest;","Ljavax/servlet/http/HttpServletResponse;"},"V"));
                code.visitLabel(L32);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m002_doGet(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/ijetty/console/MediaBrowserServlet;","doGet",new String[]{ "Ljavax/servlet/http/HttpServletRequest;","Ljavax/servlet/http/HttpServletResponse;"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljavax/servlet/ServletException;"));
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(16);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ "Ljava/lang/Exception;"});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"request");
                ddv.visitParameterName(1,"response");
                DexLabel L3=new DexLabel();
                ddv.visitPrologue(L3);
                ddv.visitLineNumber(73,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(74,L4);
                ddv.visitStartLocal(5,L4,"pathInfo","Ljava/lang/String;",null);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(77,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(116,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(81,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(82,L8);
                ddv.visitStartLocal(10,L8,"typestr","Ljava/lang/String;",null);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(84,L9);
                ddv.visitStartLocal(3,L9,"item","Ljava/lang/String;",null);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(85,L10);
                ddv.visitStartLocal(8,L10,"strtok","Ljava/util/StringTokenizer;",null);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(86,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(88,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(89,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(91,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(93,L15);
                ddv.visitLineNumber(98,L0);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(99,L16);
                ddv.visitStartLocal(6,L16,"rowid","Ljava/lang/Long;",null);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(101,L17);
                ddv.visitStartLocal(9,L17,"type","I",null);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(102,L18);
                ddv.visitStartLocal(1,L18,"contenturi","Landroid/net/Uri;",null);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(104,L19);
                ddv.visitStartLocal(0,L19,"content","Landroid/net/Uri;",null);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(105,L20);
                DexLabel L21=new DexLabel();
                ddv.visitLineNumber(106,L21);
                DexLabel L22=new DexLabel();
                ddv.visitLineNumber(107,L22);
                ddv.visitStartLocal(7,L22,"stream","Ljava/io/InputStream;",null);
                DexLabel L23=new DexLabel();
                ddv.visitLineNumber(108,L23);
                ddv.visitStartLocal(4,L23,"os","Ljava/io/OutputStream;",null);
                ddv.visitLineNumber(110,L2);
                ddv.visitEndLocal(6,L2);
                ddv.visitEndLocal(9,L2);
                ddv.visitEndLocal(1,L2);
                ddv.visitEndLocal(0,L2);
                ddv.visitEndLocal(7,L2);
                ddv.visitEndLocal(4,L2);
                DexLabel L24=new DexLabel();
                ddv.visitLineNumber(111,L24);
                ddv.visitStartLocal(2,L24,"e","Ljava/lang/Exception;",null);
                DexLabel L25=new DexLabel();
                ddv.visitLineNumber(112,L25);
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 14},new Method("Ljavax/servlet/http/HttpServletRequest;","getPathInfo",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitLabel(L4);
                code.visitJumpStmt(IF_NEZ,5,-1,L7);
                code.visitLabel(L5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 13,14,15},new Method("Lorg/mortbay/ijetty/console/MediaBrowserServlet;","doBody",new String[]{ "Ljavax/servlet/http/HttpServletRequest;","Ljavax/servlet/http/HttpServletResponse;"},"V"));
                code.visitLabel(L6);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L7);
                code.visitConstStmt(CONST_4,10, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L8);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L9);
                code.visitTypeStmt(NEW_INSTANCE,8,-1,"Ljava/util/StringTokenizer;");
                code.visitConstStmt(CONST_STRING,11,"/");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 8,5,11},new Method("Ljava/util/StringTokenizer;","<init>",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"V"));
                code.visitLabel(L10);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8},new Method("Ljava/util/StringTokenizer;","hasMoreElements",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,11);
                code.visitJumpStmt(IF_EQZ,11,-1,L12);
                code.visitLabel(L11);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8},new Method("Ljava/util/StringTokenizer;","nextToken",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,10);
                code.visitLabel(L12);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8},new Method("Ljava/util/StringTokenizer;","hasMoreElements",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,11);
                code.visitJumpStmt(IF_EQZ,11,-1,L14);
                code.visitLabel(L13);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8},new Method("Ljava/util/StringTokenizer;","nextToken",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitLabel(L14);
                code.visitJumpStmt(IF_EQZ,10,-1,L15);
                code.visitJumpStmt(IF_NEZ,3,-1,L0);
                code.visitLabel(L15);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 13,14,15},new Method("Lorg/mortbay/ijetty/console/MediaBrowserServlet;","doBody",new String[]{ "Ljavax/servlet/http/HttpServletRequest;","Ljavax/servlet/http/HttpServletResponse;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L6);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 3},new Method("Ljava/lang/Long;","parseLong",new String[]{ "Ljava/lang/String;"},"J"));
                code.visitStmt1R(MOVE_RESULT_WIDE,11);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 11,12},new Method("Ljava/lang/Long;","valueOf",new String[]{ "J"},"Ljava/lang/Long;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitLabel(L16);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 10},new Method("Ljava/lang/Integer;","parseInt",new String[]{ "Ljava/lang/String;"},"I"));
                code.visitStmt1R(MOVE_RESULT,9);
                code.visitLabel(L17);
                code.visitFieldStmt(IGET_OBJECT,11,13,new Field("Lorg/mortbay/ijetty/console/MediaBrowserServlet;","__MEDIA_URIS","[Landroid/net/Uri;"));
                code.visitStmt3R(AGET_OBJECT,1,11,9);
                code.visitLabel(L18);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1,3},new Method("Landroid/net/Uri;","withAppendedPath",new String[]{ "Landroid/net/Uri;","Ljava/lang/String;"},"Landroid/net/Uri;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L19);
                code.visitFieldStmt(IGET_OBJECT,11,13,new Field("Lorg/mortbay/ijetty/console/MediaBrowserServlet;","resolver","Landroid/content/ContentResolver;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 11,0},new Method("Landroid/content/ContentResolver;","getType",new String[]{ "Landroid/net/Uri;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,11);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 15,11},new Method("Ljavax/servlet/http/HttpServletResponse;","setContentType",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L20);
                code.visitConstStmt(CONST_16,11, Integer.valueOf(200)); // int: 0x000000c8  float:0.000000
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 15,11},new Method("Ljavax/servlet/http/HttpServletResponse;","setStatus",new String[]{ "I"},"V"));
                code.visitLabel(L21);
                code.visitFieldStmt(IGET_OBJECT,11,13,new Field("Lorg/mortbay/ijetty/console/MediaBrowserServlet;","resolver","Landroid/content/ContentResolver;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 11,0},new Method("Landroid/content/ContentResolver;","openInputStream",new String[]{ "Landroid/net/Uri;"},"Ljava/io/InputStream;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitLabel(L22);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 15},new Method("Ljavax/servlet/http/HttpServletResponse;","getOutputStream",new String[]{ },"Ljavax/servlet/ServletOutputStream;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitLabel(L23);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 7,4},new Method("Lorg/mortbay/util/IO;","copy",new String[]{ "Ljava/io/InputStream;","Ljava/io/OutputStream;"},"V"));
                code.visitLabel(L1);
                code.visitJumpStmt(GOTO,-1,-1,L6);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,11);
                code.visitStmt2R(MOVE_OBJECT,2,11);
                code.visitLabel(L24);
                code.visitConstStmt(CONST_STRING,11,"Jetty");
                code.visitConstStmt(CONST_STRING,12,"Failed to fetch media");
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 11,12,2},new Method("Landroid/util/Log;","w",new String[]{ "Ljava/lang/String;","Ljava/lang/String;","Ljava/lang/Throwable;"},"I"));
                code.visitLabel(L25);
                code.visitConstStmt(CONST_16,11, Integer.valueOf(404)); // int: 0x00000194  float:0.000000
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 15,11},new Method("Ljavax/servlet/http/HttpServletResponse;","setStatus",new String[]{ "I"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L6);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m003_getContentResolver(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/ijetty/console/MediaBrowserServlet;","getContentResolver",new String[]{ },"Landroid/content/ContentResolver;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(68,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/ijetty/console/MediaBrowserServlet;","resolver","Landroid/content/ContentResolver;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m004_init(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/ijetty/console/MediaBrowserServlet;","init",new String[]{ "Ljavax/servlet/ServletConfig;"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljavax/servlet/ServletException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"config");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(62,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(63,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(64,L2);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_SUPER,new int[]{ 2,3},new Method("Ljavax/servlet/http/HttpServlet;","init",new String[]{ "Ljavax/servlet/ServletConfig;"},"V"));
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/ijetty/console/MediaBrowserServlet;","getServletContext",new String[]{ },"Ljavax/servlet/ServletContext;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitConstStmt(CONST_STRING,1,"contentResolver");
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,1},new Method("Ljavax/servlet/ServletContext;","getAttribute",new String[]{ "Ljava/lang/String;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitTypeStmt(CHECK_CAST,0,-1,"Landroid/content/ContentResolver;");
                code.visitFieldStmt(IPUT_OBJECT,0,2,new Field("Lorg/mortbay/ijetty/console/MediaBrowserServlet;","resolver","Landroid/content/ContentResolver;"));
                code.visitLabel(L2);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
