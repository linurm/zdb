package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0316_org_mortbay_jetty_servlet_AbstractSessionManager_Session {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(ACC_PUBLIC|ACC_ABSTRACT,"Lorg/mortbay/jetty/servlet/AbstractSessionManager$Session;","Ljava/lang/Object;",new String[]{ "Lorg/mortbay/jetty/servlet/AbstractSessionManager$SessionIf;","Ljava/io/Serializable;"});
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("AbstractSessionManager.java");
        if(cv!=null){
            DexAnnotationVisitor av00 = cv.visitAnnotation("Ldalvik/annotation/EnclosingClass;", Visibility.SYSTEM);
            if(av00 != null) {
                av00.visit("value", new DexType("Lorg/mortbay/jetty/servlet/AbstractSessionManager;"));
                av00.visitEnd();
            }
        }
        if(cv!=null){
            DexAnnotationVisitor av00 = cv.visitAnnotation("Ldalvik/annotation/InnerClass;", Visibility.SYSTEM);
            if(av00 != null) {
                av00.visit("accessFlags",  Integer.valueOf(1025));
                av00.visit("name", "Session");
                av00.visitEnd();
            }
        }
        f000__accessed(cv);
        f001__clusterId(cv);
        f002__cookieSet(cv);
        f003__created(cv);
        f004__doInvalidate(cv);
        f005__idChanged(cv);
        f006__invalid(cv);
        f007__lastAccessed(cv);
        f008__maxIdleMs(cv);
        f009__newSession(cv);
        f010__nodeId(cv);
        f011__requests(cv);
        f012__values(cv);
        f013_this$0(cv);
        m000__init_(cv);
        m001__init_(cv);
        m002_access(cv);
        m003_bindValue(cv);
        m004_complete(cv);
        m005_cookieSet(cv);
        m006_didActivate(cv);
        m007_doInvalidate(cv);
        m008_getAttribute(cv);
        m009_getAttributeNames(cv);
        m010_getClusterId(cv);
        m011_getCookieSetTime(cv);
        m012_getCreationTime(cv);
        m013_getId(cv);
        m014_getLastAccessedTime(cv);
        m015_getMaxInactiveInterval(cv);
        m016_getNodeId(cv);
        m017_getServletContext(cv);
        m018_getSession(cv);
        m019_getSessionContext(cv);
        m020_getValue(cv);
        m021_getValueNames(cv);
        m022_initValues(cv);
        m023_invalidate(cv);
        m024_isIdChanged(cv);
        m025_isNew(cv);
        m026_isValid(cv);
        m027_newAttributeMap(cv);
        m028_putValue(cv);
        m029_removeAttribute(cv);
        m030_removeValue(cv);
        m031_setAttribute(cv);
        m032_setIdChanged(cv);
        m033_setMaxInactiveInterval(cv);
        m034_timeout(cv);
        m035_toString(cv);
        m036_unbindValue(cv);
        m037_willPassivate(cv);
    }
    public static void f000__accessed(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PROTECTED, new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager$Session;","_accessed","J"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f001__clusterId(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PROTECTED|ACC_FINAL, new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager$Session;","_clusterId","Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f002__cookieSet(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PROTECTED, new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager$Session;","_cookieSet","J"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f003__created(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PROTECTED|ACC_FINAL, new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager$Session;","_created","J"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f004__doInvalidate(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PROTECTED, new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager$Session;","_doInvalidate","Z"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f005__idChanged(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PROTECTED, new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager$Session;","_idChanged","Z"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f006__invalid(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PROTECTED, new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager$Session;","_invalid","Z"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f007__lastAccessed(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PROTECTED, new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager$Session;","_lastAccessed","J"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f008__maxIdleMs(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PROTECTED, new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager$Session;","_maxIdleMs","J"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f009__newSession(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PROTECTED, new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager$Session;","_newSession","Z"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f010__nodeId(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PROTECTED|ACC_FINAL, new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager$Session;","_nodeId","Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f011__requests(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PROTECTED, new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager$Session;","_requests","I"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f012__values(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PROTECTED, new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager$Session;","_values","Ljava/util/Map;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f013_this$0(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_FINAL|ACC_SYNTHETIC, new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager$Session;","this$0","Lorg/mortbay/jetty/servlet/AbstractSessionManager;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void m000__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/jetty/servlet/AbstractSessionManager$Session;","<init>",new String[]{ "Lorg/mortbay/jetty/servlet/AbstractSessionManager;","J","Ljava/lang/String;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(8);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(1,"created");
                ddv.visitParameterName(2,"clusterId");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(761,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(743,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(762,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(763,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(764,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(765,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(766,L6);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_OBJECT,4,3,new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager$Session;","this$0","Lorg/mortbay/jetty/servlet/AbstractSessionManager;"));
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 3},new Method("Ljava/lang/Object;","<init>",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,0,3,new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager$Session;","this$0","Lorg/mortbay/jetty/servlet/AbstractSessionManager;"));
                code.visitFieldStmt(IGET,0,0,new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","_dftMaxIdleSecs","I"));
                code.visitStmt2R1N(MUL_INT_LIT16,0,0,1000);
                code.visitStmt2R(INT_TO_LONG,0,0);
                code.visitFieldStmt(IPUT_WIDE,0,3,new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager$Session;","_maxIdleMs","J"));
                code.visitLabel(L2);
                code.visitFieldStmt(IPUT_WIDE,5,3,new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager$Session;","_created","J"));
                code.visitLabel(L3);
                code.visitFieldStmt(IPUT_OBJECT,7,3,new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager$Session;","_clusterId","Ljava/lang/String;"));
                code.visitLabel(L4);
                code.visitFieldStmt(IGET_OBJECT,0,4,new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","_sessionIdManager","Lorg/mortbay/jetty/SessionIdManager;"));
                code.visitFieldStmt(IGET_OBJECT,1,3,new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager$Session;","_clusterId","Ljava/lang/String;"));
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,1,2},new Method("Lorg/mortbay/jetty/SessionIdManager;","getNodeId",new String[]{ "Ljava/lang/String;","Ljavax/servlet/http/HttpServletRequest;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(IPUT_OBJECT,0,3,new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager$Session;","_nodeId","Ljava/lang/String;"));
                code.visitLabel(L5);
                code.visitFieldStmt(IGET_WIDE,0,3,new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager$Session;","_created","J"));
                code.visitFieldStmt(IPUT_WIDE,0,3,new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager$Session;","_accessed","J"));
                code.visitLabel(L6);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/jetty/servlet/AbstractSessionManager$Session;","<init>",new String[]{ "Lorg/mortbay/jetty/servlet/AbstractSessionManager;","Ljavax/servlet/http/HttpServletRequest;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(7);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(1,"request");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(750,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(743,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(751,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(752,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(753,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(754,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(755,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(756,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(757,L9);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitLabel(L1);
                code.visitFieldStmt(IPUT_OBJECT,5,4,new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager$Session;","this$0","Lorg/mortbay/jetty/servlet/AbstractSessionManager;"));
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 4},new Method("Ljava/lang/Object;","<init>",new String[]{ },"V"));
                code.visitLabel(L2);
                code.visitFieldStmt(IGET_OBJECT,0,4,new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager$Session;","this$0","Lorg/mortbay/jetty/servlet/AbstractSessionManager;"));
                code.visitFieldStmt(IGET,0,0,new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","_dftMaxIdleSecs","I"));
                code.visitStmt2R1N(MUL_INT_LIT16,0,0,1000);
                code.visitStmt2R(INT_TO_LONG,0,0);
                code.visitFieldStmt(IPUT_WIDE,0,4,new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager$Session;","_maxIdleMs","J"));
                code.visitLabel(L3);
                code.visitFieldStmt(IPUT_BOOLEAN,3,4,new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager$Session;","_newSession","Z"));
                code.visitLabel(L4);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Ljava/lang/System;","currentTimeMillis",new String[]{ },"J"));
                code.visitStmt1R(MOVE_RESULT_WIDE,0);
                code.visitFieldStmt(IPUT_WIDE,0,4,new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager$Session;","_created","J"));
                code.visitLabel(L5);
                code.visitFieldStmt(IGET_OBJECT,0,5,new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","_sessionIdManager","Lorg/mortbay/jetty/SessionIdManager;"));
                code.visitFieldStmt(IGET_WIDE,1,4,new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager$Session;","_created","J"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,6,1,2},new Method("Lorg/mortbay/jetty/SessionIdManager;","newSessionId",new String[]{ "Ljavax/servlet/http/HttpServletRequest;","J"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(IPUT_OBJECT,0,4,new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager$Session;","_clusterId","Ljava/lang/String;"));
                code.visitLabel(L6);
                code.visitFieldStmt(IGET_OBJECT,0,5,new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","_sessionIdManager","Lorg/mortbay/jetty/SessionIdManager;"));
                code.visitFieldStmt(IGET_OBJECT,1,4,new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager$Session;","_clusterId","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,1,6},new Method("Lorg/mortbay/jetty/SessionIdManager;","getNodeId",new String[]{ "Ljava/lang/String;","Ljavax/servlet/http/HttpServletRequest;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(IPUT_OBJECT,0,4,new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager$Session;","_nodeId","Ljava/lang/String;"));
                code.visitLabel(L7);
                code.visitFieldStmt(IGET_WIDE,0,4,new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager$Session;","_created","J"));
                code.visitFieldStmt(IPUT_WIDE,0,4,new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager$Session;","_accessed","J"));
                code.visitLabel(L8);
                code.visitFieldStmt(IPUT,3,4,new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager$Session;","_requests","I"));
                code.visitLabel(L9);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m002_access(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Lorg/mortbay/jetty/servlet/AbstractSessionManager$Session;","access",new String[]{ "J"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"time");
                DexLabel L3=new DexLabel();
                ddv.visitPrologue(L3);
                ddv.visitLineNumber(897,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(899,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(900,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(901,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(902,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(903,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(904,L9);
                ddv.visitLineNumber(903,L2);
                code.visitLabel(L3);
                code.visitStmt1R(MONITOR_ENTER,2);
                code.visitLabel(L4);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_BOOLEAN,0,2,new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager$Session;","_newSession","Z"));
                code.visitLabel(L5);
                code.visitFieldStmt(IGET_WIDE,0,2,new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager$Session;","_accessed","J"));
                code.visitFieldStmt(IPUT_WIDE,0,2,new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager$Session;","_lastAccessed","J"));
                code.visitLabel(L6);
                code.visitFieldStmt(IPUT_WIDE,3,2,new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager$Session;","_accessed","J"));
                code.visitLabel(L7);
                code.visitFieldStmt(IGET,0,2,new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager$Session;","_requests","I"));
                code.visitStmt2R1N(ADD_INT_LIT8,0,0,1);
                code.visitFieldStmt(IPUT,0,2,new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager$Session;","_requests","I"));
                code.visitLabel(L8);
                code.visitStmt1R(MONITOR_EXIT,2);
                code.visitLabel(L9);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,0);
                code.visitStmt1R(MONITOR_EXIT,2);
                code.visitLabel(L1);
                code.visitStmt1R(THROW,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m003_bindValue(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Lorg/mortbay/jetty/servlet/AbstractSessionManager$Session;","bindValue",new String[]{ "Ljava/lang/String;","Ljava/lang/Object;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"name");
                ddv.visitParameterName(1,"value");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(1105,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(1106,L1);
                DexLabel L2=new DexLabel();
                ddv.visitEndLocal(3,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(1107,L3);
                code.visitLabel(L0);
                code.visitJumpStmt(IF_EQZ,3,-1,L3);
                code.visitTypeStmt(INSTANCE_OF,0,3,"Ljavax/servlet/http/HttpSessionBindingListener;");
                code.visitJumpStmt(IF_EQZ,0,-1,L3);
                code.visitLabel(L1);
                code.visitTypeStmt(CHECK_CAST,3,-1,"Ljavax/servlet/http/HttpSessionBindingListener;");
                code.visitLabel(L2);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljavax/servlet/http/HttpSessionBindingEvent;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1,2},new Method("Ljavax/servlet/http/HttpSessionBindingEvent;","<init>",new String[]{ "Ljavax/servlet/http/HttpSession;","Ljava/lang/String;"},"V"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 3,0},new Method("Ljavax/servlet/http/HttpSessionBindingListener;","valueBound",new String[]{ "Ljavax/servlet/http/HttpSessionBindingEvent;"},"V"));
                code.visitLabel(L3);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m004_complete(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Lorg/mortbay/jetty/servlet/AbstractSessionManager$Session;","complete",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L3=new DexLabel();
                ddv.visitPrologue(L3);
                ddv.visitLineNumber(909,L3);
                ddv.visitLineNumber(911,L0);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(912,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(913,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(914,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(915,L7);
                ddv.visitLineNumber(914,L2);
                code.visitLabel(L3);
                code.visitStmt1R(MONITOR_ENTER,2);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET,0,2,new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager$Session;","_requests","I"));
                code.visitConstStmt(CONST_4,1, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitStmt2R(SUB_INT_2ADDR,0,1);
                code.visitFieldStmt(IPUT,0,2,new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager$Session;","_requests","I"));
                code.visitLabel(L4);
                code.visitFieldStmt(IGET_BOOLEAN,0,2,new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager$Session;","_doInvalidate","Z"));
                code.visitJumpStmt(IF_EQZ,0,-1,L6);
                code.visitFieldStmt(IGET,0,2,new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager$Session;","_requests","I"));
                code.visitJumpStmt(IF_GTZ,0,-1,L6);
                code.visitLabel(L5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/jetty/servlet/AbstractSessionManager$Session;","doInvalidate",new String[]{ },"V"));
                code.visitLabel(L6);
                code.visitStmt1R(MONITOR_EXIT,2);
                code.visitLabel(L7);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,0);
                code.visitStmt1R(MONITOR_EXIT,2);
                code.visitLabel(L1);
                code.visitStmt1R(THROW,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m005_cookieSet(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Lorg/mortbay/jetty/servlet/AbstractSessionManager$Session;","cookieSet",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(1121,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(1122,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_WIDE,0,2,new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager$Session;","_accessed","J"));
                code.visitFieldStmt(IPUT_WIDE,0,2,new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager$Session;","_cookieSet","J"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m006_didActivate(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Lorg/mortbay/jetty/servlet/AbstractSessionManager$Session;","didActivate",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(7);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L3=new DexLabel();
                ddv.visitPrologue(L3);
                ddv.visitLineNumber(1150,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(1151,L4);
                ddv.visitStartLocal(1,L4,"event","Ljavax/servlet/http/HttpSessionEvent;",null);
                DexLabel L5=new DexLabel();
                ddv.visitStartLocal(2,L5,"iter","Ljava/util/Iterator;",null);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(1153,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(1154,L7);
                ddv.visitStartLocal(4,L7,"value","Ljava/lang/Object;",null);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(1156,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(1157,L9);
                ddv.visitStartLocal(3,L9,"listener","Ljavax/servlet/http/HttpSessionActivationListener;",null);
                ddv.visitLineNumber(1150,L2);
                ddv.visitEndLocal(1,L2);
                ddv.visitEndLocal(2,L2);
                ddv.visitEndLocal(4,L2);
                ddv.visitEndLocal(3,L2);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(1160,L10);
                ddv.visitRestartLocal(1,L10);
                ddv.visitRestartLocal(2,L10);
                code.visitLabel(L3);
                code.visitStmt1R(MONITOR_ENTER,6);
                code.visitLabel(L0);
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Ljavax/servlet/http/HttpSessionEvent;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1,6},new Method("Ljavax/servlet/http/HttpSessionEvent;","<init>",new String[]{ "Ljavax/servlet/http/HttpSession;"},"V"));
                code.visitLabel(L4);
                code.visitFieldStmt(IGET_OBJECT,5,6,new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager$Session;","_values","Ljava/util/Map;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 5},new Method("Ljava/util/Map;","values",new String[]{ },"Ljava/util/Collection;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 5},new Method("Ljava/util/Collection;","iterator",new String[]{ },"Ljava/util/Iterator;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitLabel(L5);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 2},new Method("Ljava/util/Iterator;","hasNext",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,5);
                code.visitJumpStmt(IF_EQZ,5,-1,L10);
                code.visitLabel(L6);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 2},new Method("Ljava/util/Iterator;","next",new String[]{ },"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitLabel(L7);
                code.visitTypeStmt(INSTANCE_OF,5,4,"Ljavax/servlet/http/HttpSessionActivationListener;");
                code.visitJumpStmt(IF_EQZ,5,-1,L5);
                code.visitLabel(L8);
                code.visitStmt2R(MOVE_OBJECT,0,4);
                code.visitTypeStmt(CHECK_CAST,0,-1,"Ljavax/servlet/http/HttpSessionActivationListener;");
                code.visitStmt2R(MOVE_OBJECT,3,0);
                code.visitLabel(L9);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 3,1},new Method("Ljavax/servlet/http/HttpSessionActivationListener;","sessionDidActivate",new String[]{ "Ljavax/servlet/http/HttpSessionEvent;"},"V"));
                code.visitLabel(L1);
                code.visitJumpStmt(GOTO,-1,-1,L5);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,5);
                code.visitStmt1R(MONITOR_EXIT,6);
                code.visitStmt1R(THROW,5);
                code.visitLabel(L10);
                code.visitStmt1R(MONITOR_EXIT,6);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m007_doInvalidate(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Lorg/mortbay/jetty/servlet/AbstractSessionManager$Session;","doInvalidate",new String[]{ },"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/lang/IllegalStateException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(9);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L1},new String[]{ null});
                DexLabel L2=new DexLabel();
                DexLabel L3=new DexLabel();
                code.visitTryCatch(L2,L3,new DexLabel[]{L1},new String[]{ null});
                DexLabel L4=new DexLabel();
                DexLabel L5=new DexLabel();
                code.visitTryCatch(L3,L4,new DexLabel[]{L5},new String[]{ null});
                DexLabel L6=new DexLabel();
                code.visitTryCatch(L4,L6,new DexLabel[]{L1},new String[]{ null});
                DexLabel L7=new DexLabel();
                DexLabel L8=new DexLabel();
                code.visitTryCatch(L6,L7,new DexLabel[]{L8},new String[]{ null});
                DexLabel L9=new DexLabel();
                code.visitTryCatch(L7,L9,new DexLabel[]{L1},new String[]{ null});
                DexLabel L10=new DexLabel();
                DexLabel L11=new DexLabel();
                code.visitTryCatch(L10,L11,new DexLabel[]{L5},new String[]{ null});
                code.visitTryCatch(L11,L8,new DexLabel[]{L1},new String[]{ null});
                DexLabel L12=new DexLabel();
                DexLabel L13=new DexLabel();
                code.visitTryCatch(L12,L13,new DexLabel[]{L8},new String[]{ null});
                DexLabel L14=new DexLabel();
                code.visitTryCatch(L13,L14,new DexLabel[]{L1},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L15=new DexLabel();
                ddv.visitPrologue(L15);
                ddv.visitLineNumber(948,L0);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(949,L16);
                ddv.visitLineNumber(984,L1);
                ddv.visitLineNumber(951,L2);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(954,L17);
                ddv.visitLineNumber(956,L3);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(957,L18);
                ddv.visitStartLocal(4,L18,"keys","Ljava/util/ArrayList;",null);
                ddv.visitLineNumber(959,L4);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(960,L19);
                ddv.visitStartLocal(2,L19,"iter","Ljava/util/Iterator;",null);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(962,L20);
                DexLabel L21=new DexLabel();
                ddv.visitLineNumber(965,L21);
                ddv.visitStartLocal(3,L21,"key","Ljava/lang/String;",null);
                ddv.visitLineNumber(967,L6);
                DexLabel L22=new DexLabel();
                ddv.visitLineNumber(968,L22);
                ddv.visitStartLocal(5,L22,"value","Ljava/lang/Object;",null);
                ddv.visitLineNumber(969,L7);
                DexLabel L23=new DexLabel();
                ddv.visitLineNumber(971,L23);
                DexLabel L24=new DexLabel();
                ddv.visitLineNumber(973,L24);
                DexLabel L25=new DexLabel();
                ddv.visitLineNumber(975,L25);
                ddv.visitStartLocal(0,L25,"event","Ljavax/servlet/http/HttpSessionBindingEvent;",null);
                DexLabel L26=new DexLabel();
                ddv.visitStartLocal(1,L26,"i","I",null);
                DexLabel L27=new DexLabel();
                ddv.visitLineNumber(976,L27);
                ddv.visitLineNumber(975,L9);
                ddv.visitLineNumber(957,L5);
                ddv.visitEndLocal(4,L5);
                ddv.visitEndLocal(2,L5);
                ddv.visitEndLocal(3,L5);
                ddv.visitEndLocal(5,L5);
                ddv.visitEndLocal(0,L5);
                ddv.visitEndLocal(1,L5);
                ddv.visitLineNumber(968,L8);
                ddv.visitRestartLocal(2,L8);
                ddv.visitRestartLocal(3,L8);
                ddv.visitRestartLocal(4,L8);
                ddv.visitLineNumber(984,L14);
                ddv.visitEndLocal(2,L14);
                ddv.visitEndLocal(3,L14);
                ddv.visitEndLocal(4,L14);
                DexLabel L28=new DexLabel();
                ddv.visitLineNumber(986,L28);
                code.visitLabel(L15);
                code.visitConstStmt(CONST_4,7, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_BOOLEAN,6,8,new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager$Session;","_invalid","Z"));
                code.visitJumpStmt(IF_EQZ,6,-1,L2);
                code.visitLabel(L16);
                code.visitTypeStmt(NEW_INSTANCE,6,-1,"Ljava/lang/IllegalStateException;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 6},new Method("Ljava/lang/IllegalStateException;","<init>",new String[]{ },"V"));
                code.visitStmt1R(THROW,6);
                code.visitLabel(L1);
                code.visitStmt1R(MOVE_EXCEPTION,6);
                code.visitFieldStmt(IPUT_BOOLEAN,7,8,new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager$Session;","_invalid","Z"));
                code.visitStmt1R(THROW,6);
                code.visitLabel(L2);
                code.visitFieldStmt(IGET_OBJECT,6,8,new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager$Session;","_values","Ljava/util/Map;"));
                code.visitJumpStmt(IF_EQZ,6,-1,L14);
                code.visitFieldStmt(IGET_OBJECT,6,8,new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager$Session;","_values","Ljava/util/Map;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 6},new Method("Ljava/util/Map;","size",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,6);
                code.visitJumpStmt(IF_LEZ,6,-1,L14);
                code.visitLabel(L17);
                code.visitStmt1R(MONITOR_ENTER,8);
                code.visitLabel(L3);
                code.visitTypeStmt(NEW_INSTANCE,4,-1,"Ljava/util/ArrayList;");
                code.visitFieldStmt(IGET_OBJECT,6,8,new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager$Session;","_values","Ljava/util/Map;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 6},new Method("Ljava/util/Map;","keySet",new String[]{ },"Ljava/util/Set;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 4,6},new Method("Ljava/util/ArrayList;","<init>",new String[]{ "Ljava/util/Collection;"},"V"));
                code.visitLabel(L18);
                code.visitStmt1R(MONITOR_EXIT,8);
                code.visitLabel(L4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Ljava/util/ArrayList;","iterator",new String[]{ },"Ljava/util/Iterator;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitLabel(L19);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 2},new Method("Ljava/util/Iterator;","hasNext",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,6);
                code.visitJumpStmt(IF_EQZ,6,-1,L2);
                code.visitLabel(L20);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 2},new Method("Ljava/util/Iterator;","next",new String[]{ },"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitTypeStmt(CHECK_CAST,3,-1,"Ljava/lang/String;");
                code.visitLabel(L21);
                code.visitStmt1R(MONITOR_ENTER,8);
                code.visitLabel(L6);
                code.visitFieldStmt(IGET_OBJECT,6,8,new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager$Session;","_values","Ljava/util/Map;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 6,3},new Method("Ljava/util/Map;","remove",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitLabel(L22);
                code.visitStmt1R(MONITOR_EXIT,8);
                code.visitLabel(L7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8,3,5},new Method("Lorg/mortbay/jetty/servlet/AbstractSessionManager$Session;","unbindValue",new String[]{ "Ljava/lang/String;","Ljava/lang/Object;"},"V"));
                code.visitLabel(L23);
                code.visitFieldStmt(IGET_OBJECT,6,8,new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager$Session;","this$0","Lorg/mortbay/jetty/servlet/AbstractSessionManager;"));
                code.visitFieldStmt(IGET_OBJECT,6,6,new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","_sessionAttributeListeners","Ljava/lang/Object;"));
                code.visitJumpStmt(IF_EQZ,6,-1,L19);
                code.visitLabel(L24);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljavax/servlet/http/HttpSessionBindingEvent;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,8,3,5},new Method("Ljavax/servlet/http/HttpSessionBindingEvent;","<init>",new String[]{ "Ljavax/servlet/http/HttpSession;","Ljava/lang/String;","Ljava/lang/Object;"},"V"));
                code.visitLabel(L25);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L26);
                code.visitFieldStmt(IGET_OBJECT,6,8,new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager$Session;","this$0","Lorg/mortbay/jetty/servlet/AbstractSessionManager;"));
                code.visitFieldStmt(IGET_OBJECT,6,6,new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","_sessionAttributeListeners","Ljava/lang/Object;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 6},new Method("Lorg/mortbay/util/LazyList;","size",new String[]{ "Ljava/lang/Object;"},"I"));
                code.visitStmt1R(MOVE_RESULT,6);
                code.visitJumpStmt(IF_GE,1,6,L19);
                code.visitLabel(L27);
                code.visitFieldStmt(IGET_OBJECT,6,8,new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager$Session;","this$0","Lorg/mortbay/jetty/servlet/AbstractSessionManager;"));
                code.visitFieldStmt(IGET_OBJECT,6,6,new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","_sessionAttributeListeners","Ljava/lang/Object;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 6,1},new Method("Lorg/mortbay/util/LazyList;","get",new String[]{ "Ljava/lang/Object;","I"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitTypeStmt(CHECK_CAST,6,-1,"Ljavax/servlet/http/HttpSessionAttributeListener;");
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 6,0},new Method("Ljavax/servlet/http/HttpSessionAttributeListener;","attributeRemoved",new String[]{ "Ljavax/servlet/http/HttpSessionBindingEvent;"},"V"));
                code.visitLabel(L9);
                code.visitStmt2R1N(ADD_INT_LIT8,1,1,1);
                code.visitJumpStmt(GOTO,-1,-1,L26);
                code.visitLabel(L5);
                code.visitStmt1R(MOVE_EXCEPTION,6);
                code.visitLabel(L10);
                code.visitStmt1R(MONITOR_EXIT,8);
                code.visitLabel(L11);
                code.visitStmt1R(THROW,6);
                code.visitLabel(L8);
                code.visitStmt1R(MOVE_EXCEPTION,6);
                code.visitLabel(L12);
                code.visitStmt1R(MONITOR_EXIT,8);
                code.visitLabel(L13);
                code.visitStmt1R(THROW,6);
                code.visitLabel(L14);
                code.visitFieldStmt(IPUT_BOOLEAN,7,8,new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager$Session;","_invalid","Z"));
                code.visitLabel(L28);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m008_getAttribute(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/servlet/AbstractSessionManager$Session;","getAttribute",new String[]{ "Ljava/lang/String;"},"Ljava/lang/Object;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L1},new String[]{ null});
                DexLabel L2=new DexLabel();
                DexLabel L3=new DexLabel();
                code.visitTryCatch(L2,L3,new DexLabel[]{L1},new String[]{ null});
                DexLabel L4=new DexLabel();
                DexLabel L5=new DexLabel();
                code.visitTryCatch(L4,L5,new DexLabel[]{L1},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"name");
                DexLabel L6=new DexLabel();
                ddv.visitPrologue(L6);
                ddv.visitLineNumber(783,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(784,L7);
                ddv.visitLineNumber(783,L1);
                ddv.visitLineNumber(786,L2);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(787,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(789,L9);
                code.visitLabel(L6);
                code.visitStmt1R(MONITOR_ENTER,1);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_BOOLEAN,0,1,new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager$Session;","_invalid","Z"));
                code.visitJumpStmt(IF_EQZ,0,-1,L2);
                code.visitLabel(L7);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/lang/IllegalStateException;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/lang/IllegalStateException;","<init>",new String[]{ },"V"));
                code.visitStmt1R(THROW,0);
                code.visitLabel(L1);
                code.visitStmt1R(MOVE_EXCEPTION,0);
                code.visitStmt1R(MONITOR_EXIT,1);
                code.visitStmt1R(THROW,0);
                code.visitLabel(L2);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager$Session;","_values","Ljava/util/Map;"));
                code.visitLabel(L3);
                code.visitJumpStmt(IF_NEZ,0,-1,L4);
                code.visitLabel(L8);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L9);
                code.visitStmt1R(MONITOR_EXIT,1);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitLabel(L4);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager$Session;","_values","Ljava/util/Map;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,2},new Method("Ljava/util/Map;","get",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitLabel(L5);
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitJumpStmt(GOTO,-1,-1,L9);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m009_getAttributeNames(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/servlet/AbstractSessionManager$Session;","getAttributeNames",new String[]{ },"Ljava/util/Enumeration;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L1},new String[]{ null});
                DexLabel L2=new DexLabel();
                DexLabel L3=new DexLabel();
                code.visitTryCatch(L2,L3,new DexLabel[]{L1},new String[]{ null});
                DexLabel L4=new DexLabel();
                DexLabel L5=new DexLabel();
                code.visitTryCatch(L4,L5,new DexLabel[]{L1},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L6=new DexLabel();
                ddv.visitPrologue(L6);
                ddv.visitLineNumber(795,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(796,L7);
                ddv.visitLineNumber(795,L1);
                ddv.visitLineNumber(797,L2);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(798,L8);
                ddv.visitStartLocal(0,L8,"names","Ljava/util/List;",null);
                ddv.visitLineNumber(797,L4);
                ddv.visitEndLocal(0,L4);
                code.visitLabel(L6);
                code.visitStmt1R(MONITOR_ENTER,3);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_BOOLEAN,1,3,new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager$Session;","_invalid","Z"));
                code.visitJumpStmt(IF_EQZ,1,-1,L2);
                code.visitLabel(L7);
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Ljava/lang/IllegalStateException;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1},new Method("Ljava/lang/IllegalStateException;","<init>",new String[]{ },"V"));
                code.visitStmt1R(THROW,1);
                code.visitLabel(L1);
                code.visitStmt1R(MOVE_EXCEPTION,1);
                code.visitStmt1R(MONITOR_EXIT,3);
                code.visitStmt1R(THROW,1);
                code.visitLabel(L2);
                code.visitFieldStmt(IGET_OBJECT,1,3,new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager$Session;","_values","Ljava/util/Map;"));
                code.visitJumpStmt(IF_NEZ,1,-1,L4);
                code.visitFieldStmt(SGET_OBJECT,1,-1,new Field("Ljava/util/Collections;","EMPTY_LIST","Ljava/util/List;"));
                code.visitStmt2R(MOVE_OBJECT,0,1);
                code.visitLabel(L8);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0},new Method("Ljava/util/Collections;","enumeration",new String[]{ "Ljava/util/Collection;"},"Ljava/util/Enumeration;"));
                code.visitLabel(L3);
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitStmt1R(MONITOR_EXIT,3);
                code.visitStmt1R(RETURN_OBJECT,1);
                code.visitLabel(L4);
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Ljava/util/ArrayList;");
                code.visitFieldStmt(IGET_OBJECT,2,3,new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager$Session;","_values","Ljava/util/Map;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 2},new Method("Ljava/util/Map;","keySet",new String[]{ },"Ljava/util/Set;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1,2},new Method("Ljava/util/ArrayList;","<init>",new String[]{ "Ljava/util/Collection;"},"V"));
                code.visitLabel(L5);
                code.visitStmt2R(MOVE_OBJECT,0,1);
                code.visitJumpStmt(GOTO,-1,-1,L8);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m010_getClusterId(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Lorg/mortbay/jetty/servlet/AbstractSessionManager$Session;","getClusterId",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(830,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager$Session;","_clusterId","Ljava/lang/String;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m011_getCookieSetTime(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/servlet/AbstractSessionManager$Session;","getCookieSetTime",new String[]{ },"J"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(804,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_WIDE,0,2,new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager$Session;","_cookieSet","J"));
                code.visitStmt1R(RETURN_WIDE,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m012_getCreationTime(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/servlet/AbstractSessionManager$Session;","getCreationTime",new String[]{ },"J"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/lang/IllegalStateException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(810,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(811,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(812,L2);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_BOOLEAN,0,2,new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager$Session;","_invalid","Z"));
                code.visitJumpStmt(IF_EQZ,0,-1,L2);
                code.visitLabel(L1);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/lang/IllegalStateException;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/lang/IllegalStateException;","<init>",new String[]{ },"V"));
                code.visitStmt1R(THROW,0);
                code.visitLabel(L2);
                code.visitFieldStmt(IGET_WIDE,0,2,new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager$Session;","_created","J"));
                code.visitStmt1R(RETURN_WIDE,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m013_getId(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/servlet/AbstractSessionManager$Session;","getId",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/lang/IllegalStateException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(818,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager$Session;","this$0","Lorg/mortbay/jetty/servlet/AbstractSessionManager;"));
                code.visitFieldStmt(IGET_BOOLEAN,0,0,new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","_nodeIdInSessionId","Z"));
                DexLabel L1=new DexLabel();
                code.visitJumpStmt(IF_EQZ,0,-1,L1);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager$Session;","_nodeId","Ljava/lang/String;"));
                DexLabel L2=new DexLabel();
                code.visitLabel(L2);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager$Session;","_clusterId","Ljava/lang/String;"));
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m014_getLastAccessedTime(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/servlet/AbstractSessionManager$Session;","getLastAccessedTime",new String[]{ },"J"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/lang/IllegalStateException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(836,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(837,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(838,L2);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_BOOLEAN,0,2,new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager$Session;","_invalid","Z"));
                code.visitJumpStmt(IF_EQZ,0,-1,L2);
                code.visitLabel(L1);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/lang/IllegalStateException;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/lang/IllegalStateException;","<init>",new String[]{ },"V"));
                code.visitStmt1R(THROW,0);
                code.visitLabel(L2);
                code.visitFieldStmt(IGET_WIDE,0,2,new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager$Session;","_lastAccessed","J"));
                code.visitStmt1R(RETURN_WIDE,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m015_getMaxInactiveInterval(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/servlet/AbstractSessionManager$Session;","getMaxInactiveInterval",new String[]{ },"I"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(844,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(845,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(846,L2);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_BOOLEAN,0,4,new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager$Session;","_invalid","Z"));
                code.visitJumpStmt(IF_EQZ,0,-1,L2);
                code.visitLabel(L1);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/lang/IllegalStateException;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/lang/IllegalStateException;","<init>",new String[]{ },"V"));
                code.visitStmt1R(THROW,0);
                code.visitLabel(L2);
                code.visitFieldStmt(IGET_WIDE,0,4,new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager$Session;","_maxIdleMs","J"));
                code.visitConstStmt(CONST_WIDE_16,2,Long.valueOf(1000L)); // long: 0x00000000000003e8  double:0.000000
                code.visitStmt2R(DIV_LONG_2ADDR,0,2);
                code.visitStmt2R(LONG_TO_INT,0,0);
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m016_getNodeId(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Lorg/mortbay/jetty/servlet/AbstractSessionManager$Session;","getNodeId",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(824,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager$Session;","_nodeId","Ljava/lang/String;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m017_getServletContext(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/servlet/AbstractSessionManager$Session;","getServletContext",new String[]{ },"Ljavax/servlet/ServletContext;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(855,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager$Session;","this$0","Lorg/mortbay/jetty/servlet/AbstractSessionManager;"));
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","_context","Lorg/mortbay/jetty/handler/ContextHandler$SContext;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m018_getSession(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/servlet/AbstractSessionManager$Session;","getSession",new String[]{ },"Lorg/mortbay/jetty/servlet/AbstractSessionManager$Session;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(1);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(771,L0);
                code.visitLabel(L0);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m019_getSessionContext(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/servlet/AbstractSessionManager$Session;","getSessionContext",new String[]{ },"Ljavax/servlet/http/HttpSessionContext;"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/lang/IllegalStateException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(864,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(865,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(866,L2);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_BOOLEAN,0,1,new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager$Session;","_invalid","Z"));
                code.visitJumpStmt(IF_EQZ,0,-1,L2);
                code.visitLabel(L1);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/lang/IllegalStateException;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/lang/IllegalStateException;","<init>",new String[]{ },"V"));
                code.visitStmt1R(THROW,0);
                code.visitLabel(L2);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","access$100",new String[]{ },"Ljavax/servlet/http/HttpSessionContext;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m020_getValue(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/servlet/AbstractSessionManager$Session;","getValue",new String[]{ "Ljava/lang/String;"},"Ljava/lang/Object;"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/lang/IllegalStateException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"name");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(876,L0);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2},new Method("Lorg/mortbay/jetty/servlet/AbstractSessionManager$Session;","getAttribute",new String[]{ "Ljava/lang/String;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m021_getValueNames(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/servlet/AbstractSessionManager$Session;","getValueNames",new String[]{ },"[Ljava/lang/String;"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/lang/IllegalStateException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L1},new String[]{ null});
                DexLabel L2=new DexLabel();
                DexLabel L3=new DexLabel();
                code.visitTryCatch(L2,L3,new DexLabel[]{L1},new String[]{ null});
                DexLabel L4=new DexLabel();
                DexLabel L5=new DexLabel();
                code.visitTryCatch(L4,L5,new DexLabel[]{L1},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L6=new DexLabel();
                ddv.visitPrologue(L6);
                ddv.visitLineNumber(886,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(887,L7);
                ddv.visitLineNumber(886,L1);
                ddv.visitLineNumber(888,L2);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(889,L8);
                ddv.visitLineNumber(891,L3);
                ddv.visitLineNumber(890,L4);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(891,L9);
                ddv.visitStartLocal(0,L9,"a","[Ljava/lang/String;",null);
                code.visitLabel(L6);
                code.visitStmt1R(MONITOR_ENTER,2);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_BOOLEAN,1,2,new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager$Session;","_invalid","Z"));
                code.visitJumpStmt(IF_EQZ,1,-1,L2);
                code.visitLabel(L7);
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Ljava/lang/IllegalStateException;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1},new Method("Ljava/lang/IllegalStateException;","<init>",new String[]{ },"V"));
                code.visitStmt1R(THROW,1);
                code.visitLabel(L1);
                code.visitStmt1R(MOVE_EXCEPTION,1);
                code.visitStmt1R(MONITOR_EXIT,2);
                code.visitStmt1R(THROW,1);
                code.visitLabel(L2);
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager$Session;","_values","Ljava/util/Map;"));
                code.visitJumpStmt(IF_NEZ,1,-1,L4);
                code.visitLabel(L8);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitTypeStmt(NEW_ARRAY,1,1,"[Ljava/lang/String;");
                code.visitLabel(L3);
                code.visitStmt1R(MONITOR_EXIT,2);
                code.visitStmt1R(RETURN_OBJECT,1);
                code.visitLabel(L4);
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager$Session;","_values","Ljava/util/Map;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 1},new Method("Ljava/util/Map;","size",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitTypeStmt(NEW_ARRAY,0,1,"[Ljava/lang/String;");
                code.visitLabel(L9);
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager$Session;","_values","Ljava/util/Map;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 1},new Method("Ljava/util/Map;","keySet",new String[]{ },"Ljava/util/Set;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 1,0},new Method("Ljava/util/Set;","toArray",new String[]{ "[Ljava/lang/Object;"},"[Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitTypeStmt(CHECK_CAST,1,-1,"[Ljava/lang/String;");
                code.visitTypeStmt(CHECK_CAST,1,-1,"[Ljava/lang/String;");
                code.visitLabel(L5);
                code.visitJumpStmt(GOTO,-1,-1,L3);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m022_initValues(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Lorg/mortbay/jetty/servlet/AbstractSessionManager$Session;","initValues",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(777,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(778,L1);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Lorg/mortbay/jetty/servlet/AbstractSessionManager$Session;","newAttributeMap",new String[]{ },"Ljava/util/Map;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager$Session;","_values","Ljava/util/Map;"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m023_invalidate(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/servlet/AbstractSessionManager$Session;","invalidate",new String[]{ },"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/lang/IllegalStateException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(938,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(939,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(940,L2);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager$Session;","this$0","Lorg/mortbay/jetty/servlet/AbstractSessionManager;"));
                code.visitConstStmt(CONST_4,1, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,2,1},new Method("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","removeSession",new String[]{ "Lorg/mortbay/jetty/servlet/AbstractSessionManager$Session;","Z"},"V"));
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/jetty/servlet/AbstractSessionManager$Session;","doInvalidate",new String[]{ },"V"));
                code.visitLabel(L2);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m024_isIdChanged(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/servlet/AbstractSessionManager$Session;","isIdChanged",new String[]{ },"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(991,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_BOOLEAN,0,1,new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager$Session;","_idChanged","Z"));
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m025_isNew(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/servlet/AbstractSessionManager$Session;","isNew",new String[]{ },"Z"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/lang/IllegalStateException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(997,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(998,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(999,L2);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_BOOLEAN,0,1,new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager$Session;","_invalid","Z"));
                code.visitJumpStmt(IF_EQZ,0,-1,L2);
                code.visitLabel(L1);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/lang/IllegalStateException;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/lang/IllegalStateException;","<init>",new String[]{ },"V"));
                code.visitStmt1R(THROW,0);
                code.visitLabel(L2);
                code.visitFieldStmt(IGET_BOOLEAN,0,1,new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager$Session;","_newSession","Z"));
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m026_isValid(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Lorg/mortbay/jetty/servlet/AbstractSessionManager$Session;","isValid",new String[]{ },"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(1112,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_BOOLEAN,0,1,new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager$Session;","_invalid","Z"));
                DexLabel L1=new DexLabel();
                code.visitJumpStmt(IF_NEZ,0,-1,L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                DexLabel L2=new DexLabel();
                code.visitLabel(L2);
                code.visitStmt1R(RETURN,0);
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m027_newAttributeMap(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED|ACC_ABSTRACT, new Method("Lorg/mortbay/jetty/servlet/AbstractSessionManager$Session;","newAttributeMap",new String[]{ },"Ljava/util/Map;"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m028_putValue(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/servlet/AbstractSessionManager$Session;","putValue",new String[]{ "Ljava/lang/String;","Ljava/lang/Object;"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/lang/IllegalStateException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"name");
                ddv.visitParameterName(1,"value");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(1009,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(1010,L1);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1,2},new Method("Lorg/mortbay/jetty/servlet/AbstractSessionManager$Session;","setAttribute",new String[]{ "Ljava/lang/String;","Ljava/lang/Object;"},"V"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m029_removeAttribute(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/servlet/AbstractSessionManager$Session;","removeAttribute",new String[]{ "Ljava/lang/String;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(6);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L1},new String[]{ null});
                DexLabel L2=new DexLabel();
                DexLabel L3=new DexLabel();
                code.visitTryCatch(L2,L3,new DexLabel[]{L1},new String[]{ null});
                DexLabel L4=new DexLabel();
                DexLabel L5=new DexLabel();
                code.visitTryCatch(L4,L5,new DexLabel[]{L1},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"name");
                DexLabel L6=new DexLabel();
                ddv.visitPrologue(L6);
                ddv.visitLineNumber(1015,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(1016,L7);
                ddv.visitLineNumber(1015,L1);
                ddv.visitLineNumber(1017,L2);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(1032,L8);
                ddv.visitLineNumber(1020,L4);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(1021,L9);
                ddv.visitStartLocal(2,L9,"old","Ljava/lang/Object;",null);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(1023,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(1024,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(1026,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(1028,L13);
                ddv.visitStartLocal(0,L13,"event","Ljavax/servlet/http/HttpSessionBindingEvent;",null);
                DexLabel L14=new DexLabel();
                ddv.visitStartLocal(1,L14,"i","I",null);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(1029,L15);
                ddv.visitLineNumber(1028,L5);
                code.visitLabel(L6);
                code.visitStmt1R(MONITOR_ENTER,4);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_BOOLEAN,3,4,new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager$Session;","_invalid","Z"));
                code.visitJumpStmt(IF_EQZ,3,-1,L2);
                code.visitLabel(L7);
                code.visitTypeStmt(NEW_INSTANCE,3,-1,"Ljava/lang/IllegalStateException;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 3},new Method("Ljava/lang/IllegalStateException;","<init>",new String[]{ },"V"));
                code.visitStmt1R(THROW,3);
                code.visitLabel(L1);
                code.visitStmt1R(MOVE_EXCEPTION,3);
                code.visitStmt1R(MONITOR_EXIT,4);
                code.visitStmt1R(THROW,3);
                code.visitLabel(L2);
                code.visitFieldStmt(IGET_OBJECT,3,4,new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager$Session;","_values","Ljava/util/Map;"));
                code.visitLabel(L3);
                code.visitJumpStmt(IF_NEZ,3,-1,L4);
                code.visitLabel(L8);
                code.visitStmt1R(MONITOR_EXIT,4);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L4);
                code.visitFieldStmt(IGET_OBJECT,3,4,new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager$Session;","_values","Ljava/util/Map;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 3,5},new Method("Ljava/util/Map;","remove",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitLabel(L9);
                code.visitJumpStmt(IF_EQZ,2,-1,L8);
                code.visitLabel(L10);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,5,2},new Method("Lorg/mortbay/jetty/servlet/AbstractSessionManager$Session;","unbindValue",new String[]{ "Ljava/lang/String;","Ljava/lang/Object;"},"V"));
                code.visitLabel(L11);
                code.visitFieldStmt(IGET_OBJECT,3,4,new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager$Session;","this$0","Lorg/mortbay/jetty/servlet/AbstractSessionManager;"));
                code.visitFieldStmt(IGET_OBJECT,3,3,new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","_sessionAttributeListeners","Ljava/lang/Object;"));
                code.visitJumpStmt(IF_EQZ,3,-1,L8);
                code.visitLabel(L12);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljavax/servlet/http/HttpSessionBindingEvent;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,4,5,2},new Method("Ljavax/servlet/http/HttpSessionBindingEvent;","<init>",new String[]{ "Ljavax/servlet/http/HttpSession;","Ljava/lang/String;","Ljava/lang/Object;"},"V"));
                code.visitLabel(L13);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L14);
                code.visitFieldStmt(IGET_OBJECT,3,4,new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager$Session;","this$0","Lorg/mortbay/jetty/servlet/AbstractSessionManager;"));
                code.visitFieldStmt(IGET_OBJECT,3,3,new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","_sessionAttributeListeners","Ljava/lang/Object;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 3},new Method("Lorg/mortbay/util/LazyList;","size",new String[]{ "Ljava/lang/Object;"},"I"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitJumpStmt(IF_GE,1,3,L8);
                code.visitLabel(L15);
                code.visitFieldStmt(IGET_OBJECT,3,4,new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager$Session;","this$0","Lorg/mortbay/jetty/servlet/AbstractSessionManager;"));
                code.visitFieldStmt(IGET_OBJECT,3,3,new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","_sessionAttributeListeners","Ljava/lang/Object;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 3,1},new Method("Lorg/mortbay/util/LazyList;","get",new String[]{ "Ljava/lang/Object;","I"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitTypeStmt(CHECK_CAST,3,-1,"Ljavax/servlet/http/HttpSessionAttributeListener;");
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 3,0},new Method("Ljavax/servlet/http/HttpSessionAttributeListener;","attributeRemoved",new String[]{ "Ljavax/servlet/http/HttpSessionBindingEvent;"},"V"));
                code.visitLabel(L5);
                code.visitStmt2R1N(ADD_INT_LIT8,1,1,1);
                code.visitJumpStmt(GOTO,-1,-1,L14);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m030_removeValue(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/servlet/AbstractSessionManager$Session;","removeValue",new String[]{ "Ljava/lang/String;"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/lang/IllegalStateException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"name");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(1041,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(1042,L1);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Lorg/mortbay/jetty/servlet/AbstractSessionManager$Session;","removeAttribute",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m031_setAttribute(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/servlet/AbstractSessionManager$Session;","setAttribute",new String[]{ "Ljava/lang/String;","Ljava/lang/Object;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(8);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexLabel L3=new DexLabel();
                code.visitTryCatch(L3,L2,new DexLabel[]{L2},new String[]{ null});
                DexLabel L4=new DexLabel();
                DexLabel L5=new DexLabel();
                code.visitTryCatch(L4,L5,new DexLabel[]{L2},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"name");
                ddv.visitParameterName(1,"value");
                DexLabel L6=new DexLabel();
                ddv.visitPrologue(L6);
                ddv.visitLineNumber(1047,L6);
                ddv.visitLineNumber(1049,L0);
                ddv.visitLineNumber(1081,L1);
                ddv.visitLineNumber(1053,L3);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(1054,L7);
                ddv.visitLineNumber(1047,L2);
                ddv.visitLineNumber(1055,L4);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(1056,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(1057,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(1059,L10);
                ddv.visitStartLocal(3,L10,"oldValue","Ljava/lang/Object;",null);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(1061,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(1062,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(1064,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(1066,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(1068,L15);
                ddv.visitStartLocal(0,L15,"event","Ljavax/servlet/http/HttpSessionBindingEvent;",null);
                DexLabel L16=new DexLabel();
                ddv.visitStartLocal(1,L16,"i","I",null);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(1070,L17);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(1072,L18);
                ddv.visitStartLocal(2,L18,"l","Ljavax/servlet/http/HttpSessionAttributeListener;",null);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(1073,L19);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(1068,L20);
                DexLabel L21=new DexLabel();
                ddv.visitEndLocal(0,L21);
                ddv.visitEndLocal(1,L21);
                ddv.visitEndLocal(2,L21);
                DexLabel L22=new DexLabel();
                ddv.visitLineNumber(1066,L22);
                DexLabel L23=new DexLabel();
                ddv.visitLineNumber(1074,L23);
                ddv.visitRestartLocal(0,L23);
                ddv.visitRestartLocal(1,L23);
                ddv.visitRestartLocal(2,L23);
                DexLabel L24=new DexLabel();
                ddv.visitLineNumber(1075,L24);
                DexLabel L25=new DexLabel();
                ddv.visitLineNumber(1077,L25);
                code.visitLabel(L6);
                code.visitStmt1R(MONITOR_ENTER,5);
                code.visitJumpStmt(IF_NEZ,7,-1,L3);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,6},new Method("Lorg/mortbay/jetty/servlet/AbstractSessionManager$Session;","removeAttribute",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L1);
                code.visitStmt1R(MONITOR_EXIT,5);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_BOOLEAN,4,5,new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager$Session;","_invalid","Z"));
                code.visitJumpStmt(IF_EQZ,4,-1,L4);
                code.visitLabel(L7);
                code.visitTypeStmt(NEW_INSTANCE,4,-1,"Ljava/lang/IllegalStateException;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 4},new Method("Ljava/lang/IllegalStateException;","<init>",new String[]{ },"V"));
                code.visitStmt1R(THROW,4);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,4);
                code.visitStmt1R(MONITOR_EXIT,5);
                code.visitStmt1R(THROW,4);
                code.visitLabel(L4);
                code.visitFieldStmt(IGET_OBJECT,4,5,new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager$Session;","_values","Ljava/util/Map;"));
                code.visitJumpStmt(IF_NEZ,4,-1,L9);
                code.visitLabel(L8);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Lorg/mortbay/jetty/servlet/AbstractSessionManager$Session;","newAttributeMap",new String[]{ },"Ljava/util/Map;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitFieldStmt(IPUT_OBJECT,4,5,new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager$Session;","_values","Ljava/util/Map;"));
                code.visitLabel(L9);
                code.visitFieldStmt(IGET_OBJECT,4,5,new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager$Session;","_values","Ljava/util/Map;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 4,6,7},new Method("Ljava/util/Map;","put",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitLabel(L10);
                code.visitJumpStmt(IF_EQZ,3,-1,L11);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7,3},new Method("Ljava/lang/Object;","equals",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,4);
                code.visitJumpStmt(IF_NEZ,4,-1,L1);
                code.visitLabel(L11);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,6,3},new Method("Lorg/mortbay/jetty/servlet/AbstractSessionManager$Session;","unbindValue",new String[]{ "Ljava/lang/String;","Ljava/lang/Object;"},"V"));
                code.visitLabel(L12);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,6,7},new Method("Lorg/mortbay/jetty/servlet/AbstractSessionManager$Session;","bindValue",new String[]{ "Ljava/lang/String;","Ljava/lang/Object;"},"V"));
                code.visitLabel(L13);
                code.visitFieldStmt(IGET_OBJECT,4,5,new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager$Session;","this$0","Lorg/mortbay/jetty/servlet/AbstractSessionManager;"));
                code.visitFieldStmt(IGET_OBJECT,4,4,new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","_sessionAttributeListeners","Ljava/lang/Object;"));
                code.visitJumpStmt(IF_EQZ,4,-1,L1);
                code.visitLabel(L14);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljavax/servlet/http/HttpSessionBindingEvent;");
                code.visitJumpStmt(IF_NEZ,3,-1,L21);
                code.visitStmt2R(MOVE_OBJECT,4,7);
                DexLabel L26=new DexLabel();
                code.visitLabel(L26);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,5,6,4},new Method("Ljavax/servlet/http/HttpSessionBindingEvent;","<init>",new String[]{ "Ljavax/servlet/http/HttpSession;","Ljava/lang/String;","Ljava/lang/Object;"},"V"));
                code.visitLabel(L15);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L16);
                code.visitFieldStmt(IGET_OBJECT,4,5,new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager$Session;","this$0","Lorg/mortbay/jetty/servlet/AbstractSessionManager;"));
                code.visitFieldStmt(IGET_OBJECT,4,4,new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","_sessionAttributeListeners","Ljava/lang/Object;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 4},new Method("Lorg/mortbay/util/LazyList;","size",new String[]{ "Ljava/lang/Object;"},"I"));
                code.visitStmt1R(MOVE_RESULT,4);
                code.visitJumpStmt(IF_GE,1,4,L1);
                code.visitLabel(L17);
                code.visitFieldStmt(IGET_OBJECT,4,5,new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager$Session;","this$0","Lorg/mortbay/jetty/servlet/AbstractSessionManager;"));
                code.visitFieldStmt(IGET_OBJECT,4,4,new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","_sessionAttributeListeners","Ljava/lang/Object;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 4,1},new Method("Lorg/mortbay/util/LazyList;","get",new String[]{ "Ljava/lang/Object;","I"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitTypeStmt(CHECK_CAST,2,-1,"Ljavax/servlet/http/HttpSessionAttributeListener;");
                code.visitLabel(L18);
                code.visitJumpStmt(IF_NEZ,3,-1,L23);
                code.visitLabel(L19);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 2,0},new Method("Ljavax/servlet/http/HttpSessionAttributeListener;","attributeAdded",new String[]{ "Ljavax/servlet/http/HttpSessionBindingEvent;"},"V"));
                code.visitLabel(L20);
                code.visitStmt2R1N(ADD_INT_LIT8,1,1,1);
                code.visitJumpStmt(GOTO,-1,-1,L16);
                code.visitLabel(L21);
                code.visitStmt2R(MOVE_OBJECT,4,3);
                code.visitLabel(L22);
                code.visitJumpStmt(GOTO,-1,-1,L26);
                code.visitLabel(L23);
                code.visitJumpStmt(IF_NEZ,7,-1,L25);
                code.visitLabel(L24);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 2,0},new Method("Ljavax/servlet/http/HttpSessionAttributeListener;","attributeRemoved",new String[]{ "Ljavax/servlet/http/HttpSessionBindingEvent;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L20);
                code.visitLabel(L25);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 2,0},new Method("Ljavax/servlet/http/HttpSessionAttributeListener;","attributeReplaced",new String[]{ "Ljavax/servlet/http/HttpSessionBindingEvent;"},"V"));
                code.visitLabel(L5);
                code.visitJumpStmt(GOTO,-1,-1,L20);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m032_setIdChanged(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/servlet/AbstractSessionManager$Session;","setIdChanged",new String[]{ "Z"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"changed");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(1086,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(1087,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_BOOLEAN,1,0,new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager$Session;","_idChanged","Z"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m033_setMaxInactiveInterval(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/servlet/AbstractSessionManager$Session;","setMaxInactiveInterval",new String[]{ "I"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(6);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"secs");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(1092,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(1093,L1);
                code.visitLabel(L0);
                code.visitStmt2R(INT_TO_LONG,0,5);
                code.visitConstStmt(CONST_WIDE_16,2,Long.valueOf(1000L)); // long: 0x00000000000003e8  double:0.000000
                code.visitStmt2R(MUL_LONG_2ADDR,0,2);
                code.visitFieldStmt(IPUT_WIDE,0,4,new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager$Session;","_maxIdleMs","J"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m034_timeout(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Lorg/mortbay/jetty/servlet/AbstractSessionManager$Session;","timeout",new String[]{ },"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/lang/IllegalStateException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L3=new DexLabel();
                ddv.visitPrologue(L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(922,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(925,L5);
                ddv.visitLineNumber(927,L0);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(928,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(931,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(932,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(930,L9);
                ddv.visitLineNumber(931,L2);
                code.visitLabel(L3);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitLabel(L4);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager$Session;","this$0","Lorg/mortbay/jetty/servlet/AbstractSessionManager;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,2,1},new Method("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","removeSession",new String[]{ "Lorg/mortbay/jetty/servlet/AbstractSessionManager$Session;","Z"},"V"));
                code.visitLabel(L5);
                code.visitStmt1R(MONITOR_ENTER,2);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET,0,2,new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager$Session;","_requests","I"));
                code.visitJumpStmt(IF_GTZ,0,-1,L9);
                code.visitLabel(L6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/jetty/servlet/AbstractSessionManager$Session;","doInvalidate",new String[]{ },"V"));
                code.visitLabel(L7);
                code.visitStmt1R(MONITOR_EXIT,2);
                code.visitLabel(L8);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L9);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitFieldStmt(IPUT_BOOLEAN,0,2,new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager$Session;","_doInvalidate","Z"));
                code.visitJumpStmt(GOTO,-1,-1,L7);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,0);
                code.visitStmt1R(MONITOR_EXIT,2);
                code.visitLabel(L1);
                code.visitStmt1R(THROW,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m035_toString(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/servlet/AbstractSessionManager$Session;","toString",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(1098,L0);
                code.visitLabel(L0);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Ljava/lang/Object;","getClass",new String[]{ },"Ljava/lang/Class;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/lang/Class;","getName",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitConstStmt(CONST_STRING,1,":");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/jetty/servlet/AbstractSessionManager$Session;","getId",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitConstStmt(CONST_STRING,1,"@");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Ljava/lang/Object;","hashCode",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "I"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m036_unbindValue(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Lorg/mortbay/jetty/servlet/AbstractSessionManager$Session;","unbindValue",new String[]{ "Ljava/lang/String;","Ljava/lang/Object;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"name");
                ddv.visitParameterName(1,"value");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(1128,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(1129,L1);
                DexLabel L2=new DexLabel();
                ddv.visitEndLocal(3,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(1130,L3);
                code.visitLabel(L0);
                code.visitJumpStmt(IF_EQZ,3,-1,L3);
                code.visitTypeStmt(INSTANCE_OF,0,3,"Ljavax/servlet/http/HttpSessionBindingListener;");
                code.visitJumpStmt(IF_EQZ,0,-1,L3);
                code.visitLabel(L1);
                code.visitTypeStmt(CHECK_CAST,3,-1,"Ljavax/servlet/http/HttpSessionBindingListener;");
                code.visitLabel(L2);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljavax/servlet/http/HttpSessionBindingEvent;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1,2},new Method("Ljavax/servlet/http/HttpSessionBindingEvent;","<init>",new String[]{ "Ljavax/servlet/http/HttpSession;","Ljava/lang/String;"},"V"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 3,0},new Method("Ljavax/servlet/http/HttpSessionBindingListener;","valueUnbound",new String[]{ "Ljavax/servlet/http/HttpSessionBindingEvent;"},"V"));
                code.visitLabel(L3);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m037_willPassivate(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Lorg/mortbay/jetty/servlet/AbstractSessionManager$Session;","willPassivate",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(7);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L3=new DexLabel();
                ddv.visitPrologue(L3);
                ddv.visitLineNumber(1135,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(1136,L4);
                ddv.visitStartLocal(1,L4,"event","Ljavax/servlet/http/HttpSessionEvent;",null);
                DexLabel L5=new DexLabel();
                ddv.visitStartLocal(2,L5,"iter","Ljava/util/Iterator;",null);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(1138,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(1139,L7);
                ddv.visitStartLocal(4,L7,"value","Ljava/lang/Object;",null);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(1141,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(1142,L9);
                ddv.visitStartLocal(3,L9,"listener","Ljavax/servlet/http/HttpSessionActivationListener;",null);
                ddv.visitLineNumber(1135,L2);
                ddv.visitEndLocal(1,L2);
                ddv.visitEndLocal(2,L2);
                ddv.visitEndLocal(4,L2);
                ddv.visitEndLocal(3,L2);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(1145,L10);
                ddv.visitRestartLocal(1,L10);
                ddv.visitRestartLocal(2,L10);
                code.visitLabel(L3);
                code.visitStmt1R(MONITOR_ENTER,6);
                code.visitLabel(L0);
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Ljavax/servlet/http/HttpSessionEvent;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1,6},new Method("Ljavax/servlet/http/HttpSessionEvent;","<init>",new String[]{ "Ljavax/servlet/http/HttpSession;"},"V"));
                code.visitLabel(L4);
                code.visitFieldStmt(IGET_OBJECT,5,6,new Field("Lorg/mortbay/jetty/servlet/AbstractSessionManager$Session;","_values","Ljava/util/Map;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 5},new Method("Ljava/util/Map;","values",new String[]{ },"Ljava/util/Collection;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 5},new Method("Ljava/util/Collection;","iterator",new String[]{ },"Ljava/util/Iterator;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitLabel(L5);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 2},new Method("Ljava/util/Iterator;","hasNext",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,5);
                code.visitJumpStmt(IF_EQZ,5,-1,L10);
                code.visitLabel(L6);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 2},new Method("Ljava/util/Iterator;","next",new String[]{ },"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitLabel(L7);
                code.visitTypeStmt(INSTANCE_OF,5,4,"Ljavax/servlet/http/HttpSessionActivationListener;");
                code.visitJumpStmt(IF_EQZ,5,-1,L5);
                code.visitLabel(L8);
                code.visitStmt2R(MOVE_OBJECT,0,4);
                code.visitTypeStmt(CHECK_CAST,0,-1,"Ljavax/servlet/http/HttpSessionActivationListener;");
                code.visitStmt2R(MOVE_OBJECT,3,0);
                code.visitLabel(L9);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 3,1},new Method("Ljavax/servlet/http/HttpSessionActivationListener;","sessionWillPassivate",new String[]{ "Ljavax/servlet/http/HttpSessionEvent;"},"V"));
                code.visitLabel(L1);
                code.visitJumpStmt(GOTO,-1,-1,L5);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,5);
                code.visitStmt1R(MONITOR_EXIT,6);
                code.visitStmt1R(THROW,5);
                code.visitLabel(L10);
                code.visitStmt1R(MONITOR_EXIT,6);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
