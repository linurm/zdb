package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0363_org_mortbay_resource_Resource {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(ACC_PUBLIC|ACC_ABSTRACT,"Lorg/mortbay/resource/Resource;","Ljava/lang/Object;",new String[]{ "Ljava/io/Serializable;"});
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("Resource.java");
        f000___defaultUseCaches(cv);
        f001__associate(cv);
        m000__clinit_(cv);
        m001__init_(cv);
        m002_getDefaultUseCaches(cv);
        m003_newClassPathResource(cv);
        m004_newClassPathResource(cv);
        m005_newResource(cv);
        m006_newResource(cv);
        m007_newResource(cv);
        m008_newResource(cv);
        m009_newSystemResource(cv);
        m010_setDefaultUseCaches(cv);
        m011_addPath(cv);
        m012_delete(cv);
        m013_encode(cv);
        m014_exists(cv);
        m015_finalize(cv);
        m016_getAlias(cv);
        m017_getAssociate(cv);
        m018_getFile(cv);
        m019_getInputStream(cv);
        m020_getListHTML(cv);
        m021_getName(cv);
        m022_getOutputStream(cv);
        m023_getURL(cv);
        m024_isDirectory(cv);
        m025_lastModified(cv);
        m026_length(cv);
        m027_list(cv);
        m028_release(cv);
        m029_renameTo(cv);
        m030_setAssociate(cv);
        m031_writeTo(cv);
    }
    public static void f000___defaultUseCaches(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC, new Field("Lorg/mortbay/resource/Resource;","__defaultUseCaches","Z"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f001__associate(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(0, new Field("Lorg/mortbay/resource/Resource;","_associate","Ljava/lang/Object;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void m000__clinit_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_STATIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/resource/Resource;","<clinit>",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(1);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(43,L0);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitFieldStmt(SPUT_BOOLEAN,0,-1,new Field("Lorg/mortbay/resource/Resource;","__defaultUseCaches","Z"));
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/resource/Resource;","<init>",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(1);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(41,L0);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/lang/Object;","<init>",new String[]{ },"V"));
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m002_getDefaultUseCaches(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Lorg/mortbay/resource/Resource;","getDefaultUseCaches",new String[]{ },"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(1);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(58,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(SGET_BOOLEAN,0,-1,new Field("Lorg/mortbay/resource/Resource;","__defaultUseCaches","Z"));
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m003_newClassPathResource(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Lorg/mortbay/resource/Resource;","newClassPathResource",new String[]{ "Ljava/lang/String;"},"Lorg/mortbay/resource/Resource;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"resource");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(235,L0);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 2,0,1},new Method("Lorg/mortbay/resource/Resource;","newClassPathResource",new String[]{ "Ljava/lang/String;","Z","Z"},"Lorg/mortbay/resource/Resource;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m004_newClassPathResource(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Lorg/mortbay/resource/Resource;","newClassPathResource",new String[]{ "Ljava/lang/String;","Z","Z"},"Lorg/mortbay/resource/Resource;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(7);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ "Ljava/lang/ClassNotFoundException;"});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"name");
                ddv.visitParameterName(1,"useCaches");
                ddv.visitParameterName(2,"checkParents");
                DexLabel L3=new DexLabel();
                ddv.visitPrologue(L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(252,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(254,L5);
                ddv.visitStartLocal(1,L5,"url","Ljava/net/URL;",null);
                ddv.visitLineNumber(258,L0);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(265,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(266,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(267,L8);
                ddv.visitLineNumber(260,L2);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(262,L9);
                ddv.visitStartLocal(0,L9,"e","Ljava/lang/ClassNotFoundException;",null);
                DexLabel L10=new DexLabel();
                ddv.visitRestartLocal(1,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(267,L11);
                ddv.visitEndLocal(0,L11);
                code.visitLabel(L3);
                code.visitConstStmt(CONST_CLASS,3,new DexType("Lorg/mortbay/resource/Resource;"));
                code.visitLabel(L4);
                code.visitConstStmt(CONST_CLASS,2,new DexType("Lorg/mortbay/resource/Resource;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,4},new Method("Ljava/lang/Class;","getResource",new String[]{ "Ljava/lang/String;"},"Ljava/net/URL;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L5);
                code.visitJumpStmt(IF_NEZ,1,-1,L6);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_CLASS,2,new DexType("Lorg/mortbay/resource/Resource;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 2,4,6},new Method("Lorg/mortbay/util/Loader;","getResource",new String[]{ "Ljava/lang/Class;","Ljava/lang/String;","Z"},"Ljava/net/URL;"));
                code.visitLabel(L1);
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L6);
                code.visitJumpStmt(IF_NEZ,1,-1,L11);
                code.visitLabel(L7);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L8);
                code.visitStmt1R(RETURN_OBJECT,2);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,2);
                code.visitStmt2R(MOVE_OBJECT,0,2);
                code.visitLabel(L9);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 4},new Method("Ljava/lang/ClassLoader;","getSystemResource",new String[]{ "Ljava/lang/String;"},"Ljava/net/URL;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L10);
                code.visitJumpStmt(GOTO,-1,-1,L6);
                code.visitLabel(L11);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1,5},new Method("Lorg/mortbay/resource/Resource;","newResource",new String[]{ "Ljava/net/URL;","Z"},"Lorg/mortbay/resource/Resource;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitJumpStmt(GOTO,-1,-1,L8);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m005_newResource(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Lorg/mortbay/resource/Resource;","newResource",new String[]{ "Ljava/lang/String;"},"Lorg/mortbay/resource/Resource;"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/net/MalformedURLException;"));
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"resource");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(120,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(SGET_BOOLEAN,0,-1,new Field("Lorg/mortbay/resource/Resource;","__defaultUseCaches","Z"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1,0},new Method("Lorg/mortbay/resource/Resource;","newResource",new String[]{ "Ljava/lang/String;","Z"},"Lorg/mortbay/resource/Resource;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m006_newResource(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Lorg/mortbay/resource/Resource;","newResource",new String[]{ "Ljava/lang/String;","Z"},"Lorg/mortbay/resource/Resource;"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/net/MalformedURLException;"));
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(15);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ "Ljava/net/MalformedURLException;"});
                DexLabel L3=new DexLabel();
                DexLabel L4=new DexLabel();
                DexLabel L5=new DexLabel();
                code.visitTryCatch(L3,L4,new DexLabel[]{L5},new String[]{ "Ljava/lang/Exception;"});
                DexLabel L6=new DexLabel();
                DexLabel L7=new DexLabel();
                code.visitTryCatch(L4,L6,new DexLabel[]{L7},new String[]{ "Ljava/lang/Exception;"});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"resource");
                ddv.visitParameterName(1,"useCaches");
                DexLabel L8=new DexLabel();
                ddv.visitPrologue(L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(132,L9);
                ddv.visitLineNumber(136,L0);
                ddv.visitStartLocal(6,L0,"url","Ljava/net/URL;",null);
                ddv.visitLineNumber(172,L1);
                ddv.visitEndLocal(6,L1);
                ddv.visitStartLocal(7,L1,"url","Ljava/net/URL;",null);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(173,L10);
                ddv.visitStartLocal(5,L10,"nurl","Ljava/lang/String;",null);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(175,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(182,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(185,L13);
                ddv.visitEndLocal(7,L13);
                ddv.visitEndLocal(5,L13);
                ddv.visitRestartLocal(6,L13);
                ddv.visitLineNumber(138,L2);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(140,L14);
                ddv.visitStartLocal(1,L14,"e","Ljava/net/MalformedURLException;",null);
                ddv.visitLineNumber(147,L3);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(148,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(150,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(151,L17);
                ddv.visitStartLocal(3,L17,"file","Ljava/io/File;",null);
                ddv.visitLineNumber(153,L4);
                ddv.visitRestartLocal(7,L4);
                DexLabel L18=new DexLabel();
                ddv.visitEndLocal(6,L18);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(154,L19);
                ddv.visitStartLocal(0,L19,"connection","Ljava/net/URLConnection;",null);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(155,L20);
                ddv.visitStartLocal(4,L6,"fileResource","Lorg/mortbay/resource/FileResource;",null);
                DexLabel L21=new DexLabel();
                ddv.visitRestartLocal(6,L21);
                DexLabel L22=new DexLabel();
                ddv.visitLineNumber(156,L22);
                ddv.visitLineNumber(158,L5);
                ddv.visitEndLocal(3,L5);
                ddv.visitEndLocal(7,L5);
                ddv.visitEndLocal(0,L5);
                ddv.visitEndLocal(4,L5);
                DexLabel L23=new DexLabel();
                ddv.visitLineNumber(160,L23);
                ddv.visitStartLocal(2,L23,"e2","Ljava/lang/Exception;",null);
                DexLabel L24=new DexLabel();
                ddv.visitLineNumber(161,L24);
                DexLabel L25=new DexLabel();
                ddv.visitLineNumber(166,L25);
                ddv.visitEndLocal(2,L25);
                DexLabel L26=new DexLabel();
                ddv.visitLineNumber(167,L26);
                DexLabel L27=new DexLabel();
                ddv.visitLineNumber(185,L27);
                ddv.visitEndLocal(1,L27);
                ddv.visitEndLocal(6,L27);
                ddv.visitRestartLocal(5,L27);
                ddv.visitRestartLocal(7,L27);
                DexLabel L28=new DexLabel();
                ddv.visitRestartLocal(6,L28);
                ddv.visitLineNumber(158,L7);
                ddv.visitEndLocal(5,L7);
                ddv.visitEndLocal(6,L7);
                ddv.visitRestartLocal(1,L7);
                ddv.visitRestartLocal(3,L7);
                DexLabel L29=new DexLabel();
                ddv.visitRestartLocal(6,L29);
                code.visitLabel(L8);
                code.visitConstStmt(CONST_16,12, Integer.valueOf(47)); // int: 0x0000002f  float:0.000000
                code.visitConstStmt(CONST_4,11, Integer.valueOf(2)); // int: 0x00000002  float:0.000000
                code.visitConstStmt(CONST_4,10, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitLabel(L9);
                code.visitConstStmt(CONST_4,6, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L0);
                code.visitTypeStmt(NEW_INSTANCE,7,-1,"Ljava/net/URL;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 7,13},new Method("Ljava/net/URL;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7},new Method("Ljava/net/URL;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitLabel(L10);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Ljava/lang/String;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,8);
                code.visitJumpStmt(IF_LEZ,8,-1,L27);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Ljava/lang/String;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,8);
                code.visitStmt2R(SUB_INT_2ADDR,8,10);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,8},new Method("Ljava/lang/String;","charAt",new String[]{ "I"},"C"));
                code.visitStmt1R(MOVE_RESULT,8);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 13},new Method("Ljava/lang/String;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,9);
                code.visitStmt2R(SUB_INT_2ADDR,9,10);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 13,9},new Method("Ljava/lang/String;","charAt",new String[]{ "I"},"C"));
                code.visitStmt1R(MOVE_RESULT,9);
                code.visitJumpStmt(IF_EQ,8,9,L27);
                code.visitLabel(L11);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Ljava/lang/String;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,8);
                code.visitStmt2R(SUB_INT_2ADDR,8,10);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,8},new Method("Ljava/lang/String;","charAt",new String[]{ "I"},"C"));
                code.visitStmt1R(MOVE_RESULT,8);
                DexLabel L30=new DexLabel();
                code.visitJumpStmt(IF_NE,8,12,L30);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Ljava/lang/String;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,8);
                code.visitStmt2R(SUB_INT_2ADDR,8,11);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,8},new Method("Ljava/lang/String;","charAt",new String[]{ "I"},"C"));
                code.visitStmt1R(MOVE_RESULT,8);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 13},new Method("Ljava/lang/String;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,9);
                code.visitStmt2R(SUB_INT_2ADDR,9,10);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 13,9},new Method("Ljava/lang/String;","charAt",new String[]{ "I"},"C"));
                code.visitStmt1R(MOVE_RESULT,9);
                code.visitJumpStmt(IF_EQ,8,9,L27);
                code.visitLabel(L30);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 13},new Method("Ljava/lang/String;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,8);
                code.visitStmt2R(SUB_INT_2ADDR,8,10);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 13,8},new Method("Ljava/lang/String;","charAt",new String[]{ "I"},"C"));
                code.visitStmt1R(MOVE_RESULT,8);
                code.visitJumpStmt(IF_NE,8,12,L12);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 13},new Method("Ljava/lang/String;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,8);
                code.visitStmt2R(SUB_INT_2ADDR,8,11);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 13,8},new Method("Ljava/lang/String;","charAt",new String[]{ "I"},"C"));
                code.visitStmt1R(MOVE_RESULT,8);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Ljava/lang/String;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,9);
                code.visitStmt2R(SUB_INT_2ADDR,9,10);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,9},new Method("Ljava/lang/String;","charAt",new String[]{ "I"},"C"));
                code.visitStmt1R(MOVE_RESULT,9);
                code.visitJumpStmt(IF_EQ,8,9,L27);
                code.visitLabel(L12);
                code.visitTypeStmt(NEW_INSTANCE,8,-1,"Lorg/mortbay/resource/BadResource;");
                code.visitTypeStmt(NEW_INSTANCE,9,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 9},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,10,"Trailing special characters stripped by URL in ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9,10},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,9);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9,13},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,9);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,9);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 8,7,9},new Method("Lorg/mortbay/resource/BadResource;","<init>",new String[]{ "Ljava/net/URL;","Ljava/lang/String;"},"V"));
                code.visitStmt2R(MOVE_OBJECT,6,7);
                code.visitLabel(L13);
                code.visitStmt1R(RETURN_OBJECT,8);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,8);
                code.visitStmt2R(MOVE_OBJECT,1,8);
                code.visitLabel(L14);
                code.visitConstStmt(CONST_STRING,8,"ftp:");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 13,8},new Method("Ljava/lang/String;","startsWith",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,8);
                code.visitJumpStmt(IF_NEZ,8,-1,L25);
                code.visitConstStmt(CONST_STRING,8,"file:");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 13,8},new Method("Ljava/lang/String;","startsWith",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,8);
                code.visitJumpStmt(IF_NEZ,8,-1,L25);
                code.visitConstStmt(CONST_STRING,8,"jar:");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 13,8},new Method("Ljava/lang/String;","startsWith",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,8);
                code.visitJumpStmt(IF_NEZ,8,-1,L25);
                code.visitLabel(L3);
                code.visitConstStmt(CONST_STRING,8,"./");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 13,8},new Method("Ljava/lang/String;","startsWith",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,8);
                code.visitJumpStmt(IF_EQZ,8,-1,L16);
                code.visitLabel(L15);
                code.visitConstStmt(CONST_4,8, Integer.valueOf(2)); // int: 0x00000002  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 13,8},new Method("Ljava/lang/String;","substring",new String[]{ "I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,13);
                code.visitLabel(L16);
                code.visitTypeStmt(NEW_INSTANCE,8,-1,"Ljava/io/File;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 8,13},new Method("Ljava/io/File;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8},new Method("Ljava/io/File;","getCanonicalFile",new String[]{ },"Ljava/io/File;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitLabel(L17);
                code.visitTypeStmt(NEW_INSTANCE,7,-1,"Ljava/net/URL;");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Ljava/io/File;","toURL",new String[]{ },"Ljava/net/URL;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8},new Method("Ljava/net/URL;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 8},new Method("Lorg/mortbay/util/URIUtil;","encodePath",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 7,8},new Method("Ljava/net/URL;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7},new Method("Ljava/net/URL;","openConnection",new String[]{ },"Ljava/net/URLConnection;"));
                code.visitLabel(L18);
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L19);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,14},new Method("Ljava/net/URLConnection;","setUseCaches",new String[]{ "Z"},"V"));
                code.visitLabel(L20);
                code.visitTypeStmt(NEW_INSTANCE,4,-1,"Lorg/mortbay/resource/FileResource;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 4,7,0,3},new Method("Lorg/mortbay/resource/FileResource;","<init>",new String[]{ "Ljava/net/URL;","Ljava/net/URLConnection;","Ljava/io/File;"},"V"));
                code.visitLabel(L6);
                code.visitStmt2R(MOVE_OBJECT,6,7);
                code.visitLabel(L21);
                code.visitStmt2R(MOVE_OBJECT,8,4);
                code.visitLabel(L22);
                code.visitJumpStmt(GOTO,-1,-1,L13);
                code.visitLabel(L5);
                code.visitStmt1R(MOVE_EXCEPTION,8);
                code.visitStmt2R(MOVE_OBJECT,2,8);
                code.visitLabel(L23);
                code.visitConstStmt(CONST_STRING,8,"EXCEPTION ");
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 8,2},new Method("Lorg/mortbay/log/Log;","debug",new String[]{ "Ljava/lang/String;","Ljava/lang/Object;"},"V"));
                code.visitLabel(L24);
                code.visitStmt1R(THROW,1);
                code.visitLabel(L25);
                code.visitTypeStmt(NEW_INSTANCE,8,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 8},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,9,"Bad Resource: ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8,9},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8,13},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 8},new Method("Lorg/mortbay/log/Log;","warn",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L26);
                code.visitStmt1R(THROW,1);
                code.visitLabel(L27);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 7},new Method("Lorg/mortbay/resource/Resource;","newResource",new String[]{ "Ljava/net/URL;"},"Lorg/mortbay/resource/Resource;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitStmt2R(MOVE_OBJECT,6,7);
                code.visitLabel(L28);
                code.visitJumpStmt(GOTO,-1,-1,L13);
                code.visitLabel(L7);
                code.visitStmt1R(MOVE_EXCEPTION,8);
                code.visitStmt2R(MOVE_OBJECT,2,8);
                code.visitStmt2R(MOVE_OBJECT,6,7);
                code.visitLabel(L29);
                code.visitJumpStmt(GOTO,-1,-1,L23);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m007_newResource(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Lorg/mortbay/resource/Resource;","newResource",new String[]{ "Ljava/net/URL;"},"Lorg/mortbay/resource/Resource;"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"url");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(69,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(SGET_BOOLEAN,0,-1,new Field("Lorg/mortbay/resource/Resource;","__defaultUseCaches","Z"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1,0},new Method("Lorg/mortbay/resource/Resource;","newResource",new String[]{ "Ljava/net/URL;","Z"},"Lorg/mortbay/resource/Resource;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m008_newResource(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Lorg/mortbay/resource/Resource;","newResource",new String[]{ "Ljava/net/URL;","Z"},"Lorg/mortbay/resource/Resource;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(7);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ "Ljava/lang/Exception;"});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"url");
                ddv.visitParameterName(1,"useCaches");
                DexLabel L3=new DexLabel();
                ddv.visitPrologue(L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(81,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(107,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(84,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(85,L7);
                ddv.visitStartLocal(2,L7,"url_string","Ljava/lang/String;",null);
                ddv.visitLineNumber(89,L0);
                ddv.visitStartLocal(1,L1,"fileResource","Lorg/mortbay/resource/FileResource;",null);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(90,L8);
                ddv.visitLineNumber(92,L2);
                ddv.visitEndLocal(1,L2);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(94,L9);
                ddv.visitStartLocal(0,L9,"e","Ljava/lang/Exception;",null);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(95,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(98,L11);
                ddv.visitEndLocal(0,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(100,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(102,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(104,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(107,L15);
                code.visitLabel(L3);
                code.visitConstStmt(CONST_4,4, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L4);
                code.visitJumpStmt(IF_NEZ,5,-1,L6);
                code.visitStmt2R(MOVE_OBJECT,3,4);
                code.visitLabel(L5);
                code.visitStmt1R(RETURN_OBJECT,3);
                code.visitLabel(L6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Ljava/net/URL;","toExternalForm",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitLabel(L7);
                code.visitConstStmt(CONST_STRING,3,"file:");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3},new Method("Ljava/lang/String;","startsWith",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitJumpStmt(IF_EQZ,3,-1,L11);
                code.visitLabel(L0);
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Lorg/mortbay/resource/FileResource;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1,5},new Method("Lorg/mortbay/resource/FileResource;","<init>",new String[]{ "Ljava/net/URL;"},"V"));
                code.visitLabel(L1);
                code.visitStmt2R(MOVE_OBJECT,3,1);
                code.visitLabel(L8);
                code.visitJumpStmt(GOTO,-1,-1,L5);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,3);
                code.visitStmt2R(MOVE_OBJECT,0,3);
                code.visitLabel(L9);
                code.visitConstStmt(CONST_STRING,3,"EXCEPTION ");
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 3,0},new Method("Lorg/mortbay/log/Log;","debug",new String[]{ "Ljava/lang/String;","Ljava/lang/Object;"},"V"));
                code.visitLabel(L10);
                code.visitTypeStmt(NEW_INSTANCE,3,-1,"Lorg/mortbay/resource/BadResource;");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/lang/Exception;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 3,5,4},new Method("Lorg/mortbay/resource/BadResource;","<init>",new String[]{ "Ljava/net/URL;","Ljava/lang/String;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L5);
                code.visitLabel(L11);
                code.visitConstStmt(CONST_STRING,3,"jar:file:");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3},new Method("Ljava/lang/String;","startsWith",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitJumpStmt(IF_EQZ,3,-1,L13);
                code.visitLabel(L12);
                code.visitTypeStmt(NEW_INSTANCE,3,-1,"Lorg/mortbay/resource/JarFileResource;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 3,5,6},new Method("Lorg/mortbay/resource/JarFileResource;","<init>",new String[]{ "Ljava/net/URL;","Z"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L5);
                code.visitLabel(L13);
                code.visitConstStmt(CONST_STRING,3,"jar:");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3},new Method("Ljava/lang/String;","startsWith",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitJumpStmt(IF_EQZ,3,-1,L15);
                code.visitLabel(L14);
                code.visitTypeStmt(NEW_INSTANCE,3,-1,"Lorg/mortbay/resource/JarResource;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 3,5,6},new Method("Lorg/mortbay/resource/JarResource;","<init>",new String[]{ "Ljava/net/URL;","Z"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L5);
                code.visitLabel(L15);
                code.visitTypeStmt(NEW_INSTANCE,3,-1,"Lorg/mortbay/resource/URLResource;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 3,5,4,6},new Method("Lorg/mortbay/resource/URLResource;","<init>",new String[]{ "Ljava/net/URL;","Ljava/net/URLConnection;","Z"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L5);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m009_newSystemResource(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Lorg/mortbay/resource/Resource;","newSystemResource",new String[]{ "Ljava/lang/String;"},"Lorg/mortbay/resource/Resource;"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(6);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"resource");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(196,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(199,L2);
                ddv.visitStartLocal(1,L2,"url","Ljava/net/URL;",null);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(200,L3);
                ddv.visitStartLocal(0,L3,"loader","Ljava/lang/ClassLoader;",null);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(202,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(203,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(204,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(206,L7);
                ddv.visitRestartLocal(1,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(208,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(209,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(211,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(212,L11);
                ddv.visitRestartLocal(1,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(213,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(217,L13);
                ddv.visitRestartLocal(1,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(219,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(220,L15);
                ddv.visitRestartLocal(1,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(221,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(224,L17);
                ddv.visitRestartLocal(1,L17);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(225,L18);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(227,L19);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitConstStmt(CONST_STRING,4,"/");
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L2);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Ljava/lang/Thread;","currentThread",new String[]{ },"Ljava/lang/Thread;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Ljava/lang/Thread;","getContextClassLoader",new String[]{ },"Ljava/lang/ClassLoader;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L3);
                code.visitJumpStmt(IF_EQZ,0,-1,L7);
                code.visitLabel(L4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,5},new Method("Ljava/lang/ClassLoader;","getResource",new String[]{ "Ljava/lang/String;"},"Ljava/net/URL;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L5);
                code.visitJumpStmt(IF_NEZ,1,-1,L7);
                code.visitConstStmt(CONST_STRING,2,"/");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,4},new Method("Ljava/lang/String;","startsWith",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitJumpStmt(IF_EQZ,2,-1,L7);
                code.visitLabel(L6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,3},new Method("Ljava/lang/String;","substring",new String[]{ "I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,2},new Method("Ljava/lang/ClassLoader;","getResource",new String[]{ "Ljava/lang/String;"},"Ljava/net/URL;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L7);
                code.visitJumpStmt(IF_NEZ,1,-1,L13);
                code.visitLabel(L8);
                code.visitConstStmt(CONST_CLASS,2,new DexType("Lorg/mortbay/resource/Resource;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Ljava/lang/Class;","getClassLoader",new String[]{ },"Ljava/lang/ClassLoader;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L9);
                code.visitJumpStmt(IF_EQZ,0,-1,L13);
                code.visitLabel(L10);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,5},new Method("Ljava/lang/ClassLoader;","getResource",new String[]{ "Ljava/lang/String;"},"Ljava/net/URL;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L11);
                code.visitJumpStmt(IF_NEZ,1,-1,L13);
                code.visitConstStmt(CONST_STRING,2,"/");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,4},new Method("Ljava/lang/String;","startsWith",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitJumpStmt(IF_EQZ,2,-1,L13);
                code.visitLabel(L12);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,3},new Method("Ljava/lang/String;","substring",new String[]{ "I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,2},new Method("Ljava/lang/ClassLoader;","getResource",new String[]{ "Ljava/lang/String;"},"Ljava/net/URL;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L13);
                code.visitJumpStmt(IF_NEZ,1,-1,L17);
                code.visitLabel(L14);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 5},new Method("Ljava/lang/ClassLoader;","getSystemResource",new String[]{ "Ljava/lang/String;"},"Ljava/net/URL;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L15);
                code.visitJumpStmt(IF_NEZ,1,-1,L17);
                code.visitConstStmt(CONST_STRING,2,"/");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,4},new Method("Ljava/lang/String;","startsWith",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitJumpStmt(IF_EQZ,2,-1,L17);
                code.visitLabel(L16);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,3},new Method("Ljava/lang/String;","substring",new String[]{ "I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,2},new Method("Ljava/lang/ClassLoader;","getResource",new String[]{ "Ljava/lang/String;"},"Ljava/net/URL;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L17);
                DexLabel L20=new DexLabel();
                code.visitJumpStmt(IF_NEZ,1,-1,L20);
                code.visitLabel(L18);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L19);
                code.visitStmt1R(RETURN_OBJECT,2);
                code.visitLabel(L20);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1},new Method("Lorg/mortbay/resource/Resource;","newResource",new String[]{ "Ljava/net/URL;"},"Lorg/mortbay/resource/Resource;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitJumpStmt(GOTO,-1,-1,L19);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m010_setDefaultUseCaches(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Lorg/mortbay/resource/Resource;","setDefaultUseCaches",new String[]{ "Z"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(1);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"useCaches");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(53,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(54,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(SPUT_BOOLEAN,0,-1,new Field("Lorg/mortbay/resource/Resource;","__defaultUseCaches","Z"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m011_addPath(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Lorg/mortbay/resource/Resource;","addPath",new String[]{ "Ljava/lang/String;"},"Lorg/mortbay/resource/Resource;"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visit(null, new DexType("Ljava/net/MalformedURLException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            mv.visitEnd();
        }
    }
    public static void m012_delete(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Lorg/mortbay/resource/Resource;","delete",new String[]{ },"Z"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/lang/SecurityException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            mv.visitEnd();
        }
    }
    public static void m013_encode(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/resource/Resource;","encode",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"uri");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(390,L0);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 2},new Method("Lorg/mortbay/util/URIUtil;","encodePath",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m014_exists(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Lorg/mortbay/resource/Resource;","exists",new String[]{ },"Z"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m015_finalize(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Lorg/mortbay/resource/Resource;","finalize",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(1);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(275,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(276,L1);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/resource/Resource;","release",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m016_getAlias(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/resource/Resource;","getAlias",new String[]{ },"Ljava/net/URL;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(411,L0);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m017_getAssociate(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/resource/Resource;","getAssociate",new String[]{ },"Ljava/lang/Object;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(396,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/resource/Resource;","_associate","Ljava/lang/Object;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m018_getFile(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Lorg/mortbay/resource/Resource;","getFile",new String[]{ },"Ljava/io/File;"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            mv.visitEnd();
        }
    }
    public static void m019_getInputStream(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Lorg/mortbay/resource/Resource;","getInputStream",new String[]{ },"Ljava/io/InputStream;"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            mv.visitEnd();
        }
    }
    public static void m020_getListHTML(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/resource/Resource;","getListHTML",new String[]{ "Ljava/lang/String;","Z"},"Ljava/lang/String;"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(16);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"base");
                ddv.visitParameterName(1,"parent");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(424,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(474,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(427,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(428,L4);
                ddv.visitStartLocal(6,L4,"ls","[Ljava/lang/String;",null);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(429,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(430,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(432,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(433,L8);
                ddv.visitStartLocal(1,L8,"decodedBase","Ljava/lang/String;",null);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(435,L9);
                ddv.visitStartLocal(8,L9,"title","Ljava/lang/String;",null);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(436,L10);
                ddv.visitStartLocal(0,L10,"buf","Ljava/lang/StringBuffer;",null);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(437,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(438,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(439,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(440,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(442,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(444,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(445,L17);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(446,L18);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(449,L19);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(451,L20);
                ddv.visitStartLocal(2,L20,"dfmt","Ljava/text/DateFormat;",null);
                DexLabel L21=new DexLabel();
                ddv.visitStartLocal(4,L21,"i","I",null);
                DexLabel L22=new DexLabel();
                ddv.visitLineNumber(453,L22);
                DexLabel L23=new DexLabel();
                ddv.visitLineNumber(454,L23);
                ddv.visitStartLocal(3,L23,"encoded","Ljava/lang/String;",null);
                DexLabel L24=new DexLabel();
                ddv.visitLineNumber(456,L24);
                ddv.visitStartLocal(5,L24,"item","Lorg/mortbay/resource/Resource;",null);
                DexLabel L25=new DexLabel();
                ddv.visitLineNumber(457,L25);
                DexLabel L26=new DexLabel();
                ddv.visitLineNumber(459,L26);
                ddv.visitStartLocal(7,L26,"path","Ljava/lang/String;",null);
                DexLabel L27=new DexLabel();
                ddv.visitLineNumber(460,L27);
                DexLabel L28=new DexLabel();
                ddv.visitLineNumber(461,L28);
                DexLabel L29=new DexLabel();
                ddv.visitLineNumber(462,L29);
                DexLabel L30=new DexLabel();
                ddv.visitLineNumber(463,L30);
                DexLabel L31=new DexLabel();
                ddv.visitLineNumber(464,L31);
                DexLabel L32=new DexLabel();
                ddv.visitLineNumber(465,L32);
                DexLabel L33=new DexLabel();
                ddv.visitLineNumber(466,L33);
                DexLabel L34=new DexLabel();
                ddv.visitLineNumber(467,L34);
                DexLabel L35=new DexLabel();
                ddv.visitLineNumber(468,L35);
                DexLabel L36=new DexLabel();
                ddv.visitLineNumber(469,L36);
                DexLabel L37=new DexLabel();
                ddv.visitLineNumber(451,L37);
                DexLabel L38=new DexLabel();
                ddv.visitLineNumber(471,L38);
                ddv.visitEndLocal(3,L38);
                ddv.visitEndLocal(5,L38);
                ddv.visitEndLocal(7,L38);
                DexLabel L39=new DexLabel();
                ddv.visitLineNumber(472,L39);
                DexLabel L40=new DexLabel();
                ddv.visitLineNumber(474,L40);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,10, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitConstStmt(CONST_4,11, Integer.valueOf(2)); // int: 0x00000002  float:0.000000
                code.visitConstStmt(CONST_STRING,12,"/");
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 13},new Method("Lorg/mortbay/resource/Resource;","isDirectory",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,9);
                code.visitJumpStmt(IF_NEZ,9,-1,L3);
                code.visitStmt2R(MOVE_OBJECT,9,10);
                code.visitLabel(L2);
                code.visitStmt1R(RETURN_OBJECT,9);
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 13},new Method("Lorg/mortbay/resource/Resource;","list",new String[]{ },"[Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitLabel(L4);
                code.visitJumpStmt(IF_NEZ,6,-1,L6);
                code.visitStmt2R(MOVE_OBJECT,9,10);
                code.visitLabel(L5);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitLabel(L6);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 6},new Method("Ljava/util/Arrays;","sort",new String[]{ "[Ljava/lang/Object;"},"V"));
                code.visitLabel(L7);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 14},new Method("Lorg/mortbay/util/URIUtil;","decodePath",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L8);
                code.visitTypeStmt(NEW_INSTANCE,9,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 9},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,10,"Directory: ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9,10},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,9);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,9);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitLabel(L9);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/lang/StringBuffer;");
                code.visitConstStmt(CONST_16,9, Integer.valueOf(4096)); // int: 0x00001000  float:0.000000
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,9},new Method("Ljava/lang/StringBuffer;","<init>",new String[]{ "I"},"V"));
                code.visitLabel(L10);
                code.visitConstStmt(CONST_STRING,9,"<HTML><HEAD><TITLE>");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,9},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L11);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,8},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L12);
                code.visitConstStmt(CONST_STRING,9,"</TITLE></HEAD><BODY>\n<H1>");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,9},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L13);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,8},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L14);
                code.visitConstStmt(CONST_STRING,9,"</H1><TABLE BORDER=0>");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,9},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L15);
                code.visitJumpStmt(IF_EQZ,15,-1,L19);
                code.visitLabel(L16);
                code.visitConstStmt(CONST_STRING,9,"<TR><TD><A HREF=");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,9},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L17);
                code.visitConstStmt(CONST_STRING,9,"../");
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 14,9},new Method("Lorg/mortbay/util/URIUtil;","addPaths",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,9);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,9},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L18);
                code.visitConstStmt(CONST_STRING,9,">Parent Directory</A></TD><TD></TD><TD></TD></TR>\n");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,9},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L19);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 11,11},new Method("Ljava/text/DateFormat;","getDateTimeInstance",new String[]{ "I","I"},"Ljava/text/DateFormat;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitLabel(L20);
                code.visitConstStmt(CONST_4,4, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L21);
                code.visitStmt2R(ARRAY_LENGTH,9,6);
                code.visitJumpStmt(IF_GE,4,9,L38);
                code.visitLabel(L22);
                code.visitStmt3R(AGET_OBJECT,9,6,4);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 9},new Method("Lorg/mortbay/util/URIUtil;","encodePath",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitLabel(L23);
                code.visitStmt3R(AGET_OBJECT,9,6,4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 13,9},new Method("Lorg/mortbay/resource/Resource;","addPath",new String[]{ "Ljava/lang/String;"},"Lorg/mortbay/resource/Resource;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitLabel(L24);
                code.visitConstStmt(CONST_STRING,9,"<TR><TD><A HREF=\"");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,9},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L25);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 14,3},new Method("Lorg/mortbay/util/URIUtil;","addPaths",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitLabel(L26);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Lorg/mortbay/resource/Resource;","isDirectory",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,9);
                code.visitJumpStmt(IF_EQZ,9,-1,L28);
                code.visitConstStmt(CONST_STRING,9,"/");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7,12},new Method("Ljava/lang/String;","endsWith",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,9);
                code.visitJumpStmt(IF_NEZ,9,-1,L28);
                code.visitLabel(L27);
                code.visitConstStmt(CONST_STRING,9,"/");
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 7,12},new Method("Lorg/mortbay/util/URIUtil;","addPaths",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitLabel(L28);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,7},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L29);
                code.visitConstStmt(CONST_STRING,9,"\">");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,9},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L30);
                code.visitStmt3R(AGET_OBJECT,9,6,4);
                code.visitConstStmt(CONST_STRING,10,"<");
                code.visitConstStmt(CONST_STRING,11,"&lt;");
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 9,10,11},new Method("Lorg/mortbay/util/StringUtil;","replace",new String[]{ "Ljava/lang/String;","Ljava/lang/String;","Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,9);
                code.visitConstStmt(CONST_STRING,10,">");
                code.visitConstStmt(CONST_STRING,11,"&gt;");
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 9,10,11},new Method("Lorg/mortbay/util/StringUtil;","replace",new String[]{ "Ljava/lang/String;","Ljava/lang/String;","Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,9);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,9},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L31);
                code.visitConstStmt(CONST_STRING,9,"&nbsp;");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,9},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L32);
                code.visitConstStmt(CONST_STRING,9,"</TD><TD ALIGN=right>");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,9},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L33);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Lorg/mortbay/resource/Resource;","length",new String[]{ },"J"));
                code.visitStmt1R(MOVE_RESULT_WIDE,9);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,9,10},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "J"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L34);
                code.visitConstStmt(CONST_STRING,9," bytes&nbsp;</TD><TD>");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,9},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L35);
                code.visitTypeStmt(NEW_INSTANCE,9,-1,"Ljava/util/Date;");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Lorg/mortbay/resource/Resource;","lastModified",new String[]{ },"J"));
                code.visitStmt1R(MOVE_RESULT_WIDE,10);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 9,10,11},new Method("Ljava/util/Date;","<init>",new String[]{ "J"},"V"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,9},new Method("Ljava/text/DateFormat;","format",new String[]{ "Ljava/util/Date;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,9);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,9},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L36);
                code.visitConstStmt(CONST_STRING,9,"</TD></TR>\n");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,9},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L37);
                code.visitStmt2R1N(ADD_INT_LIT8,4,4,1);
                code.visitJumpStmt(GOTO,-1,-1,L21);
                code.visitLabel(L38);
                code.visitConstStmt(CONST_STRING,9,"</TABLE>\n");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,9},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L39);
                code.visitConstStmt(CONST_STRING,9,"</BODY></HTML>\n");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,9},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L40);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/lang/StringBuffer;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,9);
                code.visitJumpStmt(GOTO_16,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m021_getName(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Lorg/mortbay/resource/Resource;","getName",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m022_getOutputStream(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Lorg/mortbay/resource/Resource;","getOutputStream",new String[]{ },"Ljava/io/OutputStream;"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visit(null, new DexType("Ljava/lang/SecurityException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            mv.visitEnd();
        }
    }
    public static void m023_getURL(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Lorg/mortbay/resource/Resource;","getURL",new String[]{ },"Ljava/net/URL;"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m024_isDirectory(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Lorg/mortbay/resource/Resource;","isDirectory",new String[]{ },"Z"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m025_lastModified(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Lorg/mortbay/resource/Resource;","lastModified",new String[]{ },"J"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m026_length(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Lorg/mortbay/resource/Resource;","length",new String[]{ },"J"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m027_list(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Lorg/mortbay/resource/Resource;","list",new String[]{ },"[Ljava/lang/String;"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m028_release(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Lorg/mortbay/resource/Resource;","release",new String[]{ },"V"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m029_renameTo(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Lorg/mortbay/resource/Resource;","renameTo",new String[]{ "Lorg/mortbay/resource/Resource;"},"Z"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/lang/SecurityException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            mv.visitEnd();
        }
    }
    public static void m030_setAssociate(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/resource/Resource;","setAssociate",new String[]{ "Ljava/lang/Object;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"o");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(402,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(403,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_OBJECT,1,0,new Field("Lorg/mortbay/resource/Resource;","_associate","Ljava/lang/Object;"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m031_writeTo(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/resource/Resource;","writeTo",new String[]{ "Ljava/io/OutputStream;","J","J"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(9);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexLabel L3=new DexLabel();
                DexLabel L4=new DexLabel();
                code.visitTryCatch(L3,L4,new DexLabel[]{L2},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"out");
                ddv.visitParameterName(1,"start");
                ddv.visitParameterName(2,"count");
                DexLabel L5=new DexLabel();
                ddv.visitPrologue(L5);
                ddv.visitLineNumber(486,L5);
                ddv.visitLineNumber(489,L0);
                ddv.visitStartLocal(0,L0,"in","Ljava/io/InputStream;",null);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(490,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(491,L7);
                ddv.visitLineNumber(497,L1);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(499,L8);
                ddv.visitLineNumber(493,L3);
                ddv.visitLineNumber(497,L2);
                code.visitLabel(L5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Lorg/mortbay/resource/Resource;","getInputStream",new String[]{ },"Ljava/io/InputStream;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,5,6},new Method("Ljava/io/InputStream;","skip",new String[]{ "J"},"J"));
                code.visitLabel(L6);
                code.visitConstStmt(CONST_WIDE_16,1,Long.valueOf(0L)); // long: 0x0000000000000000  double:0.000000
                code.visitStmt3R(CMP_LONG,1,7,1);
                code.visitJumpStmt(IF_GEZ,1,-1,L3);
                code.visitLabel(L7);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0,4},new Method("Lorg/mortbay/util/IO;","copy",new String[]{ "Ljava/io/InputStream;","Ljava/io/OutputStream;"},"V"));
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/io/InputStream;","close",new String[]{ },"V"));
                code.visitLabel(L8);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0,4,7,8},new Method("Lorg/mortbay/util/IO;","copy",new String[]{ "Ljava/io/InputStream;","Ljava/io/OutputStream;","J"},"V"));
                code.visitLabel(L4);
                code.visitJumpStmt(GOTO,-1,-1,L1);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/io/InputStream;","close",new String[]{ },"V"));
                code.visitStmt1R(THROW,1);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
