package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0281_org_mortbay_jetty_security_FormAuthenticator {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(ACC_PUBLIC,"Lorg/mortbay/jetty/security/FormAuthenticator;","Ljava/lang/Object;",new String[]{ "Lorg/mortbay/jetty/security/Authenticator;"});
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("FormAuthenticator.java");
        if(cv!=null){
            DexAnnotationVisitor av00 = cv.visitAnnotation("Ldalvik/annotation/MemberClasses;", Visibility.SYSTEM);
            if(av00 != null) {
                {
                    DexAnnotationVisitor av01 = av00.visitArray("value");
                    if(av01 != null) {
                        av01.visit(null, new DexType("Lorg/mortbay/jetty/security/FormAuthenticator$1;"));
                        av01.visit(null, new DexType("Lorg/mortbay/jetty/security/FormAuthenticator$FormCredential;"));
                        av01.visitEnd();
                    }
                }
                av00.visitEnd();
            }
        }
        f000___J_AUTHENTICATED(cv);
        f001___J_PASSWORD(cv);
        f002___J_SECURITY_CHECK(cv);
        f003___J_URI(cv);
        f004___J_USERNAME(cv);
        f005__formErrorPage(cv);
        f006__formErrorPath(cv);
        f007__formLoginPage(cv);
        f008__formLoginPath(cv);
        m000__init_(cv);
        m001_authenticate(cv);
        m002_getAuthMethod(cv);
        m003_getErrorPage(cv);
        m004_getLoginPage(cv);
        m005_isLoginOrErrorPage(cv);
        m006_setErrorPage(cv);
        m007_setLoginPage(cv);
    }
    public static void f000___J_AUTHENTICATED(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/security/FormAuthenticator;","__J_AUTHENTICATED","Ljava/lang/String;"), "org.mortbay.jetty.Auth");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f001___J_PASSWORD(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/security/FormAuthenticator;","__J_PASSWORD","Ljava/lang/String;"), "j_password");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f002___J_SECURITY_CHECK(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/security/FormAuthenticator;","__J_SECURITY_CHECK","Ljava/lang/String;"), "/j_security_check");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f003___J_URI(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/security/FormAuthenticator;","__J_URI","Ljava/lang/String;"), "org.mortbay.jetty.URI");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f004___J_USERNAME(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/security/FormAuthenticator;","__J_USERNAME","Ljava/lang/String;"), "j_username");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f005__formErrorPage(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/security/FormAuthenticator;","_formErrorPage","Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f006__formErrorPath(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/security/FormAuthenticator;","_formErrorPath","Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f007__formLoginPage(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/security/FormAuthenticator;","_formLoginPage","Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f008__formLoginPath(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/security/FormAuthenticator;","_formLoginPath","Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void m000__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/jetty/security/FormAuthenticator;","<init>",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(1);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(43,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(273,L1);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/lang/Object;","<init>",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001_authenticate(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/security/FormAuthenticator;","authenticate",new String[]{ "Lorg/mortbay/jetty/security/UserRealm;","Ljava/lang/String;","Lorg/mortbay/jetty/Request;","Lorg/mortbay/jetty/Response;"},"Ljava/security/Principal;"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(13);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"realm");
                ddv.visitParameterName(1,"pathInContext");
                ddv.visitParameterName(2,"request");
                ddv.visitParameterName(3,"response");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(124,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(127,L1);
                ddv.visitStartLocal(4,L1,"uri","Ljava/lang/String;",null);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(128,L2);
                ddv.visitStartLocal(3,L2,"session","Ljavax/servlet/http/HttpSession;",null);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(129,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(261,L4);
                ddv.visitEndLocal(9,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(127,L5);
                ddv.visitEndLocal(3,L5);
                ddv.visitRestartLocal(9,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(133,L6);
                ddv.visitRestartLocal(3,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(136,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(137,L8);
                ddv.visitStartLocal(1,L8,"form_cred","Lorg/mortbay/jetty/security/FormAuthenticator$FormCredential;",null);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(142,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(143,L10);
                ddv.visitStartLocal(2,L10,"nuri","Ljava/lang/String;",null);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(145,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(146,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(147,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(150,L14);
                ddv.visitRestartLocal(2,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(153,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(154,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(155,L17);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(156,L18);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(157,L19);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(160,L20);
                DexLabel L21=new DexLabel();
                ddv.visitLineNumber(161,L21);
                DexLabel L22=new DexLabel();
                ddv.visitEndLocal(9,L22);
                DexLabel L23=new DexLabel();
                ddv.visitLineNumber(164,L23);
                DexLabel L24=new DexLabel();
                ddv.visitLineNumber(165,L24);
                DexLabel L25=new DexLabel();
                ddv.visitLineNumber(166,L25);
                DexLabel L26=new DexLabel();
                ddv.visitLineNumber(188,L26);
                DexLabel L27=new DexLabel();
                ddv.visitLineNumber(171,L27);
                ddv.visitRestartLocal(9,L27);
                DexLabel L28=new DexLabel();
                ddv.visitLineNumber(172,L28);
                DexLabel L29=new DexLabel();
                ddv.visitLineNumber(174,L29);
                DexLabel L30=new DexLabel();
                ddv.visitLineNumber(175,L30);
                DexLabel L31=new DexLabel();
                ddv.visitLineNumber(179,L31);
                DexLabel L32=new DexLabel();
                ddv.visitLineNumber(180,L32);
                DexLabel L33=new DexLabel();
                ddv.visitLineNumber(181,L33);
                DexLabel L34=new DexLabel();
                ddv.visitLineNumber(192,L34);
                ddv.visitEndLocal(1,L34);
                ddv.visitEndLocal(2,L34);
                DexLabel L35=new DexLabel();
                ddv.visitLineNumber(194,L35);
                ddv.visitRestartLocal(1,L35);
                DexLabel L36=new DexLabel();
                ddv.visitLineNumber(197,L36);
                DexLabel L37=new DexLabel();
                ddv.visitLineNumber(200,L37);
                DexLabel L38=new DexLabel();
                ddv.visitLineNumber(203,L38);
                DexLabel L39=new DexLabel();
                ddv.visitLineNumber(204,L39);
                DexLabel L40=new DexLabel();
                ddv.visitEndLocal(9,L40);
                DexLabel L41=new DexLabel();
                ddv.visitLineNumber(212,L41);
                DexLabel L42=new DexLabel();
                ddv.visitLineNumber(214,L42);
                DexLabel L43=new DexLabel();
                ddv.visitLineNumber(215,L43);
                DexLabel L44=new DexLabel();
                ddv.visitLineNumber(216,L44);
                DexLabel L45=new DexLabel();
                ddv.visitLineNumber(217,L45);
                DexLabel L46=new DexLabel();
                ddv.visitLineNumber(207,L46);
                ddv.visitRestartLocal(9,L46);
                DexLabel L47=new DexLabel();
                ddv.visitLineNumber(209,L47);
                DexLabel L48=new DexLabel();
                ddv.visitLineNumber(220,L48);
                ddv.visitEndLocal(9,L48);
                DexLabel L49=new DexLabel();
                ddv.visitLineNumber(243,L49);
                DexLabel L50=new DexLabel();
                ddv.visitLineNumber(244,L50);
                DexLabel L51=new DexLabel();
                ddv.visitLineNumber(222,L51);
                ddv.visitRestartLocal(9,L51);
                DexLabel L52=new DexLabel();
                ddv.visitLineNumber(225,L52);
                DexLabel L53=new DexLabel();
                ddv.visitEndLocal(9,L53);
                DexLabel L54=new DexLabel();
                ddv.visitLineNumber(227,L54);
                ddv.visitStartLocal(0,L54,"cred","Lorg/mortbay/jetty/security/Credential;",null);
                DexLabel L55=new DexLabel();
                ddv.visitLineNumber(229,L55);
                DexLabel L56=new DexLabel();
                ddv.visitEndLocal(1,L56);
                DexLabel L57=new DexLabel();
                ddv.visitLineNumber(230,L57);
                ddv.visitRestartLocal(1,L57);
                DexLabel L58=new DexLabel();
                ddv.visitLineNumber(231,L58);
                DexLabel L59=new DexLabel();
                ddv.visitLineNumber(232,L59);
                DexLabel L60=new DexLabel();
                ddv.visitLineNumber(233,L60);
                DexLabel L61=new DexLabel();
                ddv.visitLineNumber(234,L61);
                DexLabel L62=new DexLabel();
                ddv.visitLineNumber(236,L62);
                DexLabel L63=new DexLabel();
                ddv.visitLineNumber(237,L63);
                DexLabel L64=new DexLabel();
                ddv.visitLineNumber(238,L64);
                DexLabel L65=new DexLabel();
                ddv.visitLineNumber(247,L65);
                ddv.visitEndLocal(0,L65);
                DexLabel L66=new DexLabel();
                ddv.visitLineNumber(249,L66);
                DexLabel L67=new DexLabel();
                ddv.visitLineNumber(250,L67);
                DexLabel L68=new DexLabel();
                ddv.visitLineNumber(251,L68);
                DexLabel L69=new DexLabel();
                ddv.visitLineNumber(256,L69);
                DexLabel L70=new DexLabel();
                ddv.visitLineNumber(257,L70);
                DexLabel L71=new DexLabel();
                ddv.visitLineNumber(261,L71);
                code.visitLabel(L0);
                code.visitStmt2R(MOVE_OBJECT,4,10);
                code.visitLabel(L1);
                code.visitJumpStmt(IF_EQZ,12,-1,L5);
                code.visitConstStmt(CONST_4,5, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                DexLabel L72=new DexLabel();
                code.visitLabel(L72);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 11,5},new Method("Lorg/mortbay/jetty/Request;","getSession",new String[]{ "Z"},"Ljavax/servlet/http/HttpSession;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitLabel(L2);
                code.visitJumpStmt(IF_NEZ,3,-1,L6);
                code.visitLabel(L3);
                code.visitConstStmt(CONST_4,5, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L4);
                code.visitStmt1R(RETURN_OBJECT,5);
                code.visitLabel(L5);
                code.visitConstStmt(CONST_4,5, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L72);
                code.visitLabel(L6);
                code.visitConstStmt(CONST_STRING,5,"/j_security_check");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,5},new Method("Ljava/lang/String;","endsWith",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,5);
                code.visitJumpStmt(IF_EQZ,5,-1,L34);
                code.visitLabel(L7);
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Lorg/mortbay/jetty/security/FormAuthenticator$FormCredential;");
                code.visitConstStmt(CONST_4,5, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1,5},new Method("Lorg/mortbay/jetty/security/FormAuthenticator$FormCredential;","<init>",new String[]{ "Lorg/mortbay/jetty/security/FormAuthenticator$1;"},"V"));
                code.visitLabel(L8);
                code.visitConstStmt(CONST_STRING,5,"j_username");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 11,5},new Method("Lorg/mortbay/jetty/Request;","getParameter",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitConstStmt(CONST_STRING,6,"j_password");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 11,6},new Method("Lorg/mortbay/jetty/Request;","getParameter",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,9,5,6,11},new Method("Lorg/mortbay/jetty/security/FormAuthenticator$FormCredential;","authenticate",new String[]{ "Lorg/mortbay/jetty/security/UserRealm;","Ljava/lang/String;","Ljava/lang/String;","Lorg/mortbay/jetty/Request;"},"V"));
                code.visitLabel(L9);
                code.visitConstStmt(CONST_STRING,5,"org.mortbay.jetty.URI");
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 3,5},new Method("Ljavax/servlet/http/HttpSession;","getAttribute",new String[]{ "Ljava/lang/String;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitTypeStmt(CHECK_CAST,2,-1,"Ljava/lang/String;");
                code.visitLabel(L10);
                code.visitJumpStmt(IF_EQZ,2,-1,L11);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Ljava/lang/String;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,5);
                code.visitJumpStmt(IF_NEZ,5,-1,L14);
                code.visitLabel(L11);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 11},new Method("Lorg/mortbay/jetty/Request;","getContextPath",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitLabel(L12);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Ljava/lang/String;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,5);
                code.visitJumpStmt(IF_NEZ,5,-1,L14);
                code.visitLabel(L13);
                code.visitConstStmt(CONST_STRING,2,"/");
                code.visitLabel(L14);
                code.visitFieldStmt(IGET_OBJECT,5,1,new Field("Lorg/mortbay/jetty/security/FormAuthenticator$FormCredential;","_userPrincipal","Ljava/security/Principal;"));
                code.visitJumpStmt(IF_EQZ,5,-1,L27);
                code.visitLabel(L15);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Lorg/mortbay/log/Log;","isDebugEnabled",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,5);
                code.visitJumpStmt(IF_EQZ,5,-1,L16);
                code.visitTypeStmt(NEW_INSTANCE,5,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 5},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,6,"Form authentication OK for ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,6},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitFieldStmt(IGET_OBJECT,6,1,new Field("Lorg/mortbay/jetty/security/FormAuthenticator$FormCredential;","_jUserName","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,6},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 5},new Method("Lorg/mortbay/log/Log;","debug",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L16);
                code.visitConstStmt(CONST_STRING,5,"org.mortbay.jetty.URI");
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 3,5},new Method("Ljavax/servlet/http/HttpSession;","removeAttribute",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L17);
                code.visitConstStmt(CONST_STRING,5,"FORM");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 11,5},new Method("Lorg/mortbay/jetty/Request;","setAuthType",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L18);
                code.visitFieldStmt(IGET_OBJECT,5,1,new Field("Lorg/mortbay/jetty/security/FormAuthenticator$FormCredential;","_userPrincipal","Ljava/security/Principal;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 11,5},new Method("Lorg/mortbay/jetty/Request;","setUserPrincipal",new String[]{ "Ljava/security/Principal;"},"V"));
                code.visitLabel(L19);
                code.visitConstStmt(CONST_STRING,5,"org.mortbay.jetty.Auth");
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 3,5,1},new Method("Ljavax/servlet/http/HttpSession;","setAttribute",new String[]{ "Ljava/lang/String;","Ljava/lang/Object;"},"V"));
                code.visitLabel(L20);
                code.visitTypeStmt(INSTANCE_OF,5,9,"Lorg/mortbay/jetty/security/SSORealm;");
                code.visitJumpStmt(IF_EQZ,5,-1,L23);
                code.visitLabel(L21);
                code.visitTypeStmt(CHECK_CAST,9,-1,"Lorg/mortbay/jetty/security/SSORealm;");
                code.visitLabel(L22);
                code.visitFieldStmt(IGET_OBJECT,5,1,new Field("Lorg/mortbay/jetty/security/FormAuthenticator$FormCredential;","_userPrincipal","Ljava/security/Principal;"));
                code.visitTypeStmt(NEW_INSTANCE,6,-1,"Lorg/mortbay/jetty/security/Password;");
                code.visitFieldStmt(IGET_OBJECT,7,1,new Field("Lorg/mortbay/jetty/security/FormAuthenticator$FormCredential;","_jPassword","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 6,7},new Method("Lorg/mortbay/jetty/security/Password;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 9,11,12,5,6},new Method("Lorg/mortbay/jetty/security/SSORealm;","setSingleSignOn",new String[]{ "Lorg/mortbay/jetty/Request;","Lorg/mortbay/jetty/Response;","Ljava/security/Principal;","Lorg/mortbay/jetty/security/Credential;"},"V"));
                code.visitLabel(L23);
                code.visitJumpStmt(IF_EQZ,12,-1,L26);
                code.visitLabel(L24);
                code.visitConstStmt(CONST_4,5, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 12,5},new Method("Lorg/mortbay/jetty/Response;","setContentLength",new String[]{ "I"},"V"));
                code.visitLabel(L25);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 12,2},new Method("Lorg/mortbay/jetty/Response;","encodeRedirectURL",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 12,5},new Method("Lorg/mortbay/jetty/Response;","sendRedirect",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L26);
                code.visitConstStmt(CONST_4,5, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitJumpStmt(GOTO_16,-1,-1,L4);
                code.visitLabel(L27);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Lorg/mortbay/log/Log;","isDebugEnabled",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,5);
                code.visitJumpStmt(IF_EQZ,5,-1,L28);
                code.visitTypeStmt(NEW_INSTANCE,5,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 5},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,6,"Form authentication FAILED for ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,6},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitFieldStmt(IGET_OBJECT,6,1,new Field("Lorg/mortbay/jetty/security/FormAuthenticator$FormCredential;","_jUserName","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 6},new Method("Lorg/mortbay/util/StringUtil;","printable",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,6},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 5},new Method("Lorg/mortbay/log/Log;","debug",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L28);
                code.visitFieldStmt(IGET_OBJECT,5,8,new Field("Lorg/mortbay/jetty/security/FormAuthenticator;","_formErrorPage","Ljava/lang/String;"));
                code.visitJumpStmt(IF_NEZ,5,-1,L31);
                code.visitLabel(L29);
                code.visitJumpStmt(IF_EQZ,12,-1,L26);
                code.visitLabel(L30);
                code.visitConstStmt(CONST_16,5, Integer.valueOf(403)); // int: 0x00000193  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 12,5},new Method("Lorg/mortbay/jetty/Response;","sendError",new String[]{ "I"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L26);
                code.visitLabel(L31);
                code.visitJumpStmt(IF_EQZ,12,-1,L33);
                code.visitLabel(L32);
                code.visitConstStmt(CONST_4,5, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 12,5},new Method("Lorg/mortbay/jetty/Response;","setContentLength",new String[]{ "I"},"V"));
                code.visitLabel(L33);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 11},new Method("Lorg/mortbay/jetty/Request;","getContextPath",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitFieldStmt(IGET_OBJECT,6,8,new Field("Lorg/mortbay/jetty/security/FormAuthenticator;","_formErrorPage","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 5,6},new Method("Lorg/mortbay/util/URIUtil;","addPaths",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 12,5},new Method("Lorg/mortbay/jetty/Response;","encodeRedirectURL",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 12,5},new Method("Lorg/mortbay/jetty/Response;","sendRedirect",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L26);
                code.visitLabel(L34);
                code.visitConstStmt(CONST_STRING,5,"org.mortbay.jetty.Auth");
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 3,5},new Method("Ljavax/servlet/http/HttpSession;","getAttribute",new String[]{ "Ljava/lang/String;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitTypeStmt(CHECK_CAST,1,-1,"Lorg/mortbay/jetty/security/FormAuthenticator$FormCredential;");
                code.visitLabel(L35);
                code.visitJumpStmt(IF_EQZ,1,-1,L51);
                code.visitLabel(L36);
                code.visitFieldStmt(IGET_OBJECT,5,1,new Field("Lorg/mortbay/jetty/security/FormAuthenticator$FormCredential;","_userPrincipal","Ljava/security/Principal;"));
                code.visitJumpStmt(IF_NEZ,5,-1,L46);
                code.visitLabel(L37);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,9,11},new Method("Lorg/mortbay/jetty/security/FormAuthenticator$FormCredential;","authenticate",new String[]{ "Lorg/mortbay/jetty/security/UserRealm;","Lorg/mortbay/jetty/Request;"},"V"));
                code.visitLabel(L38);
                code.visitFieldStmt(IGET_OBJECT,5,1,new Field("Lorg/mortbay/jetty/security/FormAuthenticator$FormCredential;","_userPrincipal","Ljava/security/Principal;"));
                code.visitJumpStmt(IF_EQZ,5,-1,L41);
                code.visitTypeStmt(INSTANCE_OF,5,9,"Lorg/mortbay/jetty/security/SSORealm;");
                code.visitJumpStmt(IF_EQZ,5,-1,L41);
                code.visitLabel(L39);
                code.visitTypeStmt(CHECK_CAST,9,-1,"Lorg/mortbay/jetty/security/SSORealm;");
                code.visitLabel(L40);
                code.visitFieldStmt(IGET_OBJECT,5,1,new Field("Lorg/mortbay/jetty/security/FormAuthenticator$FormCredential;","_userPrincipal","Ljava/security/Principal;"));
                code.visitTypeStmt(NEW_INSTANCE,6,-1,"Lorg/mortbay/jetty/security/Password;");
                code.visitFieldStmt(IGET_OBJECT,7,1,new Field("Lorg/mortbay/jetty/security/FormAuthenticator$FormCredential;","_jPassword","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 6,7},new Method("Lorg/mortbay/jetty/security/Password;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 9,11,12,5,6},new Method("Lorg/mortbay/jetty/security/SSORealm;","setSingleSignOn",new String[]{ "Lorg/mortbay/jetty/Request;","Lorg/mortbay/jetty/Response;","Ljava/security/Principal;","Lorg/mortbay/jetty/security/Credential;"},"V"));
                code.visitLabel(L41);
                code.visitFieldStmt(IGET_OBJECT,5,1,new Field("Lorg/mortbay/jetty/security/FormAuthenticator$FormCredential;","_userPrincipal","Ljava/security/Principal;"));
                code.visitJumpStmt(IF_EQZ,5,-1,L48);
                code.visitLabel(L42);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Lorg/mortbay/log/Log;","isDebugEnabled",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,5);
                code.visitJumpStmt(IF_EQZ,5,-1,L43);
                code.visitTypeStmt(NEW_INSTANCE,5,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 5},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,6,"FORM Authenticated for ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,6},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitFieldStmt(IGET_OBJECT,6,1,new Field("Lorg/mortbay/jetty/security/FormAuthenticator$FormCredential;","_userPrincipal","Ljava/security/Principal;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 6},new Method("Ljava/security/Principal;","getName",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,6},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 5},new Method("Lorg/mortbay/log/Log;","debug",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L43);
                code.visitConstStmt(CONST_STRING,5,"FORM");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 11,5},new Method("Lorg/mortbay/jetty/Request;","setAuthType",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L44);
                code.visitFieldStmt(IGET_OBJECT,5,1,new Field("Lorg/mortbay/jetty/security/FormAuthenticator$FormCredential;","_userPrincipal","Ljava/security/Principal;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 11,5},new Method("Lorg/mortbay/jetty/Request;","setUserPrincipal",new String[]{ "Ljava/security/Principal;"},"V"));
                code.visitLabel(L45);
                code.visitFieldStmt(IGET_OBJECT,5,1,new Field("Lorg/mortbay/jetty/security/FormAuthenticator$FormCredential;","_userPrincipal","Ljava/security/Principal;"));
                code.visitJumpStmt(GOTO_16,-1,-1,L4);
                code.visitLabel(L46);
                code.visitFieldStmt(IGET_OBJECT,5,1,new Field("Lorg/mortbay/jetty/security/FormAuthenticator$FormCredential;","_userPrincipal","Ljava/security/Principal;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 9,5},new Method("Lorg/mortbay/jetty/security/UserRealm;","reauthenticate",new String[]{ "Ljava/security/Principal;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,5);
                code.visitJumpStmt(IF_NEZ,5,-1,L41);
                code.visitLabel(L47);
                code.visitConstStmt(CONST_4,5, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT_OBJECT,5,1,new Field("Lorg/mortbay/jetty/security/FormAuthenticator$FormCredential;","_userPrincipal","Ljava/security/Principal;"));
                code.visitJumpStmt(GOTO,-1,-1,L41);
                code.visitLabel(L48);
                code.visitConstStmt(CONST_STRING,5,"org.mortbay.jetty.Auth");
                code.visitConstStmt(CONST_4,6, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 3,5,6},new Method("Ljavax/servlet/http/HttpSession;","setAttribute",new String[]{ "Ljava/lang/String;","Ljava/lang/Object;"},"V"));
                code.visitLabel(L49);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8,10},new Method("Lorg/mortbay/jetty/security/FormAuthenticator;","isLoginOrErrorPage",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,5);
                code.visitJumpStmt(IF_EQZ,5,-1,L65);
                code.visitLabel(L50);
                code.visitFieldStmt(SGET_OBJECT,5,-1,new Field("Lorg/mortbay/jetty/security/SecurityHandler;","__NOBODY","Ljava/security/Principal;"));
                code.visitJumpStmt(GOTO_16,-1,-1,L4);
                code.visitLabel(L51);
                code.visitTypeStmt(INSTANCE_OF,5,9,"Lorg/mortbay/jetty/security/SSORealm;");
                code.visitJumpStmt(IF_EQZ,5,-1,L49);
                code.visitLabel(L52);
                code.visitTypeStmt(CHECK_CAST,9,-1,"Lorg/mortbay/jetty/security/SSORealm;");
                code.visitLabel(L53);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 9,11,12},new Method("Lorg/mortbay/jetty/security/SSORealm;","getSingleSignOn",new String[]{ "Lorg/mortbay/jetty/Request;","Lorg/mortbay/jetty/Response;"},"Lorg/mortbay/jetty/security/Credential;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L54);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 11},new Method("Lorg/mortbay/jetty/Request;","getUserPrincipal",new String[]{ },"Ljava/security/Principal;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitJumpStmt(IF_EQZ,5,-1,L49);
                code.visitLabel(L55);
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Lorg/mortbay/jetty/security/FormAuthenticator$FormCredential;");
                code.visitLabel(L56);
                code.visitConstStmt(CONST_4,5, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1,5},new Method("Lorg/mortbay/jetty/security/FormAuthenticator$FormCredential;","<init>",new String[]{ "Lorg/mortbay/jetty/security/FormAuthenticator$1;"},"V"));
                code.visitLabel(L57);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 11},new Method("Lorg/mortbay/jetty/Request;","getUserPrincipal",new String[]{ },"Ljava/security/Principal;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitFieldStmt(IPUT_OBJECT,5,1,new Field("Lorg/mortbay/jetty/security/FormAuthenticator$FormCredential;","_userPrincipal","Ljava/security/Principal;"));
                code.visitLabel(L58);
                code.visitFieldStmt(IGET_OBJECT,5,1,new Field("Lorg/mortbay/jetty/security/FormAuthenticator$FormCredential;","_userPrincipal","Ljava/security/Principal;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 5},new Method("Ljava/security/Principal;","getName",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitFieldStmt(IPUT_OBJECT,5,1,new Field("Lorg/mortbay/jetty/security/FormAuthenticator$FormCredential;","_jUserName","Ljava/lang/String;"));
                code.visitLabel(L59);
                code.visitJumpStmt(IF_EQZ,0,-1,L61);
                code.visitLabel(L60);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/lang/Object;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitFieldStmt(IPUT_OBJECT,5,1,new Field("Lorg/mortbay/jetty/security/FormAuthenticator$FormCredential;","_jPassword","Ljava/lang/String;"));
                code.visitLabel(L61);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Lorg/mortbay/log/Log;","isDebugEnabled",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,5);
                code.visitJumpStmt(IF_EQZ,5,-1,L62);
                code.visitTypeStmt(NEW_INSTANCE,5,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 5},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,6,"SSO for ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,6},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitFieldStmt(IGET_OBJECT,6,1,new Field("Lorg/mortbay/jetty/security/FormAuthenticator$FormCredential;","_userPrincipal","Ljava/security/Principal;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,6},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 5},new Method("Lorg/mortbay/log/Log;","debug",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L62);
                code.visitConstStmt(CONST_STRING,5,"FORM");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 11,5},new Method("Lorg/mortbay/jetty/Request;","setAuthType",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L63);
                code.visitConstStmt(CONST_STRING,5,"org.mortbay.jetty.Auth");
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 3,5,1},new Method("Ljavax/servlet/http/HttpSession;","setAttribute",new String[]{ "Ljava/lang/String;","Ljava/lang/Object;"},"V"));
                code.visitLabel(L64);
                code.visitFieldStmt(IGET_OBJECT,5,1,new Field("Lorg/mortbay/jetty/security/FormAuthenticator$FormCredential;","_userPrincipal","Ljava/security/Principal;"));
                code.visitJumpStmt(GOTO_16,-1,-1,L4);
                code.visitLabel(L65);
                code.visitJumpStmt(IF_EQZ,12,-1,L71);
                code.visitLabel(L66);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 11},new Method("Lorg/mortbay/jetty/Request;","getQueryString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitJumpStmt(IF_EQZ,5,-1,L68);
                code.visitLabel(L67);
                code.visitTypeStmt(NEW_INSTANCE,5,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 5},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,4},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitConstStmt(CONST_STRING,6,"?");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,6},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 11},new Method("Lorg/mortbay/jetty/Request;","getQueryString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,6},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitLabel(L68);
                code.visitConstStmt(CONST_STRING,5,"org.mortbay.jetty.URI");
                code.visitTypeStmt(NEW_INSTANCE,6,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 6},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 11},new Method("Lorg/mortbay/jetty/Request;","getScheme",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,7},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitConstStmt(CONST_STRING,7,"://");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,7},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 11},new Method("Lorg/mortbay/jetty/Request;","getServerName",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,7},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitConstStmt(CONST_STRING,7,":");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,7},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 11},new Method("Lorg/mortbay/jetty/Request;","getServerPort",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,7},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "I"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 11},new Method("Lorg/mortbay/jetty/Request;","getContextPath",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 7,4},new Method("Lorg/mortbay/util/URIUtil;","addPaths",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,7},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 3,5,6},new Method("Ljavax/servlet/http/HttpSession;","setAttribute",new String[]{ "Ljava/lang/String;","Ljava/lang/Object;"},"V"));
                code.visitLabel(L69);
                code.visitConstStmt(CONST_4,5, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 12,5},new Method("Lorg/mortbay/jetty/Response;","setContentLength",new String[]{ "I"},"V"));
                code.visitLabel(L70);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 11},new Method("Lorg/mortbay/jetty/Request;","getContextPath",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitFieldStmt(IGET_OBJECT,6,8,new Field("Lorg/mortbay/jetty/security/FormAuthenticator;","_formLoginPage","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 5,6},new Method("Lorg/mortbay/util/URIUtil;","addPaths",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 12,5},new Method("Lorg/mortbay/jetty/Response;","encodeRedirectURL",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 12,5},new Method("Lorg/mortbay/jetty/Response;","sendRedirect",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L71);
                code.visitConstStmt(CONST_4,5, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitJumpStmt(GOTO_16,-1,-1,L4);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m002_getAuthMethod(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/security/FormAuthenticator;","getAuthMethod",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(60,L0);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_STRING,0,"FORM");
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m003_getErrorPage(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/security/FormAuthenticator;","getErrorPage",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(109,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/security/FormAuthenticator;","_formErrorPage","Ljava/lang/String;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m004_getLoginPage(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/security/FormAuthenticator;","getLoginPage",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(80,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/security/FormAuthenticator;","_formLoginPage","Ljava/lang/String;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m005_isLoginOrErrorPage(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/security/FormAuthenticator;","isLoginOrErrorPage",new String[]{ "Ljava/lang/String;"},"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"pathInContext");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(266,L0);
                code.visitLabel(L0);
                DexLabel L1=new DexLabel();
                code.visitJumpStmt(IF_EQZ,2,-1,L1);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/security/FormAuthenticator;","_formErrorPath","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,0},new Method("Ljava/lang/String;","equals",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                DexLabel L2=new DexLabel();
                code.visitJumpStmt(IF_NEZ,0,-1,L2);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/security/FormAuthenticator;","_formLoginPath","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,0},new Method("Ljava/lang/String;","equals",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_EQZ,0,-1,L1);
                code.visitLabel(L2);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                DexLabel L3=new DexLabel();
                code.visitLabel(L3);
                code.visitStmt1R(RETURN,0);
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L3);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m006_setErrorPage(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/security/FormAuthenticator;","setErrorPage",new String[]{ "Ljava/lang/String;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(6);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"path");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(86,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(88,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(89,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(104,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(93,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(95,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(96,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(98,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(99,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(101,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(102,L11);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitConstStmt(CONST_16,3, Integer.valueOf(63)); // int: 0x0000003f  float:0.000000
                code.visitConstStmt(CONST_STRING,2,"/");
                code.visitLabel(L1);
                code.visitJumpStmt(IF_EQZ,5,-1,L2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Ljava/lang/String;","trim",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/lang/String;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_NEZ,0,-1,L5);
                code.visitLabel(L2);
                code.visitFieldStmt(IPUT_OBJECT,1,4,new Field("Lorg/mortbay/jetty/security/FormAuthenticator;","_formErrorPath","Ljava/lang/String;"));
                code.visitLabel(L3);
                code.visitFieldStmt(IPUT_OBJECT,1,4,new Field("Lorg/mortbay/jetty/security/FormAuthenticator;","_formErrorPage","Ljava/lang/String;"));
                code.visitLabel(L4);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L5);
                code.visitConstStmt(CONST_STRING,0,"/");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,2},new Method("Ljava/lang/String;","startsWith",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_NEZ,0,-1,L8);
                code.visitLabel(L6);
                code.visitConstStmt(CONST_STRING,0,"form-error-page must start with /");
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0},new Method("Lorg/mortbay/log/Log;","warn",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L7);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,1,"/");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,2},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,5},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitLabel(L8);
                code.visitFieldStmt(IPUT_OBJECT,5,4,new Field("Lorg/mortbay/jetty/security/FormAuthenticator;","_formErrorPage","Ljava/lang/String;"));
                code.visitLabel(L9);
                code.visitFieldStmt(IPUT_OBJECT,5,4,new Field("Lorg/mortbay/jetty/security/FormAuthenticator;","_formErrorPath","Ljava/lang/String;"));
                code.visitLabel(L10);
                code.visitFieldStmt(IGET_OBJECT,0,4,new Field("Lorg/mortbay/jetty/security/FormAuthenticator;","_formErrorPath","Ljava/lang/String;"));
                code.visitJumpStmt(IF_EQZ,0,-1,L4);
                code.visitFieldStmt(IGET_OBJECT,0,4,new Field("Lorg/mortbay/jetty/security/FormAuthenticator;","_formErrorPath","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,3},new Method("Ljava/lang/String;","indexOf",new String[]{ "I"},"I"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_LEZ,0,-1,L4);
                code.visitLabel(L11);
                code.visitFieldStmt(IGET_OBJECT,0,4,new Field("Lorg/mortbay/jetty/security/FormAuthenticator;","_formErrorPath","Ljava/lang/String;"));
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IGET_OBJECT,2,4,new Field("Lorg/mortbay/jetty/security/FormAuthenticator;","_formErrorPath","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3},new Method("Ljava/lang/String;","indexOf",new String[]{ "I"},"I"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1,2},new Method("Ljava/lang/String;","substring",new String[]{ "I","I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(IPUT_OBJECT,0,4,new Field("Lorg/mortbay/jetty/security/FormAuthenticator;","_formErrorPath","Ljava/lang/String;"));
                code.visitJumpStmt(GOTO,-1,-1,L4);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m007_setLoginPage(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/security/FormAuthenticator;","setLoginPage",new String[]{ "Ljava/lang/String;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(6);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"path");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(66,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(68,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(69,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(71,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(72,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(73,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(74,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(75,L8);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_16,3, Integer.valueOf(63)); // int: 0x0000003f  float:0.000000
                code.visitConstStmt(CONST_STRING,2,"/");
                code.visitLabel(L1);
                code.visitConstStmt(CONST_STRING,0,"/");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,2},new Method("Ljava/lang/String;","startsWith",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_NEZ,0,-1,L4);
                code.visitLabel(L2);
                code.visitConstStmt(CONST_STRING,0,"form-login-page must start with /");
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0},new Method("Lorg/mortbay/log/Log;","warn",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L3);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,1,"/");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,2},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,5},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitLabel(L4);
                code.visitFieldStmt(IPUT_OBJECT,5,4,new Field("Lorg/mortbay/jetty/security/FormAuthenticator;","_formLoginPage","Ljava/lang/String;"));
                code.visitLabel(L5);
                code.visitFieldStmt(IPUT_OBJECT,5,4,new Field("Lorg/mortbay/jetty/security/FormAuthenticator;","_formLoginPath","Ljava/lang/String;"));
                code.visitLabel(L6);
                code.visitFieldStmt(IGET_OBJECT,0,4,new Field("Lorg/mortbay/jetty/security/FormAuthenticator;","_formLoginPath","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,3},new Method("Ljava/lang/String;","indexOf",new String[]{ "I"},"I"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_LEZ,0,-1,L8);
                code.visitLabel(L7);
                code.visitFieldStmt(IGET_OBJECT,0,4,new Field("Lorg/mortbay/jetty/security/FormAuthenticator;","_formLoginPath","Ljava/lang/String;"));
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IGET_OBJECT,2,4,new Field("Lorg/mortbay/jetty/security/FormAuthenticator;","_formLoginPath","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3},new Method("Ljava/lang/String;","indexOf",new String[]{ "I"},"I"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1,2},new Method("Ljava/lang/String;","substring",new String[]{ "I","I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(IPUT_OBJECT,0,4,new Field("Lorg/mortbay/jetty/security/FormAuthenticator;","_formLoginPath","Ljava/lang/String;"));
                code.visitLabel(L8);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
