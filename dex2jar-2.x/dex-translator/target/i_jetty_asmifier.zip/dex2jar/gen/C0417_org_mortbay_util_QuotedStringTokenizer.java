package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0417_org_mortbay_util_QuotedStringTokenizer {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(ACC_PUBLIC,"Lorg/mortbay/util/QuotedStringTokenizer;","Ljava/util/StringTokenizer;",new String[]{ });
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("QuotedStringTokenizer.java");
        f000___delim(cv);
        f001__delim(cv);
        f002__double(cv);
        f003__hasToken(cv);
        f004__i(cv);
        f005__lastStart(cv);
        f006__returnDelimiters(cv);
        f007__returnQuotes(cv);
        f008__single(cv);
        f009__string(cv);
        f010__token(cv);
        m000__init_(cv);
        m001__init_(cv);
        m002__init_(cv);
        m003__init_(cv);
        m004_quote(cv);
        m005_quote(cv);
        m006_quote(cv);
        m007_quoteIfNeeded(cv);
        m008_unquote(cv);
        m009_countTokens(cv);
        m010_getDouble(cv);
        m011_getSingle(cv);
        m012_hasMoreElements(cv);
        m013_hasMoreTokens(cv);
        m014_nextElement(cv);
        m015_nextToken(cv);
        m016_nextToken(cv);
        m017_setDouble(cv);
        m018_setSingle(cv);
    }
    public static void f000___delim(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/util/QuotedStringTokenizer;","__delim","Ljava/lang/String;"), "\t\n\r");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f001__delim(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/util/QuotedStringTokenizer;","_delim","Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f002__double(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/util/QuotedStringTokenizer;","_double","Z"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f003__hasToken(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/util/QuotedStringTokenizer;","_hasToken","Z"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f004__i(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/util/QuotedStringTokenizer;","_i","I"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f005__lastStart(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/util/QuotedStringTokenizer;","_lastStart","I"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f006__returnDelimiters(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/util/QuotedStringTokenizer;","_returnDelimiters","Z"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f007__returnQuotes(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/util/QuotedStringTokenizer;","_returnQuotes","Z"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f008__single(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/util/QuotedStringTokenizer;","_single","Z"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f009__string(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/util/QuotedStringTokenizer;","_string","Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f010__token(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/util/QuotedStringTokenizer;","_token","Ljava/lang/StringBuffer;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void m000__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/util/QuotedStringTokenizer;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"str");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(85,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(86,L2);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2,3,0,1,1},new Method("Lorg/mortbay/util/QuotedStringTokenizer;","<init>",new String[]{ "Ljava/lang/String;","Ljava/lang/String;","Z","Z"},"V"));
                code.visitLabel(L2);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/util/QuotedStringTokenizer;","<init>",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"str");
                ddv.visitParameterName(1,"delim");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(79,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(80,L2);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1,2,3,0,0},new Method("Lorg/mortbay/util/QuotedStringTokenizer;","<init>",new String[]{ "Ljava/lang/String;","Ljava/lang/String;","Z","Z"},"V"));
                code.visitLabel(L2);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m002__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/util/QuotedStringTokenizer;","<init>",new String[]{ "Ljava/lang/String;","Ljava/lang/String;","Z"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"str");
                ddv.visitParameterName(1,"delim");
                ddv.visitParameterName(2,"returnDelimiters");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(72,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(73,L1);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1,2,3,4,0},new Method("Lorg/mortbay/util/QuotedStringTokenizer;","<init>",new String[]{ "Ljava/lang/String;","Ljava/lang/String;","Z","Z"},"V"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m003__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/util/QuotedStringTokenizer;","<init>",new String[]{ "Ljava/lang/String;","Ljava/lang/String;","Z","Z"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(8);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"str");
                ddv.visitParameterName(1,"delim");
                ddv.visitParameterName(2,"returnDelimiters");
                ddv.visitParameterName(3,"returnQuotes");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(53,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(37,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(38,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(39,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(41,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(42,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(43,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(44,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(45,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(54,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(55,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(56,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(57,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(58,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(60,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(62,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(64,L17);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(65,L18);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(64,L19);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L1);
                code.visitConstStmt(CONST_STRING,0,"");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 3,0},new Method("Ljava/util/StringTokenizer;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L2);
                code.visitConstStmt(CONST_STRING,0,"\t\n\r");
                code.visitFieldStmt(IPUT_OBJECT,0,3,new Field("Lorg/mortbay/util/QuotedStringTokenizer;","_delim","Ljava/lang/String;"));
                code.visitLabel(L3);
                code.visitFieldStmt(IPUT_BOOLEAN,1,3,new Field("Lorg/mortbay/util/QuotedStringTokenizer;","_returnQuotes","Z"));
                code.visitLabel(L4);
                code.visitFieldStmt(IPUT_BOOLEAN,1,3,new Field("Lorg/mortbay/util/QuotedStringTokenizer;","_returnDelimiters","Z"));
                code.visitLabel(L5);
                code.visitFieldStmt(IPUT_BOOLEAN,1,3,new Field("Lorg/mortbay/util/QuotedStringTokenizer;","_hasToken","Z"));
                code.visitLabel(L6);
                code.visitFieldStmt(IPUT,1,3,new Field("Lorg/mortbay/util/QuotedStringTokenizer;","_i","I"));
                code.visitLabel(L7);
                code.visitFieldStmt(IPUT,1,3,new Field("Lorg/mortbay/util/QuotedStringTokenizer;","_lastStart","I"));
                code.visitLabel(L8);
                code.visitFieldStmt(IPUT_BOOLEAN,2,3,new Field("Lorg/mortbay/util/QuotedStringTokenizer;","_double","Z"));
                code.visitLabel(L9);
                code.visitFieldStmt(IPUT_BOOLEAN,2,3,new Field("Lorg/mortbay/util/QuotedStringTokenizer;","_single","Z"));
                code.visitLabel(L10);
                code.visitFieldStmt(IPUT_OBJECT,4,3,new Field("Lorg/mortbay/util/QuotedStringTokenizer;","_string","Ljava/lang/String;"));
                code.visitLabel(L11);
                code.visitJumpStmt(IF_EQZ,5,-1,L13);
                code.visitLabel(L12);
                code.visitFieldStmt(IPUT_OBJECT,5,3,new Field("Lorg/mortbay/util/QuotedStringTokenizer;","_delim","Ljava/lang/String;"));
                code.visitLabel(L13);
                code.visitFieldStmt(IPUT_BOOLEAN,6,3,new Field("Lorg/mortbay/util/QuotedStringTokenizer;","_returnDelimiters","Z"));
                code.visitLabel(L14);
                code.visitFieldStmt(IPUT_BOOLEAN,7,3,new Field("Lorg/mortbay/util/QuotedStringTokenizer;","_returnQuotes","Z"));
                code.visitLabel(L15);
                code.visitFieldStmt(IGET_OBJECT,0,3,new Field("Lorg/mortbay/util/QuotedStringTokenizer;","_delim","Ljava/lang/String;"));
                code.visitConstStmt(CONST_16,1, Integer.valueOf(39)); // int: 0x00000027  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/String;","indexOf",new String[]{ "I"},"I"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_GEZ,0,-1,L16);
                code.visitFieldStmt(IGET_OBJECT,0,3,new Field("Lorg/mortbay/util/QuotedStringTokenizer;","_delim","Ljava/lang/String;"));
                code.visitConstStmt(CONST_16,1, Integer.valueOf(34)); // int: 0x00000022  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/String;","indexOf",new String[]{ "I"},"I"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_LTZ,0,-1,L17);
                code.visitLabel(L16);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/lang/Error;");
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,2,"Can\'t use quotes as delimiters: ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitFieldStmt(IGET_OBJECT,2,3,new Field("Lorg/mortbay/util/QuotedStringTokenizer;","_delim","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1},new Method("Ljava/lang/Error;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitStmt1R(THROW,0);
                code.visitLabel(L17);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/lang/StringBuffer;");
                code.visitFieldStmt(IGET_OBJECT,1,3,new Field("Lorg/mortbay/util/QuotedStringTokenizer;","_string","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/lang/String;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitConstStmt(CONST_16,2, Integer.valueOf(1024)); // int: 0x00000400  float:0.000000
                code.visitJumpStmt(IF_LE,1,2,L19);
                code.visitConstStmt(CONST_16,1, Integer.valueOf(512)); // int: 0x00000200  float:0.000000
                DexLabel L20=new DexLabel();
                code.visitLabel(L20);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1},new Method("Ljava/lang/StringBuffer;","<init>",new String[]{ "I"},"V"));
                code.visitFieldStmt(IPUT_OBJECT,0,3,new Field("Lorg/mortbay/util/QuotedStringTokenizer;","_token","Ljava/lang/StringBuffer;"));
                code.visitLabel(L18);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L19);
                code.visitFieldStmt(IGET_OBJECT,1,3,new Field("Lorg/mortbay/util/QuotedStringTokenizer;","_string","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/lang/String;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitStmt2R1N(DIV_INT_LIT8,1,1,2);
                code.visitJumpStmt(GOTO,-1,-1,L20);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m004_quote(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Lorg/mortbay/util/QuotedStringTokenizer;","quote",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"s");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(296,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(297,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(303,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(298,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(299,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(301,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(302,L6);
                ddv.visitStartLocal(0,L6,"b","Ljava/lang/StringBuffer;",null);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(303,L7);
                code.visitLabel(L0);
                code.visitJumpStmt(IF_NEZ,2,-1,L3);
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L2);
                code.visitStmt1R(RETURN_OBJECT,1);
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Ljava/lang/String;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitJumpStmt(IF_NEZ,1,-1,L5);
                code.visitLabel(L4);
                code.visitConstStmt(CONST_STRING,1,"\"\"");
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitLabel(L5);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/lang/StringBuffer;");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Ljava/lang/String;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitStmt2R1N(ADD_INT_LIT8,1,1,8);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1},new Method("Ljava/lang/StringBuffer;","<init>",new String[]{ "I"},"V"));
                code.visitLabel(L6);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0,2},new Method("Lorg/mortbay/util/QuotedStringTokenizer;","quote",new String[]{ "Ljava/lang/StringBuffer;","Ljava/lang/String;"},"V"));
                code.visitLabel(L7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/lang/StringBuffer;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m005_quote(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Lorg/mortbay/util/QuotedStringTokenizer;","quote",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(6);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"s");
                ddv.visitParameterName(1,"delim");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(266,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(267,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(283,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(268,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(269,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(272,L5);
                DexLabel L6=new DexLabel();
                ddv.visitStartLocal(2,L6,"i","I",null);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(274,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(275,L8);
                ddv.visitStartLocal(1,L8,"c","C",null);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(277,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(278,L10);
                ddv.visitStartLocal(0,L10,"b","Ljava/lang/StringBuffer;",null);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(279,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(272,L12);
                ddv.visitEndLocal(0,L12);
                DexLabel L13=new DexLabel();
                ddv.visitEndLocal(1,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(283,L14);
                code.visitLabel(L0);
                code.visitJumpStmt(IF_NEZ,4,-1,L3);
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L2);
                code.visitStmt1R(RETURN_OBJECT,3);
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Ljava/lang/String;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitJumpStmt(IF_NEZ,3,-1,L5);
                code.visitLabel(L4);
                code.visitConstStmt(CONST_STRING,3,"\"\"");
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitLabel(L5);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Ljava/lang/String;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitJumpStmt(IF_GE,2,3,L13);
                code.visitLabel(L7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,2},new Method("Ljava/lang/String;","charAt",new String[]{ "I"},"C"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitLabel(L8);
                code.visitConstStmt(CONST_16,3, Integer.valueOf(92)); // int: 0x0000005c  float:0.000000
                code.visitJumpStmt(IF_EQ,1,3,L9);
                code.visitConstStmt(CONST_16,3, Integer.valueOf(34)); // int: 0x00000022  float:0.000000
                code.visitJumpStmt(IF_EQ,1,3,L9);
                code.visitConstStmt(CONST_16,3, Integer.valueOf(39)); // int: 0x00000027  float:0.000000
                code.visitJumpStmt(IF_EQ,1,3,L9);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1},new Method("Ljava/lang/Character;","isWhitespace",new String[]{ "C"},"Z"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitJumpStmt(IF_NEZ,3,-1,L9);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,1},new Method("Ljava/lang/String;","indexOf",new String[]{ "I"},"I"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitJumpStmt(IF_LTZ,3,-1,L12);
                code.visitLabel(L9);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/lang/StringBuffer;");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Ljava/lang/String;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitStmt2R1N(ADD_INT_LIT8,3,3,8);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,3},new Method("Ljava/lang/StringBuffer;","<init>",new String[]{ "I"},"V"));
                code.visitLabel(L10);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0,4},new Method("Lorg/mortbay/util/QuotedStringTokenizer;","quote",new String[]{ "Ljava/lang/StringBuffer;","Ljava/lang/String;"},"V"));
                code.visitLabel(L11);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/lang/StringBuffer;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitLabel(L12);
                code.visitStmt2R1N(ADD_INT_LIT8,2,2,1);
                code.visitJumpStmt(GOTO,-1,-1,L6);
                code.visitLabel(L13);
                code.visitStmt2R(MOVE_OBJECT,3,4);
                code.visitLabel(L14);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m006_quote(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Lorg/mortbay/util/QuotedStringTokenizer;","quote",new String[]{ "Ljava/lang/StringBuffer;","Ljava/lang/String;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(6);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexLabel L3=new DexLabel();
                DexLabel L4=new DexLabel();
                code.visitTryCatch(L3,L4,new DexLabel[]{L2},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"buf");
                ddv.visitParameterName(1,"s");
                DexLabel L5=new DexLabel();
                ddv.visitPrologue(L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(316,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(318,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(319,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(320,L9);
                ddv.visitStartLocal(1,L9,"chars","[C",null);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(322,L10);
                ddv.visitStartLocal(2,L10,"i","I",null);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(324,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(325,L12);
                ddv.visitStartLocal(0,L12,"c","C",null);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(322,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(328,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(329,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(330,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(367,L17);
                ddv.visitEndLocal(0,L17);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(368,L18);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(406,L19);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(407,L20);
                DexLabel L21=new DexLabel();
                ddv.visitLineNumber(408,L21);
                DexLabel L22=new DexLabel();
                ddv.visitLineNumber(333,L22);
                ddv.visitRestartLocal(0,L22);
                DexLabel L23=new DexLabel();
                ddv.visitLineNumber(334,L23);
                ddv.visitRestartLocal(1,L23);
                DexLabel L24=new DexLabel();
                ddv.visitLineNumber(335,L24);
                ddv.visitLineNumber(407,L2);
                ddv.visitEndLocal(2,L2);
                ddv.visitEndLocal(0,L2);
                ddv.visitEndLocal(1,L2);
                ddv.visitLineNumber(338,L3);
                ddv.visitRestartLocal(0,L3);
                ddv.visitRestartLocal(1,L3);
                ddv.visitRestartLocal(2,L3);
                DexLabel L25=new DexLabel();
                ddv.visitLineNumber(339,L25);
                ddv.visitRestartLocal(1,L25);
                DexLabel L26=new DexLabel();
                ddv.visitLineNumber(340,L26);
                DexLabel L27=new DexLabel();
                ddv.visitLineNumber(343,L27);
                DexLabel L28=new DexLabel();
                ddv.visitLineNumber(344,L28);
                ddv.visitRestartLocal(1,L28);
                DexLabel L29=new DexLabel();
                ddv.visitLineNumber(345,L29);
                DexLabel L30=new DexLabel();
                ddv.visitLineNumber(348,L30);
                DexLabel L31=new DexLabel();
                ddv.visitLineNumber(349,L31);
                ddv.visitRestartLocal(1,L31);
                DexLabel L32=new DexLabel();
                ddv.visitLineNumber(350,L32);
                DexLabel L33=new DexLabel();
                ddv.visitLineNumber(353,L33);
                DexLabel L34=new DexLabel();
                ddv.visitLineNumber(354,L34);
                ddv.visitRestartLocal(1,L34);
                DexLabel L35=new DexLabel();
                ddv.visitLineNumber(355,L35);
                DexLabel L36=new DexLabel();
                ddv.visitLineNumber(358,L36);
                DexLabel L37=new DexLabel();
                ddv.visitLineNumber(359,L37);
                ddv.visitRestartLocal(1,L37);
                DexLabel L38=new DexLabel();
                ddv.visitLineNumber(360,L38);
                DexLabel L39=new DexLabel();
                ddv.visitLineNumber(371,L39);
                ddv.visitEndLocal(0,L39);
                DexLabel L40=new DexLabel();
                ddv.visitLineNumber(372,L40);
                DexLabel L41=new DexLabel();
                ddv.visitLineNumber(374,L41);
                DexLabel L42=new DexLabel();
                ddv.visitLineNumber(375,L42);
                ddv.visitRestartLocal(0,L42);
                DexLabel L43=new DexLabel();
                ddv.visitLineNumber(400,L43);
                DexLabel L44=new DexLabel();
                ddv.visitLineNumber(372,L44);
                DexLabel L45=new DexLabel();
                ddv.visitLineNumber(378,L45);
                DexLabel L46=new DexLabel();
                ddv.visitLineNumber(381,L46);
                DexLabel L47=new DexLabel();
                ddv.visitLineNumber(384,L47);
                DexLabel L48=new DexLabel();
                ddv.visitLineNumber(387,L48);
                DexLabel L49=new DexLabel();
                ddv.visitLineNumber(390,L49);
                DexLabel L50=new DexLabel();
                ddv.visitLineNumber(393,L50);
                DexLabel L51=new DexLabel();
                ddv.visitLineNumber(396,L51);
                DexLabel L52=new DexLabel();
                ddv.visitLineNumber(325,L52);
                DexLabel L53=new DexLabel();
                ddv.visitLineNumber(375,L53);
                code.visitLabel(L5);
                code.visitConstStmt(CONST_STRING,3,"\\b");
                code.visitConstStmt(CONST_STRING,3,"\\\\");
                code.visitConstStmt(CONST_STRING,3,"\\\"");
                code.visitLabel(L6);
                code.visitStmt1R(MONITOR_ENTER,4);
                code.visitLabel(L7);
                code.visitConstStmt(CONST_16,3, Integer.valueOf(34)); // int: 0x00000022  float:0.000000
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,3},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "C"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L8);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L9);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L10);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Ljava/lang/String;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitJumpStmt(IF_GE,2,3,L17);
                code.visitLabel(L11);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,2},new Method("Ljava/lang/String;","charAt",new String[]{ "I"},"C"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitLabel(L12);
                code.visitSparseSwitchStmt(SPARSE_SWITCH,0,new int[]{ 8,9,10,12,13,34,92},new DexLabel[]{L36,L30,L3,L33,L27,L14,L22});
                code.visitLabel(L13);
                code.visitStmt2R1N(ADD_INT_LIT8,2,2,1);
                code.visitJumpStmt(GOTO,-1,-1,L10);
                code.visitLabel(L14);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Ljava/lang/String;","toCharArray",new String[]{ },"[C"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L15);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,1,3,2},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "[C","I","I"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L16);
                code.visitConstStmt(CONST_STRING,3,"\\\"");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,3},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L17);
                code.visitJumpStmt(IF_NEZ,1,-1,L39);
                code.visitLabel(L18);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,5},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L19);
                code.visitConstStmt(CONST_16,3, Integer.valueOf(34)); // int: 0x00000022  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,3},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "C"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L20);
                code.visitStmt1R(MONITOR_EXIT,4);
                code.visitLabel(L21);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L22);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Ljava/lang/String;","toCharArray",new String[]{ },"[C"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L23);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,1,3,2},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "[C","I","I"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L24);
                code.visitConstStmt(CONST_STRING,3,"\\\\");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,3},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuffer;"));
                code.visitJumpStmt(GOTO,-1,-1,L17);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,3);
                code.visitStmt1R(MONITOR_EXIT,4);
                code.visitLabel(L1);
                code.visitStmt1R(THROW,3);
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Ljava/lang/String;","toCharArray",new String[]{ },"[C"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L25);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,1,3,2},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "[C","I","I"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L26);
                code.visitConstStmt(CONST_STRING,3,"\\n");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,3},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuffer;"));
                code.visitJumpStmt(GOTO,-1,-1,L17);
                code.visitLabel(L27);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Ljava/lang/String;","toCharArray",new String[]{ },"[C"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L28);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,1,3,2},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "[C","I","I"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L29);
                code.visitConstStmt(CONST_STRING,3,"\\r");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,3},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuffer;"));
                code.visitJumpStmt(GOTO,-1,-1,L17);
                code.visitLabel(L30);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Ljava/lang/String;","toCharArray",new String[]{ },"[C"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L31);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,1,3,2},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "[C","I","I"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L32);
                code.visitConstStmt(CONST_STRING,3,"\\t");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,3},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuffer;"));
                code.visitJumpStmt(GOTO,-1,-1,L17);
                code.visitLabel(L33);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Ljava/lang/String;","toCharArray",new String[]{ },"[C"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L34);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,1,3,2},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "[C","I","I"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L35);
                code.visitConstStmt(CONST_STRING,3,"\\f");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,3},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuffer;"));
                code.visitJumpStmt(GOTO,-1,-1,L17);
                code.visitLabel(L36);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Ljava/lang/String;","toCharArray",new String[]{ },"[C"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L37);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,1,3,2},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "[C","I","I"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L38);
                code.visitConstStmt(CONST_STRING,3,"\\b");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,3},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuffer;"));
                code.visitJumpStmt(GOTO,-1,-1,L17);
                code.visitLabel(L39);
                code.visitStmt2R1N(ADD_INT_LIT8,2,2,1);
                code.visitLabel(L40);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Ljava/lang/String;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitJumpStmt(IF_GE,2,3,L19);
                code.visitLabel(L41);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,2},new Method("Ljava/lang/String;","charAt",new String[]{ "I"},"C"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitLabel(L42);
                code.visitSparseSwitchStmt(SPARSE_SWITCH,0,new int[]{ 8,9,10,12,13,34,92},new DexLabel[]{L51,L49,L47,L50,L48,L45,L46});
                code.visitLabel(L43);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,0},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "C"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L44);
                code.visitStmt2R1N(ADD_INT_LIT8,2,2,1);
                code.visitJumpStmt(GOTO,-1,-1,L40);
                code.visitLabel(L45);
                code.visitConstStmt(CONST_STRING,3,"\\\"");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,3},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuffer;"));
                code.visitJumpStmt(GOTO,-1,-1,L44);
                code.visitLabel(L46);
                code.visitConstStmt(CONST_STRING,3,"\\\\");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,3},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuffer;"));
                code.visitJumpStmt(GOTO,-1,-1,L44);
                code.visitLabel(L47);
                code.visitConstStmt(CONST_STRING,3,"\\n");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,3},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuffer;"));
                code.visitJumpStmt(GOTO,-1,-1,L44);
                code.visitLabel(L48);
                code.visitConstStmt(CONST_STRING,3,"\\r");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,3},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuffer;"));
                code.visitJumpStmt(GOTO,-1,-1,L44);
                code.visitLabel(L49);
                code.visitConstStmt(CONST_STRING,3,"\\t");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,3},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuffer;"));
                code.visitJumpStmt(GOTO,-1,-1,L44);
                code.visitLabel(L50);
                code.visitConstStmt(CONST_STRING,3,"\\f");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,3},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuffer;"));
                code.visitJumpStmt(GOTO,-1,-1,L44);
                code.visitLabel(L51);
                code.visitConstStmt(CONST_STRING,3,"\\b");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,3},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L4);
                code.visitJumpStmt(GOTO,-1,-1,L44);
                code.visitLabel(L52);
                code.visitLabel(L53);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m007_quoteIfNeeded(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Lorg/mortbay/util/QuotedStringTokenizer;","quoteIfNeeded",new String[]{ "Ljava/lang/StringBuffer;","Ljava/lang/String;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(7);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexLabel L3=new DexLabel();
                DexLabel L4=new DexLabel();
                code.visitTryCatch(L3,L4,new DexLabel[]{L2},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"buf");
                ddv.visitParameterName(1,"s");
                DexLabel L5=new DexLabel();
                ddv.visitPrologue(L5);
                ddv.visitLineNumber(422,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(424,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(426,L7);
                ddv.visitStartLocal(1,L7,"e","I",null);
                ddv.visitStartLocal(2,L0,"i","I",null);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(428,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(429,L9);
                ddv.visitStartLocal(0,L9,"c","C",null);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(426,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(441,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(442,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(444,L13);
                DexLabel L14=new DexLabel();
                ddv.visitStartLocal(3,L14,"j","I",null);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(445,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(444,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(453,L17);
                ddv.visitEndLocal(0,L17);
                ddv.visitEndLocal(3,L17);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(455,L18);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(456,L19);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(493,L20);
                DexLabel L21=new DexLabel();
                ddv.visitLineNumber(459,L21);
                DexLabel L22=new DexLabel();
                ddv.visitLineNumber(461,L22);
                DexLabel L23=new DexLabel();
                ddv.visitLineNumber(462,L23);
                ddv.visitRestartLocal(0,L23);
                DexLabel L24=new DexLabel();
                ddv.visitLineNumber(487,L24);
                DexLabel L25=new DexLabel();
                ddv.visitLineNumber(459,L25);
                DexLabel L26=new DexLabel();
                ddv.visitLineNumber(465,L26);
                ddv.visitLineNumber(492,L2);
                ddv.visitEndLocal(0,L2);
                ddv.visitLineNumber(468,L3);
                ddv.visitRestartLocal(0,L3);
                DexLabel L27=new DexLabel();
                ddv.visitLineNumber(471,L27);
                DexLabel L28=new DexLabel();
                ddv.visitLineNumber(474,L28);
                DexLabel L29=new DexLabel();
                ddv.visitLineNumber(477,L29);
                DexLabel L30=new DexLabel();
                ddv.visitLineNumber(480,L30);
                DexLabel L31=new DexLabel();
                ddv.visitLineNumber(483,L31);
                DexLabel L32=new DexLabel();
                ddv.visitLineNumber(491,L32);
                ddv.visitEndLocal(0,L32);
                DexLabel L33=new DexLabel();
                ddv.visitLineNumber(492,L33);
                DexLabel L34=new DexLabel();
                ddv.visitLineNumber(429,L34);
                DexLabel L35=new DexLabel();
                ddv.visitLineNumber(462,L35);
                code.visitLabel(L5);
                code.visitStmt1R(MONITOR_ENTER,5);
                code.visitLabel(L6);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(-1)); // int: 0xffffffff  float:NaN
                code.visitLabel(L7);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Ljava/lang/String;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,4);
                code.visitJumpStmt(IF_GE,2,4,L17);
                code.visitLabel(L8);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,2},new Method("Ljava/lang/String;","charAt",new String[]{ "I"},"C"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitLabel(L9);
                code.visitSparseSwitchStmt(SPARSE_SWITCH,0,new int[]{ 8,9,10,12,13,32,34,37,43,92},new DexLabel[]{L11,L11,L11,L11,L11,L11,L11,L11,L11,L11});
                code.visitLabel(L10);
                code.visitStmt2R1N(ADD_INT_LIT8,2,2,1);
                code.visitJumpStmt(GOTO,-1,-1,L0);
                code.visitLabel(L11);
                code.visitStmt2R(MOVE,1,2);
                code.visitLabel(L12);
                code.visitConstStmt(CONST_16,4, Integer.valueOf(34)); // int: 0x00000022  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,4},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "C"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L13);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L14);
                code.visitJumpStmt(IF_GE,3,1,L17);
                code.visitLabel(L15);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,3},new Method("Ljava/lang/String;","charAt",new String[]{ "I"},"C"));
                code.visitStmt1R(MOVE_RESULT,4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,4},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "C"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L16);
                code.visitStmt2R1N(ADD_INT_LIT8,3,3,1);
                code.visitJumpStmt(GOTO,-1,-1,L14);
                code.visitLabel(L17);
                code.visitJumpStmt(IF_GEZ,1,-1,L21);
                code.visitLabel(L18);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,6},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L19);
                code.visitStmt1R(MONITOR_EXIT,5);
                code.visitLabel(L20);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L21);
                code.visitStmt2R(MOVE,2,1);
                DexLabel L36=new DexLabel();
                code.visitLabel(L36);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Ljava/lang/String;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,4);
                code.visitJumpStmt(IF_GE,2,4,L32);
                code.visitLabel(L22);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,2},new Method("Ljava/lang/String;","charAt",new String[]{ "I"},"C"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitLabel(L23);
                code.visitSparseSwitchStmt(SPARSE_SWITCH,0,new int[]{ 8,9,10,12,13,34,92},new DexLabel[]{L31,L29,L27,L30,L28,L26,L3});
                code.visitLabel(L24);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,0},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "C"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L25);
                code.visitStmt2R1N(ADD_INT_LIT8,2,2,1);
                code.visitJumpStmt(GOTO,-1,-1,L36);
                code.visitLabel(L26);
                code.visitConstStmt(CONST_STRING,4,"\\\"");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,4},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuffer;"));
                code.visitJumpStmt(GOTO,-1,-1,L25);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,4);
                code.visitStmt1R(MONITOR_EXIT,5);
                code.visitLabel(L1);
                code.visitStmt1R(THROW,4);
                code.visitLabel(L3);
                code.visitConstStmt(CONST_STRING,4,"\\\\");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,4},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuffer;"));
                code.visitJumpStmt(GOTO,-1,-1,L25);
                code.visitLabel(L27);
                code.visitConstStmt(CONST_STRING,4,"\\n");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,4},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuffer;"));
                code.visitJumpStmt(GOTO,-1,-1,L25);
                code.visitLabel(L28);
                code.visitConstStmt(CONST_STRING,4,"\\r");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,4},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuffer;"));
                code.visitJumpStmt(GOTO,-1,-1,L25);
                code.visitLabel(L29);
                code.visitConstStmt(CONST_STRING,4,"\\t");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,4},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuffer;"));
                code.visitJumpStmt(GOTO,-1,-1,L25);
                code.visitLabel(L30);
                code.visitConstStmt(CONST_STRING,4,"\\f");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,4},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuffer;"));
                code.visitJumpStmt(GOTO,-1,-1,L25);
                code.visitLabel(L31);
                code.visitConstStmt(CONST_STRING,4,"\\b");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,4},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuffer;"));
                code.visitJumpStmt(GOTO,-1,-1,L25);
                code.visitLabel(L32);
                code.visitConstStmt(CONST_16,4, Integer.valueOf(34)); // int: 0x00000022  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,4},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "C"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L33);
                code.visitStmt1R(MONITOR_EXIT,5);
                code.visitLabel(L4);
                code.visitJumpStmt(GOTO,-1,-1,L20);
                code.visitLabel(L34);
                code.visitLabel(L35);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m008_unquote(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Lorg/mortbay/util/QuotedStringTokenizer;","unquote",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(11);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexLabel L3=new DexLabel();
                DexLabel L4=new DexLabel();
                DexLabel L5=new DexLabel();
                code.visitTryCatch(L3,L4,new DexLabel[]{L5},new String[]{ null});
                DexLabel L6=new DexLabel();
                DexLabel L7=new DexLabel();
                code.visitTryCatch(L6,L7,new DexLabel[]{L2},new String[]{ null});
                DexLabel L8=new DexLabel();
                DexLabel L9=new DexLabel();
                code.visitTryCatch(L8,L9,new DexLabel[]{L5},new String[]{ null});
                DexLabel L10=new DexLabel();
                DexLabel L11=new DexLabel();
                code.visitTryCatch(L10,L11,new DexLabel[]{L2},new String[]{ null});
                DexLabel L12=new DexLabel();
                DexLabel L13=new DexLabel();
                code.visitTryCatch(L12,L13,new DexLabel[]{L5},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"s");
                DexLabel L14=new DexLabel();
                ddv.visitPrologue(L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(502,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(503,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(562,L17);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(504,L18);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(505,L19);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(507,L20);
                DexLabel L21=new DexLabel();
                ddv.visitLineNumber(508,L21);
                ddv.visitStartLocal(3,L21,"first","C",null);
                DexLabel L22=new DexLabel();
                ddv.visitLineNumber(509,L22);
                ddv.visitStartLocal(6,L22,"last","C",null);
                DexLabel L23=new DexLabel();
                ddv.visitLineNumber(510,L23);
                DexLabel L24=new DexLabel();
                ddv.visitLineNumber(512,L24);
                DexLabel L25=new DexLabel();
                ddv.visitLineNumber(513,L25);
                ddv.visitStartLocal(0,L25,"b","Ljava/lang/StringBuffer;",null);
                DexLabel L26=new DexLabel();
                ddv.visitLineNumber(515,L26);
                DexLabel L27=new DexLabel();
                ddv.visitLineNumber(516,L27);
                ddv.visitStartLocal(2,L27,"escape","Z",null);
                DexLabel L28=new DexLabel();
                ddv.visitStartLocal(4,L28,"i","I",null);
                ddv.visitEndLocal(4,L0);
                ddv.visitStartLocal(5,L0,"i","I",null);
                DexLabel L29=new DexLabel();
                ddv.visitLineNumber(518,L29);
                DexLabel L30=new DexLabel();
                ddv.visitLineNumber(520,L30);
                ddv.visitStartLocal(1,L30,"c","C",null);
                DexLabel L31=new DexLabel();
                ddv.visitLineNumber(522,L31);
                DexLabel L32=new DexLabel();
                ddv.visitLineNumber(523,L32);
                DexLabel L33=new DexLabel();
                ddv.visitLineNumber(550,L33);
                DexLabel L34=new DexLabel();
                ddv.visitLineNumber(516,L34);
                ddv.visitEndLocal(5,L34);
                ddv.visitRestartLocal(4,L34);
                DexLabel L35=new DexLabel();
                ddv.visitRestartLocal(5,L35);
                DexLabel L36=new DexLabel();
                ddv.visitLineNumber(526,L36);
                ddv.visitEndLocal(4,L36);
                DexLabel L37=new DexLabel();
                ddv.visitLineNumber(527,L37);
                ddv.visitRestartLocal(4,L37);
                DexLabel L38=new DexLabel();
                ddv.visitLineNumber(529,L38);
                ddv.visitEndLocal(4,L38);
                DexLabel L39=new DexLabel();
                ddv.visitLineNumber(530,L39);
                ddv.visitRestartLocal(4,L39);
                DexLabel L40=new DexLabel();
                ddv.visitLineNumber(532,L40);
                ddv.visitEndLocal(4,L40);
                DexLabel L41=new DexLabel();
                ddv.visitLineNumber(533,L41);
                ddv.visitRestartLocal(4,L41);
                DexLabel L42=new DexLabel();
                ddv.visitLineNumber(535,L42);
                ddv.visitEndLocal(4,L42);
                DexLabel L43=new DexLabel();
                ddv.visitLineNumber(536,L43);
                ddv.visitRestartLocal(4,L43);
                DexLabel L44=new DexLabel();
                ddv.visitLineNumber(538,L44);
                ddv.visitEndLocal(4,L44);
                DexLabel L45=new DexLabel();
                ddv.visitLineNumber(539,L45);
                ddv.visitRestartLocal(4,L45);
                DexLabel L46=new DexLabel();
                ddv.visitLineNumber(541,L46);
                ddv.visitEndLocal(4,L46);
                ddv.visitRestartLocal(4,L3);
                DexLabel L47=new DexLabel();
                ddv.visitEndLocal(5,L47);
                ddv.visitRestartLocal(5,L6);
                DexLabel L48=new DexLabel();
                ddv.visitEndLocal(4,L48);
                ddv.visitRestartLocal(4,L8);
                DexLabel L49=new DexLabel();
                ddv.visitEndLocal(5,L49);
                ddv.visitRestartLocal(5,L10);
                DexLabel L50=new DexLabel();
                ddv.visitEndLocal(4,L50);
                DexLabel L51=new DexLabel();
                ddv.visitLineNumber(548,L51);
                ddv.visitRestartLocal(4,L51);
                DexLabel L52=new DexLabel();
                ddv.visitLineNumber(553,L52);
                ddv.visitEndLocal(4,L52);
                DexLabel L53=new DexLabel();
                ddv.visitLineNumber(555,L53);
                DexLabel L54=new DexLabel();
                ddv.visitLineNumber(556,L54);
                ddv.visitRestartLocal(4,L54);
                DexLabel L55=new DexLabel();
                ddv.visitLineNumber(559,L55);
                ddv.visitEndLocal(4,L55);
                DexLabel L56=new DexLabel();
                ddv.visitRestartLocal(4,L56);
                DexLabel L57=new DexLabel();
                ddv.visitLineNumber(562,L57);
                ddv.visitEndLocal(1,L57);
                ddv.visitEndLocal(4,L57);
                ddv.visitLineNumber(563,L2);
                ddv.visitEndLocal(5,L12);
                ddv.visitRestartLocal(4,L12);
                DexLabel L58=new DexLabel();
                ddv.visitLineNumber(523,L58);
                code.visitLabel(L14);
                code.visitConstStmt(CONST_4,8, Integer.valueOf(2)); // int: 0x00000002  float:0.000000
                code.visitConstStmt(CONST_4,9, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitLabel(L15);
                code.visitJumpStmt(IF_NEZ,10,-1,L18);
                code.visitLabel(L16);
                code.visitConstStmt(CONST_4,7, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L17);
                code.visitStmt1R(RETURN_OBJECT,7);
                code.visitLabel(L18);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10},new Method("Ljava/lang/String;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,7);
                code.visitJumpStmt(IF_GE,7,8,L20);
                code.visitStmt2R(MOVE_OBJECT,7,10);
                code.visitLabel(L19);
                code.visitJumpStmt(GOTO,-1,-1,L17);
                code.visitLabel(L20);
                code.visitConstStmt(CONST_4,7, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10,7},new Method("Ljava/lang/String;","charAt",new String[]{ "I"},"C"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitLabel(L21);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10},new Method("Ljava/lang/String;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,7);
                code.visitStmt2R(SUB_INT_2ADDR,7,9);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10,7},new Method("Ljava/lang/String;","charAt",new String[]{ "I"},"C"));
                code.visitStmt1R(MOVE_RESULT,6);
                code.visitLabel(L22);
                DexLabel L59=new DexLabel();
                code.visitJumpStmt(IF_NE,3,6,L59);
                code.visitConstStmt(CONST_16,7, Integer.valueOf(34)); // int: 0x00000022  float:0.000000
                code.visitJumpStmt(IF_EQ,3,7,L24);
                code.visitConstStmt(CONST_16,7, Integer.valueOf(39)); // int: 0x00000027  float:0.000000
                code.visitJumpStmt(IF_EQ,3,7,L24);
                code.visitLabel(L59);
                code.visitStmt2R(MOVE_OBJECT,7,10);
                code.visitLabel(L23);
                code.visitJumpStmt(GOTO,-1,-1,L17);
                code.visitLabel(L24);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/lang/StringBuffer;");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10},new Method("Ljava/lang/String;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,7);
                code.visitStmt2R(SUB_INT_2ADDR,7,8);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,7},new Method("Ljava/lang/StringBuffer;","<init>",new String[]{ "I"},"V"));
                code.visitLabel(L25);
                code.visitStmt1R(MONITOR_ENTER,0);
                code.visitLabel(L26);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L27);
                code.visitConstStmt(CONST_4,4, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitLabel(L28);
                code.visitStmt2R(MOVE,5,4);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10},new Method("Ljava/lang/String;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,7);
                code.visitStmt2R(SUB_INT_2ADDR,7,9);
                code.visitJumpStmt(IF_GE,5,7,L57);
                code.visitLabel(L29);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10,5},new Method("Ljava/lang/String;","charAt",new String[]{ "I"},"C"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitLabel(L30);
                code.visitJumpStmt(IF_EQZ,2,-1,L52);
                code.visitLabel(L31);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L32);
                code.visitSparseSwitchStmt(SPARSE_SWITCH,1,new int[]{ 98,102,110,114,116,117},new DexLabel[]{L44,L42,L36,L38,L40,L46});
                code.visitLabel(L33);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "C"},"Ljava/lang/StringBuffer;"));
                code.visitStmt2R(MOVE,4,5);
                code.visitLabel(L34);
                code.visitStmt2R1N(ADD_INT_LIT8,4,4,1);
                code.visitStmt2R(MOVE,5,4);
                code.visitLabel(L35);
                code.visitJumpStmt(GOTO,-1,-1,L0);
                code.visitLabel(L36);
                code.visitConstStmt(CONST_16,7, Integer.valueOf(10)); // int: 0x0000000a  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,7},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "C"},"Ljava/lang/StringBuffer;"));
                code.visitStmt2R(MOVE,4,5);
                code.visitLabel(L37);
                code.visitJumpStmt(GOTO,-1,-1,L34);
                code.visitLabel(L38);
                code.visitConstStmt(CONST_16,7, Integer.valueOf(13)); // int: 0x0000000d  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,7},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "C"},"Ljava/lang/StringBuffer;"));
                code.visitStmt2R(MOVE,4,5);
                code.visitLabel(L39);
                code.visitJumpStmt(GOTO,-1,-1,L34);
                code.visitLabel(L40);
                code.visitConstStmt(CONST_16,7, Integer.valueOf(9)); // int: 0x00000009  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,7},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "C"},"Ljava/lang/StringBuffer;"));
                code.visitStmt2R(MOVE,4,5);
                code.visitLabel(L41);
                code.visitJumpStmt(GOTO,-1,-1,L34);
                code.visitLabel(L42);
                code.visitConstStmt(CONST_16,7, Integer.valueOf(12)); // int: 0x0000000c  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,7},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "C"},"Ljava/lang/StringBuffer;"));
                code.visitStmt2R(MOVE,4,5);
                code.visitLabel(L43);
                code.visitJumpStmt(GOTO,-1,-1,L34);
                code.visitLabel(L44);
                code.visitConstStmt(CONST_16,7, Integer.valueOf(8)); // int: 0x00000008  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,7},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "C"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L1);
                code.visitStmt2R(MOVE,4,5);
                code.visitLabel(L45);
                code.visitJumpStmt(GOTO,-1,-1,L34);
                code.visitLabel(L46);
                code.visitStmt2R1N(ADD_INT_LIT8,4,5,1);
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10,5},new Method("Ljava/lang/String;","charAt",new String[]{ "I"},"C"));
                code.visitLabel(L47);
                code.visitStmt1R(MOVE_RESULT,7);
                code.visitStmt2R(INT_TO_BYTE,7,7);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 7},new Method("Lorg/mortbay/util/TypeUtil;","convertHexDigit",new String[]{ "B"},"B"));
                code.visitLabel(L4);
                code.visitStmt1R(MOVE_RESULT,7);
                code.visitStmt2R1N(SHL_INT_LIT8,7,7,24);
                code.visitStmt2R1N(ADD_INT_LIT8,5,4,1);
                code.visitLabel(L6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10,4},new Method("Ljava/lang/String;","charAt",new String[]{ "I"},"C"));
                code.visitLabel(L48);
                code.visitStmt1R(MOVE_RESULT,8);
                code.visitStmt2R(INT_TO_BYTE,8,8);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 8},new Method("Lorg/mortbay/util/TypeUtil;","convertHexDigit",new String[]{ "B"},"B"));
                code.visitLabel(L7);
                code.visitStmt1R(MOVE_RESULT,8);
                code.visitStmt2R1N(SHL_INT_LIT8,8,8,16);
                code.visitStmt2R(ADD_INT_2ADDR,7,8);
                code.visitStmt2R1N(ADD_INT_LIT8,4,5,1);
                code.visitLabel(L8);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10,5},new Method("Ljava/lang/String;","charAt",new String[]{ "I"},"C"));
                code.visitLabel(L49);
                code.visitStmt1R(MOVE_RESULT,8);
                code.visitStmt2R(INT_TO_BYTE,8,8);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 8},new Method("Lorg/mortbay/util/TypeUtil;","convertHexDigit",new String[]{ "B"},"B"));
                code.visitLabel(L9);
                code.visitStmt1R(MOVE_RESULT,8);
                code.visitStmt2R1N(SHL_INT_LIT8,8,8,8);
                code.visitStmt2R(ADD_INT_2ADDR,7,8);
                code.visitStmt2R1N(ADD_INT_LIT8,5,4,1);
                code.visitLabel(L10);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10,4},new Method("Ljava/lang/String;","charAt",new String[]{ "I"},"C"));
                code.visitLabel(L50);
                code.visitStmt1R(MOVE_RESULT,8);
                code.visitStmt2R(INT_TO_BYTE,8,8);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 8},new Method("Lorg/mortbay/util/TypeUtil;","convertHexDigit",new String[]{ "B"},"B"));
                code.visitStmt1R(MOVE_RESULT,8);
                code.visitStmt2R(ADD_INT_2ADDR,7,8);
                code.visitStmt2R(INT_TO_CHAR,7,7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,7},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "C"},"Ljava/lang/StringBuffer;"));
                code.visitStmt2R(MOVE,4,5);
                code.visitLabel(L51);
                code.visitJumpStmt(GOTO,-1,-1,L34);
                code.visitLabel(L52);
                code.visitConstStmt(CONST_16,7, Integer.valueOf(92)); // int: 0x0000005c  float:0.000000
                code.visitJumpStmt(IF_NE,1,7,L55);
                code.visitLabel(L53);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitStmt2R(MOVE,4,5);
                code.visitLabel(L54);
                code.visitJumpStmt(GOTO,-1,-1,L34);
                code.visitLabel(L55);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "C"},"Ljava/lang/StringBuffer;"));
                code.visitStmt2R(MOVE,4,5);
                code.visitLabel(L56);
                code.visitJumpStmt(GOTO,-1,-1,L34);
                code.visitLabel(L57);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/lang/StringBuffer;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitStmt1R(MONITOR_EXIT,0);
                code.visitLabel(L11);
                code.visitJumpStmt(GOTO_16,-1,-1,L17);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,7);
                code.visitStmt2R(MOVE,4,5);
                code.visitLabel(L12);
                code.visitStmt1R(MONITOR_EXIT,0);
                code.visitLabel(L13);
                code.visitStmt1R(THROW,7);
                code.visitLabel(L5);
                code.visitStmt1R(MOVE_EXCEPTION,7);
                code.visitJumpStmt(GOTO,-1,-1,L12);
                code.visitLabel(L58);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m009_countTokens(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/util/QuotedStringTokenizer;","countTokens",new String[]{ },"I"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(252,L0);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(-1)); // int: 0xffffffff  float:NaN
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m010_getDouble(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/util/QuotedStringTokenizer;","getDouble",new String[]{ },"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(572,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_BOOLEAN,0,1,new Field("Lorg/mortbay/util/QuotedStringTokenizer;","_double","Z"));
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m011_getSingle(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/util/QuotedStringTokenizer;","getSingle",new String[]{ },"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(590,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_BOOLEAN,0,1,new Field("Lorg/mortbay/util/QuotedStringTokenizer;","_single","Z"));
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m012_hasMoreElements(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/util/QuotedStringTokenizer;","hasMoreElements",new String[]{ },"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(237,L0);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Lorg/mortbay/util/QuotedStringTokenizer;","hasMoreTokens",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m013_hasMoreTokens(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/util/QuotedStringTokenizer;","hasMoreTokens",new String[]{ },"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(11);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(92,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(208,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(95,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(97,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(98,L5);
                ddv.visitStartLocal(2,L5,"state","I",null);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(99,L6);
                ddv.visitStartLocal(1,L6,"escape","Z",null);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(101,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(103,L8);
                ddv.visitStartLocal(0,L8,"c","C",null);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(106,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(108,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(110,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(111,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(114,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(116,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(117,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(118,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(120,L17);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(122,L18);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(123,L19);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(124,L20);
                DexLabel L21=new DexLabel();
                ddv.visitLineNumber(128,L21);
                DexLabel L22=new DexLabel();
                ddv.visitLineNumber(129,L22);
                DexLabel L23=new DexLabel();
                ddv.visitLineNumber(130,L23);
                DexLabel L24=new DexLabel();
                ddv.visitLineNumber(132,L24);
                DexLabel L25=new DexLabel();
                ddv.visitLineNumber(135,L25);
                DexLabel L26=new DexLabel();
                ddv.visitLineNumber(136,L26);
                DexLabel L27=new DexLabel();
                ddv.visitLineNumber(138,L27);
                DexLabel L28=new DexLabel();
                ddv.visitLineNumber(139,L28);
                DexLabel L29=new DexLabel();
                ddv.visitLineNumber(140,L29);
                DexLabel L30=new DexLabel();
                ddv.visitLineNumber(142,L30);
                DexLabel L31=new DexLabel();
                ddv.visitLineNumber(144,L31);
                DexLabel L32=new DexLabel();
                ddv.visitLineNumber(145,L32);
                DexLabel L33=new DexLabel();
                ddv.visitLineNumber(146,L33);
                DexLabel L34=new DexLabel();
                ddv.visitLineNumber(148,L34);
                DexLabel L35=new DexLabel();
                ddv.visitLineNumber(150,L35);
                DexLabel L36=new DexLabel();
                ddv.visitLineNumber(151,L36);
                DexLabel L37=new DexLabel();
                ddv.visitLineNumber(152,L37);
                DexLabel L38=new DexLabel();
                ddv.visitLineNumber(155,L38);
                DexLabel L39=new DexLabel();
                ddv.visitLineNumber(160,L39);
                DexLabel L40=new DexLabel();
                ddv.visitLineNumber(161,L40);
                DexLabel L41=new DexLabel();
                ddv.visitLineNumber(163,L41);
                DexLabel L42=new DexLabel();
                ddv.visitLineNumber(164,L42);
                DexLabel L43=new DexLabel();
                ddv.visitLineNumber(166,L43);
                DexLabel L44=new DexLabel();
                ddv.visitLineNumber(168,L44);
                DexLabel L45=new DexLabel();
                ddv.visitLineNumber(169,L45);
                DexLabel L46=new DexLabel();
                ddv.visitLineNumber(170,L46);
                DexLabel L47=new DexLabel();
                ddv.visitLineNumber(172,L47);
                DexLabel L48=new DexLabel();
                ddv.visitLineNumber(174,L48);
                DexLabel L49=new DexLabel();
                ddv.visitLineNumber(175,L49);
                DexLabel L50=new DexLabel();
                ddv.visitLineNumber(176,L50);
                DexLabel L51=new DexLabel();
                ddv.visitLineNumber(179,L51);
                DexLabel L52=new DexLabel();
                ddv.visitLineNumber(184,L52);
                DexLabel L53=new DexLabel();
                ddv.visitLineNumber(185,L53);
                DexLabel L54=new DexLabel();
                ddv.visitLineNumber(187,L54);
                DexLabel L55=new DexLabel();
                ddv.visitLineNumber(188,L55);
                DexLabel L56=new DexLabel();
                ddv.visitLineNumber(190,L56);
                DexLabel L57=new DexLabel();
                ddv.visitLineNumber(192,L57);
                DexLabel L58=new DexLabel();
                ddv.visitLineNumber(193,L58);
                DexLabel L59=new DexLabel();
                ddv.visitLineNumber(194,L59);
                DexLabel L60=new DexLabel();
                ddv.visitLineNumber(196,L60);
                DexLabel L61=new DexLabel();
                ddv.visitLineNumber(198,L61);
                DexLabel L62=new DexLabel();
                ddv.visitLineNumber(199,L62);
                DexLabel L63=new DexLabel();
                ddv.visitLineNumber(200,L63);
                DexLabel L64=new DexLabel();
                ddv.visitLineNumber(203,L64);
                DexLabel L65=new DexLabel();
                ddv.visitLineNumber(208,L65);
                ddv.visitEndLocal(0,L65);
                DexLabel L66=new DexLabel();
                ddv.visitLineNumber(103,L66);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_16,9, Integer.valueOf(92)); // int: 0x0000005c  float:0.000000
                code.visitConstStmt(CONST_16,8, Integer.valueOf(39)); // int: 0x00000027  float:0.000000
                code.visitConstStmt(CONST_16,7, Integer.valueOf(34)); // int: 0x00000022  float:0.000000
                code.visitConstStmt(CONST_4,6, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_BOOLEAN,3,10,new Field("Lorg/mortbay/util/QuotedStringTokenizer;","_hasToken","Z"));
                code.visitJumpStmt(IF_EQZ,3,-1,L3);
                code.visitStmt2R(MOVE,3,6);
                code.visitLabel(L2);
                code.visitStmt1R(RETURN,3);
                code.visitLabel(L3);
                code.visitFieldStmt(IGET,3,10,new Field("Lorg/mortbay/util/QuotedStringTokenizer;","_i","I"));
                code.visitFieldStmt(IPUT,3,10,new Field("Lorg/mortbay/util/QuotedStringTokenizer;","_lastStart","I"));
                code.visitLabel(L4);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L5);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L6);
                code.visitFieldStmt(IGET,3,10,new Field("Lorg/mortbay/util/QuotedStringTokenizer;","_i","I"));
                code.visitFieldStmt(IGET_OBJECT,4,10,new Field("Lorg/mortbay/util/QuotedStringTokenizer;","_string","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Ljava/lang/String;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,4);
                code.visitJumpStmt(IF_GE,3,4,L65);
                code.visitLabel(L7);
                code.visitFieldStmt(IGET_OBJECT,3,10,new Field("Lorg/mortbay/util/QuotedStringTokenizer;","_string","Ljava/lang/String;"));
                code.visitFieldStmt(IGET,4,10,new Field("Lorg/mortbay/util/QuotedStringTokenizer;","_i","I"));
                code.visitStmt2R1N(ADD_INT_LIT8,5,4,1);
                code.visitFieldStmt(IPUT,5,10,new Field("Lorg/mortbay/util/QuotedStringTokenizer;","_i","I"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,4},new Method("Ljava/lang/String;","charAt",new String[]{ "I"},"C"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitLabel(L8);
                code.visitSparseSwitchStmt(PACKED_SWITCH,2,0,new DexLabel[]{L9,L25,L39,L52});
                DexLabel L67=new DexLabel();
                code.visitLabel(L67);
                code.visitJumpStmt(GOTO,-1,-1,L6);
                code.visitLabel(L9);
                code.visitFieldStmt(IGET_OBJECT,3,10,new Field("Lorg/mortbay/util/QuotedStringTokenizer;","_delim","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,0},new Method("Ljava/lang/String;","indexOf",new String[]{ "I"},"I"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitJumpStmt(IF_LTZ,3,-1,L13);
                code.visitLabel(L10);
                code.visitFieldStmt(IGET_BOOLEAN,3,10,new Field("Lorg/mortbay/util/QuotedStringTokenizer;","_returnDelimiters","Z"));
                code.visitJumpStmt(IF_EQZ,3,-1,L6);
                code.visitLabel(L11);
                code.visitFieldStmt(IGET_OBJECT,3,10,new Field("Lorg/mortbay/util/QuotedStringTokenizer;","_token","Ljava/lang/StringBuffer;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,0},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "C"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L12);
                code.visitFieldStmt(IPUT_BOOLEAN,6,10,new Field("Lorg/mortbay/util/QuotedStringTokenizer;","_hasToken","Z"));
                code.visitStmt2R(MOVE,3,6);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitLabel(L13);
                code.visitJumpStmt(IF_NE,0,8,L17);
                code.visitFieldStmt(IGET_BOOLEAN,3,10,new Field("Lorg/mortbay/util/QuotedStringTokenizer;","_single","Z"));
                code.visitJumpStmt(IF_EQZ,3,-1,L17);
                code.visitLabel(L14);
                code.visitFieldStmt(IGET_BOOLEAN,3,10,new Field("Lorg/mortbay/util/QuotedStringTokenizer;","_returnQuotes","Z"));
                code.visitJumpStmt(IF_EQZ,3,-1,L16);
                code.visitLabel(L15);
                code.visitFieldStmt(IGET_OBJECT,3,10,new Field("Lorg/mortbay/util/QuotedStringTokenizer;","_token","Ljava/lang/StringBuffer;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,0},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "C"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L16);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(2)); // int: 0x00000002  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L6);
                code.visitLabel(L17);
                code.visitJumpStmt(IF_NE,0,7,L21);
                code.visitFieldStmt(IGET_BOOLEAN,3,10,new Field("Lorg/mortbay/util/QuotedStringTokenizer;","_double","Z"));
                code.visitJumpStmt(IF_EQZ,3,-1,L21);
                code.visitLabel(L18);
                code.visitFieldStmt(IGET_BOOLEAN,3,10,new Field("Lorg/mortbay/util/QuotedStringTokenizer;","_returnQuotes","Z"));
                code.visitJumpStmt(IF_EQZ,3,-1,L20);
                code.visitLabel(L19);
                code.visitFieldStmt(IGET_OBJECT,3,10,new Field("Lorg/mortbay/util/QuotedStringTokenizer;","_token","Ljava/lang/StringBuffer;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,0},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "C"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L20);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(3)); // int: 0x00000003  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L6);
                code.visitLabel(L21);
                code.visitFieldStmt(IGET_OBJECT,3,10,new Field("Lorg/mortbay/util/QuotedStringTokenizer;","_token","Ljava/lang/StringBuffer;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,0},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "C"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L22);
                code.visitFieldStmt(IPUT_BOOLEAN,6,10,new Field("Lorg/mortbay/util/QuotedStringTokenizer;","_hasToken","Z"));
                code.visitLabel(L23);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitLabel(L24);
                code.visitJumpStmt(GOTO,-1,-1,L6);
                code.visitLabel(L25);
                code.visitFieldStmt(IPUT_BOOLEAN,6,10,new Field("Lorg/mortbay/util/QuotedStringTokenizer;","_hasToken","Z"));
                code.visitLabel(L26);
                code.visitFieldStmt(IGET_OBJECT,3,10,new Field("Lorg/mortbay/util/QuotedStringTokenizer;","_delim","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,0},new Method("Ljava/lang/String;","indexOf",new String[]{ "I"},"I"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitJumpStmt(IF_LTZ,3,-1,L30);
                code.visitLabel(L27);
                code.visitFieldStmt(IGET_BOOLEAN,3,10,new Field("Lorg/mortbay/util/QuotedStringTokenizer;","_returnDelimiters","Z"));
                code.visitJumpStmt(IF_EQZ,3,-1,L29);
                code.visitLabel(L28);
                code.visitFieldStmt(IGET,3,10,new Field("Lorg/mortbay/util/QuotedStringTokenizer;","_i","I"));
                code.visitStmt2R(SUB_INT_2ADDR,3,6);
                code.visitFieldStmt(IPUT,3,10,new Field("Lorg/mortbay/util/QuotedStringTokenizer;","_i","I"));
                code.visitLabel(L29);
                code.visitFieldStmt(IGET_BOOLEAN,3,10,new Field("Lorg/mortbay/util/QuotedStringTokenizer;","_hasToken","Z"));
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitLabel(L30);
                code.visitJumpStmt(IF_NE,0,8,L34);
                code.visitFieldStmt(IGET_BOOLEAN,3,10,new Field("Lorg/mortbay/util/QuotedStringTokenizer;","_single","Z"));
                code.visitJumpStmt(IF_EQZ,3,-1,L34);
                code.visitLabel(L31);
                code.visitFieldStmt(IGET_BOOLEAN,3,10,new Field("Lorg/mortbay/util/QuotedStringTokenizer;","_returnQuotes","Z"));
                code.visitJumpStmt(IF_EQZ,3,-1,L33);
                code.visitLabel(L32);
                code.visitFieldStmt(IGET_OBJECT,3,10,new Field("Lorg/mortbay/util/QuotedStringTokenizer;","_token","Ljava/lang/StringBuffer;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,0},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "C"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L33);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(2)); // int: 0x00000002  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L6);
                code.visitLabel(L34);
                code.visitJumpStmt(IF_NE,0,7,L38);
                code.visitFieldStmt(IGET_BOOLEAN,3,10,new Field("Lorg/mortbay/util/QuotedStringTokenizer;","_double","Z"));
                code.visitJumpStmt(IF_EQZ,3,-1,L38);
                code.visitLabel(L35);
                code.visitFieldStmt(IGET_BOOLEAN,3,10,new Field("Lorg/mortbay/util/QuotedStringTokenizer;","_returnQuotes","Z"));
                code.visitJumpStmt(IF_EQZ,3,-1,L37);
                code.visitLabel(L36);
                code.visitFieldStmt(IGET_OBJECT,3,10,new Field("Lorg/mortbay/util/QuotedStringTokenizer;","_token","Ljava/lang/StringBuffer;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,0},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "C"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L37);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(3)); // int: 0x00000003  float:0.000000
                code.visitJumpStmt(GOTO_16,-1,-1,L6);
                code.visitLabel(L38);
                code.visitFieldStmt(IGET_OBJECT,3,10,new Field("Lorg/mortbay/util/QuotedStringTokenizer;","_token","Ljava/lang/StringBuffer;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,0},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "C"},"Ljava/lang/StringBuffer;"));
                code.visitJumpStmt(GOTO_16,-1,-1,L6);
                code.visitLabel(L39);
                code.visitFieldStmt(IPUT_BOOLEAN,6,10,new Field("Lorg/mortbay/util/QuotedStringTokenizer;","_hasToken","Z"));
                code.visitLabel(L40);
                code.visitJumpStmt(IF_EQZ,1,-1,L43);
                code.visitLabel(L41);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L42);
                code.visitFieldStmt(IGET_OBJECT,3,10,new Field("Lorg/mortbay/util/QuotedStringTokenizer;","_token","Ljava/lang/StringBuffer;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,0},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "C"},"Ljava/lang/StringBuffer;"));
                code.visitJumpStmt(GOTO_16,-1,-1,L6);
                code.visitLabel(L43);
                code.visitJumpStmt(IF_NE,0,8,L47);
                code.visitLabel(L44);
                code.visitFieldStmt(IGET_BOOLEAN,3,10,new Field("Lorg/mortbay/util/QuotedStringTokenizer;","_returnQuotes","Z"));
                code.visitJumpStmt(IF_EQZ,3,-1,L46);
                code.visitLabel(L45);
                code.visitFieldStmt(IGET_OBJECT,3,10,new Field("Lorg/mortbay/util/QuotedStringTokenizer;","_token","Ljava/lang/StringBuffer;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,0},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "C"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L46);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitJumpStmt(GOTO_16,-1,-1,L6);
                code.visitLabel(L47);
                code.visitJumpStmt(IF_NE,0,9,L51);
                code.visitLabel(L48);
                code.visitFieldStmt(IGET_BOOLEAN,3,10,new Field("Lorg/mortbay/util/QuotedStringTokenizer;","_returnQuotes","Z"));
                code.visitJumpStmt(IF_EQZ,3,-1,L50);
                code.visitLabel(L49);
                code.visitFieldStmt(IGET_OBJECT,3,10,new Field("Lorg/mortbay/util/QuotedStringTokenizer;","_token","Ljava/lang/StringBuffer;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,0},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "C"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L50);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitJumpStmt(GOTO_16,-1,-1,L6);
                code.visitLabel(L51);
                code.visitFieldStmt(IGET_OBJECT,3,10,new Field("Lorg/mortbay/util/QuotedStringTokenizer;","_token","Ljava/lang/StringBuffer;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,0},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "C"},"Ljava/lang/StringBuffer;"));
                code.visitJumpStmt(GOTO_16,-1,-1,L6);
                code.visitLabel(L52);
                code.visitFieldStmt(IPUT_BOOLEAN,6,10,new Field("Lorg/mortbay/util/QuotedStringTokenizer;","_hasToken","Z"));
                code.visitLabel(L53);
                code.visitJumpStmt(IF_EQZ,1,-1,L56);
                code.visitLabel(L54);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L55);
                code.visitFieldStmt(IGET_OBJECT,3,10,new Field("Lorg/mortbay/util/QuotedStringTokenizer;","_token","Ljava/lang/StringBuffer;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,0},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "C"},"Ljava/lang/StringBuffer;"));
                code.visitJumpStmt(GOTO_16,-1,-1,L6);
                code.visitLabel(L56);
                code.visitJumpStmt(IF_NE,0,7,L60);
                code.visitLabel(L57);
                code.visitFieldStmt(IGET_BOOLEAN,3,10,new Field("Lorg/mortbay/util/QuotedStringTokenizer;","_returnQuotes","Z"));
                code.visitJumpStmt(IF_EQZ,3,-1,L59);
                code.visitLabel(L58);
                code.visitFieldStmt(IGET_OBJECT,3,10,new Field("Lorg/mortbay/util/QuotedStringTokenizer;","_token","Ljava/lang/StringBuffer;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,0},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "C"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L59);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitJumpStmt(GOTO_16,-1,-1,L6);
                code.visitLabel(L60);
                code.visitJumpStmt(IF_NE,0,9,L64);
                code.visitLabel(L61);
                code.visitFieldStmt(IGET_BOOLEAN,3,10,new Field("Lorg/mortbay/util/QuotedStringTokenizer;","_returnQuotes","Z"));
                code.visitJumpStmt(IF_EQZ,3,-1,L63);
                code.visitLabel(L62);
                code.visitFieldStmt(IGET_OBJECT,3,10,new Field("Lorg/mortbay/util/QuotedStringTokenizer;","_token","Ljava/lang/StringBuffer;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,0},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "C"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L63);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitJumpStmt(GOTO_16,-1,-1,L6);
                code.visitLabel(L64);
                code.visitFieldStmt(IGET_OBJECT,3,10,new Field("Lorg/mortbay/util/QuotedStringTokenizer;","_token","Ljava/lang/StringBuffer;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,0},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "C"},"Ljava/lang/StringBuffer;"));
                code.visitJumpStmt(GOTO_16,-1,-1,L6);
                code.visitLabel(L65);
                code.visitFieldStmt(IGET_BOOLEAN,3,10,new Field("Lorg/mortbay/util/QuotedStringTokenizer;","_hasToken","Z"));
                code.visitJumpStmt(GOTO_16,-1,-1,L2);
                code.visitLabel(L66);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m014_nextElement(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/util/QuotedStringTokenizer;","nextElement",new String[]{ },"Ljava/lang/Object;"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/util/NoSuchElementException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(244,L0);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Lorg/mortbay/util/QuotedStringTokenizer;","nextToken",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m015_nextToken(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/util/QuotedStringTokenizer;","nextToken",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/util/NoSuchElementException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(215,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(216,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(217,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(218,L4);
                ddv.visitStartLocal(0,L4,"t","Ljava/lang/String;",null);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(219,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(220,L6);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Lorg/mortbay/util/QuotedStringTokenizer;","hasMoreTokens",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitJumpStmt(IF_EQZ,1,-1,L2);
                code.visitFieldStmt(IGET_OBJECT,1,3,new Field("Lorg/mortbay/util/QuotedStringTokenizer;","_token","Ljava/lang/StringBuffer;"));
                code.visitJumpStmt(IF_NEZ,1,-1,L3);
                code.visitLabel(L2);
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Ljava/util/NoSuchElementException;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1},new Method("Ljava/util/NoSuchElementException;","<init>",new String[]{ },"V"));
                code.visitStmt1R(THROW,1);
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,1,3,new Field("Lorg/mortbay/util/QuotedStringTokenizer;","_token","Ljava/lang/StringBuffer;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/lang/StringBuffer;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L4);
                code.visitFieldStmt(IGET_OBJECT,1,3,new Field("Lorg/mortbay/util/QuotedStringTokenizer;","_token","Ljava/lang/StringBuffer;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2},new Method("Ljava/lang/StringBuffer;","setLength",new String[]{ "I"},"V"));
                code.visitLabel(L5);
                code.visitFieldStmt(IPUT_BOOLEAN,2,3,new Field("Lorg/mortbay/util/QuotedStringTokenizer;","_hasToken","Z"));
                code.visitLabel(L6);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m016_nextToken(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/util/QuotedStringTokenizer;","nextToken",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/util/NoSuchElementException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"delim");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(227,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(228,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(229,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(230,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(231,L5);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L1);
                code.visitFieldStmt(IPUT_OBJECT,3,2,new Field("Lorg/mortbay/util/QuotedStringTokenizer;","_delim","Ljava/lang/String;"));
                code.visitLabel(L2);
                code.visitFieldStmt(IGET,0,2,new Field("Lorg/mortbay/util/QuotedStringTokenizer;","_lastStart","I"));
                code.visitFieldStmt(IPUT,0,2,new Field("Lorg/mortbay/util/QuotedStringTokenizer;","_i","I"));
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/util/QuotedStringTokenizer;","_token","Ljava/lang/StringBuffer;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuffer;","setLength",new String[]{ "I"},"V"));
                code.visitLabel(L4);
                code.visitFieldStmt(IPUT_BOOLEAN,1,2,new Field("Lorg/mortbay/util/QuotedStringTokenizer;","_hasToken","Z"));
                code.visitLabel(L5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/util/QuotedStringTokenizer;","nextToken",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m017_setDouble(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/util/QuotedStringTokenizer;","setDouble",new String[]{ "Z"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"d");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(581,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(582,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_BOOLEAN,1,0,new Field("Lorg/mortbay/util/QuotedStringTokenizer;","_double","Z"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m018_setSingle(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/util/QuotedStringTokenizer;","setSingle",new String[]{ "Z"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"single");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(599,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(600,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_BOOLEAN,1,0,new Field("Lorg/mortbay/util/QuotedStringTokenizer;","_single","Z"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
