package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0035_javax_servlet_http_HttpSessionBindingEvent {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(ACC_PUBLIC,"Ljavax/servlet/http/HttpSessionBindingEvent;","Ljavax/servlet/http/HttpSessionEvent;",new String[]{ });
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("HttpSessionBindingEvent.java");
        f000_name(cv);
        f001_value(cv);
        m000__init_(cv);
        m001__init_(cv);
        m002_getName(cv);
        m003_getSession(cv);
        m004_getValue(cv);
    }
    public static void f000_name(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Ljavax/servlet/http/HttpSessionBindingEvent;","name","Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f001_value(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Ljavax/servlet/http/HttpSessionBindingEvent;","value","Ljava/lang/Object;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void m000__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Ljavax/servlet/http/HttpSessionBindingEvent;","<init>",new String[]{ "Ljavax/servlet/http/HttpSession;","Ljava/lang/String;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"session");
                ddv.visitParameterName(1,"name");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(88,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(89,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(90,L2);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1},new Method("Ljavax/servlet/http/HttpSessionEvent;","<init>",new String[]{ "Ljavax/servlet/http/HttpSession;"},"V"));
                code.visitLabel(L1);
                code.visitFieldStmt(IPUT_OBJECT,2,0,new Field("Ljavax/servlet/http/HttpSessionBindingEvent;","name","Ljava/lang/String;"));
                code.visitLabel(L2);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Ljavax/servlet/http/HttpSessionBindingEvent;","<init>",new String[]{ "Ljavax/servlet/http/HttpSession;","Ljava/lang/String;","Ljava/lang/Object;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"session");
                ddv.visitParameterName(1,"name");
                ddv.visitParameterName(2,"value");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(111,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(112,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(113,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(114,L3);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1},new Method("Ljavax/servlet/http/HttpSessionEvent;","<init>",new String[]{ "Ljavax/servlet/http/HttpSession;"},"V"));
                code.visitLabel(L1);
                code.visitFieldStmt(IPUT_OBJECT,2,0,new Field("Ljavax/servlet/http/HttpSessionBindingEvent;","name","Ljava/lang/String;"));
                code.visitLabel(L2);
                code.visitFieldStmt(IPUT_OBJECT,3,0,new Field("Ljavax/servlet/http/HttpSessionBindingEvent;","value","Ljava/lang/Object;"));
                code.visitLabel(L3);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m002_getName(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Ljavax/servlet/http/HttpSessionBindingEvent;","getName",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(139,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Ljavax/servlet/http/HttpSessionBindingEvent;","name","Ljava/lang/String;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m003_getSession(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Ljavax/servlet/http/HttpSessionBindingEvent;","getSession",new String[]{ },"Ljavax/servlet/http/HttpSession;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(119,L0);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_SUPER,new int[]{ 1},new Method("Ljavax/servlet/http/HttpSessionEvent;","getSession",new String[]{ },"Ljavax/servlet/http/HttpSession;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m004_getValue(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Ljavax/servlet/http/HttpSessionBindingEvent;","getValue",new String[]{ },"Ljava/lang/Object;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(152,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Ljavax/servlet/http/HttpSessionBindingEvent;","value","Ljava/lang/Object;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
