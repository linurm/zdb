package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0410_org_mortbay_util_IntrospectionUtil {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(ACC_PUBLIC,"Lorg/mortbay/util/IntrospectionUtil;","Ljava/lang/Object;",new String[]{ });
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("IntrospectionUtil.java");
        m000__init_(cv);
        m001_checkParams(cv);
        m002_containsSameFieldName(cv);
        m003_containsSameMethodSignature(cv);
        m004_findField(cv);
        m005_findInheritedField(cv);
        m006_findInheritedMethod(cv);
        m007_findMethod(cv);
        m008_isInheritable(cv);
        m009_isJavaBeanCompliantSetter(cv);
        m010_isSameSignature(cv);
        m011_isTypeCompatible(cv);
    }
    public static void m000__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/util/IntrospectionUtil;","<init>",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(1);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(30,L0);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/lang/Object;","<init>",new String[]{ },"V"));
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001_checkParams(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Lorg/mortbay/util/IntrospectionUtil;","checkParams",new String[]{ "[Ljava/lang/Class;","[Ljava/lang/Class;","Z"},"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(8);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"formalParams");
                ddv.visitParameterName(1,"actualParams");
                ddv.visitParameterName(2,"strict");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(144,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(176,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(146,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(147,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(148,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(149,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(151,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(152,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(154,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(155,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(157,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(158,L12);
                ddv.visitStartLocal(0,L12,"j","I",null);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(160,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(161,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(165,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(167,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(171,L17);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(173,L18);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(176,L19);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,4, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitConstStmt(CONST_4,3, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L1);
                code.visitJumpStmt(IF_NEZ,5,-1,L3);
                code.visitJumpStmt(IF_NEZ,6,-1,L3);
                code.visitStmt2R(MOVE,1,4);
                code.visitLabel(L2);
                code.visitStmt1R(RETURN,1);
                code.visitLabel(L3);
                code.visitJumpStmt(IF_NEZ,5,-1,L5);
                code.visitJumpStmt(IF_EQZ,6,-1,L5);
                code.visitStmt2R(MOVE,1,3);
                code.visitLabel(L4);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitLabel(L5);
                code.visitJumpStmt(IF_EQZ,5,-1,L7);
                code.visitJumpStmt(IF_NEZ,6,-1,L7);
                code.visitStmt2R(MOVE,1,3);
                code.visitLabel(L6);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitLabel(L7);
                code.visitStmt2R(ARRAY_LENGTH,1,5);
                code.visitStmt2R(ARRAY_LENGTH,2,6);
                code.visitJumpStmt(IF_EQ,1,2,L9);
                code.visitStmt2R(MOVE,1,3);
                code.visitLabel(L8);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitLabel(L9);
                code.visitStmt2R(ARRAY_LENGTH,1,5);
                code.visitJumpStmt(IF_NEZ,1,-1,L11);
                code.visitStmt2R(MOVE,1,4);
                code.visitLabel(L10);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitLabel(L11);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L12);
                code.visitJumpStmt(IF_EQZ,7,-1,L15);
                code.visitLabel(L13);
                code.visitStmt2R(ARRAY_LENGTH,1,5);
                code.visitJumpStmt(IF_GE,0,1,L17);
                code.visitStmt3R(AGET_OBJECT,1,5,0);
                code.visitStmt3R(AGET_OBJECT,2,6,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2},new Method("Ljava/lang/Object;","equals",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitJumpStmt(IF_EQZ,1,-1,L17);
                code.visitLabel(L14);
                code.visitStmt2R1N(ADD_INT_LIT8,0,0,1);
                code.visitJumpStmt(GOTO,-1,-1,L13);
                code.visitLabel(L15);
                code.visitStmt2R(ARRAY_LENGTH,1,5);
                code.visitJumpStmt(IF_GE,0,1,L17);
                code.visitStmt3R(AGET_OBJECT,1,5,0);
                code.visitStmt3R(AGET_OBJECT,2,6,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2},new Method("Ljava/lang/Class;","isAssignableFrom",new String[]{ "Ljava/lang/Class;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitJumpStmt(IF_EQZ,1,-1,L17);
                code.visitLabel(L16);
                code.visitStmt2R1N(ADD_INT_LIT8,0,0,1);
                code.visitJumpStmt(GOTO,-1,-1,L15);
                code.visitLabel(L17);
                code.visitStmt2R(ARRAY_LENGTH,1,5);
                DexLabel L20=new DexLabel();
                code.visitJumpStmt(IF_EQ,0,1,L20);
                code.visitStmt2R(MOVE,1,3);
                code.visitLabel(L18);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitLabel(L20);
                code.visitStmt2R(MOVE,1,4);
                code.visitLabel(L19);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m002_containsSameFieldName(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Lorg/mortbay/util/IntrospectionUtil;","containsSameFieldName",new String[]{ "Ljava/lang/reflect/Field;","Ljava/lang/Class;","Z"},"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(8);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"field");
                ddv.visitParameterName(1,"c");
                ddv.visitParameterName(2,"checkPackage");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(237,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(239,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(240,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(250,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(243,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(244,L5);
                ddv.visitStartLocal(2,L5,"sameName","Z",null);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(245,L6);
                ddv.visitStartLocal(0,L6,"fields","[Ljava/lang/reflect/Field;",null);
                DexLabel L7=new DexLabel();
                ddv.visitStartLocal(1,L7,"i","I",null);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(247,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(248,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(245,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(250,L11);
                code.visitLabel(L0);
                code.visitJumpStmt(IF_EQZ,7,-1,L4);
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Ljava/lang/Class;","getPackage",new String[]{ },"Ljava/lang/Package;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Ljava/lang/reflect/Field;","getDeclaringClass",new String[]{ },"Ljava/lang/Class;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Ljava/lang/Class;","getPackage",new String[]{ },"Ljava/lang/Package;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,4},new Method("Ljava/lang/Object;","equals",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitJumpStmt(IF_NEZ,3,-1,L4);
                code.visitLabel(L2);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L3);
                code.visitStmt1R(RETURN,3);
                code.visitLabel(L4);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Ljava/lang/Class;","getDeclaredFields",new String[]{ },"[Ljava/lang/reflect/Field;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L6);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L7);
                code.visitStmt2R(ARRAY_LENGTH,3,0);
                DexLabel L12=new DexLabel();
                code.visitJumpStmt(IF_GE,1,3,L12);
                code.visitJumpStmt(IF_NEZ,2,-1,L12);
                code.visitLabel(L8);
                code.visitStmt3R(AGET_OBJECT,3,0,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Ljava/lang/reflect/Field;","getName",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Ljava/lang/reflect/Field;","getName",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,4},new Method("Ljava/lang/String;","equals",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitJumpStmt(IF_EQZ,3,-1,L10);
                code.visitLabel(L9);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitLabel(L10);
                code.visitStmt2R1N(ADD_INT_LIT8,1,1,1);
                code.visitJumpStmt(GOTO,-1,-1,L7);
                code.visitLabel(L12);
                code.visitStmt2R(MOVE,3,2);
                code.visitLabel(L11);
                code.visitJumpStmt(GOTO,-1,-1,L3);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m003_containsSameMethodSignature(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Lorg/mortbay/util/IntrospectionUtil;","containsSameMethodSignature",new String[]{ "Ljava/lang/reflect/Method;","Ljava/lang/Class;","Z"},"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(8);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"method");
                ddv.visitParameterName(1,"c");
                ddv.visitParameterName(2,"checkPackage");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(218,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(220,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(221,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(231,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(224,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(225,L5);
                ddv.visitStartLocal(2,L5,"samesig","Z",null);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(226,L6);
                ddv.visitStartLocal(1,L6,"methods","[Ljava/lang/reflect/Method;",null);
                DexLabel L7=new DexLabel();
                ddv.visitStartLocal(0,L7,"i","I",null);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(228,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(229,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(226,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(231,L11);
                code.visitLabel(L0);
                code.visitJumpStmt(IF_EQZ,7,-1,L4);
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Ljava/lang/Class;","getPackage",new String[]{ },"Ljava/lang/Package;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Ljava/lang/reflect/Method;","getDeclaringClass",new String[]{ },"Ljava/lang/Class;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Ljava/lang/Class;","getPackage",new String[]{ },"Ljava/lang/Package;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,4},new Method("Ljava/lang/Object;","equals",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitJumpStmt(IF_NEZ,3,-1,L4);
                code.visitLabel(L2);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L3);
                code.visitStmt1R(RETURN,3);
                code.visitLabel(L4);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Ljava/lang/Class;","getDeclaredMethods",new String[]{ },"[Ljava/lang/reflect/Method;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L6);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L7);
                code.visitStmt2R(ARRAY_LENGTH,3,1);
                DexLabel L12=new DexLabel();
                code.visitJumpStmt(IF_GE,0,3,L12);
                code.visitJumpStmt(IF_NEZ,2,-1,L12);
                code.visitLabel(L8);
                code.visitStmt3R(AGET_OBJECT,3,1,0);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 5,3},new Method("Lorg/mortbay/util/IntrospectionUtil;","isSameSignature",new String[]{ "Ljava/lang/reflect/Method;","Ljava/lang/reflect/Method;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitJumpStmt(IF_EQZ,3,-1,L10);
                code.visitLabel(L9);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitLabel(L10);
                code.visitStmt2R1N(ADD_INT_LIT8,0,0,1);
                code.visitJumpStmt(GOTO,-1,-1,L7);
                code.visitLabel(L12);
                code.visitStmt2R(MOVE,3,2);
                code.visitLabel(L11);
                code.visitJumpStmt(GOTO,-1,-1,L3);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m004_findField(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Lorg/mortbay/util/IntrospectionUtil;","findField",new String[]{ "Ljava/lang/Class;","Ljava/lang/String;","Ljava/lang/Class;","Z","Z"},"Ljava/lang/reflect/Field;"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/lang/NoSuchFieldException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(10);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L1},new String[]{ "Ljava/lang/NoSuchFieldException;"});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"clazz");
                ddv.visitParameterName(1,"targetName");
                ddv.visitParameterName(2,"targetType");
                ddv.visitParameterName(3,"checkInheritance");
                ddv.visitParameterName(4,"strictType");
                DexLabel L2=new DexLabel();
                ddv.visitPrologue(L2);
                ddv.visitLineNumber(86,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(87,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(88,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(89,L5);
                ddv.visitLineNumber(93,L0);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(94,L6);
                ddv.visitStartLocal(1,L6,"field","Ljava/lang/reflect/Field;",null);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(96,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(113,L8);
                ddv.visitEndLocal(1,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(101,L9);
                ddv.visitRestartLocal(1,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(102,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(104,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(106,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(109,L13);
                ddv.visitLineNumber(111,L1);
                ddv.visitEndLocal(1,L1);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(113,L14);
                ddv.visitStartLocal(0,L14,"e","Ljava/lang/NoSuchFieldException;",null);
                code.visitLabel(L2);
                code.visitJumpStmt(IF_NEZ,5,-1,L4);
                code.visitLabel(L3);
                code.visitTypeStmt(NEW_INSTANCE,2,-1,"Ljava/lang/NoSuchFieldException;");
                code.visitConstStmt(CONST_STRING,3,"No class");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2,3},new Method("Ljava/lang/NoSuchFieldException;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitStmt1R(THROW,2);
                code.visitLabel(L4);
                code.visitJumpStmt(IF_NEZ,6,-1,L0);
                code.visitLabel(L5);
                code.visitTypeStmt(NEW_INSTANCE,2,-1,"Ljava/lang/NoSuchFieldException;");
                code.visitConstStmt(CONST_STRING,3,"No field name");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2,3},new Method("Ljava/lang/NoSuchFieldException;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitStmt1R(THROW,2);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,6},new Method("Ljava/lang/Class;","getDeclaredField",new String[]{ "Ljava/lang/String;"},"Ljava/lang/reflect/Field;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L6);
                code.visitJumpStmt(IF_EQZ,9,-1,L9);
                code.visitLabel(L7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/lang/reflect/Field;","getType",new String[]{ },"Ljava/lang/Class;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,7},new Method("Ljava/lang/Object;","equals",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitJumpStmt(IF_EQZ,2,-1,L11);
                code.visitStmt2R(MOVE_OBJECT,2,1);
                code.visitLabel(L8);
                code.visitStmt1R(RETURN_OBJECT,2);
                code.visitLabel(L9);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/lang/reflect/Field;","getType",new String[]{ },"Ljava/lang/Class;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,7},new Method("Ljava/lang/Class;","isAssignableFrom",new String[]{ "Ljava/lang/Class;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitJumpStmt(IF_EQZ,2,-1,L11);
                code.visitStmt2R(MOVE_OBJECT,2,1);
                code.visitLabel(L10);
                code.visitJumpStmt(GOTO,-1,-1,L8);
                code.visitLabel(L11);
                code.visitJumpStmt(IF_EQZ,8,-1,L13);
                code.visitLabel(L12);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Ljava/lang/Class;","getPackage",new String[]{ },"Ljava/lang/Package;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Ljava/lang/Class;","getSuperclass",new String[]{ },"Ljava/lang/Class;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 2,3,6,7,9},new Method("Lorg/mortbay/util/IntrospectionUtil;","findInheritedField",new String[]{ "Ljava/lang/Package;","Ljava/lang/Class;","Ljava/lang/String;","Ljava/lang/Class;","Z"},"Ljava/lang/reflect/Field;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitJumpStmt(GOTO,-1,-1,L8);
                code.visitLabel(L13);
                code.visitTypeStmt(NEW_INSTANCE,2,-1,"Ljava/lang/NoSuchFieldException;");
                code.visitTypeStmt(NEW_INSTANCE,3,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 3},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,4,"No field with name ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,4},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,6},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitConstStmt(CONST_STRING,4," in class ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,4},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Ljava/lang/Class;","getName",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,4},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitConstStmt(CONST_STRING,4," of type ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,4},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,7},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2,3},new Method("Ljava/lang/NoSuchFieldException;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitStmt1R(THROW,2);
                code.visitLabel(L1);
                code.visitStmt1R(MOVE_EXCEPTION,2);
                code.visitStmt2R(MOVE_OBJECT,0,2);
                code.visitLabel(L14);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Ljava/lang/Class;","getPackage",new String[]{ },"Ljava/lang/Package;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Ljava/lang/Class;","getSuperclass",new String[]{ },"Ljava/lang/Class;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 2,3,6,7,9},new Method("Lorg/mortbay/util/IntrospectionUtil;","findInheritedField",new String[]{ "Ljava/lang/Package;","Ljava/lang/Class;","Ljava/lang/String;","Ljava/lang/Class;","Z"},"Ljava/lang/reflect/Field;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitJumpStmt(GOTO,-1,-1,L8);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m005_findInheritedField(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED|ACC_STATIC, new Method("Lorg/mortbay/util/IntrospectionUtil;","findInheritedField",new String[]{ "Ljava/lang/Package;","Ljava/lang/Class;","Ljava/lang/String;","Ljava/lang/Class;","Z"},"Ljava/lang/reflect/Field;"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/lang/NoSuchFieldException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(9);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ "Ljava/lang/NoSuchFieldException;"});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"pack");
                ddv.visitParameterName(1,"clazz");
                ddv.visitParameterName(2,"fieldName");
                ddv.visitParameterName(3,"fieldType");
                ddv.visitParameterName(4,"strictType");
                DexLabel L3=new DexLabel();
                ddv.visitPrologue(L3);
                ddv.visitLineNumber(283,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(284,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(285,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(286,L6);
                ddv.visitLineNumber(289,L0);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(290,L7);
                ddv.visitStartLocal(1,L7,"field","Ljava/lang/reflect/Field;",null);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(297,L8);
                ddv.visitEndLocal(1,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(293,L9);
                ddv.visitRestartLocal(1,L9);
                ddv.visitLineNumber(295,L2);
                ddv.visitEndLocal(1,L2);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(297,L10);
                ddv.visitStartLocal(0,L10,"e","Ljava/lang/NoSuchFieldException;",null);
                code.visitLabel(L3);
                code.visitJumpStmt(IF_NEZ,5,-1,L5);
                code.visitLabel(L4);
                code.visitTypeStmt(NEW_INSTANCE,2,-1,"Ljava/lang/NoSuchFieldException;");
                code.visitConstStmt(CONST_STRING,3,"No class");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2,3},new Method("Ljava/lang/NoSuchFieldException;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitStmt1R(THROW,2);
                code.visitLabel(L5);
                code.visitJumpStmt(IF_NEZ,6,-1,L0);
                code.visitLabel(L6);
                code.visitTypeStmt(NEW_INSTANCE,2,-1,"Ljava/lang/NoSuchFieldException;");
                code.visitConstStmt(CONST_STRING,3,"No field name");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2,3},new Method("Ljava/lang/NoSuchFieldException;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitStmt1R(THROW,2);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,6},new Method("Ljava/lang/Class;","getDeclaredField",new String[]{ "Ljava/lang/String;"},"Ljava/lang/reflect/Field;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L7);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 4,1},new Method("Lorg/mortbay/util/IntrospectionUtil;","isInheritable",new String[]{ "Ljava/lang/Package;","Ljava/lang/reflect/Member;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitJumpStmt(IF_EQZ,2,-1,L9);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/lang/reflect/Field;","getType",new String[]{ },"Ljava/lang/Class;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 7,2,8},new Method("Lorg/mortbay/util/IntrospectionUtil;","isTypeCompatible",new String[]{ "Ljava/lang/Class;","Ljava/lang/Class;","Z"},"Z"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitJumpStmt(IF_EQZ,2,-1,L9);
                code.visitStmt2R(MOVE_OBJECT,2,1);
                code.visitLabel(L8);
                code.visitStmt1R(RETURN_OBJECT,2);
                code.visitLabel(L9);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Ljava/lang/Class;","getPackage",new String[]{ },"Ljava/lang/Package;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Ljava/lang/Class;","getSuperclass",new String[]{ },"Ljava/lang/Class;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 2,3,6,7,8},new Method("Lorg/mortbay/util/IntrospectionUtil;","findInheritedField",new String[]{ "Ljava/lang/Package;","Ljava/lang/Class;","Ljava/lang/String;","Ljava/lang/Class;","Z"},"Ljava/lang/reflect/Field;"));
                code.visitLabel(L1);
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitJumpStmt(GOTO,-1,-1,L8);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,2);
                code.visitStmt2R(MOVE_OBJECT,0,2);
                code.visitLabel(L10);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Ljava/lang/Class;","getPackage",new String[]{ },"Ljava/lang/Package;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Ljava/lang/Class;","getSuperclass",new String[]{ },"Ljava/lang/Class;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 2,3,6,7,8},new Method("Lorg/mortbay/util/IntrospectionUtil;","findInheritedField",new String[]{ "Ljava/lang/Package;","Ljava/lang/Class;","Ljava/lang/String;","Ljava/lang/Class;","Z"},"Ljava/lang/reflect/Field;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitJumpStmt(GOTO,-1,-1,L8);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m006_findInheritedMethod(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED|ACC_STATIC, new Method("Lorg/mortbay/util/IntrospectionUtil;","findInheritedMethod",new String[]{ "Ljava/lang/Package;","Ljava/lang/Class;","Ljava/lang/String;","[Ljava/lang/Class;","Z"},"Ljava/lang/reflect/Method;"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/lang/NoSuchMethodException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(10);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"pack");
                ddv.visitParameterName(1,"clazz");
                ddv.visitParameterName(2,"methodName");
                ddv.visitParameterName(3,"args");
                ddv.visitParameterName(4,"strictArgs");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(258,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(259,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(260,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(261,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(263,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(264,L5);
                ddv.visitStartLocal(1,L5,"method","Ljava/lang/reflect/Method;",null);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(265,L6);
                ddv.visitStartLocal(2,L6,"methods","[Ljava/lang/reflect/Method;",null);
                DexLabel L7=new DexLabel();
                ddv.visitStartLocal(0,L7,"i","I",null);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(267,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(270,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(265,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(272,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(277,L12);
                code.visitLabel(L0);
                code.visitJumpStmt(IF_NEZ,6,-1,L2);
                code.visitLabel(L1);
                code.visitTypeStmt(NEW_INSTANCE,3,-1,"Ljava/lang/NoSuchMethodException;");
                code.visitConstStmt(CONST_STRING,4,"No class");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 3,4},new Method("Ljava/lang/NoSuchMethodException;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitStmt1R(THROW,3);
                code.visitLabel(L2);
                code.visitJumpStmt(IF_NEZ,7,-1,L4);
                code.visitLabel(L3);
                code.visitTypeStmt(NEW_INSTANCE,3,-1,"Ljava/lang/NoSuchMethodException;");
                code.visitConstStmt(CONST_STRING,4,"No method name");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 3,4},new Method("Ljava/lang/NoSuchMethodException;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitStmt1R(THROW,3);
                code.visitLabel(L4);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Ljava/lang/Class;","getDeclaredMethods",new String[]{ },"[Ljava/lang/reflect/Method;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitLabel(L6);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L7);
                code.visitStmt2R(ARRAY_LENGTH,3,2);
                code.visitJumpStmt(IF_GE,0,3,L11);
                code.visitJumpStmt(IF_NEZ,1,-1,L11);
                code.visitLabel(L8);
                code.visitStmt3R(AGET_OBJECT,3,2,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Ljava/lang/reflect/Method;","getName",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,7},new Method("Ljava/lang/String;","equals",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitJumpStmt(IF_EQZ,3,-1,L10);
                code.visitStmt3R(AGET_OBJECT,3,2,0);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 5,3},new Method("Lorg/mortbay/util/IntrospectionUtil;","isInheritable",new String[]{ "Ljava/lang/Package;","Ljava/lang/reflect/Member;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitJumpStmt(IF_EQZ,3,-1,L10);
                code.visitStmt3R(AGET_OBJECT,3,2,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Ljava/lang/reflect/Method;","getParameterTypes",new String[]{ },"[Ljava/lang/Class;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 3,8,9},new Method("Lorg/mortbay/util/IntrospectionUtil;","checkParams",new String[]{ "[Ljava/lang/Class;","[Ljava/lang/Class;","Z"},"Z"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitJumpStmt(IF_EQZ,3,-1,L10);
                code.visitLabel(L9);
                code.visitStmt3R(AGET_OBJECT,1,2,0);
                code.visitLabel(L10);
                code.visitStmt2R1N(ADD_INT_LIT8,0,0,1);
                code.visitJumpStmt(GOTO,-1,-1,L7);
                code.visitLabel(L11);
                DexLabel L13=new DexLabel();
                code.visitJumpStmt(IF_EQZ,1,-1,L13);
                code.visitStmt2R(MOVE_OBJECT,3,1);
                code.visitLabel(L12);
                code.visitStmt1R(RETURN_OBJECT,3);
                code.visitLabel(L13);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Ljava/lang/Class;","getPackage",new String[]{ },"Ljava/lang/Package;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Ljava/lang/Class;","getSuperclass",new String[]{ },"Ljava/lang/Class;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 3,4,7,8,9},new Method("Lorg/mortbay/util/IntrospectionUtil;","findInheritedMethod",new String[]{ "Ljava/lang/Package;","Ljava/lang/Class;","Ljava/lang/String;","[Ljava/lang/Class;","Z"},"Ljava/lang/reflect/Method;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitJumpStmt(GOTO,-1,-1,L12);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m007_findMethod(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Lorg/mortbay/util/IntrospectionUtil;","findMethod",new String[]{ "Ljava/lang/Class;","Ljava/lang/String;","[Ljava/lang/Class;","Z","Z"},"Ljava/lang/reflect/Method;"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/lang/NoSuchMethodException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(11);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"clazz");
                ddv.visitParameterName(1,"methodName");
                ddv.visitParameterName(2,"args");
                ddv.visitParameterName(3,"checkInheritance");
                ddv.visitParameterName(4,"strictArgs");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(53,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(54,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(55,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(56,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(58,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(59,L5);
                ddv.visitStartLocal(1,L5,"method","Ljava/lang/reflect/Method;",null);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(60,L6);
                ddv.visitStartLocal(2,L6,"methods","[Ljava/lang/reflect/Method;",null);
                DexLabel L7=new DexLabel();
                ddv.visitStartLocal(0,L7,"i","I",null);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(62,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(64,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(60,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(62,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(68,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(73,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(72,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(73,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(75,L16);
                code.visitLabel(L0);
                code.visitJumpStmt(IF_NEZ,6,-1,L2);
                code.visitLabel(L1);
                code.visitTypeStmt(NEW_INSTANCE,3,-1,"Ljava/lang/NoSuchMethodException;");
                code.visitConstStmt(CONST_STRING,4,"No class");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 3,4},new Method("Ljava/lang/NoSuchMethodException;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitStmt1R(THROW,3);
                code.visitLabel(L2);
                code.visitJumpStmt(IF_EQZ,7,-1,L3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7},new Method("Ljava/lang/String;","trim",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitConstStmt(CONST_STRING,4,"");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,4},new Method("Ljava/lang/String;","equals",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitJumpStmt(IF_EQZ,3,-1,L4);
                code.visitLabel(L3);
                code.visitTypeStmt(NEW_INSTANCE,3,-1,"Ljava/lang/NoSuchMethodException;");
                code.visitConstStmt(CONST_STRING,4,"No method name");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 3,4},new Method("Ljava/lang/NoSuchMethodException;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitStmt1R(THROW,3);
                code.visitLabel(L4);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Ljava/lang/Class;","getDeclaredMethods",new String[]{ },"[Ljava/lang/reflect/Method;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitLabel(L6);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L7);
                code.visitStmt2R(ARRAY_LENGTH,3,2);
                code.visitJumpStmt(IF_GE,0,3,L12);
                code.visitJumpStmt(IF_NEZ,1,-1,L12);
                code.visitLabel(L8);
                code.visitStmt3R(AGET_OBJECT,3,2,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Ljava/lang/reflect/Method;","getName",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,7},new Method("Ljava/lang/String;","equals",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitJumpStmt(IF_EQZ,3,-1,L10);
                code.visitStmt3R(AGET_OBJECT,3,2,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Ljava/lang/reflect/Method;","getParameterTypes",new String[]{ },"[Ljava/lang/Class;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                DexLabel L17=new DexLabel();
                code.visitJumpStmt(IF_NEZ,8,-1,L17);
                code.visitConstStmt(CONST_4,4, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitTypeStmt(NEW_ARRAY,4,4,"[Ljava/lang/Class;");
                DexLabel L18=new DexLabel();
                code.visitLabel(L18);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 3,4,10},new Method("Lorg/mortbay/util/IntrospectionUtil;","checkParams",new String[]{ "[Ljava/lang/Class;","[Ljava/lang/Class;","Z"},"Z"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitJumpStmt(IF_EQZ,3,-1,L10);
                code.visitLabel(L9);
                code.visitStmt3R(AGET_OBJECT,1,2,0);
                code.visitLabel(L10);
                code.visitStmt2R1N(ADD_INT_LIT8,0,0,1);
                code.visitJumpStmt(GOTO,-1,-1,L7);
                code.visitLabel(L17);
                code.visitStmt2R(MOVE_OBJECT,4,8);
                code.visitLabel(L11);
                code.visitJumpStmt(GOTO,-1,-1,L18);
                code.visitLabel(L12);
                code.visitJumpStmt(IF_EQZ,1,-1,L14);
                code.visitStmt2R(MOVE_OBJECT,3,1);
                code.visitLabel(L13);
                code.visitStmt1R(RETURN_OBJECT,3);
                code.visitLabel(L14);
                code.visitJumpStmt(IF_EQZ,9,-1,L16);
                code.visitLabel(L15);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Ljava/lang/Class;","getPackage",new String[]{ },"Ljava/lang/Package;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Ljava/lang/Class;","getSuperclass",new String[]{ },"Ljava/lang/Class;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 3,4,7,8,10},new Method("Lorg/mortbay/util/IntrospectionUtil;","findInheritedMethod",new String[]{ "Ljava/lang/Package;","Ljava/lang/Class;","Ljava/lang/String;","[Ljava/lang/Class;","Z"},"Ljava/lang/reflect/Method;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitJumpStmt(GOTO,-1,-1,L13);
                code.visitLabel(L16);
                code.visitTypeStmt(NEW_INSTANCE,3,-1,"Ljava/lang/NoSuchMethodException;");
                code.visitTypeStmt(NEW_INSTANCE,4,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 4},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,5,"No such method ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,5},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,7},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitConstStmt(CONST_STRING,5," on class ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,5},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Ljava/lang/Class;","getName",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,5},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 3,4},new Method("Ljava/lang/NoSuchMethodException;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitStmt1R(THROW,3);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m008_isInheritable(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Lorg/mortbay/util/IntrospectionUtil;","isInheritable",new String[]{ "Ljava/lang/Package;","Ljava/lang/reflect/Member;"},"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(6);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"pack");
                ddv.visitParameterName(1,"member");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(123,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(136,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(125,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(126,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(128,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(129,L6);
                ddv.visitStartLocal(0,L6,"modifiers","I",null);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(130,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(131,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(132,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(133,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(134,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(136,L12);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L1);
                code.visitJumpStmt(IF_NEZ,4,-1,L3);
                code.visitStmt2R(MOVE,1,2);
                code.visitLabel(L2);
                code.visitStmt1R(RETURN,1);
                code.visitLabel(L3);
                code.visitJumpStmt(IF_NEZ,5,-1,L5);
                code.visitStmt2R(MOVE,1,2);
                code.visitLabel(L4);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitLabel(L5);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 5},new Method("Ljava/lang/reflect/Member;","getModifiers",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitLabel(L6);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0},new Method("Ljava/lang/reflect/Modifier;","isPublic",new String[]{ "I"},"Z"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitJumpStmt(IF_EQZ,1,-1,L8);
                code.visitStmt2R(MOVE,1,3);
                code.visitLabel(L7);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitLabel(L8);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0},new Method("Ljava/lang/reflect/Modifier;","isProtected",new String[]{ "I"},"Z"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitJumpStmt(IF_EQZ,1,-1,L10);
                code.visitStmt2R(MOVE,1,3);
                code.visitLabel(L9);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitLabel(L10);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0},new Method("Ljava/lang/reflect/Modifier;","isPrivate",new String[]{ "I"},"Z"));
                code.visitStmt1R(MOVE_RESULT,1);
                DexLabel L13=new DexLabel();
                code.visitJumpStmt(IF_NEZ,1,-1,L13);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 5},new Method("Ljava/lang/reflect/Member;","getDeclaringClass",new String[]{ },"Ljava/lang/Class;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/lang/Class;","getPackage",new String[]{ },"Ljava/lang/Package;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,1},new Method("Ljava/lang/Object;","equals",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitJumpStmt(IF_EQZ,1,-1,L13);
                code.visitStmt2R(MOVE,1,3);
                code.visitLabel(L11);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitLabel(L13);
                code.visitStmt2R(MOVE,1,2);
                code.visitLabel(L12);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m009_isJavaBeanCompliantSetter(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Lorg/mortbay/util/IntrospectionUtil;","isJavaBeanCompliantSetter",new String[]{ "Ljava/lang/reflect/Method;"},"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"method");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(35,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(47,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(38,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(39,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(41,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(42,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(44,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(45,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(47,L9);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L1);
                code.visitJumpStmt(IF_NEZ,4,-1,L3);
                code.visitStmt2R(MOVE,0,2);
                code.visitLabel(L2);
                code.visitStmt1R(RETURN,0);
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Ljava/lang/reflect/Method;","getReturnType",new String[]{ },"Ljava/lang/Class;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(SGET_OBJECT,1,-1,new Field("Ljava/lang/Void;","TYPE","Ljava/lang/Class;"));
                code.visitJumpStmt(IF_EQ,0,1,L5);
                code.visitStmt2R(MOVE,0,2);
                code.visitLabel(L4);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitLabel(L5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Ljava/lang/reflect/Method;","getName",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitConstStmt(CONST_STRING,1,"set");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/String;","startsWith",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_NEZ,0,-1,L7);
                code.visitStmt2R(MOVE,0,2);
                code.visitLabel(L6);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitLabel(L7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Ljava/lang/reflect/Method;","getParameterTypes",new String[]{ },"[Ljava/lang/Class;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitStmt2R(ARRAY_LENGTH,0,0);
                DexLabel L10=new DexLabel();
                code.visitJumpStmt(IF_EQ,0,3,L10);
                code.visitStmt2R(MOVE,0,2);
                code.visitLabel(L8);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitLabel(L10);
                code.visitStmt2R(MOVE,0,3);
                code.visitLabel(L9);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m010_isSameSignature(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Lorg/mortbay/util/IntrospectionUtil;","isSameSignature",new String[]{ "Ljava/lang/reflect/Method;","Ljava/lang/reflect/Method;"},"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(7);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"methodA");
                ddv.visitParameterName(1,"methodB");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(182,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(195,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(184,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(185,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(187,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(188,L6);
                ddv.visitStartLocal(0,L6,"parameterTypesA","Ljava/util/List;",null);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(190,L7);
                ddv.visitStartLocal(1,L7,"parameterTypesB","Ljava/util/List;",null);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(193,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(195,L9);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,4, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L1);
                code.visitJumpStmt(IF_NEZ,5,-1,L3);
                code.visitStmt2R(MOVE,2,4);
                code.visitLabel(L2);
                code.visitStmt1R(RETURN,2);
                code.visitLabel(L3);
                code.visitJumpStmt(IF_NEZ,6,-1,L5);
                code.visitStmt2R(MOVE,2,4);
                code.visitLabel(L4);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitLabel(L5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Ljava/lang/reflect/Method;","getParameterTypes",new String[]{ },"[Ljava/lang/Class;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 2},new Method("Ljava/util/Arrays;","asList",new String[]{ "[Ljava/lang/Object;"},"Ljava/util/List;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Ljava/lang/reflect/Method;","getParameterTypes",new String[]{ },"[Ljava/lang/Class;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 2},new Method("Ljava/util/Arrays;","asList",new String[]{ "[Ljava/lang/Object;"},"Ljava/util/List;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Ljava/lang/reflect/Method;","getName",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Ljava/lang/reflect/Method;","getName",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3},new Method("Ljava/lang/String;","equals",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,2);
                DexLabel L10=new DexLabel();
                code.visitJumpStmt(IF_EQZ,2,-1,L10);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,1},new Method("Ljava/util/List;","containsAll",new String[]{ "Ljava/util/Collection;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitJumpStmt(IF_EQZ,2,-1,L10);
                code.visitLabel(L8);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitLabel(L10);
                code.visitStmt2R(MOVE,2,4);
                code.visitLabel(L9);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m011_isTypeCompatible(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_STATIC, new Method("Lorg/mortbay/util/IntrospectionUtil;","isTypeCompatible",new String[]{ "Ljava/lang/Class;","Ljava/lang/Class;","Z"},"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"formalType");
                ddv.visitParameterName(1,"actualType");
                ddv.visitParameterName(2,"strict");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(200,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(210,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(202,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(204,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(205,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(207,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(208,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(210,L8);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L1);
                code.visitJumpStmt(IF_NEZ,1,-1,L3);
                code.visitJumpStmt(IF_EQZ,2,-1,L3);
                code.visitLabel(L2);
                code.visitStmt1R(RETURN,0);
                code.visitLabel(L3);
                code.visitJumpStmt(IF_EQZ,1,-1,L4);
                code.visitJumpStmt(IF_EQZ,2,-1,L2);
                code.visitLabel(L4);
                code.visitJumpStmt(IF_NEZ,1,-1,L6);
                code.visitJumpStmt(IF_NEZ,2,-1,L6);
                code.visitLabel(L5);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitLabel(L6);
                code.visitJumpStmt(IF_EQZ,3,-1,L8);
                code.visitLabel(L7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2},new Method("Ljava/lang/Object;","equals",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitLabel(L8);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2},new Method("Ljava/lang/Class;","isAssignableFrom",new String[]{ "Ljava/lang/Class;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
