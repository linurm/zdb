package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0463_org_mortbay_xml_XmlParser_Handler {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(0,"Lorg/mortbay/xml/XmlParser$Handler;","Lorg/xml/sax/helpers/DefaultHandler;",new String[]{ });
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("XmlParser.java");
        if(cv!=null){
            DexAnnotationVisitor av00 = cv.visitAnnotation("Ldalvik/annotation/EnclosingClass;", Visibility.SYSTEM);
            if(av00 != null) {
                av00.visit("value", new DexType("Lorg/mortbay/xml/XmlParser;"));
                av00.visitEnd();
            }
        }
        if(cv!=null){
            DexAnnotationVisitor av00 = cv.visitAnnotation("Ldalvik/annotation/InnerClass;", Visibility.SYSTEM);
            if(av00 != null) {
                av00.visit("accessFlags",  Integer.valueOf(2));
                av00.visit("name", "Handler");
                av00.visitEnd();
            }
        }
        f000__context(cv);
        f001__error(cv);
        f002__noop(cv);
        f003__top(cv);
        f004_this$0(cv);
        m000__init_(cv);
        m001_getLocationString(cv);
        m002_characters(cv);
        m003_clear(cv);
        m004_endElement(cv);
        m005_error(cv);
        m006_fatalError(cv);
        m007_ignorableWhitespace(cv);
        m008_resolveEntity(cv);
        m009_startElement(cv);
        m010_warning(cv);
    }
    public static void f000__context(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/xml/XmlParser$Handler;","_context","Lorg/mortbay/xml/XmlParser$Node;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f001__error(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(0, new Field("Lorg/mortbay/xml/XmlParser$Handler;","_error","Lorg/xml/sax/SAXParseException;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f002__noop(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/xml/XmlParser$Handler;","_noop","Lorg/mortbay/xml/XmlParser$NoopHandler;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f003__top(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(0, new Field("Lorg/mortbay/xml/XmlParser$Handler;","_top","Lorg/mortbay/xml/XmlParser$Node;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f004_this$0(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_FINAL|ACC_SYNTHETIC, new Field("Lorg/mortbay/xml/XmlParser$Handler;","this$0","Lorg/mortbay/xml/XmlParser;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void m000__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_CONSTRUCTOR, new Method("Lorg/mortbay/xml/XmlParser$Handler;","<init>",new String[]{ "Lorg/mortbay/xml/XmlParser;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(276,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(270,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(272,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(277,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(278,L5);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L1);
                code.visitFieldStmt(IPUT_OBJECT,3,2,new Field("Lorg/mortbay/xml/XmlParser$Handler;","this$0","Lorg/mortbay/xml/XmlParser;"));
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2},new Method("Lorg/xml/sax/helpers/DefaultHandler;","<init>",new String[]{ },"V"));
                code.visitLabel(L2);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Lorg/mortbay/xml/XmlParser$Node;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1,1,1},new Method("Lorg/mortbay/xml/XmlParser$Node;","<init>",new String[]{ "Lorg/mortbay/xml/XmlParser$Node;","Ljava/lang/String;","Lorg/xml/sax/Attributes;"},"V"));
                code.visitFieldStmt(IPUT_OBJECT,0,2,new Field("Lorg/mortbay/xml/XmlParser$Handler;","_top","Lorg/mortbay/xml/XmlParser$Node;"));
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/xml/XmlParser$Handler;","_top","Lorg/mortbay/xml/XmlParser$Node;"));
                code.visitFieldStmt(IPUT_OBJECT,0,2,new Field("Lorg/mortbay/xml/XmlParser$Handler;","_context","Lorg/mortbay/xml/XmlParser$Node;"));
                code.visitLabel(L4);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Lorg/mortbay/xml/XmlParser$NoopHandler;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,3,2},new Method("Lorg/mortbay/xml/XmlParser$NoopHandler;","<init>",new String[]{ "Lorg/mortbay/xml/XmlParser;","Lorg/mortbay/xml/XmlParser$Handler;"},"V"));
                code.visitFieldStmt(IPUT_OBJECT,0,2,new Field("Lorg/mortbay/xml/XmlParser$Handler;","_noop","Lorg/mortbay/xml/XmlParser$NoopHandler;"));
                code.visitLabel(L5);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001_getLocationString(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PRIVATE, new Method("Lorg/mortbay/xml/XmlParser$Handler;","getLocationString",new String[]{ "Lorg/xml/sax/SAXParseException;"},"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"ex");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(389,L0);
                code.visitLabel(L0);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Lorg/xml/sax/SAXParseException;","getSystemId",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitConstStmt(CONST_STRING,1," line:");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Lorg/xml/sax/SAXParseException;","getLineNumber",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "I"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitConstStmt(CONST_STRING,1," col:");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Lorg/xml/sax/SAXParseException;","getColumnNumber",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "I"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m002_characters(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/xml/XmlParser$Handler;","characters",new String[]{ "[C","I","I"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Lorg/xml/sax/SAXException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(7);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"buf");
                ddv.visitParameterName(1,"offset");
                ddv.visitParameterName(2,"len");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(354,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(355,L1);
                DexLabel L2=new DexLabel();
                ddv.visitStartLocal(0,L2,"i","I",null);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(356,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(357,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(355,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(358,L6);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,1,3,new Field("Lorg/mortbay/xml/XmlParser$Handler;","_context","Lorg/mortbay/xml/XmlParser$Node;"));
                code.visitTypeStmt(NEW_INSTANCE,2,-1,"Ljava/lang/String;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2,4,5,6},new Method("Ljava/lang/String;","<init>",new String[]{ "[C","I","I"},"V"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2},new Method("Lorg/mortbay/xml/XmlParser$Node;","add",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L2);
                code.visitFieldStmt(IGET_OBJECT,1,3,new Field("Lorg/mortbay/xml/XmlParser$Handler;","this$0","Lorg/mortbay/xml/XmlParser;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1},new Method("Lorg/mortbay/xml/XmlParser;","access$300",new String[]{ "Lorg/mortbay/xml/XmlParser;"},"Ljava/util/Stack;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/util/Stack;","size",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitJumpStmt(IF_GE,0,1,L6);
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,1,3,new Field("Lorg/mortbay/xml/XmlParser$Handler;","this$0","Lorg/mortbay/xml/XmlParser;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1},new Method("Lorg/mortbay/xml/XmlParser;","access$300",new String[]{ "Lorg/mortbay/xml/XmlParser;"},"Ljava/util/Stack;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,0},new Method("Ljava/util/Stack;","get",new String[]{ "I"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitJumpStmt(IF_EQZ,1,-1,L5);
                code.visitLabel(L4);
                code.visitFieldStmt(IGET_OBJECT,1,3,new Field("Lorg/mortbay/xml/XmlParser$Handler;","this$0","Lorg/mortbay/xml/XmlParser;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1},new Method("Lorg/mortbay/xml/XmlParser;","access$300",new String[]{ "Lorg/mortbay/xml/XmlParser;"},"Ljava/util/Stack;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,0},new Method("Ljava/util/Stack;","get",new String[]{ "I"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitTypeStmt(CHECK_CAST,1,-1,"Lorg/xml/sax/ContentHandler;");
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 1,4,5,6},new Method("Lorg/xml/sax/ContentHandler;","characters",new String[]{ "[C","I","I"},"V"));
                code.visitLabel(L5);
                code.visitStmt2R1N(ADD_INT_LIT8,0,0,1);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitLabel(L6);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m003_clear(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(0, new Method("Lorg/mortbay/xml/XmlParser$Handler;","clear",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(283,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(284,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(285,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(286,L4);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L1);
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/xml/XmlParser$Handler;","_top","Lorg/mortbay/xml/XmlParser$Node;"));
                code.visitLabel(L2);
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/xml/XmlParser$Handler;","_error","Lorg/xml/sax/SAXParseException;"));
                code.visitLabel(L3);
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/xml/XmlParser$Handler;","_context","Lorg/mortbay/xml/XmlParser$Node;"));
                code.visitLabel(L4);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m004_endElement(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/xml/XmlParser$Handler;","endElement",new String[]{ "Ljava/lang/String;","Ljava/lang/String;","Ljava/lang/String;"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Lorg/xml/sax/SAXException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(6);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"uri");
                ddv.visitParameterName(1,"localName");
                ddv.visitParameterName(2,"qName");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(336,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(337,L1);
                DexLabel L2=new DexLabel();
                ddv.visitStartLocal(0,L2,"i","I",null);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(338,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(339,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(337,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(340,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(341,L7);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/xml/XmlParser$Handler;","_context","Lorg/mortbay/xml/XmlParser$Node;"));
                code.visitFieldStmt(IGET_OBJECT,1,1,new Field("Lorg/mortbay/xml/XmlParser$Node;","_parent","Lorg/mortbay/xml/XmlParser$Node;"));
                code.visitFieldStmt(IPUT_OBJECT,1,2,new Field("Lorg/mortbay/xml/XmlParser$Handler;","_context","Lorg/mortbay/xml/XmlParser$Node;"));
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L2);
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/xml/XmlParser$Handler;","this$0","Lorg/mortbay/xml/XmlParser;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1},new Method("Lorg/mortbay/xml/XmlParser;","access$300",new String[]{ "Lorg/mortbay/xml/XmlParser;"},"Ljava/util/Stack;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/util/Stack;","size",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitJumpStmt(IF_GE,0,1,L6);
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/xml/XmlParser$Handler;","this$0","Lorg/mortbay/xml/XmlParser;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1},new Method("Lorg/mortbay/xml/XmlParser;","access$300",new String[]{ "Lorg/mortbay/xml/XmlParser;"},"Ljava/util/Stack;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,0},new Method("Ljava/util/Stack;","get",new String[]{ "I"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitJumpStmt(IF_EQZ,1,-1,L5);
                code.visitLabel(L4);
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/xml/XmlParser$Handler;","this$0","Lorg/mortbay/xml/XmlParser;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1},new Method("Lorg/mortbay/xml/XmlParser;","access$300",new String[]{ "Lorg/mortbay/xml/XmlParser;"},"Ljava/util/Stack;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,0},new Method("Ljava/util/Stack;","get",new String[]{ "I"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitTypeStmt(CHECK_CAST,1,-1,"Lorg/xml/sax/ContentHandler;");
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 1,3,4,5},new Method("Lorg/xml/sax/ContentHandler;","endElement",new String[]{ "Ljava/lang/String;","Ljava/lang/String;","Ljava/lang/String;"},"V"));
                code.visitLabel(L5);
                code.visitStmt2R1N(ADD_INT_LIT8,0,0,1);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitLabel(L6);
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/xml/XmlParser$Handler;","this$0","Lorg/mortbay/xml/XmlParser;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1},new Method("Lorg/mortbay/xml/XmlParser;","access$300",new String[]{ "Lorg/mortbay/xml/XmlParser;"},"Ljava/util/Stack;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/util/Stack;","pop",new String[]{ },"Ljava/lang/Object;"));
                code.visitLabel(L7);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m005_error(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/xml/XmlParser$Handler;","error",new String[]{ "Lorg/xml/sax/SAXParseException;"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Lorg/xml/sax/SAXException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"ex");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(371,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(372,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(373,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(374,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(375,L4);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/xml/XmlParser$Handler;","_error","Lorg/xml/sax/SAXParseException;"));
                code.visitJumpStmt(IF_NEZ,0,-1,L2);
                code.visitLabel(L1);
                code.visitFieldStmt(IPUT_OBJECT,3,2,new Field("Lorg/mortbay/xml/XmlParser$Handler;","_error","Lorg/xml/sax/SAXParseException;"));
                code.visitLabel(L2);
                code.visitConstStmt(CONST_STRING,0,"EXCEPTION ");
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0,3},new Method("Lorg/mortbay/log/Log;","debug",new String[]{ "Ljava/lang/String;","Ljava/lang/Object;"},"V"));
                code.visitLabel(L3);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,1,"ERROR@");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2,3},new Method("Lorg/mortbay/xml/XmlParser$Handler;","getLocationString",new String[]{ "Lorg/xml/sax/SAXParseException;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitConstStmt(CONST_STRING,1," : ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Lorg/xml/sax/SAXParseException;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0},new Method("Lorg/mortbay/log/Log;","warn",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L4);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m006_fatalError(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/xml/XmlParser$Handler;","fatalError",new String[]{ "Lorg/xml/sax/SAXParseException;"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Lorg/xml/sax/SAXException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"ex");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(380,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(381,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(382,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(383,L3);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_OBJECT,3,2,new Field("Lorg/mortbay/xml/XmlParser$Handler;","_error","Lorg/xml/sax/SAXParseException;"));
                code.visitLabel(L1);
                code.visitConstStmt(CONST_STRING,0,"EXCEPTION ");
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0,3},new Method("Lorg/mortbay/log/Log;","debug",new String[]{ "Ljava/lang/String;","Ljava/lang/Object;"},"V"));
                code.visitLabel(L2);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,1,"FATAL@");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2,3},new Method("Lorg/mortbay/xml/XmlParser$Handler;","getLocationString",new String[]{ "Lorg/xml/sax/SAXParseException;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitConstStmt(CONST_STRING,1," : ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Lorg/xml/sax/SAXParseException;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0},new Method("Lorg/mortbay/log/Log;","warn",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L3);
                code.visitStmt1R(THROW,3);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m007_ignorableWhitespace(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/xml/XmlParser$Handler;","ignorableWhitespace",new String[]{ "[C","I","I"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Lorg/xml/sax/SAXException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(6);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"buf");
                ddv.visitParameterName(1,"offset");
                ddv.visitParameterName(2,"len");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(346,L0);
                DexLabel L1=new DexLabel();
                ddv.visitStartLocal(0,L1,"i","I",null);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(347,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(348,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(346,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(349,L5);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/xml/XmlParser$Handler;","this$0","Lorg/mortbay/xml/XmlParser;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1},new Method("Lorg/mortbay/xml/XmlParser;","access$300",new String[]{ "Lorg/mortbay/xml/XmlParser;"},"Ljava/util/Stack;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/util/Stack;","size",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitJumpStmt(IF_GE,0,1,L5);
                code.visitLabel(L2);
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/xml/XmlParser$Handler;","this$0","Lorg/mortbay/xml/XmlParser;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1},new Method("Lorg/mortbay/xml/XmlParser;","access$300",new String[]{ "Lorg/mortbay/xml/XmlParser;"},"Ljava/util/Stack;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,0},new Method("Ljava/util/Stack;","get",new String[]{ "I"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitJumpStmt(IF_EQZ,1,-1,L4);
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/xml/XmlParser$Handler;","this$0","Lorg/mortbay/xml/XmlParser;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1},new Method("Lorg/mortbay/xml/XmlParser;","access$300",new String[]{ "Lorg/mortbay/xml/XmlParser;"},"Ljava/util/Stack;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,0},new Method("Ljava/util/Stack;","get",new String[]{ "I"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitTypeStmt(CHECK_CAST,1,-1,"Lorg/xml/sax/ContentHandler;");
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 1,3,4,5},new Method("Lorg/xml/sax/ContentHandler;","ignorableWhitespace",new String[]{ "[C","I","I"},"V"));
                code.visitLabel(L4);
                code.visitStmt2R1N(ADD_INT_LIT8,0,0,1);
                code.visitJumpStmt(GOTO,-1,-1,L1);
                code.visitLabel(L5);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m008_resolveEntity(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/xml/XmlParser$Handler;","resolveEntity",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"Lorg/xml/sax/InputSource;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(11);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ "Ljava/io/IOException;"});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"pid");
                ddv.visitParameterName(1,"sid");
                DexLabel L3=new DexLabel();
                ddv.visitPrologue(L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(395,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(396,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(398,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(399,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(401,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(402,L9);
                ddv.visitStartLocal(2,L9,"entity","Ljava/net/URL;",null);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(403,L10);
                DexLabel L11=new DexLabel();
                ddv.visitEndLocal(2,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(404,L12);
                ddv.visitRestartLocal(2,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(405,L13);
                DexLabel L14=new DexLabel();
                ddv.visitEndLocal(2,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(406,L15);
                ddv.visitRestartLocal(2,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(408,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(409,L17);
                ddv.visitStartLocal(0,L17,"dtd","Ljava/lang/String;",null);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(410,L18);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(412,L19);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(413,L20);
                DexLabel L21=new DexLabel();
                ddv.visitLineNumber(414,L21);
                DexLabel L22=new DexLabel();
                ddv.visitEndLocal(2,L22);
                DexLabel L23=new DexLabel();
                ddv.visitLineNumber(417,L23);
                ddv.visitEndLocal(0,L23);
                ddv.visitRestartLocal(2,L23);
                ddv.visitLineNumber(421,L0);
                DexLabel L24=new DexLabel();
                ddv.visitLineNumber(422,L24);
                ddv.visitStartLocal(3,L24,"in","Ljava/io/InputStream;",null);
                DexLabel L25=new DexLabel();
                ddv.visitLineNumber(423,L25);
                DexLabel L26=new DexLabel();
                ddv.visitLineNumber(424,L26);
                DexLabel L27=new DexLabel();
                ddv.visitLineNumber(425,L27);
                ddv.visitStartLocal(4,L27,"is","Lorg/xml/sax/InputSource;",null);
                DexLabel L28=new DexLabel();
                ddv.visitLineNumber(433,L28);
                ddv.visitEndLocal(3,L28);
                ddv.visitEndLocal(4,L28);
                ddv.visitLineNumber(428,L2);
                DexLabel L29=new DexLabel();
                ddv.visitLineNumber(430,L29);
                ddv.visitStartLocal(1,L29,"e","Ljava/io/IOException;",null);
                DexLabel L30=new DexLabel();
                ddv.visitLineNumber(433,L30);
                ddv.visitEndLocal(1,L30);
                code.visitLabel(L3);
                code.visitConstStmt(CONST_16,7, Integer.valueOf(47)); // int: 0x0000002f  float:0.000000
                code.visitLabel(L4);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Lorg/mortbay/log/Log;","isDebugEnabled",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,5);
                code.visitJumpStmt(IF_EQZ,5,-1,L6);
                code.visitLabel(L5);
                code.visitTypeStmt(NEW_INSTANCE,5,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 5},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,6,"resolveEntity(");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,6},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,9},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitConstStmt(CONST_STRING,6,", ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,6},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,10},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitConstStmt(CONST_STRING,6,")");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,6},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 5},new Method("Lorg/mortbay/log/Log;","debug",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L6);
                code.visitJumpStmt(IF_EQZ,10,-1,L8);
                code.visitConstStmt(CONST_STRING,5,".dtd");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10,5},new Method("Ljava/lang/String;","endsWith",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,5);
                code.visitJumpStmt(IF_EQZ,5,-1,L8);
                code.visitLabel(L7);
                code.visitFieldStmt(IGET_OBJECT,5,8,new Field("Lorg/mortbay/xml/XmlParser$Handler;","this$0","Lorg/mortbay/xml/XmlParser;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 5,10},new Method("Lorg/mortbay/xml/XmlParser;","access$402",new String[]{ "Lorg/mortbay/xml/XmlParser;","Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitLabel(L8);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L9);
                code.visitJumpStmt(IF_EQZ,9,-1,L12);
                code.visitLabel(L10);
                code.visitFieldStmt(IGET_OBJECT,5,8,new Field("Lorg/mortbay/xml/XmlParser$Handler;","this$0","Lorg/mortbay/xml/XmlParser;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 5},new Method("Lorg/mortbay/xml/XmlParser;","access$500",new String[]{ "Lorg/mortbay/xml/XmlParser;"},"Ljava/util/Map;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 5,9},new Method("Ljava/util/Map;","get",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitLabel(L11);
                code.visitTypeStmt(CHECK_CAST,2,-1,"Ljava/net/URL;");
                code.visitLabel(L12);
                code.visitJumpStmt(IF_NEZ,2,-1,L15);
                code.visitLabel(L13);
                code.visitFieldStmt(IGET_OBJECT,5,8,new Field("Lorg/mortbay/xml/XmlParser$Handler;","this$0","Lorg/mortbay/xml/XmlParser;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 5},new Method("Lorg/mortbay/xml/XmlParser;","access$500",new String[]{ "Lorg/mortbay/xml/XmlParser;"},"Ljava/util/Map;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 5,10},new Method("Ljava/util/Map;","get",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitLabel(L14);
                code.visitTypeStmt(CHECK_CAST,2,-1,"Ljava/net/URL;");
                code.visitLabel(L15);
                code.visitJumpStmt(IF_NEZ,2,-1,L23);
                code.visitLabel(L16);
                code.visitStmt2R(MOVE_OBJECT,0,10);
                code.visitLabel(L17);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,7},new Method("Ljava/lang/String;","lastIndexOf",new String[]{ "I"},"I"));
                code.visitStmt1R(MOVE_RESULT,5);
                code.visitJumpStmt(IF_LTZ,5,-1,L19);
                code.visitLabel(L18);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,7},new Method("Ljava/lang/String;","lastIndexOf",new String[]{ "I"},"I"));
                code.visitStmt1R(MOVE_RESULT,5);
                code.visitStmt2R1N(ADD_INT_LIT8,5,5,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,5},new Method("Ljava/lang/String;","substring",new String[]{ "I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L19);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Lorg/mortbay/log/Log;","isDebugEnabled",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,5);
                code.visitJumpStmt(IF_EQZ,5,-1,L21);
                code.visitLabel(L20);
                code.visitTypeStmt(NEW_INSTANCE,5,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 5},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,6,"Can\'t exact match entity in redirect map, trying ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,6},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,0},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 5},new Method("Lorg/mortbay/log/Log;","debug",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L21);
                code.visitFieldStmt(IGET_OBJECT,5,8,new Field("Lorg/mortbay/xml/XmlParser$Handler;","this$0","Lorg/mortbay/xml/XmlParser;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 5},new Method("Lorg/mortbay/xml/XmlParser;","access$500",new String[]{ "Lorg/mortbay/xml/XmlParser;"},"Ljava/util/Map;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 5,0},new Method("Ljava/util/Map;","get",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitLabel(L22);
                code.visitTypeStmt(CHECK_CAST,2,-1,"Ljava/net/URL;");
                code.visitLabel(L23);
                code.visitJumpStmt(IF_EQZ,2,-1,L30);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Ljava/net/URL;","openStream",new String[]{ },"Ljava/io/InputStream;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitLabel(L24);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Lorg/mortbay/log/Log;","isDebugEnabled",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,5);
                code.visitJumpStmt(IF_EQZ,5,-1,L26);
                code.visitLabel(L25);
                code.visitTypeStmt(NEW_INSTANCE,5,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 5},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,6,"Redirected entity ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,6},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,10},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitConstStmt(CONST_STRING,6," --> ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,6},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,2},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 5},new Method("Lorg/mortbay/log/Log;","debug",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L26);
                code.visitTypeStmt(NEW_INSTANCE,4,-1,"Lorg/xml/sax/InputSource;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 4,3},new Method("Lorg/xml/sax/InputSource;","<init>",new String[]{ "Ljava/io/InputStream;"},"V"));
                code.visitLabel(L27);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,10},new Method("Lorg/xml/sax/InputSource;","setSystemId",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L1);
                code.visitStmt2R(MOVE_OBJECT,5,4);
                code.visitLabel(L28);
                code.visitStmt1R(RETURN_OBJECT,5);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,5);
                code.visitStmt2R(MOVE_OBJECT,1,5);
                code.visitLabel(L29);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1},new Method("Lorg/mortbay/log/Log;","ignore",new String[]{ "Ljava/lang/Throwable;"},"V"));
                code.visitLabel(L30);
                code.visitConstStmt(CONST_4,5, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L28);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m009_startElement(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/xml/XmlParser$Handler;","startElement",new String[]{ "Ljava/lang/String;","Ljava/lang/String;","Ljava/lang/String;","Lorg/xml/sax/Attributes;"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Lorg/xml/sax/SAXException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(16);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"uri");
                ddv.visitParameterName(1,"localName");
                ddv.visitParameterName(2,"qName");
                ddv.visitParameterName(3,"attrs");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(291,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(292,L2);
                ddv.visitStartLocal(3,L2,"name","Ljava/lang/String;",null);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(296,L3);
                ddv.visitStartLocal(4,L3,"node","Lorg/mortbay/xml/XmlParser$Node;",null);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(298,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(299,L5);
                ddv.visitStartLocal(6,L5,"path","Ljava/lang/String;",null);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(300,L6);
                ddv.visitStartLocal(2,L6,"match","Z",null);
                DexLabel L7=new DexLabel();
                ddv.visitStartLocal(0,L7,"i","I",null);
                DexLabel L8=new DexLabel();
                ddv.visitEndLocal(0,L8);
                ddv.visitStartLocal(1,L8,"i","I",null);
                DexLabel L9=new DexLabel();
                ddv.visitRestartLocal(0,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(302,L10);
                ddv.visitEndLocal(1,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(304,L11);
                ddv.visitStartLocal(7,L11,"xpath","Ljava/lang/String;",null);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(305,L12);
                ddv.visitRestartLocal(1,L12);
                DexLabel L13=new DexLabel();
                ddv.visitEndLocal(3,L13);
                ddv.visitEndLocal(4,L13);
                ddv.visitEndLocal(6,L13);
                ddv.visitEndLocal(0,L13);
                ddv.visitEndLocal(7,L13);
                ddv.visitEndLocal(2,L13);
                ddv.visitEndLocal(1,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(291,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(304,L15);
                ddv.visitRestartLocal(0,L15);
                ddv.visitRestartLocal(2,L15);
                ddv.visitRestartLocal(3,L15);
                ddv.visitRestartLocal(4,L15);
                ddv.visitRestartLocal(6,L15);
                ddv.visitRestartLocal(7,L15);
                DexLabel L16=new DexLabel();
                ddv.visitEndLocal(0,L16);
                ddv.visitEndLocal(7,L16);
                ddv.visitRestartLocal(1,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(307,L17);
                ddv.visitEndLocal(1,L17);
                ddv.visitRestartLocal(0,L17);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(309,L18);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(310,L19);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(323,L20);
                ddv.visitEndLocal(2,L20);
                ddv.visitEndLocal(6,L20);
                ddv.visitEndLocal(0,L20);
                DexLabel L21=new DexLabel();
                ddv.visitLineNumber(324,L21);
                ddv.visitStartLocal(5,L21,"observer","Lorg/xml/sax/ContentHandler;",null);
                DexLabel L22=new DexLabel();
                ddv.visitLineNumber(325,L22);
                DexLabel L23=new DexLabel();
                ddv.visitEndLocal(5,L23);
                DexLabel L24=new DexLabel();
                ddv.visitLineNumber(326,L24);
                ddv.visitRestartLocal(5,L24);
                DexLabel L25=new DexLabel();
                ddv.visitLineNumber(328,L25);
                DexLabel L26=new DexLabel();
                ddv.visitRestartLocal(0,L26);
                DexLabel L27=new DexLabel();
                ddv.visitLineNumber(329,L27);
                DexLabel L28=new DexLabel();
                ddv.visitLineNumber(330,L28);
                DexLabel L29=new DexLabel();
                ddv.visitLineNumber(328,L29);
                DexLabel L30=new DexLabel();
                ddv.visitLineNumber(314,L30);
                ddv.visitEndLocal(5,L30);
                ddv.visitRestartLocal(2,L30);
                ddv.visitRestartLocal(6,L30);
                DexLabel L31=new DexLabel();
                ddv.visitLineNumber(319,L31);
                ddv.visitEndLocal(0,L31);
                ddv.visitEndLocal(2,L31);
                ddv.visitEndLocal(6,L31);
                DexLabel L32=new DexLabel();
                ddv.visitLineNumber(320,L32);
                DexLabel L33=new DexLabel();
                ddv.visitLineNumber(331,L33);
                ddv.visitRestartLocal(0,L33);
                ddv.visitRestartLocal(5,L33);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,10, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitLabel(L1);
                DexLabel L34=new DexLabel();
                code.visitJumpStmt(IF_EQZ,12,-1,L34);
                code.visitConstStmt(CONST_STRING,8,"");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 12,8},new Method("Ljava/lang/String;","equals",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,8);
                code.visitJumpStmt(IF_EQZ,8,-1,L13);
                code.visitLabel(L34);
                code.visitStmt2R(MOVE_OBJECT,3,14);
                code.visitLabel(L2);
                code.visitTypeStmt(NEW_INSTANCE,4,-1,"Lorg/mortbay/xml/XmlParser$Node;");
                code.visitFieldStmt(IGET_OBJECT,8,11,new Field("Lorg/mortbay/xml/XmlParser$Handler;","_context","Lorg/mortbay/xml/XmlParser$Node;"));
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 4,8,3,15},new Method("Lorg/mortbay/xml/XmlParser$Node;","<init>",new String[]{ "Lorg/mortbay/xml/XmlParser$Node;","Ljava/lang/String;","Lorg/xml/sax/Attributes;"},"V"));
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,8,11,new Field("Lorg/mortbay/xml/XmlParser$Handler;","this$0","Lorg/mortbay/xml/XmlParser;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 8},new Method("Lorg/mortbay/xml/XmlParser;","access$100",new String[]{ "Lorg/mortbay/xml/XmlParser;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitJumpStmt(IF_EQZ,8,-1,L31);
                code.visitLabel(L4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Lorg/mortbay/xml/XmlParser$Node;","getPath",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitLabel(L5);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L6);
                code.visitFieldStmt(IGET_OBJECT,8,11,new Field("Lorg/mortbay/xml/XmlParser$Handler;","this$0","Lorg/mortbay/xml/XmlParser;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 8},new Method("Lorg/mortbay/xml/XmlParser;","access$100",new String[]{ "Lorg/mortbay/xml/XmlParser;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 8},new Method("Lorg/mortbay/util/LazyList;","size",new String[]{ "Ljava/lang/Object;"},"I"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitLabel(L7);
                code.visitStmt2R(MOVE,1,0);
                code.visitLabel(L8);
                code.visitJumpStmt(IF_NEZ,2,-1,L16);
                code.visitStmt3R(SUB_INT,0,1,10);
                code.visitLabel(L9);
                code.visitJumpStmt(IF_LEZ,1,-1,L17);
                code.visitLabel(L10);
                code.visitFieldStmt(IGET_OBJECT,8,11,new Field("Lorg/mortbay/xml/XmlParser$Handler;","this$0","Lorg/mortbay/xml/XmlParser;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 8},new Method("Lorg/mortbay/xml/XmlParser;","access$100",new String[]{ "Lorg/mortbay/xml/XmlParser;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 8,0},new Method("Lorg/mortbay/util/LazyList;","get",new String[]{ "Ljava/lang/Object;","I"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitTypeStmt(CHECK_CAST,7,-1,"Ljava/lang/String;");
                code.visitLabel(L11);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,7},new Method("Ljava/lang/String;","equals",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,8);
                DexLabel L35=new DexLabel();
                code.visitJumpStmt(IF_NEZ,8,-1,L35);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7,6},new Method("Ljava/lang/String;","startsWith",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,8);
                code.visitJumpStmt(IF_EQZ,8,-1,L15);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7},new Method("Ljava/lang/String;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,8);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Ljava/lang/String;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,9);
                code.visitJumpStmt(IF_LE,8,9,L15);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Ljava/lang/String;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,8);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7,8},new Method("Ljava/lang/String;","charAt",new String[]{ "I"},"C"));
                code.visitStmt1R(MOVE_RESULT,8);
                code.visitConstStmt(CONST_16,9, Integer.valueOf(47)); // int: 0x0000002f  float:0.000000
                code.visitJumpStmt(IF_NE,8,9,L15);
                code.visitLabel(L35);
                code.visitStmt2R(MOVE,2,10);
                DexLabel L36=new DexLabel();
                code.visitLabel(L36);
                code.visitStmt2R(MOVE,1,0);
                code.visitLabel(L12);
                code.visitJumpStmt(GOTO,-1,-1,L8);
                code.visitLabel(L13);
                code.visitStmt2R(MOVE_OBJECT,3,13);
                code.visitLabel(L14);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitLabel(L15);
                code.visitConstStmt(CONST_4,8, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitStmt2R(MOVE,2,8);
                code.visitJumpStmt(GOTO,-1,-1,L36);
                code.visitLabel(L16);
                code.visitStmt2R(MOVE,0,1);
                code.visitLabel(L17);
                code.visitJumpStmt(IF_EQZ,2,-1,L30);
                code.visitLabel(L18);
                code.visitFieldStmt(IGET_OBJECT,8,11,new Field("Lorg/mortbay/xml/XmlParser$Handler;","_context","Lorg/mortbay/xml/XmlParser$Node;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8,4},new Method("Lorg/mortbay/xml/XmlParser$Node;","add",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitLabel(L19);
                code.visitFieldStmt(IPUT_OBJECT,4,11,new Field("Lorg/mortbay/xml/XmlParser$Handler;","_context","Lorg/mortbay/xml/XmlParser$Node;"));
                code.visitLabel(L20);
                code.visitConstStmt(CONST_4,5, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L21);
                code.visitFieldStmt(IGET_OBJECT,8,11,new Field("Lorg/mortbay/xml/XmlParser$Handler;","this$0","Lorg/mortbay/xml/XmlParser;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 8},new Method("Lorg/mortbay/xml/XmlParser;","access$200",new String[]{ "Lorg/mortbay/xml/XmlParser;"},"Ljava/util/Map;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitJumpStmt(IF_EQZ,8,-1,L24);
                code.visitLabel(L22);
                code.visitFieldStmt(IGET_OBJECT,8,11,new Field("Lorg/mortbay/xml/XmlParser$Handler;","this$0","Lorg/mortbay/xml/XmlParser;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 8},new Method("Lorg/mortbay/xml/XmlParser;","access$200",new String[]{ "Lorg/mortbay/xml/XmlParser;"},"Ljava/util/Map;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 8,3},new Method("Ljava/util/Map;","get",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitLabel(L23);
                code.visitTypeStmt(CHECK_CAST,5,-1,"Lorg/xml/sax/ContentHandler;");
                code.visitLabel(L24);
                code.visitFieldStmt(IGET_OBJECT,8,11,new Field("Lorg/mortbay/xml/XmlParser$Handler;","this$0","Lorg/mortbay/xml/XmlParser;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 8},new Method("Lorg/mortbay/xml/XmlParser;","access$300",new String[]{ "Lorg/mortbay/xml/XmlParser;"},"Ljava/util/Stack;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8,5},new Method("Ljava/util/Stack;","push",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitLabel(L25);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L26);
                code.visitFieldStmt(IGET_OBJECT,8,11,new Field("Lorg/mortbay/xml/XmlParser$Handler;","this$0","Lorg/mortbay/xml/XmlParser;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 8},new Method("Lorg/mortbay/xml/XmlParser;","access$300",new String[]{ "Lorg/mortbay/xml/XmlParser;"},"Ljava/util/Stack;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8},new Method("Ljava/util/Stack;","size",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,8);
                code.visitJumpStmt(IF_GE,0,8,L33);
                code.visitLabel(L27);
                code.visitFieldStmt(IGET_OBJECT,8,11,new Field("Lorg/mortbay/xml/XmlParser$Handler;","this$0","Lorg/mortbay/xml/XmlParser;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 8},new Method("Lorg/mortbay/xml/XmlParser;","access$300",new String[]{ "Lorg/mortbay/xml/XmlParser;"},"Ljava/util/Stack;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8,0},new Method("Ljava/util/Stack;","get",new String[]{ "I"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitJumpStmt(IF_EQZ,8,-1,L29);
                code.visitLabel(L28);
                code.visitFieldStmt(IGET_OBJECT,8,11,new Field("Lorg/mortbay/xml/XmlParser$Handler;","this$0","Lorg/mortbay/xml/XmlParser;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 8},new Method("Lorg/mortbay/xml/XmlParser;","access$300",new String[]{ "Lorg/mortbay/xml/XmlParser;"},"Ljava/util/Stack;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8,0},new Method("Ljava/util/Stack;","get",new String[]{ "I"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitTypeStmt(CHECK_CAST,8,-1,"Lorg/xml/sax/ContentHandler;");
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 8,12,13,14,15},new Method("Lorg/xml/sax/ContentHandler;","startElement",new String[]{ "Ljava/lang/String;","Ljava/lang/String;","Ljava/lang/String;","Lorg/xml/sax/Attributes;"},"V"));
                code.visitLabel(L29);
                code.visitStmt2R1N(ADD_INT_LIT8,0,0,1);
                code.visitJumpStmt(GOTO,-1,-1,L26);
                code.visitLabel(L30);
                code.visitFieldStmt(IGET_OBJECT,8,11,new Field("Lorg/mortbay/xml/XmlParser$Handler;","this$0","Lorg/mortbay/xml/XmlParser;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 8},new Method("Lorg/mortbay/xml/XmlParser;","access$000",new String[]{ "Lorg/mortbay/xml/XmlParser;"},"Ljavax/xml/parsers/SAXParser;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8},new Method("Ljavax/xml/parsers/SAXParser;","getXMLReader",new String[]{ },"Lorg/xml/sax/XMLReader;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitFieldStmt(IGET_OBJECT,9,11,new Field("Lorg/mortbay/xml/XmlParser$Handler;","_noop","Lorg/mortbay/xml/XmlParser$NoopHandler;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 8,9},new Method("Lorg/xml/sax/XMLReader;","setContentHandler",new String[]{ "Lorg/xml/sax/ContentHandler;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L20);
                code.visitLabel(L31);
                code.visitFieldStmt(IGET_OBJECT,8,11,new Field("Lorg/mortbay/xml/XmlParser$Handler;","_context","Lorg/mortbay/xml/XmlParser$Node;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8,4},new Method("Lorg/mortbay/xml/XmlParser$Node;","add",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitLabel(L32);
                code.visitFieldStmt(IPUT_OBJECT,4,11,new Field("Lorg/mortbay/xml/XmlParser$Handler;","_context","Lorg/mortbay/xml/XmlParser$Node;"));
                code.visitJumpStmt(GOTO,-1,-1,L20);
                code.visitLabel(L33);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m010_warning(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/xml/XmlParser$Handler;","warning",new String[]{ "Lorg/xml/sax/SAXParseException;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"ex");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(363,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(364,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(365,L2);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_STRING,0,"EXCEPTION ");
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0,3},new Method("Lorg/mortbay/log/Log;","debug",new String[]{ "Ljava/lang/String;","Ljava/lang/Object;"},"V"));
                code.visitLabel(L1);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,1,"WARNING@");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2,3},new Method("Lorg/mortbay/xml/XmlParser$Handler;","getLocationString",new String[]{ "Lorg/xml/sax/SAXParseException;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitConstStmt(CONST_STRING,1," : ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Lorg/xml/sax/SAXParseException;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0},new Method("Lorg/mortbay/log/Log;","warn",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L2);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
