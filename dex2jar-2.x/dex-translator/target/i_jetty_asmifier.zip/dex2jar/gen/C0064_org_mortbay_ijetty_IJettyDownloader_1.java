package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0064_org_mortbay_ijetty_IJettyDownloader_1 {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(0,"Lorg/mortbay/ijetty/IJettyDownloader$1;","Landroid/os/Handler;",new String[]{ });
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("IJettyDownloader.java");
        if(cv!=null){
            DexAnnotationVisitor av00 = cv.visitAnnotation("Ldalvik/annotation/EnclosingClass;", Visibility.SYSTEM);
            if(av00 != null) {
                av00.visit("value", new DexType("Lorg/mortbay/ijetty/IJettyDownloader;"));
                av00.visitEnd();
            }
        }
        if(cv!=null){
            DexAnnotationVisitor av00 = cv.visitAnnotation("Ldalvik/annotation/InnerClass;", Visibility.SYSTEM);
            if(av00 != null) {
                av00.visit("accessFlags",  Integer.valueOf(0));
                av00.visit("name", null);
                av00.visitEnd();
            }
        }
        f000_this$0(cv);
        m000__init_(cv);
        m001_handleMessage(cv);
    }
    public static void f000_this$0(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_FINAL|ACC_SYNTHETIC, new Field("Lorg/mortbay/ijetty/IJettyDownloader$1;","this$0","Lorg/mortbay/ijetty/IJettyDownloader;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void m000__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_CONSTRUCTOR, new Method("Lorg/mortbay/ijetty/IJettyDownloader$1;","<init>",new String[]{ "Lorg/mortbay/ijetty/IJettyDownloader;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(62,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_OBJECT,1,0,new Field("Lorg/mortbay/ijetty/IJettyDownloader$1;","this$0","Lorg/mortbay/ijetty/IJettyDownloader;"));
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Landroid/os/Handler;","<init>",new String[]{ },"V"));
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001_handleMessage(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/ijetty/IJettyDownloader$1;","handleMessage",new String[]{ "Landroid/os/Message;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(9);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"msg");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(64,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(100,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(102,L3);
                ddv.visitEndLocal(7,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(68,L4);
                ddv.visitRestartLocal(7,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(69,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(70,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(71,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(72,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(73,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(74,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(75,L11);
                ddv.visitStartLocal(0,L11,"builder","Landroid/app/AlertDialog$Builder;",null);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(76,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(77,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(78,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(83,L15);
                ddv.visitEndLocal(0,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(84,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(85,L17);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(86,L18);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(87,L19);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(88,L20);
                ddv.visitRestartLocal(0,L20);
                DexLabel L21=new DexLabel();
                ddv.visitLineNumber(89,L21);
                DexLabel L22=new DexLabel();
                ddv.visitEndLocal(7,L22);
                DexLabel L23=new DexLabel();
                ddv.visitLineNumber(90,L23);
                DexLabel L24=new DexLabel();
                ddv.visitLineNumber(91,L24);
                DexLabel L25=new DexLabel();
                ddv.visitLineNumber(64,L25);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,6, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitConstStmt(CONST,5, Integer.valueOf(2131165194)); // int: 0x7f07000a  float:179445982255059680000000000000000000000.000000
                code.visitConstStmt(CONST_16,4, Integer.valueOf(100)); // int: 0x00000064  float:0.000000
                code.visitConstStmt(CONST_4,3, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitConstStmt(CONST_4,2, Integer.valueOf(4)); // int: 0x00000004  float:0.000000
                code.visitLabel(L1);
                code.visitFieldStmt(IGET,1,8,new Field("Landroid/os/Message;","what","I"));
                code.visitSparseSwitchStmt(PACKED_SWITCH,1,0,new DexLabel[]{L4,L15,L3});
                code.visitLabel(L2);
                code.visitConstStmt(CONST_STRING,1,"Jetty");
                code.visitTypeStmt(NEW_INSTANCE,2,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,3,"Unknown message id ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitFieldStmt(IGET,3,8,new Field("Landroid/os/Message;","what","I"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "I"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1,2},new Method("Landroid/util/Log;","e",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"I"));
                code.visitLabel(L3);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L4);
                code.visitFieldStmt(IGET_OBJECT,1,7,new Field("Lorg/mortbay/ijetty/IJettyDownloader$1;","this$0","Lorg/mortbay/ijetty/IJettyDownloader;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1},new Method("Lorg/mortbay/ijetty/IJettyDownloader;","access$000",new String[]{ "Lorg/mortbay/ijetty/IJettyDownloader;"},"Landroid/widget/ProgressBar;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,4},new Method("Landroid/widget/ProgressBar;","setProgress",new String[]{ "I"},"V"));
                code.visitLabel(L5);
                code.visitFieldStmt(IGET_OBJECT,1,7,new Field("Lorg/mortbay/ijetty/IJettyDownloader$1;","this$0","Lorg/mortbay/ijetty/IJettyDownloader;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1},new Method("Lorg/mortbay/ijetty/IJettyDownloader;","access$000",new String[]{ "Lorg/mortbay/ijetty/IJettyDownloader;"},"Landroid/widget/ProgressBar;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2},new Method("Landroid/widget/ProgressBar;","setVisibility",new String[]{ "I"},"V"));
                code.visitLabel(L6);
                code.visitFieldStmt(IGET_OBJECT,1,7,new Field("Lorg/mortbay/ijetty/IJettyDownloader$1;","this$0","Lorg/mortbay/ijetty/IJettyDownloader;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,5},new Method("Lorg/mortbay/ijetty/IJettyDownloader;","findViewById",new String[]{ "I"},"Landroid/view/View;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitTypeStmt(CHECK_CAST,1,-1,"Landroid/widget/TextView;");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2},new Method("Landroid/widget/TextView;","setVisibility",new String[]{ "I"},"V"));
                code.visitLabel(L7);
                code.visitFieldStmt(IGET_OBJECT,1,7,new Field("Lorg/mortbay/ijetty/IJettyDownloader$1;","this$0","Lorg/mortbay/ijetty/IJettyDownloader;"));
                code.visitConstStmt(CONST,2, Integer.valueOf(2131165190)); // int: 0x7f070006  float:179445901125421260000000000000000000000.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2},new Method("Lorg/mortbay/ijetty/IJettyDownloader;","findViewById",new String[]{ "I"},"Landroid/view/View;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitTypeStmt(CHECK_CAST,1,-1,"Landroid/widget/EditText;");
                code.visitConstStmt(CONST_STRING,2,"");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2},new Method("Landroid/widget/EditText;","setText",new String[]{ "Ljava/lang/CharSequence;"},"V"));
                code.visitLabel(L8);
                code.visitFieldStmt(IGET_OBJECT,1,7,new Field("Lorg/mortbay/ijetty/IJettyDownloader$1;","this$0","Lorg/mortbay/ijetty/IJettyDownloader;"));
                code.visitConstStmt(CONST,2, Integer.valueOf(2131165191)); // int: 0x7f070007  float:179445921407830870000000000000000000000.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2},new Method("Lorg/mortbay/ijetty/IJettyDownloader;","findViewById",new String[]{ "I"},"Landroid/view/View;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitTypeStmt(CHECK_CAST,1,-1,"Landroid/widget/EditText;");
                code.visitConstStmt(CONST_STRING,2,"");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2},new Method("Landroid/widget/EditText;","setText",new String[]{ "Ljava/lang/CharSequence;"},"V"));
                code.visitLabel(L9);
                code.visitFieldStmt(IGET_OBJECT,1,7,new Field("Lorg/mortbay/ijetty/IJettyDownloader$1;","this$0","Lorg/mortbay/ijetty/IJettyDownloader;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1,6},new Method("Lorg/mortbay/ijetty/IJettyDownloader;","access$102",new String[]{ "Lorg/mortbay/ijetty/IJettyDownloader;","Ljava/io/File;"},"Ljava/io/File;"));
                code.visitLabel(L10);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Landroid/app/AlertDialog$Builder;");
                code.visitFieldStmt(IGET_OBJECT,1,7,new Field("Lorg/mortbay/ijetty/IJettyDownloader$1;","this$0","Lorg/mortbay/ijetty/IJettyDownloader;"));
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1},new Method("Landroid/app/AlertDialog$Builder;","<init>",new String[]{ "Landroid/content/Context;"},"V"));
                code.visitLabel(L11);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,3},new Method("Landroid/app/AlertDialog$Builder;","setCancelable",new String[]{ "Z"},"Landroid/app/AlertDialog$Builder;"));
                code.visitLabel(L12);
                code.visitConstStmt(CONST,1, Integer.valueOf(2131099679)); // int: 0x7f06001f  float:178117180189876440000000000000000000000.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Landroid/app/AlertDialog$Builder;","setMessage",new String[]{ "I"},"Landroid/app/AlertDialog$Builder;"));
                code.visitLabel(L13);
                code.visitConstStmt(CONST,1, Integer.valueOf(2131099680)); // int: 0x7f060020  float:178117200472286040000000000000000000000.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Landroid/app/AlertDialog$Builder;","setTitle",new String[]{ "I"},"Landroid/app/AlertDialog$Builder;"));
                code.visitLabel(L14);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Landroid/app/AlertDialog$Builder;","show",new String[]{ },"Landroid/app/AlertDialog;"));
                code.visitJumpStmt(GOTO,-1,-1,L3);
                code.visitLabel(L15);
                code.visitFieldStmt(IGET_OBJECT,1,7,new Field("Lorg/mortbay/ijetty/IJettyDownloader$1;","this$0","Lorg/mortbay/ijetty/IJettyDownloader;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1},new Method("Lorg/mortbay/ijetty/IJettyDownloader;","access$000",new String[]{ "Lorg/mortbay/ijetty/IJettyDownloader;"},"Landroid/widget/ProgressBar;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,4},new Method("Landroid/widget/ProgressBar;","setProgress",new String[]{ "I"},"V"));
                code.visitLabel(L16);
                code.visitFieldStmt(IGET_OBJECT,1,7,new Field("Lorg/mortbay/ijetty/IJettyDownloader$1;","this$0","Lorg/mortbay/ijetty/IJettyDownloader;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1},new Method("Lorg/mortbay/ijetty/IJettyDownloader;","access$000",new String[]{ "Lorg/mortbay/ijetty/IJettyDownloader;"},"Landroid/widget/ProgressBar;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2},new Method("Landroid/widget/ProgressBar;","setVisibility",new String[]{ "I"},"V"));
                code.visitLabel(L17);
                code.visitFieldStmt(IGET_OBJECT,1,7,new Field("Lorg/mortbay/ijetty/IJettyDownloader$1;","this$0","Lorg/mortbay/ijetty/IJettyDownloader;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,5},new Method("Lorg/mortbay/ijetty/IJettyDownloader;","findViewById",new String[]{ "I"},"Landroid/view/View;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitTypeStmt(CHECK_CAST,1,-1,"Landroid/widget/TextView;");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2},new Method("Landroid/widget/TextView;","setVisibility",new String[]{ "I"},"V"));
                code.visitLabel(L18);
                code.visitFieldStmt(IGET_OBJECT,1,7,new Field("Lorg/mortbay/ijetty/IJettyDownloader$1;","this$0","Lorg/mortbay/ijetty/IJettyDownloader;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1,6},new Method("Lorg/mortbay/ijetty/IJettyDownloader;","access$102",new String[]{ "Lorg/mortbay/ijetty/IJettyDownloader;","Ljava/io/File;"},"Ljava/io/File;"));
                code.visitLabel(L19);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Landroid/app/AlertDialog$Builder;");
                code.visitFieldStmt(IGET_OBJECT,1,7,new Field("Lorg/mortbay/ijetty/IJettyDownloader$1;","this$0","Lorg/mortbay/ijetty/IJettyDownloader;"));
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1},new Method("Landroid/app/AlertDialog$Builder;","<init>",new String[]{ "Landroid/content/Context;"},"V"));
                code.visitLabel(L20);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,3},new Method("Landroid/app/AlertDialog$Builder;","setCancelable",new String[]{ "Z"},"Landroid/app/AlertDialog$Builder;"));
                code.visitLabel(L21);
                code.visitFieldStmt(IGET_OBJECT,7,8,new Field("Landroid/os/Message;","obj","Ljava/lang/Object;"));
                code.visitLabel(L22);
                code.visitTypeStmt(CHECK_CAST,7,-1,"Ljava/lang/String;");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,7},new Method("Landroid/app/AlertDialog$Builder;","setMessage",new String[]{ "Ljava/lang/CharSequence;"},"Landroid/app/AlertDialog$Builder;"));
                code.visitLabel(L23);
                code.visitConstStmt(CONST,1, Integer.valueOf(2131099678)); // int: 0x7f06001e  float:178117159907466840000000000000000000000.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Landroid/app/AlertDialog$Builder;","setTitle",new String[]{ "I"},"Landroid/app/AlertDialog$Builder;"));
                code.visitLabel(L24);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Landroid/app/AlertDialog$Builder;","show",new String[]{ },"Landroid/app/AlertDialog;"));
                code.visitJumpStmt(GOTO_16,-1,-1,L3);
                code.visitLabel(L25);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
