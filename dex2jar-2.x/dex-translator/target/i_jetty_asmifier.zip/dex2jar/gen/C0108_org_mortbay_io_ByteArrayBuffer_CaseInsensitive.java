package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0108_org_mortbay_io_ByteArrayBuffer_CaseInsensitive {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(ACC_PUBLIC,"Lorg/mortbay/io/ByteArrayBuffer$CaseInsensitive;","Lorg/mortbay/io/ByteArrayBuffer;",new String[]{ "Lorg/mortbay/io/Buffer$CaseInsensitve;"});
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("ByteArrayBuffer.java");
        if(cv!=null){
            DexAnnotationVisitor av00 = cv.visitAnnotation("Ldalvik/annotation/EnclosingClass;", Visibility.SYSTEM);
            if(av00 != null) {
                av00.visit("value", new DexType("Lorg/mortbay/io/ByteArrayBuffer;"));
                av00.visitEnd();
            }
        }
        if(cv!=null){
            DexAnnotationVisitor av00 = cv.visitAnnotation("Ldalvik/annotation/InnerClass;", Visibility.SYSTEM);
            if(av00 != null) {
                av00.visit("accessFlags",  Integer.valueOf(9));
                av00.visit("name", "CaseInsensitive");
                av00.visitEnd();
            }
        }
        m000__init_(cv);
        m001__init_(cv);
        m002_equals(cv);
    }
    public static void m000__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/io/ByteArrayBuffer$CaseInsensitive;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"s");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(414,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(415,L1);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1},new Method("Lorg/mortbay/io/ByteArrayBuffer;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/io/ByteArrayBuffer$CaseInsensitive;","<init>",new String[]{ "[B","I","I","I"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"b");
                ddv.visitParameterName(1,"o");
                ddv.visitParameterName(2,"l");
                ddv.visitParameterName(3,"rw");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(419,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(420,L1);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1,2,3,4},new Method("Lorg/mortbay/io/ByteArrayBuffer;","<init>",new String[]{ "[B","I","I","I"},"V"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m002_equals(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/io/ByteArrayBuffer$CaseInsensitive;","equals",new String[]{ "Ljava/lang/Object;"},"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"obj");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(424,L0);
                DexLabel L1=new DexLabel();
                ddv.visitEndLocal(2,L1);
                code.visitLabel(L0);
                code.visitTypeStmt(CHECK_CAST,2,-1,"Lorg/mortbay/io/Buffer;");
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2},new Method("Lorg/mortbay/io/ByteArrayBuffer$CaseInsensitive;","equalsIgnoreCase",new String[]{ "Lorg/mortbay/io/Buffer;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
