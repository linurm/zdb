package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0375_org_mortbay_servlet_GzipFilter_GZIPResponseWrapper {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(ACC_PUBLIC,"Lorg/mortbay/servlet/GzipFilter$GZIPResponseWrapper;","Ljavax/servlet/http/HttpServletResponseWrapper;",new String[]{ });
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("GzipFilter.java");
        if(cv!=null){
            DexAnnotationVisitor av00 = cv.visitAnnotation("Ldalvik/annotation/EnclosingClass;", Visibility.SYSTEM);
            if(av00 != null) {
                av00.visit("value", new DexType("Lorg/mortbay/servlet/GzipFilter;"));
                av00.visitEnd();
            }
        }
        if(cv!=null){
            DexAnnotationVisitor av00 = cv.visitAnnotation("Ldalvik/annotation/InnerClass;", Visibility.SYSTEM);
            if(av00 != null) {
                av00.visit("accessFlags",  Integer.valueOf(1));
                av00.visit("name", "GZIPResponseWrapper");
                av00.visitEnd();
            }
        }
        f000__contentLength(cv);
        f001__gzStream(cv);
        f002__noGzip(cv);
        f003__request(cv);
        f004__writer(cv);
        f005_this$0(cv);
        m000__init_(cv);
        m001_finish(cv);
        m002_flushBuffer(cv);
        m003_getOutputStream(cv);
        m004_getWriter(cv);
        m005_newGzipStream(cv);
        m006_noGzip(cv);
        m007_reset(cv);
        m008_resetBuffer(cv);
        m009_sendError(cv);
        m010_sendError(cv);
        m011_sendRedirect(cv);
        m012_setContentLength(cv);
        m013_setContentType(cv);
        m014_setHeader(cv);
        m015_setIntHeader(cv);
        m016_setStatus(cv);
        m017_setStatus(cv);
    }
    public static void f000__contentLength(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(0, new Field("Lorg/mortbay/servlet/GzipFilter$GZIPResponseWrapper;","_contentLength","J"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f001__gzStream(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(0, new Field("Lorg/mortbay/servlet/GzipFilter$GZIPResponseWrapper;","_gzStream","Lorg/mortbay/servlet/GzipFilter$GzipStream;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f002__noGzip(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(0, new Field("Lorg/mortbay/servlet/GzipFilter$GZIPResponseWrapper;","_noGzip","Z"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f003__request(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(0, new Field("Lorg/mortbay/servlet/GzipFilter$GZIPResponseWrapper;","_request","Ljavax/servlet/http/HttpServletRequest;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f004__writer(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(0, new Field("Lorg/mortbay/servlet/GzipFilter$GZIPResponseWrapper;","_writer","Ljava/io/PrintWriter;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f005_this$0(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_FINAL|ACC_SYNTHETIC, new Field("Lorg/mortbay/servlet/GzipFilter$GZIPResponseWrapper;","this$0","Lorg/mortbay/servlet/GzipFilter;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void m000__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/servlet/GzipFilter$GZIPResponseWrapper;","<init>",new String[]{ "Lorg/mortbay/servlet/GzipFilter;","Ljavax/servlet/http/HttpServletRequest;","Ljavax/servlet/http/HttpServletResponse;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(6);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(1,"request");
                ddv.visitParameterName(2,"response");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(164,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(165,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(161,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(166,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(167,L4);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_OBJECT,3,2,new Field("Lorg/mortbay/servlet/GzipFilter$GZIPResponseWrapper;","this$0","Lorg/mortbay/servlet/GzipFilter;"));
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2,5},new Method("Ljavax/servlet/http/HttpServletResponseWrapper;","<init>",new String[]{ "Ljavax/servlet/http/HttpServletResponse;"},"V"));
                code.visitLabel(L2);
                code.visitConstStmt(CONST_WIDE_16,0,Long.valueOf(-1L)); // long: 0xffffffffffffffff  double:NaN
                code.visitFieldStmt(IPUT_WIDE,0,2,new Field("Lorg/mortbay/servlet/GzipFilter$GZIPResponseWrapper;","_contentLength","J"));
                code.visitLabel(L3);
                code.visitFieldStmt(IPUT_OBJECT,4,2,new Field("Lorg/mortbay/servlet/GzipFilter$GZIPResponseWrapper;","_request","Ljavax/servlet/http/HttpServletRequest;"));
                code.visitLabel(L4);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001_finish(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(0, new Method("Lorg/mortbay/servlet/GzipFilter$GZIPResponseWrapper;","finish",new String[]{ },"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(340,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(341,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(342,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(343,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(344,L4);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/servlet/GzipFilter$GZIPResponseWrapper;","_writer","Ljava/io/PrintWriter;"));
                code.visitJumpStmt(IF_EQZ,0,-1,L2);
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/servlet/GzipFilter$GZIPResponseWrapper;","_writer","Ljava/io/PrintWriter;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/io/PrintWriter;","flush",new String[]{ },"V"));
                code.visitLabel(L2);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/servlet/GzipFilter$GZIPResponseWrapper;","_gzStream","Lorg/mortbay/servlet/GzipFilter$GzipStream;"));
                code.visitJumpStmt(IF_EQZ,0,-1,L4);
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/servlet/GzipFilter$GZIPResponseWrapper;","_gzStream","Lorg/mortbay/servlet/GzipFilter$GzipStream;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/servlet/GzipFilter$GzipStream;","finish",new String[]{ },"V"));
                code.visitLabel(L4);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m002_flushBuffer(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/servlet/GzipFilter$GZIPResponseWrapper;","flushBuffer",new String[]{ },"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(244,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(245,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(246,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(247,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(250,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(249,L5);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/servlet/GzipFilter$GZIPResponseWrapper;","_writer","Ljava/io/PrintWriter;"));
                code.visitJumpStmt(IF_EQZ,0,-1,L2);
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/servlet/GzipFilter$GZIPResponseWrapper;","_writer","Ljava/io/PrintWriter;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/io/PrintWriter;","flush",new String[]{ },"V"));
                code.visitLabel(L2);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/servlet/GzipFilter$GZIPResponseWrapper;","_gzStream","Lorg/mortbay/servlet/GzipFilter$GzipStream;"));
                code.visitJumpStmt(IF_EQZ,0,-1,L5);
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/servlet/GzipFilter$GZIPResponseWrapper;","_gzStream","Lorg/mortbay/servlet/GzipFilter$GzipStream;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/servlet/GzipFilter$GzipStream;","finish",new String[]{ },"V"));
                code.visitLabel(L4);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Lorg/mortbay/servlet/GzipFilter$GZIPResponseWrapper;","getResponse",new String[]{ },"Ljavax/servlet/ServletResponse;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0},new Method("Ljavax/servlet/ServletResponse;","flushBuffer",new String[]{ },"V"));
                code.visitJumpStmt(GOTO,-1,-1,L4);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m003_getOutputStream(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/servlet/GzipFilter$GZIPResponseWrapper;","getOutputStream",new String[]{ },"Ljavax/servlet/ServletOutputStream;"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(8);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(292,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(294,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(295,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(302,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(297,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(302,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(299,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(300,L7);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,7,new Field("Lorg/mortbay/servlet/GzipFilter$GZIPResponseWrapper;","_gzStream","Lorg/mortbay/servlet/GzipFilter$GzipStream;"));
                code.visitJumpStmt(IF_NEZ,0,-1,L6);
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7},new Method("Lorg/mortbay/servlet/GzipFilter$GZIPResponseWrapper;","getResponse",new String[]{ },"Ljavax/servlet/ServletResponse;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0},new Method("Ljavax/servlet/ServletResponse;","isCommitted",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_NEZ,0,-1,L2);
                code.visitFieldStmt(IGET_BOOLEAN,0,7,new Field("Lorg/mortbay/servlet/GzipFilter$GZIPResponseWrapper;","_noGzip","Z"));
                code.visitJumpStmt(IF_EQZ,0,-1,L4);
                code.visitLabel(L2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7},new Method("Lorg/mortbay/servlet/GzipFilter$GZIPResponseWrapper;","getResponse",new String[]{ },"Ljavax/servlet/ServletResponse;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0},new Method("Ljavax/servlet/ServletResponse;","getOutputStream",new String[]{ },"Ljavax/servlet/ServletOutputStream;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L3);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitLabel(L4);
                code.visitFieldStmt(IGET_OBJECT,1,7,new Field("Lorg/mortbay/servlet/GzipFilter$GZIPResponseWrapper;","_request","Ljavax/servlet/http/HttpServletRequest;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7},new Method("Lorg/mortbay/servlet/GzipFilter$GZIPResponseWrapper;","getResponse",new String[]{ },"Ljavax/servlet/ServletResponse;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitTypeStmt(CHECK_CAST,2,-1,"Ljavax/servlet/http/HttpServletResponse;");
                code.visitFieldStmt(IGET_WIDE,3,7,new Field("Lorg/mortbay/servlet/GzipFilter$GZIPResponseWrapper;","_contentLength","J"));
                code.visitFieldStmt(IGET_OBJECT,0,7,new Field("Lorg/mortbay/servlet/GzipFilter$GZIPResponseWrapper;","this$0","Lorg/mortbay/servlet/GzipFilter;"));
                code.visitFieldStmt(IGET,5,0,new Field("Lorg/mortbay/servlet/GzipFilter;","_bufferSize","I"));
                code.visitFieldStmt(IGET_OBJECT,0,7,new Field("Lorg/mortbay/servlet/GzipFilter$GZIPResponseWrapper;","this$0","Lorg/mortbay/servlet/GzipFilter;"));
                code.visitFieldStmt(IGET,6,0,new Field("Lorg/mortbay/servlet/GzipFilter;","_minGzipSize","I"));
                code.visitStmt2R(MOVE_OBJECT,0,7);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 0,1,2,3,4,5,6},new Method("Lorg/mortbay/servlet/GzipFilter$GZIPResponseWrapper;","newGzipStream",new String[]{ "Ljavax/servlet/http/HttpServletRequest;","Ljavax/servlet/http/HttpServletResponse;","J","I","I"},"Lorg/mortbay/servlet/GzipFilter$GzipStream;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(IPUT_OBJECT,0,7,new Field("Lorg/mortbay/servlet/GzipFilter$GZIPResponseWrapper;","_gzStream","Lorg/mortbay/servlet/GzipFilter$GzipStream;"));
                code.visitLabel(L5);
                code.visitFieldStmt(IGET_OBJECT,0,7,new Field("Lorg/mortbay/servlet/GzipFilter$GZIPResponseWrapper;","_gzStream","Lorg/mortbay/servlet/GzipFilter$GzipStream;"));
                code.visitJumpStmt(GOTO,-1,-1,L3);
                code.visitLabel(L6);
                code.visitFieldStmt(IGET_OBJECT,0,7,new Field("Lorg/mortbay/servlet/GzipFilter$GZIPResponseWrapper;","_writer","Ljava/io/PrintWriter;"));
                code.visitJumpStmt(IF_EQZ,0,-1,L5);
                code.visitLabel(L7);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/lang/IllegalStateException;");
                code.visitConstStmt(CONST_STRING,1,"getWriter() called");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1},new Method("Ljava/lang/IllegalStateException;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitStmt1R(THROW,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m004_getWriter(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/servlet/GzipFilter$GZIPResponseWrapper;","getWriter",new String[]{ },"Ljava/io/PrintWriter;"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(9);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(307,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(309,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(310,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(312,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(313,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(319,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(315,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(316,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(317,L8);
                ddv.visitStartLocal(7,L8,"encoding","Ljava/lang/String;",null);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(319,L9);
                ddv.visitEndLocal(7,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(317,L10);
                ddv.visitRestartLocal(7,L10);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,8,new Field("Lorg/mortbay/servlet/GzipFilter$GZIPResponseWrapper;","_writer","Ljava/io/PrintWriter;"));
                code.visitJumpStmt(IF_NEZ,0,-1,L9);
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,0,8,new Field("Lorg/mortbay/servlet/GzipFilter$GZIPResponseWrapper;","_gzStream","Lorg/mortbay/servlet/GzipFilter$GzipStream;"));
                code.visitJumpStmt(IF_EQZ,0,-1,L3);
                code.visitLabel(L2);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/lang/IllegalStateException;");
                code.visitConstStmt(CONST_STRING,1,"getOutputStream() called");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1},new Method("Ljava/lang/IllegalStateException;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitStmt1R(THROW,0);
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8},new Method("Lorg/mortbay/servlet/GzipFilter$GZIPResponseWrapper;","getResponse",new String[]{ },"Ljavax/servlet/ServletResponse;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0},new Method("Ljavax/servlet/ServletResponse;","isCommitted",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_NEZ,0,-1,L4);
                code.visitFieldStmt(IGET_BOOLEAN,0,8,new Field("Lorg/mortbay/servlet/GzipFilter$GZIPResponseWrapper;","_noGzip","Z"));
                code.visitJumpStmt(IF_EQZ,0,-1,L6);
                code.visitLabel(L4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8},new Method("Lorg/mortbay/servlet/GzipFilter$GZIPResponseWrapper;","getResponse",new String[]{ },"Ljavax/servlet/ServletResponse;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0},new Method("Ljavax/servlet/ServletResponse;","getWriter",new String[]{ },"Ljava/io/PrintWriter;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L5);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitLabel(L6);
                code.visitFieldStmt(IGET_OBJECT,1,8,new Field("Lorg/mortbay/servlet/GzipFilter$GZIPResponseWrapper;","_request","Ljavax/servlet/http/HttpServletRequest;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8},new Method("Lorg/mortbay/servlet/GzipFilter$GZIPResponseWrapper;","getResponse",new String[]{ },"Ljavax/servlet/ServletResponse;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitTypeStmt(CHECK_CAST,2,-1,"Ljavax/servlet/http/HttpServletResponse;");
                code.visitFieldStmt(IGET_WIDE,3,8,new Field("Lorg/mortbay/servlet/GzipFilter$GZIPResponseWrapper;","_contentLength","J"));
                code.visitFieldStmt(IGET_OBJECT,0,8,new Field("Lorg/mortbay/servlet/GzipFilter$GZIPResponseWrapper;","this$0","Lorg/mortbay/servlet/GzipFilter;"));
                code.visitFieldStmt(IGET,5,0,new Field("Lorg/mortbay/servlet/GzipFilter;","_bufferSize","I"));
                code.visitFieldStmt(IGET_OBJECT,0,8,new Field("Lorg/mortbay/servlet/GzipFilter$GZIPResponseWrapper;","this$0","Lorg/mortbay/servlet/GzipFilter;"));
                code.visitFieldStmt(IGET,6,0,new Field("Lorg/mortbay/servlet/GzipFilter;","_minGzipSize","I"));
                code.visitStmt2R(MOVE_OBJECT,0,8);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 0,1,2,3,4,5,6},new Method("Lorg/mortbay/servlet/GzipFilter$GZIPResponseWrapper;","newGzipStream",new String[]{ "Ljavax/servlet/http/HttpServletRequest;","Ljavax/servlet/http/HttpServletResponse;","J","I","I"},"Lorg/mortbay/servlet/GzipFilter$GzipStream;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(IPUT_OBJECT,0,8,new Field("Lorg/mortbay/servlet/GzipFilter$GZIPResponseWrapper;","_gzStream","Lorg/mortbay/servlet/GzipFilter$GzipStream;"));
                code.visitLabel(L7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8},new Method("Lorg/mortbay/servlet/GzipFilter$GZIPResponseWrapper;","getCharacterEncoding",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitLabel(L8);
                code.visitJumpStmt(IF_NEZ,7,-1,L10);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/io/PrintWriter;");
                code.visitFieldStmt(IGET_OBJECT,1,8,new Field("Lorg/mortbay/servlet/GzipFilter$GZIPResponseWrapper;","_gzStream","Lorg/mortbay/servlet/GzipFilter$GzipStream;"));
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1},new Method("Ljava/io/PrintWriter;","<init>",new String[]{ "Ljava/io/OutputStream;"},"V"));
                DexLabel L11=new DexLabel();
                code.visitLabel(L11);
                code.visitFieldStmt(IPUT_OBJECT,0,8,new Field("Lorg/mortbay/servlet/GzipFilter$GZIPResponseWrapper;","_writer","Ljava/io/PrintWriter;"));
                code.visitLabel(L9);
                code.visitFieldStmt(IGET_OBJECT,0,8,new Field("Lorg/mortbay/servlet/GzipFilter$GZIPResponseWrapper;","_writer","Ljava/io/PrintWriter;"));
                code.visitJumpStmt(GOTO,-1,-1,L5);
                code.visitLabel(L10);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/io/PrintWriter;");
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Ljava/io/OutputStreamWriter;");
                code.visitFieldStmt(IGET_OBJECT,2,8,new Field("Lorg/mortbay/servlet/GzipFilter$GZIPResponseWrapper;","_gzStream","Lorg/mortbay/servlet/GzipFilter$GzipStream;"));
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1,2,7},new Method("Ljava/io/OutputStreamWriter;","<init>",new String[]{ "Ljava/io/OutputStream;","Ljava/lang/String;"},"V"));
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1},new Method("Ljava/io/PrintWriter;","<init>",new String[]{ "Ljava/io/Writer;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L11);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m005_newGzipStream(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Lorg/mortbay/servlet/GzipFilter$GZIPResponseWrapper;","newGzipStream",new String[]{ "Ljavax/servlet/http/HttpServletRequest;","Ljavax/servlet/http/HttpServletResponse;","J","I","I"},"Lorg/mortbay/servlet/GzipFilter$GzipStream;"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(14);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"request");
                ddv.visitParameterName(1,"response");
                ddv.visitParameterName(2,"contentLength");
                ddv.visitParameterName(3,"bufferSize");
                ddv.visitParameterName(4,"minGzipSize");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(348,L0);
                code.visitLabel(L0);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Lorg/mortbay/servlet/GzipFilter$GzipStream;");
                code.visitStmt2R(MOVE_OBJECT,1,8);
                code.visitStmt2R(MOVE_OBJECT,2,9);
                code.visitStmt2R(MOVE_WIDE,3,10);
                code.visitStmt2R(MOVE,5,12);
                code.visitStmt2R(MOVE,6,13);
                code.visitMethodStmt(INVOKE_DIRECT_RANGE,new int[]{ 0,1,2,3,4,5,6},new Method("Lorg/mortbay/servlet/GzipFilter$GzipStream;","<init>",new String[]{ "Ljavax/servlet/http/HttpServletRequest;","Ljavax/servlet/http/HttpServletResponse;","J","I","I"},"V"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m006_noGzip(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(0, new Method("Lorg/mortbay/servlet/GzipFilter$GZIPResponseWrapper;","noGzip",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ "Ljava/io/IOException;"});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L3=new DexLabel();
                ddv.visitPrologue(L3);
                ddv.visitLineNumber(324,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(325,L4);
                ddv.visitLineNumber(329,L0);
                ddv.visitLineNumber(336,L1);
                ddv.visitLineNumber(331,L2);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(333,L5);
                ddv.visitStartLocal(0,L5,"e","Ljava/io/IOException;",null);
                code.visitLabel(L3);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitFieldStmt(IPUT_BOOLEAN,1,2,new Field("Lorg/mortbay/servlet/GzipFilter$GZIPResponseWrapper;","_noGzip","Z"));
                code.visitLabel(L4);
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/servlet/GzipFilter$GZIPResponseWrapper;","_gzStream","Lorg/mortbay/servlet/GzipFilter$GzipStream;"));
                code.visitJumpStmt(IF_EQZ,1,-1,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/servlet/GzipFilter$GZIPResponseWrapper;","_gzStream","Lorg/mortbay/servlet/GzipFilter$GzipStream;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Lorg/mortbay/servlet/GzipFilter$GzipStream;","doNotGzip",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,1);
                code.visitStmt2R(MOVE_OBJECT,0,1);
                code.visitLabel(L5);
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Ljava/lang/IllegalStateException;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1},new Method("Ljava/lang/IllegalStateException;","<init>",new String[]{ },"V"));
                code.visitStmt1R(THROW,1);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m007_reset(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/servlet/GzipFilter$GZIPResponseWrapper;","reset",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(254,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(255,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(256,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(257,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(258,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(259,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(260,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(261,L8);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_SUPER,new int[]{ 2},new Method("Ljavax/servlet/http/HttpServletResponseWrapper;","reset",new String[]{ },"V"));
                code.visitLabel(L2);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/servlet/GzipFilter$GZIPResponseWrapper;","_gzStream","Lorg/mortbay/servlet/GzipFilter$GzipStream;"));
                code.visitJumpStmt(IF_EQZ,0,-1,L4);
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/servlet/GzipFilter$GZIPResponseWrapper;","_gzStream","Lorg/mortbay/servlet/GzipFilter$GzipStream;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/servlet/GzipFilter$GzipStream;","resetBuffer",new String[]{ },"V"));
                code.visitLabel(L4);
                code.visitFieldStmt(IPUT_OBJECT,1,2,new Field("Lorg/mortbay/servlet/GzipFilter$GZIPResponseWrapper;","_writer","Ljava/io/PrintWriter;"));
                code.visitLabel(L5);
                code.visitFieldStmt(IPUT_OBJECT,1,2,new Field("Lorg/mortbay/servlet/GzipFilter$GZIPResponseWrapper;","_gzStream","Lorg/mortbay/servlet/GzipFilter$GzipStream;"));
                code.visitLabel(L6);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT_BOOLEAN,0,2,new Field("Lorg/mortbay/servlet/GzipFilter$GZIPResponseWrapper;","_noGzip","Z"));
                code.visitLabel(L7);
                code.visitConstStmt(CONST_WIDE_16,0,Long.valueOf(-1L)); // long: 0xffffffffffffffff  double:NaN
                code.visitFieldStmt(IPUT_WIDE,0,2,new Field("Lorg/mortbay/servlet/GzipFilter$GZIPResponseWrapper;","_contentLength","J"));
                code.visitLabel(L8);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m008_resetBuffer(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/servlet/GzipFilter$GZIPResponseWrapper;","resetBuffer",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(265,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(266,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(267,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(268,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(269,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(270,L6);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_SUPER,new int[]{ 2},new Method("Ljavax/servlet/http/HttpServletResponseWrapper;","resetBuffer",new String[]{ },"V"));
                code.visitLabel(L2);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/servlet/GzipFilter$GZIPResponseWrapper;","_gzStream","Lorg/mortbay/servlet/GzipFilter$GzipStream;"));
                code.visitJumpStmt(IF_EQZ,0,-1,L4);
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/servlet/GzipFilter$GZIPResponseWrapper;","_gzStream","Lorg/mortbay/servlet/GzipFilter$GzipStream;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/servlet/GzipFilter$GzipStream;","resetBuffer",new String[]{ },"V"));
                code.visitLabel(L4);
                code.visitFieldStmt(IPUT_OBJECT,1,2,new Field("Lorg/mortbay/servlet/GzipFilter$GZIPResponseWrapper;","_writer","Ljava/io/PrintWriter;"));
                code.visitLabel(L5);
                code.visitFieldStmt(IPUT_OBJECT,1,2,new Field("Lorg/mortbay/servlet/GzipFilter$GZIPResponseWrapper;","_gzStream","Lorg/mortbay/servlet/GzipFilter$GzipStream;"));
                code.visitLabel(L6);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m009_sendError(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/servlet/GzipFilter$GZIPResponseWrapper;","sendError",new String[]{ "I"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"sc");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(280,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(281,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(282,L2);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/servlet/GzipFilter$GZIPResponseWrapper;","resetBuffer",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_SUPER,new int[]{ 0,1},new Method("Ljavax/servlet/http/HttpServletResponseWrapper;","sendError",new String[]{ "I"},"V"));
                code.visitLabel(L2);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m010_sendError(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/servlet/GzipFilter$GZIPResponseWrapper;","sendError",new String[]{ "I","Ljava/lang/String;"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"sc");
                ddv.visitParameterName(1,"msg");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(274,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(275,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(276,L2);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/servlet/GzipFilter$GZIPResponseWrapper;","resetBuffer",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_SUPER,new int[]{ 0,1,2},new Method("Ljavax/servlet/http/HttpServletResponseWrapper;","sendError",new String[]{ "I","Ljava/lang/String;"},"V"));
                code.visitLabel(L2);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m011_sendRedirect(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/servlet/GzipFilter$GZIPResponseWrapper;","sendRedirect",new String[]{ "Ljava/lang/String;"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"location");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(286,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(287,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(288,L2);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/servlet/GzipFilter$GZIPResponseWrapper;","resetBuffer",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_SUPER,new int[]{ 0,1},new Method("Ljavax/servlet/http/HttpServletResponseWrapper;","sendRedirect",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L2);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m012_setContentLength(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/servlet/GzipFilter$GZIPResponseWrapper;","setContentLength",new String[]{ "I"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"length");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(201,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(202,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(203,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(204,L3);
                code.visitLabel(L0);
                code.visitStmt2R(INT_TO_LONG,0,4);
                code.visitFieldStmt(IPUT_WIDE,0,3,new Field("Lorg/mortbay/servlet/GzipFilter$GZIPResponseWrapper;","_contentLength","J"));
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,0,3,new Field("Lorg/mortbay/servlet/GzipFilter$GZIPResponseWrapper;","_gzStream","Lorg/mortbay/servlet/GzipFilter$GzipStream;"));
                code.visitJumpStmt(IF_EQZ,0,-1,L3);
                code.visitLabel(L2);
                code.visitFieldStmt(IGET_OBJECT,0,3,new Field("Lorg/mortbay/servlet/GzipFilter$GZIPResponseWrapper;","_gzStream","Lorg/mortbay/servlet/GzipFilter$GzipStream;"));
                code.visitStmt2R(INT_TO_LONG,1,4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1,2},new Method("Lorg/mortbay/servlet/GzipFilter$GzipStream;","setContentLength",new String[]{ "J"},"V"));
                code.visitLabel(L3);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m013_setContentType(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/servlet/GzipFilter$GZIPResponseWrapper;","setContentType",new String[]{ "Ljava/lang/String;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"ct");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(171,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(172,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(173,L2);
                ddv.visitStartLocal(0,L2,"colon","I",null);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(174,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(176,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(180,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(182,L6);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_SUPER,new int[]{ 3,4},new Method("Ljavax/servlet/http/HttpServletResponseWrapper;","setContentType",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L1);
                code.visitConstStmt(CONST_STRING,1,";");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,1},new Method("Ljava/lang/String;","indexOf",new String[]{ "Ljava/lang/String;"},"I"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitLabel(L2);
                code.visitJumpStmt(IF_LEZ,0,-1,L4);
                code.visitLabel(L3);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,1,0},new Method("Ljava/lang/String;","substring",new String[]{ "I","I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitLabel(L4);
                code.visitFieldStmt(IGET_OBJECT,1,3,new Field("Lorg/mortbay/servlet/GzipFilter$GZIPResponseWrapper;","_gzStream","Lorg/mortbay/servlet/GzipFilter$GzipStream;"));
                DexLabel L7=new DexLabel();
                code.visitJumpStmt(IF_EQZ,1,-1,L7);
                code.visitFieldStmt(IGET_OBJECT,1,3,new Field("Lorg/mortbay/servlet/GzipFilter$GZIPResponseWrapper;","_gzStream","Lorg/mortbay/servlet/GzipFilter$GzipStream;"));
                code.visitFieldStmt(IGET_OBJECT,1,1,new Field("Lorg/mortbay/servlet/GzipFilter$GzipStream;","_out","Ljava/io/OutputStream;"));
                code.visitJumpStmt(IF_NEZ,1,-1,L6);
                code.visitLabel(L7);
                code.visitFieldStmt(IGET_OBJECT,1,3,new Field("Lorg/mortbay/servlet/GzipFilter$GZIPResponseWrapper;","this$0","Lorg/mortbay/servlet/GzipFilter;"));
                code.visitFieldStmt(IGET_OBJECT,1,1,new Field("Lorg/mortbay/servlet/GzipFilter;","_mimeTypes","Ljava/util/Set;"));
                DexLabel L8=new DexLabel();
                code.visitJumpStmt(IF_NEZ,1,-1,L8);
                code.visitConstStmt(CONST_STRING,1,"application/gzip");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,4},new Method("Ljava/lang/String;","equalsIgnoreCase",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitJumpStmt(IF_NEZ,1,-1,L5);
                code.visitLabel(L8);
                code.visitFieldStmt(IGET_OBJECT,1,3,new Field("Lorg/mortbay/servlet/GzipFilter$GZIPResponseWrapper;","this$0","Lorg/mortbay/servlet/GzipFilter;"));
                code.visitFieldStmt(IGET_OBJECT,1,1,new Field("Lorg/mortbay/servlet/GzipFilter;","_mimeTypes","Ljava/util/Set;"));
                code.visitJumpStmt(IF_EQZ,1,-1,L6);
                code.visitFieldStmt(IGET_OBJECT,1,3,new Field("Lorg/mortbay/servlet/GzipFilter$GZIPResponseWrapper;","this$0","Lorg/mortbay/servlet/GzipFilter;"));
                code.visitFieldStmt(IGET_OBJECT,1,1,new Field("Lorg/mortbay/servlet/GzipFilter;","_mimeTypes","Ljava/util/Set;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 4},new Method("Lorg/mortbay/util/StringUtil;","asciiToLowerCase",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 1,2},new Method("Ljava/util/Set;","contains",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitJumpStmt(IF_NEZ,1,-1,L6);
                code.visitLabel(L5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Lorg/mortbay/servlet/GzipFilter$GZIPResponseWrapper;","noGzip",new String[]{ },"V"));
                code.visitLabel(L6);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m014_setHeader(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/servlet/GzipFilter$GZIPResponseWrapper;","setHeader",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(6);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"name");
                ddv.visitParameterName(1,"value");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(208,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(210,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(211,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(212,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(228,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(214,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(216,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(218,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(220,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(221,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(223,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(227,L11);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_STRING,0,"content-length");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,4},new Method("Ljava/lang/String;","equalsIgnoreCase",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_EQZ,0,-1,L5);
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 5},new Method("Ljava/lang/Long;","parseLong",new String[]{ "Ljava/lang/String;"},"J"));
                code.visitStmt1R(MOVE_RESULT_WIDE,0);
                code.visitFieldStmt(IPUT_WIDE,0,3,new Field("Lorg/mortbay/servlet/GzipFilter$GZIPResponseWrapper;","_contentLength","J"));
                code.visitLabel(L2);
                code.visitFieldStmt(IGET_OBJECT,0,3,new Field("Lorg/mortbay/servlet/GzipFilter$GZIPResponseWrapper;","_gzStream","Lorg/mortbay/servlet/GzipFilter$GzipStream;"));
                code.visitJumpStmt(IF_EQZ,0,-1,L4);
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,0,3,new Field("Lorg/mortbay/servlet/GzipFilter$GZIPResponseWrapper;","_gzStream","Lorg/mortbay/servlet/GzipFilter$GzipStream;"));
                code.visitFieldStmt(IGET_WIDE,1,3,new Field("Lorg/mortbay/servlet/GzipFilter$GZIPResponseWrapper;","_contentLength","J"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1,2},new Method("Lorg/mortbay/servlet/GzipFilter$GzipStream;","setContentLength",new String[]{ "J"},"V"));
                code.visitLabel(L4);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L5);
                code.visitConstStmt(CONST_STRING,0,"content-type");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,4},new Method("Ljava/lang/String;","equalsIgnoreCase",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_EQZ,0,-1,L7);
                code.visitLabel(L6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,5},new Method("Lorg/mortbay/servlet/GzipFilter$GZIPResponseWrapper;","setContentType",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L4);
                code.visitLabel(L7);
                code.visitConstStmt(CONST_STRING,0,"content-encoding");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,4},new Method("Ljava/lang/String;","equalsIgnoreCase",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_EQZ,0,-1,L11);
                code.visitLabel(L8);
                code.visitMethodStmt(INVOKE_SUPER,new int[]{ 3,4,5},new Method("Ljavax/servlet/http/HttpServletResponseWrapper;","setHeader",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"V"));
                code.visitLabel(L9);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Lorg/mortbay/servlet/GzipFilter$GZIPResponseWrapper;","isCommitted",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_NEZ,0,-1,L4);
                code.visitLabel(L10);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Lorg/mortbay/servlet/GzipFilter$GZIPResponseWrapper;","noGzip",new String[]{ },"V"));
                code.visitJumpStmt(GOTO,-1,-1,L4);
                code.visitLabel(L11);
                code.visitMethodStmt(INVOKE_SUPER,new int[]{ 3,4,5},new Method("Ljavax/servlet/http/HttpServletResponseWrapper;","setHeader",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L4);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m015_setIntHeader(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/servlet/GzipFilter$GZIPResponseWrapper;","setIntHeader",new String[]{ "Ljava/lang/String;","I"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(6);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"name");
                ddv.visitParameterName(1,"value");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(232,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(234,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(235,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(236,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(240,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(239,L5);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_STRING,0,"content-length");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,4},new Method("Ljava/lang/String;","equalsIgnoreCase",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_EQZ,0,-1,L5);
                code.visitLabel(L1);
                code.visitStmt2R(INT_TO_LONG,0,5);
                code.visitFieldStmt(IPUT_WIDE,0,3,new Field("Lorg/mortbay/servlet/GzipFilter$GZIPResponseWrapper;","_contentLength","J"));
                code.visitLabel(L2);
                code.visitFieldStmt(IGET_OBJECT,0,3,new Field("Lorg/mortbay/servlet/GzipFilter$GZIPResponseWrapper;","_gzStream","Lorg/mortbay/servlet/GzipFilter$GzipStream;"));
                code.visitJumpStmt(IF_EQZ,0,-1,L4);
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,0,3,new Field("Lorg/mortbay/servlet/GzipFilter$GZIPResponseWrapper;","_gzStream","Lorg/mortbay/servlet/GzipFilter$GzipStream;"));
                code.visitFieldStmt(IGET_WIDE,1,3,new Field("Lorg/mortbay/servlet/GzipFilter$GZIPResponseWrapper;","_contentLength","J"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1,2},new Method("Lorg/mortbay/servlet/GzipFilter$GzipStream;","setContentLength",new String[]{ "J"},"V"));
                code.visitLabel(L4);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L5);
                code.visitMethodStmt(INVOKE_SUPER,new int[]{ 3,4,5},new Method("Ljavax/servlet/http/HttpServletResponseWrapper;","setIntHeader",new String[]{ "Ljava/lang/String;","I"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L4);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m016_setStatus(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/servlet/GzipFilter$GZIPResponseWrapper;","setStatus",new String[]{ "I"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"sc");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(194,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(195,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(196,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(197,L3);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_SUPER,new int[]{ 1,2},new Method("Ljavax/servlet/http/HttpServletResponseWrapper;","setStatus",new String[]{ "I"},"V"));
                code.visitLabel(L1);
                code.visitConstStmt(CONST_16,0, Integer.valueOf(200)); // int: 0x000000c8  float:0.000000
                code.visitJumpStmt(IF_LT,2,0,L2);
                code.visitConstStmt(CONST_16,0, Integer.valueOf(300)); // int: 0x0000012c  float:0.000000
                code.visitJumpStmt(IF_LT,2,0,L3);
                code.visitLabel(L2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Lorg/mortbay/servlet/GzipFilter$GZIPResponseWrapper;","noGzip",new String[]{ },"V"));
                code.visitLabel(L3);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m017_setStatus(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/servlet/GzipFilter$GZIPResponseWrapper;","setStatus",new String[]{ "I","Ljava/lang/String;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"sc");
                ddv.visitParameterName(1,"sm");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(187,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(188,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(189,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(190,L3);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_SUPER,new int[]{ 1,2,3},new Method("Ljavax/servlet/http/HttpServletResponseWrapper;","setStatus",new String[]{ "I","Ljava/lang/String;"},"V"));
                code.visitLabel(L1);
                code.visitConstStmt(CONST_16,0, Integer.valueOf(200)); // int: 0x000000c8  float:0.000000
                code.visitJumpStmt(IF_LT,2,0,L2);
                code.visitConstStmt(CONST_16,0, Integer.valueOf(300)); // int: 0x0000012c  float:0.000000
                code.visitJumpStmt(IF_LT,2,0,L3);
                code.visitLabel(L2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Lorg/mortbay/servlet/GzipFilter$GZIPResponseWrapper;","noGzip",new String[]{ },"V"));
                code.visitLabel(L3);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
