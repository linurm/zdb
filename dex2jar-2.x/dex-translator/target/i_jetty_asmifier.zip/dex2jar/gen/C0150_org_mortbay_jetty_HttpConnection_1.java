package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0150_org_mortbay_jetty_HttpConnection_1 {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(0,"Lorg/mortbay/jetty/HttpConnection$1;","Ljava/io/PrintWriter;",new String[]{ });
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("HttpConnection.java");
        if(cv!=null){
            DexAnnotationVisitor av00 = cv.visitAnnotation("Ldalvik/annotation/EnclosingMethod;", Visibility.SYSTEM);
            if(av00 != null) {
                av00.visit("value", new Method("Lorg/mortbay/jetty/HttpConnection;","getPrintWriter",new String[]{ "Ljava/lang/String;"},"Ljava/io/PrintWriter;"));
                av00.visitEnd();
            }
        }
        if(cv!=null){
            DexAnnotationVisitor av00 = cv.visitAnnotation("Ldalvik/annotation/InnerClass;", Visibility.SYSTEM);
            if(av00 != null) {
                av00.visit("accessFlags",  Integer.valueOf(0));
                av00.visit("name", null);
                av00.visitEnd();
            }
        }
        f000_this$0(cv);
        m000__init_(cv);
        m001_close(cv);
    }
    public static void f000_this$0(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_FINAL|ACC_SYNTHETIC, new Field("Lorg/mortbay/jetty/HttpConnection$1;","this$0","Lorg/mortbay/jetty/HttpConnection;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void m000__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_CONSTRUCTOR, new Method("Lorg/mortbay/jetty/HttpConnection$1;","<init>",new String[]{ "Lorg/mortbay/jetty/HttpConnection;","Ljava/io/Writer;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(1,"x0");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(345,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_OBJECT,1,0,new Field("Lorg/mortbay/jetty/HttpConnection$1;","this$0","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,2},new Method("Ljava/io/PrintWriter;","<init>",new String[]{ "Ljava/io/Writer;"},"V"));
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001_close(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/HttpConnection$1;","close",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ "Ljava/io/IOException;"});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(349,L0);
                ddv.visitLineNumber(356,L1);
                ddv.visitLineNumber(351,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(353,L3);
                ddv.visitStartLocal(0,L3,"e","Ljava/io/IOException;",null);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(354,L4);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/jetty/HttpConnection$1;","out","Ljava/io/Writer;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/io/Writer;","close",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,1);
                code.visitStmt2R(MOVE_OBJECT,0,1);
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0},new Method("Lorg/mortbay/log/Log;","debug",new String[]{ "Ljava/lang/Throwable;"},"V"));
                code.visitLabel(L4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/jetty/HttpConnection$1;","setError",new String[]{ },"V"));
                code.visitJumpStmt(GOTO,-1,-1,L1);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
