package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0466_org_mortbay_xml_XmlParser_NoopHandler {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(0,"Lorg/mortbay/xml/XmlParser$NoopHandler;","Lorg/xml/sax/helpers/DefaultHandler;",new String[]{ });
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("XmlParser.java");
        if(cv!=null){
            DexAnnotationVisitor av00 = cv.visitAnnotation("Ldalvik/annotation/EnclosingClass;", Visibility.SYSTEM);
            if(av00 != null) {
                av00.visit("value", new DexType("Lorg/mortbay/xml/XmlParser;"));
                av00.visitEnd();
            }
        }
        if(cv!=null){
            DexAnnotationVisitor av00 = cv.visitAnnotation("Ldalvik/annotation/InnerClass;", Visibility.SYSTEM);
            if(av00 != null) {
                av00.visit("accessFlags",  Integer.valueOf(2));
                av00.visit("name", "NoopHandler");
                av00.visitEnd();
            }
        }
        f000__depth(cv);
        f001__next(cv);
        f002_this$0(cv);
        m000__init_(cv);
        m001_endElement(cv);
        m002_startElement(cv);
    }
    public static void f000__depth(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(0, new Field("Lorg/mortbay/xml/XmlParser$NoopHandler;","_depth","I"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f001__next(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(0, new Field("Lorg/mortbay/xml/XmlParser$NoopHandler;","_next","Lorg/mortbay/xml/XmlParser$Handler;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f002_this$0(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_FINAL|ACC_SYNTHETIC, new Field("Lorg/mortbay/xml/XmlParser$NoopHandler;","this$0","Lorg/mortbay/xml/XmlParser;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void m000__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_CONSTRUCTOR, new Method("Lorg/mortbay/xml/XmlParser$NoopHandler;","<init>",new String[]{ "Lorg/mortbay/xml/XmlParser;","Lorg/mortbay/xml/XmlParser$Handler;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(1,"next");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(246,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(247,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(248,L2);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_OBJECT,1,0,new Field("Lorg/mortbay/xml/XmlParser$NoopHandler;","this$0","Lorg/mortbay/xml/XmlParser;"));
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Lorg/xml/sax/helpers/DefaultHandler;","<init>",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitFieldStmt(IPUT_OBJECT,2,0,new Field("Lorg/mortbay/xml/XmlParser$NoopHandler;","_next","Lorg/mortbay/xml/XmlParser$Handler;"));
                code.visitLabel(L2);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001_endElement(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/xml/XmlParser$NoopHandler;","endElement",new String[]{ "Ljava/lang/String;","Ljava/lang/String;","Ljava/lang/String;"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Lorg/xml/sax/SAXException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(6);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"uri");
                ddv.visitParameterName(1,"localName");
                ddv.visitParameterName(2,"qName");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(259,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(260,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(263,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(262,L3);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET,0,2,new Field("Lorg/mortbay/xml/XmlParser$NoopHandler;","_depth","I"));
                code.visitJumpStmt(IF_NEZ,0,-1,L3);
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/xml/XmlParser$NoopHandler;","this$0","Lorg/mortbay/xml/XmlParser;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0},new Method("Lorg/mortbay/xml/XmlParser;","access$000",new String[]{ "Lorg/mortbay/xml/XmlParser;"},"Ljavax/xml/parsers/SAXParser;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljavax/xml/parsers/SAXParser;","getXMLReader",new String[]{ },"Lorg/xml/sax/XMLReader;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/xml/XmlParser$NoopHandler;","_next","Lorg/mortbay/xml/XmlParser$Handler;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,1},new Method("Lorg/xml/sax/XMLReader;","setContentHandler",new String[]{ "Lorg/xml/sax/ContentHandler;"},"V"));
                code.visitLabel(L2);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L3);
                code.visitFieldStmt(IGET,0,2,new Field("Lorg/mortbay/xml/XmlParser$NoopHandler;","_depth","I"));
                code.visitConstStmt(CONST_4,1, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitStmt2R(SUB_INT_2ADDR,0,1);
                code.visitFieldStmt(IPUT,0,2,new Field("Lorg/mortbay/xml/XmlParser$NoopHandler;","_depth","I"));
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m002_startElement(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/xml/XmlParser$NoopHandler;","startElement",new String[]{ "Ljava/lang/String;","Ljava/lang/String;","Ljava/lang/String;","Lorg/xml/sax/Attributes;"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Lorg/xml/sax/SAXException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(6);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"uri");
                ddv.visitParameterName(1,"localName");
                ddv.visitParameterName(2,"qName");
                ddv.visitParameterName(3,"attrs");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(253,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(254,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET,0,1,new Field("Lorg/mortbay/xml/XmlParser$NoopHandler;","_depth","I"));
                code.visitStmt2R1N(ADD_INT_LIT8,0,0,1);
                code.visitFieldStmt(IPUT,0,1,new Field("Lorg/mortbay/xml/XmlParser$NoopHandler;","_depth","I"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
