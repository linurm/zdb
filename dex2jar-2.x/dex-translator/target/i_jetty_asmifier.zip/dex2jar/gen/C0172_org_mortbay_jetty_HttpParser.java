package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0172_org_mortbay_jetty_HttpParser {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(ACC_PUBLIC,"Lorg/mortbay/jetty/HttpParser;","Ljava/lang/Object;",new String[]{ "Lorg/mortbay/jetty/Parser;"});
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("HttpParser.java");
        if(cv!=null){
            DexAnnotationVisitor av00 = cv.visitAnnotation("Ldalvik/annotation/MemberClasses;", Visibility.SYSTEM);
            if(av00 != null) {
                {
                    DexAnnotationVisitor av01 = av00.visitArray("value");
                    if(av01 != null) {
                        av01.visit(null, new DexType("Lorg/mortbay/jetty/HttpParser$Input;"));
                        av01.visit(null, new DexType("Lorg/mortbay/jetty/HttpParser$EventHandler;"));
                        av01.visitEnd();
                    }
                }
                av00.visitEnd();
            }
        }
        f000_STATE_CHUNK(cv);
        f001_STATE_CHUNKED_CONTENT(cv);
        f002_STATE_CHUNK_PARAMS(cv);
        f003_STATE_CHUNK_SIZE(cv);
        f004_STATE_CONTENT(cv);
        f005_STATE_END(cv);
        f006_STATE_END0(cv);
        f007_STATE_END1(cv);
        f008_STATE_EOF_CONTENT(cv);
        f009_STATE_FIELD0(cv);
        f010_STATE_FIELD1(cv);
        f011_STATE_FIELD2(cv);
        f012_STATE_HEADER(cv);
        f013_STATE_HEADER_IN_NAME(cv);
        f014_STATE_HEADER_IN_VALUE(cv);
        f015_STATE_HEADER_NAME(cv);
        f016_STATE_HEADER_VALUE(cv);
        f017_STATE_SPACE1(cv);
        f018_STATE_SPACE2(cv);
        f019_STATE_START(cv);
        f020__body(cv);
        f021__buffer(cv);
        f022__buffers(cv);
        f023__cached(cv);
        f024__chunkLength(cv);
        f025__chunkPosition(cv);
        f026__contentBufferSize(cv);
        f027__contentLength(cv);
        f028__contentPosition(cv);
        f029__contentView(cv);
        f030__endp(cv);
        f031__eol(cv);
        f032__forceContentBuffer(cv);
        f033__handler(cv);
        f034__header(cv);
        f035__headerBufferSize(cv);
        f036__input(cv);
        f037__length(cv);
        f038__multiLineValue(cv);
        f039__responseStatus(cv);
        f040__state(cv);
        f041__tok0(cv);
        f042__tok1(cv);
        m000__init_(cv);
        m001__init_(cv);
        m002_access$000(cv);
        m003_access$100(cv);
        m004_access$202(cv);
        m005_fill(cv);
        m006_getBodyBuffer(cv);
        m007_getContentLength(cv);
        m008_getContentRead(cv);
        m009_getHeaderBuffer(cv);
        m010_getState(cv);
        m011_inContentState(cv);
        m012_inHeaderState(cv);
        m013_isChunking(cv);
        m014_isComplete(cv);
        m015_isIdle(cv);
        m016_isMoreInBuffer(cv);
        m017_isState(cv);
        m018_parse(cv);
        m019_parseAvailable(cv);
        m020_parseNext(cv);
        m021_reset(cv);
        m022_setForceContentBuffer(cv);
        m023_setState(cv);
        m024_skipCRLF(cv);
        m025_toString(cv);
        m026_toString(cv);
    }
    public static void f000_STATE_CHUNK(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpParser;","STATE_CHUNK","I"),  Integer.valueOf(6));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f001_STATE_CHUNKED_CONTENT(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpParser;","STATE_CHUNKED_CONTENT","I"),  Integer.valueOf(3));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f002_STATE_CHUNK_PARAMS(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpParser;","STATE_CHUNK_PARAMS","I"),  Integer.valueOf(5));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f003_STATE_CHUNK_SIZE(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpParser;","STATE_CHUNK_SIZE","I"),  Integer.valueOf(4));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f004_STATE_CONTENT(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpParser;","STATE_CONTENT","I"),  Integer.valueOf(2));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f005_STATE_END(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpParser;","STATE_END","I"),  Integer.valueOf(0));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f006_STATE_END0(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpParser;","STATE_END0","I"),  Integer.valueOf(-8));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f007_STATE_END1(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpParser;","STATE_END1","I"),  Integer.valueOf(-7));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f008_STATE_EOF_CONTENT(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpParser;","STATE_EOF_CONTENT","I"),  Integer.valueOf(1));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f009_STATE_FIELD0(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpParser;","STATE_FIELD0","I"),  Integer.valueOf(-12));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f010_STATE_FIELD1(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpParser;","STATE_FIELD1","I"),  Integer.valueOf(-10));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f011_STATE_FIELD2(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpParser;","STATE_FIELD2","I"),  Integer.valueOf(-6));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f012_STATE_HEADER(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpParser;","STATE_HEADER","I"),  Integer.valueOf(-5));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f013_STATE_HEADER_IN_NAME(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpParser;","STATE_HEADER_IN_NAME","I"),  Integer.valueOf(-3));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f014_STATE_HEADER_IN_VALUE(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpParser;","STATE_HEADER_IN_VALUE","I"),  Integer.valueOf(-1));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f015_STATE_HEADER_NAME(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpParser;","STATE_HEADER_NAME","I"),  Integer.valueOf(-4));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f016_STATE_HEADER_VALUE(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpParser;","STATE_HEADER_VALUE","I"),  Integer.valueOf(-2));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f017_STATE_SPACE1(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpParser;","STATE_SPACE1","I"),  Integer.valueOf(-11));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f018_STATE_SPACE2(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpParser;","STATE_SPACE2","I"),  Integer.valueOf(-9));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f019_STATE_START(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/HttpParser;","STATE_START","I"),  Integer.valueOf(-13));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f020__body(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/HttpParser;","_body","Lorg/mortbay/io/Buffer;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f021__buffer(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/HttpParser;","_buffer","Lorg/mortbay/io/Buffer;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f022__buffers(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/HttpParser;","_buffers","Lorg/mortbay/io/Buffers;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f023__cached(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/HttpParser;","_cached","Lorg/mortbay/io/BufferCache$CachedBuffer;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f024__chunkLength(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PROTECTED, new Field("Lorg/mortbay/jetty/HttpParser;","_chunkLength","I"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f025__chunkPosition(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PROTECTED, new Field("Lorg/mortbay/jetty/HttpParser;","_chunkPosition","I"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f026__contentBufferSize(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/HttpParser;","_contentBufferSize","I"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f027__contentLength(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PROTECTED, new Field("Lorg/mortbay/jetty/HttpParser;","_contentLength","J"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f028__contentPosition(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PROTECTED, new Field("Lorg/mortbay/jetty/HttpParser;","_contentPosition","J"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f029__contentView(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/HttpParser;","_contentView","Lorg/mortbay/io/View;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f030__endp(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/HttpParser;","_endp","Lorg/mortbay/io/EndPoint;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f031__eol(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PROTECTED, new Field("Lorg/mortbay/jetty/HttpParser;","_eol","B"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f032__forceContentBuffer(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/HttpParser;","_forceContentBuffer","Z"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f033__handler(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/HttpParser;","_handler","Lorg/mortbay/jetty/HttpParser$EventHandler;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f034__header(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/HttpParser;","_header","Lorg/mortbay/io/Buffer;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f035__headerBufferSize(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/HttpParser;","_headerBufferSize","I"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f036__input(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/HttpParser;","_input","Lorg/mortbay/jetty/HttpParser$Input;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f037__length(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PROTECTED, new Field("Lorg/mortbay/jetty/HttpParser;","_length","I"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f038__multiLineValue(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/HttpParser;","_multiLineValue","Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f039__responseStatus(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/HttpParser;","_responseStatus","I"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f040__state(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PROTECTED, new Field("Lorg/mortbay/jetty/HttpParser;","_state","I"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f041__tok0(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/HttpParser;","_tok0","Lorg/mortbay/io/View$CaseInsensitive;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f042__tok1(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/HttpParser;","_tok1","Lorg/mortbay/io/View$CaseInsensitive;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void m000__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/jetty/HttpParser;","<init>",new String[]{ "Lorg/mortbay/io/Buffer;","Lorg/mortbay/jetty/HttpParser$EventHandler;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"buffer");
                ddv.visitParameterName(1,"handler");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(91,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(64,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(78,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(92,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(93,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(94,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(96,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(98,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(99,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(100,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(101,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(103,L11);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2},new Method("Ljava/lang/Object;","<init>",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Lorg/mortbay/io/View;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Lorg/mortbay/io/View;","<init>",new String[]{ },"V"));
                code.visitFieldStmt(IPUT_OBJECT,0,2,new Field("Lorg/mortbay/jetty/HttpParser;","_contentView","Lorg/mortbay/io/View;"));
                code.visitLabel(L2);
                code.visitConstStmt(CONST_16,0, Integer.valueOf(-13)); // int: 0xfffffff3  float:NaN
                code.visitFieldStmt(IPUT,0,2,new Field("Lorg/mortbay/jetty/HttpParser;","_state","I"));
                code.visitLabel(L3);
                code.visitFieldStmt(IPUT_OBJECT,3,2,new Field("Lorg/mortbay/jetty/HttpParser;","_header","Lorg/mortbay/io/Buffer;"));
                code.visitLabel(L4);
                code.visitFieldStmt(IPUT_OBJECT,3,2,new Field("Lorg/mortbay/jetty/HttpParser;","_buffer","Lorg/mortbay/io/Buffer;"));
                code.visitLabel(L5);
                code.visitFieldStmt(IPUT_OBJECT,4,2,new Field("Lorg/mortbay/jetty/HttpParser;","_handler","Lorg/mortbay/jetty/HttpParser$EventHandler;"));
                code.visitLabel(L6);
                code.visitJumpStmt(IF_EQZ,3,-1,L11);
                code.visitLabel(L7);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Lorg/mortbay/io/View$CaseInsensitive;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,3},new Method("Lorg/mortbay/io/View$CaseInsensitive;","<init>",new String[]{ "Lorg/mortbay/io/Buffer;"},"V"));
                code.visitFieldStmt(IPUT_OBJECT,0,2,new Field("Lorg/mortbay/jetty/HttpParser;","_tok0","Lorg/mortbay/io/View$CaseInsensitive;"));
                code.visitLabel(L8);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Lorg/mortbay/io/View$CaseInsensitive;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,3},new Method("Lorg/mortbay/io/View$CaseInsensitive;","<init>",new String[]{ "Lorg/mortbay/io/Buffer;"},"V"));
                code.visitFieldStmt(IPUT_OBJECT,0,2,new Field("Lorg/mortbay/jetty/HttpParser;","_tok1","Lorg/mortbay/io/View$CaseInsensitive;"));
                code.visitLabel(L9);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/jetty/HttpParser;","_tok0","Lorg/mortbay/io/View$CaseInsensitive;"));
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/jetty/HttpParser;","_tok0","Lorg/mortbay/io/View$CaseInsensitive;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Lorg/mortbay/io/View$CaseInsensitive;","getIndex",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Lorg/mortbay/io/View$CaseInsensitive;","setPutIndex",new String[]{ "I"},"V"));
                code.visitLabel(L10);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/jetty/HttpParser;","_tok1","Lorg/mortbay/io/View$CaseInsensitive;"));
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/jetty/HttpParser;","_tok1","Lorg/mortbay/io/View$CaseInsensitive;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Lorg/mortbay/io/View$CaseInsensitive;","getIndex",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Lorg/mortbay/io/View$CaseInsensitive;","setPutIndex",new String[]{ "I"},"V"));
                code.visitLabel(L11);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/jetty/HttpParser;","<init>",new String[]{ "Lorg/mortbay/io/Buffers;","Lorg/mortbay/io/EndPoint;","Lorg/mortbay/jetty/HttpParser$EventHandler;","I","I"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(7);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"buffers");
                ddv.visitParameterName(1,"endp");
                ddv.visitParameterName(2,"handler");
                ddv.visitParameterName(3,"headerBufferSize");
                ddv.visitParameterName(4,"contentBufferSize");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(112,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(64,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(78,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(113,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(114,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(115,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(116,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(117,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(118,L8);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1},new Method("Ljava/lang/Object;","<init>",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Lorg/mortbay/io/View;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Lorg/mortbay/io/View;","<init>",new String[]{ },"V"));
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/jetty/HttpParser;","_contentView","Lorg/mortbay/io/View;"));
                code.visitLabel(L2);
                code.visitConstStmt(CONST_16,0, Integer.valueOf(-13)); // int: 0xfffffff3  float:NaN
                code.visitFieldStmt(IPUT,0,1,new Field("Lorg/mortbay/jetty/HttpParser;","_state","I"));
                code.visitLabel(L3);
                code.visitFieldStmt(IPUT_OBJECT,2,1,new Field("Lorg/mortbay/jetty/HttpParser;","_buffers","Lorg/mortbay/io/Buffers;"));
                code.visitLabel(L4);
                code.visitFieldStmt(IPUT_OBJECT,3,1,new Field("Lorg/mortbay/jetty/HttpParser;","_endp","Lorg/mortbay/io/EndPoint;"));
                code.visitLabel(L5);
                code.visitFieldStmt(IPUT_OBJECT,4,1,new Field("Lorg/mortbay/jetty/HttpParser;","_handler","Lorg/mortbay/jetty/HttpParser$EventHandler;"));
                code.visitLabel(L6);
                code.visitFieldStmt(IPUT,5,1,new Field("Lorg/mortbay/jetty/HttpParser;","_headerBufferSize","I"));
                code.visitLabel(L7);
                code.visitFieldStmt(IPUT,6,1,new Field("Lorg/mortbay/jetty/HttpParser;","_contentBufferSize","I"));
                code.visitLabel(L8);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m002_access$000(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_STATIC|ACC_SYNTHETIC, new Method("Lorg/mortbay/jetty/HttpParser;","access$000",new String[]{ "Lorg/mortbay/jetty/HttpParser;"},"Lorg/mortbay/io/EndPoint;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"x0");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(35,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/HttpParser;","_endp","Lorg/mortbay/io/EndPoint;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m003_access$100(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_STATIC|ACC_SYNTHETIC, new Method("Lorg/mortbay/jetty/HttpParser;","access$100",new String[]{ "Lorg/mortbay/jetty/HttpParser;"},"Lorg/mortbay/io/View;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"x0");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(35,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/HttpParser;","_contentView","Lorg/mortbay/io/View;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m004_access$202(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_STATIC|ACC_SYNTHETIC, new Method("Lorg/mortbay/jetty/HttpParser;","access$202",new String[]{ "Lorg/mortbay/jetty/HttpParser;","Lorg/mortbay/jetty/HttpParser$Input;"},"Lorg/mortbay/jetty/HttpParser$Input;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"x0");
                ddv.visitParameterName(1,"x1");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(35,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_OBJECT,1,0,new Field("Lorg/mortbay/jetty/HttpParser;","_input","Lorg/mortbay/jetty/HttpParser$Input;"));
                code.visitStmt1R(RETURN_OBJECT,1);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m005_fill(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/HttpParser;","fill",new String[]{ },"J"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(9);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ "Ljava/io/IOException;"});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L3=new DexLabel();
                ddv.visitPrologue(L3);
                ddv.visitLineNumber(851,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(853,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(854,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(855,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(857,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(858,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(859,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(860,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(862,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(865,L12);
                ddv.visitStartLocal(2,L12,"space","I",null);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(866,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(869,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(871,L15);
                ddv.visitStartLocal(1,L15,"filled","I",null);
                ddv.visitLineNumber(875,L0);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(885,L16);
                ddv.visitLineNumber(877,L2);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(879,L17);
                ddv.visitStartLocal(0,L17,"e","Ljava/io/IOException;",null);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(880,L18);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(881,L19);
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,3,8,new Field("Lorg/mortbay/jetty/HttpParser;","_buffer","Lorg/mortbay/io/Buffer;"));
                code.visitJumpStmt(IF_NEZ,3,-1,L7);
                code.visitLabel(L4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8},new Method("Lorg/mortbay/jetty/HttpParser;","getHeaderBuffer",new String[]{ },"Lorg/mortbay/io/Buffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitFieldStmt(IPUT_OBJECT,3,8,new Field("Lorg/mortbay/jetty/HttpParser;","_header","Lorg/mortbay/io/Buffer;"));
                code.visitFieldStmt(IPUT_OBJECT,3,8,new Field("Lorg/mortbay/jetty/HttpParser;","_buffer","Lorg/mortbay/io/Buffer;"));
                code.visitLabel(L5);
                code.visitTypeStmt(NEW_INSTANCE,3,-1,"Lorg/mortbay/io/View$CaseInsensitive;");
                code.visitFieldStmt(IGET_OBJECT,4,8,new Field("Lorg/mortbay/jetty/HttpParser;","_buffer","Lorg/mortbay/io/Buffer;"));
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 3,4},new Method("Lorg/mortbay/io/View$CaseInsensitive;","<init>",new String[]{ "Lorg/mortbay/io/Buffer;"},"V"));
                code.visitFieldStmt(IPUT_OBJECT,3,8,new Field("Lorg/mortbay/jetty/HttpParser;","_tok0","Lorg/mortbay/io/View$CaseInsensitive;"));
                code.visitLabel(L6);
                code.visitTypeStmt(NEW_INSTANCE,3,-1,"Lorg/mortbay/io/View$CaseInsensitive;");
                code.visitFieldStmt(IGET_OBJECT,4,8,new Field("Lorg/mortbay/jetty/HttpParser;","_buffer","Lorg/mortbay/io/Buffer;"));
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 3,4},new Method("Lorg/mortbay/io/View$CaseInsensitive;","<init>",new String[]{ "Lorg/mortbay/io/Buffer;"},"V"));
                code.visitFieldStmt(IPUT_OBJECT,3,8,new Field("Lorg/mortbay/jetty/HttpParser;","_tok1","Lorg/mortbay/io/View$CaseInsensitive;"));
                code.visitLabel(L7);
                code.visitFieldStmt(IGET_OBJECT,3,8,new Field("Lorg/mortbay/jetty/HttpParser;","_body","Lorg/mortbay/io/Buffer;"));
                code.visitJumpStmt(IF_EQZ,3,-1,L9);
                code.visitFieldStmt(IGET_OBJECT,3,8,new Field("Lorg/mortbay/jetty/HttpParser;","_buffer","Lorg/mortbay/io/Buffer;"));
                code.visitFieldStmt(IGET_OBJECT,4,8,new Field("Lorg/mortbay/jetty/HttpParser;","_body","Lorg/mortbay/io/Buffer;"));
                code.visitJumpStmt(IF_EQ,3,4,L9);
                code.visitLabel(L8);
                code.visitFieldStmt(IGET_OBJECT,3,8,new Field("Lorg/mortbay/jetty/HttpParser;","_body","Lorg/mortbay/io/Buffer;"));
                code.visitFieldStmt(IPUT_OBJECT,3,8,new Field("Lorg/mortbay/jetty/HttpParser;","_buffer","Lorg/mortbay/io/Buffer;"));
                code.visitLabel(L9);
                code.visitFieldStmt(IGET_OBJECT,3,8,new Field("Lorg/mortbay/jetty/HttpParser;","_buffer","Lorg/mortbay/io/Buffer;"));
                code.visitFieldStmt(IGET_OBJECT,4,8,new Field("Lorg/mortbay/jetty/HttpParser;","_body","Lorg/mortbay/io/Buffer;"));
                code.visitJumpStmt(IF_NE,3,4,L11);
                code.visitLabel(L10);
                code.visitFieldStmt(IGET_OBJECT,3,8,new Field("Lorg/mortbay/jetty/HttpParser;","_buffer","Lorg/mortbay/io/Buffer;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 3},new Method("Lorg/mortbay/io/Buffer;","compact",new String[]{ },"V"));
                code.visitLabel(L11);
                code.visitFieldStmt(IGET_OBJECT,3,8,new Field("Lorg/mortbay/jetty/HttpParser;","_buffer","Lorg/mortbay/io/Buffer;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 3},new Method("Lorg/mortbay/io/Buffer;","space",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitLabel(L12);
                code.visitJumpStmt(IF_NEZ,2,-1,L14);
                code.visitLabel(L13);
                code.visitTypeStmt(NEW_INSTANCE,3,-1,"Lorg/mortbay/jetty/HttpException;");
                code.visitConstStmt(CONST_16,4, Integer.valueOf(413)); // int: 0x0000019d  float:0.000000
                code.visitTypeStmt(NEW_INSTANCE,5,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 5},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,6,"FULL ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,6},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitFieldStmt(IGET_OBJECT,6,8,new Field("Lorg/mortbay/jetty/HttpParser;","_buffer","Lorg/mortbay/io/Buffer;"));
                code.visitFieldStmt(IGET_OBJECT,7,8,new Field("Lorg/mortbay/jetty/HttpParser;","_body","Lorg/mortbay/io/Buffer;"));
                DexLabel L20=new DexLabel();
                code.visitJumpStmt(IF_NE,6,7,L20);
                code.visitConstStmt(CONST_STRING,6,"body");
                DexLabel L21=new DexLabel();
                code.visitLabel(L21);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,6},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 3,4,5},new Method("Lorg/mortbay/jetty/HttpException;","<init>",new String[]{ "I","Ljava/lang/String;"},"V"));
                code.visitStmt1R(THROW,3);
                code.visitLabel(L20);
                code.visitConstStmt(CONST_STRING,6,"head");
                code.visitJumpStmt(GOTO,-1,-1,L21);
                code.visitLabel(L14);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(-1)); // int: 0xffffffff  float:NaN
                code.visitLabel(L15);
                code.visitFieldStmt(IGET_OBJECT,3,8,new Field("Lorg/mortbay/jetty/HttpParser;","_endp","Lorg/mortbay/io/EndPoint;"));
                code.visitJumpStmt(IF_EQZ,3,-1,L16);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,3,8,new Field("Lorg/mortbay/jetty/HttpParser;","_endp","Lorg/mortbay/io/EndPoint;"));
                code.visitFieldStmt(IGET_OBJECT,4,8,new Field("Lorg/mortbay/jetty/HttpParser;","_buffer","Lorg/mortbay/io/Buffer;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 3,4},new Method("Lorg/mortbay/io/EndPoint;","fill",new String[]{ "Lorg/mortbay/io/Buffer;"},"I"));
                code.visitLabel(L1);
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitLabel(L16);
                code.visitStmt2R(INT_TO_LONG,3,1);
                code.visitStmt1R(RETURN_WIDE,3);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,3);
                code.visitStmt2R(MOVE_OBJECT,0,3);
                code.visitLabel(L17);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0},new Method("Lorg/mortbay/log/Log;","debug",new String[]{ "Ljava/lang/Throwable;"},"V"));
                code.visitLabel(L18);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8,3},new Method("Lorg/mortbay/jetty/HttpParser;","reset",new String[]{ "Z"},"V"));
                code.visitLabel(L19);
                code.visitTypeStmt(INSTANCE_OF,3,0,"Lorg/mortbay/jetty/EofException;");
                DexLabel L22=new DexLabel();
                code.visitJumpStmt(IF_EQZ,3,-1,L22);
                code.visitStmt2R(MOVE_OBJECT,3,0);
                DexLabel L23=new DexLabel();
                code.visitLabel(L23);
                code.visitStmt1R(THROW,3);
                code.visitLabel(L22);
                code.visitTypeStmt(NEW_INSTANCE,3,-1,"Lorg/mortbay/jetty/EofException;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 3,0},new Method("Lorg/mortbay/jetty/EofException;","<init>",new String[]{ "Ljava/lang/Throwable;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L23);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m006_getBodyBuffer(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/HttpParser;","getBodyBuffer",new String[]{ },"Lorg/mortbay/io/Buffer;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(1021,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/HttpParser;","_body","Lorg/mortbay/io/Buffer;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m007_getContentLength(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/HttpParser;","getContentLength",new String[]{ },"J"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(123,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_WIDE,0,2,new Field("Lorg/mortbay/jetty/HttpParser;","_contentLength","J"));
                code.visitStmt1R(RETURN_WIDE,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m008_getContentRead(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/HttpParser;","getContentRead",new String[]{ },"J"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(128,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_WIDE,0,2,new Field("Lorg/mortbay/jetty/HttpParser;","_contentPosition","J"));
                code.visitStmt1R(RETURN_WIDE,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m009_getHeaderBuffer(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/HttpParser;","getHeaderBuffer",new String[]{ },"Lorg/mortbay/io/Buffer;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(1011,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(1013,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(1015,L2);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/jetty/HttpParser;","_header","Lorg/mortbay/io/Buffer;"));
                code.visitJumpStmt(IF_NEZ,0,-1,L2);
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/jetty/HttpParser;","_buffers","Lorg/mortbay/io/Buffers;"));
                code.visitFieldStmt(IGET,1,2,new Field("Lorg/mortbay/jetty/HttpParser;","_headerBufferSize","I"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,1},new Method("Lorg/mortbay/io/Buffers;","getBuffer",new String[]{ "I"},"Lorg/mortbay/io/Buffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(IPUT_OBJECT,0,2,new Field("Lorg/mortbay/jetty/HttpParser;","_header","Lorg/mortbay/io/Buffer;"));
                code.visitLabel(L2);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/jetty/HttpParser;","_header","Lorg/mortbay/io/Buffer;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m010_getState(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/HttpParser;","getState",new String[]{ },"I"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(134,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET,0,1,new Field("Lorg/mortbay/jetty/HttpParser;","_state","I"));
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m011_inContentState(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/HttpParser;","inContentState",new String[]{ },"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(140,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET,0,1,new Field("Lorg/mortbay/jetty/HttpParser;","_state","I"));
                DexLabel L1=new DexLabel();
                code.visitJumpStmt(IF_LEZ,0,-1,L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                DexLabel L2=new DexLabel();
                code.visitLabel(L2);
                code.visitStmt1R(RETURN,0);
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m012_inHeaderState(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/HttpParser;","inHeaderState",new String[]{ },"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(146,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET,0,1,new Field("Lorg/mortbay/jetty/HttpParser;","_state","I"));
                DexLabel L1=new DexLabel();
                code.visitJumpStmt(IF_GEZ,0,-1,L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                DexLabel L2=new DexLabel();
                code.visitLabel(L2);
                code.visitStmt1R(RETURN,0);
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m013_isChunking(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/HttpParser;","isChunking",new String[]{ },"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(152,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_WIDE,0,4,new Field("Lorg/mortbay/jetty/HttpParser;","_contentLength","J"));
                code.visitConstStmt(CONST_WIDE_16,2,Long.valueOf(-2L)); // long: 0xfffffffffffffffe  double:NaN
                code.visitStmt3R(CMP_LONG,0,0,2);
                DexLabel L1=new DexLabel();
                code.visitJumpStmt(IF_NEZ,0,-1,L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                DexLabel L2=new DexLabel();
                code.visitLabel(L2);
                code.visitStmt1R(RETURN,0);
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m014_isComplete(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/HttpParser;","isComplete",new String[]{ },"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(164,L0);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,0},new Method("Lorg/mortbay/jetty/HttpParser;","isState",new String[]{ "I"},"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m015_isIdle(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/HttpParser;","isIdle",new String[]{ },"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(158,L0);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_16,0, Integer.valueOf(-13)); // int: 0xfffffff3  float:NaN
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,0},new Method("Lorg/mortbay/jetty/HttpParser;","isState",new String[]{ "I"},"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m016_isMoreInBuffer(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/HttpParser;","isMoreInBuffer",new String[]{ },"Z"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(171,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(173,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(175,L2);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/HttpParser;","_header","Lorg/mortbay/io/Buffer;"));
                DexLabel L3=new DexLabel();
                code.visitJumpStmt(IF_EQZ,0,-1,L3);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/HttpParser;","_header","Lorg/mortbay/io/Buffer;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0},new Method("Lorg/mortbay/io/Buffer;","hasContent",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_NEZ,0,-1,L1);
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/HttpParser;","_body","Lorg/mortbay/io/Buffer;"));
                DexLabel L4=new DexLabel();
                code.visitJumpStmt(IF_EQZ,0,-1,L4);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/HttpParser;","_body","Lorg/mortbay/io/Buffer;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0},new Method("Lorg/mortbay/io/Buffer;","hasContent",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_EQZ,0,-1,L4);
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitLabel(L2);
                code.visitStmt1R(RETURN,0);
                code.visitLabel(L4);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m017_isState(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/HttpParser;","isState",new String[]{ "I"},"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"state");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(181,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET,0,1,new Field("Lorg/mortbay/jetty/HttpParser;","_state","I"));
                DexLabel L1=new DexLabel();
                code.visitJumpStmt(IF_NE,0,2,L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                DexLabel L2=new DexLabel();
                code.visitLabel(L2);
                code.visitStmt1R(RETURN,0);
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m018_parse(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/HttpParser;","parse",new String[]{ },"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(192,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(193,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(194,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(195,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(198,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(199,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(200,L6);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET,0,2,new Field("Lorg/mortbay/jetty/HttpParser;","_state","I"));
                code.visitJumpStmt(IF_NEZ,0,-1,L2);
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,0},new Method("Lorg/mortbay/jetty/HttpParser;","reset",new String[]{ "Z"},"V"));
                code.visitLabel(L2);
                code.visitFieldStmt(IGET,0,2,new Field("Lorg/mortbay/jetty/HttpParser;","_state","I"));
                code.visitConstStmt(CONST_16,1, Integer.valueOf(-13)); // int: 0xfffffff3  float:NaN
                code.visitJumpStmt(IF_EQ,0,1,L4);
                code.visitLabel(L3);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/lang/IllegalStateException;");
                code.visitConstStmt(CONST_STRING,1,"!START");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1},new Method("Ljava/lang/IllegalStateException;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitStmt1R(THROW,0);
                code.visitLabel(L4);
                code.visitFieldStmt(IGET,0,2,new Field("Lorg/mortbay/jetty/HttpParser;","_state","I"));
                code.visitJumpStmt(IF_EQZ,0,-1,L6);
                code.visitLabel(L5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/jetty/HttpParser;","parseNext",new String[]{ },"J"));
                code.visitJumpStmt(GOTO,-1,-1,L4);
                code.visitLabel(L6);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m019_parseAvailable(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/HttpParser;","parseAvailable",new String[]{ },"J"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(8);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(212,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(213,L2);
                ddv.visitStartLocal(0,L2,"len","J",null);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(216,L3);
                ddv.visitStartLocal(2,L3,"total","J",null);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(218,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(219,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(220,L6);
                DexLabel L7=new DexLabel();
                ddv.visitEndLocal(2,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(213,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(222,L9);
                ddv.visitRestartLocal(2,L9);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_WIDE_16,5,Long.valueOf(0L)); // long: 0x0000000000000000  double:0.000000
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7},new Method("Lorg/mortbay/jetty/HttpParser;","parseNext",new String[]{ },"J"));
                code.visitStmt1R(MOVE_RESULT_WIDE,0);
                code.visitLabel(L2);
                code.visitStmt3R(CMP_LONG,4,0,5);
                code.visitJumpStmt(IF_LEZ,4,-1,L7);
                code.visitStmt2R(MOVE_WIDE,2,0);
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7},new Method("Lorg/mortbay/jetty/HttpParser;","isComplete",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,4);
                code.visitJumpStmt(IF_NEZ,4,-1,L9);
                code.visitFieldStmt(IGET_OBJECT,4,7,new Field("Lorg/mortbay/jetty/HttpParser;","_buffer","Lorg/mortbay/io/Buffer;"));
                code.visitJumpStmt(IF_EQZ,4,-1,L9);
                code.visitFieldStmt(IGET_OBJECT,4,7,new Field("Lorg/mortbay/jetty/HttpParser;","_buffer","Lorg/mortbay/io/Buffer;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 4},new Method("Lorg/mortbay/io/Buffer;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,4);
                code.visitJumpStmt(IF_LEZ,4,-1,L9);
                code.visitLabel(L4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7},new Method("Lorg/mortbay/jetty/HttpParser;","parseNext",new String[]{ },"J"));
                code.visitStmt1R(MOVE_RESULT_WIDE,0);
                code.visitLabel(L5);
                code.visitStmt3R(CMP_LONG,4,0,5);
                code.visitJumpStmt(IF_LEZ,4,-1,L3);
                code.visitLabel(L6);
                code.visitStmt2R(ADD_LONG_2ADDR,2,0);
                code.visitJumpStmt(GOTO,-1,-1,L3);
                code.visitLabel(L7);
                code.visitStmt2R(MOVE_WIDE,2,5);
                code.visitLabel(L8);
                code.visitJumpStmt(GOTO,-1,-1,L3);
                code.visitLabel(L9);
                code.visitStmt1R(RETURN_WIDE,2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m020_parseNext(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/HttpParser;","parseNext",new String[]{ },"J"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(28);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ "Ljava/io/IOException;"});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L3=new DexLabel();
                ddv.visitPrologue(L3);
                ddv.visitLineNumber(234,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(236,L4);
                ddv.visitStartLocal(18,L4,"total_filled","J",null);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(237,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(842,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(239,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(241,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(243,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(245,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(246,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(247,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(248,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(249,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(253,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(255,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(256,L17);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(257,L18);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(260,L19);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(263,L20);
                ddv.visitStartLocal(13,L20,"length","I",null);
                DexLabel L21=new DexLabel();
                ddv.visitLineNumber(265,L21);
                DexLabel L22=new DexLabel();
                ddv.visitLineNumber(266,L22);
                ddv.visitStartLocal(9,L22,"filled","I",null);
                DexLabel L23=new DexLabel();
                ddv.visitLineNumber(268,L23);
                DexLabel L24=new DexLabel();
                ddv.visitLineNumber(269,L24);
                DexLabel L25=new DexLabel();
                ddv.visitLineNumber(272,L25);
                DexLabel L26=new DexLabel();
                ddv.visitLineNumber(273,L26);
                DexLabel L27=new DexLabel();
                ddv.visitLineNumber(275,L27);
                DexLabel L28=new DexLabel();
                ddv.visitLineNumber(277,L28);
                ddv.visitStartLocal(12,L28,"ioex","Ljava/io/IOException;",null);
                DexLabel L29=new DexLabel();
                ddv.visitLineNumber(281,L29);
                DexLabel L30=new DexLabel();
                ddv.visitLineNumber(282,L30);
                DexLabel L31=new DexLabel();
                ddv.visitLineNumber(284,L31);
                DexLabel L32=new DexLabel();
                ddv.visitLineNumber(285,L32);
                DexLabel L33=new DexLabel();
                ddv.visitLineNumber(288,L33);
                DexLabel L34=new DexLabel();
                ddv.visitLineNumber(289,L34);
                ddv.visitLineNumber(290,L0);
                DexLabel L35=new DexLabel();
                ddv.visitLineNumber(291,L35);
                ddv.visitRestartLocal(9,L35);
                DexLabel L36=new DexLabel();
                ddv.visitLineNumber(292,L36);
                DexLabel L37=new DexLabel();
                ddv.visitLineNumber(302,L37);
                DexLabel L38=new DexLabel();
                ddv.visitLineNumber(304,L38);
                DexLabel L39=new DexLabel();
                ddv.visitLineNumber(306,L39);
                DexLabel L40=new DexLabel();
                ddv.visitLineNumber(309,L40);
                DexLabel L41=new DexLabel();
                ddv.visitLineNumber(310,L41);
                ddv.visitStartLocal(7,L41,"chunk","Lorg/mortbay/io/Buffer;",null);
                DexLabel L42=new DexLabel();
                ddv.visitLineNumber(311,L42);
                DexLabel L43=new DexLabel();
                ddv.visitLineNumber(312,L43);
                DexLabel L44=new DexLabel();
                ddv.visitLineNumber(314,L44);
                ddv.visitEndLocal(7,L44);
                DexLabel L45=new DexLabel();
                ddv.visitLineNumber(315,L45);
                DexLabel L46=new DexLabel();
                ddv.visitLineNumber(316,L46);
                ddv.visitLineNumber(294,L2);
                DexLabel L47=new DexLabel();
                ddv.visitLineNumber(296,L47);
                ddv.visitStartLocal(8,L47,"e","Ljava/io/IOException;",null);
                DexLabel L48=new DexLabel();
                ddv.visitLineNumber(297,L48);
                DexLabel L49=new DexLabel();
                ddv.visitLineNumber(298,L49);
                DexLabel L50=new DexLabel();
                ddv.visitLineNumber(318,L50);
                ddv.visitEndLocal(8,L50);
                DexLabel L51=new DexLabel();
                ddv.visitLineNumber(319,L51);
                DexLabel L52=new DexLabel();
                ddv.visitLineNumber(321,L52);
                DexLabel L53=new DexLabel();
                ddv.visitLineNumber(327,L53);
                ddv.visitEndLocal(12,L53);
                ddv.visitEndLocal(9,L53);
                DexLabel L54=new DexLabel();
                ddv.visitLineNumber(329,L54);
                ddv.visitStartLocal(4,L54,"array","[B",null);
                DexLabel L55=new DexLabel();
                ddv.visitStartLocal(14,L55,"length","I",null);
                DexLabel L56=new DexLabel();
                ddv.visitLineNumber(331,L56);
                ddv.visitEndLocal(13,L56);
                DexLabel L57=new DexLabel();
                ddv.visitLineNumber(333,L57);
                ddv.visitStartLocal(6,L57,"ch","B",null);
                DexLabel L58=new DexLabel();
                ddv.visitLineNumber(335,L58);
                DexLabel L59=new DexLabel();
                ddv.visitLineNumber(336,L59);
                ddv.visitRestartLocal(13,L59);
                DexLabel L60=new DexLabel();
                ddv.visitLineNumber(338,L60);
                ddv.visitEndLocal(13,L60);
                DexLabel L61=new DexLabel();
                ddv.visitLineNumber(340,L61);
                DexLabel L62=new DexLabel();
                ddv.visitRestartLocal(13,L62);
                DexLabel L63=new DexLabel();
                ddv.visitLineNumber(343,L63);
                ddv.visitEndLocal(13,L63);
                DexLabel L64=new DexLabel();
                ddv.visitLineNumber(344,L64);
                DexLabel L65=new DexLabel();
                ddv.visitLineNumber(345,L65);
                DexLabel L66=new DexLabel();
                ddv.visitLineNumber(347,L66);
                DexLabel L67=new DexLabel();
                ddv.visitLineNumber(348,L67);
                DexLabel L68=new DexLabel();
                ddv.visitRestartLocal(13,L68);
                DexLabel L69=new DexLabel();
                ddv.visitLineNumber(353,L69);
                ddv.visitEndLocal(13,L69);
                DexLabel L70=new DexLabel();
                ddv.visitLineNumber(355,L70);
                DexLabel L71=new DexLabel();
                ddv.visitLineNumber(356,L71);
                DexLabel L72=new DexLabel();
                ddv.visitLineNumber(357,L72);
                ddv.visitRestartLocal(13,L72);
                DexLabel L73=new DexLabel();
                ddv.visitLineNumber(359,L73);
                ddv.visitEndLocal(13,L73);
                DexLabel L74=new DexLabel();
                ddv.visitLineNumber(361,L74);
                DexLabel L75=new DexLabel();
                ddv.visitLineNumber(366,L75);
                DexLabel L76=new DexLabel();
                ddv.visitLineNumber(368,L76);
                DexLabel L77=new DexLabel();
                ddv.visitLineNumber(369,L77);
                DexLabel L78=new DexLabel();
                ddv.visitRestartLocal(13,L78);
                DexLabel L79=new DexLabel();
                ddv.visitLineNumber(371,L79);
                ddv.visitEndLocal(13,L79);
                DexLabel L80=new DexLabel();
                ddv.visitLineNumber(373,L80);
                DexLabel L81=new DexLabel();
                ddv.visitLineNumber(378,L81);
                DexLabel L82=new DexLabel();
                ddv.visitLineNumber(380,L82);
                DexLabel L83=new DexLabel();
                ddv.visitLineNumber(381,L83);
                DexLabel L84=new DexLabel();
                ddv.visitLineNumber(382,L84);
                ddv.visitRestartLocal(13,L84);
                DexLabel L85=new DexLabel();
                ddv.visitLineNumber(384,L85);
                ddv.visitEndLocal(13,L85);
                DexLabel L86=new DexLabel();
                ddv.visitLineNumber(387,L86);
                DexLabel L87=new DexLabel();
                ddv.visitLineNumber(389,L87);
                DexLabel L88=new DexLabel();
                ddv.visitLineNumber(390,L88);
                DexLabel L89=new DexLabel();
                ddv.visitLineNumber(391,L89);
                DexLabel L90=new DexLabel();
                ddv.visitLineNumber(392,L90);
                DexLabel L91=new DexLabel();
                ddv.visitLineNumber(397,L91);
                DexLabel L92=new DexLabel();
                ddv.visitLineNumber(399,L92);
                DexLabel L93=new DexLabel();
                ddv.visitLineNumber(400,L93);
                DexLabel L94=new DexLabel();
                ddv.visitRestartLocal(13,L94);
                DexLabel L95=new DexLabel();
                ddv.visitLineNumber(402,L95);
                ddv.visitEndLocal(13,L95);
                DexLabel L96=new DexLabel();
                ddv.visitLineNumber(405,L96);
                DexLabel L97=new DexLabel();
                ddv.visitLineNumber(406,L97);
                DexLabel L98=new DexLabel();
                ddv.visitLineNumber(407,L98);
                DexLabel L99=new DexLabel();
                ddv.visitLineNumber(408,L99);
                DexLabel L100=new DexLabel();
                ddv.visitLineNumber(409,L100);
                DexLabel L101=new DexLabel();
                ddv.visitLineNumber(414,L101);
                DexLabel L102=new DexLabel();
                ddv.visitLineNumber(417,L102);
                DexLabel L103=new DexLabel();
                ddv.visitLineNumber(418,L103);
                ddv.visitStartLocal(15,L103,"method","Lorg/mortbay/io/Buffer;",null);
                DexLabel L104=new DexLabel();
                ddv.visitLineNumber(420,L104);
                DexLabel L105=new DexLabel();
                ddv.visitLineNumber(421,L105);
                DexLabel L106=new DexLabel();
                ddv.visitLineNumber(425,L106);
                DexLabel L107=new DexLabel();
                ddv.visitLineNumber(426,L107);
                DexLabel L108=new DexLabel();
                ddv.visitLineNumber(427,L108);
                DexLabel L109=new DexLabel();
                ddv.visitLineNumber(428,L109);
                DexLabel L110=new DexLabel();
                ddv.visitLineNumber(429,L110);
                DexLabel L111=new DexLabel();
                ddv.visitLineNumber(430,L111);
                ddv.visitRestartLocal(13,L111);
                DexLabel L112=new DexLabel();
                ddv.visitLineNumber(424,L112);
                ddv.visitEndLocal(13,L112);
                DexLabel L113=new DexLabel();
                ddv.visitLineNumber(436,L113);
                ddv.visitEndLocal(15,L113);
                DexLabel L114=new DexLabel();
                ddv.visitLineNumber(451,L114);
                DexLabel L115=new DexLabel();
                ddv.visitLineNumber(454,L115);
                DexLabel L116=new DexLabel();
                ddv.visitLineNumber(455,L116);
                ddv.visitStartLocal(10,L116,"header","Lorg/mortbay/io/Buffer;",null);
                DexLabel L117=new DexLabel();
                ddv.visitLineNumber(456,L117);
                DexLabel L118=new DexLabel();
                ddv.visitLineNumber(458,L118);
                ddv.visitStartLocal(20,L118,"value","Lorg/mortbay/io/Buffer;",null);
                DexLabel L119=new DexLabel();
                ddv.visitLineNumber(459,L119);
                ddv.visitStartLocal(11,L119,"ho","I",null);
                DexLabel L120=new DexLabel();
                ddv.visitLineNumber(461,L120);
                DexLabel L121=new DexLabel();
                ddv.visitLineNumber(463,L121);
                ddv.visitStartLocal(21,L121,"vo","I",null);
                DexLabel L122=new DexLabel();
                ddv.visitLineNumber(492,L122);
                ddv.visitEndLocal(21,L122);
                DexLabel L123=new DexLabel();
                ddv.visitLineNumber(493,L123);
                DexLabel L124=new DexLabel();
                ddv.visitLineNumber(494,L124);
                DexLabel L125=new DexLabel();
                ddv.visitLineNumber(495,L125);
                DexLabel L126=new DexLabel();
                ddv.visitLineNumber(500,L126);
                ddv.visitEndLocal(10,L126);
                ddv.visitEndLocal(20,L126);
                ddv.visitEndLocal(11,L126);
                DexLabel L127=new DexLabel();
                ddv.visitLineNumber(505,L127);
                DexLabel L128=new DexLabel();
                ddv.visitLineNumber(507,L128);
                DexLabel L129=new DexLabel();
                ddv.visitLineNumber(511,L129);
                DexLabel L130=new DexLabel();
                ddv.visitLineNumber(516,L130);
                DexLabel L131=new DexLabel();
                ddv.visitLineNumber(517,L131);
                DexLabel L132=new DexLabel();
                ddv.visitLineNumber(520,L132);
                DexLabel L133=new DexLabel();
                ddv.visitLineNumber(544,L133);
                DexLabel L134=new DexLabel();
                ddv.visitLineNumber(545,L134);
                DexLabel L135=new DexLabel();
                ddv.visitLineNumber(547,L135);
                DexLabel L136=new DexLabel();
                ddv.visitLineNumber(548,L136);
                DexLabel L137=new DexLabel();
                ddv.visitLineNumber(551,L137);
                DexLabel L138=new DexLabel();
                ddv.visitLineNumber(443,L138);
                DexLabel L139=new DexLabel();
                ddv.visitLineNumber(444,L139);
                DexLabel L140=new DexLabel();
                ddv.visitLineNumber(445,L140);
                ddv.visitRestartLocal(13,L140);
                DexLabel L141=new DexLabel();
                ddv.visitLineNumber(454,L141);
                ddv.visitEndLocal(13,L141);
                DexLabel L142=new DexLabel();
                ddv.visitLineNumber(456,L142);
                ddv.visitRestartLocal(10,L142);
                DexLabel L143=new DexLabel();
                ddv.visitLineNumber(466,L143);
                ddv.visitRestartLocal(11,L143);
                ddv.visitRestartLocal(20,L143);
                ddv.visitRestartLocal(21,L143);
                DexLabel L144=new DexLabel();
                ddv.visitLineNumber(468,L144);
                DexLabel L145=new DexLabel();
                ddv.visitLineNumber(469,L145);
                DexLabel L146=new DexLabel();
                ddv.visitLineNumber(470,L146);
                DexLabel L147=new DexLabel();
                ddv.visitLineNumber(475,L147);
                DexLabel L148=new DexLabel();
                ddv.visitLineNumber(476,L148);
                ddv.visitRestartLocal(20,L148);
                DexLabel L149=new DexLabel();
                ddv.visitLineNumber(477,L149);
                ddv.visitRestartLocal(21,L149);
                DexLabel L150=new DexLabel();
                ddv.visitLineNumber(478,L150);
                DexLabel L151=new DexLabel();
                ddv.visitLineNumber(481,L151);
                DexLabel L152=new DexLabel();
                ddv.visitLineNumber(482,L152);
                ddv.visitStartLocal(5,L152,"c","Ljava/lang/String;",null);
                DexLabel L153=new DexLabel();
                ddv.visitLineNumber(483,L153);
                DexLabel L154=new DexLabel();
                ddv.visitLineNumber(485,L154);
                DexLabel L155=new DexLabel();
                ddv.visitLineNumber(486,L155);
                DexLabel L156=new DexLabel();
                ddv.visitLineNumber(513,L156);
                ddv.visitEndLocal(10,L156);
                ddv.visitEndLocal(11,L156);
                ddv.visitEndLocal(20,L156);
                ddv.visitEndLocal(21,L156);
                ddv.visitEndLocal(5,L156);
                DexLabel L157=new DexLabel();
                ddv.visitLineNumber(520,L157);
                DexLabel L158=new DexLabel();
                ddv.visitLineNumber(523,L158);
                DexLabel L159=new DexLabel();
                ddv.visitLineNumber(524,L159);
                DexLabel L160=new DexLabel();
                ddv.visitLineNumber(525,L160);
                DexLabel L161=new DexLabel();
                ddv.visitLineNumber(527,L161);
                DexLabel L162=new DexLabel();
                ddv.visitLineNumber(531,L162);
                DexLabel L163=new DexLabel();
                ddv.visitLineNumber(532,L163);
                DexLabel L164=new DexLabel();
                ddv.visitLineNumber(533,L164);
                DexLabel L165=new DexLabel();
                ddv.visitLineNumber(534,L165);
                DexLabel L166=new DexLabel();
                ddv.visitLineNumber(538,L166);
                DexLabel L167=new DexLabel();
                ddv.visitLineNumber(539,L167);
                DexLabel L168=new DexLabel();
                ddv.visitLineNumber(540,L168);
                DexLabel L169=new DexLabel();
                ddv.visitLineNumber(556,L169);
                DexLabel L170=new DexLabel();
                ddv.visitLineNumber(557,L170);
                DexLabel L171=new DexLabel();
                ddv.visitLineNumber(558,L171);
                DexLabel L172=new DexLabel();
                ddv.visitLineNumber(561,L172);
                DexLabel L173=new DexLabel();
                ddv.visitLineNumber(563,L173);
                DexLabel L174=new DexLabel();
                ddv.visitLineNumber(565,L174);
                DexLabel L175=new DexLabel();
                ddv.visitLineNumber(567,L175);
                DexLabel L176=new DexLabel();
                ddv.visitLineNumber(568,L176);
                DexLabel L177=new DexLabel();
                ddv.visitLineNumber(569,L177);
                DexLabel L178=new DexLabel();
                ddv.visitRestartLocal(13,L178);
                DexLabel L179=new DexLabel();
                ddv.visitLineNumber(579,L179);
                ddv.visitEndLocal(13,L179);
                DexLabel L180=new DexLabel();
                ddv.visitLineNumber(599,L180);
                DexLabel L181=new DexLabel();
                ddv.visitLineNumber(600,L181);
                DexLabel L182=new DexLabel();
                ddv.visitLineNumber(601,L182);
                DexLabel L183=new DexLabel();
                ddv.visitLineNumber(602,L183);
                DexLabel L184=new DexLabel();
                ddv.visitLineNumber(603,L184);
                DexLabel L185=new DexLabel();
                ddv.visitLineNumber(607,L185);
                ddv.visitRestartLocal(13,L185);
                DexLabel L186=new DexLabel();
                ddv.visitLineNumber(583,L186);
                ddv.visitEndLocal(13,L186);
                DexLabel L187=new DexLabel();
                ddv.visitLineNumber(584,L187);
                DexLabel L188=new DexLabel();
                ddv.visitLineNumber(585,L188);
                DexLabel L189=new DexLabel();
                ddv.visitLineNumber(586,L189);
                DexLabel L190=new DexLabel();
                ddv.visitLineNumber(587,L190);
                ddv.visitRestartLocal(13,L190);
                DexLabel L191=new DexLabel();
                ddv.visitLineNumber(589,L191);
                ddv.visitEndLocal(13,L191);
                DexLabel L192=new DexLabel();
                ddv.visitLineNumber(590,L192);
                DexLabel L193=new DexLabel();
                ddv.visitLineNumber(591,L193);
                DexLabel L194=new DexLabel();
                ddv.visitLineNumber(592,L194);
                DexLabel L195=new DexLabel();
                ddv.visitLineNumber(593,L195);
                ddv.visitRestartLocal(13,L195);
                DexLabel L196=new DexLabel();
                ddv.visitEndLocal(13,L196);
                DexLabel L197=new DexLabel();
                ddv.visitLineNumber(596,L197);
                ddv.visitRestartLocal(13,L197);
                DexLabel L198=new DexLabel();
                ddv.visitLineNumber(610,L198);
                ddv.visitEndLocal(13,L198);
                DexLabel L199=new DexLabel();
                ddv.visitLineNumber(631,L199);
                DexLabel L200=new DexLabel();
                ddv.visitLineNumber(632,L200);
                DexLabel L201=new DexLabel();
                ddv.visitLineNumber(635,L201);
                ddv.visitRestartLocal(13,L201);
                DexLabel L202=new DexLabel();
                ddv.visitLineNumber(614,L202);
                ddv.visitEndLocal(13,L202);
                DexLabel L203=new DexLabel();
                ddv.visitLineNumber(615,L203);
                DexLabel L204=new DexLabel();
                ddv.visitLineNumber(616,L204);
                DexLabel L205=new DexLabel();
                ddv.visitLineNumber(617,L205);
                DexLabel L206=new DexLabel();
                ddv.visitLineNumber(618,L206);
                ddv.visitRestartLocal(13,L206);
                DexLabel L207=new DexLabel();
                ddv.visitLineNumber(620,L207);
                ddv.visitEndLocal(13,L207);
                DexLabel L208=new DexLabel();
                ddv.visitLineNumber(621,L208);
                DexLabel L209=new DexLabel();
                ddv.visitLineNumber(622,L209);
                DexLabel L210=new DexLabel();
                ddv.visitLineNumber(623,L210);
                DexLabel L211=new DexLabel();
                ddv.visitLineNumber(624,L211);
                ddv.visitRestartLocal(13,L211);
                DexLabel L212=new DexLabel();
                ddv.visitLineNumber(627,L212);
                ddv.visitEndLocal(13,L212);
                DexLabel L213=new DexLabel();
                ddv.visitLineNumber(628,L213);
                ddv.visitRestartLocal(13,L213);
                DexLabel L214=new DexLabel();
                ddv.visitLineNumber(638,L214);
                ddv.visitEndLocal(13,L214);
                DexLabel L215=new DexLabel();
                ddv.visitLineNumber(662,L215);
                DexLabel L216=new DexLabel();
                ddv.visitLineNumber(663,L216);
                DexLabel L217=new DexLabel();
                ddv.visitLineNumber(664,L217);
                DexLabel L218=new DexLabel();
                ddv.visitLineNumber(665,L218);
                DexLabel L219=new DexLabel();
                ddv.visitLineNumber(668,L219);
                ddv.visitRestartLocal(13,L219);
                DexLabel L220=new DexLabel();
                ddv.visitLineNumber(642,L220);
                ddv.visitEndLocal(13,L220);
                DexLabel L221=new DexLabel();
                ddv.visitLineNumber(644,L221);
                DexLabel L222=new DexLabel();
                ddv.visitLineNumber(645,L222);
                DexLabel L223=new DexLabel();
                ddv.visitLineNumber(654,L223);
                DexLabel L224=new DexLabel();
                ddv.visitLineNumber(655,L224);
                DexLabel L225=new DexLabel();
                ddv.visitLineNumber(656,L225);
                ddv.visitRestartLocal(13,L225);
                DexLabel L226=new DexLabel();
                ddv.visitLineNumber(649,L226);
                ddv.visitEndLocal(13,L226);
                DexLabel L227=new DexLabel();
                ddv.visitLineNumber(650,L227);
                DexLabel L228=new DexLabel();
                ddv.visitLineNumber(651,L228);
                DexLabel L229=new DexLabel();
                ddv.visitLineNumber(659,L229);
                ddv.visitRestartLocal(13,L229);
                DexLabel L230=new DexLabel();
                ddv.visitLineNumber(671,L230);
                ddv.visitEndLocal(13,L230);
                DexLabel L231=new DexLabel();
                ddv.visitLineNumber(695,L231);
                DexLabel L232=new DexLabel();
                ddv.visitLineNumber(675,L232);
                DexLabel L233=new DexLabel();
                ddv.visitLineNumber(677,L233);
                DexLabel L234=new DexLabel();
                ddv.visitLineNumber(678,L234);
                DexLabel L235=new DexLabel();
                ddv.visitLineNumber(687,L235);
                DexLabel L236=new DexLabel();
                ddv.visitLineNumber(688,L236);
                DexLabel L237=new DexLabel();
                ddv.visitLineNumber(689,L237);
                ddv.visitRestartLocal(13,L237);
                DexLabel L238=new DexLabel();
                ddv.visitLineNumber(682,L238);
                ddv.visitEndLocal(13,L238);
                DexLabel L239=new DexLabel();
                ddv.visitLineNumber(683,L239);
                DexLabel L240=new DexLabel();
                ddv.visitLineNumber(684,L240);
                DexLabel L241=new DexLabel();
                ddv.visitLineNumber(692,L241);
                DexLabel L242=new DexLabel();
                ddv.visitLineNumber(693,L242);
                ddv.visitRestartLocal(13,L242);
                DexLabel L243=new DexLabel();
                ddv.visitEndLocal(6,L243);
                ddv.visitEndLocal(13,L243);
                DexLabel L244=new DexLabel();
                ddv.visitLineNumber(704,L244);
                ddv.visitEndLocal(14,L244);
                ddv.visitRestartLocal(13,L244);
                DexLabel L245=new DexLabel();
                ddv.visitLineNumber(705,L245);
                ddv.visitRestartLocal(13,L245);
                DexLabel L246=new DexLabel();
                ddv.visitLineNumber(706,L246);
                DexLabel L247=new DexLabel();
                ddv.visitLineNumber(708,L247);
                DexLabel L248=new DexLabel();
                ddv.visitLineNumber(710,L248);
                DexLabel L249=new DexLabel();
                ddv.visitLineNumber(712,L249);
                DexLabel L250=new DexLabel();
                ddv.visitLineNumber(713,L250);
                DexLabel L251=new DexLabel();
                ddv.visitLineNumber(714,L251);
                ddv.visitRestartLocal(13,L251);
                DexLabel L252=new DexLabel();
                ddv.visitLineNumber(716,L252);
                DexLabel L253=new DexLabel();
                ddv.visitLineNumber(717,L253);
                DexLabel L254=new DexLabel();
                ddv.visitLineNumber(840,L254);
                DexLabel L255=new DexLabel();
                ddv.visitRestartLocal(13,L255);
                DexLabel L256=new DexLabel();
                ddv.visitLineNumber(720,L256);
                DexLabel L257=new DexLabel();
                ddv.visitLineNumber(721,L257);
                ddv.visitRestartLocal(7,L257);
                DexLabel L258=new DexLabel();
                ddv.visitLineNumber(722,L258);
                DexLabel L259=new DexLabel();
                ddv.visitLineNumber(723,L259);
                DexLabel L260=new DexLabel();
                ddv.visitLineNumber(725,L260);
                DexLabel L261=new DexLabel();
                ddv.visitLineNumber(729,L261);
                ddv.visitEndLocal(7,L261);
                DexLabel L262=new DexLabel();
                ddv.visitLineNumber(730,L262);
                ddv.visitStartLocal(16,L262,"remaining","J",null);
                DexLabel L263=new DexLabel();
                ddv.visitLineNumber(732,L263);
                DexLabel L264=new DexLabel();
                ddv.visitLineNumber(733,L264);
                DexLabel L265=new DexLabel();
                ddv.visitLineNumber(734,L265);
                DexLabel L266=new DexLabel();
                ddv.visitLineNumber(737,L266);
                DexLabel L267=new DexLabel();
                ddv.visitLineNumber(741,L267);
                DexLabel L268=new DexLabel();
                ddv.visitLineNumber(744,L268);
                DexLabel L269=new DexLabel();
                ddv.visitLineNumber(745,L269);
                ddv.visitRestartLocal(7,L269);
                DexLabel L270=new DexLabel();
                ddv.visitLineNumber(746,L270);
                DexLabel L271=new DexLabel();
                ddv.visitLineNumber(747,L271);
                DexLabel L272=new DexLabel();
                ddv.visitLineNumber(749,L272);
                DexLabel L273=new DexLabel();
                ddv.visitLineNumber(751,L273);
                DexLabel L274=new DexLabel();
                ddv.visitLineNumber(752,L274);
                DexLabel L275=new DexLabel();
                ddv.visitLineNumber(755,L275);
                DexLabel L276=new DexLabel();
                ddv.visitLineNumber(760,L276);
                ddv.visitEndLocal(16,L276);
                ddv.visitEndLocal(7,L276);
                DexLabel L277=new DexLabel();
                ddv.visitLineNumber(761,L277);
                ddv.visitRestartLocal(6,L277);
                DexLabel L278=new DexLabel();
                ddv.visitLineNumber(762,L278);
                DexLabel L279=new DexLabel();
                ddv.visitLineNumber(763,L279);
                DexLabel L280=new DexLabel();
                ddv.visitLineNumber(764,L280);
                DexLabel L281=new DexLabel();
                ddv.visitLineNumber(767,L281);
                DexLabel L282=new DexLabel();
                ddv.visitLineNumber(768,L282);
                DexLabel L283=new DexLabel();
                ddv.visitLineNumber(769,L283);
                DexLabel L284=new DexLabel();
                ddv.visitLineNumber(776,L284);
                ddv.visitEndLocal(6,L284);
                DexLabel L285=new DexLabel();
                ddv.visitLineNumber(777,L285);
                ddv.visitRestartLocal(6,L285);
                DexLabel L286=new DexLabel();
                ddv.visitLineNumber(779,L286);
                DexLabel L287=new DexLabel();
                ddv.visitLineNumber(780,L287);
                DexLabel L288=new DexLabel();
                ddv.visitLineNumber(782,L288);
                DexLabel L289=new DexLabel();
                ddv.visitLineNumber(783,L289);
                DexLabel L290=new DexLabel();
                ddv.visitLineNumber(784,L290);
                DexLabel L291=new DexLabel();
                ddv.visitLineNumber(787,L291);
                DexLabel L292=new DexLabel();
                ddv.visitLineNumber(789,L292);
                DexLabel L293=new DexLabel();
                ddv.visitLineNumber(790,L293);
                DexLabel L294=new DexLabel();
                ddv.visitLineNumber(791,L294);
                DexLabel L295=new DexLabel();
                ddv.visitLineNumber(792,L295);
                DexLabel L296=new DexLabel();
                ddv.visitLineNumber(793,L296);
                DexLabel L297=new DexLabel();
                ddv.visitLineNumber(794,L297);
                DexLabel L298=new DexLabel();
                ddv.visitLineNumber(795,L298);
                DexLabel L299=new DexLabel();
                ddv.visitLineNumber(796,L299);
                DexLabel L300=new DexLabel();
                ddv.visitLineNumber(798,L300);
                DexLabel L301=new DexLabel();
                ddv.visitLineNumber(804,L301);
                ddv.visitEndLocal(6,L301);
                DexLabel L302=new DexLabel();
                ddv.visitLineNumber(805,L302);
                ddv.visitRestartLocal(6,L302);
                DexLabel L303=new DexLabel();
                ddv.visitLineNumber(807,L303);
                DexLabel L304=new DexLabel();
                ddv.visitLineNumber(808,L304);
                DexLabel L305=new DexLabel();
                ddv.visitLineNumber(810,L305);
                DexLabel L306=new DexLabel();
                ddv.visitLineNumber(811,L306);
                DexLabel L307=new DexLabel();
                ddv.visitLineNumber(812,L307);
                DexLabel L308=new DexLabel();
                ddv.visitLineNumber(815,L308);
                DexLabel L309=new DexLabel();
                ddv.visitLineNumber(822,L309);
                ddv.visitEndLocal(6,L309);
                DexLabel L310=new DexLabel();
                ddv.visitLineNumber(823,L310);
                ddv.visitStartLocal(16,L310,"remaining","I",null);
                DexLabel L311=new DexLabel();
                ddv.visitLineNumber(825,L311);
                DexLabel L312=new DexLabel();
                ddv.visitLineNumber(828,L312);
                DexLabel L313=new DexLabel();
                ddv.visitLineNumber(829,L313);
                DexLabel L314=new DexLabel();
                ddv.visitLineNumber(830,L314);
                DexLabel L315=new DexLabel();
                ddv.visitLineNumber(831,L315);
                ddv.visitRestartLocal(7,L315);
                DexLabel L316=new DexLabel();
                ddv.visitLineNumber(832,L316);
                DexLabel L317=new DexLabel();
                ddv.visitLineNumber(833,L317);
                DexLabel L318=new DexLabel();
                ddv.visitLineNumber(834,L318);
                DexLabel L319=new DexLabel();
                ddv.visitLineNumber(836,L319);
                DexLabel L320=new DexLabel();
                ddv.visitEndLocal(16,L320);
                ddv.visitEndLocal(7,L320);
                DexLabel L321=new DexLabel();
                ddv.visitLineNumber(842,L321);
                DexLabel L322=new DexLabel();
                ddv.visitLineNumber(340,L322);
                DexLabel L323=new DexLabel();
                ddv.visitLineNumber(436,L323);
                DexLabel L324=new DexLabel();
                ddv.visitLineNumber(463,L324);
                DexLabel L325=new DexLabel();
                ddv.visitLineNumber(520,L325);
                DexLabel L326=new DexLabel();
                ddv.visitLineNumber(579,L326);
                DexLabel L327=new DexLabel();
                ddv.visitLineNumber(610,L327);
                DexLabel L328=new DexLabel();
                ddv.visitLineNumber(638,L328);
                DexLabel L329=new DexLabel();
                ddv.visitLineNumber(671,L329);
                DexLabel L330=new DexLabel();
                ddv.visitLineNumber(717,L330);
                code.visitLabel(L3);
                code.visitConstStmt(CONST_WIDE_16,18,Long.valueOf(-1L)); // long: 0xffffffffffffffff  double:NaN
                code.visitLabel(L4);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_state","I"));
                code.visitStmt2R(MOVE_FROM16,22,0);
                code.visitJumpStmt(IF_NEZ,22,-1,L7);
                code.visitLabel(L5);
                code.visitConstStmt(CONST_WIDE_16,22,Long.valueOf(-1L)); // long: 0xffffffffffffffff  double:NaN
                code.visitLabel(L6);
                code.visitStmt1R(RETURN_WIDE,22);
                code.visitLabel(L7);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_buffer","Lorg/mortbay/io/Buffer;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,22,0);
                code.visitJumpStmt(IF_NEZ,22,-1,L15);
                code.visitLabel(L8);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_header","Lorg/mortbay/io/Buffer;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,22,0);
                code.visitJumpStmt(IF_NEZ,22,-1,L10);
                code.visitLabel(L9);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_buffers","Lorg/mortbay/io/Buffers;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,22,0);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_headerBufferSize","I"));
                code.visitStmt2R(MOVE_FROM16,23,0);
                code.visitMethodStmt(INVOKE_INTERFACE_RANGE,new int[]{ 22,23},new Method("Lorg/mortbay/io/Buffers;","getBuffer",new String[]{ "I"},"Lorg/mortbay/io/Buffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,22);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,22);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,27);
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/jetty/HttpParser;","_header","Lorg/mortbay/io/Buffer;"));
                code.visitLabel(L10);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_header","Lorg/mortbay/io/Buffer;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,22,0);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,22);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,27);
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/jetty/HttpParser;","_buffer","Lorg/mortbay/io/Buffer;"));
                code.visitLabel(L11);
                code.visitTypeStmt(NEW_INSTANCE,22,-1,"Lorg/mortbay/io/View$CaseInsensitive;");
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_header","Lorg/mortbay/io/Buffer;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,23,0);
                code.visitMethodStmt(INVOKE_DIRECT_RANGE,new int[]{ 22,23},new Method("Lorg/mortbay/io/View$CaseInsensitive;","<init>",new String[]{ "Lorg/mortbay/io/Buffer;"},"V"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,22);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,27);
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/jetty/HttpParser;","_tok0","Lorg/mortbay/io/View$CaseInsensitive;"));
                code.visitLabel(L12);
                code.visitTypeStmt(NEW_INSTANCE,22,-1,"Lorg/mortbay/io/View$CaseInsensitive;");
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_header","Lorg/mortbay/io/Buffer;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,23,0);
                code.visitMethodStmt(INVOKE_DIRECT_RANGE,new int[]{ 22,23},new Method("Lorg/mortbay/io/View$CaseInsensitive;","<init>",new String[]{ "Lorg/mortbay/io/Buffer;"},"V"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,22);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,27);
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/jetty/HttpParser;","_tok1","Lorg/mortbay/io/View$CaseInsensitive;"));
                code.visitLabel(L13);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_tok0","Lorg/mortbay/io/View$CaseInsensitive;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,22,0);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_tok0","Lorg/mortbay/io/View$CaseInsensitive;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,23,0);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 23},new Method("Lorg/mortbay/io/View$CaseInsensitive;","getIndex",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,23);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 22,23},new Method("Lorg/mortbay/io/View$CaseInsensitive;","setPutIndex",new String[]{ "I"},"V"));
                code.visitLabel(L14);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_tok1","Lorg/mortbay/io/View$CaseInsensitive;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,22,0);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_tok1","Lorg/mortbay/io/View$CaseInsensitive;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,23,0);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 23},new Method("Lorg/mortbay/io/View$CaseInsensitive;","getIndex",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,23);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 22,23},new Method("Lorg/mortbay/io/View$CaseInsensitive;","setPutIndex",new String[]{ "I"},"V"));
                code.visitLabel(L15);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_state","I"));
                code.visitStmt2R(MOVE_FROM16,22,0);
                code.visitConstStmt(CONST_16,23, Integer.valueOf(2)); // int: 0x00000002  float:0.000000
                code.visitStmt2R(MOVE_FROM16,0,22);
                code.visitStmt2R(MOVE_FROM16,1,23);
                code.visitJumpStmt(IF_NE,0,1,L19);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_WIDE,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_contentPosition","J"));
                code.visitStmt2R(MOVE_WIDE_FROM16,22,0);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_WIDE,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_contentLength","J"));
                code.visitStmt2R(MOVE_WIDE_FROM16,24,0);
                code.visitStmt3R(CMP_LONG,22,22,24);
                code.visitJumpStmt(IF_NEZ,22,-1,L19);
                code.visitLabel(L16);
                code.visitConstStmt(CONST_16,22, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitStmt2R(MOVE_FROM16,0,22);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,27);
                code.visitFieldStmt(IPUT,0,1,new Field("Lorg/mortbay/jetty/HttpParser;","_state","I"));
                code.visitLabel(L17);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_handler","Lorg/mortbay/jetty/HttpParser$EventHandler;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,22,0);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_WIDE,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_contentPosition","J"));
                code.visitStmt2R(MOVE_WIDE_FROM16,23,0);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 22,23,24},new Method("Lorg/mortbay/jetty/HttpParser$EventHandler;","messageComplete",new String[]{ "J"},"V"));
                code.visitStmt2R(MOVE_WIDE_FROM16,22,18);
                code.visitLabel(L18);
                code.visitJumpStmt(GOTO_16,-1,-1,L6);
                code.visitLabel(L19);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_buffer","Lorg/mortbay/io/Buffer;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,22,0);
                code.visitMethodStmt(INVOKE_INTERFACE_RANGE,new int[]{ 22},new Method("Lorg/mortbay/io/Buffer;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,13);
                code.visitLabel(L20);
                code.visitJumpStmt(IF_NEZ,13,-1,L53);
                code.visitLabel(L21);
                code.visitConstStmt(CONST_4,9, Integer.valueOf(-1)); // int: 0xffffffff  float:NaN
                code.visitLabel(L22);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_body","Lorg/mortbay/io/Buffer;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,22,0);
                code.visitJumpStmt(IF_EQZ,22,-1,L25);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_buffer","Lorg/mortbay/io/Buffer;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,22,0);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_body","Lorg/mortbay/io/Buffer;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,23,0);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,22);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,23);
                code.visitJumpStmt(IF_EQ,0,1,L25);
                code.visitLabel(L23);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_body","Lorg/mortbay/io/Buffer;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,22,0);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,22);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,27);
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/jetty/HttpParser;","_buffer","Lorg/mortbay/io/Buffer;"));
                code.visitLabel(L24);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_buffer","Lorg/mortbay/io/Buffer;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,22,0);
                code.visitMethodStmt(INVOKE_INTERFACE_RANGE,new int[]{ 22},new Method("Lorg/mortbay/io/Buffer;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,9);
                code.visitLabel(L25);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_buffer","Lorg/mortbay/io/Buffer;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,22,0);
                code.visitMethodStmt(INVOKE_INTERFACE_RANGE,new int[]{ 22},new Method("Lorg/mortbay/io/Buffer;","markIndex",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,22);
                code.visitJumpStmt(IF_NEZ,22,-1,L27);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_buffer","Lorg/mortbay/io/Buffer;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,22,0);
                code.visitMethodStmt(INVOKE_INTERFACE_RANGE,new int[]{ 22},new Method("Lorg/mortbay/io/Buffer;","putIndex",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,22);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_buffer","Lorg/mortbay/io/Buffer;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,23,0);
                code.visitMethodStmt(INVOKE_INTERFACE_RANGE,new int[]{ 23},new Method("Lorg/mortbay/io/Buffer;","capacity",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,23);
                code.visitStmt2R(MOVE_FROM16,0,22);
                code.visitStmt2R(MOVE_FROM16,1,23);
                code.visitJumpStmt(IF_NE,0,1,L27);
                code.visitLabel(L26);
                code.visitTypeStmt(NEW_INSTANCE,22,-1,"Lorg/mortbay/jetty/HttpException;");
                code.visitConstStmt(CONST_16,23, Integer.valueOf(413)); // int: 0x0000019d  float:0.000000
                code.visitConstStmt(CONST_STRING,24,"FULL");
                code.visitMethodStmt(INVOKE_DIRECT_RANGE,new int[]{ 22,23,24},new Method("Lorg/mortbay/jetty/HttpException;","<init>",new String[]{ "I","Ljava/lang/String;"},"V"));
                code.visitStmt1R(THROW,22);
                code.visitLabel(L27);
                code.visitConstStmt(CONST_4,12, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L28);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_endp","Lorg/mortbay/io/EndPoint;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,22,0);
                code.visitJumpStmt(IF_EQZ,22,-1,L37);
                code.visitJumpStmt(IF_GTZ,9,-1,L37);
                code.visitLabel(L29);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_buffer","Lorg/mortbay/io/Buffer;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,22,0);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_body","Lorg/mortbay/io/Buffer;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,23,0);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,22);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,23);
                code.visitJumpStmt(IF_NE,0,1,L31);
                code.visitLabel(L30);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_buffer","Lorg/mortbay/io/Buffer;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,22,0);
                code.visitMethodStmt(INVOKE_INTERFACE_RANGE,new int[]{ 22},new Method("Lorg/mortbay/io/Buffer;","compact",new String[]{ },"V"));
                code.visitLabel(L31);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_buffer","Lorg/mortbay/io/Buffer;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,22,0);
                code.visitMethodStmt(INVOKE_INTERFACE_RANGE,new int[]{ 22},new Method("Lorg/mortbay/io/Buffer;","space",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,22);
                code.visitJumpStmt(IF_NEZ,22,-1,L33);
                code.visitLabel(L32);
                code.visitTypeStmt(NEW_INSTANCE,22,-1,"Lorg/mortbay/jetty/HttpException;");
                code.visitConstStmt(CONST_16,23, Integer.valueOf(413)); // int: 0x0000019d  float:0.000000
                code.visitTypeStmt(NEW_INSTANCE,24,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT_RANGE,new int[]{ 24},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,25,"FULL ");
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 24,25},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,24);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_buffer","Lorg/mortbay/io/Buffer;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,25,0);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_body","Lorg/mortbay/io/Buffer;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,26,0);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,25);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,26);
                DexLabel L331=new DexLabel();
                code.visitJumpStmt(IF_NE,0,1,L331);
                code.visitConstStmt(CONST_STRING,25,"body");
                DexLabel L332=new DexLabel();
                code.visitLabel(L332);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 24,25},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,24);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 24},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,24);
                code.visitMethodStmt(INVOKE_DIRECT_RANGE,new int[]{ 22,23,24},new Method("Lorg/mortbay/jetty/HttpException;","<init>",new String[]{ "I","Ljava/lang/String;"},"V"));
                code.visitStmt1R(THROW,22);
                code.visitLabel(L331);
                code.visitConstStmt(CONST_STRING,25,"head");
                code.visitJumpStmt(GOTO,-1,-1,L332);
                code.visitLabel(L33);
                code.visitConstStmt(CONST_WIDE_16,22,Long.valueOf(0L)); // long: 0x0000000000000000  double:0.000000
                code.visitStmt3R(CMP_LONG,22,18,22);
                code.visitJumpStmt(IF_GEZ,22,-1,L0);
                code.visitLabel(L34);
                code.visitConstStmt(CONST_WIDE_16,18,Long.valueOf(0L)); // long: 0x0000000000000000  double:0.000000
                code.visitLabel(L0);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_endp","Lorg/mortbay/io/EndPoint;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,22,0);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_buffer","Lorg/mortbay/io/Buffer;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,23,0);
                code.visitMethodStmt(INVOKE_INTERFACE_RANGE,new int[]{ 22,23},new Method("Lorg/mortbay/io/EndPoint;","fill",new String[]{ "Lorg/mortbay/io/Buffer;"},"I"));
                code.visitLabel(L1);
                code.visitStmt1R(MOVE_RESULT,9);
                code.visitLabel(L35);
                code.visitJumpStmt(IF_LEZ,9,-1,L37);
                code.visitLabel(L36);
                code.visitStmt2R(MOVE,0,9);
                code.visitStmt2R(INT_TO_LONG,0,0);
                code.visitStmt2R(MOVE_WIDE_FROM16,22,0);
                code.visitStmt3R(ADD_LONG,18,18,22);
                code.visitLabel(L37);
                code.visitJumpStmt(IF_GEZ,9,-1,L52);
                code.visitLabel(L38);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_state","I"));
                code.visitStmt2R(MOVE_FROM16,22,0);
                code.visitConstStmt(CONST_16,23, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitStmt2R(MOVE_FROM16,0,22);
                code.visitStmt2R(MOVE_FROM16,1,23);
                code.visitJumpStmt(IF_NE,0,1,L50);
                code.visitLabel(L39);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_buffer","Lorg/mortbay/io/Buffer;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,22,0);
                code.visitMethodStmt(INVOKE_INTERFACE_RANGE,new int[]{ 22},new Method("Lorg/mortbay/io/Buffer;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,22);
                code.visitJumpStmt(IF_LEZ,22,-1,L44);
                code.visitLabel(L40);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_buffer","Lorg/mortbay/io/Buffer;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,22,0);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_buffer","Lorg/mortbay/io/Buffer;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,23,0);
                code.visitMethodStmt(INVOKE_INTERFACE_RANGE,new int[]{ 23},new Method("Lorg/mortbay/io/Buffer;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,23);
                code.visitMethodStmt(INVOKE_INTERFACE_RANGE,new int[]{ 22,23},new Method("Lorg/mortbay/io/Buffer;","get",new String[]{ "I"},"Lorg/mortbay/io/Buffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitLabel(L41);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_WIDE,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_contentPosition","J"));
                code.visitStmt2R(MOVE_WIDE_FROM16,22,0);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 7},new Method("Lorg/mortbay/io/Buffer;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,24);
                code.visitStmt2R(MOVE_FROM16,0,24);
                code.visitStmt2R(INT_TO_LONG,0,0);
                code.visitStmt2R(MOVE_WIDE_FROM16,24,0);
                code.visitStmt3R(ADD_LONG,22,22,24);
                code.visitStmt2R(MOVE_WIDE_FROM16,0,22);
                code.visitStmt2R(MOVE_OBJECT_FROM16,2,27);
                code.visitFieldStmt(IPUT_WIDE,0,2,new Field("Lorg/mortbay/jetty/HttpParser;","_contentPosition","J"));
                code.visitLabel(L42);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_contentView","Lorg/mortbay/io/View;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,22,0);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,22);
                code.visitStmt2R(MOVE_OBJECT,1,7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Lorg/mortbay/io/View;","update",new String[]{ "Lorg/mortbay/io/Buffer;"},"V"));
                code.visitLabel(L43);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_handler","Lorg/mortbay/jetty/HttpParser$EventHandler;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,22,0);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,22);
                code.visitStmt2R(MOVE_OBJECT,1,7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Lorg/mortbay/jetty/HttpParser$EventHandler;","content",new String[]{ "Lorg/mortbay/io/Buffer;"},"V"));
                code.visitLabel(L44);
                code.visitConstStmt(CONST_16,22, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitStmt2R(MOVE_FROM16,0,22);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,27);
                code.visitFieldStmt(IPUT,0,1,new Field("Lorg/mortbay/jetty/HttpParser;","_state","I"));
                code.visitLabel(L45);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_handler","Lorg/mortbay/jetty/HttpParser$EventHandler;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,22,0);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_WIDE,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_contentPosition","J"));
                code.visitStmt2R(MOVE_WIDE_FROM16,23,0);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 22,23,24},new Method("Lorg/mortbay/jetty/HttpParser$EventHandler;","messageComplete",new String[]{ "J"},"V"));
                code.visitStmt2R(MOVE_WIDE_FROM16,22,18);
                code.visitLabel(L46);
                code.visitJumpStmt(GOTO_16,-1,-1,L6);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,22);
                code.visitStmt2R(MOVE_OBJECT_FROM16,8,22);
                code.visitLabel(L47);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 8},new Method("Lorg/mortbay/log/Log;","debug",new String[]{ "Ljava/lang/Throwable;"},"V"));
                code.visitLabel(L48);
                code.visitStmt2R(MOVE_OBJECT,12,8);
                code.visitLabel(L49);
                code.visitConstStmt(CONST_4,9, Integer.valueOf(-1)); // int: 0xffffffff  float:NaN
                code.visitJumpStmt(GOTO_16,-1,-1,L37);
                code.visitLabel(L50);
                code.visitConstStmt(CONST_16,22, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitStmt2R(MOVE_FROM16,1,22);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Lorg/mortbay/jetty/HttpParser;","reset",new String[]{ "Z"},"V"));
                code.visitLabel(L51);
                code.visitTypeStmt(NEW_INSTANCE,22,-1,"Lorg/mortbay/jetty/EofException;");
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,22);
                code.visitStmt2R(MOVE_OBJECT,1,12);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1},new Method("Lorg/mortbay/jetty/EofException;","<init>",new String[]{ "Ljava/lang/Throwable;"},"V"));
                code.visitStmt1R(THROW,22);
                code.visitLabel(L52);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_buffer","Lorg/mortbay/io/Buffer;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,22,0);
                code.visitMethodStmt(INVOKE_INTERFACE_RANGE,new int[]{ 22},new Method("Lorg/mortbay/io/Buffer;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,13);
                code.visitLabel(L53);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_buffer","Lorg/mortbay/io/Buffer;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,22,0);
                code.visitMethodStmt(INVOKE_INTERFACE_RANGE,new int[]{ 22},new Method("Lorg/mortbay/io/Buffer;","array",new String[]{ },"[B"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitLabel(L54);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_state","I"));
                code.visitStmt2R(MOVE_FROM16,22,0);
                code.visitJumpStmt(IF_GEZ,22,-1,L244);
                code.visitConstStmt(CONST_16,22, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitStmt3R(SUB_INT,14,13,22);
                code.visitLabel(L55);
                code.visitJumpStmt(IF_LEZ,13,-1,L243);
                code.visitLabel(L56);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_buffer","Lorg/mortbay/io/Buffer;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,22,0);
                code.visitMethodStmt(INVOKE_INTERFACE_RANGE,new int[]{ 22},new Method("Lorg/mortbay/io/Buffer;","get",new String[]{ },"B"));
                code.visitStmt1R(MOVE_RESULT,6);
                code.visitLabel(L57);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_BYTE,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_eol","B"));
                code.visitStmt2R(MOVE_FROM16,22,0);
                code.visitConstStmt(CONST_16,23, Integer.valueOf(13)); // int: 0x0000000d  float:0.000000
                code.visitStmt2R(MOVE_FROM16,0,22);
                code.visitStmt2R(MOVE_FROM16,1,23);
                code.visitJumpStmt(IF_NE,0,1,L60);
                code.visitConstStmt(CONST_16,22, Integer.valueOf(10)); // int: 0x0000000a  float:0.000000
                code.visitStmt2R(MOVE,0,6);
                code.visitStmt2R(MOVE_FROM16,1,22);
                code.visitJumpStmt(IF_NE,0,1,L60);
                code.visitLabel(L58);
                code.visitConstStmt(CONST_16,22, Integer.valueOf(10)); // int: 0x0000000a  float:0.000000
                code.visitStmt2R(MOVE_FROM16,0,22);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,27);
                code.visitFieldStmt(IPUT_BYTE,0,1,new Field("Lorg/mortbay/jetty/HttpParser;","_eol","B"));
                code.visitStmt2R(MOVE,13,14);
                code.visitLabel(L59);
                code.visitJumpStmt(GOTO,-1,-1,L54);
                code.visitLabel(L60);
                code.visitConstStmt(CONST_16,22, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitStmt2R(MOVE_FROM16,0,22);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,27);
                code.visitFieldStmt(IPUT_BYTE,0,1,new Field("Lorg/mortbay/jetty/HttpParser;","_eol","B"));
                code.visitLabel(L61);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_state","I"));
                code.visitStmt2R(MOVE_FROM16,22,0);
                DexLabel L333=new DexLabel();
                code.visitSparseSwitchStmt(PACKED_SWITCH,22,-13,new DexLabel[]{L63,L69,L75,L81,L91,L333,L333,L101,L113,L179,L198,L214,L230});
                code.visitLabel(L333);
                code.visitStmt2R(MOVE,13,14);
                code.visitLabel(L62);
                code.visitJumpStmt(GOTO,-1,-1,L54);
                code.visitLabel(L63);
                code.visitConstStmt(CONST_WIDE_16,22,Long.valueOf(-3L)); // long: 0xfffffffffffffffd  double:NaN
                code.visitStmt2R(MOVE_WIDE_FROM16,0,22);
                code.visitStmt2R(MOVE_OBJECT_FROM16,2,27);
                code.visitFieldStmt(IPUT_WIDE,0,2,new Field("Lorg/mortbay/jetty/HttpParser;","_contentLength","J"));
                code.visitLabel(L64);
                code.visitConstStmt(CONST_16,22, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,22);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,27);
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/jetty/HttpParser;","_cached","Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitLabel(L65);
                code.visitConstStmt(CONST_16,22, Integer.valueOf(32)); // int: 0x00000020  float:0.000000
                code.visitStmt2R(MOVE,0,6);
                code.visitStmt2R(MOVE_FROM16,1,22);
                code.visitJumpStmt(IF_GT,0,1,L66);
                code.visitJumpStmt(IF_GEZ,6,-1,L333);
                code.visitLabel(L66);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_buffer","Lorg/mortbay/io/Buffer;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,22,0);
                code.visitMethodStmt(INVOKE_INTERFACE_RANGE,new int[]{ 22},new Method("Lorg/mortbay/io/Buffer;","mark",new String[]{ },"V"));
                code.visitLabel(L67);
                code.visitConstStmt(CONST_16,22, Integer.valueOf(-12)); // int: 0xfffffff4  float:NaN
                code.visitStmt2R(MOVE_FROM16,0,22);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,27);
                code.visitFieldStmt(IPUT,0,1,new Field("Lorg/mortbay/jetty/HttpParser;","_state","I"));
                code.visitStmt2R(MOVE,13,14);
                code.visitLabel(L68);
                code.visitJumpStmt(GOTO,-1,-1,L54);
                code.visitLabel(L69);
                code.visitConstStmt(CONST_16,22, Integer.valueOf(32)); // int: 0x00000020  float:0.000000
                code.visitStmt2R(MOVE,0,6);
                code.visitStmt2R(MOVE_FROM16,1,22);
                code.visitJumpStmt(IF_NE,0,1,L73);
                code.visitLabel(L70);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_tok0","Lorg/mortbay/io/View$CaseInsensitive;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,22,0);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_buffer","Lorg/mortbay/io/Buffer;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,23,0);
                code.visitMethodStmt(INVOKE_INTERFACE_RANGE,new int[]{ 23},new Method("Lorg/mortbay/io/Buffer;","markIndex",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,23);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_buffer","Lorg/mortbay/io/Buffer;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,24,0);
                code.visitMethodStmt(INVOKE_INTERFACE_RANGE,new int[]{ 24},new Method("Lorg/mortbay/io/Buffer;","getIndex",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,24);
                code.visitConstStmt(CONST_16,25, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitStmt3R(SUB_INT,24,24,25);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 22,23,24},new Method("Lorg/mortbay/io/View$CaseInsensitive;","update",new String[]{ "I","I"},"V"));
                code.visitLabel(L71);
                code.visitConstStmt(CONST_16,22, Integer.valueOf(-11)); // int: 0xfffffff5  float:NaN
                code.visitStmt2R(MOVE_FROM16,0,22);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,27);
                code.visitFieldStmt(IPUT,0,1,new Field("Lorg/mortbay/jetty/HttpParser;","_state","I"));
                code.visitStmt2R(MOVE,13,14);
                code.visitLabel(L72);
                code.visitJumpStmt(GOTO_16,-1,-1,L54);
                code.visitLabel(L73);
                code.visitConstStmt(CONST_16,22, Integer.valueOf(32)); // int: 0x00000020  float:0.000000
                code.visitStmt2R(MOVE,0,6);
                code.visitStmt2R(MOVE_FROM16,1,22);
                code.visitJumpStmt(IF_GE,0,1,L333);
                code.visitJumpStmt(IF_LTZ,6,-1,L333);
                code.visitLabel(L74);
                code.visitTypeStmt(NEW_INSTANCE,22,-1,"Lorg/mortbay/jetty/HttpException;");
                code.visitConstStmt(CONST_16,23, Integer.valueOf(400)); // int: 0x00000190  float:0.000000
                code.visitMethodStmt(INVOKE_DIRECT_RANGE,new int[]{ 22,23},new Method("Lorg/mortbay/jetty/HttpException;","<init>",new String[]{ "I"},"V"));
                code.visitStmt1R(THROW,22);
                code.visitLabel(L75);
                code.visitConstStmt(CONST_16,22, Integer.valueOf(32)); // int: 0x00000020  float:0.000000
                code.visitStmt2R(MOVE,0,6);
                code.visitStmt2R(MOVE_FROM16,1,22);
                code.visitJumpStmt(IF_GT,0,1,L76);
                code.visitJumpStmt(IF_GEZ,6,-1,L79);
                code.visitLabel(L76);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_buffer","Lorg/mortbay/io/Buffer;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,22,0);
                code.visitMethodStmt(INVOKE_INTERFACE_RANGE,new int[]{ 22},new Method("Lorg/mortbay/io/Buffer;","mark",new String[]{ },"V"));
                code.visitLabel(L77);
                code.visitConstStmt(CONST_16,22, Integer.valueOf(-10)); // int: 0xfffffff6  float:NaN
                code.visitStmt2R(MOVE_FROM16,0,22);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,27);
                code.visitFieldStmt(IPUT,0,1,new Field("Lorg/mortbay/jetty/HttpParser;","_state","I"));
                code.visitStmt2R(MOVE,13,14);
                code.visitLabel(L78);
                code.visitJumpStmt(GOTO_16,-1,-1,L54);
                code.visitLabel(L79);
                code.visitConstStmt(CONST_16,22, Integer.valueOf(32)); // int: 0x00000020  float:0.000000
                code.visitStmt2R(MOVE,0,6);
                code.visitStmt2R(MOVE_FROM16,1,22);
                code.visitJumpStmt(IF_GE,0,1,L333);
                code.visitLabel(L80);
                code.visitTypeStmt(NEW_INSTANCE,22,-1,"Lorg/mortbay/jetty/HttpException;");
                code.visitConstStmt(CONST_16,23, Integer.valueOf(400)); // int: 0x00000190  float:0.000000
                code.visitMethodStmt(INVOKE_DIRECT_RANGE,new int[]{ 22,23},new Method("Lorg/mortbay/jetty/HttpException;","<init>",new String[]{ "I"},"V"));
                code.visitStmt1R(THROW,22);
                code.visitLabel(L81);
                code.visitConstStmt(CONST_16,22, Integer.valueOf(32)); // int: 0x00000020  float:0.000000
                code.visitStmt2R(MOVE,0,6);
                code.visitStmt2R(MOVE_FROM16,1,22);
                code.visitJumpStmt(IF_NE,0,1,L85);
                code.visitLabel(L82);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_tok1","Lorg/mortbay/io/View$CaseInsensitive;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,22,0);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_buffer","Lorg/mortbay/io/Buffer;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,23,0);
                code.visitMethodStmt(INVOKE_INTERFACE_RANGE,new int[]{ 23},new Method("Lorg/mortbay/io/Buffer;","markIndex",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,23);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_buffer","Lorg/mortbay/io/Buffer;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,24,0);
                code.visitMethodStmt(INVOKE_INTERFACE_RANGE,new int[]{ 24},new Method("Lorg/mortbay/io/Buffer;","getIndex",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,24);
                code.visitConstStmt(CONST_16,25, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitStmt3R(SUB_INT,24,24,25);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 22,23,24},new Method("Lorg/mortbay/io/View$CaseInsensitive;","update",new String[]{ "I","I"},"V"));
                code.visitLabel(L83);
                code.visitConstStmt(CONST_16,22, Integer.valueOf(-9)); // int: 0xfffffff7  float:NaN
                code.visitStmt2R(MOVE_FROM16,0,22);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,27);
                code.visitFieldStmt(IPUT,0,1,new Field("Lorg/mortbay/jetty/HttpParser;","_state","I"));
                code.visitStmt2R(MOVE,13,14);
                code.visitLabel(L84);
                code.visitJumpStmt(GOTO_16,-1,-1,L54);
                code.visitLabel(L85);
                code.visitConstStmt(CONST_16,22, Integer.valueOf(32)); // int: 0x00000020  float:0.000000
                code.visitStmt2R(MOVE,0,6);
                code.visitStmt2R(MOVE_FROM16,1,22);
                code.visitJumpStmt(IF_GE,0,1,L333);
                code.visitJumpStmt(IF_LTZ,6,-1,L333);
                code.visitLabel(L86);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_handler","Lorg/mortbay/jetty/HttpParser$EventHandler;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,22,0);
                code.visitFieldStmt(SGET_OBJECT,23,-1,new Field("Lorg/mortbay/jetty/HttpMethods;","CACHE","Lorg/mortbay/io/BufferCache;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_tok0","Lorg/mortbay/io/View$CaseInsensitive;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,24,0);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 23,24},new Method("Lorg/mortbay/io/BufferCache;","lookup",new String[]{ "Lorg/mortbay/io/Buffer;"},"Lorg/mortbay/io/Buffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,23);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_buffer","Lorg/mortbay/io/Buffer;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,24,0);
                code.visitMethodStmt(INVOKE_INTERFACE_RANGE,new int[]{ 24},new Method("Lorg/mortbay/io/Buffer;","sliceFromMark",new String[]{ },"Lorg/mortbay/io/Buffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,24);
                code.visitConstStmt(CONST_16,25, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 22,23,24,25},new Method("Lorg/mortbay/jetty/HttpParser$EventHandler;","startRequest",new String[]{ "Lorg/mortbay/io/Buffer;","Lorg/mortbay/io/Buffer;","Lorg/mortbay/io/Buffer;"},"V"));
                code.visitLabel(L87);
                code.visitConstStmt(CONST_16,22, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitStmt2R(MOVE_FROM16,0,22);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,27);
                code.visitFieldStmt(IPUT,0,1,new Field("Lorg/mortbay/jetty/HttpParser;","_state","I"));
                code.visitLabel(L88);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_handler","Lorg/mortbay/jetty/HttpParser$EventHandler;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,22,0);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 22},new Method("Lorg/mortbay/jetty/HttpParser$EventHandler;","headerComplete",new String[]{ },"V"));
                code.visitLabel(L89);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_handler","Lorg/mortbay/jetty/HttpParser$EventHandler;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,22,0);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_WIDE,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_contentPosition","J"));
                code.visitStmt2R(MOVE_WIDE_FROM16,23,0);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 22,23,24},new Method("Lorg/mortbay/jetty/HttpParser$EventHandler;","messageComplete",new String[]{ "J"},"V"));
                code.visitStmt2R(MOVE_WIDE_FROM16,22,18);
                code.visitLabel(L90);
                code.visitJumpStmt(GOTO_16,-1,-1,L6);
                code.visitLabel(L91);
                code.visitConstStmt(CONST_16,22, Integer.valueOf(32)); // int: 0x00000020  float:0.000000
                code.visitStmt2R(MOVE,0,6);
                code.visitStmt2R(MOVE_FROM16,1,22);
                code.visitJumpStmt(IF_GT,0,1,L92);
                code.visitJumpStmt(IF_GEZ,6,-1,L95);
                code.visitLabel(L92);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_buffer","Lorg/mortbay/io/Buffer;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,22,0);
                code.visitMethodStmt(INVOKE_INTERFACE_RANGE,new int[]{ 22},new Method("Lorg/mortbay/io/Buffer;","mark",new String[]{ },"V"));
                code.visitLabel(L93);
                code.visitConstStmt(CONST_16,22, Integer.valueOf(-6)); // int: 0xfffffffa  float:NaN
                code.visitStmt2R(MOVE_FROM16,0,22);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,27);
                code.visitFieldStmt(IPUT,0,1,new Field("Lorg/mortbay/jetty/HttpParser;","_state","I"));
                code.visitStmt2R(MOVE,13,14);
                code.visitLabel(L94);
                code.visitJumpStmt(GOTO_16,-1,-1,L54);
                code.visitLabel(L95);
                code.visitConstStmt(CONST_16,22, Integer.valueOf(32)); // int: 0x00000020  float:0.000000
                code.visitStmt2R(MOVE,0,6);
                code.visitStmt2R(MOVE_FROM16,1,22);
                code.visitJumpStmt(IF_GE,0,1,L333);
                code.visitLabel(L96);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_handler","Lorg/mortbay/jetty/HttpParser$EventHandler;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,22,0);
                code.visitFieldStmt(SGET_OBJECT,23,-1,new Field("Lorg/mortbay/jetty/HttpMethods;","CACHE","Lorg/mortbay/io/BufferCache;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_tok0","Lorg/mortbay/io/View$CaseInsensitive;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,24,0);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 23,24},new Method("Lorg/mortbay/io/BufferCache;","lookup",new String[]{ "Lorg/mortbay/io/Buffer;"},"Lorg/mortbay/io/Buffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,23);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_tok1","Lorg/mortbay/io/View$CaseInsensitive;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,24,0);
                code.visitConstStmt(CONST_16,25, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 22,23,24,25},new Method("Lorg/mortbay/jetty/HttpParser$EventHandler;","startRequest",new String[]{ "Lorg/mortbay/io/Buffer;","Lorg/mortbay/io/Buffer;","Lorg/mortbay/io/Buffer;"},"V"));
                code.visitLabel(L97);
                code.visitConstStmt(CONST_16,22, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitStmt2R(MOVE_FROM16,0,22);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,27);
                code.visitFieldStmt(IPUT,0,1,new Field("Lorg/mortbay/jetty/HttpParser;","_state","I"));
                code.visitLabel(L98);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_handler","Lorg/mortbay/jetty/HttpParser$EventHandler;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,22,0);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 22},new Method("Lorg/mortbay/jetty/HttpParser$EventHandler;","headerComplete",new String[]{ },"V"));
                code.visitLabel(L99);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_handler","Lorg/mortbay/jetty/HttpParser$EventHandler;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,22,0);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_WIDE,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_contentPosition","J"));
                code.visitStmt2R(MOVE_WIDE_FROM16,23,0);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 22,23,24},new Method("Lorg/mortbay/jetty/HttpParser$EventHandler;","messageComplete",new String[]{ "J"},"V"));
                code.visitStmt2R(MOVE_WIDE_FROM16,22,18);
                code.visitLabel(L100);
                code.visitJumpStmt(GOTO_16,-1,-1,L6);
                code.visitLabel(L101);
                code.visitConstStmt(CONST_16,22, Integer.valueOf(13)); // int: 0x0000000d  float:0.000000
                code.visitStmt2R(MOVE,0,6);
                code.visitStmt2R(MOVE_FROM16,1,22);
                code.visitJumpStmt(IF_EQ,0,1,L102);
                code.visitConstStmt(CONST_16,22, Integer.valueOf(10)); // int: 0x0000000a  float:0.000000
                code.visitStmt2R(MOVE,0,6);
                code.visitStmt2R(MOVE_FROM16,1,22);
                code.visitJumpStmt(IF_NE,0,1,L333);
                code.visitLabel(L102);
                code.visitFieldStmt(SGET_OBJECT,22,-1,new Field("Lorg/mortbay/jetty/HttpMethods;","CACHE","Lorg/mortbay/io/BufferCache;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_tok0","Lorg/mortbay/io/View$CaseInsensitive;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,23,0);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 22,23},new Method("Lorg/mortbay/io/BufferCache;","lookup",new String[]{ "Lorg/mortbay/io/Buffer;"},"Lorg/mortbay/io/Buffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,15);
                code.visitLabel(L103);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_tok0","Lorg/mortbay/io/View$CaseInsensitive;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,22,0);
                code.visitStmt2R(MOVE_OBJECT,0,15);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,22);
                code.visitJumpStmt(IF_NE,0,1,L112);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_tok1","Lorg/mortbay/io/View$CaseInsensitive;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,22,0);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 22},new Method("Lorg/mortbay/io/View$CaseInsensitive;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,22);
                code.visitConstStmt(CONST_16,23, Integer.valueOf(3)); // int: 0x00000003  float:0.000000
                code.visitStmt2R(MOVE_FROM16,0,22);
                code.visitStmt2R(MOVE_FROM16,1,23);
                code.visitJumpStmt(IF_NE,0,1,L112);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_tok1","Lorg/mortbay/io/View$CaseInsensitive;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,22,0);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 22},new Method("Lorg/mortbay/io/View$CaseInsensitive;","peek",new String[]{ },"B"));
                code.visitStmt1R(MOVE_RESULT,22);
                code.visitMethodStmt(INVOKE_STATIC_RANGE,new int[]{ 22},new Method("Ljava/lang/Character;","isDigit",new String[]{ "I"},"Z"));
                code.visitStmt1R(MOVE_RESULT,22);
                code.visitJumpStmt(IF_EQZ,22,-1,L112);
                code.visitLabel(L104);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_tok1","Lorg/mortbay/io/View$CaseInsensitive;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,22,0);
                code.visitMethodStmt(INVOKE_STATIC_RANGE,new int[]{ 22},new Method("Lorg/mortbay/io/BufferUtil;","toInt",new String[]{ "Lorg/mortbay/io/Buffer;"},"I"));
                code.visitStmt1R(MOVE_RESULT,22);
                code.visitStmt2R(MOVE_FROM16,0,22);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,27);
                code.visitFieldStmt(IPUT,0,1,new Field("Lorg/mortbay/jetty/HttpParser;","_responseStatus","I"));
                code.visitLabel(L105);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_handler","Lorg/mortbay/jetty/HttpParser$EventHandler;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,22,0);
                code.visitFieldStmt(SGET_OBJECT,23,-1,new Field("Lorg/mortbay/jetty/HttpVersions;","CACHE","Lorg/mortbay/io/BufferCache;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_tok0","Lorg/mortbay/io/View$CaseInsensitive;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,24,0);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 23,24},new Method("Lorg/mortbay/io/BufferCache;","lookup",new String[]{ "Lorg/mortbay/io/Buffer;"},"Lorg/mortbay/io/Buffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,23);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_responseStatus","I"));
                code.visitStmt2R(MOVE_FROM16,24,0);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_buffer","Lorg/mortbay/io/Buffer;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,25,0);
                code.visitMethodStmt(INVOKE_INTERFACE_RANGE,new int[]{ 25},new Method("Lorg/mortbay/io/Buffer;","sliceFromMark",new String[]{ },"Lorg/mortbay/io/Buffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,25);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 22,23,24,25},new Method("Lorg/mortbay/jetty/HttpParser$EventHandler;","startResponse",new String[]{ "Lorg/mortbay/io/Buffer;","I","Lorg/mortbay/io/Buffer;"},"V"));
                code.visitLabel(L106);
                code.visitStmt2R(MOVE,0,6);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,27);
                code.visitFieldStmt(IPUT_BYTE,0,1,new Field("Lorg/mortbay/jetty/HttpParser;","_eol","B"));
                code.visitLabel(L107);
                code.visitConstStmt(CONST_16,22, Integer.valueOf(-5)); // int: 0xfffffffb  float:NaN
                code.visitStmt2R(MOVE_FROM16,0,22);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,27);
                code.visitFieldStmt(IPUT,0,1,new Field("Lorg/mortbay/jetty/HttpParser;","_state","I"));
                code.visitLabel(L108);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_tok0","Lorg/mortbay/io/View$CaseInsensitive;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,22,0);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_tok0","Lorg/mortbay/io/View$CaseInsensitive;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,23,0);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 23},new Method("Lorg/mortbay/io/View$CaseInsensitive;","getIndex",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,23);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 22,23},new Method("Lorg/mortbay/io/View$CaseInsensitive;","setPutIndex",new String[]{ "I"},"V"));
                code.visitLabel(L109);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_tok1","Lorg/mortbay/io/View$CaseInsensitive;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,22,0);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_tok1","Lorg/mortbay/io/View$CaseInsensitive;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,23,0);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 23},new Method("Lorg/mortbay/io/View$CaseInsensitive;","getIndex",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,23);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 22,23},new Method("Lorg/mortbay/io/View$CaseInsensitive;","setPutIndex",new String[]{ "I"},"V"));
                code.visitLabel(L110);
                code.visitConstStmt(CONST_16,22, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,22);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,27);
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/jetty/HttpParser;","_multiLineValue","Ljava/lang/String;"));
                code.visitStmt2R(MOVE,13,14);
                code.visitLabel(L111);
                code.visitJumpStmt(GOTO_16,-1,-1,L54);
                code.visitLabel(L112);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_handler","Lorg/mortbay/jetty/HttpParser$EventHandler;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,22,0);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_tok1","Lorg/mortbay/io/View$CaseInsensitive;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,23,0);
                code.visitFieldStmt(SGET_OBJECT,24,-1,new Field("Lorg/mortbay/jetty/HttpVersions;","CACHE","Lorg/mortbay/io/BufferCache;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_buffer","Lorg/mortbay/io/Buffer;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,25,0);
                code.visitMethodStmt(INVOKE_INTERFACE_RANGE,new int[]{ 25},new Method("Lorg/mortbay/io/Buffer;","sliceFromMark",new String[]{ },"Lorg/mortbay/io/Buffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,25);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 24,25},new Method("Lorg/mortbay/io/BufferCache;","lookup",new String[]{ "Lorg/mortbay/io/Buffer;"},"Lorg/mortbay/io/Buffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,24);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,22);
                code.visitStmt2R(MOVE_OBJECT,1,15);
                code.visitStmt2R(MOVE_OBJECT_FROM16,2,23);
                code.visitStmt2R(MOVE_OBJECT_FROM16,3,24);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1,2,3},new Method("Lorg/mortbay/jetty/HttpParser$EventHandler;","startRequest",new String[]{ "Lorg/mortbay/io/Buffer;","Lorg/mortbay/io/Buffer;","Lorg/mortbay/io/Buffer;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L106);
                code.visitLabel(L113);
                code.visitSparseSwitchStmt(SPARSE_SWITCH,6,new int[]{ 9,32,58},new DexLabel[]{L138,L138,L138});
                code.visitLabel(L114);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_cached","Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,22,0);
                code.visitJumpStmt(IF_NEZ,22,-1,L115);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_tok0","Lorg/mortbay/io/View$CaseInsensitive;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,22,0);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 22},new Method("Lorg/mortbay/io/View$CaseInsensitive;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,22);
                code.visitJumpStmt(IF_GTZ,22,-1,L115);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_tok1","Lorg/mortbay/io/View$CaseInsensitive;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,22,0);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 22},new Method("Lorg/mortbay/io/View$CaseInsensitive;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,22);
                code.visitJumpStmt(IF_GTZ,22,-1,L115);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_multiLineValue","Ljava/lang/String;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,22,0);
                code.visitJumpStmt(IF_EQZ,22,-1,L126);
                code.visitLabel(L115);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_cached","Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,22,0);
                code.visitJumpStmt(IF_EQZ,22,-1,L141);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_cached","Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,22,0);
                code.visitStmt2R(MOVE_OBJECT_FROM16,10,22);
                code.visitLabel(L116);
                code.visitConstStmt(CONST_16,22, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,22);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,27);
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/jetty/HttpParser;","_cached","Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitLabel(L117);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_multiLineValue","Ljava/lang/String;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,22,0);
                code.visitJumpStmt(IF_NEZ,22,-1,L142);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_tok1","Lorg/mortbay/io/View$CaseInsensitive;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,22,0);
                code.visitStmt2R(MOVE_OBJECT_FROM16,20,22);
                code.visitLabel(L118);
                code.visitFieldStmt(SGET_OBJECT,22,-1,new Field("Lorg/mortbay/jetty/HttpHeaders;","CACHE","Lorg/mortbay/jetty/HttpHeaders;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,22);
                code.visitStmt2R(MOVE_OBJECT,1,10);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Lorg/mortbay/jetty/HttpHeaders;","getOrdinal",new String[]{ "Lorg/mortbay/io/Buffer;"},"I"));
                code.visitStmt1R(MOVE_RESULT,11);
                code.visitLabel(L119);
                code.visitJumpStmt(IF_LTZ,11,-1,L122);
                code.visitLabel(L120);
                code.visitConstStmt(CONST_16,21, Integer.valueOf(-1)); // int: 0xffffffff  float:NaN
                code.visitLabel(L121);
                code.visitSparseSwitchStmt(SPARSE_SWITCH,11,new int[]{ 5,12},new DexLabel[]{L147,L143});
                code.visitLabel(L122);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_handler","Lorg/mortbay/jetty/HttpParser$EventHandler;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,22,0);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,22);
                code.visitStmt2R(MOVE_OBJECT,1,10);
                code.visitStmt2R(MOVE_OBJECT_FROM16,2,20);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1,2},new Method("Lorg/mortbay/jetty/HttpParser$EventHandler;","parsedHeader",new String[]{ "Lorg/mortbay/io/Buffer;","Lorg/mortbay/io/Buffer;"},"V"));
                code.visitLabel(L123);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_tok0","Lorg/mortbay/io/View$CaseInsensitive;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,22,0);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_tok0","Lorg/mortbay/io/View$CaseInsensitive;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,23,0);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 23},new Method("Lorg/mortbay/io/View$CaseInsensitive;","getIndex",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,23);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 22,23},new Method("Lorg/mortbay/io/View$CaseInsensitive;","setPutIndex",new String[]{ "I"},"V"));
                code.visitLabel(L124);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_tok1","Lorg/mortbay/io/View$CaseInsensitive;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,22,0);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_tok1","Lorg/mortbay/io/View$CaseInsensitive;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,23,0);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 23},new Method("Lorg/mortbay/io/View$CaseInsensitive;","getIndex",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,23);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 22,23},new Method("Lorg/mortbay/io/View$CaseInsensitive;","setPutIndex",new String[]{ "I"},"V"));
                code.visitLabel(L125);
                code.visitConstStmt(CONST_16,22, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,22);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,27);
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/jetty/HttpParser;","_multiLineValue","Ljava/lang/String;"));
                code.visitLabel(L126);
                code.visitConstStmt(CONST_16,22, Integer.valueOf(13)); // int: 0x0000000d  float:0.000000
                code.visitStmt2R(MOVE,0,6);
                code.visitStmt2R(MOVE_FROM16,1,22);
                code.visitJumpStmt(IF_EQ,0,1,L127);
                code.visitConstStmt(CONST_16,22, Integer.valueOf(10)); // int: 0x0000000a  float:0.000000
                code.visitStmt2R(MOVE,0,6);
                code.visitStmt2R(MOVE_FROM16,1,22);
                code.visitJumpStmt(IF_NE,0,1,L169);
                code.visitLabel(L127);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_WIDE,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_contentLength","J"));
                code.visitStmt2R(MOVE_WIDE_FROM16,22,0);
                code.visitConstStmt(CONST_WIDE_16,24,Long.valueOf(-3L)); // long: 0xfffffffffffffffd  double:NaN
                code.visitStmt3R(CMP_LONG,22,22,24);
                code.visitJumpStmt(IF_NEZ,22,-1,L130);
                code.visitLabel(L128);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_responseStatus","I"));
                code.visitStmt2R(MOVE_FROM16,22,0);
                code.visitJumpStmt(IF_EQZ,22,-1,L129);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_responseStatus","I"));
                code.visitStmt2R(MOVE_FROM16,22,0);
                code.visitConstStmt(CONST_16,23, Integer.valueOf(304)); // int: 0x00000130  float:0.000000
                code.visitStmt2R(MOVE_FROM16,0,22);
                code.visitStmt2R(MOVE_FROM16,1,23);
                code.visitJumpStmt(IF_EQ,0,1,L129);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_responseStatus","I"));
                code.visitStmt2R(MOVE_FROM16,22,0);
                code.visitConstStmt(CONST_16,23, Integer.valueOf(204)); // int: 0x000000cc  float:0.000000
                code.visitStmt2R(MOVE_FROM16,0,22);
                code.visitStmt2R(MOVE_FROM16,1,23);
                code.visitJumpStmt(IF_EQ,0,1,L129);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_responseStatus","I"));
                code.visitStmt2R(MOVE_FROM16,22,0);
                code.visitConstStmt(CONST_16,23, Integer.valueOf(200)); // int: 0x000000c8  float:0.000000
                code.visitStmt2R(MOVE_FROM16,0,22);
                code.visitStmt2R(MOVE_FROM16,1,23);
                code.visitJumpStmt(IF_GE,0,1,L156);
                code.visitLabel(L129);
                code.visitConstStmt(CONST_WIDE_16,22,Long.valueOf(0L)); // long: 0x0000000000000000  double:0.000000
                code.visitStmt2R(MOVE_WIDE_FROM16,0,22);
                code.visitStmt2R(MOVE_OBJECT_FROM16,2,27);
                code.visitFieldStmt(IPUT_WIDE,0,2,new Field("Lorg/mortbay/jetty/HttpParser;","_contentLength","J"));
                code.visitLabel(L130);
                code.visitConstStmt(CONST_WIDE_16,22,Long.valueOf(0L)); // long: 0x0000000000000000  double:0.000000
                code.visitStmt2R(MOVE_WIDE_FROM16,0,22);
                code.visitStmt2R(MOVE_OBJECT_FROM16,2,27);
                code.visitFieldStmt(IPUT_WIDE,0,2,new Field("Lorg/mortbay/jetty/HttpParser;","_contentPosition","J"));
                code.visitLabel(L131);
                code.visitStmt2R(MOVE,0,6);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,27);
                code.visitFieldStmt(IPUT_BYTE,0,1,new Field("Lorg/mortbay/jetty/HttpParser;","_eol","B"));
                code.visitLabel(L132);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_WIDE,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_contentLength","J"));
                code.visitStmt2R(MOVE_WIDE_FROM16,22,0);
                code.visitConstStmt(CONST_WIDE_32,24,Long.valueOf(2147483647L)); // long: 0x000000007fffffff  double:0.000000
                code.visitStmt3R(CMP_LONG,22,22,24);
                code.visitJumpStmt(IF_LEZ,22,-1,L157);
                code.visitConstStmt(CONST,22, Integer.valueOf(2147483647)); // int: 0x7fffffff  float:NaN
                DexLabel L334=new DexLabel();
                code.visitLabel(L334);
                code.visitSparseSwitchStmt(PACKED_SWITCH,22,-2,new DexLabel[]{L162,L158,L166});
                code.visitLabel(L133);
                code.visitConstStmt(CONST_16,22, Integer.valueOf(2)); // int: 0x00000002  float:0.000000
                code.visitStmt2R(MOVE_FROM16,0,22);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,27);
                code.visitFieldStmt(IPUT,0,1,new Field("Lorg/mortbay/jetty/HttpParser;","_state","I"));
                code.visitLabel(L134);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_BOOLEAN,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_forceContentBuffer","Z"));
                code.visitStmt2R(MOVE_FROM16,22,0);
                code.visitJumpStmt(IF_NEZ,22,-1,L135);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_buffers","Lorg/mortbay/io/Buffers;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,22,0);
                code.visitJumpStmt(IF_EQZ,22,-1,L136);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_body","Lorg/mortbay/io/Buffer;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,22,0);
                code.visitJumpStmt(IF_NEZ,22,-1,L136);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_buffer","Lorg/mortbay/io/Buffer;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,22,0);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_header","Lorg/mortbay/io/Buffer;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,23,0);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,22);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,23);
                code.visitJumpStmt(IF_NE,0,1,L136);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_WIDE,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_contentLength","J"));
                code.visitStmt2R(MOVE_WIDE_FROM16,22,0);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_header","Lorg/mortbay/io/Buffer;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,24,0);
                code.visitMethodStmt(INVOKE_INTERFACE_RANGE,new int[]{ 24},new Method("Lorg/mortbay/io/Buffer;","capacity",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,24);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_header","Lorg/mortbay/io/Buffer;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,25,0);
                code.visitMethodStmt(INVOKE_INTERFACE_RANGE,new int[]{ 25},new Method("Lorg/mortbay/io/Buffer;","getIndex",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,25);
                code.visitStmt3R(SUB_INT,24,24,25);
                code.visitStmt2R(MOVE_FROM16,0,24);
                code.visitStmt2R(INT_TO_LONG,0,0);
                code.visitStmt2R(MOVE_WIDE_FROM16,24,0);
                code.visitStmt3R(CMP_LONG,22,22,24);
                code.visitJumpStmt(IF_LTZ,22,-1,L136);
                code.visitLabel(L135);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_buffers","Lorg/mortbay/io/Buffers;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,22,0);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_contentBufferSize","I"));
                code.visitStmt2R(MOVE_FROM16,23,0);
                code.visitMethodStmt(INVOKE_INTERFACE_RANGE,new int[]{ 22,23},new Method("Lorg/mortbay/io/Buffers;","getBuffer",new String[]{ "I"},"Lorg/mortbay/io/Buffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,22);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,22);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,27);
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/jetty/HttpParser;","_body","Lorg/mortbay/io/Buffer;"));
                code.visitLabel(L136);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_handler","Lorg/mortbay/jetty/HttpParser$EventHandler;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,22,0);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 22},new Method("Lorg/mortbay/jetty/HttpParser$EventHandler;","headerComplete",new String[]{ },"V"));
                DexLabel L335=new DexLabel();
                code.visitLabel(L335);
                code.visitStmt2R(MOVE_WIDE_FROM16,22,18);
                code.visitLabel(L137);
                code.visitJumpStmt(GOTO_16,-1,-1,L6);
                code.visitLabel(L138);
                code.visitConstStmt(CONST_16,22, Integer.valueOf(-1)); // int: 0xffffffff  float:NaN
                code.visitStmt2R(MOVE_FROM16,0,22);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,27);
                code.visitFieldStmt(IPUT,0,1,new Field("Lorg/mortbay/jetty/HttpParser;","_length","I"));
                code.visitLabel(L139);
                code.visitConstStmt(CONST_16,22, Integer.valueOf(-2)); // int: 0xfffffffe  float:NaN
                code.visitStmt2R(MOVE_FROM16,0,22);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,27);
                code.visitFieldStmt(IPUT,0,1,new Field("Lorg/mortbay/jetty/HttpParser;","_state","I"));
                code.visitStmt2R(MOVE,13,14);
                code.visitLabel(L140);
                code.visitJumpStmt(GOTO_16,-1,-1,L54);
                code.visitLabel(L141);
                code.visitFieldStmt(SGET_OBJECT,22,-1,new Field("Lorg/mortbay/jetty/HttpHeaders;","CACHE","Lorg/mortbay/jetty/HttpHeaders;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_tok0","Lorg/mortbay/io/View$CaseInsensitive;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,23,0);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 22,23},new Method("Lorg/mortbay/jetty/HttpHeaders;","lookup",new String[]{ "Lorg/mortbay/io/Buffer;"},"Lorg/mortbay/io/Buffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,22);
                code.visitStmt2R(MOVE_OBJECT_FROM16,10,22);
                code.visitJumpStmt(GOTO_16,-1,-1,L116);
                code.visitLabel(L142);
                code.visitTypeStmt(NEW_INSTANCE,22,-1,"Lorg/mortbay/io/ByteArrayBuffer;");
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_multiLineValue","Ljava/lang/String;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,23,0);
                code.visitMethodStmt(INVOKE_DIRECT_RANGE,new int[]{ 22,23},new Method("Lorg/mortbay/io/ByteArrayBuffer;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,20,22);
                code.visitJumpStmt(GOTO_16,-1,-1,L118);
                code.visitLabel(L143);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_WIDE,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_contentLength","J"));
                code.visitStmt2R(MOVE_WIDE_FROM16,22,0);
                code.visitConstStmt(CONST_WIDE_16,24,Long.valueOf(-2L)); // long: 0xfffffffffffffffe  double:NaN
                code.visitStmt3R(CMP_LONG,22,22,24);
                code.visitJumpStmt(IF_EQZ,22,-1,L122);
                code.visitLabel(L144);
                code.visitMethodStmt(INVOKE_STATIC_RANGE,new int[]{ 20},new Method("Lorg/mortbay/io/BufferUtil;","toLong",new String[]{ "Lorg/mortbay/io/Buffer;"},"J"));
                code.visitStmt1R(MOVE_RESULT_WIDE,22);
                code.visitStmt2R(MOVE_WIDE_FROM16,0,22);
                code.visitStmt2R(MOVE_OBJECT_FROM16,2,27);
                code.visitFieldStmt(IPUT_WIDE,0,2,new Field("Lorg/mortbay/jetty/HttpParser;","_contentLength","J"));
                code.visitLabel(L145);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_WIDE,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_contentLength","J"));
                code.visitStmt2R(MOVE_WIDE_FROM16,22,0);
                code.visitConstStmt(CONST_WIDE_16,24,Long.valueOf(0L)); // long: 0x0000000000000000  double:0.000000
                code.visitStmt3R(CMP_LONG,22,22,24);
                code.visitJumpStmt(IF_GTZ,22,-1,L122);
                code.visitLabel(L146);
                code.visitConstStmt(CONST_WIDE_16,22,Long.valueOf(0L)); // long: 0x0000000000000000  double:0.000000
                code.visitStmt2R(MOVE_WIDE_FROM16,0,22);
                code.visitStmt2R(MOVE_OBJECT_FROM16,2,27);
                code.visitFieldStmt(IPUT_WIDE,0,2,new Field("Lorg/mortbay/jetty/HttpParser;","_contentLength","J"));
                code.visitJumpStmt(GOTO_16,-1,-1,L122);
                code.visitLabel(L147);
                code.visitFieldStmt(SGET_OBJECT,22,-1,new Field("Lorg/mortbay/jetty/HttpHeaderValues;","CACHE","Lorg/mortbay/jetty/HttpHeaderValues;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,22);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,20);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Lorg/mortbay/jetty/HttpHeaderValues;","lookup",new String[]{ "Lorg/mortbay/io/Buffer;"},"Lorg/mortbay/io/Buffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,20);
                code.visitLabel(L148);
                code.visitFieldStmt(SGET_OBJECT,22,-1,new Field("Lorg/mortbay/jetty/HttpHeaderValues;","CACHE","Lorg/mortbay/jetty/HttpHeaderValues;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,22);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,20);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Lorg/mortbay/jetty/HttpHeaderValues;","getOrdinal",new String[]{ "Lorg/mortbay/io/Buffer;"},"I"));
                code.visitStmt1R(MOVE_RESULT,21);
                code.visitLabel(L149);
                code.visitConstStmt(CONST_16,22, Integer.valueOf(2)); // int: 0x00000002  float:0.000000
                code.visitStmt2R(MOVE_FROM16,0,22);
                code.visitStmt2R(MOVE_FROM16,1,21);
                code.visitJumpStmt(IF_NE,0,1,L151);
                code.visitLabel(L150);
                code.visitConstStmt(CONST_WIDE_16,22,Long.valueOf(-2L)); // long: 0xfffffffffffffffe  double:NaN
                code.visitStmt2R(MOVE_WIDE_FROM16,0,22);
                code.visitStmt2R(MOVE_OBJECT_FROM16,2,27);
                code.visitFieldStmt(IPUT_WIDE,0,2,new Field("Lorg/mortbay/jetty/HttpParser;","_contentLength","J"));
                code.visitJumpStmt(GOTO_16,-1,-1,L122);
                code.visitLabel(L151);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 20},new Method("Ljava/lang/Object;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitLabel(L152);
                code.visitConstStmt(CONST_STRING,22,"chunked");
                code.visitStmt2R(MOVE_OBJECT,0,5);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,22);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/String;","endsWith",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,22);
                code.visitJumpStmt(IF_EQZ,22,-1,L154);
                code.visitLabel(L153);
                code.visitConstStmt(CONST_WIDE_16,22,Long.valueOf(-2L)); // long: 0xfffffffffffffffe  double:NaN
                code.visitStmt2R(MOVE_WIDE_FROM16,0,22);
                code.visitStmt2R(MOVE_OBJECT_FROM16,2,27);
                code.visitFieldStmt(IPUT_WIDE,0,2,new Field("Lorg/mortbay/jetty/HttpParser;","_contentLength","J"));
                code.visitJumpStmt(GOTO_16,-1,-1,L122);
                code.visitLabel(L154);
                code.visitConstStmt(CONST_STRING,22,"chunked");
                code.visitStmt2R(MOVE_OBJECT,0,5);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,22);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/String;","indexOf",new String[]{ "Ljava/lang/String;"},"I"));
                code.visitStmt1R(MOVE_RESULT,22);
                code.visitJumpStmt(IF_LTZ,22,-1,L122);
                code.visitLabel(L155);
                code.visitTypeStmt(NEW_INSTANCE,22,-1,"Lorg/mortbay/jetty/HttpException;");
                code.visitConstStmt(CONST_16,23, Integer.valueOf(400)); // int: 0x00000190  float:0.000000
                code.visitConstStmt(CONST_16,24, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_DIRECT_RANGE,new int[]{ 22,23,24},new Method("Lorg/mortbay/jetty/HttpException;","<init>",new String[]{ "I","Ljava/lang/String;"},"V"));
                code.visitStmt1R(THROW,22);
                code.visitLabel(L156);
                code.visitConstStmt(CONST_WIDE_16,22,Long.valueOf(-1L)); // long: 0xffffffffffffffff  double:NaN
                code.visitStmt2R(MOVE_WIDE_FROM16,0,22);
                code.visitStmt2R(MOVE_OBJECT_FROM16,2,27);
                code.visitFieldStmt(IPUT_WIDE,0,2,new Field("Lorg/mortbay/jetty/HttpParser;","_contentLength","J"));
                code.visitJumpStmt(GOTO_16,-1,-1,L130);
                code.visitLabel(L157);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_WIDE,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_contentLength","J"));
                code.visitStmt2R(MOVE_WIDE_FROM16,22,0);
                code.visitStmt2R(MOVE_WIDE_FROM16,0,22);
                code.visitStmt2R(LONG_TO_INT,0,0);
                code.visitStmt2R(MOVE_FROM16,22,0);
                code.visitJumpStmt(GOTO_16,-1,-1,L334);
                code.visitLabel(L158);
                code.visitConstStmt(CONST_16,22, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitStmt2R(MOVE_FROM16,0,22);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,27);
                code.visitFieldStmt(IPUT,0,1,new Field("Lorg/mortbay/jetty/HttpParser;","_state","I"));
                code.visitLabel(L159);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_body","Lorg/mortbay/io/Buffer;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,22,0);
                code.visitJumpStmt(IF_NEZ,22,-1,L161);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_buffers","Lorg/mortbay/io/Buffers;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,22,0);
                code.visitJumpStmt(IF_EQZ,22,-1,L161);
                code.visitLabel(L160);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_buffers","Lorg/mortbay/io/Buffers;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,22,0);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_contentBufferSize","I"));
                code.visitStmt2R(MOVE_FROM16,23,0);
                code.visitMethodStmt(INVOKE_INTERFACE_RANGE,new int[]{ 22,23},new Method("Lorg/mortbay/io/Buffers;","getBuffer",new String[]{ "I"},"Lorg/mortbay/io/Buffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,22);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,22);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,27);
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/jetty/HttpParser;","_body","Lorg/mortbay/io/Buffer;"));
                code.visitLabel(L161);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_handler","Lorg/mortbay/jetty/HttpParser$EventHandler;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,22,0);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 22},new Method("Lorg/mortbay/jetty/HttpParser$EventHandler;","headerComplete",new String[]{ },"V"));
                code.visitJumpStmt(GOTO_16,-1,-1,L335);
                code.visitLabel(L162);
                code.visitConstStmt(CONST_16,22, Integer.valueOf(3)); // int: 0x00000003  float:0.000000
                code.visitStmt2R(MOVE_FROM16,0,22);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,27);
                code.visitFieldStmt(IPUT,0,1,new Field("Lorg/mortbay/jetty/HttpParser;","_state","I"));
                code.visitLabel(L163);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_body","Lorg/mortbay/io/Buffer;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,22,0);
                code.visitJumpStmt(IF_NEZ,22,-1,L165);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_buffers","Lorg/mortbay/io/Buffers;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,22,0);
                code.visitJumpStmt(IF_EQZ,22,-1,L165);
                code.visitLabel(L164);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_buffers","Lorg/mortbay/io/Buffers;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,22,0);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_contentBufferSize","I"));
                code.visitStmt2R(MOVE_FROM16,23,0);
                code.visitMethodStmt(INVOKE_INTERFACE_RANGE,new int[]{ 22,23},new Method("Lorg/mortbay/io/Buffers;","getBuffer",new String[]{ "I"},"Lorg/mortbay/io/Buffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,22);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,22);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,27);
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/jetty/HttpParser;","_body","Lorg/mortbay/io/Buffer;"));
                code.visitLabel(L165);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_handler","Lorg/mortbay/jetty/HttpParser$EventHandler;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,22,0);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 22},new Method("Lorg/mortbay/jetty/HttpParser$EventHandler;","headerComplete",new String[]{ },"V"));
                code.visitJumpStmt(GOTO_16,-1,-1,L335);
                code.visitLabel(L166);
                code.visitConstStmt(CONST_16,22, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitStmt2R(MOVE_FROM16,0,22);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,27);
                code.visitFieldStmt(IPUT,0,1,new Field("Lorg/mortbay/jetty/HttpParser;","_state","I"));
                code.visitLabel(L167);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_handler","Lorg/mortbay/jetty/HttpParser$EventHandler;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,22,0);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 22},new Method("Lorg/mortbay/jetty/HttpParser$EventHandler;","headerComplete",new String[]{ },"V"));
                code.visitLabel(L168);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_handler","Lorg/mortbay/jetty/HttpParser$EventHandler;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,22,0);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_WIDE,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_contentPosition","J"));
                code.visitStmt2R(MOVE_WIDE_FROM16,23,0);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 22,23,24},new Method("Lorg/mortbay/jetty/HttpParser$EventHandler;","messageComplete",new String[]{ "J"},"V"));
                code.visitJumpStmt(GOTO_16,-1,-1,L335);
                code.visitLabel(L169);
                code.visitConstStmt(CONST_16,22, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitStmt2R(MOVE_FROM16,0,22);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,27);
                code.visitFieldStmt(IPUT,0,1,new Field("Lorg/mortbay/jetty/HttpParser;","_length","I"));
                code.visitLabel(L170);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_buffer","Lorg/mortbay/io/Buffer;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,22,0);
                code.visitMethodStmt(INVOKE_INTERFACE_RANGE,new int[]{ 22},new Method("Lorg/mortbay/io/Buffer;","mark",new String[]{ },"V"));
                code.visitLabel(L171);
                code.visitConstStmt(CONST_16,22, Integer.valueOf(-4)); // int: 0xfffffffc  float:NaN
                code.visitStmt2R(MOVE_FROM16,0,22);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,27);
                code.visitFieldStmt(IPUT,0,1,new Field("Lorg/mortbay/jetty/HttpParser;","_state","I"));
                code.visitLabel(L172);
                code.visitJumpStmt(IF_EQZ,4,-1,L333);
                code.visitLabel(L173);
                code.visitFieldStmt(SGET_OBJECT,22,-1,new Field("Lorg/mortbay/jetty/HttpHeaders;","CACHE","Lorg/mortbay/jetty/HttpHeaders;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_buffer","Lorg/mortbay/io/Buffer;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,23,0);
                code.visitMethodStmt(INVOKE_INTERFACE_RANGE,new int[]{ 23},new Method("Lorg/mortbay/io/Buffer;","markIndex",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,23);
                code.visitStmt2R1N(ADD_INT_LIT8,24,14,1);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,22);
                code.visitStmt2R(MOVE_OBJECT,1,4);
                code.visitStmt2R(MOVE_FROM16,2,23);
                code.visitStmt2R(MOVE_FROM16,3,24);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1,2,3},new Method("Lorg/mortbay/jetty/HttpHeaders;","getBest",new String[]{ "[B","I","I"},"Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,22);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,22);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,27);
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/jetty/HttpParser;","_cached","Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitLabel(L174);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_cached","Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,22,0);
                code.visitJumpStmt(IF_EQZ,22,-1,L333);
                code.visitLabel(L175);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_cached","Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,22,0);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 22},new Method("Lorg/mortbay/io/BufferCache$CachedBuffer;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,22);
                code.visitStmt2R(MOVE_FROM16,0,22);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,27);
                code.visitFieldStmt(IPUT,0,1,new Field("Lorg/mortbay/jetty/HttpParser;","_length","I"));
                code.visitLabel(L176);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_buffer","Lorg/mortbay/io/Buffer;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,22,0);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_buffer","Lorg/mortbay/io/Buffer;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,23,0);
                code.visitMethodStmt(INVOKE_INTERFACE_RANGE,new int[]{ 23},new Method("Lorg/mortbay/io/Buffer;","markIndex",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,23);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_length","I"));
                code.visitStmt2R(MOVE_FROM16,24,0);
                code.visitStmt3R(ADD_INT,23,23,24);
                code.visitMethodStmt(INVOKE_INTERFACE_RANGE,new int[]{ 22,23},new Method("Lorg/mortbay/io/Buffer;","setGetIndex",new String[]{ "I"},"V"));
                code.visitLabel(L177);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_buffer","Lorg/mortbay/io/Buffer;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,22,0);
                code.visitMethodStmt(INVOKE_INTERFACE_RANGE,new int[]{ 22},new Method("Lorg/mortbay/io/Buffer;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,13);
                code.visitLabel(L178);
                code.visitJumpStmt(GOTO_16,-1,-1,L54);
                code.visitLabel(L179);
                code.visitSparseSwitchStmt(SPARSE_SWITCH,6,new int[]{ 9,10,13,32,58},new DexLabel[]{L196,L186,L186,L196,L191});
                code.visitLabel(L180);
                code.visitConstStmt(CONST_16,22, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,22);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,27);
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/jetty/HttpParser;","_cached","Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitLabel(L181);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_length","I"));
                code.visitStmt2R(MOVE_FROM16,22,0);
                code.visitConstStmt(CONST_16,23, Integer.valueOf(-1)); // int: 0xffffffff  float:NaN
                code.visitStmt2R(MOVE_FROM16,0,22);
                code.visitStmt2R(MOVE_FROM16,1,23);
                code.visitJumpStmt(IF_NE,0,1,L183);
                code.visitLabel(L182);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_buffer","Lorg/mortbay/io/Buffer;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,22,0);
                code.visitMethodStmt(INVOKE_INTERFACE_RANGE,new int[]{ 22},new Method("Lorg/mortbay/io/Buffer;","mark",new String[]{ },"V"));
                code.visitLabel(L183);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_buffer","Lorg/mortbay/io/Buffer;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,22,0);
                code.visitMethodStmt(INVOKE_INTERFACE_RANGE,new int[]{ 22},new Method("Lorg/mortbay/io/Buffer;","getIndex",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,22);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_buffer","Lorg/mortbay/io/Buffer;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,23,0);
                code.visitMethodStmt(INVOKE_INTERFACE_RANGE,new int[]{ 23},new Method("Lorg/mortbay/io/Buffer;","markIndex",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,23);
                code.visitStmt3R(SUB_INT,22,22,23);
                code.visitStmt2R(MOVE_FROM16,0,22);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,27);
                code.visitFieldStmt(IPUT,0,1,new Field("Lorg/mortbay/jetty/HttpParser;","_length","I"));
                code.visitLabel(L184);
                code.visitConstStmt(CONST_16,22, Integer.valueOf(-3)); // int: 0xfffffffd  float:NaN
                code.visitStmt2R(MOVE_FROM16,0,22);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,27);
                code.visitFieldStmt(IPUT,0,1,new Field("Lorg/mortbay/jetty/HttpParser;","_state","I"));
                code.visitStmt2R(MOVE,13,14);
                code.visitLabel(L185);
                code.visitJumpStmt(GOTO_16,-1,-1,L54);
                code.visitLabel(L186);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_length","I"));
                code.visitStmt2R(MOVE_FROM16,22,0);
                code.visitJumpStmt(IF_LEZ,22,-1,L188);
                code.visitLabel(L187);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_tok0","Lorg/mortbay/io/View$CaseInsensitive;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,22,0);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_buffer","Lorg/mortbay/io/Buffer;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,23,0);
                code.visitMethodStmt(INVOKE_INTERFACE_RANGE,new int[]{ 23},new Method("Lorg/mortbay/io/Buffer;","markIndex",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,23);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_buffer","Lorg/mortbay/io/Buffer;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,24,0);
                code.visitMethodStmt(INVOKE_INTERFACE_RANGE,new int[]{ 24},new Method("Lorg/mortbay/io/Buffer;","markIndex",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,24);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_length","I"));
                code.visitStmt2R(MOVE_FROM16,25,0);
                code.visitStmt3R(ADD_INT,24,24,25);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 22,23,24},new Method("Lorg/mortbay/io/View$CaseInsensitive;","update",new String[]{ "I","I"},"V"));
                code.visitLabel(L188);
                code.visitStmt2R(MOVE,0,6);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,27);
                code.visitFieldStmt(IPUT_BYTE,0,1,new Field("Lorg/mortbay/jetty/HttpParser;","_eol","B"));
                code.visitLabel(L189);
                code.visitConstStmt(CONST_16,22, Integer.valueOf(-5)); // int: 0xfffffffb  float:NaN
                code.visitStmt2R(MOVE_FROM16,0,22);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,27);
                code.visitFieldStmt(IPUT,0,1,new Field("Lorg/mortbay/jetty/HttpParser;","_state","I"));
                code.visitStmt2R(MOVE,13,14);
                code.visitLabel(L190);
                code.visitJumpStmt(GOTO_16,-1,-1,L54);
                code.visitLabel(L191);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_length","I"));
                code.visitStmt2R(MOVE_FROM16,22,0);
                code.visitJumpStmt(IF_LEZ,22,-1,L193);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_cached","Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,22,0);
                code.visitJumpStmt(IF_NEZ,22,-1,L193);
                code.visitLabel(L192);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_tok0","Lorg/mortbay/io/View$CaseInsensitive;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,22,0);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_buffer","Lorg/mortbay/io/Buffer;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,23,0);
                code.visitMethodStmt(INVOKE_INTERFACE_RANGE,new int[]{ 23},new Method("Lorg/mortbay/io/Buffer;","markIndex",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,23);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_buffer","Lorg/mortbay/io/Buffer;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,24,0);
                code.visitMethodStmt(INVOKE_INTERFACE_RANGE,new int[]{ 24},new Method("Lorg/mortbay/io/Buffer;","markIndex",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,24);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_length","I"));
                code.visitStmt2R(MOVE_FROM16,25,0);
                code.visitStmt3R(ADD_INT,24,24,25);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 22,23,24},new Method("Lorg/mortbay/io/View$CaseInsensitive;","update",new String[]{ "I","I"},"V"));
                code.visitLabel(L193);
                code.visitConstStmt(CONST_16,22, Integer.valueOf(-1)); // int: 0xffffffff  float:NaN
                code.visitStmt2R(MOVE_FROM16,0,22);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,27);
                code.visitFieldStmt(IPUT,0,1,new Field("Lorg/mortbay/jetty/HttpParser;","_length","I"));
                code.visitLabel(L194);
                code.visitConstStmt(CONST_16,22, Integer.valueOf(-2)); // int: 0xfffffffe  float:NaN
                code.visitStmt2R(MOVE_FROM16,0,22);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,27);
                code.visitFieldStmt(IPUT,0,1,new Field("Lorg/mortbay/jetty/HttpParser;","_state","I"));
                code.visitStmt2R(MOVE,13,14);
                code.visitLabel(L195);
                code.visitJumpStmt(GOTO_16,-1,-1,L54);
                code.visitLabel(L196);
                code.visitStmt2R(MOVE,13,14);
                code.visitLabel(L197);
                code.visitJumpStmt(GOTO_16,-1,-1,L54);
                code.visitLabel(L198);
                code.visitSparseSwitchStmt(SPARSE_SWITCH,6,new int[]{ 9,10,13,32,58},new DexLabel[]{L212,L202,L202,L212,L207});
                code.visitLabel(L199);
                code.visitConstStmt(CONST_16,22, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,22);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,27);
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/jetty/HttpParser;","_cached","Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitLabel(L200);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_length","I"));
                code.visitStmt2R(MOVE_FROM16,22,0);
                code.visitStmt2R1N(ADD_INT_LIT8,22,22,1);
                code.visitStmt2R(MOVE_FROM16,0,22);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,27);
                code.visitFieldStmt(IPUT,0,1,new Field("Lorg/mortbay/jetty/HttpParser;","_length","I"));
                code.visitStmt2R(MOVE,13,14);
                code.visitLabel(L201);
                code.visitJumpStmt(GOTO_16,-1,-1,L54);
                code.visitLabel(L202);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_length","I"));
                code.visitStmt2R(MOVE_FROM16,22,0);
                code.visitJumpStmt(IF_LEZ,22,-1,L204);
                code.visitLabel(L203);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_tok0","Lorg/mortbay/io/View$CaseInsensitive;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,22,0);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_buffer","Lorg/mortbay/io/Buffer;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,23,0);
                code.visitMethodStmt(INVOKE_INTERFACE_RANGE,new int[]{ 23},new Method("Lorg/mortbay/io/Buffer;","markIndex",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,23);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_buffer","Lorg/mortbay/io/Buffer;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,24,0);
                code.visitMethodStmt(INVOKE_INTERFACE_RANGE,new int[]{ 24},new Method("Lorg/mortbay/io/Buffer;","markIndex",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,24);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_length","I"));
                code.visitStmt2R(MOVE_FROM16,25,0);
                code.visitStmt3R(ADD_INT,24,24,25);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 22,23,24},new Method("Lorg/mortbay/io/View$CaseInsensitive;","update",new String[]{ "I","I"},"V"));
                code.visitLabel(L204);
                code.visitStmt2R(MOVE,0,6);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,27);
                code.visitFieldStmt(IPUT_BYTE,0,1,new Field("Lorg/mortbay/jetty/HttpParser;","_eol","B"));
                code.visitLabel(L205);
                code.visitConstStmt(CONST_16,22, Integer.valueOf(-5)); // int: 0xfffffffb  float:NaN
                code.visitStmt2R(MOVE_FROM16,0,22);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,27);
                code.visitFieldStmt(IPUT,0,1,new Field("Lorg/mortbay/jetty/HttpParser;","_state","I"));
                code.visitStmt2R(MOVE,13,14);
                code.visitLabel(L206);
                code.visitJumpStmt(GOTO_16,-1,-1,L54);
                code.visitLabel(L207);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_length","I"));
                code.visitStmt2R(MOVE_FROM16,22,0);
                code.visitJumpStmt(IF_LEZ,22,-1,L209);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_cached","Lorg/mortbay/io/BufferCache$CachedBuffer;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,22,0);
                code.visitJumpStmt(IF_NEZ,22,-1,L209);
                code.visitLabel(L208);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_tok0","Lorg/mortbay/io/View$CaseInsensitive;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,22,0);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_buffer","Lorg/mortbay/io/Buffer;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,23,0);
                code.visitMethodStmt(INVOKE_INTERFACE_RANGE,new int[]{ 23},new Method("Lorg/mortbay/io/Buffer;","markIndex",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,23);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_buffer","Lorg/mortbay/io/Buffer;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,24,0);
                code.visitMethodStmt(INVOKE_INTERFACE_RANGE,new int[]{ 24},new Method("Lorg/mortbay/io/Buffer;","markIndex",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,24);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_length","I"));
                code.visitStmt2R(MOVE_FROM16,25,0);
                code.visitStmt3R(ADD_INT,24,24,25);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 22,23,24},new Method("Lorg/mortbay/io/View$CaseInsensitive;","update",new String[]{ "I","I"},"V"));
                code.visitLabel(L209);
                code.visitConstStmt(CONST_16,22, Integer.valueOf(-1)); // int: 0xffffffff  float:NaN
                code.visitStmt2R(MOVE_FROM16,0,22);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,27);
                code.visitFieldStmt(IPUT,0,1,new Field("Lorg/mortbay/jetty/HttpParser;","_length","I"));
                code.visitLabel(L210);
                code.visitConstStmt(CONST_16,22, Integer.valueOf(-2)); // int: 0xfffffffe  float:NaN
                code.visitStmt2R(MOVE_FROM16,0,22);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,27);
                code.visitFieldStmt(IPUT,0,1,new Field("Lorg/mortbay/jetty/HttpParser;","_state","I"));
                code.visitStmt2R(MOVE,13,14);
                code.visitLabel(L211);
                code.visitJumpStmt(GOTO_16,-1,-1,L54);
                code.visitLabel(L212);
                code.visitConstStmt(CONST_16,22, Integer.valueOf(-4)); // int: 0xfffffffc  float:NaN
                code.visitStmt2R(MOVE_FROM16,0,22);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,27);
                code.visitFieldStmt(IPUT,0,1,new Field("Lorg/mortbay/jetty/HttpParser;","_state","I"));
                code.visitStmt2R(MOVE,13,14);
                code.visitLabel(L213);
                code.visitJumpStmt(GOTO_16,-1,-1,L54);
                code.visitLabel(L214);
                DexLabel L336=new DexLabel();
                code.visitSparseSwitchStmt(SPARSE_SWITCH,6,new int[]{ 9,10,13,32},new DexLabel[]{L336,L220,L220,L336});
                code.visitLabel(L215);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_length","I"));
                code.visitStmt2R(MOVE_FROM16,22,0);
                code.visitConstStmt(CONST_16,23, Integer.valueOf(-1)); // int: 0xffffffff  float:NaN
                code.visitStmt2R(MOVE_FROM16,0,22);
                code.visitStmt2R(MOVE_FROM16,1,23);
                code.visitJumpStmt(IF_NE,0,1,L217);
                code.visitLabel(L216);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_buffer","Lorg/mortbay/io/Buffer;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,22,0);
                code.visitMethodStmt(INVOKE_INTERFACE_RANGE,new int[]{ 22},new Method("Lorg/mortbay/io/Buffer;","mark",new String[]{ },"V"));
                code.visitLabel(L217);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_buffer","Lorg/mortbay/io/Buffer;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,22,0);
                code.visitMethodStmt(INVOKE_INTERFACE_RANGE,new int[]{ 22},new Method("Lorg/mortbay/io/Buffer;","getIndex",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,22);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_buffer","Lorg/mortbay/io/Buffer;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,23,0);
                code.visitMethodStmt(INVOKE_INTERFACE_RANGE,new int[]{ 23},new Method("Lorg/mortbay/io/Buffer;","markIndex",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,23);
                code.visitStmt3R(SUB_INT,22,22,23);
                code.visitStmt2R(MOVE_FROM16,0,22);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,27);
                code.visitFieldStmt(IPUT,0,1,new Field("Lorg/mortbay/jetty/HttpParser;","_length","I"));
                code.visitLabel(L218);
                code.visitConstStmt(CONST_16,22, Integer.valueOf(-1)); // int: 0xffffffff  float:NaN
                code.visitStmt2R(MOVE_FROM16,0,22);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,27);
                code.visitFieldStmt(IPUT,0,1,new Field("Lorg/mortbay/jetty/HttpParser;","_state","I"));
                code.visitStmt2R(MOVE,13,14);
                code.visitLabel(L219);
                code.visitJumpStmt(GOTO_16,-1,-1,L54);
                code.visitLabel(L220);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_length","I"));
                code.visitStmt2R(MOVE_FROM16,22,0);
                code.visitJumpStmt(IF_LEZ,22,-1,L223);
                code.visitLabel(L221);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_tok1","Lorg/mortbay/io/View$CaseInsensitive;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,22,0);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 22},new Method("Lorg/mortbay/io/View$CaseInsensitive;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,22);
                code.visitJumpStmt(IF_NEZ,22,-1,L226);
                code.visitLabel(L222);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_tok1","Lorg/mortbay/io/View$CaseInsensitive;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,22,0);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_buffer","Lorg/mortbay/io/Buffer;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,23,0);
                code.visitMethodStmt(INVOKE_INTERFACE_RANGE,new int[]{ 23},new Method("Lorg/mortbay/io/Buffer;","markIndex",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,23);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_buffer","Lorg/mortbay/io/Buffer;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,24,0);
                code.visitMethodStmt(INVOKE_INTERFACE_RANGE,new int[]{ 24},new Method("Lorg/mortbay/io/Buffer;","markIndex",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,24);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_length","I"));
                code.visitStmt2R(MOVE_FROM16,25,0);
                code.visitStmt3R(ADD_INT,24,24,25);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 22,23,24},new Method("Lorg/mortbay/io/View$CaseInsensitive;","update",new String[]{ "I","I"},"V"));
                code.visitLabel(L223);
                code.visitStmt2R(MOVE,0,6);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,27);
                code.visitFieldStmt(IPUT_BYTE,0,1,new Field("Lorg/mortbay/jetty/HttpParser;","_eol","B"));
                code.visitLabel(L224);
                code.visitConstStmt(CONST_16,22, Integer.valueOf(-5)); // int: 0xfffffffb  float:NaN
                code.visitStmt2R(MOVE_FROM16,0,22);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,27);
                code.visitFieldStmt(IPUT,0,1,new Field("Lorg/mortbay/jetty/HttpParser;","_state","I"));
                code.visitStmt2R(MOVE,13,14);
                code.visitLabel(L225);
                code.visitJumpStmt(GOTO_16,-1,-1,L54);
                code.visitLabel(L226);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_multiLineValue","Ljava/lang/String;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,22,0);
                code.visitJumpStmt(IF_NEZ,22,-1,L227);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_tok1","Lorg/mortbay/io/View$CaseInsensitive;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,22,0);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 22},new Method("Lorg/mortbay/io/View$CaseInsensitive;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,22);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,22);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,27);
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/jetty/HttpParser;","_multiLineValue","Ljava/lang/String;"));
                code.visitLabel(L227);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_tok1","Lorg/mortbay/io/View$CaseInsensitive;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,22,0);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_buffer","Lorg/mortbay/io/Buffer;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,23,0);
                code.visitMethodStmt(INVOKE_INTERFACE_RANGE,new int[]{ 23},new Method("Lorg/mortbay/io/Buffer;","markIndex",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,23);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_buffer","Lorg/mortbay/io/Buffer;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,24,0);
                code.visitMethodStmt(INVOKE_INTERFACE_RANGE,new int[]{ 24},new Method("Lorg/mortbay/io/Buffer;","markIndex",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,24);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_length","I"));
                code.visitStmt2R(MOVE_FROM16,25,0);
                code.visitStmt3R(ADD_INT,24,24,25);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 22,23,24},new Method("Lorg/mortbay/io/View$CaseInsensitive;","update",new String[]{ "I","I"},"V"));
                code.visitLabel(L228);
                code.visitTypeStmt(NEW_INSTANCE,22,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT_RANGE,new int[]{ 22},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_multiLineValue","Ljava/lang/String;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,23,0);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 22,23},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,22);
                code.visitConstStmt(CONST_STRING,23," ");
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 22,23},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,22);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_tok1","Lorg/mortbay/io/View$CaseInsensitive;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,23,0);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 23},new Method("Lorg/mortbay/io/View$CaseInsensitive;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,23);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 22,23},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,22);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 22},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,22);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,22);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,27);
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/jetty/HttpParser;","_multiLineValue","Ljava/lang/String;"));
                code.visitJumpStmt(GOTO,-1,-1,L223);
                code.visitLabel(L336);
                code.visitStmt2R(MOVE,13,14);
                code.visitLabel(L229);
                code.visitJumpStmt(GOTO_16,-1,-1,L54);
                code.visitLabel(L230);
                code.visitSparseSwitchStmt(SPARSE_SWITCH,6,new int[]{ 9,10,13,32},new DexLabel[]{L241,L232,L232,L241});
                code.visitLabel(L231);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_length","I"));
                code.visitStmt2R(MOVE_FROM16,22,0);
                code.visitStmt2R1N(ADD_INT_LIT8,22,22,1);
                code.visitStmt2R(MOVE_FROM16,0,22);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,27);
                code.visitFieldStmt(IPUT,0,1,new Field("Lorg/mortbay/jetty/HttpParser;","_length","I"));
                code.visitJumpStmt(GOTO_16,-1,-1,L333);
                code.visitLabel(L232);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_length","I"));
                code.visitStmt2R(MOVE_FROM16,22,0);
                code.visitJumpStmt(IF_LEZ,22,-1,L235);
                code.visitLabel(L233);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_tok1","Lorg/mortbay/io/View$CaseInsensitive;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,22,0);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 22},new Method("Lorg/mortbay/io/View$CaseInsensitive;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,22);
                code.visitJumpStmt(IF_NEZ,22,-1,L238);
                code.visitLabel(L234);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_tok1","Lorg/mortbay/io/View$CaseInsensitive;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,22,0);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_buffer","Lorg/mortbay/io/Buffer;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,23,0);
                code.visitMethodStmt(INVOKE_INTERFACE_RANGE,new int[]{ 23},new Method("Lorg/mortbay/io/Buffer;","markIndex",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,23);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_buffer","Lorg/mortbay/io/Buffer;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,24,0);
                code.visitMethodStmt(INVOKE_INTERFACE_RANGE,new int[]{ 24},new Method("Lorg/mortbay/io/Buffer;","markIndex",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,24);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_length","I"));
                code.visitStmt2R(MOVE_FROM16,25,0);
                code.visitStmt3R(ADD_INT,24,24,25);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 22,23,24},new Method("Lorg/mortbay/io/View$CaseInsensitive;","update",new String[]{ "I","I"},"V"));
                code.visitLabel(L235);
                code.visitStmt2R(MOVE,0,6);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,27);
                code.visitFieldStmt(IPUT_BYTE,0,1,new Field("Lorg/mortbay/jetty/HttpParser;","_eol","B"));
                code.visitLabel(L236);
                code.visitConstStmt(CONST_16,22, Integer.valueOf(-5)); // int: 0xfffffffb  float:NaN
                code.visitStmt2R(MOVE_FROM16,0,22);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,27);
                code.visitFieldStmt(IPUT,0,1,new Field("Lorg/mortbay/jetty/HttpParser;","_state","I"));
                code.visitStmt2R(MOVE,13,14);
                code.visitLabel(L237);
                code.visitJumpStmt(GOTO_16,-1,-1,L54);
                code.visitLabel(L238);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_multiLineValue","Ljava/lang/String;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,22,0);
                code.visitJumpStmt(IF_NEZ,22,-1,L239);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_tok1","Lorg/mortbay/io/View$CaseInsensitive;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,22,0);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 22},new Method("Lorg/mortbay/io/View$CaseInsensitive;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,22);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,22);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,27);
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/jetty/HttpParser;","_multiLineValue","Ljava/lang/String;"));
                code.visitLabel(L239);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_tok1","Lorg/mortbay/io/View$CaseInsensitive;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,22,0);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_buffer","Lorg/mortbay/io/Buffer;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,23,0);
                code.visitMethodStmt(INVOKE_INTERFACE_RANGE,new int[]{ 23},new Method("Lorg/mortbay/io/Buffer;","markIndex",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,23);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_buffer","Lorg/mortbay/io/Buffer;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,24,0);
                code.visitMethodStmt(INVOKE_INTERFACE_RANGE,new int[]{ 24},new Method("Lorg/mortbay/io/Buffer;","markIndex",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,24);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_length","I"));
                code.visitStmt2R(MOVE_FROM16,25,0);
                code.visitStmt3R(ADD_INT,24,24,25);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 22,23,24},new Method("Lorg/mortbay/io/View$CaseInsensitive;","update",new String[]{ "I","I"},"V"));
                code.visitLabel(L240);
                code.visitTypeStmt(NEW_INSTANCE,22,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT_RANGE,new int[]{ 22},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_multiLineValue","Ljava/lang/String;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,23,0);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 22,23},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,22);
                code.visitConstStmt(CONST_STRING,23," ");
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 22,23},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,22);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_tok1","Lorg/mortbay/io/View$CaseInsensitive;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,23,0);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 23},new Method("Lorg/mortbay/io/View$CaseInsensitive;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,23);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 22,23},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,22);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 22},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,22);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,22);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,27);
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/jetty/HttpParser;","_multiLineValue","Ljava/lang/String;"));
                code.visitJumpStmt(GOTO,-1,-1,L235);
                code.visitLabel(L241);
                code.visitConstStmt(CONST_16,22, Integer.valueOf(-2)); // int: 0xfffffffe  float:NaN
                code.visitStmt2R(MOVE_FROM16,0,22);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,27);
                code.visitFieldStmt(IPUT,0,1,new Field("Lorg/mortbay/jetty/HttpParser;","_state","I"));
                code.visitStmt2R(MOVE,13,14);
                code.visitLabel(L242);
                code.visitJumpStmt(GOTO_16,-1,-1,L54);
                code.visitLabel(L243);
                code.visitStmt2R(MOVE,13,14);
                code.visitLabel(L244);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_buffer","Lorg/mortbay/io/Buffer;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,22,0);
                code.visitMethodStmt(INVOKE_INTERFACE_RANGE,new int[]{ 22},new Method("Lorg/mortbay/io/Buffer;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,13);
                code.visitLabel(L245);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_input","Lorg/mortbay/jetty/HttpParser$Input;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,22,0);
                code.visitJumpStmt(IF_EQZ,22,-1,L247);
                code.visitLabel(L246);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_input","Lorg/mortbay/jetty/HttpParser$Input;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,22,0);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_contentView","Lorg/mortbay/io/View;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,23,0);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,23);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,22);
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/jetty/HttpParser$Input;","_contentView","Lorg/mortbay/io/Buffer;"));
                code.visitLabel(L247);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_state","I"));
                code.visitStmt2R(MOVE_FROM16,22,0);
                code.visitJumpStmt(IF_LEZ,22,-1,L320);
                code.visitJumpStmt(IF_LEZ,13,-1,L320);
                code.visitLabel(L248);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_BYTE,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_eol","B"));
                code.visitStmt2R(MOVE_FROM16,22,0);
                code.visitConstStmt(CONST_16,23, Integer.valueOf(13)); // int: 0x0000000d  float:0.000000
                code.visitStmt2R(MOVE_FROM16,0,22);
                code.visitStmt2R(MOVE_FROM16,1,23);
                code.visitJumpStmt(IF_NE,0,1,L252);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_buffer","Lorg/mortbay/io/Buffer;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,22,0);
                code.visitMethodStmt(INVOKE_INTERFACE_RANGE,new int[]{ 22},new Method("Lorg/mortbay/io/Buffer;","peek",new String[]{ },"B"));
                code.visitStmt1R(MOVE_RESULT,22);
                code.visitConstStmt(CONST_16,23, Integer.valueOf(10)); // int: 0x0000000a  float:0.000000
                code.visitStmt2R(MOVE_FROM16,0,22);
                code.visitStmt2R(MOVE_FROM16,1,23);
                code.visitJumpStmt(IF_NE,0,1,L252);
                code.visitLabel(L249);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_buffer","Lorg/mortbay/io/Buffer;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,22,0);
                code.visitMethodStmt(INVOKE_INTERFACE_RANGE,new int[]{ 22},new Method("Lorg/mortbay/io/Buffer;","get",new String[]{ },"B"));
                code.visitStmt1R(MOVE_RESULT,22);
                code.visitStmt2R(MOVE_FROM16,0,22);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,27);
                code.visitFieldStmt(IPUT_BYTE,0,1,new Field("Lorg/mortbay/jetty/HttpParser;","_eol","B"));
                code.visitLabel(L250);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_buffer","Lorg/mortbay/io/Buffer;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,22,0);
                code.visitMethodStmt(INVOKE_INTERFACE_RANGE,new int[]{ 22},new Method("Lorg/mortbay/io/Buffer;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,13);
                code.visitLabel(L251);
                code.visitJumpStmt(GOTO,-1,-1,L247);
                code.visitLabel(L252);
                code.visitConstStmt(CONST_16,22, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitStmt2R(MOVE_FROM16,0,22);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,27);
                code.visitFieldStmt(IPUT_BYTE,0,1,new Field("Lorg/mortbay/jetty/HttpParser;","_eol","B"));
                code.visitLabel(L253);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_state","I"));
                code.visitStmt2R(MOVE_FROM16,22,0);
                code.visitSparseSwitchStmt(PACKED_SWITCH,22,1,new DexLabel[]{L256,L261,L276,L284,L301,L309});
                code.visitLabel(L254);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_buffer","Lorg/mortbay/io/Buffer;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,22,0);
                code.visitMethodStmt(INVOKE_INTERFACE_RANGE,new int[]{ 22},new Method("Lorg/mortbay/io/Buffer;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,13);
                code.visitLabel(L255);
                code.visitJumpStmt(GOTO,-1,-1,L247);
                code.visitLabel(L256);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_buffer","Lorg/mortbay/io/Buffer;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,22,0);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_buffer","Lorg/mortbay/io/Buffer;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,23,0);
                code.visitMethodStmt(INVOKE_INTERFACE_RANGE,new int[]{ 23},new Method("Lorg/mortbay/io/Buffer;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,23);
                code.visitMethodStmt(INVOKE_INTERFACE_RANGE,new int[]{ 22,23},new Method("Lorg/mortbay/io/Buffer;","get",new String[]{ "I"},"Lorg/mortbay/io/Buffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitLabel(L257);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_WIDE,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_contentPosition","J"));
                code.visitStmt2R(MOVE_WIDE_FROM16,22,0);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 7},new Method("Lorg/mortbay/io/Buffer;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,24);
                code.visitStmt2R(MOVE_FROM16,0,24);
                code.visitStmt2R(INT_TO_LONG,0,0);
                code.visitStmt2R(MOVE_WIDE_FROM16,24,0);
                code.visitStmt3R(ADD_LONG,22,22,24);
                code.visitStmt2R(MOVE_WIDE_FROM16,0,22);
                code.visitStmt2R(MOVE_OBJECT_FROM16,2,27);
                code.visitFieldStmt(IPUT_WIDE,0,2,new Field("Lorg/mortbay/jetty/HttpParser;","_contentPosition","J"));
                code.visitLabel(L258);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_contentView","Lorg/mortbay/io/View;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,22,0);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,22);
                code.visitStmt2R(MOVE_OBJECT,1,7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Lorg/mortbay/io/View;","update",new String[]{ "Lorg/mortbay/io/Buffer;"},"V"));
                code.visitLabel(L259);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_handler","Lorg/mortbay/jetty/HttpParser$EventHandler;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,22,0);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,22);
                code.visitStmt2R(MOVE_OBJECT,1,7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Lorg/mortbay/jetty/HttpParser$EventHandler;","content",new String[]{ "Lorg/mortbay/io/Buffer;"},"V"));
                code.visitStmt2R(MOVE_WIDE_FROM16,22,18);
                code.visitLabel(L260);
                code.visitJumpStmt(GOTO_16,-1,-1,L6);
                code.visitLabel(L261);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_WIDE,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_contentLength","J"));
                code.visitStmt2R(MOVE_WIDE_FROM16,22,0);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_WIDE,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_contentPosition","J"));
                code.visitStmt2R(MOVE_WIDE_FROM16,24,0);
                code.visitStmt3R(SUB_LONG,16,22,24);
                code.visitLabel(L262);
                code.visitConstStmt(CONST_WIDE_16,22,Long.valueOf(0L)); // long: 0x0000000000000000  double:0.000000
                code.visitStmt3R(CMP_LONG,22,16,22);
                code.visitJumpStmt(IF_NEZ,22,-1,L266);
                code.visitLabel(L263);
                code.visitConstStmt(CONST_16,22, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitStmt2R(MOVE_FROM16,0,22);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,27);
                code.visitFieldStmt(IPUT,0,1,new Field("Lorg/mortbay/jetty/HttpParser;","_state","I"));
                code.visitLabel(L264);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_handler","Lorg/mortbay/jetty/HttpParser$EventHandler;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,22,0);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_WIDE,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_contentPosition","J"));
                code.visitStmt2R(MOVE_WIDE_FROM16,23,0);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 22,23,24},new Method("Lorg/mortbay/jetty/HttpParser$EventHandler;","messageComplete",new String[]{ "J"},"V"));
                code.visitStmt2R(MOVE_WIDE_FROM16,22,18);
                code.visitLabel(L265);
                code.visitJumpStmt(GOTO_16,-1,-1,L6);
                code.visitLabel(L266);
                code.visitStmt2R(MOVE,0,13);
                code.visitStmt2R(INT_TO_LONG,0,0);
                code.visitStmt2R(MOVE_WIDE_FROM16,22,0);
                code.visitStmt3R(CMP_LONG,22,22,16);
                code.visitJumpStmt(IF_LEZ,22,-1,L268);
                code.visitLabel(L267);
                code.visitStmt2R(MOVE_WIDE_FROM16,0,16);
                code.visitStmt2R(LONG_TO_INT,0,0);
                code.visitStmt2R(MOVE,13,0);
                code.visitLabel(L268);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_buffer","Lorg/mortbay/io/Buffer;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,22,0);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,22);
                code.visitStmt2R(MOVE,1,13);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,1},new Method("Lorg/mortbay/io/Buffer;","get",new String[]{ "I"},"Lorg/mortbay/io/Buffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitLabel(L269);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_WIDE,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_contentPosition","J"));
                code.visitStmt2R(MOVE_WIDE_FROM16,22,0);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 7},new Method("Lorg/mortbay/io/Buffer;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,24);
                code.visitStmt2R(MOVE_FROM16,0,24);
                code.visitStmt2R(INT_TO_LONG,0,0);
                code.visitStmt2R(MOVE_WIDE_FROM16,24,0);
                code.visitStmt3R(ADD_LONG,22,22,24);
                code.visitStmt2R(MOVE_WIDE_FROM16,0,22);
                code.visitStmt2R(MOVE_OBJECT_FROM16,2,27);
                code.visitFieldStmt(IPUT_WIDE,0,2,new Field("Lorg/mortbay/jetty/HttpParser;","_contentPosition","J"));
                code.visitLabel(L270);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_contentView","Lorg/mortbay/io/View;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,22,0);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,22);
                code.visitStmt2R(MOVE_OBJECT,1,7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Lorg/mortbay/io/View;","update",new String[]{ "Lorg/mortbay/io/Buffer;"},"V"));
                code.visitLabel(L271);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_handler","Lorg/mortbay/jetty/HttpParser$EventHandler;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,22,0);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,22);
                code.visitStmt2R(MOVE_OBJECT,1,7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Lorg/mortbay/jetty/HttpParser$EventHandler;","content",new String[]{ "Lorg/mortbay/io/Buffer;"},"V"));
                code.visitLabel(L272);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_WIDE,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_contentPosition","J"));
                code.visitStmt2R(MOVE_WIDE_FROM16,22,0);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_WIDE,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_contentLength","J"));
                code.visitStmt2R(MOVE_WIDE_FROM16,24,0);
                code.visitStmt3R(CMP_LONG,22,22,24);
                DexLabel L337=new DexLabel();
                code.visitJumpStmt(IF_NEZ,22,-1,L337);
                code.visitLabel(L273);
                code.visitConstStmt(CONST_16,22, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitStmt2R(MOVE_FROM16,0,22);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,27);
                code.visitFieldStmt(IPUT,0,1,new Field("Lorg/mortbay/jetty/HttpParser;","_state","I"));
                code.visitLabel(L274);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_handler","Lorg/mortbay/jetty/HttpParser$EventHandler;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,22,0);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_WIDE,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_contentPosition","J"));
                code.visitStmt2R(MOVE_WIDE_FROM16,23,0);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 22,23,24},new Method("Lorg/mortbay/jetty/HttpParser$EventHandler;","messageComplete",new String[]{ "J"},"V"));
                code.visitLabel(L337);
                code.visitStmt2R(MOVE_WIDE_FROM16,22,18);
                code.visitLabel(L275);
                code.visitJumpStmt(GOTO_16,-1,-1,L6);
                code.visitLabel(L276);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_buffer","Lorg/mortbay/io/Buffer;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,22,0);
                code.visitMethodStmt(INVOKE_INTERFACE_RANGE,new int[]{ 22},new Method("Lorg/mortbay/io/Buffer;","peek",new String[]{ },"B"));
                code.visitStmt1R(MOVE_RESULT,6);
                code.visitLabel(L277);
                code.visitConstStmt(CONST_16,22, Integer.valueOf(13)); // int: 0x0000000d  float:0.000000
                code.visitStmt2R(MOVE,0,6);
                code.visitStmt2R(MOVE_FROM16,1,22);
                code.visitJumpStmt(IF_EQ,0,1,L278);
                code.visitConstStmt(CONST_16,22, Integer.valueOf(10)); // int: 0x0000000a  float:0.000000
                code.visitStmt2R(MOVE,0,6);
                code.visitStmt2R(MOVE_FROM16,1,22);
                code.visitJumpStmt(IF_NE,0,1,L279);
                code.visitLabel(L278);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_buffer","Lorg/mortbay/io/Buffer;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,22,0);
                code.visitMethodStmt(INVOKE_INTERFACE_RANGE,new int[]{ 22},new Method("Lorg/mortbay/io/Buffer;","get",new String[]{ },"B"));
                code.visitStmt1R(MOVE_RESULT,22);
                code.visitStmt2R(MOVE_FROM16,0,22);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,27);
                code.visitFieldStmt(IPUT_BYTE,0,1,new Field("Lorg/mortbay/jetty/HttpParser;","_eol","B"));
                code.visitJumpStmt(GOTO_16,-1,-1,L254);
                code.visitLabel(L279);
                code.visitConstStmt(CONST_16,22, Integer.valueOf(32)); // int: 0x00000020  float:0.000000
                code.visitStmt2R(MOVE,0,6);
                code.visitStmt2R(MOVE_FROM16,1,22);
                code.visitJumpStmt(IF_GT,0,1,L281);
                code.visitLabel(L280);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_buffer","Lorg/mortbay/io/Buffer;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,22,0);
                code.visitMethodStmt(INVOKE_INTERFACE_RANGE,new int[]{ 22},new Method("Lorg/mortbay/io/Buffer;","get",new String[]{ },"B"));
                code.visitJumpStmt(GOTO_16,-1,-1,L254);
                code.visitLabel(L281);
                code.visitConstStmt(CONST_16,22, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitStmt2R(MOVE_FROM16,0,22);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,27);
                code.visitFieldStmt(IPUT,0,1,new Field("Lorg/mortbay/jetty/HttpParser;","_chunkLength","I"));
                code.visitLabel(L282);
                code.visitConstStmt(CONST_16,22, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitStmt2R(MOVE_FROM16,0,22);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,27);
                code.visitFieldStmt(IPUT,0,1,new Field("Lorg/mortbay/jetty/HttpParser;","_chunkPosition","I"));
                code.visitLabel(L283);
                code.visitConstStmt(CONST_16,22, Integer.valueOf(4)); // int: 0x00000004  float:0.000000
                code.visitStmt2R(MOVE_FROM16,0,22);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,27);
                code.visitFieldStmt(IPUT,0,1,new Field("Lorg/mortbay/jetty/HttpParser;","_state","I"));
                code.visitJumpStmt(GOTO_16,-1,-1,L254);
                code.visitLabel(L284);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_buffer","Lorg/mortbay/io/Buffer;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,22,0);
                code.visitMethodStmt(INVOKE_INTERFACE_RANGE,new int[]{ 22},new Method("Lorg/mortbay/io/Buffer;","get",new String[]{ },"B"));
                code.visitStmt1R(MOVE_RESULT,6);
                code.visitLabel(L285);
                code.visitConstStmt(CONST_16,22, Integer.valueOf(13)); // int: 0x0000000d  float:0.000000
                code.visitStmt2R(MOVE,0,6);
                code.visitStmt2R(MOVE_FROM16,1,22);
                code.visitJumpStmt(IF_EQ,0,1,L286);
                code.visitConstStmt(CONST_16,22, Integer.valueOf(10)); // int: 0x0000000a  float:0.000000
                code.visitStmt2R(MOVE,0,6);
                code.visitStmt2R(MOVE_FROM16,1,22);
                code.visitJumpStmt(IF_NE,0,1,L292);
                code.visitLabel(L286);
                code.visitStmt2R(MOVE,0,6);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,27);
                code.visitFieldStmt(IPUT_BYTE,0,1,new Field("Lorg/mortbay/jetty/HttpParser;","_eol","B"));
                code.visitLabel(L287);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_chunkLength","I"));
                code.visitStmt2R(MOVE_FROM16,22,0);
                code.visitJumpStmt(IF_NEZ,22,-1,L291);
                code.visitLabel(L288);
                code.visitConstStmt(CONST_16,22, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitStmt2R(MOVE_FROM16,0,22);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,27);
                code.visitFieldStmt(IPUT,0,1,new Field("Lorg/mortbay/jetty/HttpParser;","_state","I"));
                code.visitLabel(L289);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_handler","Lorg/mortbay/jetty/HttpParser$EventHandler;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,22,0);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_WIDE,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_contentPosition","J"));
                code.visitStmt2R(MOVE_WIDE_FROM16,23,0);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 22,23,24},new Method("Lorg/mortbay/jetty/HttpParser$EventHandler;","messageComplete",new String[]{ "J"},"V"));
                code.visitStmt2R(MOVE_WIDE_FROM16,22,18);
                code.visitLabel(L290);
                code.visitJumpStmt(GOTO_16,-1,-1,L6);
                code.visitLabel(L291);
                code.visitConstStmt(CONST_16,22, Integer.valueOf(6)); // int: 0x00000006  float:0.000000
                code.visitStmt2R(MOVE_FROM16,0,22);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,27);
                code.visitFieldStmt(IPUT,0,1,new Field("Lorg/mortbay/jetty/HttpParser;","_state","I"));
                code.visitJumpStmt(GOTO_16,-1,-1,L254);
                code.visitLabel(L292);
                code.visitConstStmt(CONST_16,22, Integer.valueOf(32)); // int: 0x00000020  float:0.000000
                code.visitStmt2R(MOVE,0,6);
                code.visitStmt2R(MOVE_FROM16,1,22);
                code.visitJumpStmt(IF_LE,0,1,L293);
                code.visitConstStmt(CONST_16,22, Integer.valueOf(59)); // int: 0x0000003b  float:0.000000
                code.visitStmt2R(MOVE,0,6);
                code.visitStmt2R(MOVE_FROM16,1,22);
                code.visitJumpStmt(IF_NE,0,1,L294);
                code.visitLabel(L293);
                code.visitConstStmt(CONST_16,22, Integer.valueOf(5)); // int: 0x00000005  float:0.000000
                code.visitStmt2R(MOVE_FROM16,0,22);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,27);
                code.visitFieldStmt(IPUT,0,1,new Field("Lorg/mortbay/jetty/HttpParser;","_state","I"));
                code.visitJumpStmt(GOTO_16,-1,-1,L254);
                code.visitLabel(L294);
                code.visitConstStmt(CONST_16,22, Integer.valueOf(48)); // int: 0x00000030  float:0.000000
                code.visitStmt2R(MOVE,0,6);
                code.visitStmt2R(MOVE_FROM16,1,22);
                code.visitJumpStmt(IF_LT,0,1,L296);
                code.visitConstStmt(CONST_16,22, Integer.valueOf(57)); // int: 0x00000039  float:0.000000
                code.visitStmt2R(MOVE,0,6);
                code.visitStmt2R(MOVE_FROM16,1,22);
                code.visitJumpStmt(IF_GT,0,1,L296);
                code.visitLabel(L295);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_chunkLength","I"));
                code.visitStmt2R(MOVE_FROM16,22,0);
                code.visitStmt2R1N(MUL_INT_LIT8,22,22,16);
                code.visitConstStmt(CONST_16,23, Integer.valueOf(48)); // int: 0x00000030  float:0.000000
                code.visitStmt3R(SUB_INT,23,6,23);
                code.visitStmt3R(ADD_INT,22,22,23);
                code.visitStmt2R(MOVE_FROM16,0,22);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,27);
                code.visitFieldStmt(IPUT,0,1,new Field("Lorg/mortbay/jetty/HttpParser;","_chunkLength","I"));
                code.visitJumpStmt(GOTO_16,-1,-1,L254);
                code.visitLabel(L296);
                code.visitConstStmt(CONST_16,22, Integer.valueOf(97)); // int: 0x00000061  float:0.000000
                code.visitStmt2R(MOVE,0,6);
                code.visitStmt2R(MOVE_FROM16,1,22);
                code.visitJumpStmt(IF_LT,0,1,L298);
                code.visitConstStmt(CONST_16,22, Integer.valueOf(102)); // int: 0x00000066  float:0.000000
                code.visitStmt2R(MOVE,0,6);
                code.visitStmt2R(MOVE_FROM16,1,22);
                code.visitJumpStmt(IF_GT,0,1,L298);
                code.visitLabel(L297);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_chunkLength","I"));
                code.visitStmt2R(MOVE_FROM16,22,0);
                code.visitStmt2R1N(MUL_INT_LIT8,22,22,16);
                code.visitStmt2R1N(ADD_INT_LIT8,23,6,10);
                code.visitConstStmt(CONST_16,24, Integer.valueOf(97)); // int: 0x00000061  float:0.000000
                code.visitStmt3R(SUB_INT,23,23,24);
                code.visitStmt3R(ADD_INT,22,22,23);
                code.visitStmt2R(MOVE_FROM16,0,22);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,27);
                code.visitFieldStmt(IPUT,0,1,new Field("Lorg/mortbay/jetty/HttpParser;","_chunkLength","I"));
                code.visitJumpStmt(GOTO_16,-1,-1,L254);
                code.visitLabel(L298);
                code.visitConstStmt(CONST_16,22, Integer.valueOf(65)); // int: 0x00000041  float:0.000000
                code.visitStmt2R(MOVE,0,6);
                code.visitStmt2R(MOVE_FROM16,1,22);
                code.visitJumpStmt(IF_LT,0,1,L300);
                code.visitConstStmt(CONST_16,22, Integer.valueOf(70)); // int: 0x00000046  float:0.000000
                code.visitStmt2R(MOVE,0,6);
                code.visitStmt2R(MOVE_FROM16,1,22);
                code.visitJumpStmt(IF_GT,0,1,L300);
                code.visitLabel(L299);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_chunkLength","I"));
                code.visitStmt2R(MOVE_FROM16,22,0);
                code.visitStmt2R1N(MUL_INT_LIT8,22,22,16);
                code.visitStmt2R1N(ADD_INT_LIT8,23,6,10);
                code.visitConstStmt(CONST_16,24, Integer.valueOf(65)); // int: 0x00000041  float:0.000000
                code.visitStmt3R(SUB_INT,23,23,24);
                code.visitStmt3R(ADD_INT,22,22,23);
                code.visitStmt2R(MOVE_FROM16,0,22);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,27);
                code.visitFieldStmt(IPUT,0,1,new Field("Lorg/mortbay/jetty/HttpParser;","_chunkLength","I"));
                code.visitJumpStmt(GOTO_16,-1,-1,L254);
                code.visitLabel(L300);
                code.visitTypeStmt(NEW_INSTANCE,22,-1,"Ljava/io/IOException;");
                code.visitTypeStmt(NEW_INSTANCE,23,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT_RANGE,new int[]{ 23},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,24,"bad chunk char: ");
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 23,24},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,23);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,23);
                code.visitStmt2R(MOVE,1,6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "I"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,23);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 23},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,23);
                code.visitMethodStmt(INVOKE_DIRECT_RANGE,new int[]{ 22,23},new Method("Ljava/io/IOException;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitStmt1R(THROW,22);
                code.visitLabel(L301);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_buffer","Lorg/mortbay/io/Buffer;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,22,0);
                code.visitMethodStmt(INVOKE_INTERFACE_RANGE,new int[]{ 22},new Method("Lorg/mortbay/io/Buffer;","get",new String[]{ },"B"));
                code.visitStmt1R(MOVE_RESULT,6);
                code.visitLabel(L302);
                code.visitConstStmt(CONST_16,22, Integer.valueOf(13)); // int: 0x0000000d  float:0.000000
                code.visitStmt2R(MOVE,0,6);
                code.visitStmt2R(MOVE_FROM16,1,22);
                code.visitJumpStmt(IF_EQ,0,1,L303);
                code.visitConstStmt(CONST_16,22, Integer.valueOf(10)); // int: 0x0000000a  float:0.000000
                code.visitStmt2R(MOVE,0,6);
                code.visitStmt2R(MOVE_FROM16,1,22);
                code.visitJumpStmt(IF_NE,0,1,L254);
                code.visitLabel(L303);
                code.visitStmt2R(MOVE,0,6);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,27);
                code.visitFieldStmt(IPUT_BYTE,0,1,new Field("Lorg/mortbay/jetty/HttpParser;","_eol","B"));
                code.visitLabel(L304);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_chunkLength","I"));
                code.visitStmt2R(MOVE_FROM16,22,0);
                code.visitJumpStmt(IF_NEZ,22,-1,L308);
                code.visitLabel(L305);
                code.visitConstStmt(CONST_16,22, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitStmt2R(MOVE_FROM16,0,22);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,27);
                code.visitFieldStmt(IPUT,0,1,new Field("Lorg/mortbay/jetty/HttpParser;","_state","I"));
                code.visitLabel(L306);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_handler","Lorg/mortbay/jetty/HttpParser$EventHandler;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,22,0);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_WIDE,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_contentPosition","J"));
                code.visitStmt2R(MOVE_WIDE_FROM16,23,0);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 22,23,24},new Method("Lorg/mortbay/jetty/HttpParser$EventHandler;","messageComplete",new String[]{ "J"},"V"));
                code.visitStmt2R(MOVE_WIDE_FROM16,22,18);
                code.visitLabel(L307);
                code.visitJumpStmt(GOTO_16,-1,-1,L6);
                code.visitLabel(L308);
                code.visitConstStmt(CONST_16,22, Integer.valueOf(6)); // int: 0x00000006  float:0.000000
                code.visitStmt2R(MOVE_FROM16,0,22);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,27);
                code.visitFieldStmt(IPUT,0,1,new Field("Lorg/mortbay/jetty/HttpParser;","_state","I"));
                code.visitJumpStmt(GOTO_16,-1,-1,L254);
                code.visitLabel(L309);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_chunkLength","I"));
                code.visitStmt2R(MOVE_FROM16,22,0);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_chunkPosition","I"));
                code.visitStmt2R(MOVE_FROM16,23,0);
                code.visitStmt3R(SUB_INT,16,22,23);
                code.visitLabel(L310);
                code.visitJumpStmt(IF_NEZ,16,-1,L312);
                code.visitLabel(L311);
                code.visitConstStmt(CONST_16,22, Integer.valueOf(3)); // int: 0x00000003  float:0.000000
                code.visitStmt2R(MOVE_FROM16,0,22);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,27);
                code.visitFieldStmt(IPUT,0,1,new Field("Lorg/mortbay/jetty/HttpParser;","_state","I"));
                code.visitJumpStmt(GOTO_16,-1,-1,L254);
                code.visitLabel(L312);
                code.visitStmt2R(MOVE,0,13);
                code.visitStmt2R(MOVE_FROM16,1,16);
                code.visitJumpStmt(IF_LE,0,1,L314);
                code.visitLabel(L313);
                code.visitStmt2R(MOVE_FROM16,13,16);
                code.visitLabel(L314);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_buffer","Lorg/mortbay/io/Buffer;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,22,0);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,22);
                code.visitStmt2R(MOVE,1,13);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,1},new Method("Lorg/mortbay/io/Buffer;","get",new String[]{ "I"},"Lorg/mortbay/io/Buffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitLabel(L315);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_WIDE,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_contentPosition","J"));
                code.visitStmt2R(MOVE_WIDE_FROM16,22,0);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 7},new Method("Lorg/mortbay/io/Buffer;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,24);
                code.visitStmt2R(MOVE_FROM16,0,24);
                code.visitStmt2R(INT_TO_LONG,0,0);
                code.visitStmt2R(MOVE_WIDE_FROM16,24,0);
                code.visitStmt3R(ADD_LONG,22,22,24);
                code.visitStmt2R(MOVE_WIDE_FROM16,0,22);
                code.visitStmt2R(MOVE_OBJECT_FROM16,2,27);
                code.visitFieldStmt(IPUT_WIDE,0,2,new Field("Lorg/mortbay/jetty/HttpParser;","_contentPosition","J"));
                code.visitLabel(L316);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_chunkPosition","I"));
                code.visitStmt2R(MOVE_FROM16,22,0);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 7},new Method("Lorg/mortbay/io/Buffer;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,23);
                code.visitStmt3R(ADD_INT,22,22,23);
                code.visitStmt2R(MOVE_FROM16,0,22);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,27);
                code.visitFieldStmt(IPUT,0,1,new Field("Lorg/mortbay/jetty/HttpParser;","_chunkPosition","I"));
                code.visitLabel(L317);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_contentView","Lorg/mortbay/io/View;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,22,0);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,22);
                code.visitStmt2R(MOVE_OBJECT,1,7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Lorg/mortbay/io/View;","update",new String[]{ "Lorg/mortbay/io/Buffer;"},"V"));
                code.visitLabel(L318);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/HttpParser;","_handler","Lorg/mortbay/jetty/HttpParser$EventHandler;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,22,0);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,22);
                code.visitStmt2R(MOVE_OBJECT,1,7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Lorg/mortbay/jetty/HttpParser$EventHandler;","content",new String[]{ "Lorg/mortbay/io/Buffer;"},"V"));
                code.visitStmt2R(MOVE_WIDE_FROM16,22,18);
                code.visitLabel(L319);
                code.visitJumpStmt(GOTO_16,-1,-1,L6);
                code.visitLabel(L320);
                code.visitStmt2R(MOVE_WIDE_FROM16,22,18);
                code.visitLabel(L321);
                code.visitJumpStmt(GOTO_16,-1,-1,L6);
                code.visitLabel(L322);
                code.visitLabel(L323);
                code.visitLabel(L324);
                code.visitLabel(L325);
                code.visitLabel(L326);
                code.visitLabel(L327);
                code.visitLabel(L328);
                code.visitLabel(L329);
                code.visitLabel(L330);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m021_reset(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/HttpParser;","reset",new String[]{ "Z"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(6);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexLabel L3=new DexLabel();
                DexLabel L4=new DexLabel();
                code.visitTryCatch(L3,L4,new DexLabel[]{L2},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"returnBuffers");
                DexLabel L5=new DexLabel();
                ddv.visitPrologue(L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(924,L6);
                ddv.visitLineNumber(926,L0);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(927,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(929,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(930,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(931,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(932,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(933,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(935,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(937,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(938,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(941,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(943,L17);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(945,L18);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(946,L19);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(948,L20);
                DexLabel L21=new DexLabel();
                ddv.visitLineNumber(952,L21);
                DexLabel L22=new DexLabel();
                ddv.visitLineNumber(954,L22);
                DexLabel L23=new DexLabel();
                ddv.visitLineNumber(955,L23);
                DexLabel L24=new DexLabel();
                ddv.visitLineNumber(956,L24);
                DexLabel L25=new DexLabel();
                ddv.visitLineNumber(966,L25);
                DexLabel L26=new DexLabel();
                ddv.visitLineNumber(968,L26);
                DexLabel L27=new DexLabel();
                ddv.visitLineNumber(969,L27);
                DexLabel L28=new DexLabel();
                ddv.visitLineNumber(971,L28);
                DexLabel L29=new DexLabel();
                ddv.visitLineNumber(972,L29);
                DexLabel L30=new DexLabel();
                ddv.visitLineNumber(973,L30);
                DexLabel L31=new DexLabel();
                ddv.visitLineNumber(985,L31);
                DexLabel L32=new DexLabel();
                ddv.visitLineNumber(986,L32);
                DexLabel L33=new DexLabel();
                ddv.visitLineNumber(987,L33);
                DexLabel L34=new DexLabel();
                ddv.visitLineNumber(960,L34);
                DexLabel L35=new DexLabel();
                ddv.visitLineNumber(961,L35);
                ddv.visitLineNumber(986,L2);
                ddv.visitLineNumber(977,L3);
                DexLabel L36=new DexLabel();
                ddv.visitLineNumber(978,L36);
                DexLabel L37=new DexLabel();
                ddv.visitLineNumber(979,L37);
                DexLabel L38=new DexLabel();
                ddv.visitLineNumber(980,L38);
                DexLabel L39=new DexLabel();
                ddv.visitLineNumber(981,L39);
                code.visitLabel(L5);
                code.visitConstStmt(CONST_16,3, Integer.valueOf(10)); // int: 0x0000000a  float:0.000000
                code.visitLabel(L6);
                code.visitStmt1R(MONITOR_ENTER,4);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,4,new Field("Lorg/mortbay/jetty/HttpParser;","_input","Lorg/mortbay/jetty/HttpParser$Input;"));
                code.visitJumpStmt(IF_EQZ,0,-1,L8);
                code.visitFieldStmt(IGET_OBJECT,0,4,new Field("Lorg/mortbay/jetty/HttpParser;","_contentView","Lorg/mortbay/io/View;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/io/View;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_LEZ,0,-1,L8);
                code.visitLabel(L7);
                code.visitFieldStmt(IGET_OBJECT,0,4,new Field("Lorg/mortbay/jetty/HttpParser;","_input","Lorg/mortbay/jetty/HttpParser$Input;"));
                code.visitFieldStmt(IGET_OBJECT,1,4,new Field("Lorg/mortbay/jetty/HttpParser;","_contentView","Lorg/mortbay/io/View;"));
                code.visitConstStmt(CONST_4,2, Integer.valueOf(2)); // int: 0x00000002  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2},new Method("Lorg/mortbay/io/View;","duplicate",new String[]{ "I"},"Lorg/mortbay/io/ByteArrayBuffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitFieldStmt(IPUT_OBJECT,1,0,new Field("Lorg/mortbay/jetty/HttpParser$Input;","_contentView","Lorg/mortbay/io/Buffer;"));
                code.visitLabel(L8);
                code.visitConstStmt(CONST_16,0, Integer.valueOf(-13)); // int: 0xfffffff3  float:NaN
                code.visitFieldStmt(IPUT,0,4,new Field("Lorg/mortbay/jetty/HttpParser;","_state","I"));
                code.visitLabel(L9);
                code.visitConstStmt(CONST_WIDE_16,0,Long.valueOf(-3L)); // long: 0xfffffffffffffffd  double:NaN
                code.visitFieldStmt(IPUT_WIDE,0,4,new Field("Lorg/mortbay/jetty/HttpParser;","_contentLength","J"));
                code.visitLabel(L10);
                code.visitConstStmt(CONST_WIDE_16,0,Long.valueOf(0L)); // long: 0x0000000000000000  double:0.000000
                code.visitFieldStmt(IPUT_WIDE,0,4,new Field("Lorg/mortbay/jetty/HttpParser;","_contentPosition","J"));
                code.visitLabel(L11);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT,0,4,new Field("Lorg/mortbay/jetty/HttpParser;","_length","I"));
                code.visitLabel(L12);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT,0,4,new Field("Lorg/mortbay/jetty/HttpParser;","_responseStatus","I"));
                code.visitLabel(L13);
                code.visitFieldStmt(IGET_OBJECT,0,4,new Field("Lorg/mortbay/jetty/HttpParser;","_buffer","Lorg/mortbay/io/Buffer;"));
                code.visitJumpStmt(IF_EQZ,0,-1,L16);
                code.visitFieldStmt(IGET_OBJECT,0,4,new Field("Lorg/mortbay/jetty/HttpParser;","_buffer","Lorg/mortbay/io/Buffer;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0},new Method("Lorg/mortbay/io/Buffer;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_LEZ,0,-1,L16);
                code.visitFieldStmt(IGET_BYTE,0,4,new Field("Lorg/mortbay/jetty/HttpParser;","_eol","B"));
                code.visitConstStmt(CONST_16,1, Integer.valueOf(13)); // int: 0x0000000d  float:0.000000
                code.visitJumpStmt(IF_NE,0,1,L16);
                code.visitFieldStmt(IGET_OBJECT,0,4,new Field("Lorg/mortbay/jetty/HttpParser;","_buffer","Lorg/mortbay/io/Buffer;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0},new Method("Lorg/mortbay/io/Buffer;","peek",new String[]{ },"B"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_NE,0,3,L16);
                code.visitLabel(L14);
                code.visitFieldStmt(IGET_OBJECT,0,4,new Field("Lorg/mortbay/jetty/HttpParser;","_buffer","Lorg/mortbay/io/Buffer;"));
                code.visitConstStmt(CONST_4,1, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,1},new Method("Lorg/mortbay/io/Buffer;","skip",new String[]{ "I"},"I"));
                code.visitLabel(L15);
                code.visitConstStmt(CONST_16,0, Integer.valueOf(10)); // int: 0x0000000a  float:0.000000
                code.visitFieldStmt(IPUT_BYTE,0,4,new Field("Lorg/mortbay/jetty/HttpParser;","_eol","B"));
                code.visitLabel(L16);
                code.visitFieldStmt(IGET_OBJECT,0,4,new Field("Lorg/mortbay/jetty/HttpParser;","_body","Lorg/mortbay/io/Buffer;"));
                code.visitJumpStmt(IF_EQZ,0,-1,L25);
                code.visitLabel(L17);
                code.visitFieldStmt(IGET_OBJECT,0,4,new Field("Lorg/mortbay/jetty/HttpParser;","_body","Lorg/mortbay/io/Buffer;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0},new Method("Lorg/mortbay/io/Buffer;","hasContent",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_EQZ,0,-1,L21);
                code.visitLabel(L18);
                code.visitFieldStmt(IGET_OBJECT,0,4,new Field("Lorg/mortbay/jetty/HttpParser;","_header","Lorg/mortbay/io/Buffer;"));
                code.visitConstStmt(CONST_4,1, Integer.valueOf(-1)); // int: 0xffffffff  float:NaN
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,1},new Method("Lorg/mortbay/io/Buffer;","setMarkIndex",new String[]{ "I"},"V"));
                code.visitLabel(L19);
                code.visitFieldStmt(IGET_OBJECT,0,4,new Field("Lorg/mortbay/jetty/HttpParser;","_header","Lorg/mortbay/io/Buffer;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0},new Method("Lorg/mortbay/io/Buffer;","compact",new String[]{ },"V"));
                code.visitLabel(L20);
                code.visitFieldStmt(IGET_OBJECT,0,4,new Field("Lorg/mortbay/jetty/HttpParser;","_body","Lorg/mortbay/io/Buffer;"));
                code.visitFieldStmt(IGET_OBJECT,1,4,new Field("Lorg/mortbay/jetty/HttpParser;","_header","Lorg/mortbay/io/Buffer;"));
                code.visitFieldStmt(IGET_OBJECT,2,4,new Field("Lorg/mortbay/jetty/HttpParser;","_body","Lorg/mortbay/io/Buffer;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 1,2},new Method("Lorg/mortbay/io/Buffer;","put",new String[]{ "Lorg/mortbay/io/Buffer;"},"I"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,1},new Method("Lorg/mortbay/io/Buffer;","skip",new String[]{ "I"},"I"));
                code.visitLabel(L21);
                code.visitFieldStmt(IGET_OBJECT,0,4,new Field("Lorg/mortbay/jetty/HttpParser;","_body","Lorg/mortbay/io/Buffer;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0},new Method("Lorg/mortbay/io/Buffer;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_NEZ,0,-1,L34);
                code.visitLabel(L22);
                code.visitFieldStmt(IGET_OBJECT,0,4,new Field("Lorg/mortbay/jetty/HttpParser;","_buffers","Lorg/mortbay/io/Buffers;"));
                code.visitJumpStmt(IF_EQZ,0,-1,L24);
                code.visitJumpStmt(IF_EQZ,5,-1,L24);
                code.visitLabel(L23);
                code.visitFieldStmt(IGET_OBJECT,0,4,new Field("Lorg/mortbay/jetty/HttpParser;","_buffers","Lorg/mortbay/io/Buffers;"));
                code.visitFieldStmt(IGET_OBJECT,1,4,new Field("Lorg/mortbay/jetty/HttpParser;","_body","Lorg/mortbay/io/Buffer;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,1},new Method("Lorg/mortbay/io/Buffers;","returnBuffer",new String[]{ "Lorg/mortbay/io/Buffer;"},"V"));
                code.visitLabel(L24);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT_OBJECT,0,4,new Field("Lorg/mortbay/jetty/HttpParser;","_body","Lorg/mortbay/io/Buffer;"));
                code.visitLabel(L25);
                code.visitFieldStmt(IGET_OBJECT,0,4,new Field("Lorg/mortbay/jetty/HttpParser;","_header","Lorg/mortbay/io/Buffer;"));
                code.visitJumpStmt(IF_EQZ,0,-1,L31);
                code.visitLabel(L26);
                code.visitFieldStmt(IGET_OBJECT,0,4,new Field("Lorg/mortbay/jetty/HttpParser;","_header","Lorg/mortbay/io/Buffer;"));
                code.visitConstStmt(CONST_4,1, Integer.valueOf(-1)); // int: 0xffffffff  float:NaN
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,1},new Method("Lorg/mortbay/io/Buffer;","setMarkIndex",new String[]{ "I"},"V"));
                code.visitLabel(L27);
                code.visitFieldStmt(IGET_OBJECT,0,4,new Field("Lorg/mortbay/jetty/HttpParser;","_header","Lorg/mortbay/io/Buffer;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0},new Method("Lorg/mortbay/io/Buffer;","hasContent",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_NEZ,0,-1,L3);
                code.visitFieldStmt(IGET_OBJECT,0,4,new Field("Lorg/mortbay/jetty/HttpParser;","_buffers","Lorg/mortbay/io/Buffers;"));
                code.visitJumpStmt(IF_EQZ,0,-1,L3);
                code.visitJumpStmt(IF_EQZ,5,-1,L3);
                code.visitLabel(L28);
                code.visitFieldStmt(IGET_OBJECT,0,4,new Field("Lorg/mortbay/jetty/HttpParser;","_buffers","Lorg/mortbay/io/Buffers;"));
                code.visitFieldStmt(IGET_OBJECT,1,4,new Field("Lorg/mortbay/jetty/HttpParser;","_header","Lorg/mortbay/io/Buffer;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,1},new Method("Lorg/mortbay/io/Buffers;","returnBuffer",new String[]{ "Lorg/mortbay/io/Buffer;"},"V"));
                code.visitLabel(L29);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT_OBJECT,0,4,new Field("Lorg/mortbay/jetty/HttpParser;","_header","Lorg/mortbay/io/Buffer;"));
                code.visitLabel(L30);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT_OBJECT,0,4,new Field("Lorg/mortbay/jetty/HttpParser;","_buffer","Lorg/mortbay/io/Buffer;"));
                code.visitLabel(L31);
                code.visitFieldStmt(IGET_OBJECT,0,4,new Field("Lorg/mortbay/jetty/HttpParser;","_header","Lorg/mortbay/io/Buffer;"));
                code.visitFieldStmt(IPUT_OBJECT,0,4,new Field("Lorg/mortbay/jetty/HttpParser;","_buffer","Lorg/mortbay/io/Buffer;"));
                code.visitLabel(L32);
                code.visitStmt1R(MONITOR_EXIT,4);
                code.visitLabel(L33);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L34);
                code.visitFieldStmt(IGET_OBJECT,0,4,new Field("Lorg/mortbay/jetty/HttpParser;","_body","Lorg/mortbay/io/Buffer;"));
                code.visitConstStmt(CONST_4,1, Integer.valueOf(-1)); // int: 0xffffffff  float:NaN
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,1},new Method("Lorg/mortbay/io/Buffer;","setMarkIndex",new String[]{ "I"},"V"));
                code.visitLabel(L35);
                code.visitFieldStmt(IGET_OBJECT,0,4,new Field("Lorg/mortbay/jetty/HttpParser;","_body","Lorg/mortbay/io/Buffer;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0},new Method("Lorg/mortbay/io/Buffer;","compact",new String[]{ },"V"));
                code.visitJumpStmt(GOTO,-1,-1,L25);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,0);
                code.visitStmt1R(MONITOR_EXIT,4);
                code.visitLabel(L1);
                code.visitStmt1R(THROW,0);
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,0,4,new Field("Lorg/mortbay/jetty/HttpParser;","_header","Lorg/mortbay/io/Buffer;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0},new Method("Lorg/mortbay/io/Buffer;","compact",new String[]{ },"V"));
                code.visitLabel(L36);
                code.visitFieldStmt(IGET_OBJECT,0,4,new Field("Lorg/mortbay/jetty/HttpParser;","_tok0","Lorg/mortbay/io/View$CaseInsensitive;"));
                code.visitFieldStmt(IGET_OBJECT,1,4,new Field("Lorg/mortbay/jetty/HttpParser;","_header","Lorg/mortbay/io/Buffer;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Lorg/mortbay/io/View$CaseInsensitive;","update",new String[]{ "Lorg/mortbay/io/Buffer;"},"V"));
                code.visitLabel(L37);
                code.visitFieldStmt(IGET_OBJECT,0,4,new Field("Lorg/mortbay/jetty/HttpParser;","_tok0","Lorg/mortbay/io/View$CaseInsensitive;"));
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1,2},new Method("Lorg/mortbay/io/View$CaseInsensitive;","update",new String[]{ "I","I"},"V"));
                code.visitLabel(L38);
                code.visitFieldStmt(IGET_OBJECT,0,4,new Field("Lorg/mortbay/jetty/HttpParser;","_tok1","Lorg/mortbay/io/View$CaseInsensitive;"));
                code.visitFieldStmt(IGET_OBJECT,1,4,new Field("Lorg/mortbay/jetty/HttpParser;","_header","Lorg/mortbay/io/Buffer;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Lorg/mortbay/io/View$CaseInsensitive;","update",new String[]{ "Lorg/mortbay/io/Buffer;"},"V"));
                code.visitLabel(L39);
                code.visitFieldStmt(IGET_OBJECT,0,4,new Field("Lorg/mortbay/jetty/HttpParser;","_tok1","Lorg/mortbay/io/View$CaseInsensitive;"));
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1,2},new Method("Lorg/mortbay/io/View$CaseInsensitive;","update",new String[]{ "I","I"},"V"));
                code.visitLabel(L4);
                code.visitJumpStmt(GOTO,-1,-1,L31);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m022_setForceContentBuffer(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/HttpParser;","setForceContentBuffer",new String[]{ "Z"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"force");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(1030,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(1031,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_BOOLEAN,1,0,new Field("Lorg/mortbay/jetty/HttpParser;","_forceContentBuffer","Z"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m023_setState(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/HttpParser;","setState",new String[]{ "I"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"state");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(992,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(993,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(994,L2);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT,3,2,new Field("Lorg/mortbay/jetty/HttpParser;","_state","I"));
                code.visitLabel(L1);
                code.visitConstStmt(CONST_WIDE_16,0,Long.valueOf(-3L)); // long: 0xfffffffffffffffd  double:NaN
                code.visitFieldStmt(IPUT_WIDE,0,2,new Field("Lorg/mortbay/jetty/HttpParser;","_contentLength","J"));
                code.visitLabel(L2);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m024_skipCRLF(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/HttpParser;","skipCRLF",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(6);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(896,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(898,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(899,L3);
                ddv.visitStartLocal(0,L3,"ch","B",null);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(901,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(902,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(908,L6);
                ddv.visitEndLocal(0,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(910,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(911,L8);
                ddv.visitRestartLocal(0,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(913,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(914,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(920,L11);
                ddv.visitEndLocal(0,L11);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_16,4, Integer.valueOf(13)); // int: 0x0000000d  float:0.000000
                code.visitConstStmt(CONST_16,3, Integer.valueOf(10)); // int: 0x0000000a  float:0.000000
                code.visitConstStmt(CONST_4,2, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,1,5,new Field("Lorg/mortbay/jetty/HttpParser;","_header","Lorg/mortbay/io/Buffer;"));
                code.visitJumpStmt(IF_EQZ,1,-1,L6);
                code.visitFieldStmt(IGET_OBJECT,1,5,new Field("Lorg/mortbay/jetty/HttpParser;","_header","Lorg/mortbay/io/Buffer;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 1},new Method("Lorg/mortbay/io/Buffer;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitJumpStmt(IF_LEZ,1,-1,L6);
                code.visitLabel(L2);
                code.visitFieldStmt(IGET_OBJECT,1,5,new Field("Lorg/mortbay/jetty/HttpParser;","_header","Lorg/mortbay/io/Buffer;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 1},new Method("Lorg/mortbay/io/Buffer;","peek",new String[]{ },"B"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitLabel(L3);
                code.visitJumpStmt(IF_EQ,0,4,L4);
                code.visitJumpStmt(IF_NE,0,3,L6);
                code.visitLabel(L4);
                code.visitFieldStmt(IPUT_BYTE,0,5,new Field("Lorg/mortbay/jetty/HttpParser;","_eol","B"));
                code.visitLabel(L5);
                code.visitFieldStmt(IGET_OBJECT,1,5,new Field("Lorg/mortbay/jetty/HttpParser;","_header","Lorg/mortbay/io/Buffer;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 1,2},new Method("Lorg/mortbay/io/Buffer;","skip",new String[]{ "I"},"I"));
                code.visitJumpStmt(GOTO,-1,-1,L1);
                code.visitLabel(L6);
                code.visitFieldStmt(IGET_OBJECT,1,5,new Field("Lorg/mortbay/jetty/HttpParser;","_body","Lorg/mortbay/io/Buffer;"));
                code.visitJumpStmt(IF_EQZ,1,-1,L11);
                code.visitFieldStmt(IGET_OBJECT,1,5,new Field("Lorg/mortbay/jetty/HttpParser;","_body","Lorg/mortbay/io/Buffer;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 1},new Method("Lorg/mortbay/io/Buffer;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitJumpStmt(IF_LEZ,1,-1,L11);
                code.visitLabel(L7);
                code.visitFieldStmt(IGET_OBJECT,1,5,new Field("Lorg/mortbay/jetty/HttpParser;","_body","Lorg/mortbay/io/Buffer;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 1},new Method("Lorg/mortbay/io/Buffer;","peek",new String[]{ },"B"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitLabel(L8);
                code.visitJumpStmt(IF_EQ,0,4,L9);
                code.visitJumpStmt(IF_NE,0,3,L11);
                code.visitLabel(L9);
                code.visitFieldStmt(IPUT_BYTE,0,5,new Field("Lorg/mortbay/jetty/HttpParser;","_eol","B"));
                code.visitLabel(L10);
                code.visitFieldStmt(IGET_OBJECT,1,5,new Field("Lorg/mortbay/jetty/HttpParser;","_body","Lorg/mortbay/io/Buffer;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 1,2},new Method("Lorg/mortbay/io/Buffer;","skip",new String[]{ "I"},"I"));
                code.visitJumpStmt(GOTO,-1,-1,L6);
                code.visitLabel(L11);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m025_toString(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/HttpParser;","toString",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(1005,L0);
                code.visitLabel(L0);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,1,"state=");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(IGET,1,3,new Field("Lorg/mortbay/jetty/HttpParser;","_state","I"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "I"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitConstStmt(CONST_STRING,1," length=");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(IGET,1,3,new Field("Lorg/mortbay/jetty/HttpParser;","_length","I"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "I"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitConstStmt(CONST_STRING,1," len=");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(IGET_WIDE,1,3,new Field("Lorg/mortbay/jetty/HttpParser;","_contentLength","J"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1,2},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "J"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m026_toString(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/HttpParser;","toString",new String[]{ "Lorg/mortbay/io/Buffer;"},"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"buf");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(999,L0);
                code.visitLabel(L0);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,1,"state=");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(IGET,1,2,new Field("Lorg/mortbay/jetty/HttpParser;","_state","I"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "I"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitConstStmt(CONST_STRING,1," length=");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(IGET,1,2,new Field("Lorg/mortbay/jetty/HttpParser;","_length","I"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "I"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitConstStmt(CONST_STRING,1," buf=");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Ljava/lang/Object;","hashCode",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "I"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
