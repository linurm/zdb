package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0270_org_mortbay_jetty_security_BasicAuthenticator {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(ACC_PUBLIC,"Lorg/mortbay/jetty/security/BasicAuthenticator;","Ljava/lang/Object;",new String[]{ "Lorg/mortbay/jetty/security/Authenticator;"});
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("BasicAuthenticator.java");
        m000__init_(cv);
        m001_authenticate(cv);
        m002_getAuthMethod(cv);
        m003_sendChallenge(cv);
    }
    public static void m000__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/jetty/security/BasicAuthenticator;","<init>",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(1);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(33,L0);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/lang/Object;","<init>",new String[]{ },"V"));
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001_authenticate(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/security/BasicAuthenticator;","authenticate",new String[]{ "Lorg/mortbay/jetty/security/UserRealm;","Ljava/lang/String;","Lorg/mortbay/jetty/Request;","Lorg/mortbay/jetty/Response;"},"Ljava/security/Principal;"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(13);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ "Ljava/lang/Exception;"});
                DexLabel L3=new DexLabel();
                DexLabel L4=new DexLabel();
                code.visitTryCatch(L3,L4,new DexLabel[]{L2},new String[]{ "Ljava/lang/Exception;"});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"realm");
                ddv.visitParameterName(1,"pathInContext");
                ddv.visitParameterName(2,"request");
                ddv.visitParameterName(3,"response");
                DexLabel L5=new DexLabel();
                ddv.visitPrologue(L5);
                ddv.visitLineNumber(49,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(50,L6);
                ddv.visitStartLocal(4,L6,"user","Ljava/security/Principal;",null);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(52,L7);
                ddv.visitStartLocal(0,L7,"credentials","Ljava/lang/String;",null);
                ddv.visitLineNumber(56,L0);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(57,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(58,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(59,L10);
                ddv.visitRestartLocal(0,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(60,L11);
                ddv.visitStartLocal(2,L11,"i","I",null);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(61,L12);
                ddv.visitStartLocal(5,L12,"username","Ljava/lang/String;",null);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(62,L13);
                ddv.visitStartLocal(3,L13,"password","Ljava/lang/String;",null);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(64,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(66,L15);
                ddv.visitLineNumber(82,L1);
                ddv.visitEndLocal(2,L1);
                ddv.visitEndLocal(5,L1);
                ddv.visitEndLocal(3,L1);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(83,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(85,L17);
                ddv.visitLineNumber(70,L3);
                ddv.visitRestartLocal(2,L3);
                ddv.visitRestartLocal(3,L3);
                ddv.visitRestartLocal(5,L3);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(71,L18);
                ddv.visitLineNumber(74,L2);
                ddv.visitEndLocal(2,L2);
                ddv.visitEndLocal(3,L2);
                ddv.visitEndLocal(5,L2);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(76,L19);
                ddv.visitStartLocal(1,L19,"e","Ljava/lang/Exception;",null);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(77,L20);
                code.visitLabel(L5);
                code.visitConstStmt(CONST_4,4, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L6);
                code.visitConstStmt(CONST_STRING,6,"Authorization");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 11,6},new Method("Lorg/mortbay/jetty/Request;","getHeader",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L7);
                code.visitJumpStmt(IF_EQZ,0,-1,L1);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Lorg/mortbay/log/Log;","isDebugEnabled",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,6);
                code.visitJumpStmt(IF_EQZ,6,-1,L8);
                code.visitTypeStmt(NEW_INSTANCE,6,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 6},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,7,"Credentials: ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,7},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,0},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 6},new Method("Lorg/mortbay/log/Log;","debug",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L8);
                code.visitConstStmt(CONST_16,6, Integer.valueOf(32)); // int: 0x00000020  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,6},new Method("Ljava/lang/String;","indexOf",new String[]{ "I"},"I"));
                code.visitStmt1R(MOVE_RESULT,6);
                code.visitStmt2R1N(ADD_INT_LIT8,6,6,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,6},new Method("Ljava/lang/String;","substring",new String[]{ "I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L9);
                code.visitFieldStmt(SGET_OBJECT,6,-1,new Field("Lorg/mortbay/util/StringUtil;","__ISO_8859_1","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0,6},new Method("Lorg/mortbay/jetty/security/B64Code;","decode",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L10);
                code.visitConstStmt(CONST_16,6, Integer.valueOf(58)); // int: 0x0000003a  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,6},new Method("Ljava/lang/String;","indexOf",new String[]{ "I"},"I"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitLabel(L11);
                code.visitConstStmt(CONST_4,6, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,6,2},new Method("Ljava/lang/String;","substring",new String[]{ "I","I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitLabel(L12);
                code.visitStmt2R1N(ADD_INT_LIT8,6,2,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,6},new Method("Ljava/lang/String;","substring",new String[]{ "I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitLabel(L13);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 9,5,3,11},new Method("Lorg/mortbay/jetty/security/UserRealm;","authenticate",new String[]{ "Ljava/lang/String;","Ljava/lang/Object;","Lorg/mortbay/jetty/Request;"},"Ljava/security/Principal;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitLabel(L14);
                code.visitJumpStmt(IF_NEZ,4,-1,L3);
                code.visitLabel(L15);
                code.visitConstStmt(CONST_STRING,6,"AUTH FAILURE: user {}");
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 5},new Method("Lorg/mortbay/util/StringUtil;","printable",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 6,7},new Method("Lorg/mortbay/log/Log;","warn",new String[]{ "Ljava/lang/String;","Ljava/lang/Object;"},"V"));
                code.visitLabel(L1);
                code.visitJumpStmt(IF_NEZ,4,-1,L17);
                code.visitJumpStmt(IF_EQZ,12,-1,L17);
                code.visitLabel(L16);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8,9,12},new Method("Lorg/mortbay/jetty/security/BasicAuthenticator;","sendChallenge",new String[]{ "Lorg/mortbay/jetty/security/UserRealm;","Lorg/mortbay/jetty/Response;"},"V"));
                code.visitLabel(L17);
                code.visitStmt1R(RETURN_OBJECT,4);
                code.visitLabel(L3);
                code.visitConstStmt(CONST_STRING,6,"BASIC");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 11,6},new Method("Lorg/mortbay/jetty/Request;","setAuthType",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L18);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 11,4},new Method("Lorg/mortbay/jetty/Request;","setUserPrincipal",new String[]{ "Ljava/security/Principal;"},"V"));
                code.visitLabel(L4);
                code.visitJumpStmt(GOTO,-1,-1,L1);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,6);
                code.visitStmt2R(MOVE_OBJECT,1,6);
                code.visitLabel(L19);
                code.visitTypeStmt(NEW_INSTANCE,6,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 6},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,7,"AUTH FAILURE: ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,7},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/lang/Exception;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,7},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 6},new Method("Lorg/mortbay/log/Log;","warn",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L20);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1},new Method("Lorg/mortbay/log/Log;","ignore",new String[]{ "Ljava/lang/Throwable;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L1);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m002_getAuthMethod(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/security/BasicAuthenticator;","getAuthMethod",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(91,L0);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_STRING,0,"BASIC");
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m003_sendChallenge(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/security/BasicAuthenticator;","sendChallenge",new String[]{ "Lorg/mortbay/jetty/security/UserRealm;","Lorg/mortbay/jetty/Response;"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(6);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"realm");
                ddv.visitParameterName(1,"response");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(98,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(99,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(100,L2);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_STRING,0,"WWW-Authenticate");
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,2,"Basic realm=\"");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 4},new Method("Lorg/mortbay/jetty/security/UserRealm;","getName",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitConstStmt(CONST_16,2, Integer.valueOf(34)); // int: 0x00000022  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "C"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,0,1},new Method("Lorg/mortbay/jetty/Response;","setHeader",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"V"));
                code.visitLabel(L1);
                code.visitConstStmt(CONST_16,0, Integer.valueOf(401)); // int: 0x00000191  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,0},new Method("Lorg/mortbay/jetty/Response;","sendError",new String[]{ "I"},"V"));
                code.visitLabel(L2);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
