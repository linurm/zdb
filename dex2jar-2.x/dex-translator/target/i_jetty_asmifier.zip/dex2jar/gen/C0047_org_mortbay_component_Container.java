package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0047_org_mortbay_component_Container {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(ACC_PUBLIC,"Lorg/mortbay/component/Container;","Ljava/lang/Object;",new String[]{ });
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("Container.java");
        if(cv!=null){
            DexAnnotationVisitor av00 = cv.visitAnnotation("Ldalvik/annotation/MemberClasses;", Visibility.SYSTEM);
            if(av00 != null) {
                {
                    DexAnnotationVisitor av01 = av00.visitArray("value");
                    if(av01 != null) {
                        av01.visit(null, new DexType("Lorg/mortbay/component/Container$1;"));
                        av01.visit(null, new DexType("Lorg/mortbay/component/Container$Listener;"));
                        av01.visit(null, new DexType("Lorg/mortbay/component/Container$Relationship;"));
                        av01.visitEnd();
                    }
                }
                av00.visitEnd();
            }
        }
        f000__listeners(cv);
        m000__init_(cv);
        m001_add(cv);
        m002_remove(cv);
        m003_addBean(cv);
        m004_addEventListener(cv);
        m005_removeBean(cv);
        m006_removeEventListener(cv);
        m007_update(cv);
        m008_update(cv);
        m009_update(cv);
        m010_update(cv);
    }
    public static void f000__listeners(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/component/Container;","_listeners","Ljava/lang/Object;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void m000__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/component/Container;","<init>",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(1);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(42,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(291,L1);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/lang/Object;","<init>",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001_add(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PRIVATE, new Method("Lorg/mortbay/component/Container;","add",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;","Ljava/lang/String;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(11);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"parent");
                ddv.visitParameterName(1,"child");
                ddv.visitParameterName(2,"relationship");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(200,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(201,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(202,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(204,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(205,L4);
                ddv.visitStartLocal(0,L4,"event","Lorg/mortbay/component/Container$Relationship;",null);
                DexLabel L5=new DexLabel();
                ddv.visitStartLocal(6,L5,"i","I",null);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(206,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(205,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(208,L8);
                ddv.visitEndLocal(0,L8);
                ddv.visitEndLocal(6,L8);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Lorg/mortbay/log/Log;","isDebugEnabled",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitJumpStmt(IF_EQZ,1,-1,L2);
                code.visitLabel(L1);
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,2,"Container ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,8},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitConstStmt(CONST_STRING,2," + ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,9},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitConstStmt(CONST_STRING,2," as ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,10},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1},new Method("Lorg/mortbay/log/Log;","debug",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L2);
                code.visitFieldStmt(IGET_OBJECT,1,7,new Field("Lorg/mortbay/component/Container;","_listeners","Ljava/lang/Object;"));
                code.visitJumpStmt(IF_EQZ,1,-1,L8);
                code.visitLabel(L3);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Lorg/mortbay/component/Container$Relationship;");
                code.visitConstStmt(CONST_4,5, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitStmt2R(MOVE_OBJECT,1,7);
                code.visitStmt2R(MOVE_OBJECT,2,8);
                code.visitStmt2R(MOVE_OBJECT,3,9);
                code.visitStmt2R(MOVE_OBJECT,4,10);
                code.visitMethodStmt(INVOKE_DIRECT_RANGE,new int[]{ 0,1,2,3,4,5},new Method("Lorg/mortbay/component/Container$Relationship;","<init>",new String[]{ "Lorg/mortbay/component/Container;","Ljava/lang/Object;","Ljava/lang/Object;","Ljava/lang/String;","Lorg/mortbay/component/Container$1;"},"V"));
                code.visitLabel(L4);
                code.visitConstStmt(CONST_4,6, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L5);
                code.visitFieldStmt(IGET_OBJECT,1,7,new Field("Lorg/mortbay/component/Container;","_listeners","Ljava/lang/Object;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1},new Method("Lorg/mortbay/util/LazyList;","size",new String[]{ "Ljava/lang/Object;"},"I"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitJumpStmt(IF_GE,6,1,L8);
                code.visitLabel(L6);
                code.visitFieldStmt(IGET_OBJECT,1,7,new Field("Lorg/mortbay/component/Container;","_listeners","Ljava/lang/Object;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1,6},new Method("Lorg/mortbay/util/LazyList;","get",new String[]{ "Ljava/lang/Object;","I"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitTypeStmt(CHECK_CAST,1,-1,"Lorg/mortbay/component/Container$Listener;");
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 1,0},new Method("Lorg/mortbay/component/Container$Listener;","add",new String[]{ "Lorg/mortbay/component/Container$Relationship;"},"V"));
                code.visitLabel(L7);
                code.visitStmt2R1N(ADD_INT_LIT8,6,6,1);
                code.visitJumpStmt(GOTO,-1,-1,L5);
                code.visitLabel(L8);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m002_remove(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PRIVATE, new Method("Lorg/mortbay/component/Container;","remove",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;","Ljava/lang/String;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(11);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"parent");
                ddv.visitParameterName(1,"child");
                ddv.visitParameterName(2,"relationship");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(218,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(219,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(220,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(222,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(223,L4);
                ddv.visitStartLocal(0,L4,"event","Lorg/mortbay/component/Container$Relationship;",null);
                DexLabel L5=new DexLabel();
                ddv.visitStartLocal(6,L5,"i","I",null);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(224,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(223,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(226,L8);
                ddv.visitEndLocal(0,L8);
                ddv.visitEndLocal(6,L8);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Lorg/mortbay/log/Log;","isDebugEnabled",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitJumpStmt(IF_EQZ,1,-1,L2);
                code.visitLabel(L1);
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,2,"Container ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,8},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitConstStmt(CONST_STRING,2," - ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,9},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitConstStmt(CONST_STRING,2," as ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,10},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1},new Method("Lorg/mortbay/log/Log;","debug",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L2);
                code.visitFieldStmt(IGET_OBJECT,1,7,new Field("Lorg/mortbay/component/Container;","_listeners","Ljava/lang/Object;"));
                code.visitJumpStmt(IF_EQZ,1,-1,L8);
                code.visitLabel(L3);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Lorg/mortbay/component/Container$Relationship;");
                code.visitConstStmt(CONST_4,5, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitStmt2R(MOVE_OBJECT,1,7);
                code.visitStmt2R(MOVE_OBJECT,2,8);
                code.visitStmt2R(MOVE_OBJECT,3,9);
                code.visitStmt2R(MOVE_OBJECT,4,10);
                code.visitMethodStmt(INVOKE_DIRECT_RANGE,new int[]{ 0,1,2,3,4,5},new Method("Lorg/mortbay/component/Container$Relationship;","<init>",new String[]{ "Lorg/mortbay/component/Container;","Ljava/lang/Object;","Ljava/lang/Object;","Ljava/lang/String;","Lorg/mortbay/component/Container$1;"},"V"));
                code.visitLabel(L4);
                code.visitConstStmt(CONST_4,6, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L5);
                code.visitFieldStmt(IGET_OBJECT,1,7,new Field("Lorg/mortbay/component/Container;","_listeners","Ljava/lang/Object;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1},new Method("Lorg/mortbay/util/LazyList;","size",new String[]{ "Ljava/lang/Object;"},"I"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitJumpStmt(IF_GE,6,1,L8);
                code.visitLabel(L6);
                code.visitFieldStmt(IGET_OBJECT,1,7,new Field("Lorg/mortbay/component/Container;","_listeners","Ljava/lang/Object;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1,6},new Method("Lorg/mortbay/util/LazyList;","get",new String[]{ "Ljava/lang/Object;","I"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitTypeStmt(CHECK_CAST,1,-1,"Lorg/mortbay/component/Container$Listener;");
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 1,0},new Method("Lorg/mortbay/component/Container$Listener;","remove",new String[]{ "Lorg/mortbay/component/Container$Relationship;"},"V"));
                code.visitLabel(L7);
                code.visitStmt2R1N(ADD_INT_LIT8,6,6,1);
                code.visitJumpStmt(GOTO,-1,-1,L5);
                code.visitLabel(L8);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m003_addBean(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/component/Container;","addBean",new String[]{ "Ljava/lang/Object;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"obj");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(172,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(174,L1);
                DexLabel L2=new DexLabel();
                ddv.visitStartLocal(0,L2,"i","I",null);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(176,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(177,L4);
                ddv.visitStartLocal(1,L4,"listener","Lorg/mortbay/component/Container$Listener;",null);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(174,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(180,L6);
                ddv.visitEndLocal(0,L6);
                ddv.visitEndLocal(1,L6);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,2,3,new Field("Lorg/mortbay/component/Container;","_listeners","Ljava/lang/Object;"));
                code.visitJumpStmt(IF_EQZ,2,-1,L6);
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L2);
                code.visitFieldStmt(IGET_OBJECT,2,3,new Field("Lorg/mortbay/component/Container;","_listeners","Ljava/lang/Object;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 2},new Method("Lorg/mortbay/util/LazyList;","size",new String[]{ "Ljava/lang/Object;"},"I"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitJumpStmt(IF_GE,0,2,L6);
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,2,3,new Field("Lorg/mortbay/component/Container;","_listeners","Ljava/lang/Object;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 2,0},new Method("Lorg/mortbay/util/LazyList;","get",new String[]{ "Ljava/lang/Object;","I"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitTypeStmt(CHECK_CAST,1,-1,"Lorg/mortbay/component/Container$Listener;");
                code.visitLabel(L4);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 1,4},new Method("Lorg/mortbay/component/Container$Listener;","addBean",new String[]{ "Ljava/lang/Object;"},"V"));
                code.visitLabel(L5);
                code.visitStmt2R1N(ADD_INT_LIT8,0,0,1);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitLabel(L6);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m004_addEventListener(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/component/Container;","addEventListener",new String[]{ "Lorg/mortbay/component/Container$Listener;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"listener");
                DexLabel L3=new DexLabel();
                ddv.visitPrologue(L3);
                ddv.visitLineNumber(48,L3);
                ddv.visitLineNumber(49,L1);
                ddv.visitLineNumber(48,L2);
                code.visitLabel(L3);
                code.visitStmt1R(MONITOR_ENTER,1);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/component/Container;","_listeners","Ljava/lang/Object;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0,2},new Method("Lorg/mortbay/util/LazyList;","add",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/component/Container;","_listeners","Ljava/lang/Object;"));
                code.visitLabel(L1);
                code.visitStmt1R(MONITOR_EXIT,1);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,0);
                code.visitStmt1R(MONITOR_EXIT,1);
                code.visitStmt1R(THROW,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m005_removeBean(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/component/Container;","removeBean",new String[]{ "Ljava/lang/Object;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"obj");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(185,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(187,L1);
                DexLabel L2=new DexLabel();
                ddv.visitStartLocal(0,L2,"i","I",null);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(188,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(187,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(190,L5);
                ddv.visitEndLocal(0,L5);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/component/Container;","_listeners","Ljava/lang/Object;"));
                code.visitJumpStmt(IF_EQZ,1,-1,L5);
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L2);
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/component/Container;","_listeners","Ljava/lang/Object;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1},new Method("Lorg/mortbay/util/LazyList;","size",new String[]{ "Ljava/lang/Object;"},"I"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitJumpStmt(IF_GE,0,1,L5);
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/component/Container;","_listeners","Ljava/lang/Object;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1,0},new Method("Lorg/mortbay/util/LazyList;","get",new String[]{ "Ljava/lang/Object;","I"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitTypeStmt(CHECK_CAST,1,-1,"Lorg/mortbay/component/Container$Listener;");
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 1,3},new Method("Lorg/mortbay/component/Container$Listener;","removeBean",new String[]{ "Ljava/lang/Object;"},"V"));
                code.visitLabel(L4);
                code.visitStmt2R1N(ADD_INT_LIT8,0,0,1);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitLabel(L5);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m006_removeEventListener(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/component/Container;","removeEventListener",new String[]{ "Lorg/mortbay/component/Container$Listener;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"listener");
                DexLabel L3=new DexLabel();
                ddv.visitPrologue(L3);
                ddv.visitLineNumber(53,L3);
                ddv.visitLineNumber(54,L1);
                ddv.visitLineNumber(53,L2);
                code.visitLabel(L3);
                code.visitStmt1R(MONITOR_ENTER,1);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/component/Container;","_listeners","Ljava/lang/Object;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0,2},new Method("Lorg/mortbay/util/LazyList;","remove",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/component/Container;","_listeners","Ljava/lang/Object;"));
                code.visitLabel(L1);
                code.visitStmt1R(MONITOR_EXIT,1);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,0);
                code.visitStmt1R(MONITOR_EXIT,1);
                code.visitStmt1R(THROW,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m007_update(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/component/Container;","update",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;","Ljava/lang/Object;","Ljava/lang/String;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(6);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"parent");
                ddv.visitParameterName(1,"oldChild");
                ddv.visitParameterName(2,"child");
                ddv.visitParameterName(3,"relationship");
                DexLabel L3=new DexLabel();
                ddv.visitPrologue(L3);
                ddv.visitLineNumber(65,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(66,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(67,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(68,L6);
                ddv.visitLineNumber(69,L1);
                ddv.visitLineNumber(65,L2);
                code.visitLabel(L3);
                code.visitStmt1R(MONITOR_ENTER,1);
                code.visitJumpStmt(IF_EQZ,3,-1,L5);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,4},new Method("Ljava/lang/Object;","equals",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_NEZ,0,-1,L5);
                code.visitLabel(L4);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1,2,3,5},new Method("Lorg/mortbay/component/Container;","remove",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;","Ljava/lang/String;"},"V"));
                code.visitLabel(L5);
                code.visitJumpStmt(IF_EQZ,4,-1,L1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,3},new Method("Ljava/lang/Object;","equals",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_NEZ,0,-1,L1);
                code.visitLabel(L6);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1,2,4,5},new Method("Lorg/mortbay/component/Container;","add",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;","Ljava/lang/String;"},"V"));
                code.visitLabel(L1);
                code.visitStmt1R(MONITOR_EXIT,1);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,0);
                code.visitStmt1R(MONITOR_EXIT,1);
                code.visitStmt1R(THROW,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m008_update(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/component/Container;","update",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;","Ljava/lang/Object;","Ljava/lang/String;","Z"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(7);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"parent");
                ddv.visitParameterName(1,"oldChild");
                ddv.visitParameterName(2,"child");
                ddv.visitParameterName(3,"relationship");
                ddv.visitParameterName(4,"addRemove");
                DexLabel L3=new DexLabel();
                ddv.visitPrologue(L3);
                ddv.visitLineNumber(81,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(83,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(84,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(85,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(88,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(90,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(91,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(92,L10);
                ddv.visitLineNumber(94,L1);
                ddv.visitLineNumber(81,L2);
                code.visitLabel(L3);
                code.visitStmt1R(MONITOR_ENTER,1);
                code.visitJumpStmt(IF_EQZ,3,-1,L7);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,4},new Method("Ljava/lang/Object;","equals",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_NEZ,0,-1,L7);
                code.visitLabel(L4);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1,2,3,5},new Method("Lorg/mortbay/component/Container;","remove",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;","Ljava/lang/String;"},"V"));
                code.visitLabel(L5);
                code.visitJumpStmt(IF_EQZ,6,-1,L7);
                code.visitLabel(L6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,3},new Method("Lorg/mortbay/component/Container;","removeBean",new String[]{ "Ljava/lang/Object;"},"V"));
                code.visitLabel(L7);
                code.visitJumpStmt(IF_EQZ,4,-1,L1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,3},new Method("Ljava/lang/Object;","equals",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_NEZ,0,-1,L1);
                code.visitLabel(L8);
                code.visitJumpStmt(IF_EQZ,6,-1,L10);
                code.visitLabel(L9);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,4},new Method("Lorg/mortbay/component/Container;","addBean",new String[]{ "Ljava/lang/Object;"},"V"));
                code.visitLabel(L10);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1,2,4,5},new Method("Lorg/mortbay/component/Container;","add",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;","Ljava/lang/String;"},"V"));
                code.visitLabel(L1);
                code.visitStmt1R(MONITOR_EXIT,1);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,0);
                code.visitStmt1R(MONITOR_EXIT,1);
                code.visitStmt1R(THROW,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m009_update(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/component/Container;","update",new String[]{ "Ljava/lang/Object;","[Ljava/lang/Object;","[Ljava/lang/Object;","Ljava/lang/String;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(11);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"parent");
                ddv.visitParameterName(1,"oldChildren");
                ddv.visitParameterName(2,"children");
                ddv.visitParameterName(3,"relationship");
                DexLabel L3=new DexLabel();
                ddv.visitPrologue(L3);
                ddv.visitLineNumber(106,L3);
                ddv.visitLineNumber(107,L1);
                ddv.visitLineNumber(106,L2);
                code.visitLabel(L3);
                code.visitStmt1R(MONITOR_ENTER,6);
                code.visitConstStmt(CONST_4,5, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitStmt2R(MOVE_OBJECT,0,6);
                code.visitStmt2R(MOVE_OBJECT,1,7);
                code.visitStmt2R(MOVE_OBJECT,2,8);
                code.visitStmt2R(MOVE_OBJECT,3,9);
                code.visitStmt2R(MOVE_OBJECT,4,10);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 0,1,2,3,4,5},new Method("Lorg/mortbay/component/Container;","update",new String[]{ "Ljava/lang/Object;","[Ljava/lang/Object;","[Ljava/lang/Object;","Ljava/lang/String;","Z"},"V"));
                code.visitLabel(L1);
                code.visitStmt1R(MONITOR_EXIT,6);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,0);
                code.visitStmt1R(MONITOR_EXIT,6);
                code.visitStmt1R(THROW,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m010_update(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/component/Container;","update",new String[]{ "Ljava/lang/Object;","[Ljava/lang/Object;","[Ljava/lang/Object;","Ljava/lang/String;","Z"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(15);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"parent");
                ddv.visitParameterName(1,"oldChildren");
                ddv.visitParameterName(2,"children");
                ddv.visitParameterName(3,"relationship");
                ddv.visitParameterName(4,"addRemove");
                DexLabel L3=new DexLabel();
                ddv.visitPrologue(L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(120,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(121,L5);
                ddv.visitStartLocal(4,L5,"newChildren","[Ljava/lang/Object;",null);
                ddv.visitLineNumber(123,L0);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(125,L6);
                DexLabel L7=new DexLabel();
                ddv.visitStartLocal(0,L7,"i","I",null);
                DexLabel L8=new DexLabel();
                ddv.visitEndLocal(0,L8);
                ddv.visitStartLocal(1,L8,"i","I",null);
                DexLabel L9=new DexLabel();
                ddv.visitRestartLocal(0,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(127,L10);
                ddv.visitEndLocal(1,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(128,L11);
                ddv.visitStartLocal(5,L11,"new_child","Z",null);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(130,L12);
                DexLabel L13=new DexLabel();
                ddv.visitStartLocal(2,L13,"j","I",null);
                DexLabel L14=new DexLabel();
                ddv.visitEndLocal(2,L14);
                ddv.visitStartLocal(3,L14,"j","I",null);
                DexLabel L15=new DexLabel();
                ddv.visitRestartLocal(2,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(132,L16);
                ddv.visitEndLocal(3,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(134,L17);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(135,L18);
                DexLabel L19=new DexLabel();
                ddv.visitRestartLocal(3,L19);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(139,L20);
                ddv.visitEndLocal(2,L20);
                ddv.visitEndLocal(3,L20);
                DexLabel L21=new DexLabel();
                ddv.visitLineNumber(140,L21);
                DexLabel L22=new DexLabel();
                ddv.visitLineNumber(141,L22);
                ddv.visitRestartLocal(1,L22);
                DexLabel L23=new DexLabel();
                ddv.visitLineNumber(144,L23);
                ddv.visitEndLocal(0,L23);
                ddv.visitEndLocal(5,L23);
                ddv.visitEndLocal(1,L23);
                DexLabel L24=new DexLabel();
                ddv.visitLineNumber(146,L24);
                DexLabel L25=new DexLabel();
                ddv.visitRestartLocal(0,L25);
                DexLabel L26=new DexLabel();
                ddv.visitEndLocal(0,L26);
                ddv.visitRestartLocal(1,L26);
                DexLabel L27=new DexLabel();
                ddv.visitRestartLocal(0,L27);
                DexLabel L28=new DexLabel();
                ddv.visitLineNumber(148,L28);
                ddv.visitEndLocal(1,L28);
                DexLabel L29=new DexLabel();
                ddv.visitLineNumber(150,L29);
                DexLabel L30=new DexLabel();
                ddv.visitLineNumber(151,L30);
                DexLabel L31=new DexLabel();
                ddv.visitLineNumber(152,L31);
                DexLabel L32=new DexLabel();
                ddv.visitRestartLocal(1,L32);
                DexLabel L33=new DexLabel();
                ddv.visitLineNumber(157,L33);
                ddv.visitEndLocal(0,L33);
                ddv.visitEndLocal(1,L33);
                DexLabel L34=new DexLabel();
                ddv.visitLineNumber(159,L34);
                DexLabel L35=new DexLabel();
                ddv.visitRestartLocal(0,L35);
                DexLabel L36=new DexLabel();
                ddv.visitLineNumber(160,L36);
                DexLabel L37=new DexLabel();
                ddv.visitLineNumber(162,L37);
                DexLabel L38=new DexLabel();
                ddv.visitLineNumber(163,L38);
                DexLabel L39=new DexLabel();
                ddv.visitLineNumber(164,L39);
                ddv.visitLineNumber(159,L1);
                DexLabel L40=new DexLabel();
                ddv.visitLineNumber(167,L40);
                ddv.visitEndLocal(0,L40);
                ddv.visitLineNumber(120,L2);
                DexLabel L41=new DexLabel();
                ddv.visitRestartLocal(0,L41);
                DexLabel L42=new DexLabel();
                ddv.visitRestartLocal(1,L42);
                DexLabel L43=new DexLabel();
                ddv.visitEndLocal(1,L43);
                ddv.visitRestartLocal(2,L43);
                ddv.visitRestartLocal(5,L43);
                DexLabel L44=new DexLabel();
                ddv.visitRestartLocal(3,L44);
                code.visitLabel(L3);
                code.visitConstStmt(CONST_4,8, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitLabel(L4);
                code.visitStmt1R(MONITOR_ENTER,9);
                code.visitConstStmt(CONST_4,4, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L5);
                code.visitJumpStmt(IF_EQZ,12,-1,L23);
                code.visitLabel(L0);
                code.visitStmt2R(ARRAY_LENGTH,6,12);
                code.visitTypeStmt(NEW_ARRAY,4,6,"[Ljava/lang/Object;");
                code.visitLabel(L6);
                code.visitStmt2R(ARRAY_LENGTH,0,12);
                code.visitLabel(L7);
                code.visitStmt2R(MOVE,1,0);
                code.visitLabel(L8);
                code.visitStmt3R(SUB_INT,0,1,8);
                code.visitLabel(L9);
                code.visitJumpStmt(IF_LEZ,1,-1,L23);
                code.visitLabel(L10);
                code.visitConstStmt(CONST_4,5, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitLabel(L11);
                code.visitJumpStmt(IF_EQZ,11,-1,L20);
                code.visitLabel(L12);
                code.visitStmt2R(ARRAY_LENGTH,2,11);
                code.visitLabel(L13);
                code.visitStmt2R(MOVE,3,2);
                code.visitLabel(L14);
                code.visitStmt3R(SUB_INT,2,3,8);
                code.visitLabel(L15);
                code.visitJumpStmt(IF_LEZ,3,-1,L20);
                code.visitLabel(L16);
                code.visitStmt3R(AGET_OBJECT,6,12,0);
                code.visitJumpStmt(IF_EQZ,6,-1,L43);
                code.visitStmt3R(AGET_OBJECT,6,12,0);
                code.visitStmt3R(AGET_OBJECT,7,11,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,7},new Method("Ljava/lang/Object;","equals",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,6);
                code.visitJumpStmt(IF_EQZ,6,-1,L43);
                code.visitLabel(L17);
                code.visitConstStmt(CONST_4,6, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitStmt3R(APUT_OBJECT,6,11,2);
                code.visitLabel(L18);
                code.visitConstStmt(CONST_4,5, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitStmt2R(MOVE,3,2);
                code.visitLabel(L19);
                code.visitJumpStmt(GOTO,-1,-1,L14);
                code.visitLabel(L20);
                DexLabel L45=new DexLabel();
                code.visitJumpStmt(IF_EQZ,5,-1,L45);
                code.visitLabel(L21);
                code.visitStmt3R(AGET_OBJECT,6,12,0);
                code.visitStmt3R(APUT_OBJECT,6,4,0);
                code.visitLabel(L45);
                code.visitStmt2R(MOVE,1,0);
                code.visitLabel(L22);
                code.visitJumpStmt(GOTO,-1,-1,L8);
                code.visitLabel(L23);
                code.visitJumpStmt(IF_EQZ,11,-1,L33);
                code.visitLabel(L24);
                code.visitStmt2R(ARRAY_LENGTH,0,11);
                code.visitLabel(L25);
                code.visitStmt2R(MOVE,1,0);
                code.visitLabel(L26);
                code.visitStmt3R(SUB_INT,0,1,8);
                code.visitLabel(L27);
                code.visitJumpStmt(IF_LEZ,1,-1,L33);
                code.visitLabel(L28);
                code.visitStmt3R(AGET_OBJECT,6,11,0);
                code.visitJumpStmt(IF_EQZ,6,-1,L41);
                code.visitLabel(L29);
                code.visitStmt3R(AGET_OBJECT,6,11,0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 9,10,6,13},new Method("Lorg/mortbay/component/Container;","remove",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;","Ljava/lang/String;"},"V"));
                code.visitLabel(L30);
                code.visitJumpStmt(IF_EQZ,14,-1,L41);
                code.visitLabel(L31);
                code.visitStmt3R(AGET_OBJECT,6,11,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9,6},new Method("Lorg/mortbay/component/Container;","removeBean",new String[]{ "Ljava/lang/Object;"},"V"));
                code.visitStmt2R(MOVE,1,0);
                code.visitLabel(L32);
                code.visitJumpStmt(GOTO,-1,-1,L26);
                code.visitLabel(L33);
                code.visitJumpStmt(IF_EQZ,4,-1,L40);
                code.visitLabel(L34);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L35);
                code.visitStmt2R(ARRAY_LENGTH,6,4);
                code.visitJumpStmt(IF_GE,0,6,L40);
                code.visitLabel(L36);
                code.visitStmt3R(AGET_OBJECT,6,4,0);
                code.visitJumpStmt(IF_EQZ,6,-1,L1);
                code.visitLabel(L37);
                code.visitJumpStmt(IF_EQZ,14,-1,L39);
                code.visitLabel(L38);
                code.visitStmt3R(AGET_OBJECT,6,4,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9,6},new Method("Lorg/mortbay/component/Container;","addBean",new String[]{ "Ljava/lang/Object;"},"V"));
                code.visitLabel(L39);
                code.visitStmt3R(AGET_OBJECT,6,4,0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 9,10,6,13},new Method("Lorg/mortbay/component/Container;","add",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;","Ljava/lang/String;"},"V"));
                code.visitLabel(L1);
                code.visitStmt2R1N(ADD_INT_LIT8,0,0,1);
                code.visitJumpStmt(GOTO,-1,-1,L35);
                code.visitLabel(L40);
                code.visitStmt1R(MONITOR_EXIT,9);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,6);
                code.visitStmt1R(MONITOR_EXIT,9);
                code.visitStmt1R(THROW,6);
                code.visitLabel(L41);
                code.visitStmt2R(MOVE,1,0);
                code.visitLabel(L42);
                code.visitJumpStmt(GOTO,-1,-1,L26);
                code.visitLabel(L43);
                code.visitStmt2R(MOVE,3,2);
                code.visitLabel(L44);
                code.visitJumpStmt(GOTO,-1,-1,L14);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
