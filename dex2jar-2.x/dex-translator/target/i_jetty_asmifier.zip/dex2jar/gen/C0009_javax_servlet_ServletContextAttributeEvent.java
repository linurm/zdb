package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0009_javax_servlet_ServletContextAttributeEvent {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(ACC_PUBLIC,"Ljavax/servlet/ServletContextAttributeEvent;","Ljavax/servlet/ServletContextEvent;",new String[]{ });
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("ServletContextAttributeEvent.java");
        f000_name(cv);
        f001_value(cv);
        m000__init_(cv);
        m001_getName(cv);
        m002_getValue(cv);
    }
    public static void f000_name(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Ljavax/servlet/ServletContextAttributeEvent;","name","Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f001_value(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Ljavax/servlet/ServletContextAttributeEvent;","value","Ljava/lang/Object;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void m000__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Ljavax/servlet/ServletContextAttributeEvent;","<init>",new String[]{ "Ljavax/servlet/ServletContext;","Ljava/lang/String;","Ljava/lang/Object;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"source");
                ddv.visitParameterName(1,"name");
                ddv.visitParameterName(2,"value");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(46,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(47,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(48,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(49,L3);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1},new Method("Ljavax/servlet/ServletContextEvent;","<init>",new String[]{ "Ljavax/servlet/ServletContext;"},"V"));
                code.visitLabel(L1);
                code.visitFieldStmt(IPUT_OBJECT,2,0,new Field("Ljavax/servlet/ServletContextAttributeEvent;","name","Ljava/lang/String;"));
                code.visitLabel(L2);
                code.visitFieldStmt(IPUT_OBJECT,3,0,new Field("Ljavax/servlet/ServletContextAttributeEvent;","value","Ljava/lang/Object;"));
                code.visitLabel(L3);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001_getName(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Ljavax/servlet/ServletContextAttributeEvent;","getName",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(56,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Ljavax/servlet/ServletContextAttributeEvent;","name","Ljava/lang/String;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m002_getValue(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Ljavax/servlet/ServletContextAttributeEvent;","getValue",new String[]{ },"Ljava/lang/Object;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(68,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Ljavax/servlet/ServletContextAttributeEvent;","value","Ljava/lang/Object;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
