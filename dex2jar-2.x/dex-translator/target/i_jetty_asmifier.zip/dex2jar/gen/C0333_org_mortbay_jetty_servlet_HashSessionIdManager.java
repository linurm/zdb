package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0333_org_mortbay_jetty_servlet_HashSessionIdManager {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(ACC_PUBLIC,"Lorg/mortbay/jetty/servlet/HashSessionIdManager;","Lorg/mortbay/component/AbstractLifeCycle;",new String[]{ "Lorg/mortbay/jetty/SessionIdManager;"});
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("HashSessionIdManager.java");
        f000_SESSION_ID_RANDOM_ALGORITHM(cv);
        f001_SESSION_ID_RANDOM_ALGORITHM_ALT(cv);
        f002___NEW_SESSION_ID(cv);
        f003__random(cv);
        f004__sessions(cv);
        f005__weakRandom(cv);
        f006__workerName(cv);
        m000__init_(cv);
        m001__init_(cv);
        m002_addSession(cv);
        m003_doStart(cv);
        m004_doStop(cv);
        m005_getClusterId(cv);
        m006_getNodeId(cv);
        m007_getRandom(cv);
        m008_getWorkerName(cv);
        m009_idInUse(cv);
        m010_invalidateAll(cv);
        m011_newSessionId(cv);
        m012_removeSession(cv);
        m013_setRandom(cv);
        m014_setWorkerName(cv);
    }
    public static void f000_SESSION_ID_RANDOM_ALGORITHM(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PROTECTED|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/servlet/HashSessionIdManager;","SESSION_ID_RANDOM_ALGORITHM","Ljava/lang/String;"), "SHA1PRNG");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f001_SESSION_ID_RANDOM_ALGORITHM_ALT(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PROTECTED|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/servlet/HashSessionIdManager;","SESSION_ID_RANDOM_ALGORITHM_ALT","Ljava/lang/String;"), "IBMSecureRandom");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f002___NEW_SESSION_ID(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/jetty/servlet/HashSessionIdManager;","__NEW_SESSION_ID","Ljava/lang/String;"), "org.mortbay.jetty.newSessionId");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f003__random(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PROTECTED, new Field("Lorg/mortbay/jetty/servlet/HashSessionIdManager;","_random","Ljava/util/Random;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f004__sessions(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(0, new Field("Lorg/mortbay/jetty/servlet/HashSessionIdManager;","_sessions","Lorg/mortbay/util/MultiMap;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f005__weakRandom(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/servlet/HashSessionIdManager;","_weakRandom","Z"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f006__workerName(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/servlet/HashSessionIdManager;","_workerName","Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void m000__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/jetty/servlet/HashSessionIdManager;","<init>",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(1);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(47,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(48,L1);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Lorg/mortbay/component/AbstractLifeCycle;","<init>",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/jetty/servlet/HashSessionIdManager;","<init>",new String[]{ "Ljava/util/Random;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"random");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(52,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(53,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(55,L2);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Lorg/mortbay/component/AbstractLifeCycle;","<init>",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitFieldStmt(IPUT_OBJECT,1,0,new Field("Lorg/mortbay/jetty/servlet/HashSessionIdManager;","_random","Ljava/util/Random;"));
                code.visitLabel(L2);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m002_addSession(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/servlet/HashSessionIdManager;","addSession",new String[]{ "Ljavax/servlet/http/HttpSession;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"session");
                DexLabel L3=new DexLabel();
                ddv.visitPrologue(L3);
                ddv.visitLineNumber(166,L3);
                ddv.visitLineNumber(168,L0);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(169,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(170,L5);
                ddv.visitLineNumber(169,L2);
                code.visitLabel(L3);
                code.visitStmt1R(MONITOR_ENTER,2);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/jetty/servlet/HashSessionIdManager;","_sessions","Lorg/mortbay/util/MultiMap;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 3},new Method("Ljavax/servlet/http/HttpSession;","getId",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,1},new Method("Lorg/mortbay/jetty/servlet/HashSessionIdManager;","getClusterId",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1,3},new Method("Lorg/mortbay/util/MultiMap;","add",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;"},"V"));
                code.visitLabel(L4);
                code.visitStmt1R(MONITOR_EXIT,2);
                code.visitLabel(L5);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,0);
                code.visitStmt1R(MONITOR_EXIT,2);
                code.visitLabel(L1);
                code.visitStmt1R(THROW,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m003_doStart(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Lorg/mortbay/jetty/servlet/HashSessionIdManager;","doStart",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(8);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ "Ljava/security/NoSuchAlgorithmException;"});
                DexLabel L3=new DexLabel();
                DexLabel L4=new DexLabel();
                DexLabel L5=new DexLabel();
                code.visitTryCatch(L3,L4,new DexLabel[]{L5},new String[]{ "Ljava/security/NoSuchAlgorithmException;"});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L6=new DexLabel();
                ddv.visitPrologue(L6);
                ddv.visitLineNumber(114,L6);
                ddv.visitLineNumber(121,L0);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(122,L7);
                ddv.visitLineNumber(139,L1);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(140,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(141,L9);
                ddv.visitLineNumber(124,L2);
                ddv.visitLineNumber(128,L3);
                ddv.visitStartLocal(0,L3,"e","Ljava/security/NoSuchAlgorithmException;",null);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(129,L10);
                ddv.visitLineNumber(131,L5);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(133,L11);
                ddv.visitStartLocal(1,L11,"e_alt","Ljava/security/NoSuchAlgorithmException;",null);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(134,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(135,L13);
                code.visitLabel(L6);
                code.visitFieldStmt(IGET_OBJECT,2,7,new Field("Lorg/mortbay/jetty/servlet/HashSessionIdManager;","_random","Ljava/util/Random;"));
                code.visitJumpStmt(IF_NEZ,2,-1,L1);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_STRING,2,"Init SecureRandom.");
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 2},new Method("Lorg/mortbay/log/Log;","debug",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L7);
                code.visitConstStmt(CONST_STRING,2,"SHA1PRNG");
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 2},new Method("Ljava/security/SecureRandom;","getInstance",new String[]{ "Ljava/lang/String;"},"Ljava/security/SecureRandom;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitFieldStmt(IPUT_OBJECT,2,7,new Field("Lorg/mortbay/jetty/servlet/HashSessionIdManager;","_random","Ljava/util/Random;"));
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,2,7,new Field("Lorg/mortbay/jetty/servlet/HashSessionIdManager;","_random","Ljava/util/Random;"));
                code.visitFieldStmt(IGET_OBJECT,3,7,new Field("Lorg/mortbay/jetty/servlet/HashSessionIdManager;","_random","Ljava/util/Random;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Ljava/util/Random;","nextLong",new String[]{ },"J"));
                code.visitStmt1R(MOVE_RESULT_WIDE,3);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Ljava/lang/System;","currentTimeMillis",new String[]{ },"J"));
                code.visitStmt1R(MOVE_RESULT_WIDE,5);
                code.visitStmt2R(XOR_LONG_2ADDR,3,5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7},new Method("Ljava/lang/Object;","hashCode",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,5);
                code.visitStmt2R(INT_TO_LONG,5,5);
                code.visitStmt2R(XOR_LONG_2ADDR,3,5);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Ljava/lang/Runtime;","getRuntime",new String[]{ },"Ljava/lang/Runtime;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Ljava/lang/Runtime;","freeMemory",new String[]{ },"J"));
                code.visitStmt1R(MOVE_RESULT_WIDE,5);
                code.visitStmt2R(XOR_LONG_2ADDR,3,5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3,4},new Method("Ljava/util/Random;","setSeed",new String[]{ "J"},"V"));
                code.visitLabel(L8);
                code.visitTypeStmt(NEW_INSTANCE,2,-1,"Lorg/mortbay/util/MultiMap;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2},new Method("Lorg/mortbay/util/MultiMap;","<init>",new String[]{ },"V"));
                code.visitFieldStmt(IPUT_OBJECT,2,7,new Field("Lorg/mortbay/jetty/servlet/HashSessionIdManager;","_sessions","Lorg/mortbay/util/MultiMap;"));
                code.visitLabel(L9);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,2);
                code.visitStmt2R(MOVE_OBJECT,0,2);
                code.visitLabel(L3);
                code.visitConstStmt(CONST_STRING,2,"IBMSecureRandom");
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 2},new Method("Ljava/security/SecureRandom;","getInstance",new String[]{ "Ljava/lang/String;"},"Ljava/security/SecureRandom;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitFieldStmt(IPUT_OBJECT,2,7,new Field("Lorg/mortbay/jetty/servlet/HashSessionIdManager;","_random","Ljava/util/Random;"));
                code.visitLabel(L10);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT_BOOLEAN,2,7,new Field("Lorg/mortbay/jetty/servlet/HashSessionIdManager;","_weakRandom","Z"));
                code.visitLabel(L4);
                code.visitJumpStmt(GOTO,-1,-1,L1);
                code.visitLabel(L5);
                code.visitStmt1R(MOVE_EXCEPTION,2);
                code.visitStmt2R(MOVE_OBJECT,1,2);
                code.visitLabel(L11);
                code.visitConstStmt(CONST_STRING,2,"Could not generate SecureRandom for session-id randomness");
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 2,0},new Method("Lorg/mortbay/log/Log;","warn",new String[]{ "Ljava/lang/String;","Ljava/lang/Throwable;"},"V"));
                code.visitLabel(L12);
                code.visitTypeStmt(NEW_INSTANCE,2,-1,"Ljava/util/Random;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2},new Method("Ljava/util/Random;","<init>",new String[]{ },"V"));
                code.visitFieldStmt(IPUT_OBJECT,2,7,new Field("Lorg/mortbay/jetty/servlet/HashSessionIdManager;","_random","Ljava/util/Random;"));
                code.visitLabel(L13);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitFieldStmt(IPUT_BOOLEAN,2,7,new Field("Lorg/mortbay/jetty/servlet/HashSessionIdManager;","_weakRandom","Z"));
                code.visitJumpStmt(GOTO,-1,-1,L1);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m004_doStop(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Lorg/mortbay/jetty/servlet/HashSessionIdManager;","doStop",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(146,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(147,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(148,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(149,L3);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/servlet/HashSessionIdManager;","_sessions","Lorg/mortbay/util/MultiMap;"));
                code.visitJumpStmt(IF_EQZ,0,-1,L2);
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/servlet/HashSessionIdManager;","_sessions","Lorg/mortbay/util/MultiMap;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/util/MultiMap;","clear",new String[]{ },"V"));
                code.visitLabel(L2);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/jetty/servlet/HashSessionIdManager;","_sessions","Lorg/mortbay/util/MultiMap;"));
                code.visitLabel(L3);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m005_getClusterId(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/servlet/HashSessionIdManager;","getClusterId",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"nodeId");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(107,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(108,L1);
                ddv.visitStartLocal(0,L1,"dot","I",null);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_16,1, Integer.valueOf(46)); // int: 0x0000002e  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,1},new Method("Ljava/lang/String;","lastIndexOf",new String[]{ "I"},"I"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitLabel(L1);
                DexLabel L2=new DexLabel();
                code.visitJumpStmt(IF_LEZ,0,-1,L2);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,1,0},new Method("Ljava/lang/String;","substring",new String[]{ "I","I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                DexLabel L3=new DexLabel();
                code.visitLabel(L3);
                code.visitStmt1R(RETURN_OBJECT,1);
                code.visitLabel(L2);
                code.visitStmt2R(MOVE_OBJECT,1,3);
                code.visitJumpStmt(GOTO,-1,-1,L3);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m006_getNodeId(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/servlet/HashSessionIdManager;","getNodeId",new String[]{ "Ljava/lang/String;","Ljavax/servlet/http/HttpServletRequest;"},"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(6);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"clusterId");
                ddv.visitParameterName(1,"request");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(89,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(90,L2);
                ddv.visitStartLocal(0,L2,"worker","Ljava/lang/String;",null);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(91,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(96,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(89,L5);
                ddv.visitEndLocal(0,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(93,L6);
                ddv.visitRestartLocal(0,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(94,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(96,L8);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_16,2, Integer.valueOf(46)); // int: 0x0000002e  float:0.000000
                code.visitLabel(L1);
                code.visitJumpStmt(IF_NEZ,5,-1,L5);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitStmt2R(MOVE_OBJECT,0,1);
                code.visitLabel(L2);
                code.visitJumpStmt(IF_EQZ,0,-1,L6);
                code.visitLabel(L3);
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,4},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "C"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,0},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L4);
                code.visitStmt1R(RETURN_OBJECT,1);
                code.visitLabel(L5);
                code.visitConstStmt(CONST_STRING,1,"org.mortbay.http.ajp.JVMRoute");
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 5,1},new Method("Ljavax/servlet/http/HttpServletRequest;","getAttribute",new String[]{ "Ljava/lang/String;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitTypeStmt(CHECK_CAST,1,-1,"Ljava/lang/String;");
                code.visitStmt2R(MOVE_OBJECT,0,1);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitLabel(L6);
                code.visitFieldStmt(IGET_OBJECT,1,3,new Field("Lorg/mortbay/jetty/servlet/HashSessionIdManager;","_workerName","Ljava/lang/String;"));
                DexLabel L9=new DexLabel();
                code.visitJumpStmt(IF_EQZ,1,-1,L9);
                code.visitLabel(L7);
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,4},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "C"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitFieldStmt(IGET_OBJECT,2,3,new Field("Lorg/mortbay/jetty/servlet/HashSessionIdManager;","_workerName","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitJumpStmt(GOTO,-1,-1,L4);
                code.visitLabel(L9);
                code.visitStmt2R(MOVE_OBJECT,1,4);
                code.visitLabel(L8);
                code.visitJumpStmt(GOTO,-1,-1,L4);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m007_getRandom(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/servlet/HashSessionIdManager;","getRandom",new String[]{ },"Ljava/util/Random;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(256,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/servlet/HashSessionIdManager;","_random","Ljava/util/Random;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m008_getWorkerName(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/servlet/HashSessionIdManager;","getWorkerName",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(66,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/servlet/HashSessionIdManager;","_workerName","Ljava/lang/String;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m009_idInUse(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/servlet/HashSessionIdManager;","idInUse",new String[]{ "Ljava/lang/String;"},"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"id");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(157,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/servlet/HashSessionIdManager;","_sessions","Lorg/mortbay/util/MultiMap;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,2},new Method("Lorg/mortbay/util/MultiMap;","containsKey",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m010_invalidateAll(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/servlet/HashSessionIdManager;","invalidateAll",new String[]{ "Ljava/lang/String;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexLabel L3=new DexLabel();
                DexLabel L4=new DexLabel();
                code.visitTryCatch(L3,L4,new DexLabel[]{L2},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"id");
                DexLabel L5=new DexLabel();
                ddv.visitPrologue(L5);
                ddv.visitLineNumber(190,L5);
                ddv.visitLineNumber(194,L0);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(196,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(197,L7);
                ddv.visitStartLocal(0,L7,"session","Lorg/mortbay/jetty/servlet/AbstractSessionManager$Session;",null);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(198,L8);
                ddv.visitLineNumber(202,L2);
                ddv.visitEndLocal(0,L2);
                ddv.visitLineNumber(200,L3);
                ddv.visitRestartLocal(0,L3);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(202,L9);
                ddv.visitEndLocal(0,L9);
                ddv.visitLineNumber(203,L4);
                code.visitLabel(L5);
                code.visitStmt1R(MONITOR_ENTER,3);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,1,3,new Field("Lorg/mortbay/jetty/servlet/HashSessionIdManager;","_sessions","Lorg/mortbay/util/MultiMap;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,4},new Method("Lorg/mortbay/util/MultiMap;","containsKey",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitJumpStmt(IF_EQZ,1,-1,L9);
                code.visitLabel(L6);
                code.visitFieldStmt(IGET_OBJECT,1,3,new Field("Lorg/mortbay/jetty/servlet/HashSessionIdManager;","_sessions","Lorg/mortbay/util/MultiMap;"));
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,4,2},new Method("Lorg/mortbay/util/MultiMap;","getValue",new String[]{ "Ljava/lang/Object;","I"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitTypeStmt(CHECK_CAST,0,-1,"Lorg/mortbay/jetty/servlet/AbstractSessionManager$Session;");
                code.visitLabel(L7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/jetty/servlet/AbstractSessionManager$Session;","isValid",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitJumpStmt(IF_EQZ,1,-1,L3);
                code.visitLabel(L8);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/jetty/servlet/AbstractSessionManager$Session;","invalidate",new String[]{ },"V"));
                code.visitJumpStmt(GOTO,-1,-1,L0);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,1);
                code.visitStmt1R(MONITOR_EXIT,3);
                code.visitLabel(L1);
                code.visitStmt1R(THROW,1);
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,1,3,new Field("Lorg/mortbay/jetty/servlet/HashSessionIdManager;","_sessions","Lorg/mortbay/util/MultiMap;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,4,0},new Method("Lorg/mortbay/util/MultiMap;","removeValue",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;"},"Z"));
                code.visitJumpStmt(GOTO,-1,-1,L0);
                code.visitLabel(L9);
                code.visitStmt1R(MONITOR_EXIT,3);
                code.visitLabel(L4);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m011_newSessionId(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/servlet/HashSessionIdManager;","newSessionId",new String[]{ "Ljavax/servlet/http/HttpServletRequest;","J"},"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(15);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"request");
                ddv.visitParameterName(1,"created");
                DexLabel L3=new DexLabel();
                ddv.visitPrologue(L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(216,L4);
                ddv.visitLineNumber(219,L0);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(221,L5);
                ddv.visitStartLocal(5,L5,"requested_id","Ljava/lang/String;",null);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(223,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(224,L7);
                ddv.visitStartLocal(0,L7,"cluster_id","Ljava/lang/String;",null);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(225,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(249,L9);
                ddv.visitEndLocal(0,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(229,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(230,L11);
                ddv.visitStartLocal(2,L11,"new_id","Ljava/lang/String;",null);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(231,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(234,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(235,L14);
                ddv.visitStartLocal(1,L14,"id","Ljava/lang/String;",null);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(237,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(240,L16);
                ddv.visitStartLocal(3,L16,"r","J",null);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(241,L17);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(242,L18);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(243,L19);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(244,L20);
                DexLabel L21=new DexLabel();
                ddv.visitLineNumber(245,L21);
                DexLabel L22=new DexLabel();
                ddv.visitLineNumber(246,L22);
                DexLabel L23=new DexLabel();
                ddv.visitLineNumber(237,L23);
                ddv.visitEndLocal(3,L23);
                DexLabel L24=new DexLabel();
                ddv.visitLineNumber(248,L24);
                DexLabel L25=new DexLabel();
                ddv.visitLineNumber(249,L25);
                ddv.visitLineNumber(250,L2);
                ddv.visitEndLocal(5,L2);
                ddv.visitEndLocal(2,L2);
                ddv.visitEndLocal(1,L2);
                code.visitLabel(L3);
                code.visitConstStmt(CONST_STRING,6,"org.mortbay.jetty.newSessionId");
                code.visitLabel(L4);
                code.visitStmt1R(MONITOR_ENTER,11);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 12},new Method("Ljavax/servlet/http/HttpServletRequest;","getRequestedSessionId",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitLabel(L5);
                code.visitJumpStmt(IF_EQZ,5,-1,L10);
                code.visitLabel(L6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 11,5},new Method("Lorg/mortbay/jetty/servlet/HashSessionIdManager;","getClusterId",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 11,0},new Method("Lorg/mortbay/jetty/servlet/HashSessionIdManager;","idInUse",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,6);
                code.visitJumpStmt(IF_EQZ,6,-1,L10);
                code.visitLabel(L8);
                code.visitStmt1R(MONITOR_EXIT,11);
                code.visitStmt2R(MOVE_OBJECT,6,0);
                code.visitLabel(L9);
                code.visitStmt1R(RETURN_OBJECT,6);
                code.visitLabel(L10);
                code.visitConstStmt(CONST_STRING,6,"org.mortbay.jetty.newSessionId");
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 12,6},new Method("Ljavax/servlet/http/HttpServletRequest;","getAttribute",new String[]{ "Ljava/lang/String;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitTypeStmt(CHECK_CAST,2,-1,"Ljava/lang/String;");
                code.visitLabel(L11);
                code.visitJumpStmt(IF_EQZ,2,-1,L13);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 11,2},new Method("Lorg/mortbay/jetty/servlet/HashSessionIdManager;","idInUse",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,6);
                code.visitJumpStmt(IF_EQZ,6,-1,L13);
                code.visitLabel(L12);
                code.visitStmt1R(MONITOR_EXIT,11);
                code.visitStmt2R(MOVE_OBJECT,6,2);
                code.visitJumpStmt(GOTO,-1,-1,L9);
                code.visitLabel(L13);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L14);
                code.visitJumpStmt(IF_EQZ,1,-1,L15);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/lang/String;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,6);
                code.visitJumpStmt(IF_EQZ,6,-1,L15);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 11,1},new Method("Lorg/mortbay/jetty/servlet/HashSessionIdManager;","idInUse",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,6);
                code.visitJumpStmt(IF_EQZ,6,-1,L24);
                code.visitLabel(L15);
                code.visitFieldStmt(IGET_BOOLEAN,6,11,new Field("Lorg/mortbay/jetty/servlet/HashSessionIdManager;","_weakRandom","Z"));
                code.visitJumpStmt(IF_EQZ,6,-1,L23);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 11},new Method("Ljava/lang/Object;","hashCode",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,6);
                code.visitStmt2R(INT_TO_LONG,6,6);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Ljava/lang/Runtime;","getRuntime",new String[]{ },"Ljava/lang/Runtime;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8},new Method("Ljava/lang/Runtime;","freeMemory",new String[]{ },"J"));
                code.visitStmt1R(MOVE_RESULT_WIDE,8);
                code.visitStmt2R(XOR_LONG_2ADDR,6,8);
                code.visitFieldStmt(IGET_OBJECT,8,11,new Field("Lorg/mortbay/jetty/servlet/HashSessionIdManager;","_random","Ljava/util/Random;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8},new Method("Ljava/util/Random;","nextInt",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,8);
                code.visitStmt2R(INT_TO_LONG,8,8);
                code.visitStmt2R(XOR_LONG_2ADDR,6,8);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 12},new Method("Ljava/lang/Object;","hashCode",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,8);
                code.visitStmt2R(INT_TO_LONG,8,8);
                code.visitConstStmt(CONST_16,10, Integer.valueOf(32)); // int: 0x00000020  float:0.000000
                code.visitStmt2R(SHL_LONG_2ADDR,8,10);
                code.visitStmt2R(XOR_LONG_2ADDR,6,8);
                code.visitStmt2R(MOVE_WIDE,3,6);
                code.visitLabel(L16);
                code.visitStmt2R(XOR_LONG_2ADDR,3,13);
                code.visitLabel(L17);
                code.visitJumpStmt(IF_EQZ,12,-1,L19);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 12},new Method("Ljavax/servlet/http/HttpServletRequest;","getRemoteAddr",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitJumpStmt(IF_EQZ,6,-1,L19);
                code.visitLabel(L18);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 12},new Method("Ljavax/servlet/http/HttpServletRequest;","getRemoteAddr",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Ljava/lang/String;","hashCode",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,6);
                code.visitStmt2R(INT_TO_LONG,6,6);
                code.visitStmt2R(XOR_LONG_2ADDR,3,6);
                code.visitLabel(L19);
                code.visitConstStmt(CONST_WIDE_16,6,Long.valueOf(0L)); // long: 0x0000000000000000  double:0.000000
                code.visitStmt3R(CMP_LONG,6,3,6);
                code.visitJumpStmt(IF_GEZ,6,-1,L21);
                code.visitLabel(L20);
                code.visitStmt2R(NEG_LONG,3,3);
                code.visitLabel(L21);
                code.visitConstStmt(CONST_16,6, Integer.valueOf(36)); // int: 0x00000024  float:0.000000
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 3,4,6},new Method("Ljava/lang/Long;","toString",new String[]{ "J","I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L22);
                code.visitJumpStmt(GOTO,-1,-1,L14);
                code.visitLabel(L23);
                code.visitFieldStmt(IGET_OBJECT,6,11,new Field("Lorg/mortbay/jetty/servlet/HashSessionIdManager;","_random","Ljava/util/Random;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Ljava/util/Random;","nextLong",new String[]{ },"J"));
                code.visitStmt1R(MOVE_RESULT_WIDE,6);
                code.visitStmt2R(MOVE_WIDE,3,6);
                code.visitJumpStmt(GOTO,-1,-1,L16);
                code.visitLabel(L24);
                code.visitConstStmt(CONST_STRING,6,"org.mortbay.jetty.newSessionId");
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 12,6,1},new Method("Ljavax/servlet/http/HttpServletRequest;","setAttribute",new String[]{ "Ljava/lang/String;","Ljava/lang/Object;"},"V"));
                code.visitLabel(L25);
                code.visitStmt1R(MONITOR_EXIT,11);
                code.visitStmt2R(MOVE_OBJECT,6,1);
                code.visitJumpStmt(GOTO,-1,-1,L9);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,6);
                code.visitStmt1R(MONITOR_EXIT,11);
                code.visitLabel(L1);
                code.visitStmt1R(THROW,6);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m012_removeSession(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/servlet/HashSessionIdManager;","removeSession",new String[]{ "Ljavax/servlet/http/HttpSession;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"session");
                DexLabel L3=new DexLabel();
                ddv.visitPrologue(L3);
                ddv.visitLineNumber(178,L3);
                ddv.visitLineNumber(180,L0);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(181,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(182,L5);
                ddv.visitLineNumber(181,L2);
                code.visitLabel(L3);
                code.visitStmt1R(MONITOR_ENTER,2);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/jetty/servlet/HashSessionIdManager;","_sessions","Lorg/mortbay/util/MultiMap;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 3},new Method("Ljavax/servlet/http/HttpSession;","getId",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,1},new Method("Lorg/mortbay/jetty/servlet/HashSessionIdManager;","getClusterId",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1,3},new Method("Lorg/mortbay/util/MultiMap;","removeValue",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;"},"Z"));
                code.visitLabel(L4);
                code.visitStmt1R(MONITOR_EXIT,2);
                code.visitLabel(L5);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,0);
                code.visitStmt1R(MONITOR_EXIT,2);
                code.visitLabel(L1);
                code.visitStmt1R(THROW,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m013_setRandom(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/servlet/HashSessionIdManager;","setRandom",new String[]{ "Ljava/util/Random;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"random");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(262,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(263,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(264,L2);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_OBJECT,2,1,new Field("Lorg/mortbay/jetty/servlet/HashSessionIdManager;","_random","Ljava/util/Random;"));
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT_BOOLEAN,0,1,new Field("Lorg/mortbay/jetty/servlet/HashSessionIdManager;","_weakRandom","Z"));
                code.visitLabel(L2);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m014_setWorkerName(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/servlet/HashSessionIdManager;","setWorkerName",new String[]{ "Ljava/lang/String;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"workerName");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(78,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(79,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_OBJECT,1,0,new Field("Lorg/mortbay/jetty/servlet/HashSessionIdManager;","_workerName","Ljava/lang/String;"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
