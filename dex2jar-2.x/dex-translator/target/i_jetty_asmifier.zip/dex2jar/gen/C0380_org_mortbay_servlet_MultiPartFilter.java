package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0380_org_mortbay_servlet_MultiPartFilter {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(ACC_PUBLIC,"Lorg/mortbay/servlet/MultiPartFilter;","Ljava/lang/Object;",new String[]{ "Ljavax/servlet/Filter;"});
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("MultiPartFilter.java");
        if(cv!=null){
            DexAnnotationVisitor av00 = cv.visitAnnotation("Ldalvik/annotation/MemberClasses;", Visibility.SYSTEM);
            if(av00 != null) {
                {
                    DexAnnotationVisitor av01 = av00.visitArray("value");
                    if(av01 != null) {
                        av01.visit(null, new DexType("Lorg/mortbay/servlet/MultiPartFilter$Wrapper;"));
                        av01.visitEnd();
                    }
                }
                av00.visitEnd();
            }
        }
        f000_FILES(cv);
        f001__context(cv);
        f002__deleteFiles(cv);
        f003__fileOutputBuffer(cv);
        f004_tempdir(cv);
        m000__init_(cv);
        m001_deleteFiles(cv);
        m002_value(cv);
        m003_destroy(cv);
        m004_doFilter(cv);
        m005_init(cv);
    }
    public static void f000_FILES(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/servlet/MultiPartFilter;","FILES","Ljava/lang/String;"), "org.mortbay.servlet.MultiPartFilter.files");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f001__context(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/servlet/MultiPartFilter;","_context","Ljavax/servlet/ServletContext;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f002__deleteFiles(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/servlet/MultiPartFilter;","_deleteFiles","Z"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f003__fileOutputBuffer(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/servlet/MultiPartFilter;","_fileOutputBuffer","I"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f004_tempdir(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/servlet/MultiPartFilter;","tempdir","Ljava/io/File;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void m000__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/servlet/MultiPartFilter;","<init>",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(62,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(68,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(347,L2);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1},new Method("Ljava/lang/Object;","<init>",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT,0,1,new Field("Lorg/mortbay/servlet/MultiPartFilter;","_fileOutputBuffer","I"));
                code.visitLabel(L2);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001_deleteFiles(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PRIVATE, new Method("Lorg/mortbay/servlet/MultiPartFilter;","deleteFiles",new String[]{ "Ljavax/servlet/ServletRequest;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(9);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ "Ljava/lang/Exception;"});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"request");
                DexLabel L3=new DexLabel();
                ddv.visitPrologue(L3);
                ddv.visitLineNumber(301,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(302,L4);
                ddv.visitStartLocal(2,L4,"files","Ljava/util/ArrayList;",null);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(304,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(305,L6);
                ddv.visitStartLocal(3,L6,"iter","Ljava/util/Iterator;",null);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(307,L7);
                ddv.visitLineNumber(310,L0);
                ddv.visitStartLocal(1,L0,"file","Ljava/io/File;",null);
                ddv.visitLineNumber(312,L2);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(314,L8);
                ddv.visitStartLocal(0,L8,"e","Ljava/lang/Exception;",null);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(318,L9);
                ddv.visitEndLocal(3,L9);
                ddv.visitEndLocal(1,L9);
                ddv.visitEndLocal(0,L9);
                code.visitLabel(L3);
                code.visitConstStmt(CONST_STRING,4,"org.mortbay.servlet.MultiPartFilter.files");
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 8,4},new Method("Ljavax/servlet/ServletRequest;","getAttribute",new String[]{ "Ljava/lang/String;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitTypeStmt(CHECK_CAST,2,-1,"Ljava/util/ArrayList;");
                code.visitLabel(L4);
                code.visitJumpStmt(IF_EQZ,2,-1,L9);
                code.visitLabel(L5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Ljava/util/ArrayList;","iterator",new String[]{ },"Ljava/util/Iterator;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitLabel(L6);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 3},new Method("Ljava/util/Iterator;","hasNext",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,4);
                code.visitJumpStmt(IF_EQZ,4,-1,L9);
                code.visitLabel(L7);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 3},new Method("Ljava/util/Iterator;","next",new String[]{ },"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitTypeStmt(CHECK_CAST,1,-1,"Ljava/io/File;");
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/io/File;","delete",new String[]{ },"Z"));
                code.visitLabel(L1);
                code.visitJumpStmt(GOTO,-1,-1,L6);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,0);
                code.visitLabel(L8);
                code.visitFieldStmt(IGET_OBJECT,4,7,new Field("Lorg/mortbay/servlet/MultiPartFilter;","_context","Ljavax/servlet/ServletContext;"));
                code.visitTypeStmt(NEW_INSTANCE,5,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 5},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,6,"failed to delete ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,6},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 4,5,0},new Method("Ljavax/servlet/ServletContext;","log",new String[]{ "Ljava/lang/String;","Ljava/lang/Throwable;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L6);
                code.visitLabel(L9);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m002_value(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PRIVATE, new Method("Lorg/mortbay/servlet/MultiPartFilter;","value",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(7);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"nameEqualsValue");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(322,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(323,L2);
                ddv.visitStartLocal(1,L2,"value","Ljava/lang/String;",null);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(324,L3);
                ddv.visitStartLocal(0,L3,"i","I",null);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(325,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(326,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(328,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(336,L7);
                ddv.visitRestartLocal(1,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(332,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(333,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(334,L10);
                DexLabel L11=new DexLabel();
                ddv.visitRestartLocal(1,L11);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,4, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitConstStmt(CONST_4,3, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L1);
                code.visitConstStmt(CONST_16,2, Integer.valueOf(61)); // int: 0x0000003d  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,2},new Method("Ljava/lang/String;","indexOf",new String[]{ "I"},"I"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitStmt2R1N(ADD_INT_LIT8,2,2,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,2},new Method("Ljava/lang/String;","substring",new String[]{ "I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Ljava/lang/String;","trim",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L2);
                code.visitConstStmt(CONST_16,2, Integer.valueOf(59)); // int: 0x0000003b  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2},new Method("Ljava/lang/String;","indexOf",new String[]{ "I"},"I"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitLabel(L3);
                code.visitJumpStmt(IF_LEZ,0,-1,L5);
                code.visitLabel(L4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,3,0},new Method("Ljava/lang/String;","substring",new String[]{ "I","I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L5);
                code.visitConstStmt(CONST_STRING,2,"\"");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2},new Method("Ljava/lang/String;","startsWith",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitJumpStmt(IF_EQZ,2,-1,L8);
                code.visitLabel(L6);
                code.visitConstStmt(CONST_16,2, Integer.valueOf(34)); // int: 0x00000022  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2,4},new Method("Ljava/lang/String;","indexOf",new String[]{ "I","I"},"I"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,4,2},new Method("Ljava/lang/String;","substring",new String[]{ "I","I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L7);
                code.visitStmt1R(RETURN_OBJECT,1);
                code.visitLabel(L8);
                code.visitConstStmt(CONST_16,2, Integer.valueOf(32)); // int: 0x00000020  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2},new Method("Ljava/lang/String;","indexOf",new String[]{ "I"},"I"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitLabel(L9);
                code.visitJumpStmt(IF_LEZ,0,-1,L7);
                code.visitLabel(L10);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,3,0},new Method("Ljava/lang/String;","substring",new String[]{ "I","I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L11);
                code.visitJumpStmt(GOTO,-1,-1,L7);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m003_destroy(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/servlet/MultiPartFilter;","destroy",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(1);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(345,L0);
                code.visitLabel(L0);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m004_doFilter(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/servlet/MultiPartFilter;","doFilter",new String[]{ "Ljavax/servlet/ServletRequest;","Ljavax/servlet/ServletResponse;","Ljavax/servlet/FilterChain;"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visit(null, new DexType("Ljavax/servlet/ServletException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(38);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L1},new String[]{ null});
                DexLabel L2=new DexLabel();
                DexLabel L3=new DexLabel();
                code.visitTryCatch(L2,L3,new DexLabel[]{L1},new String[]{ null});
                DexLabel L4=new DexLabel();
                DexLabel L5=new DexLabel();
                DexLabel L6=new DexLabel();
                code.visitTryCatch(L4,L5,new DexLabel[]{L6},new String[]{ null});
                DexLabel L7=new DexLabel();
                DexLabel L8=new DexLabel();
                code.visitTryCatch(L5,L7,new DexLabel[]{L8},new String[]{ null});
                DexLabel L9=new DexLabel();
                code.visitTryCatch(L7,L9,new DexLabel[]{L6},new String[]{ null});
                DexLabel L10=new DexLabel();
                DexLabel L11=new DexLabel();
                code.visitTryCatch(L10,L11,new DexLabel[]{L1},new String[]{ null});
                DexLabel L12=new DexLabel();
                DexLabel L13=new DexLabel();
                code.visitTryCatch(L12,L13,new DexLabel[]{L6},new String[]{ null});
                DexLabel L14=new DexLabel();
                DexLabel L15=new DexLabel();
                code.visitTryCatch(L14,L15,new DexLabel[]{L1},new String[]{ null});
                DexLabel L16=new DexLabel();
                DexLabel L17=new DexLabel();
                code.visitTryCatch(L16,L17,new DexLabel[]{L6},new String[]{ null});
                DexLabel L18=new DexLabel();
                DexLabel L19=new DexLabel();
                code.visitTryCatch(L18,L19,new DexLabel[]{L1},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"request");
                ddv.visitParameterName(1,"response");
                ddv.visitParameterName(2,"chain");
                DexLabel L20=new DexLabel();
                ddv.visitPrologue(L20);
                ddv.visitLineNumber(92,L20);
                DexLabel L21=new DexLabel();
                ddv.visitLineNumber(93,L21);
                ddv.visitStartLocal(25,L21,"srequest","Ljavax/servlet/http/HttpServletRequest;",null);
                DexLabel L22=new DexLabel();
                ddv.visitLineNumber(95,L22);
                DexLabel L23=new DexLabel();
                ddv.visitLineNumber(297,L23);
                DexLabel L24=new DexLabel();
                ddv.visitLineNumber(99,L24);
                DexLabel L25=new DexLabel();
                ddv.visitLineNumber(100,L25);
                ddv.visitStartLocal(16,L25,"in","Ljava/io/BufferedInputStream;",null);
                DexLabel L26=new DexLabel();
                ddv.visitLineNumber(104,L26);
                ddv.visitStartLocal(10,L26,"content_type","Ljava/lang/String;",null);
                DexLabel L27=new DexLabel();
                ddv.visitLineNumber(105,L27);
                ddv.visitStartLocal(5,L27,"boundary","Ljava/lang/String;",null);
                DexLabel L28=new DexLabel();
                ddv.visitLineNumber(107,L28);
                ddv.visitStartLocal(6,L28,"byteBoundary","[B",null);
                ddv.visitLineNumber(120,L0);
                ddv.visitStartLocal(24,L0,"params","Lorg/mortbay/util/MultiMap;",null);
                DexLabel L29=new DexLabel();
                ddv.visitLineNumber(121,L29);
                ddv.visitStartLocal(7,L29,"bytes","[B",null);
                DexLabel L30=new DexLabel();
                ddv.visitLineNumber(122,L30);
                ddv.visitStartLocal(20,L30,"line","Ljava/lang/String;",null);
                DexLabel L31=new DexLabel();
                ddv.visitLineNumber(124,L31);
                ddv.visitLineNumber(295,L1);
                ddv.visitEndLocal(7,L1);
                ddv.visitEndLocal(20,L1);
                ddv.visitLineNumber(121,L2);
                ddv.visitRestartLocal(7,L2);
                DexLabel L32=new DexLabel();
                ddv.visitLineNumber(128,L32);
                ddv.visitRestartLocal(20,L32);
                DexLabel L33=new DexLabel();
                ddv.visitLineNumber(129,L33);
                ddv.visitStartLocal(18,L33,"lastPart","Z",null);
                DexLabel L34=new DexLabel();
                ddv.visitLineNumber(130,L34);
                ddv.visitStartLocal(9,L34,"content_disposition","Ljava/lang/String;",null);
                DexLabel L35=new DexLabel();
                ddv.visitLineNumber(134,L35);
                DexLabel L36=new DexLabel();
                ddv.visitLineNumber(136,L36);
                ddv.visitRestartLocal(7,L36);
                DexLabel L37=new DexLabel();
                ddv.visitLineNumber(151,L37);
                DexLabel L38=new DexLabel();
                ddv.visitLineNumber(152,L38);
                ddv.visitStartLocal(15,L38,"form_data","Z",null);
                DexLabel L39=new DexLabel();
                ddv.visitLineNumber(154,L39);
                DexLabel L40=new DexLabel();
                ddv.visitLineNumber(138,L40);
                ddv.visitEndLocal(15,L40);
                DexLabel L41=new DexLabel();
                ddv.visitEndLocal(20,L41);
                DexLabel L42=new DexLabel();
                ddv.visitLineNumber(141,L42);
                ddv.visitRestartLocal(20,L42);
                DexLabel L43=new DexLabel();
                ddv.visitLineNumber(142,L43);
                ddv.visitStartLocal(8,L43,"c","I",null);
                DexLabel L44=new DexLabel();
                ddv.visitLineNumber(144,L44);
                DexLabel L45=new DexLabel();
                ddv.visitLineNumber(145,L45);
                ddv.visitStartLocal(17,L45,"key","Ljava/lang/String;",null);
                DexLabel L46=new DexLabel();
                ddv.visitLineNumber(146,L46);
                ddv.visitStartLocal(30,L46,"value","Ljava/lang/String;",null);
                DexLabel L47=new DexLabel();
                ddv.visitLineNumber(147,L47);
                DexLabel L48=new DexLabel();
                ddv.visitLineNumber(157,L48);
                ddv.visitEndLocal(8,L48);
                ddv.visitEndLocal(17,L48);
                ddv.visitEndLocal(30,L48);
                ddv.visitRestartLocal(15,L48);
                DexLabel L49=new DexLabel();
                ddv.visitLineNumber(158,L49);
                ddv.visitStartLocal(29,L49,"tok","Ljava/util/StringTokenizer;",null);
                DexLabel L50=new DexLabel();
                ddv.visitLineNumber(159,L50);
                ddv.visitStartLocal(21,L50,"name","Ljava/lang/String;",null);
                DexLabel L51=new DexLabel();
                ddv.visitLineNumber(160,L51);
                ddv.visitStartLocal(13,L51,"filename","Ljava/lang/String;",null);
                DexLabel L52=new DexLabel();
                ddv.visitLineNumber(162,L52);
                DexLabel L53=new DexLabel();
                ddv.visitLineNumber(163,L53);
                ddv.visitStartLocal(27,L53,"t","Ljava/lang/String;",null);
                DexLabel L54=new DexLabel();
                ddv.visitLineNumber(164,L54);
                ddv.visitStartLocal(28,L54,"tl","Ljava/lang/String;",null);
                DexLabel L55=new DexLabel();
                ddv.visitLineNumber(165,L55);
                DexLabel L56=new DexLabel();
                ddv.visitLineNumber(166,L56);
                DexLabel L57=new DexLabel();
                ddv.visitLineNumber(167,L57);
                DexLabel L58=new DexLabel();
                ddv.visitLineNumber(168,L58);
                DexLabel L59=new DexLabel();
                ddv.visitLineNumber(169,L59);
                DexLabel L60=new DexLabel();
                ddv.visitLineNumber(173,L60);
                ddv.visitEndLocal(27,L60);
                ddv.visitEndLocal(28,L60);
                DexLabel L61=new DexLabel();
                ddv.visitLineNumber(177,L61);
                DexLabel L62=new DexLabel();
                ddv.visitLineNumber(182,L62);
                DexLabel L63=new DexLabel();
                ddv.visitLineNumber(183,L63);
                ddv.visitStartLocal(22,L63,"out","Ljava/io/OutputStream;",null);
                DexLabel L64=new DexLabel();
                ddv.visitLineNumber(186,L64);
                ddv.visitStartLocal(12,L64,"file","Ljava/io/File;",null);
                DexLabel L65=new DexLabel();
                ddv.visitLineNumber(188,L65);
                DexLabel L66=new DexLabel();
                ddv.visitLineNumber(189,L66);
                ddv.visitLineNumber(190,L5);
                ddv.visitStartLocal(23,L5,"out","Ljava/io/OutputStream;",null);
                DexLabel L67=new DexLabel();
                ddv.visitEndLocal(22,L67);
                DexLabel L68=new DexLabel();
                ddv.visitLineNumber(191,L68);
                ddv.visitLineNumber(192,L7);
                ddv.visitEndLocal(23,L7);
                ddv.visitRestartLocal(22,L7);
                DexLabel L69=new DexLabel();
                ddv.visitLineNumber(193,L69);
                DexLabel L70=new DexLabel();
                ddv.visitLineNumber(195,L70);
                DexLabel L71=new DexLabel();
                ddv.visitLineNumber(197,L71);
                DexLabel L72=new DexLabel();
                ddv.visitLineNumber(198,L72);
                DexLabel L73=new DexLabel();
                ddv.visitLineNumber(199,L73);
                ddv.visitStartLocal(14,L73,"files","Ljava/util/ArrayList;",null);
                DexLabel L74=new DexLabel();
                ddv.visitLineNumber(201,L74);
                DexLabel L75=new DexLabel();
                ddv.visitEndLocal(14,L75);
                DexLabel L76=new DexLabel();
                ddv.visitLineNumber(202,L76);
                ddv.visitRestartLocal(14,L76);
                DexLabel L77=new DexLabel();
                ddv.visitLineNumber(204,L77);
                DexLabel L78=new DexLabel();
                ddv.visitLineNumber(211,L78);
                ddv.visitEndLocal(14,L78);
                DexLabel L79=new DexLabel();
                ddv.visitLineNumber(213,L79);
                ddv.visitStartLocal(26,L79,"state","I",null);
                DexLabel L80=new DexLabel();
                ddv.visitLineNumber(214,L80);
                ddv.visitStartLocal(11,L80,"cr","Z",null);
                DexLabel L81=new DexLabel();
                ddv.visitLineNumber(219,L81);
                ddv.visitStartLocal(19,L81,"lf","Z",null);
                DexLabel L82=new DexLabel();
                ddv.visitLineNumber(220,L82);
                ddv.visitStartLocal(4,L82,"b","I",null);
                DexLabel L83=new DexLabel();
                ddv.visitRestartLocal(8,L83);
                DexLabel L84=new DexLabel();
                ddv.visitLineNumber(222,L84);
                DexLabel L85=new DexLabel();
                ddv.visitLineNumber(224,L85);
                DexLabel L86=new DexLabel();
                ddv.visitLineNumber(226,L86);
                DexLabel L87=new DexLabel();
                ddv.visitLineNumber(227,L87);
                DexLabel L88=new DexLabel();
                ddv.visitLineNumber(248,L88);
                DexLabel L89=new DexLabel();
                ddv.visitLineNumber(250,L89);
                DexLabel L90=new DexLabel();
                ddv.visitLineNumber(251,L90);
                DexLabel L91=new DexLabel();
                ddv.visitLineNumber(252,L91);
                DexLabel L92=new DexLabel();
                ddv.visitLineNumber(253,L92);
                DexLabel L93=new DexLabel();
                ddv.visitLineNumber(254,L93);
                DexLabel L94=new DexLabel();
                ddv.visitLineNumber(255,L94);
                DexLabel L95=new DexLabel();
                ddv.visitLineNumber(256,L95);
                DexLabel L96=new DexLabel();
                ddv.visitLineNumber(259,L96);
                DexLabel L97=new DexLabel();
                ddv.visitLineNumber(261,L97);
                DexLabel L98=new DexLabel();
                ddv.visitLineNumber(262,L98);
                DexLabel L99=new DexLabel();
                ddv.visitLineNumber(263,L99);
                DexLabel L100=new DexLabel();
                ddv.visitLineNumber(264,L100);
                ddv.visitLineNumber(280,L10);
                DexLabel L101=new DexLabel();
                ddv.visitLineNumber(283,L101);
                DexLabel L102=new DexLabel();
                ddv.visitLineNumber(285,L102);
                DexLabel L103=new DexLabel();
                ddv.visitEndLocal(22,L103);
                DexLabel L104=new DexLabel();
                ddv.visitLineNumber(286,L104);
                ddv.visitRestartLocal(7,L104);
                ddv.visitLineNumber(209,L12);
                ddv.visitEndLocal(11,L12);
                ddv.visitEndLocal(19,L12);
                ddv.visitEndLocal(4,L12);
                ddv.visitEndLocal(8,L12);
                ddv.visitEndLocal(26,L12);
                ddv.visitRestartLocal(22,L12);
                DexLabel L105=new DexLabel();
                ddv.visitRestartLocal(23,L105);
                DexLabel L106=new DexLabel();
                ddv.visitLineNumber(220,L106);
                ddv.visitEndLocal(23,L106);
                ddv.visitRestartLocal(4,L106);
                ddv.visitRestartLocal(11,L106);
                ddv.visitRestartLocal(19,L106);
                ddv.visitRestartLocal(26,L106);
                DexLabel L107=new DexLabel();
                ddv.visitLineNumber(231,L107);
                ddv.visitRestartLocal(8,L107);
                DexLabel L108=new DexLabel();
                ddv.visitLineNumber(232,L108);
                DexLabel L109=new DexLabel();
                ddv.visitLineNumber(236,L109);
                DexLabel L110=new DexLabel();
                ddv.visitLineNumber(237,L110);
                DexLabel L111=new DexLabel();
                ddv.visitLineNumber(238,L111);
                DexLabel L112=new DexLabel();
                ddv.visitLineNumber(239,L112);
                DexLabel L113=new DexLabel();
                ddv.visitLineNumber(240,L113);
                DexLabel L114=new DexLabel();
                ddv.visitLineNumber(241,L114);
                DexLabel L115=new DexLabel();
                ddv.visitLineNumber(242,L115);
                DexLabel L116=new DexLabel();
                ddv.visitLineNumber(243,L116);
                DexLabel L117=new DexLabel();
                ddv.visitLineNumber(244,L117);
                ddv.visitLineNumber(280,L6);
                ddv.visitEndLocal(4,L6);
                ddv.visitEndLocal(11,L6);
                ddv.visitEndLocal(19,L6);
                ddv.visitEndLocal(26,L6);
                ddv.visitEndLocal(8,L6);
                ddv.visitLineNumber(268,L15);
                ddv.visitRestartLocal(4,L15);
                ddv.visitRestartLocal(8,L15);
                ddv.visitRestartLocal(11,L15);
                ddv.visitRestartLocal(19,L15);
                ddv.visitRestartLocal(26,L15);
                DexLabel L118=new DexLabel();
                ddv.visitLineNumber(269,L118);
                DexLabel L119=new DexLabel();
                ddv.visitLineNumber(270,L119);
                DexLabel L120=new DexLabel();
                ddv.visitLineNumber(271,L120);
                ddv.visitLineNumber(272,L17);
                DexLabel L121=new DexLabel();
                ddv.visitLineNumber(273,L121);
                ddv.visitRestartLocal(11,L121);
                DexLabel L122=new DexLabel();
                ddv.visitLineNumber(274,L122);
                ddv.visitRestartLocal(19,L122);
                DexLabel L123=new DexLabel();
                ddv.visitLineNumber(275,L123);
                DexLabel L124=new DexLabel();
                ddv.visitLineNumber(272,L124);
                DexLabel L125=new DexLabel();
                ddv.visitLineNumber(273,L125);
                ddv.visitLineNumber(291,L18);
                ddv.visitEndLocal(15,L18);
                ddv.visitEndLocal(29,L18);
                ddv.visitEndLocal(21,L18);
                ddv.visitEndLocal(13,L18);
                ddv.visitEndLocal(12,L18);
                ddv.visitEndLocal(22,L18);
                ddv.visitEndLocal(4,L18);
                ddv.visitEndLocal(8,L18);
                ddv.visitEndLocal(26,L18);
                ddv.visitEndLocal(11,L18);
                ddv.visitEndLocal(19,L18);
                ddv.visitLineNumber(295,L19);
                ddv.visitLineNumber(280,L8);
                ddv.visitRestartLocal(12,L8);
                ddv.visitRestartLocal(13,L8);
                ddv.visitRestartLocal(15,L8);
                ddv.visitRestartLocal(21,L8);
                ddv.visitRestartLocal(23,L8);
                ddv.visitRestartLocal(29,L8);
                DexLabel L126=new DexLabel();
                ddv.visitRestartLocal(22,L126);
                DexLabel L127=new DexLabel();
                ddv.visitEndLocal(22,L127);
                DexLabel L128=new DexLabel();
                ddv.visitRestartLocal(22,L128);
                code.visitLabel(L20);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,35);
                code.visitTypeStmt(CHECK_CAST,0,-1,"Ljavax/servlet/http/HttpServletRequest;");
                code.visitStmt2R(MOVE_OBJECT_FROM16,25,0);
                code.visitLabel(L21);
                code.visitMethodStmt(INVOKE_INTERFACE_RANGE,new int[]{ 25},new Method("Ljavax/servlet/http/HttpServletRequest;","getContentType",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,31);
                code.visitJumpStmt(IF_EQZ,31,-1,L22);
                code.visitMethodStmt(INVOKE_INTERFACE_RANGE,new int[]{ 25},new Method("Ljavax/servlet/http/HttpServletRequest;","getContentType",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,31);
                code.visitConstStmt(CONST_STRING,32,"multipart/form-data");
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 31,32},new Method("Ljava/lang/String;","startsWith",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,31);
                code.visitJumpStmt(IF_NEZ,31,-1,L24);
                code.visitLabel(L22);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,37);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,35);
                code.visitStmt2R(MOVE_OBJECT_FROM16,2,36);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,1,2},new Method("Ljavax/servlet/FilterChain;","doFilter",new String[]{ "Ljavax/servlet/ServletRequest;","Ljavax/servlet/ServletResponse;"},"V"));
                code.visitLabel(L23);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L24);
                code.visitTypeStmt(NEW_INSTANCE,16,-1,"Ljava/io/BufferedInputStream;");
                code.visitMethodStmt(INVOKE_INTERFACE_RANGE,new int[]{ 35},new Method("Ljavax/servlet/ServletRequest;","getInputStream",new String[]{ },"Ljavax/servlet/ServletInputStream;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,31);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,16);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,31);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1},new Method("Ljava/io/BufferedInputStream;","<init>",new String[]{ "Ljava/io/InputStream;"},"V"));
                code.visitLabel(L25);
                code.visitMethodStmt(INVOKE_INTERFACE_RANGE,new int[]{ 25},new Method("Ljavax/servlet/http/HttpServletRequest;","getContentType",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,10);
                code.visitLabel(L26);
                code.visitTypeStmt(NEW_INSTANCE,31,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT_RANGE,new int[]{ 31},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,32,"--");
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 31,32},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,31);
                code.visitConstStmt(CONST_STRING,32,"boundary=");
                code.visitStmt2R(MOVE_OBJECT,0,10);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,32);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/String;","indexOf",new String[]{ "Ljava/lang/String;"},"I"));
                code.visitStmt1R(MOVE_RESULT,32);
                code.visitStmt2R(MOVE_OBJECT,0,10);
                code.visitStmt2R(MOVE_FROM16,1,32);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/String;","substring",new String[]{ "I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,32);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,34);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,32);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1},new Method("Lorg/mortbay/servlet/MultiPartFilter;","value",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,32);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 31,32},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,31);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 31},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitLabel(L27);
                code.visitTypeStmt(NEW_INSTANCE,31,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT_RANGE,new int[]{ 31},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,31);
                code.visitStmt2R(MOVE_OBJECT,1,5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,31);
                code.visitConstStmt(CONST_STRING,32,"--");
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 31,32},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,31);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 31},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,31);
                code.visitFieldStmt(SGET_OBJECT,32,-1,new Field("Lorg/mortbay/util/StringUtil;","__ISO_8859_1","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 31,32},new Method("Ljava/lang/String;","getBytes",new String[]{ "Ljava/lang/String;"},"[B"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitLabel(L28);
                code.visitTypeStmt(NEW_INSTANCE,24,-1,"Lorg/mortbay/util/MultiMap;");
                code.visitMethodStmt(INVOKE_INTERFACE_RANGE,new int[]{ 35},new Method("Ljavax/servlet/ServletRequest;","getParameterMap",new String[]{ },"Ljava/util/Map;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,31);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,24);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,31);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1},new Method("Lorg/mortbay/util/MultiMap;","<init>",new String[]{ "Ljava/util/Map;"},"V"));
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_STATIC_RANGE,new int[]{ 16},new Method("Lorg/mortbay/util/TypeUtil;","readLine",new String[]{ "Ljava/io/InputStream;"},"[B"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitLabel(L29);
                code.visitJumpStmt(IF_NEZ,7,-1,L2);
                code.visitConstStmt(CONST_16,31, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitStmt2R(MOVE_OBJECT_FROM16,20,31);
                code.visitLabel(L30);
                code.visitJumpStmt(IF_EQZ,20,-1,L31);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,20);
                code.visitStmt2R(MOVE_OBJECT,1,5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/String;","equals",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,31);
                code.visitJumpStmt(IF_NEZ,31,-1,L32);
                code.visitLabel(L31);
                code.visitTypeStmt(NEW_INSTANCE,31,-1,"Ljava/io/IOException;");
                code.visitConstStmt(CONST_STRING,32,"Missing initial multi part boundary");
                code.visitMethodStmt(INVOKE_DIRECT_RANGE,new int[]{ 31,32},new Method("Ljava/io/IOException;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitStmt1R(THROW,31);
                code.visitLabel(L1);
                code.visitStmt1R(MOVE_EXCEPTION,31);
                code.visitMethodStmt(INVOKE_DIRECT_RANGE,new int[]{ 34,35},new Method("Lorg/mortbay/servlet/MultiPartFilter;","deleteFiles",new String[]{ "Ljavax/servlet/ServletRequest;"},"V"));
                code.visitStmt1R(THROW,31);
                code.visitLabel(L2);
                code.visitTypeStmt(NEW_INSTANCE,31,-1,"Ljava/lang/String;");
                code.visitConstStmt(CONST_STRING,32,"UTF-8");
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,31);
                code.visitStmt2R(MOVE_OBJECT,1,7);
                code.visitStmt2R(MOVE_OBJECT_FROM16,2,32);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1,2},new Method("Ljava/lang/String;","<init>",new String[]{ "[B","Ljava/lang/String;"},"V"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,20,31);
                code.visitJumpStmt(GOTO,-1,-1,L30);
                code.visitLabel(L32);
                code.visitConstStmt(CONST_16,18, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L33);
                code.visitConstStmt(CONST_4,9, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L34);
                code.visitJumpStmt(IF_NEZ,18,-1,L18);
                code.visitLabel(L35);
                code.visitMethodStmt(INVOKE_STATIC_RANGE,new int[]{ 16},new Method("Lorg/mortbay/util/TypeUtil;","readLine",new String[]{ "Ljava/io/InputStream;"},"[B"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitLabel(L36);
                code.visitJumpStmt(IF_EQZ,7,-1,L37);
                code.visitStmt2R(MOVE_OBJECT,0,7);
                code.visitStmt2R(ARRAY_LENGTH,0,0);
                code.visitStmt2R(MOVE_FROM16,31,0);
                code.visitJumpStmt(IF_NEZ,31,-1,L40);
                code.visitLabel(L37);
                code.visitConstStmt(CONST_4,15, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L38);
                code.visitJumpStmt(IF_NEZ,9,-1,L48);
                code.visitLabel(L39);
                code.visitTypeStmt(NEW_INSTANCE,31,-1,"Ljava/io/IOException;");
                code.visitConstStmt(CONST_STRING,32,"Missing content-disposition");
                code.visitMethodStmt(INVOKE_DIRECT_RANGE,new int[]{ 31,32},new Method("Ljava/io/IOException;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitStmt1R(THROW,31);
                code.visitLabel(L40);
                code.visitTypeStmt(NEW_INSTANCE,20,-1,"Ljava/lang/String;");
                code.visitLabel(L41);
                code.visitConstStmt(CONST_STRING,31,"UTF-8");
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,20);
                code.visitStmt2R(MOVE_OBJECT,1,7);
                code.visitStmt2R(MOVE_OBJECT_FROM16,2,31);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1,2},new Method("Ljava/lang/String;","<init>",new String[]{ "[B","Ljava/lang/String;"},"V"));
                code.visitLabel(L42);
                code.visitConstStmt(CONST_16,31, Integer.valueOf(58)); // int: 0x0000003a  float:0.000000
                code.visitConstStmt(CONST_16,32, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,20);
                code.visitStmt2R(MOVE_FROM16,1,31);
                code.visitStmt2R(MOVE_FROM16,2,32);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1,2},new Method("Ljava/lang/String;","indexOf",new String[]{ "I","I"},"I"));
                code.visitStmt1R(MOVE_RESULT,8);
                code.visitLabel(L43);
                code.visitJumpStmt(IF_LEZ,8,-1,L35);
                code.visitLabel(L44);
                code.visitConstStmt(CONST_16,31, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,20);
                code.visitStmt2R(MOVE_FROM16,1,31);
                code.visitStmt2R(MOVE,2,8);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1,2},new Method("Ljava/lang/String;","substring",new String[]{ "I","I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,31);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 31},new Method("Ljava/lang/String;","trim",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,31);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 31},new Method("Ljava/lang/String;","toLowerCase",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,17);
                code.visitLabel(L45);
                code.visitStmt2R1N(ADD_INT_LIT8,31,8,1);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 20},new Method("Ljava/lang/String;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,32);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,20);
                code.visitStmt2R(MOVE_FROM16,1,31);
                code.visitStmt2R(MOVE_FROM16,2,32);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1,2},new Method("Ljava/lang/String;","substring",new String[]{ "I","I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,31);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 31},new Method("Ljava/lang/String;","trim",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,30);
                code.visitLabel(L46);
                code.visitConstStmt(CONST_STRING,31,"content-disposition");
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,17);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,31);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/String;","equals",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,31);
                code.visitJumpStmt(IF_EQZ,31,-1,L35);
                code.visitLabel(L47);
                code.visitStmt2R(MOVE_OBJECT_FROM16,9,30);
                code.visitJumpStmt(GOTO,-1,-1,L35);
                code.visitLabel(L48);
                code.visitTypeStmt(NEW_INSTANCE,29,-1,"Ljava/util/StringTokenizer;");
                code.visitConstStmt(CONST_STRING,31,";");
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,29);
                code.visitStmt2R(MOVE_OBJECT,1,9);
                code.visitStmt2R(MOVE_OBJECT_FROM16,2,31);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1,2},new Method("Ljava/util/StringTokenizer;","<init>",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"V"));
                code.visitLabel(L49);
                code.visitConstStmt(CONST_16,21, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L50);
                code.visitConstStmt(CONST_4,13, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L51);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 29},new Method("Ljava/util/StringTokenizer;","hasMoreTokens",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,31);
                code.visitJumpStmt(IF_EQZ,31,-1,L60);
                code.visitLabel(L52);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 29},new Method("Ljava/util/StringTokenizer;","nextToken",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,31);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 31},new Method("Ljava/lang/String;","trim",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,27);
                code.visitLabel(L53);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 27},new Method("Ljava/lang/String;","toLowerCase",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,28);
                code.visitLabel(L54);
                code.visitConstStmt(CONST_STRING,31,"form-data");
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,31);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/String;","startsWith",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,31);
                code.visitJumpStmt(IF_EQZ,31,-1,L56);
                code.visitLabel(L55);
                code.visitConstStmt(CONST_4,15, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L51);
                code.visitLabel(L56);
                code.visitConstStmt(CONST_STRING,31,"name=");
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,28);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,31);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/String;","startsWith",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,31);
                code.visitJumpStmt(IF_EQZ,31,-1,L58);
                code.visitLabel(L57);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,34);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,27);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1},new Method("Lorg/mortbay/servlet/MultiPartFilter;","value",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,21);
                code.visitJumpStmt(GOTO,-1,-1,L51);
                code.visitLabel(L58);
                code.visitConstStmt(CONST_STRING,31,"filename=");
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,28);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,31);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/String;","startsWith",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,31);
                code.visitJumpStmt(IF_EQZ,31,-1,L51);
                code.visitLabel(L59);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,34);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,27);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1},new Method("Lorg/mortbay/servlet/MultiPartFilter;","value",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,13);
                code.visitJumpStmt(GOTO,-1,-1,L51);
                code.visitLabel(L60);
                code.visitJumpStmt(IF_EQZ,15,-1,L34);
                code.visitLabel(L61);
                code.visitJumpStmt(IF_EQZ,21,-1,L34);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 21},new Method("Ljava/lang/String;","length",new String[]{ },"I"));
                code.visitLabel(L3);
                code.visitStmt1R(MOVE_RESULT,31);
                code.visitJumpStmt(IF_EQZ,31,-1,L34);
                code.visitLabel(L62);
                code.visitConstStmt(CONST_16,22, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L63);
                code.visitConstStmt(CONST_4,12, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L64);
                code.visitJumpStmt(IF_EQZ,13,-1,L12);
                code.visitLabel(L4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 13},new Method("Ljava/lang/String;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,31);
                code.visitJumpStmt(IF_LEZ,31,-1,L12);
                code.visitLabel(L65);
                code.visitConstStmt(CONST_STRING,31,"MultiPart");
                code.visitConstStmt(CONST_STRING,32,"");
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,34);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/servlet/MultiPartFilter;","tempdir","Ljava/io/File;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,33,0);
                code.visitMethodStmt(INVOKE_STATIC_RANGE,new int[]{ 31,32,33},new Method("Ljava/io/File;","createTempFile",new String[]{ "Ljava/lang/String;","Ljava/lang/String;","Ljava/io/File;"},"Ljava/io/File;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,12);
                code.visitLabel(L66);
                code.visitTypeStmt(NEW_INSTANCE,23,-1,"Ljava/io/FileOutputStream;");
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,23);
                code.visitStmt2R(MOVE_OBJECT,1,12);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1},new Method("Ljava/io/FileOutputStream;","<init>",new String[]{ "Ljava/io/File;"},"V"));
                code.visitLabel(L5);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,34);
                code.visitFieldStmt(IGET,0,0,new Field("Lorg/mortbay/servlet/MultiPartFilter;","_fileOutputBuffer","I"));
                code.visitStmt2R(MOVE_FROM16,31,0);
                code.visitLabel(L67);
                code.visitJumpStmt(IF_LEZ,31,-1,L127);
                code.visitLabel(L68);
                code.visitTypeStmt(NEW_INSTANCE,22,-1,"Ljava/io/BufferedOutputStream;");
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,34);
                code.visitFieldStmt(IGET,0,0,new Field("Lorg/mortbay/servlet/MultiPartFilter;","_fileOutputBuffer","I"));
                code.visitStmt2R(MOVE_FROM16,31,0);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,22);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,23);
                code.visitStmt2R(MOVE_FROM16,2,31);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1,2},new Method("Ljava/io/BufferedOutputStream;","<init>",new String[]{ "Ljava/io/OutputStream;","I"},"V"));
                code.visitLabel(L7);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,35);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,21);
                code.visitStmt2R(MOVE_OBJECT,2,12);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,1,2},new Method("Ljavax/servlet/ServletRequest;","setAttribute",new String[]{ "Ljava/lang/String;","Ljava/lang/Object;"},"V"));
                code.visitLabel(L69);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,24);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,21);
                code.visitStmt2R(MOVE_OBJECT,2,13);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1,2},new Method("Lorg/mortbay/util/MultiMap;","put",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitLabel(L70);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,34);
                code.visitFieldStmt(IGET_BOOLEAN,0,0,new Field("Lorg/mortbay/servlet/MultiPartFilter;","_deleteFiles","Z"));
                code.visitStmt2R(MOVE_FROM16,31,0);
                code.visitJumpStmt(IF_EQZ,31,-1,L78);
                code.visitLabel(L71);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 12},new Method("Ljava/io/File;","deleteOnExit",new String[]{ },"V"));
                code.visitLabel(L72);
                code.visitConstStmt(CONST_STRING,31,"org.mortbay.servlet.MultiPartFilter.files");
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,35);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,31);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,1},new Method("Ljavax/servlet/ServletRequest;","getAttribute",new String[]{ "Ljava/lang/String;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,14);
                code.visitTypeStmt(CHECK_CAST,14,-1,"Ljava/util/ArrayList;");
                code.visitLabel(L73);
                code.visitJumpStmt(IF_NEZ,14,-1,L77);
                code.visitLabel(L74);
                code.visitTypeStmt(NEW_INSTANCE,14,-1,"Ljava/util/ArrayList;");
                code.visitLabel(L75);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 14},new Method("Ljava/util/ArrayList;","<init>",new String[]{ },"V"));
                code.visitLabel(L76);
                code.visitConstStmt(CONST_STRING,31,"org.mortbay.servlet.MultiPartFilter.files");
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,35);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,31);
                code.visitStmt2R(MOVE_OBJECT,2,14);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,1,2},new Method("Ljavax/servlet/ServletRequest;","setAttribute",new String[]{ "Ljava/lang/String;","Ljava/lang/Object;"},"V"));
                code.visitLabel(L77);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 14,12},new Method("Ljava/util/ArrayList;","add",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitLabel(L78);
                code.visitConstStmt(CONST_16,26, Integer.valueOf(-2)); // int: 0xfffffffe  float:NaN
                code.visitLabel(L79);
                code.visitConstStmt(CONST_4,11, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L80);
                code.visitConstStmt(CONST_16,19, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L81);
                code.visitConstStmt(CONST_4,4, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L82);
                code.visitConstStmt(CONST_16,31, Integer.valueOf(-2)); // int: 0xfffffffe  float:NaN
                code.visitStmt2R(MOVE_FROM16,0,26);
                code.visitStmt2R(MOVE_FROM16,1,31);
                code.visitJumpStmt(IF_EQ,0,1,L106);
                code.visitStmt2R(MOVE_FROM16,8,26);
                code.visitLabel(L83);
                code.visitConstStmt(CONST_16,31, Integer.valueOf(-1)); // int: 0xffffffff  float:NaN
                code.visitStmt2R(MOVE,0,8);
                code.visitStmt2R(MOVE_FROM16,1,31);
                code.visitJumpStmt(IF_EQ,0,1,L88);
                code.visitLabel(L84);
                code.visitConstStmt(CONST_16,26, Integer.valueOf(-2)); // int: 0xfffffffe  float:NaN
                code.visitLabel(L85);
                code.visitConstStmt(CONST_16,31, Integer.valueOf(13)); // int: 0x0000000d  float:0.000000
                code.visitStmt2R(MOVE,0,8);
                code.visitStmt2R(MOVE_FROM16,1,31);
                code.visitJumpStmt(IF_EQ,0,1,L86);
                code.visitConstStmt(CONST_16,31, Integer.valueOf(10)); // int: 0x0000000a  float:0.000000
                code.visitStmt2R(MOVE,0,8);
                code.visitStmt2R(MOVE_FROM16,1,31);
                code.visitJumpStmt(IF_NE,0,1,L107);
                code.visitLabel(L86);
                code.visitConstStmt(CONST_16,31, Integer.valueOf(13)); // int: 0x0000000d  float:0.000000
                code.visitStmt2R(MOVE,0,8);
                code.visitStmt2R(MOVE_FROM16,1,31);
                code.visitJumpStmt(IF_NE,0,1,L88);
                code.visitLabel(L87);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 16},new Method("Ljava/io/BufferedInputStream;","read",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,26);
                code.visitLabel(L88);
                DexLabel L129=new DexLabel();
                code.visitJumpStmt(IF_LEZ,4,-1,L129);
                code.visitStmt2R(MOVE_OBJECT,0,6);
                code.visitStmt2R(ARRAY_LENGTH,0,0);
                code.visitStmt2R(MOVE_FROM16,31,0);
                code.visitConstStmt(CONST_16,32, Integer.valueOf(2)); // int: 0x00000002  float:0.000000
                code.visitStmt3R(SUB_INT,31,31,32);
                code.visitStmt2R(MOVE,0,4);
                code.visitStmt2R(MOVE_FROM16,1,31);
                code.visitJumpStmt(IF_LT,0,1,L89);
                code.visitLabel(L129);
                code.visitStmt2R(MOVE_OBJECT,0,6);
                code.visitStmt2R(ARRAY_LENGTH,0,0);
                code.visitStmt2R(MOVE_FROM16,31,0);
                code.visitConstStmt(CONST_16,32, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitStmt3R(SUB_INT,31,31,32);
                code.visitStmt2R(MOVE,0,4);
                code.visitStmt2R(MOVE_FROM16,1,31);
                code.visitJumpStmt(IF_NE,0,1,L96);
                code.visitLabel(L89);
                code.visitJumpStmt(IF_EQZ,11,-1,L91);
                code.visitLabel(L90);
                code.visitConstStmt(CONST_16,31, Integer.valueOf(13)); // int: 0x0000000d  float:0.000000
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,22);
                code.visitStmt2R(MOVE_FROM16,1,31);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/io/OutputStream;","write",new String[]{ "I"},"V"));
                code.visitLabel(L91);
                code.visitJumpStmt(IF_EQZ,19,-1,L93);
                code.visitLabel(L92);
                code.visitConstStmt(CONST_16,31, Integer.valueOf(10)); // int: 0x0000000a  float:0.000000
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,22);
                code.visitStmt2R(MOVE_FROM16,1,31);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/io/OutputStream;","write",new String[]{ "I"},"V"));
                code.visitLabel(L93);
                code.visitConstStmt(CONST_16,19, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitStmt2R(MOVE_FROM16,11,19);
                code.visitLabel(L94);
                code.visitConstStmt(CONST_16,31, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,22);
                code.visitStmt2R(MOVE_OBJECT,1,6);
                code.visitStmt2R(MOVE_FROM16,2,31);
                code.visitStmt2R(MOVE,3,4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1,2,3},new Method("Ljava/io/OutputStream;","write",new String[]{ "[B","I","I"},"V"));
                code.visitLabel(L95);
                code.visitConstStmt(CONST_4,4, Integer.valueOf(-1)); // int: 0xffffffff  float:NaN
                code.visitLabel(L96);
                code.visitJumpStmt(IF_GTZ,4,-1,L97);
                code.visitConstStmt(CONST_16,31, Integer.valueOf(-1)); // int: 0xffffffff  float:NaN
                code.visitStmt2R(MOVE,0,8);
                code.visitStmt2R(MOVE_FROM16,1,31);
                code.visitJumpStmt(IF_NE,0,1,L15);
                code.visitLabel(L97);
                code.visitStmt2R(MOVE_OBJECT,0,6);
                code.visitStmt2R(ARRAY_LENGTH,0,0);
                code.visitStmt2R(MOVE_FROM16,31,0);
                code.visitLabel(L9);
                code.visitStmt2R(MOVE,0,4);
                code.visitStmt2R(MOVE_FROM16,1,31);
                code.visitJumpStmt(IF_NE,0,1,L99);
                code.visitLabel(L98);
                code.visitConstStmt(CONST_16,18, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitLabel(L99);
                code.visitConstStmt(CONST_16,31, Integer.valueOf(10)); // int: 0x0000000a  float:0.000000
                code.visitStmt2R(MOVE_FROM16,0,26);
                code.visitStmt2R(MOVE_FROM16,1,31);
                code.visitJumpStmt(IF_NE,0,1,L10);
                code.visitLabel(L100);
                code.visitConstStmt(CONST_16,26, Integer.valueOf(-2)); // int: 0xfffffffe  float:NaN
                code.visitLabel(L10);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 22},new Method("Ljava/io/OutputStream;","close",new String[]{ },"V"));
                code.visitLabel(L101);
                code.visitJumpStmt(IF_NEZ,12,-1,L34);
                code.visitLabel(L102);
                code.visitTypeStmt(CHECK_CAST,22,-1,"Ljava/io/ByteArrayOutputStream;");
                code.visitLabel(L103);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 22},new Method("Ljava/io/ByteArrayOutputStream;","toByteArray",new String[]{ },"[B"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitLabel(L104);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,24);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,21);
                code.visitStmt2R(MOVE_OBJECT,2,7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1,2},new Method("Lorg/mortbay/util/MultiMap;","add",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;"},"V"));
                code.visitLabel(L11);
                code.visitJumpStmt(GOTO_16,-1,-1,L34);
                code.visitLabel(L12);
                code.visitTypeStmt(NEW_INSTANCE,23,-1,"Ljava/io/ByteArrayOutputStream;");
                code.visitMethodStmt(INVOKE_DIRECT_RANGE,new int[]{ 23},new Method("Ljava/io/ByteArrayOutputStream;","<init>",new String[]{ },"V"));
                code.visitLabel(L105);
                code.visitStmt2R(MOVE_OBJECT_FROM16,22,23);
                code.visitJumpStmt(GOTO_16,-1,-1,L78);
                code.visitLabel(L106);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 16},new Method("Ljava/io/BufferedInputStream;","read",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,31);
                code.visitStmt2R(MOVE_FROM16,8,31);
                code.visitJumpStmt(GOTO_16,-1,-1,L83);
                code.visitLabel(L107);
                code.visitJumpStmt(IF_LTZ,4,-1,L109);
                code.visitStmt2R(MOVE_OBJECT,0,6);
                code.visitStmt2R(ARRAY_LENGTH,0,0);
                code.visitStmt2R(MOVE_FROM16,31,0);
                code.visitStmt2R(MOVE,0,4);
                code.visitStmt2R(MOVE_FROM16,1,31);
                code.visitJumpStmt(IF_GE,0,1,L109);
                code.visitStmt3R(AGET_BYTE,31,6,4);
                code.visitStmt2R(MOVE,0,8);
                code.visitStmt2R(MOVE_FROM16,1,31);
                code.visitJumpStmt(IF_NE,0,1,L109);
                code.visitLabel(L108);
                code.visitStmt2R1N(ADD_INT_LIT8,4,4,1);
                code.visitJumpStmt(GOTO_16,-1,-1,L82);
                code.visitLabel(L109);
                code.visitJumpStmt(IF_EQZ,11,-1,L111);
                code.visitLabel(L110);
                code.visitConstStmt(CONST_16,31, Integer.valueOf(13)); // int: 0x0000000d  float:0.000000
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,22);
                code.visitStmt2R(MOVE_FROM16,1,31);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/io/OutputStream;","write",new String[]{ "I"},"V"));
                code.visitLabel(L111);
                code.visitJumpStmt(IF_EQZ,19,-1,L113);
                code.visitLabel(L112);
                code.visitConstStmt(CONST_16,31, Integer.valueOf(10)); // int: 0x0000000a  float:0.000000
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,22);
                code.visitStmt2R(MOVE_FROM16,1,31);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/io/OutputStream;","write",new String[]{ "I"},"V"));
                code.visitLabel(L113);
                code.visitConstStmt(CONST_16,19, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitStmt2R(MOVE_FROM16,11,19);
                code.visitLabel(L114);
                code.visitJumpStmt(IF_LEZ,4,-1,L116);
                code.visitLabel(L115);
                code.visitConstStmt(CONST_16,31, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,22);
                code.visitStmt2R(MOVE_OBJECT,1,6);
                code.visitStmt2R(MOVE_FROM16,2,31);
                code.visitStmt2R(MOVE,3,4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1,2,3},new Method("Ljava/io/OutputStream;","write",new String[]{ "[B","I","I"},"V"));
                code.visitLabel(L116);
                code.visitConstStmt(CONST_4,4, Integer.valueOf(-1)); // int: 0xffffffff  float:NaN
                code.visitLabel(L117);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,22);
                code.visitStmt2R(MOVE,1,8);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/io/OutputStream;","write",new String[]{ "I"},"V"));
                code.visitLabel(L13);
                code.visitJumpStmt(GOTO_16,-1,-1,L82);
                code.visitLabel(L6);
                code.visitStmt1R(MOVE_EXCEPTION,31);
                code.visitLabel(L14);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 22},new Method("Ljava/io/OutputStream;","close",new String[]{ },"V"));
                code.visitStmt1R(THROW,31);
                code.visitLabel(L15);
                code.visitJumpStmt(IF_EQZ,11,-1,L119);
                code.visitLabel(L118);
                code.visitConstStmt(CONST_16,31, Integer.valueOf(13)); // int: 0x0000000d  float:0.000000
                code.visitLabel(L16);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,22);
                code.visitStmt2R(MOVE_FROM16,1,31);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/io/OutputStream;","write",new String[]{ "I"},"V"));
                code.visitLabel(L119);
                code.visitJumpStmt(IF_EQZ,19,-1,L17);
                code.visitLabel(L120);
                code.visitConstStmt(CONST_16,31, Integer.valueOf(10)); // int: 0x0000000a  float:0.000000
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,22);
                code.visitStmt2R(MOVE_FROM16,1,31);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/io/OutputStream;","write",new String[]{ "I"},"V"));
                code.visitLabel(L17);
                code.visitConstStmt(CONST_16,31, Integer.valueOf(13)); // int: 0x0000000d  float:0.000000
                code.visitStmt2R(MOVE,0,8);
                code.visitStmt2R(MOVE_FROM16,1,31);
                code.visitJumpStmt(IF_NE,0,1,L124);
                code.visitConstStmt(CONST_16,31, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitStmt2R(MOVE_FROM16,11,31);
                code.visitLabel(L121);
                code.visitConstStmt(CONST_16,31, Integer.valueOf(10)); // int: 0x0000000a  float:0.000000
                code.visitStmt2R(MOVE,0,8);
                code.visitStmt2R(MOVE_FROM16,1,31);
                DexLabel L130=new DexLabel();
                code.visitJumpStmt(IF_EQ,0,1,L130);
                code.visitConstStmt(CONST_16,31, Integer.valueOf(10)); // int: 0x0000000a  float:0.000000
                code.visitStmt2R(MOVE_FROM16,0,26);
                code.visitStmt2R(MOVE_FROM16,1,31);
                code.visitJumpStmt(IF_NE,0,1,L125);
                code.visitLabel(L130);
                code.visitConstStmt(CONST_16,31, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitStmt2R(MOVE_FROM16,19,31);
                code.visitLabel(L122);
                code.visitConstStmt(CONST_16,31, Integer.valueOf(10)); // int: 0x0000000a  float:0.000000
                code.visitStmt2R(MOVE_FROM16,0,26);
                code.visitStmt2R(MOVE_FROM16,1,31);
                code.visitJumpStmt(IF_NE,0,1,L81);
                code.visitLabel(L123);
                code.visitConstStmt(CONST_16,26, Integer.valueOf(-2)); // int: 0xfffffffe  float:NaN
                code.visitJumpStmt(GOTO_16,-1,-1,L81);
                code.visitLabel(L124);
                code.visitConstStmt(CONST_16,31, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitStmt2R(MOVE_FROM16,11,31);
                code.visitJumpStmt(GOTO,-1,-1,L121);
                code.visitLabel(L125);
                code.visitConstStmt(CONST_16,31, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitStmt2R(MOVE_FROM16,19,31);
                code.visitJumpStmt(GOTO,-1,-1,L122);
                code.visitLabel(L18);
                code.visitTypeStmt(NEW_INSTANCE,31,-1,"Lorg/mortbay/servlet/MultiPartFilter$Wrapper;");
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,31);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,25);
                code.visitStmt2R(MOVE_OBJECT_FROM16,2,24);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1,2},new Method("Lorg/mortbay/servlet/MultiPartFilter$Wrapper;","<init>",new String[]{ "Ljavax/servlet/http/HttpServletRequest;","Lorg/mortbay/util/MultiMap;"},"V"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,37);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,31);
                code.visitStmt2R(MOVE_OBJECT_FROM16,2,36);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,1,2},new Method("Ljavax/servlet/FilterChain;","doFilter",new String[]{ "Ljavax/servlet/ServletRequest;","Ljavax/servlet/ServletResponse;"},"V"));
                code.visitLabel(L19);
                code.visitMethodStmt(INVOKE_DIRECT_RANGE,new int[]{ 34,35},new Method("Lorg/mortbay/servlet/MultiPartFilter;","deleteFiles",new String[]{ "Ljavax/servlet/ServletRequest;"},"V"));
                code.visitJumpStmt(GOTO_16,-1,-1,L23);
                code.visitLabel(L8);
                code.visitStmt1R(MOVE_EXCEPTION,31);
                code.visitStmt2R(MOVE_OBJECT_FROM16,22,23);
                code.visitLabel(L126);
                code.visitJumpStmt(GOTO,-1,-1,L14);
                code.visitLabel(L127);
                code.visitStmt2R(MOVE_OBJECT_FROM16,22,23);
                code.visitLabel(L128);
                code.visitJumpStmt(GOTO_16,-1,-1,L7);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m005_init(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/servlet/MultiPartFilter;","init",new String[]{ "Ljavax/servlet/FilterConfig;"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljavax/servlet/ServletException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"filterConfig");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(76,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(77,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(78,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(79,L3);
                ddv.visitStartLocal(0,L3,"fileOutputBuffer","Ljava/lang/String;",null);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(80,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(81,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(82,L6);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 4},new Method("Ljavax/servlet/FilterConfig;","getServletContext",new String[]{ },"Ljavax/servlet/ServletContext;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitConstStmt(CONST_STRING,2,"javax.servlet.context.tempdir");
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 1,2},new Method("Ljavax/servlet/ServletContext;","getAttribute",new String[]{ "Ljava/lang/String;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitTypeStmt(CHECK_CAST,1,-1,"Ljava/io/File;");
                code.visitFieldStmt(IPUT_OBJECT,1,3,new Field("Lorg/mortbay/servlet/MultiPartFilter;","tempdir","Ljava/io/File;"));
                code.visitLabel(L1);
                code.visitConstStmt(CONST_STRING,1,"true");
                code.visitConstStmt(CONST_STRING,2,"deleteFiles");
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 4,2},new Method("Ljavax/servlet/FilterConfig;","getInitParameter",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2},new Method("Ljava/lang/String;","equals",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitFieldStmt(IPUT_BOOLEAN,1,3,new Field("Lorg/mortbay/servlet/MultiPartFilter;","_deleteFiles","Z"));
                code.visitLabel(L2);
                code.visitConstStmt(CONST_STRING,1,"fileOutputBuffer");
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 4,1},new Method("Ljavax/servlet/FilterConfig;","getInitParameter",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L3);
                code.visitJumpStmt(IF_EQZ,0,-1,L5);
                code.visitLabel(L4);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0},new Method("Ljava/lang/Integer;","parseInt",new String[]{ "Ljava/lang/String;"},"I"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitFieldStmt(IPUT,1,3,new Field("Lorg/mortbay/servlet/MultiPartFilter;","_fileOutputBuffer","I"));
                code.visitLabel(L5);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 4},new Method("Ljavax/servlet/FilterConfig;","getServletContext",new String[]{ },"Ljavax/servlet/ServletContext;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitFieldStmt(IPUT_OBJECT,1,3,new Field("Lorg/mortbay/servlet/MultiPartFilter;","_context","Ljavax/servlet/ServletContext;"));
                code.visitLabel(L6);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
