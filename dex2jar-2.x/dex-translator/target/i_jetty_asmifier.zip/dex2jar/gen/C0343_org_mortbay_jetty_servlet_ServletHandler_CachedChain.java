package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0343_org_mortbay_jetty_servlet_ServletHandler_CachedChain {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(0,"Lorg/mortbay/jetty/servlet/ServletHandler$CachedChain;","Ljava/lang/Object;",new String[]{ "Ljavax/servlet/FilterChain;"});
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("ServletHandler.java");
        if(cv!=null){
            DexAnnotationVisitor av00 = cv.visitAnnotation("Ldalvik/annotation/EnclosingClass;", Visibility.SYSTEM);
            if(av00 != null) {
                av00.visit("value", new DexType("Lorg/mortbay/jetty/servlet/ServletHandler;"));
                av00.visitEnd();
            }
        }
        if(cv!=null){
            DexAnnotationVisitor av00 = cv.visitAnnotation("Ldalvik/annotation/InnerClass;", Visibility.SYSTEM);
            if(av00 != null) {
                av00.visit("accessFlags",  Integer.valueOf(2));
                av00.visit("name", "CachedChain");
                av00.visitEnd();
            }
        }
        f000__filterHolder(cv);
        f001__next(cv);
        f002__servletHolder(cv);
        f003_this$0(cv);
        m000__init_(cv);
        m001_doFilter(cv);
        m002_toString(cv);
    }
    public static void f000__filterHolder(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(0, new Field("Lorg/mortbay/jetty/servlet/ServletHandler$CachedChain;","_filterHolder","Lorg/mortbay/jetty/servlet/FilterHolder;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f001__next(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(0, new Field("Lorg/mortbay/jetty/servlet/ServletHandler$CachedChain;","_next","Lorg/mortbay/jetty/servlet/ServletHandler$CachedChain;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f002__servletHolder(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(0, new Field("Lorg/mortbay/jetty/servlet/ServletHandler$CachedChain;","_servletHolder","Lorg/mortbay/jetty/servlet/ServletHolder;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f003_this$0(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_FINAL|ACC_SYNTHETIC, new Field("Lorg/mortbay/jetty/servlet/ServletHandler$CachedChain;","this$0","Lorg/mortbay/jetty/servlet/ServletHandler;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void m000__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_CONSTRUCTOR, new Method("Lorg/mortbay/jetty/servlet/ServletHandler$CachedChain;","<init>",new String[]{ "Lorg/mortbay/jetty/servlet/ServletHandler;","Ljava/lang/Object;","Lorg/mortbay/jetty/servlet/ServletHolder;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(6);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(1,"filters");
                ddv.visitParameterName(2,"servletHolder");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(1127,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(1128,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(1130,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(1131,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(1132,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(1136,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(1135,L7);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L1);
                code.visitFieldStmt(IPUT_OBJECT,3,2,new Field("Lorg/mortbay/jetty/servlet/ServletHandler$CachedChain;","this$0","Lorg/mortbay/jetty/servlet/ServletHandler;"));
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2},new Method("Ljava/lang/Object;","<init>",new String[]{ },"V"));
                code.visitLabel(L2);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 4},new Method("Lorg/mortbay/util/LazyList;","size",new String[]{ "Ljava/lang/Object;"},"I"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_LEZ,0,-1,L7);
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 4,1},new Method("Lorg/mortbay/util/LazyList;","get",new String[]{ "Ljava/lang/Object;","I"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitTypeStmt(CHECK_CAST,0,-1,"Lorg/mortbay/jetty/servlet/FilterHolder;");
                code.visitFieldStmt(IPUT_OBJECT,0,2,new Field("Lorg/mortbay/jetty/servlet/ServletHandler$CachedChain;","_filterHolder","Lorg/mortbay/jetty/servlet/FilterHolder;"));
                code.visitLabel(L4);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 4,1},new Method("Lorg/mortbay/util/LazyList;","remove",new String[]{ "Ljava/lang/Object;","I"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitLabel(L5);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Lorg/mortbay/jetty/servlet/ServletHandler$CachedChain;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,3,4,5},new Method("Lorg/mortbay/jetty/servlet/ServletHandler$CachedChain;","<init>",new String[]{ "Lorg/mortbay/jetty/servlet/ServletHandler;","Ljava/lang/Object;","Lorg/mortbay/jetty/servlet/ServletHolder;"},"V"));
                code.visitFieldStmt(IPUT_OBJECT,0,2,new Field("Lorg/mortbay/jetty/servlet/ServletHandler$CachedChain;","_next","Lorg/mortbay/jetty/servlet/ServletHandler$CachedChain;"));
                code.visitLabel(L6);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L7);
                code.visitFieldStmt(IPUT_OBJECT,5,2,new Field("Lorg/mortbay/jetty/servlet/ServletHandler$CachedChain;","_servletHolder","Lorg/mortbay/jetty/servlet/ServletHolder;"));
                code.visitJumpStmt(GOTO,-1,-1,L6);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001_doFilter(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/servlet/ServletHandler$CachedChain;","doFilter",new String[]{ "Ljavax/servlet/ServletRequest;","Ljavax/servlet/ServletResponse;"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visit(null, new DexType("Ljavax/servlet/ServletException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(6);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"request");
                ddv.visitParameterName(1,"response");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(1143,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(1145,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(1146,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(1147,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(1148,L4);
                ddv.visitStartLocal(0,L4,"filter","Ljavax/servlet/Filter;",null);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(1161,L5);
                ddv.visitEndLocal(4,L5);
                ddv.visitEndLocal(5,L5);
                ddv.visitEndLocal(0,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(1153,L6);
                ddv.visitRestartLocal(4,L6);
                ddv.visitRestartLocal(5,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(1155,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(1156,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(1157,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(1160,L10);
                DexLabel L11=new DexLabel();
                ddv.visitEndLocal(4,L11);
                DexLabel L12=new DexLabel();
                ddv.visitEndLocal(5,L12);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,1,3,new Field("Lorg/mortbay/jetty/servlet/ServletHandler$CachedChain;","_filterHolder","Lorg/mortbay/jetty/servlet/FilterHolder;"));
                code.visitJumpStmt(IF_EQZ,1,-1,L6);
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Lorg/mortbay/log/Log;","isDebugEnabled",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitJumpStmt(IF_EQZ,1,-1,L3);
                code.visitLabel(L2);
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,2,"call filter ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitFieldStmt(IGET_OBJECT,2,3,new Field("Lorg/mortbay/jetty/servlet/ServletHandler$CachedChain;","_filterHolder","Lorg/mortbay/jetty/servlet/FilterHolder;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1},new Method("Lorg/mortbay/log/Log;","debug",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,1,3,new Field("Lorg/mortbay/jetty/servlet/ServletHandler$CachedChain;","_filterHolder","Lorg/mortbay/jetty/servlet/FilterHolder;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Lorg/mortbay/jetty/servlet/FilterHolder;","getFilter",new String[]{ },"Ljavax/servlet/Filter;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L4);
                code.visitFieldStmt(IGET_OBJECT,1,3,new Field("Lorg/mortbay/jetty/servlet/ServletHandler$CachedChain;","_next","Lorg/mortbay/jetty/servlet/ServletHandler$CachedChain;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,4,5,1},new Method("Ljavax/servlet/Filter;","doFilter",new String[]{ "Ljavax/servlet/ServletRequest;","Ljavax/servlet/ServletResponse;","Ljavax/servlet/FilterChain;"},"V"));
                code.visitLabel(L5);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L6);
                code.visitFieldStmt(IGET_OBJECT,1,3,new Field("Lorg/mortbay/jetty/servlet/ServletHandler$CachedChain;","_servletHolder","Lorg/mortbay/jetty/servlet/ServletHolder;"));
                code.visitJumpStmt(IF_EQZ,1,-1,L10);
                code.visitLabel(L7);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Lorg/mortbay/log/Log;","isDebugEnabled",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitJumpStmt(IF_EQZ,1,-1,L9);
                code.visitLabel(L8);
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,2,"call servlet ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitFieldStmt(IGET_OBJECT,2,3,new Field("Lorg/mortbay/jetty/servlet/ServletHandler$CachedChain;","_servletHolder","Lorg/mortbay/jetty/servlet/ServletHolder;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1},new Method("Lorg/mortbay/log/Log;","debug",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L9);
                code.visitFieldStmt(IGET_OBJECT,1,3,new Field("Lorg/mortbay/jetty/servlet/ServletHandler$CachedChain;","_servletHolder","Lorg/mortbay/jetty/servlet/ServletHolder;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,4,5},new Method("Lorg/mortbay/jetty/servlet/ServletHolder;","handle",new String[]{ "Ljavax/servlet/ServletRequest;","Ljavax/servlet/ServletResponse;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L5);
                code.visitLabel(L10);
                code.visitFieldStmt(IGET_OBJECT,1,3,new Field("Lorg/mortbay/jetty/servlet/ServletHandler$CachedChain;","this$0","Lorg/mortbay/jetty/servlet/ServletHandler;"));
                code.visitTypeStmt(CHECK_CAST,4,-1,"Ljavax/servlet/http/HttpServletRequest;");
                code.visitLabel(L11);
                code.visitTypeStmt(CHECK_CAST,5,-1,"Ljavax/servlet/http/HttpServletResponse;");
                code.visitLabel(L12);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,4,5},new Method("Lorg/mortbay/jetty/servlet/ServletHandler;","notFound",new String[]{ "Ljavax/servlet/http/HttpServletRequest;","Ljavax/servlet/http/HttpServletResponse;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L5);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m002_toString(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/servlet/ServletHandler$CachedChain;","toString",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(1165,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(1166,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(1169,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(1167,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(1168,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(1169,L5);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/jetty/servlet/ServletHandler$CachedChain;","_filterHolder","Lorg/mortbay/jetty/servlet/FilterHolder;"));
                code.visitJumpStmt(IF_EQZ,0,-1,L3);
                code.visitLabel(L1);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/jetty/servlet/ServletHandler$CachedChain;","_filterHolder","Lorg/mortbay/jetty/servlet/FilterHolder;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitConstStmt(CONST_STRING,1,"->");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/jetty/servlet/ServletHandler$CachedChain;","_next","Lorg/mortbay/jetty/servlet/ServletHandler$CachedChain;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Lorg/mortbay/jetty/servlet/ServletHandler$CachedChain;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L2);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/jetty/servlet/ServletHandler$CachedChain;","_servletHolder","Lorg/mortbay/jetty/servlet/ServletHolder;"));
                code.visitJumpStmt(IF_EQZ,0,-1,L5);
                code.visitLabel(L4);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/jetty/servlet/ServletHandler$CachedChain;","_servletHolder","Lorg/mortbay/jetty/servlet/ServletHolder;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/jetty/servlet/ServletHolder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitLabel(L5);
                code.visitConstStmt(CONST_STRING,0,"null");
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
