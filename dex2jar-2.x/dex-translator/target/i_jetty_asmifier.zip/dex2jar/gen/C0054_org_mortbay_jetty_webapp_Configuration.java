package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0054_org_mortbay_jetty_webapp_Configuration {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(ACC_PUBLIC|ACC_INTERFACE|ACC_ABSTRACT,"Lorg/mortbay/jetty/webapp/Configuration;","Ljava/lang/Object;",new String[]{ "Ljava/io/Serializable;"});
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("Configuration.java");
        m000_configureClassLoader(cv);
        m001_configureDefaults(cv);
        m002_configureWebApp(cv);
        m003_deconfigureWebApp(cv);
        m004_getWebAppContext(cv);
        m005_setWebAppContext(cv);
    }
    public static void m000_configureClassLoader(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Lorg/mortbay/jetty/webapp/Configuration;","configureClassLoader",new String[]{ },"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/lang/Exception;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            mv.visitEnd();
        }
    }
    public static void m001_configureDefaults(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Lorg/mortbay/jetty/webapp/Configuration;","configureDefaults",new String[]{ },"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/lang/Exception;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            mv.visitEnd();
        }
    }
    public static void m002_configureWebApp(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Lorg/mortbay/jetty/webapp/Configuration;","configureWebApp",new String[]{ },"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/lang/Exception;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            mv.visitEnd();
        }
    }
    public static void m003_deconfigureWebApp(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Lorg/mortbay/jetty/webapp/Configuration;","deconfigureWebApp",new String[]{ },"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/lang/Exception;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            mv.visitEnd();
        }
    }
    public static void m004_getWebAppContext(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Lorg/mortbay/jetty/webapp/Configuration;","getWebAppContext",new String[]{ },"Lorg/mortbay/jetty/webapp/WebAppContext;"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m005_setWebAppContext(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Lorg/mortbay/jetty/webapp/Configuration;","setWebAppContext",new String[]{ "Lorg/mortbay/jetty/webapp/WebAppContext;"},"V"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
}
