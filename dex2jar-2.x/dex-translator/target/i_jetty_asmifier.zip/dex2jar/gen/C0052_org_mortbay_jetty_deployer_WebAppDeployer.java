package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0052_org_mortbay_jetty_deployer_WebAppDeployer {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(ACC_PUBLIC,"Lorg/mortbay/jetty/deployer/WebAppDeployer;","Lorg/mortbay/component/AbstractLifeCycle;",new String[]{ });
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("WebAppDeployer.java");
        f000__allowDuplicates(cv);
        f001__configurationClasses(cv);
        f002__contexts(cv);
        f003__defaultsDescriptor(cv);
        f004__deployed(cv);
        f005__extract(cv);
        f006__parentLoaderPriority(cv);
        f007__webAppDir(cv);
        m000__init_(cv);
        m001_doStart(cv);
        m002_doStop(cv);
        m003_getAllowDuplicates(cv);
        m004_getConfigurationClasses(cv);
        m005_getContexts(cv);
        m006_getDefaultsDescriptor(cv);
        m007_getWebAppDir(cv);
        m008_isExtract(cv);
        m009_isParentLoaderPriority(cv);
        m010_scan(cv);
        m011_setAllowDuplicates(cv);
        m012_setConfigurationClasses(cv);
        m013_setContexts(cv);
        m014_setDefaultsDescriptor(cv);
        m015_setExtract(cv);
        m016_setParentLoaderPriority(cv);
        m017_setWebAppDir(cv);
    }
    public static void f000__allowDuplicates(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/deployer/WebAppDeployer;","_allowDuplicates","Z"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f001__configurationClasses(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/deployer/WebAppDeployer;","_configurationClasses","[Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f002__contexts(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/deployer/WebAppDeployer;","_contexts","Lorg/mortbay/jetty/HandlerContainer;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f003__defaultsDescriptor(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/deployer/WebAppDeployer;","_defaultsDescriptor","Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f004__deployed(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/deployer/WebAppDeployer;","_deployed","Ljava/util/ArrayList;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f005__extract(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/deployer/WebAppDeployer;","_extract","Z"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f006__parentLoaderPriority(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/deployer/WebAppDeployer;","_parentLoaderPriority","Z"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f007__webAppDir(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/deployer/WebAppDeployer;","_webAppDir","Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void m000__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/jetty/deployer/WebAppDeployer;","<init>",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(1);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(45,L0);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Lorg/mortbay/component/AbstractLifeCycle;","<init>",new String[]{ },"V"));
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001_doStart(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/deployer/WebAppDeployer;","doStart",new String[]{ },"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/lang/Exception;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(136,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(138,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(140,L2);
                code.visitLabel(L0);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/util/ArrayList;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/util/ArrayList;","<init>",new String[]{ },"V"));
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/jetty/deployer/WebAppDeployer;","_deployed","Ljava/util/ArrayList;"));
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Lorg/mortbay/jetty/deployer/WebAppDeployer;","scan",new String[]{ },"V"));
                code.visitLabel(L2);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m002_doStop(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/deployer/WebAppDeployer;","doStop",new String[]{ },"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/lang/Exception;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(249,L0);
                DexLabel L1=new DexLabel();
                ddv.visitStartLocal(0,L1,"i","I",null);
                DexLabel L2=new DexLabel();
                ddv.visitEndLocal(0,L2);
                ddv.visitStartLocal(1,L2,"i","I",null);
                DexLabel L3=new DexLabel();
                ddv.visitRestartLocal(0,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(251,L4);
                ddv.visitEndLocal(1,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(252,L5);
                ddv.visitStartLocal(2,L5,"wac","Lorg/mortbay/jetty/handler/ContextHandler;",null);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(253,L6);
                ddv.visitRestartLocal(1,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(254,L7);
                ddv.visitEndLocal(2,L7);
                ddv.visitEndLocal(1,L7);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,3,4,new Field("Lorg/mortbay/jetty/deployer/WebAppDeployer;","_deployed","Ljava/util/ArrayList;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Ljava/util/ArrayList;","size",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitLabel(L1);
                code.visitStmt2R(MOVE,1,0);
                code.visitLabel(L2);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitStmt3R(SUB_INT,0,1,3);
                code.visitLabel(L3);
                code.visitJumpStmt(IF_LEZ,1,-1,L7);
                code.visitLabel(L4);
                code.visitFieldStmt(IGET_OBJECT,3,4,new Field("Lorg/mortbay/jetty/deployer/WebAppDeployer;","_deployed","Ljava/util/ArrayList;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,0},new Method("Ljava/util/ArrayList;","get",new String[]{ "I"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitTypeStmt(CHECK_CAST,2,-1,"Lorg/mortbay/jetty/handler/ContextHandler;");
                code.visitLabel(L5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/jetty/handler/ContextHandler;","stop",new String[]{ },"V"));
                code.visitStmt2R(MOVE,1,0);
                code.visitLabel(L6);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitLabel(L7);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m003_getAllowDuplicates(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/deployer/WebAppDeployer;","getAllowDuplicates",new String[]{ },"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(118,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_BOOLEAN,0,1,new Field("Lorg/mortbay/jetty/deployer/WebAppDeployer;","_allowDuplicates","Z"));
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m004_getConfigurationClasses(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/deployer/WebAppDeployer;","getConfigurationClasses",new String[]{ },"[Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(58,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/deployer/WebAppDeployer;","_configurationClasses","[Ljava/lang/String;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m005_getContexts(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/deployer/WebAppDeployer;","getContexts",new String[]{ },"Lorg/mortbay/jetty/HandlerContainer;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(68,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/deployer/WebAppDeployer;","_contexts","Lorg/mortbay/jetty/HandlerContainer;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m006_getDefaultsDescriptor(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/deployer/WebAppDeployer;","getDefaultsDescriptor",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(78,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/deployer/WebAppDeployer;","_defaultsDescriptor","Ljava/lang/String;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m007_getWebAppDir(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/deployer/WebAppDeployer;","getWebAppDir",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(108,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/deployer/WebAppDeployer;","_webAppDir","Ljava/lang/String;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m008_isExtract(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/deployer/WebAppDeployer;","isExtract",new String[]{ },"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(88,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_BOOLEAN,0,1,new Field("Lorg/mortbay/jetty/deployer/WebAppDeployer;","_extract","Z"));
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m009_isParentLoaderPriority(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/deployer/WebAppDeployer;","isParentLoaderPriority",new String[]{ },"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(98,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_BOOLEAN,0,1,new Field("Lorg/mortbay/jetty/deployer/WebAppDeployer;","_parentLoaderPriority","Z"));
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m010_scan(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/deployer/WebAppDeployer;","scan",new String[]{ },"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/lang/Exception;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(16);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ "Ljava/lang/Exception;"});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L3=new DexLabel();
                ddv.visitPrologue(L3);
                ddv.visitLineNumber(149,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(150,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(152,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(153,L6);
                ddv.visitStartLocal(9,L6,"r","Lorg/mortbay/resource/Resource;",null);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(154,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(156,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(157,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(159,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(161,L11);
                ddv.visitStartLocal(5,L11,"files","[Ljava/lang/String;",null);
                DexLabel L12=new DexLabel();
                ddv.visitStartLocal(4,L12,"f","I",null);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(163,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(165,L14);
                ddv.visitStartLocal(2,L14,"context","Ljava/lang/String;",null);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(161,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(168,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(170,L17);
                ddv.visitStartLocal(0,L17,"app","Lorg/mortbay/resource/Resource;",null);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(172,L18);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(173,L19);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(174,L20);
                ddv.visitStartLocal(10,L20,"unpacked","Lorg/mortbay/resource/Resource;",null);
                DexLabel L21=new DexLabel();
                ddv.visitLineNumber(180,L21);
                ddv.visitEndLocal(10,L21);
                DexLabel L22=new DexLabel();
                ddv.visitLineNumber(181,L22);
                DexLabel L23=new DexLabel();
                ddv.visitLineNumber(184,L23);
                ddv.visitRestartLocal(2,L23);
                DexLabel L24=new DexLabel();
                ddv.visitLineNumber(185,L24);
                DexLabel L25=new DexLabel();
                ddv.visitLineNumber(188,L25);
                ddv.visitRestartLocal(2,L25);
                DexLabel L26=new DexLabel();
                ddv.visitLineNumber(190,L26);
                DexLabel L27=new DexLabel();
                ddv.visitLineNumber(191,L27);
                ddv.visitStartLocal(7,L27,"installed","[Lorg/mortbay/jetty/Handler;",null);
                DexLabel L28=new DexLabel();
                ddv.visitStartLocal(6,L28,"i","I",null);
                DexLabel L29=new DexLabel();
                ddv.visitLineNumber(193,L29);
                DexLabel L30=new DexLabel();
                ddv.visitLineNumber(195,L30);
                ddv.visitStartLocal(1,L30,"c","Lorg/mortbay/jetty/handler/ContextHandler;",null);
                DexLabel L31=new DexLabel();
                ddv.visitLineNumber(199,L31);
                DexLabel L32=new DexLabel();
                ddv.visitLineNumber(200,L32);
                DexLabel L33=new DexLabel();
                ddv.visitEndLocal(1,L33);
                DexLabel L34=new DexLabel();
                ddv.visitLineNumber(204,L34);
                ddv.visitStartLocal(8,L34,"path","Ljava/lang/String;",null);
                DexLabel L35=new DexLabel();
                ddv.visitLineNumber(191,L35);
                DexLabel L36=new DexLabel();
                ddv.visitLineNumber(177,L36);
                ddv.visitEndLocal(7,L36);
                ddv.visitEndLocal(6,L36);
                ddv.visitEndLocal(8,L36);
                DexLabel L37=new DexLabel();
                ddv.visitLineNumber(183,L37);
                DexLabel L38=new DexLabel();
                ddv.visitRestartLocal(2,L38);
                DexLabel L39=new DexLabel();
                ddv.visitLineNumber(202,L39);
                ddv.visitRestartLocal(1,L39);
                ddv.visitRestartLocal(6,L39);
                ddv.visitRestartLocal(7,L39);
                DexLabel L40=new DexLabel();
                ddv.visitRestartLocal(8,L40);
                DexLabel L41=new DexLabel();
                ddv.visitEndLocal(8,L41);
                DexLabel L42=new DexLabel();
                ddv.visitLineNumber(211,L42);
                ddv.visitEndLocal(1,L42);
                ddv.visitEndLocal(6,L42);
                ddv.visitEndLocal(7,L42);
                DexLabel L43=new DexLabel();
                ddv.visitLineNumber(212,L43);
                ddv.visitStartLocal(11,L43,"wah","Lorg/mortbay/jetty/webapp/WebAppContext;",null);
                ddv.visitLineNumber(217,L0);
                DexLabel L44=new DexLabel();
                ddv.visitEndLocal(11,L44);
                ddv.visitLineNumber(230,L1);
                ddv.visitRestartLocal(11,L1);
                DexLabel L45=new DexLabel();
                ddv.visitLineNumber(231,L45);
                DexLabel L46=new DexLabel();
                ddv.visitLineNumber(232,L46);
                DexLabel L47=new DexLabel();
                ddv.visitLineNumber(233,L47);
                DexLabel L48=new DexLabel();
                ddv.visitLineNumber(234,L48);
                DexLabel L49=new DexLabel();
                ddv.visitLineNumber(235,L49);
                DexLabel L50=new DexLabel();
                ddv.visitLineNumber(236,L50);
                DexLabel L51=new DexLabel();
                ddv.visitLineNumber(237,L51);
                DexLabel L52=new DexLabel();
                ddv.visitLineNumber(239,L52);
                DexLabel L53=new DexLabel();
                ddv.visitLineNumber(240,L53);
                DexLabel L54=new DexLabel();
                ddv.visitLineNumber(242,L54);
                DexLabel L55=new DexLabel();
                ddv.visitLineNumber(243,L55);
                ddv.visitLineNumber(219,L2);
                ddv.visitEndLocal(11,L2);
                DexLabel L56=new DexLabel();
                ddv.visitLineNumber(221,L56);
                ddv.visitStartLocal(3,L56,"e","Ljava/lang/Exception;",null);
                DexLabel L57=new DexLabel();
                ddv.visitLineNumber(226,L57);
                ddv.visitEndLocal(3,L57);
                ddv.visitRestartLocal(11,L57);
                DexLabel L58=new DexLabel();
                ddv.visitEndLocal(11,L58);
                DexLabel L59=new DexLabel();
                ddv.visitRestartLocal(11,L59);
                DexLabel L60=new DexLabel();
                ddv.visitLineNumber(245,L60);
                ddv.visitEndLocal(0,L60);
                ddv.visitEndLocal(2,L60);
                ddv.visitEndLocal(11,L60);
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,12,15,new Field("Lorg/mortbay/jetty/deployer/WebAppDeployer;","_contexts","Lorg/mortbay/jetty/HandlerContainer;"));
                code.visitJumpStmt(IF_NEZ,12,-1,L5);
                code.visitLabel(L4);
                code.visitTypeStmt(NEW_INSTANCE,12,-1,"Ljava/lang/IllegalArgumentException;");
                code.visitConstStmt(CONST_STRING,13,"No HandlerContainer");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 12,13},new Method("Ljava/lang/IllegalArgumentException;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitStmt1R(THROW,12);
                code.visitLabel(L5);
                code.visitFieldStmt(IGET_OBJECT,12,15,new Field("Lorg/mortbay/jetty/deployer/WebAppDeployer;","_webAppDir","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 12},new Method("Lorg/mortbay/resource/Resource;","newResource",new String[]{ "Ljava/lang/String;"},"Lorg/mortbay/resource/Resource;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,9);
                code.visitLabel(L6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9},new Method("Lorg/mortbay/resource/Resource;","exists",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,12);
                code.visitJumpStmt(IF_NEZ,12,-1,L8);
                code.visitLabel(L7);
                code.visitTypeStmt(NEW_INSTANCE,12,-1,"Ljava/lang/IllegalArgumentException;");
                code.visitTypeStmt(NEW_INSTANCE,13,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 13},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,14,"No such webapps resource ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 13,14},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,13);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 13,9},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,13);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 13},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,13);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 12,13},new Method("Ljava/lang/IllegalArgumentException;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitStmt1R(THROW,12);
                code.visitLabel(L8);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9},new Method("Lorg/mortbay/resource/Resource;","isDirectory",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,12);
                code.visitJumpStmt(IF_NEZ,12,-1,L10);
                code.visitLabel(L9);
                code.visitTypeStmt(NEW_INSTANCE,12,-1,"Ljava/lang/IllegalArgumentException;");
                code.visitTypeStmt(NEW_INSTANCE,13,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 13},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,14,"Not directory webapps resource ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 13,14},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,13);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 13,9},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,13);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 13},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,13);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 12,13},new Method("Ljava/lang/IllegalArgumentException;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitStmt1R(THROW,12);
                code.visitLabel(L10);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9},new Method("Lorg/mortbay/resource/Resource;","list",new String[]{ },"[Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitLabel(L11);
                code.visitConstStmt(CONST_4,4, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L12);
                code.visitJumpStmt(IF_EQZ,5,-1,L60);
                code.visitStmt2R(ARRAY_LENGTH,12,5);
                code.visitJumpStmt(IF_GE,4,12,L60);
                code.visitLabel(L13);
                code.visitStmt3R(AGET_OBJECT,2,5,4);
                code.visitLabel(L14);
                code.visitConstStmt(CONST_STRING,12,"CVS/");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,12},new Method("Ljava/lang/String;","equalsIgnoreCase",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,12);
                code.visitJumpStmt(IF_NEZ,12,-1,L15);
                code.visitConstStmt(CONST_STRING,12,"CVS");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,12},new Method("Ljava/lang/String;","equalsIgnoreCase",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,12);
                code.visitJumpStmt(IF_NEZ,12,-1,L15);
                code.visitConstStmt(CONST_STRING,12,".");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,12},new Method("Ljava/lang/String;","startsWith",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,12);
                code.visitJumpStmt(IF_EQZ,12,-1,L16);
                code.visitLabel(L15);
                code.visitStmt2R1N(ADD_INT_LIT8,4,4,1);
                code.visitJumpStmt(GOTO,-1,-1,L12);
                code.visitLabel(L16);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9,2},new Method("Lorg/mortbay/resource/Resource;","encode",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,12);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9,12},new Method("Lorg/mortbay/resource/Resource;","addPath",new String[]{ "Ljava/lang/String;"},"Lorg/mortbay/resource/Resource;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L17);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Ljava/lang/String;","toLowerCase",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,12);
                code.visitConstStmt(CONST_STRING,13,".war");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 12,13},new Method("Ljava/lang/String;","endsWith",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,12);
                code.visitJumpStmt(IF_NEZ,12,-1,L18);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Ljava/lang/String;","toLowerCase",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,12);
                code.visitConstStmt(CONST_STRING,13,".jar");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 12,13},new Method("Ljava/lang/String;","endsWith",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,12);
                code.visitJumpStmt(IF_EQZ,12,-1,L36);
                code.visitLabel(L18);
                code.visitConstStmt(CONST_4,12, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Ljava/lang/String;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,13);
                code.visitConstStmt(CONST_4,14, Integer.valueOf(4)); // int: 0x00000004  float:0.000000
                code.visitStmt2R(SUB_INT_2ADDR,13,14);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,12,13},new Method("Ljava/lang/String;","substring",new String[]{ "I","I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitLabel(L19);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9,2},new Method("Lorg/mortbay/resource/Resource;","addPath",new String[]{ "Ljava/lang/String;"},"Lorg/mortbay/resource/Resource;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,10);
                code.visitLabel(L20);
                code.visitJumpStmt(IF_EQZ,10,-1,L21);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10},new Method("Lorg/mortbay/resource/Resource;","exists",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,12);
                code.visitJumpStmt(IF_EQZ,12,-1,L21);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10},new Method("Lorg/mortbay/resource/Resource;","isDirectory",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,12);
                code.visitJumpStmt(IF_NEZ,12,-1,L15);
                code.visitLabel(L21);
                code.visitConstStmt(CONST_STRING,12,"root");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,12},new Method("Ljava/lang/String;","equalsIgnoreCase",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,12);
                code.visitJumpStmt(IF_NEZ,12,-1,L22);
                code.visitConstStmt(CONST_STRING,12,"root/");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,12},new Method("Ljava/lang/String;","equalsIgnoreCase",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,12);
                code.visitJumpStmt(IF_EQZ,12,-1,L37);
                code.visitLabel(L22);
                code.visitConstStmt(CONST_STRING,2,"/");
                code.visitLabel(L23);
                code.visitConstStmt(CONST_STRING,12,"/");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,12},new Method("Ljava/lang/String;","endsWith",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,12);
                code.visitJumpStmt(IF_EQZ,12,-1,L25);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Ljava/lang/String;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,12);
                code.visitJumpStmt(IF_LEZ,12,-1,L25);
                code.visitLabel(L24);
                code.visitConstStmt(CONST_4,12, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Ljava/lang/String;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,13);
                code.visitConstStmt(CONST_4,14, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitStmt2R(SUB_INT_2ADDR,13,14);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,12,13},new Method("Ljava/lang/String;","substring",new String[]{ "I","I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitLabel(L25);
                code.visitFieldStmt(IGET_BOOLEAN,12,15,new Field("Lorg/mortbay/jetty/deployer/WebAppDeployer;","_allowDuplicates","Z"));
                code.visitJumpStmt(IF_NEZ,12,-1,L42);
                code.visitLabel(L26);
                code.visitFieldStmt(IGET_OBJECT,12,15,new Field("Lorg/mortbay/jetty/deployer/WebAppDeployer;","_contexts","Lorg/mortbay/jetty/HandlerContainer;"));
                code.visitConstStmt(CONST_CLASS,13,new DexType("Lorg/mortbay/jetty/handler/ContextHandler;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 12,13},new Method("Lorg/mortbay/jetty/HandlerContainer;","getChildHandlersByClass",new String[]{ "Ljava/lang/Class;"},"[Lorg/mortbay/jetty/Handler;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitLabel(L27);
                code.visitConstStmt(CONST_4,6, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L28);
                code.visitStmt2R(ARRAY_LENGTH,12,7);
                code.visitJumpStmt(IF_GE,6,12,L42);
                code.visitLabel(L29);
                code.visitStmt3R(AGET_OBJECT,1,7,6);
                code.visitTypeStmt(CHECK_CAST,1,-1,"Lorg/mortbay/jetty/handler/ContextHandler;");
                code.visitLabel(L30);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Lorg/mortbay/jetty/handler/ContextHandler;","getContextPath",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,12);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,12},new Method("Ljava/lang/String;","equals",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,12);
                code.visitJumpStmt(IF_NEZ,12,-1,L15);
                code.visitLabel(L31);
                code.visitTypeStmt(INSTANCE_OF,12,1,"Lorg/mortbay/jetty/webapp/WebAppContext;");
                code.visitJumpStmt(IF_EQZ,12,-1,L39);
                code.visitLabel(L32);
                code.visitTypeStmt(CHECK_CAST,1,-1,"Lorg/mortbay/jetty/webapp/WebAppContext;");
                code.visitLabel(L33);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Lorg/mortbay/jetty/webapp/WebAppContext;","getWar",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitLabel(L34);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/resource/Resource;","getFile",new String[]{ },"Ljava/io/File;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,12);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 12},new Method("Ljava/io/File;","getAbsolutePath",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,12);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8,12},new Method("Ljava/lang/String;","equals",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,12);
                code.visitJumpStmt(IF_NEZ,12,-1,L15);
                code.visitLabel(L35);
                code.visitStmt2R1N(ADD_INT_LIT8,6,6,1);
                code.visitJumpStmt(GOTO,-1,-1,L28);
                code.visitLabel(L36);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/resource/Resource;","isDirectory",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,12);
                code.visitJumpStmt(IF_NEZ,12,-1,L21);
                code.visitJumpStmt(GOTO_16,-1,-1,L15);
                code.visitLabel(L37);
                code.visitTypeStmt(NEW_INSTANCE,12,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 12},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,13,"/");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 12,13},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,12);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 12,2},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,12);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 12},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitLabel(L38);
                code.visitJumpStmt(GOTO,-1,-1,L23);
                code.visitLabel(L39);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Lorg/mortbay/jetty/handler/ContextHandler;","getBaseResource",new String[]{ },"Lorg/mortbay/resource/Resource;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,12);
                code.visitJumpStmt(IF_NEZ,12,-1,L41);
                code.visitConstStmt(CONST_STRING,12,"");
                code.visitStmt2R(MOVE_OBJECT,8,12);
                code.visitLabel(L40);
                code.visitJumpStmt(GOTO,-1,-1,L34);
                code.visitLabel(L41);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Lorg/mortbay/jetty/handler/ContextHandler;","getBaseResource",new String[]{ },"Lorg/mortbay/resource/Resource;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,12);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 12},new Method("Lorg/mortbay/resource/Resource;","getFile",new String[]{ },"Ljava/io/File;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,12);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 12},new Method("Ljava/io/File;","getAbsolutePath",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,12);
                code.visitStmt2R(MOVE_OBJECT,8,12);
                code.visitJumpStmt(GOTO,-1,-1,L40);
                code.visitLabel(L42);
                code.visitConstStmt(CONST_4,11, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L43);
                code.visitFieldStmt(IGET_OBJECT,12,15,new Field("Lorg/mortbay/jetty/deployer/WebAppDeployer;","_contexts","Lorg/mortbay/jetty/HandlerContainer;"));
                code.visitTypeStmt(INSTANCE_OF,12,12,"Lorg/mortbay/jetty/handler/ContextHandlerCollection;");
                code.visitJumpStmt(IF_EQZ,12,-1,L57);
                code.visitConstStmt(CONST_CLASS,12,new DexType("Lorg/mortbay/jetty/webapp/WebAppContext;"));
                code.visitFieldStmt(IGET_OBJECT,1,15,new Field("Lorg/mortbay/jetty/deployer/WebAppDeployer;","_contexts","Lorg/mortbay/jetty/HandlerContainer;"));
                code.visitTypeStmt(CHECK_CAST,1,-1,"Lorg/mortbay/jetty/handler/ContextHandlerCollection;");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Lorg/mortbay/jetty/handler/ContextHandlerCollection;","getContextClass",new String[]{ },"Ljava/lang/Class;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,13);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 12,13},new Method("Ljava/lang/Class;","isAssignableFrom",new String[]{ "Ljava/lang/Class;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,12);
                code.visitJumpStmt(IF_EQZ,12,-1,L57);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,1,15,new Field("Lorg/mortbay/jetty/deployer/WebAppDeployer;","_contexts","Lorg/mortbay/jetty/HandlerContainer;"));
                code.visitTypeStmt(CHECK_CAST,1,-1,"Lorg/mortbay/jetty/handler/ContextHandlerCollection;");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Lorg/mortbay/jetty/handler/ContextHandlerCollection;","getContextClass",new String[]{ },"Ljava/lang/Class;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,12);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 12},new Method("Ljava/lang/Class;","newInstance",new String[]{ },"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,11);
                code.visitLabel(L44);
                code.visitTypeStmt(CHECK_CAST,11,-1,"Lorg/mortbay/jetty/webapp/WebAppContext;");
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 11,2},new Method("Lorg/mortbay/jetty/webapp/WebAppContext;","setContextPath",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L45);
                code.visitFieldStmt(IGET_OBJECT,12,15,new Field("Lorg/mortbay/jetty/deployer/WebAppDeployer;","_configurationClasses","[Ljava/lang/String;"));
                code.visitJumpStmt(IF_EQZ,12,-1,L47);
                code.visitLabel(L46);
                code.visitFieldStmt(IGET_OBJECT,12,15,new Field("Lorg/mortbay/jetty/deployer/WebAppDeployer;","_configurationClasses","[Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 11,12},new Method("Lorg/mortbay/jetty/webapp/WebAppContext;","setConfigurationClasses",new String[]{ "[Ljava/lang/String;"},"V"));
                code.visitLabel(L47);
                code.visitFieldStmt(IGET_OBJECT,12,15,new Field("Lorg/mortbay/jetty/deployer/WebAppDeployer;","_defaultsDescriptor","Ljava/lang/String;"));
                code.visitJumpStmt(IF_EQZ,12,-1,L49);
                code.visitLabel(L48);
                code.visitFieldStmt(IGET_OBJECT,12,15,new Field("Lorg/mortbay/jetty/deployer/WebAppDeployer;","_defaultsDescriptor","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 11,12},new Method("Lorg/mortbay/jetty/webapp/WebAppContext;","setDefaultsDescriptor",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L49);
                code.visitFieldStmt(IGET_BOOLEAN,12,15,new Field("Lorg/mortbay/jetty/deployer/WebAppDeployer;","_extract","Z"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 11,12},new Method("Lorg/mortbay/jetty/webapp/WebAppContext;","setExtractWAR",new String[]{ "Z"},"V"));
                code.visitLabel(L50);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/lang/Object;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,12);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 11,12},new Method("Lorg/mortbay/jetty/webapp/WebAppContext;","setWar",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L51);
                code.visitFieldStmt(IGET_BOOLEAN,12,15,new Field("Lorg/mortbay/jetty/deployer/WebAppDeployer;","_parentLoaderPriority","Z"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 11,12},new Method("Lorg/mortbay/jetty/webapp/WebAppContext;","setParentLoaderPriority",new String[]{ "Z"},"V"));
                code.visitLabel(L52);
                code.visitFieldStmt(IGET_OBJECT,12,15,new Field("Lorg/mortbay/jetty/deployer/WebAppDeployer;","_contexts","Lorg/mortbay/jetty/HandlerContainer;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 12,11},new Method("Lorg/mortbay/jetty/HandlerContainer;","addHandler",new String[]{ "Lorg/mortbay/jetty/Handler;"},"V"));
                code.visitLabel(L53);
                code.visitFieldStmt(IGET_OBJECT,12,15,new Field("Lorg/mortbay/jetty/deployer/WebAppDeployer;","_deployed","Ljava/util/ArrayList;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 12,11},new Method("Ljava/util/ArrayList;","add",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitLabel(L54);
                code.visitFieldStmt(IGET_OBJECT,12,15,new Field("Lorg/mortbay/jetty/deployer/WebAppDeployer;","_contexts","Lorg/mortbay/jetty/HandlerContainer;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 12},new Method("Lorg/mortbay/jetty/HandlerContainer;","isStarted",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,12);
                code.visitJumpStmt(IF_EQZ,12,-1,L15);
                code.visitLabel(L55);
                code.visitFieldStmt(IGET_OBJECT,12,15,new Field("Lorg/mortbay/jetty/deployer/WebAppDeployer;","_contexts","Lorg/mortbay/jetty/HandlerContainer;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 12},new Method("Lorg/mortbay/jetty/HandlerContainer;","start",new String[]{ },"V"));
                code.visitJumpStmt(GOTO_16,-1,-1,L15);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,12);
                code.visitStmt2R(MOVE_OBJECT,3,12);
                code.visitLabel(L56);
                code.visitTypeStmt(NEW_INSTANCE,12,-1,"Ljava/lang/Error;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 12,3},new Method("Ljava/lang/Error;","<init>",new String[]{ "Ljava/lang/Throwable;"},"V"));
                code.visitStmt1R(THROW,12);
                code.visitLabel(L57);
                code.visitTypeStmt(NEW_INSTANCE,11,-1,"Lorg/mortbay/jetty/webapp/WebAppContext;");
                code.visitLabel(L58);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 11},new Method("Lorg/mortbay/jetty/webapp/WebAppContext;","<init>",new String[]{ },"V"));
                code.visitLabel(L59);
                code.visitJumpStmt(GOTO,-1,-1,L1);
                code.visitLabel(L60);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m011_setAllowDuplicates(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/deployer/WebAppDeployer;","setAllowDuplicates",new String[]{ "Z"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"allowDuplicates");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(127,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(128,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_BOOLEAN,1,0,new Field("Lorg/mortbay/jetty/deployer/WebAppDeployer;","_allowDuplicates","Z"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m012_setConfigurationClasses(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/deployer/WebAppDeployer;","setConfigurationClasses",new String[]{ "[Ljava/lang/String;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"configurationClasses");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(63,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(64,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_OBJECT,1,0,new Field("Lorg/mortbay/jetty/deployer/WebAppDeployer;","_configurationClasses","[Ljava/lang/String;"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m013_setContexts(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/deployer/WebAppDeployer;","setContexts",new String[]{ "Lorg/mortbay/jetty/HandlerContainer;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"contexts");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(73,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(74,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_OBJECT,1,0,new Field("Lorg/mortbay/jetty/deployer/WebAppDeployer;","_contexts","Lorg/mortbay/jetty/HandlerContainer;"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m014_setDefaultsDescriptor(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/deployer/WebAppDeployer;","setDefaultsDescriptor",new String[]{ "Ljava/lang/String;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"defaultsDescriptor");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(83,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(84,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_OBJECT,1,0,new Field("Lorg/mortbay/jetty/deployer/WebAppDeployer;","_defaultsDescriptor","Ljava/lang/String;"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m015_setExtract(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/deployer/WebAppDeployer;","setExtract",new String[]{ "Z"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"extract");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(93,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(94,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_BOOLEAN,1,0,new Field("Lorg/mortbay/jetty/deployer/WebAppDeployer;","_extract","Z"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m016_setParentLoaderPriority(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/deployer/WebAppDeployer;","setParentLoaderPriority",new String[]{ "Z"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"parentPriorityClassLoading");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(103,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(104,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_BOOLEAN,1,0,new Field("Lorg/mortbay/jetty/deployer/WebAppDeployer;","_parentLoaderPriority","Z"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m017_setWebAppDir(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/deployer/WebAppDeployer;","setWebAppDir",new String[]{ "Ljava/lang/String;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"dir");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(113,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(114,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_OBJECT,1,0,new Field("Lorg/mortbay/jetty/deployer/WebAppDeployer;","_webAppDir","Ljava/lang/String;"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
