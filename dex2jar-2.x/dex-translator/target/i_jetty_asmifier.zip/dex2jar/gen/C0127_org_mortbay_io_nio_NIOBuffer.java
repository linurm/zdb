package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0127_org_mortbay_io_nio_NIOBuffer {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(ACC_PUBLIC|ACC_INTERFACE|ACC_ABSTRACT,"Lorg/mortbay/io/nio/NIOBuffer;","Ljava/lang/Object;",new String[]{ "Lorg/mortbay/io/Buffer;"});
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("NIOBuffer.java");
        m000_getByteBuffer(cv);
        m001_isDirect(cv);
    }
    public static void m000_getByteBuffer(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Lorg/mortbay/io/nio/NIOBuffer;","getByteBuffer",new String[]{ },"Ljava/nio/ByteBuffer;"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
    public static void m001_isDirect(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Lorg/mortbay/io/nio/NIOBuffer;","isDirect",new String[]{ },"Z"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
}
