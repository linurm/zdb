package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0284_org_mortbay_jetty_security_SecurityHandler {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(ACC_PUBLIC,"Lorg/mortbay/jetty/security/SecurityHandler;","Lorg/mortbay/jetty/handler/HandlerWrapper;",new String[]{ });
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("SecurityHandler.java");
        if(cv!=null){
            DexAnnotationVisitor av00 = cv.visitAnnotation("Ldalvik/annotation/MemberClasses;", Visibility.SYSTEM);
            if(av00 != null) {
                {
                    DexAnnotationVisitor av01 = av00.visitArray("value");
                    if(av01 != null) {
                        av01.visit(null, new DexType("Lorg/mortbay/jetty/security/SecurityHandler$NotChecked;"));
                        av01.visitEnd();
                    }
                }
                av00.visitEnd();
            }
        }
        f000___NOBODY(cv);
        f001___NO_USER(cv);
        f002__authMethod(cv);
        f003__authenticator(cv);
        f004__checkWelcomeFiles(cv);
        f005__constraintMap(cv);
        f006__constraintMappings(cv);
        f007__notChecked(cv);
        f008__userRealm(cv);
        m000__clinit_(cv);
        m001__init_(cv);
        m002_check(cv);
        m003_checkSecurityConstraints(cv);
        m004_doStart(cv);
        m005_getAuthMethod(cv);
        m006_getAuthenticator(cv);
        m007_getConstraintMappings(cv);
        m008_getUserRealm(cv);
        m009_handle(cv);
        m010_hasConstraints(cv);
        m011_isCheckWelcomeFiles(cv);
        m012_setAuthMethod(cv);
        m013_setAuthenticator(cv);
        m014_setCheckWelcomeFiles(cv);
        m015_setConstraintMappings(cv);
        m016_setUserRealm(cv);
    }
    public static void f000___NOBODY(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC, new Field("Lorg/mortbay/jetty/security/SecurityHandler;","__NOBODY","Ljava/security/Principal;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f001___NO_USER(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PUBLIC|ACC_STATIC, new Field("Lorg/mortbay/jetty/security/SecurityHandler;","__NO_USER","Ljava/security/Principal;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f002__authMethod(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/security/SecurityHandler;","_authMethod","Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f003__authenticator(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/security/SecurityHandler;","_authenticator","Lorg/mortbay/jetty/security/Authenticator;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f004__checkWelcomeFiles(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/security/SecurityHandler;","_checkWelcomeFiles","Z"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f005__constraintMap(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/security/SecurityHandler;","_constraintMap","Lorg/mortbay/jetty/servlet/PathMap;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f006__constraintMappings(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/security/SecurityHandler;","_constraintMappings","[Lorg/mortbay/jetty/security/ConstraintMapping;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f007__notChecked(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/security/SecurityHandler;","_notChecked","Lorg/mortbay/jetty/security/SecurityHandler$NotChecked;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f008__userRealm(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/security/SecurityHandler;","_userRealm","Lorg/mortbay/jetty/security/UserRealm;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void m000__clinit_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_STATIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/jetty/security/SecurityHandler;","<clinit>",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(1);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(487,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(526,L1);
                code.visitLabel(L0);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Lorg/mortbay/jetty/security/SecurityHandler$1;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Lorg/mortbay/jetty/security/SecurityHandler$1;","<init>",new String[]{ },"V"));
                code.visitFieldStmt(SPUT_OBJECT,0,-1,new Field("Lorg/mortbay/jetty/security/SecurityHandler;","__NO_USER","Ljava/security/Principal;"));
                code.visitLabel(L1);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Lorg/mortbay/jetty/security/SecurityHandler$2;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Lorg/mortbay/jetty/security/SecurityHandler$2;","<init>",new String[]{ },"V"));
                code.visitFieldStmt(SPUT_OBJECT,0,-1,new Field("Lorg/mortbay/jetty/security/SecurityHandler;","__NOBODY","Ljava/security/Principal;"));
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/jetty/security/SecurityHandler;","<init>",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(41,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(44,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(47,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(49,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(50,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(513,L5);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1},new Method("Lorg/mortbay/jetty/handler/HandlerWrapper;","<init>",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitConstStmt(CONST_STRING,0,"BASIC");
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/jetty/security/SecurityHandler;","_authMethod","Ljava/lang/String;"));
                code.visitLabel(L2);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Lorg/mortbay/jetty/servlet/PathMap;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Lorg/mortbay/jetty/servlet/PathMap;","<init>",new String[]{ },"V"));
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/jetty/security/SecurityHandler;","_constraintMap","Lorg/mortbay/jetty/servlet/PathMap;"));
                code.visitLabel(L3);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Lorg/mortbay/jetty/security/SecurityHandler$NotChecked;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1},new Method("Lorg/mortbay/jetty/security/SecurityHandler$NotChecked;","<init>",new String[]{ "Lorg/mortbay/jetty/security/SecurityHandler;"},"V"));
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/jetty/security/SecurityHandler;","_notChecked","Lorg/mortbay/jetty/security/SecurityHandler$NotChecked;"));
                code.visitLabel(L4);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT_BOOLEAN,0,1,new Field("Lorg/mortbay/jetty/security/SecurityHandler;","_checkWelcomeFiles","Z"));
                code.visitLabel(L5);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m002_check(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PRIVATE, new Method("Lorg/mortbay/jetty/security/SecurityHandler;","check",new String[]{ "Ljava/lang/Object;","Lorg/mortbay/jetty/security/Authenticator;","Lorg/mortbay/jetty/security/UserRealm;","Ljava/lang/String;","Lorg/mortbay/jetty/Request;","Lorg/mortbay/jetty/Response;"},"Z"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(28);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"constraints");
                ddv.visitParameterName(1,"authenticator");
                ddv.visitParameterName(2,"realm");
                ddv.visitParameterName(3,"pathInContext");
                ddv.visitParameterName(4,"request");
                ddv.visitParameterName(5,"response");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(298,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(299,L1);
                ddv.visitStartLocal(7,L1,"dataConstraint","I",null);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(300,L2);
                ddv.visitStartLocal(12,L2,"roles","Ljava/lang/Object;",null);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(301,L3);
                ddv.visitStartLocal(15,L3,"unauthenticated","Z",null);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(303,L4);
                ddv.visitStartLocal(8,L4,"forbidden","Z",null);
                DexLabel L5=new DexLabel();
                ddv.visitStartLocal(4,L5,"c","I",null);
                DexLabel L6=new DexLabel();
                ddv.visitEndLocal(12,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(305,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(308,L8);
                ddv.visitStartLocal(13,L8,"sc","Lorg/mortbay/jetty/security/Constraint;",null);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(310,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(311,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(317,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(319,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(321,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(323,L14);
                DexLabel L15=new DexLabel();
                ddv.visitStartLocal(12,L15,"roles","Ljava/lang/String;",null);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(303,L16);
                ddv.visitEndLocal(12,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(314,L17);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(327,L18);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(328,L19);
                ddv.visitStartLocal(14,L19,"scr","[Ljava/lang/String;",null);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(330,L20);
                DexLabel L21=new DexLabel();
                ddv.visitLineNumber(350,L21);
                ddv.visitEndLocal(13,L21);
                ddv.visitEndLocal(14,L21);
                DexLabel L22=new DexLabel();
                ddv.visitEndLocal(4,L22);
                DexLabel L23=new DexLabel();
                ddv.visitLineNumber(355,L23);
                DexLabel L24=new DexLabel();
                ddv.visitLineNumber(356,L24);
                DexLabel L25=new DexLabel();
                ddv.visitLineNumber(484,L25);
                ddv.visitEndLocal(21,L25);
                DexLabel L26=new DexLabel();
                ddv.visitLineNumber(336,L26);
                ddv.visitRestartLocal(4,L26);
                ddv.visitRestartLocal(13,L26);
                ddv.visitRestartLocal(14,L26);
                ddv.visitRestartLocal(21,L26);
                DexLabel L27=new DexLabel();
                ddv.visitLineNumber(338,L27);
                DexLabel L28=new DexLabel();
                ddv.visitStartLocal(10,L28,"r","I",null);
                DexLabel L29=new DexLabel();
                ddv.visitEndLocal(10,L29);
                ddv.visitStartLocal(11,L29,"r","I",null);
                DexLabel L30=new DexLabel();
                ddv.visitRestartLocal(10,L30);
                DexLabel L31=new DexLabel();
                ddv.visitLineNumber(339,L31);
                ddv.visitEndLocal(11,L31);
                DexLabel L32=new DexLabel();
                ddv.visitStartLocal(12,L32,"roles","Ljava/lang/Object;",null);
                DexLabel L33=new DexLabel();
                ddv.visitRestartLocal(11,L33);
                DexLabel L34=new DexLabel();
                ddv.visitLineNumber(345,L34);
                ddv.visitEndLocal(14,L34);
                ddv.visitEndLocal(10,L34);
                ddv.visitEndLocal(12,L34);
                ddv.visitEndLocal(11,L34);
                DexLabel L35=new DexLabel();
                ddv.visitLineNumber(360,L35);
                ddv.visitEndLocal(4,L35);
                ddv.visitEndLocal(13,L35);
                DexLabel L36=new DexLabel();
                ddv.visitLineNumber(362,L36);
                DexLabel L37=new DexLabel();
                ddv.visitLineNumber(363,L37);
                ddv.visitStartLocal(5,L37,"connection","Lorg/mortbay/jetty/HttpConnection;",null);
                DexLabel L38=new DexLabel();
                ddv.visitLineNumber(365,L38);
                ddv.visitStartLocal(6,L38,"connector","Lorg/mortbay/jetty/Connector;",null);
                DexLabel L39=new DexLabel();
                ddv.visitLineNumber(411,L39);
                DexLabel L40=new DexLabel();
                ddv.visitLineNumber(412,L40);
                DexLabel L41=new DexLabel();
                ddv.visitLineNumber(368,L41);
                DexLabel L42=new DexLabel();
                ddv.visitLineNumber(417,L42);
                ddv.visitEndLocal(5,L42);
                ddv.visitEndLocal(6,L42);
                DexLabel L43=new DexLabel();
                ddv.visitLineNumber(419,L43);
                DexLabel L44=new DexLabel();
                ddv.visitLineNumber(421,L44);
                DexLabel L45=new DexLabel();
                ddv.visitLineNumber(422,L45);
                DexLabel L46=new DexLabel();
                ddv.visitLineNumber(423,L46);
                DexLabel L47=new DexLabel();
                ddv.visitLineNumber(370,L47);
                ddv.visitRestartLocal(5,L47);
                ddv.visitRestartLocal(6,L47);
                DexLabel L48=new DexLabel();
                ddv.visitLineNumber(372,L48);
                DexLabel L49=new DexLabel();
                ddv.visitLineNumber(379,L49);
                ddv.visitStartLocal(16,L49,"url","Ljava/lang/String;",null);
                DexLabel L50=new DexLabel();
                ddv.visitLineNumber(380,L50);
                DexLabel L51=new DexLabel();
                ddv.visitLineNumber(381,L51);
                DexLabel L52=new DexLabel();
                ddv.visitLineNumber(382,L52);
                DexLabel L53=new DexLabel();
                ddv.visitLineNumber(386,L53);
                ddv.visitEndLocal(16,L53);
                DexLabel L54=new DexLabel();
                ddv.visitLineNumber(385,L54);
                DexLabel L55=new DexLabel();
                ddv.visitLineNumber(388,L55);
                DexLabel L56=new DexLabel();
                ddv.visitLineNumber(391,L56);
                DexLabel L57=new DexLabel();
                ddv.visitLineNumber(393,L57);
                DexLabel L58=new DexLabel();
                ddv.visitLineNumber(400,L58);
                ddv.visitRestartLocal(16,L58);
                DexLabel L59=new DexLabel();
                ddv.visitLineNumber(401,L59);
                DexLabel L60=new DexLabel();
                ddv.visitLineNumber(403,L60);
                ddv.visitRestartLocal(16,L60);
                DexLabel L61=new DexLabel();
                ddv.visitLineNumber(404,L61);
                DexLabel L62=new DexLabel();
                ddv.visitLineNumber(408,L62);
                ddv.visitEndLocal(16,L62);
                DexLabel L63=new DexLabel();
                ddv.visitLineNumber(407,L63);
                DexLabel L64=new DexLabel();
                ddv.visitLineNumber(426,L64);
                ddv.visitEndLocal(5,L64);
                ddv.visitEndLocal(6,L64);
                DexLabel L65=new DexLabel();
                ddv.visitLineNumber(429,L65);
                ddv.visitStartLocal(17,L65,"user","Ljava/security/Principal;",null);
                DexLabel L66=new DexLabel();
                ddv.visitLineNumber(432,L66);
                DexLabel L67=new DexLabel();
                ddv.visitLineNumber(433,L67);
                DexLabel L68=new DexLabel();
                ddv.visitLineNumber(434,L68);
                DexLabel L69=new DexLabel();
                ddv.visitLineNumber(435,L69);
                ddv.visitRestartLocal(17,L69);
                DexLabel L70=new DexLabel();
                ddv.visitLineNumber(436,L70);
                DexLabel L71=new DexLabel();
                ddv.visitLineNumber(451,L71);
                ddv.visitRestartLocal(17,L71);
                DexLabel L72=new DexLabel();
                ddv.visitLineNumber(452,L72);
                DexLabel L73=new DexLabel();
                ddv.visitLineNumber(438,L73);
                DexLabel L74=new DexLabel();
                ddv.visitLineNumber(441,L74);
                DexLabel L75=new DexLabel();
                ddv.visitRestartLocal(17,L75);
                DexLabel L76=new DexLabel();
                ddv.visitLineNumber(446,L76);
                DexLabel L77=new DexLabel();
                ddv.visitLineNumber(447,L77);
                DexLabel L78=new DexLabel();
                ddv.visitLineNumber(453,L78);
                DexLabel L79=new DexLabel();
                ddv.visitLineNumber(454,L79);
                DexLabel L80=new DexLabel();
                ddv.visitLineNumber(456,L80);
                DexLabel L81=new DexLabel();
                ddv.visitLineNumber(458,L81);
                DexLabel L82=new DexLabel();
                ddv.visitLineNumber(459,L82);
                ddv.visitStartLocal(9,L82,"inRole","Z",null);
                DexLabel L83=new DexLabel();
                ddv.visitRestartLocal(10,L83);
                DexLabel L84=new DexLabel();
                ddv.visitEndLocal(21,L84);
                ddv.visitEndLocal(10,L84);
                ddv.visitRestartLocal(11,L84);
                DexLabel L85=new DexLabel();
                ddv.visitRestartLocal(10,L85);
                DexLabel L86=new DexLabel();
                ddv.visitLineNumber(461,L86);
                ddv.visitEndLocal(11,L86);
                DexLabel L87=new DexLabel();
                ddv.visitLineNumber(463,L87);
                DexLabel L88=new DexLabel();
                ddv.visitLineNumber(468,L88);
                DexLabel L89=new DexLabel();
                ddv.visitLineNumber(470,L89);
                DexLabel L90=new DexLabel();
                ddv.visitLineNumber(474,L90);
                DexLabel L91=new DexLabel();
                ddv.visitLineNumber(475,L91);
                DexLabel L92=new DexLabel();
                ddv.visitLineNumber(481,L92);
                ddv.visitEndLocal(17,L92);
                ddv.visitEndLocal(9,L92);
                ddv.visitEndLocal(10,L92);
                ddv.visitRestartLocal(21,L92);
                DexLabel L93=new DexLabel();
                ddv.visitLineNumber(484,L93);
                ddv.visitEndLocal(21,L93);
                DexLabel L94=new DexLabel();
                ddv.visitRestartLocal(9,L94);
                ddv.visitRestartLocal(10,L94);
                ddv.visitRestartLocal(17,L94);
                DexLabel L95=new DexLabel();
                ddv.visitRestartLocal(11,L95);
                DexLabel L96=new DexLabel();
                ddv.visitLineNumber(365,L96);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,7, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,12, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L2);
                code.visitConstStmt(CONST_4,15, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L3);
                code.visitConstStmt(CONST_4,8, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L4);
                code.visitConstStmt(CONST_4,4, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L5);
                code.visitStmt2R(MOVE_OBJECT_FROM16,18,12);
                code.visitLabel(L6);
                code.visitMethodStmt(INVOKE_STATIC_RANGE,new int[]{ 22},new Method("Lorg/mortbay/util/LazyList;","size",new String[]{ "Ljava/lang/Object;"},"I"));
                code.visitStmt1R(MOVE_RESULT,19);
                code.visitStmt2R(MOVE,0,4);
                code.visitStmt2R(MOVE_FROM16,1,19);
                code.visitJumpStmt(IF_GE,0,1,L21);
                code.visitLabel(L7);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,22);
                code.visitStmt2R(MOVE,1,4);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0,1},new Method("Lorg/mortbay/util/LazyList;","get",new String[]{ "Ljava/lang/Object;","I"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,13);
                code.visitTypeStmt(CHECK_CAST,13,-1,"Lorg/mortbay/jetty/security/Constraint;");
                code.visitLabel(L8);
                code.visitConstStmt(CONST_16,19, Integer.valueOf(-1)); // int: 0xffffffff  float:NaN
                code.visitStmt2R(MOVE,0,7);
                code.visitStmt2R(MOVE_FROM16,1,19);
                code.visitJumpStmt(IF_LE,0,1,L17);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 13},new Method("Lorg/mortbay/jetty/security/Constraint;","hasDataConstraint",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,19);
                code.visitJumpStmt(IF_EQZ,19,-1,L17);
                code.visitLabel(L9);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 13},new Method("Lorg/mortbay/jetty/security/Constraint;","getDataConstraint",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,19);
                code.visitStmt2R(MOVE_FROM16,0,19);
                code.visitStmt2R(MOVE,1,7);
                code.visitJumpStmt(IF_LE,0,1,L11);
                code.visitLabel(L10);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 13},new Method("Lorg/mortbay/jetty/security/Constraint;","getDataConstraint",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,7);
                code.visitLabel(L11);
                code.visitJumpStmt(IF_NEZ,15,-1,L16);
                code.visitJumpStmt(IF_NEZ,8,-1,L16);
                code.visitLabel(L12);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 13},new Method("Lorg/mortbay/jetty/security/Constraint;","getAuthenticate",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,19);
                code.visitJumpStmt(IF_EQZ,19,-1,L34);
                code.visitLabel(L13);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 13},new Method("Lorg/mortbay/jetty/security/Constraint;","isAnyRole",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,19);
                code.visitJumpStmt(IF_EQZ,19,-1,L18);
                code.visitLabel(L14);
                code.visitConstStmt(CONST_STRING,12,"*");
                code.visitLabel(L15);
                code.visitStmt2R(MOVE_OBJECT_FROM16,18,12);
                code.visitLabel(L16);
                code.visitStmt2R1N(ADD_INT_LIT8,4,4,1);
                code.visitJumpStmt(GOTO,-1,-1,L6);
                code.visitLabel(L17);
                code.visitConstStmt(CONST_4,7, Integer.valueOf(-1)); // int: 0xffffffff  float:NaN
                code.visitJumpStmt(GOTO,-1,-1,L11);
                code.visitLabel(L18);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 13},new Method("Lorg/mortbay/jetty/security/Constraint;","getRoles",new String[]{ },"[Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,14);
                code.visitLabel(L19);
                code.visitJumpStmt(IF_EQZ,14,-1,L20);
                code.visitStmt2R(MOVE_OBJECT,0,14);
                code.visitStmt2R(ARRAY_LENGTH,0,0);
                code.visitStmt2R(MOVE_FROM16,19,0);
                code.visitJumpStmt(IF_NEZ,19,-1,L26);
                code.visitLabel(L20);
                code.visitConstStmt(CONST_4,8, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitLabel(L21);
                code.visitJumpStmt(IF_EQZ,8,-1,L35);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,23);
                code.visitTypeStmt(INSTANCE_OF,0,0,"Lorg/mortbay/jetty/security/FormAuthenticator;");
                code.visitStmt2R(MOVE_FROM16,19,0);
                code.visitJumpStmt(IF_EQZ,19,-1,L23);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,23);
                code.visitTypeStmt(CHECK_CAST,0,-1,"Lorg/mortbay/jetty/security/FormAuthenticator;");
                code.visitStmt2R(MOVE_OBJECT,4,0);
                code.visitLabel(L22);
                code.visitStmt2R(MOVE_OBJECT,0,4);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,25);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Lorg/mortbay/jetty/security/FormAuthenticator;","isLoginOrErrorPage",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,19);
                code.visitJumpStmt(IF_NEZ,19,-1,L35);
                code.visitLabel(L23);
                code.visitConstStmt(CONST_16,18, Integer.valueOf(403)); // int: 0x00000193  float:0.000000
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitStmt2R(MOVE_FROM16,1,18);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Lorg/mortbay/jetty/Response;","sendError",new String[]{ "I"},"V"));
                code.visitLabel(L24);
                code.visitConstStmt(CONST_16,18, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L25);
                code.visitStmt1R(RETURN,18);
                code.visitLabel(L26);
                code.visitConstStmt(CONST_STRING,19,"*");
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,18);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,19);
                code.visitJumpStmt(IF_EQ,0,1,L16);
                code.visitLabel(L27);
                code.visitStmt2R(ARRAY_LENGTH,10,14);
                code.visitLabel(L28);
                code.visitStmt2R(MOVE,11,10);
                code.visitLabel(L29);
                code.visitConstStmt(CONST_16,19, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitStmt3R(SUB_INT,10,11,19);
                code.visitLabel(L30);
                code.visitJumpStmt(IF_LEZ,11,-1,L16);
                code.visitLabel(L31);
                code.visitStmt3R(AGET_OBJECT,19,14,10);
                code.visitMethodStmt(INVOKE_STATIC_RANGE,new int[]{ 18,19},new Method("Lorg/mortbay/util/LazyList;","add",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,12);
                code.visitLabel(L32);
                code.visitStmt2R(MOVE,11,10);
                code.visitLabel(L33);
                code.visitStmt2R(MOVE_OBJECT_FROM16,18,12);
                code.visitJumpStmt(GOTO,-1,-1,L29);
                code.visitLabel(L34);
                code.visitConstStmt(CONST_4,15, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L16);
                code.visitLabel(L35);
                code.visitJumpStmt(IF_LEZ,7,-1,L42);
                code.visitLabel(L36);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Lorg/mortbay/jetty/HttpConnection;","getCurrentConnection",new String[]{ },"Lorg/mortbay/jetty/HttpConnection;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitLabel(L37);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Lorg/mortbay/jetty/HttpConnection;","getConnector",new String[]{ },"Lorg/mortbay/jetty/Connector;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitLabel(L38);
                code.visitSparseSwitchStmt(PACKED_SWITCH,7,1,new DexLabel[]{L41,L55});
                code.visitLabel(L39);
                code.visitConstStmt(CONST_16,18, Integer.valueOf(403)); // int: 0x00000193  float:0.000000
                code.visitConstStmt(CONST_16,19, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitStmt2R(MOVE_FROM16,1,18);
                code.visitStmt2R(MOVE_OBJECT_FROM16,2,19);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1,2},new Method("Lorg/mortbay/jetty/Response;","sendError",new String[]{ "I","Ljava/lang/String;"},"V"));
                code.visitLabel(L40);
                code.visitConstStmt(CONST_16,18, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L25);
                code.visitLabel(L41);
                code.visitStmt2R(MOVE_OBJECT,0,6);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,26);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,1},new Method("Lorg/mortbay/jetty/Connector;","isIntegral",new String[]{ "Lorg/mortbay/jetty/Request;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,19);
                code.visitJumpStmt(IF_EQZ,19,-1,L47);
                code.visitLabel(L42);
                code.visitJumpStmt(IF_NEZ,15,-1,L92);
                code.visitJumpStmt(IF_EQZ,18,-1,L92);
                code.visitLabel(L43);
                code.visitJumpStmt(IF_NEZ,24,-1,L64);
                code.visitLabel(L44);
                code.visitTypeStmt(NEW_INSTANCE,18,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT_RANGE,new int[]{ 18},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,19,"Request ");
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 18,19},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,18);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 26},new Method("Lorg/mortbay/jetty/Request;","getRequestURI",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,19);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 18,19},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,18);
                code.visitConstStmt(CONST_STRING,19," failed - no realm");
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 18,19},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,18);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 18},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,18);
                code.visitMethodStmt(INVOKE_STATIC_RANGE,new int[]{ 18},new Method("Lorg/mortbay/log/Log;","warn",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L45);
                code.visitConstStmt(CONST_16,18, Integer.valueOf(500)); // int: 0x000001f4  float:0.000000
                code.visitConstStmt(CONST_STRING,19,"No realm");
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitStmt2R(MOVE_FROM16,1,18);
                code.visitStmt2R(MOVE_OBJECT_FROM16,2,19);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1,2},new Method("Lorg/mortbay/jetty/Response;","sendError",new String[]{ "I","Ljava/lang/String;"},"V"));
                code.visitLabel(L46);
                code.visitConstStmt(CONST_16,18, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L25);
                code.visitLabel(L47);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 6},new Method("Lorg/mortbay/jetty/Connector;","getConfidentialPort",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,18);
                code.visitJumpStmt(IF_LEZ,18,-1,L54);
                code.visitLabel(L48);
                code.visitTypeStmt(NEW_INSTANCE,18,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT_RANGE,new int[]{ 18},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 6},new Method("Lorg/mortbay/jetty/Connector;","getIntegralScheme",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,19);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 18,19},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,18);
                code.visitConstStmt(CONST_STRING,19,"://");
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 18,19},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,18);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 26},new Method("Lorg/mortbay/jetty/Request;","getServerName",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,19);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 18,19},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,18);
                code.visitConstStmt(CONST_STRING,19,":");
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 18,19},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,18);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 6},new Method("Lorg/mortbay/jetty/Connector;","getIntegralPort",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,19);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 18,19},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "I"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,18);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 26},new Method("Lorg/mortbay/jetty/Request;","getRequestURI",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,19);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 18,19},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,18);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 18},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,16);
                code.visitLabel(L49);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 26},new Method("Lorg/mortbay/jetty/Request;","getQueryString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,18);
                code.visitJumpStmt(IF_EQZ,18,-1,L51);
                code.visitLabel(L50);
                code.visitTypeStmt(NEW_INSTANCE,18,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT_RANGE,new int[]{ 18},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,18);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,16);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,18);
                code.visitConstStmt(CONST_STRING,19,"?");
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 18,19},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,18);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 26},new Method("Lorg/mortbay/jetty/Request;","getQueryString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,19);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 18,19},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,18);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 18},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,16);
                code.visitLabel(L51);
                code.visitConstStmt(CONST_16,18, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitStmt2R(MOVE_FROM16,1,18);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Lorg/mortbay/jetty/Response;","setContentLength",new String[]{ "I"},"V"));
                code.visitLabel(L52);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,16);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Lorg/mortbay/jetty/Response;","sendRedirect",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L53);
                code.visitConstStmt(CONST_16,18, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitJumpStmt(GOTO_16,-1,-1,L25);
                code.visitLabel(L54);
                code.visitConstStmt(CONST_16,18, Integer.valueOf(403)); // int: 0x00000193  float:0.000000
                code.visitConstStmt(CONST_16,19, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitStmt2R(MOVE_FROM16,1,18);
                code.visitStmt2R(MOVE_OBJECT_FROM16,2,19);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1,2},new Method("Lorg/mortbay/jetty/Response;","sendError",new String[]{ "I","Ljava/lang/String;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L53);
                code.visitLabel(L55);
                code.visitStmt2R(MOVE_OBJECT,0,6);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,26);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,1},new Method("Lorg/mortbay/jetty/Connector;","isConfidential",new String[]{ "Lorg/mortbay/jetty/Request;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,19);
                code.visitJumpStmt(IF_NEZ,19,-1,L42);
                code.visitLabel(L56);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 6},new Method("Lorg/mortbay/jetty/Connector;","getConfidentialPort",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,18);
                code.visitJumpStmt(IF_LEZ,18,-1,L63);
                code.visitLabel(L57);
                code.visitTypeStmt(NEW_INSTANCE,18,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT_RANGE,new int[]{ 18},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 6},new Method("Lorg/mortbay/jetty/Connector;","getConfidentialScheme",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,19);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 18,19},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,18);
                code.visitConstStmt(CONST_STRING,19,"://");
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 18,19},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,18);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 26},new Method("Lorg/mortbay/jetty/Request;","getServerName",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,19);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 18,19},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,18);
                code.visitConstStmt(CONST_STRING,19,":");
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 18,19},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,18);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 6},new Method("Lorg/mortbay/jetty/Connector;","getConfidentialPort",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,19);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 18,19},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "I"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,18);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 26},new Method("Lorg/mortbay/jetty/Request;","getRequestURI",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,19);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 18,19},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,18);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 18},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,16);
                code.visitLabel(L58);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 26},new Method("Lorg/mortbay/jetty/Request;","getQueryString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,18);
                code.visitJumpStmt(IF_EQZ,18,-1,L60);
                code.visitLabel(L59);
                code.visitTypeStmt(NEW_INSTANCE,18,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT_RANGE,new int[]{ 18},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,18);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,16);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,18);
                code.visitConstStmt(CONST_STRING,19,"?");
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 18,19},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,18);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 26},new Method("Lorg/mortbay/jetty/Request;","getQueryString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,19);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 18,19},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,18);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 18},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,16);
                code.visitLabel(L60);
                code.visitConstStmt(CONST_16,18, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitStmt2R(MOVE_FROM16,1,18);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Lorg/mortbay/jetty/Response;","setContentLength",new String[]{ "I"},"V"));
                code.visitLabel(L61);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,16);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Lorg/mortbay/jetty/Response;","sendRedirect",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L62);
                code.visitConstStmt(CONST_16,18, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitJumpStmt(GOTO_16,-1,-1,L25);
                code.visitLabel(L63);
                code.visitConstStmt(CONST_16,18, Integer.valueOf(403)); // int: 0x00000193  float:0.000000
                code.visitConstStmt(CONST_16,19, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitStmt2R(MOVE_FROM16,1,18);
                code.visitStmt2R(MOVE_OBJECT_FROM16,2,19);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1,2},new Method("Lorg/mortbay/jetty/Response;","sendError",new String[]{ "I","Ljava/lang/String;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L62);
                code.visitLabel(L64);
                code.visitConstStmt(CONST_16,17, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L65);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 26},new Method("Lorg/mortbay/jetty/Request;","getAuthType",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,19);
                code.visitJumpStmt(IF_EQZ,19,-1,L73);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 26},new Method("Lorg/mortbay/jetty/Request;","getRemoteUser",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,19);
                code.visitJumpStmt(IF_EQZ,19,-1,L73);
                code.visitLabel(L66);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 26},new Method("Lorg/mortbay/jetty/Request;","getUserPrincipal",new String[]{ },"Ljava/security/Principal;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,17);
                code.visitLabel(L67);
                code.visitJumpStmt(IF_NEZ,17,-1,L69);
                code.visitLabel(L68);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 26},new Method("Lorg/mortbay/jetty/Request;","getRemoteUser",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,19);
                code.visitConstStmt(CONST_16,20, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,24);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,19);
                code.visitStmt2R(MOVE_OBJECT_FROM16,2,20);
                code.visitStmt2R(MOVE_OBJECT_FROM16,3,26);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,1,2,3},new Method("Lorg/mortbay/jetty/security/UserRealm;","authenticate",new String[]{ "Ljava/lang/String;","Ljava/lang/Object;","Lorg/mortbay/jetty/Request;"},"Ljava/security/Principal;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,17);
                code.visitLabel(L69);
                code.visitJumpStmt(IF_NEZ,17,-1,L71);
                code.visitJumpStmt(IF_EQZ,23,-1,L71);
                code.visitLabel(L70);
                code.visitMethodStmt(INVOKE_INTERFACE_RANGE,new int[]{ 23,24,25,26,27},new Method("Lorg/mortbay/jetty/security/Authenticator;","authenticate",new String[]{ "Lorg/mortbay/jetty/security/UserRealm;","Ljava/lang/String;","Lorg/mortbay/jetty/Request;","Lorg/mortbay/jetty/Response;"},"Ljava/security/Principal;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,17);
                code.visitLabel(L71);
                code.visitJumpStmt(IF_NEZ,17,-1,L78);
                code.visitLabel(L72);
                code.visitConstStmt(CONST_16,18, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitJumpStmt(GOTO_16,-1,-1,L25);
                code.visitLabel(L73);
                code.visitJumpStmt(IF_EQZ,23,-1,L76);
                code.visitLabel(L74);
                code.visitMethodStmt(INVOKE_INTERFACE_RANGE,new int[]{ 23,24,25,26,27},new Method("Lorg/mortbay/jetty/security/Authenticator;","authenticate",new String[]{ "Lorg/mortbay/jetty/security/UserRealm;","Ljava/lang/String;","Lorg/mortbay/jetty/Request;","Lorg/mortbay/jetty/Response;"},"Ljava/security/Principal;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,17);
                code.visitLabel(L75);
                code.visitJumpStmt(GOTO,-1,-1,L71);
                code.visitLabel(L76);
                code.visitTypeStmt(NEW_INSTANCE,19,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT_RANGE,new int[]{ 19},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,20,"Mis-configured Authenticator for ");
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 19,20},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,19);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 26},new Method("Lorg/mortbay/jetty/Request;","getRequestURI",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,20);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 19,20},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,19);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 19},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,19);
                code.visitMethodStmt(INVOKE_STATIC_RANGE,new int[]{ 19},new Method("Lorg/mortbay/log/Log;","warn",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L77);
                code.visitConstStmt(CONST_16,19, Integer.valueOf(500)); // int: 0x000001f4  float:0.000000
                code.visitConstStmt(CONST_STRING,20,"Configuration error");
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitStmt2R(MOVE_FROM16,1,19);
                code.visitStmt2R(MOVE_OBJECT_FROM16,2,20);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1,2},new Method("Lorg/mortbay/jetty/Response;","sendError",new String[]{ "I","Ljava/lang/String;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L71);
                code.visitLabel(L78);
                code.visitFieldStmt(SGET_OBJECT,19,-1,new Field("Lorg/mortbay/jetty/security/SecurityHandler;","__NOBODY","Ljava/security/Principal;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,17);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,19);
                code.visitJumpStmt(IF_NE,0,1,L80);
                code.visitLabel(L79);
                code.visitConstStmt(CONST_16,18, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitJumpStmt(GOTO_16,-1,-1,L25);
                code.visitLabel(L80);
                code.visitConstStmt(CONST_STRING,19,"*");
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,18);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,19);
                code.visitJumpStmt(IF_EQ,0,1,L93);
                code.visitLabel(L81);
                code.visitConstStmt(CONST_4,9, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L82);
                code.visitMethodStmt(INVOKE_STATIC_RANGE,new int[]{ 18},new Method("Lorg/mortbay/util/LazyList;","size",new String[]{ "Ljava/lang/Object;"},"I"));
                code.visitStmt1R(MOVE_RESULT,10);
                code.visitLabel(L83);
                code.visitStmt2R(MOVE,11,10);
                code.visitLabel(L84);
                code.visitConstStmt(CONST_16,19, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitStmt3R(SUB_INT,10,11,19);
                code.visitLabel(L85);
                code.visitJumpStmt(IF_LEZ,11,-1,L88);
                code.visitLabel(L86);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,18);
                code.visitStmt2R(MOVE,1,10);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0,1},new Method("Lorg/mortbay/util/LazyList;","get",new String[]{ "Ljava/lang/Object;","I"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,21);
                code.visitTypeStmt(CHECK_CAST,21,-1,"Ljava/lang/String;");
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,24);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,17);
                code.visitStmt2R(MOVE_OBJECT_FROM16,2,21);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,1,2},new Method("Lorg/mortbay/jetty/security/UserRealm;","isUserInRole",new String[]{ "Ljava/security/Principal;","Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,19);
                code.visitJumpStmt(IF_EQZ,19,-1,L94);
                code.visitLabel(L87);
                code.visitConstStmt(CONST_4,9, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitLabel(L88);
                code.visitJumpStmt(IF_NEZ,9,-1,L93);
                code.visitLabel(L89);
                code.visitTypeStmt(NEW_INSTANCE,18,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT_RANGE,new int[]{ 18},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,19,"AUTH FAILURE: incorrect role for ");
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 18,19},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,18);
                code.visitMethodStmt(INVOKE_INTERFACE_RANGE,new int[]{ 17},new Method("Ljava/security/Principal;","getName",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,19);
                code.visitMethodStmt(INVOKE_STATIC_RANGE,new int[]{ 19},new Method("Lorg/mortbay/util/StringUtil;","printable",new String[]{ "Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,19);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 18,19},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,18);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 18},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,18);
                code.visitMethodStmt(INVOKE_STATIC_RANGE,new int[]{ 18},new Method("Lorg/mortbay/log/Log;","warn",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L90);
                code.visitConstStmt(CONST_16,18, Integer.valueOf(403)); // int: 0x00000193  float:0.000000
                code.visitConstStmt(CONST_STRING,19,"User not in required role");
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,27);
                code.visitStmt2R(MOVE_FROM16,1,18);
                code.visitStmt2R(MOVE_OBJECT_FROM16,2,19);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1,2},new Method("Lorg/mortbay/jetty/Response;","sendError",new String[]{ "I","Ljava/lang/String;"},"V"));
                code.visitLabel(L91);
                code.visitConstStmt(CONST_16,18, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitJumpStmt(GOTO_16,-1,-1,L25);
                code.visitLabel(L92);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,21);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/security/SecurityHandler;","_notChecked","Lorg/mortbay/jetty/security/SecurityHandler$NotChecked;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,18,0);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,26);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,18);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Lorg/mortbay/jetty/Request;","setUserPrincipal",new String[]{ "Ljava/security/Principal;"},"V"));
                code.visitLabel(L93);
                code.visitConstStmt(CONST_16,18, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitJumpStmt(GOTO_16,-1,-1,L25);
                code.visitLabel(L94);
                code.visitStmt2R(MOVE,11,10);
                code.visitLabel(L95);
                code.visitJumpStmt(GOTO,-1,-1,L84);
                code.visitLabel(L96);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m003_checkSecurityConstraints(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/security/SecurityHandler;","checkSecurityConstraints",new String[]{ "Ljava/lang/String;","Lorg/mortbay/jetty/Request;","Lorg/mortbay/jetty/Response;"},"Z"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(22);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"pathInContext");
                ddv.visitParameterName(1,"request");
                ddv.visitParameterName(2,"response");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(239,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(240,L1);
                ddv.visitStartLocal(14,L1,"mapping_entries","Ljava/lang/Object;",null);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(241,L2);
                ddv.visitStartLocal(17,L2,"pattern","Ljava/lang/String;",null);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(247,L3);
                ddv.visitStartLocal(10,L3,"constraints","Ljava/lang/Object;",null);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(249,L4);
                DexLabel L5=new DexLabel();
                ddv.visitStartLocal(12,L5,"m","I",null);
                DexLabel L6=new DexLabel();
                ddv.visitEndLocal(10,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(251,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(252,L8);
                ddv.visitStartLocal(11,L8,"entry","Ljava/util/Map$Entry;",null);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(253,L9);
                ddv.visitStartLocal(15,L9,"mappings","Ljava/lang/Object;",null);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(255,L10);
                ddv.visitStartLocal(16,L10,"path_spec","Ljava/lang/String;",null);
                DexLabel L11=new DexLabel();
                ddv.visitStartLocal(9,L11,"c","I",null);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(257,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(258,L13);
                ddv.visitStartLocal(13,L13,"mapping","Lorg/mortbay/jetty/security/ConstraintMapping;",null);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(255,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(261,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(269,L16);
                ddv.visitEndLocal(11,L16);
                ddv.visitEndLocal(15,L16);
                ddv.visitEndLocal(16,L16);
                ddv.visitEndLocal(9,L16);
                ddv.visitEndLocal(13,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(273,L17);
                ddv.visitEndLocal(12,L17);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(264,L18);
                ddv.visitRestartLocal(9,L18);
                ddv.visitRestartLocal(11,L18);
                ddv.visitRestartLocal(12,L18);
                ddv.visitRestartLocal(13,L18);
                ddv.visitRestartLocal(15,L18);
                ddv.visitRestartLocal(16,L18);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(265,L19);
                DexLabel L20=new DexLabel();
                ddv.visitStartLocal(10,L20,"constraints","Ljava/lang/Object;",null);
                DexLabel L21=new DexLabel();
                ddv.visitLineNumber(249,L21);
                ddv.visitEndLocal(13,L21);
                ddv.visitEndLocal(10,L21);
                DexLabel L22=new DexLabel();
                ddv.visitLineNumber(272,L22);
                ddv.visitEndLocal(9,L22);
                ddv.visitEndLocal(11,L22);
                ddv.visitEndLocal(12,L22);
                ddv.visitEndLocal(15,L22);
                ddv.visitEndLocal(16,L22);
                ddv.visitStartLocal(10,L22,"constraints","Ljava/lang/Object;",null);
                DexLabel L23=new DexLabel();
                ddv.visitLineNumber(273,L23);
                DexLabel L24=new DexLabel();
                ddv.visitEndLocal(10,L24);
                ddv.visitRestartLocal(12,L24);
                code.visitLabel(L0);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,18);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/security/SecurityHandler;","_constraintMap","Lorg/mortbay/jetty/servlet/PathMap;"));
                code.visitStmt2R(MOVE_OBJECT,2,0);
                code.visitStmt2R(MOVE_OBJECT,0,2);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,19);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Lorg/mortbay/jetty/servlet/PathMap;","getLazyMatches",new String[]{ "Ljava/lang/String;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,14);
                code.visitLabel(L1);
                code.visitConstStmt(CONST_16,17, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L2);
                code.visitConstStmt(CONST_4,10, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L3);
                code.visitJumpStmt(IF_EQZ,14,-1,L22);
                code.visitLabel(L4);
                code.visitConstStmt(CONST_4,12, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L5);
                code.visitStmt2R(MOVE_OBJECT,2,10);
                code.visitLabel(L6);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 14},new Method("Lorg/mortbay/util/LazyList;","size",new String[]{ "Ljava/lang/Object;"},"I"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitJumpStmt(IF_GE,12,3,L24);
                code.visitLabel(L7);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 14,12},new Method("Lorg/mortbay/util/LazyList;","get",new String[]{ "Ljava/lang/Object;","I"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,11);
                code.visitTypeStmt(CHECK_CAST,11,-1,"Ljava/util/Map$Entry;");
                code.visitLabel(L8);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 11},new Method("Ljava/util/Map$Entry;","getValue",new String[]{ },"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,15);
                code.visitLabel(L9);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 11},new Method("Ljava/util/Map$Entry;","getKey",new String[]{ },"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,16);
                code.visitTypeStmt(CHECK_CAST,16,-1,"Ljava/lang/String;");
                code.visitLabel(L10);
                code.visitConstStmt(CONST_4,9, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L11);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 15},new Method("Lorg/mortbay/util/LazyList;","size",new String[]{ "Ljava/lang/Object;"},"I"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitJumpStmt(IF_GE,9,3,L21);
                code.visitLabel(L12);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 15,9},new Method("Lorg/mortbay/util/LazyList;","get",new String[]{ "Ljava/lang/Object;","I"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,13);
                code.visitTypeStmt(CHECK_CAST,13,-1,"Lorg/mortbay/jetty/security/ConstraintMapping;");
                code.visitLabel(L13);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 13},new Method("Lorg/mortbay/jetty/security/ConstraintMapping;","getMethod",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitJumpStmt(IF_EQZ,3,-1,L15);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 13},new Method("Lorg/mortbay/jetty/security/ConstraintMapping;","getMethod",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 20},new Method("Lorg/mortbay/jetty/Request;","getMethod",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,4},new Method("Ljava/lang/String;","equalsIgnoreCase",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitJumpStmt(IF_NEZ,3,-1,L15);
                code.visitLabel(L14);
                code.visitStmt2R1N(ADD_INT_LIT8,9,9,1);
                code.visitJumpStmt(GOTO,-1,-1,L11);
                code.visitLabel(L15);
                code.visitJumpStmt(IF_EQZ,17,-1,L18);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,17);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,16);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/String;","equals",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitJumpStmt(IF_NEZ,3,-1,L18);
                code.visitStmt2R(MOVE_OBJECT,3,2);
                code.visitLabel(L16);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,18);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/security/SecurityHandler;","_authenticator","Lorg/mortbay/jetty/security/Authenticator;"));
                code.visitStmt2R(MOVE_OBJECT,4,0);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,18);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/security/SecurityHandler;","_userRealm","Lorg/mortbay/jetty/security/UserRealm;"));
                code.visitStmt2R(MOVE_OBJECT,5,0);
                code.visitStmt2R(MOVE_OBJECT_FROM16,2,18);
                code.visitStmt2R(MOVE_OBJECT_FROM16,6,19);
                code.visitStmt2R(MOVE_OBJECT_FROM16,7,20);
                code.visitStmt2R(MOVE_OBJECT_FROM16,8,21);
                code.visitMethodStmt(INVOKE_DIRECT_RANGE,new int[]{ 2,3,4,5,6,7,8},new Method("Lorg/mortbay/jetty/security/SecurityHandler;","check",new String[]{ "Ljava/lang/Object;","Lorg/mortbay/jetty/security/Authenticator;","Lorg/mortbay/jetty/security/UserRealm;","Ljava/lang/String;","Lorg/mortbay/jetty/Request;","Lorg/mortbay/jetty/Response;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitLabel(L17);
                code.visitStmt1R(RETURN,2);
                code.visitLabel(L18);
                code.visitStmt2R(MOVE_OBJECT_FROM16,17,16);
                code.visitLabel(L19);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 13},new Method("Lorg/mortbay/jetty/security/ConstraintMapping;","getConstraint",new String[]{ },"Lorg/mortbay/jetty/security/Constraint;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 2,3},new Method("Lorg/mortbay/util/LazyList;","add",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,10);
                code.visitLabel(L20);
                code.visitStmt2R(MOVE_OBJECT,2,10);
                code.visitJumpStmt(GOTO,-1,-1,L14);
                code.visitLabel(L21);
                code.visitStmt2R1N(ADD_INT_LIT8,12,12,1);
                code.visitJumpStmt(GOTO,-1,-1,L6);
                code.visitLabel(L22);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,18);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/security/SecurityHandler;","_notChecked","Lorg/mortbay/jetty/security/SecurityHandler$NotChecked;"));
                code.visitStmt2R(MOVE_OBJECT,2,0);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,20);
                code.visitStmt2R(MOVE_OBJECT,1,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Lorg/mortbay/jetty/Request;","setUserPrincipal",new String[]{ "Ljava/security/Principal;"},"V"));
                code.visitLabel(L23);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L17);
                code.visitLabel(L24);
                code.visitStmt2R(MOVE_OBJECT,3,2);
                code.visitJumpStmt(GOTO,-1,-1,L16);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m004_doStart(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/security/SecurityHandler;","doStart",new String[]{ },"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/lang/Exception;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(160,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(163,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(164,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(175,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(176,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(165,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(166,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(167,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(168,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(169,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(170,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(172,L11);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/jetty/security/SecurityHandler;","_authenticator","Lorg/mortbay/jetty/security/Authenticator;"));
                code.visitJumpStmt(IF_NEZ,0,-1,L3);
                code.visitLabel(L1);
                code.visitConstStmt(CONST_STRING,0,"BASIC");
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/jetty/security/SecurityHandler;","_authMethod","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/String;","equalsIgnoreCase",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_EQZ,0,-1,L5);
                code.visitLabel(L2);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Lorg/mortbay/jetty/security/BasicAuthenticator;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Lorg/mortbay/jetty/security/BasicAuthenticator;","<init>",new String[]{ },"V"));
                code.visitFieldStmt(IPUT_OBJECT,0,2,new Field("Lorg/mortbay/jetty/security/SecurityHandler;","_authenticator","Lorg/mortbay/jetty/security/Authenticator;"));
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_SUPER,new int[]{ 2},new Method("Lorg/mortbay/jetty/handler/HandlerWrapper;","doStart",new String[]{ },"V"));
                code.visitLabel(L4);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L5);
                code.visitConstStmt(CONST_STRING,0,"DIGEST");
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/jetty/security/SecurityHandler;","_authMethod","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/String;","equalsIgnoreCase",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_EQZ,0,-1,L7);
                code.visitLabel(L6);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Lorg/mortbay/jetty/security/DigestAuthenticator;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Lorg/mortbay/jetty/security/DigestAuthenticator;","<init>",new String[]{ },"V"));
                code.visitFieldStmt(IPUT_OBJECT,0,2,new Field("Lorg/mortbay/jetty/security/SecurityHandler;","_authenticator","Lorg/mortbay/jetty/security/Authenticator;"));
                code.visitJumpStmt(GOTO,-1,-1,L3);
                code.visitLabel(L7);
                code.visitConstStmt(CONST_STRING,0,"CLIENT_CERT");
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/jetty/security/SecurityHandler;","_authMethod","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/String;","equalsIgnoreCase",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_EQZ,0,-1,L9);
                code.visitLabel(L8);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Lorg/mortbay/jetty/security/ClientCertAuthenticator;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Lorg/mortbay/jetty/security/ClientCertAuthenticator;","<init>",new String[]{ },"V"));
                code.visitFieldStmt(IPUT_OBJECT,0,2,new Field("Lorg/mortbay/jetty/security/SecurityHandler;","_authenticator","Lorg/mortbay/jetty/security/Authenticator;"));
                code.visitJumpStmt(GOTO,-1,-1,L3);
                code.visitLabel(L9);
                code.visitConstStmt(CONST_STRING,0,"FORM");
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/jetty/security/SecurityHandler;","_authMethod","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/String;","equalsIgnoreCase",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_EQZ,0,-1,L11);
                code.visitLabel(L10);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Lorg/mortbay/jetty/security/FormAuthenticator;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Lorg/mortbay/jetty/security/FormAuthenticator;","<init>",new String[]{ },"V"));
                code.visitFieldStmt(IPUT_OBJECT,0,2,new Field("Lorg/mortbay/jetty/security/SecurityHandler;","_authenticator","Lorg/mortbay/jetty/security/Authenticator;"));
                code.visitJumpStmt(GOTO,-1,-1,L3);
                code.visitLabel(L11);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,1,"Unknown Authentication method:");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/jetty/security/SecurityHandler;","_authMethod","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0},new Method("Lorg/mortbay/log/Log;","warn",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L3);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m005_getAuthMethod(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/security/SecurityHandler;","getAuthMethod",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(122,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/security/SecurityHandler;","_authMethod","Ljava/lang/String;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m006_getAuthenticator(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/security/SecurityHandler;","getAuthenticator",new String[]{ },"Lorg/mortbay/jetty/security/Authenticator;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(59,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/security/SecurityHandler;","_authenticator","Lorg/mortbay/jetty/security/Authenticator;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m007_getConstraintMappings(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/security/SecurityHandler;","getConstraintMappings",new String[]{ },"[Lorg/mortbay/jetty/security/ConstraintMapping;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(95,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/security/SecurityHandler;","_constraintMappings","[Lorg/mortbay/jetty/security/ConstraintMapping;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m008_getUserRealm(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/security/SecurityHandler;","getUserRealm",new String[]{ },"Lorg/mortbay/jetty/security/UserRealm;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(77,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/security/SecurityHandler;","_userRealm","Lorg/mortbay/jetty/security/UserRealm;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m009_handle(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/security/SecurityHandler;","handle",new String[]{ "Ljava/lang/String;","Ljavax/servlet/http/HttpServletRequest;","Ljavax/servlet/http/HttpServletResponse;","I"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visit(null, new DexType("Ljavax/servlet/ServletException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(12);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexLabel L3=new DexLabel();
                DexLabel L4=new DexLabel();
                code.visitTryCatch(L3,L4,new DexLabel[]{L2},new String[]{ null});
                DexLabel L5=new DexLabel();
                DexLabel L6=new DexLabel();
                code.visitTryCatch(L5,L6,new DexLabel[]{L2},new String[]{ null});
                DexLabel L7=new DexLabel();
                DexLabel L8=new DexLabel();
                code.visitTryCatch(L7,L8,new DexLabel[]{L2},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"target");
                ddv.visitParameterName(1,"request");
                ddv.visitParameterName(2,"response");
                ddv.visitParameterName(3,"dispatch");
                DexLabel L9=new DexLabel();
                ddv.visitPrologue(L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(185,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(186,L11);
                ddv.visitStartLocal(1,L11,"base_request","Lorg/mortbay/jetty/Request;",null);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(187,L12);
                ddv.visitStartLocal(2,L12,"base_response","Lorg/mortbay/jetty/Response;",null);
                ddv.visitLineNumber(190,L0);
                ddv.visitStartLocal(3,L0,"old_realm","Lorg/mortbay/jetty/security/UserRealm;",null);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(191,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(193,L14);
                ddv.visitLineNumber(220,L1);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(222,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(224,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(227,L17);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(229,L18);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(185,L19);
                ddv.visitEndLocal(1,L19);
                ddv.visitEndLocal(2,L19);
                ddv.visitEndLocal(3,L19);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(186,L20);
                ddv.visitRestartLocal(1,L20);
                DexLabel L21=new DexLabel();
                ddv.visitLineNumber(197,L21);
                ddv.visitRestartLocal(2,L21);
                ddv.visitRestartLocal(3,L21);
                DexLabel L22=new DexLabel();
                ddv.visitLineNumber(199,L22);
                DexLabel L23=new DexLabel();
                ddv.visitLineNumber(200,L23);
                DexLabel L24=new DexLabel();
                ddv.visitLineNumber(202,L24);
                ddv.visitLineNumber(220,L4);
                DexLabel L25=new DexLabel();
                ddv.visitLineNumber(222,L25);
                DexLabel L26=new DexLabel();
                ddv.visitLineNumber(224,L26);
                ddv.visitLineNumber(208,L5);
                DexLabel L27=new DexLabel();
                ddv.visitLineNumber(210,L27);
                DexLabel L28=new DexLabel();
                ddv.visitLineNumber(211,L28);
                ddv.visitLineNumber(220,L6);
                DexLabel L29=new DexLabel();
                ddv.visitLineNumber(222,L29);
                DexLabel L30=new DexLabel();
                ddv.visitLineNumber(224,L30);
                ddv.visitLineNumber(215,L7);
                DexLabel L31=new DexLabel();
                ddv.visitLineNumber(216,L31);
                ddv.visitLineNumber(220,L8);
                DexLabel L32=new DexLabel();
                ddv.visitLineNumber(222,L32);
                DexLabel L33=new DexLabel();
                ddv.visitLineNumber(224,L33);
                ddv.visitLineNumber(220,L2);
                DexLabel L34=new DexLabel();
                ddv.visitLineNumber(222,L34);
                DexLabel L35=new DexLabel();
                ddv.visitLineNumber(224,L35);
                DexLabel L36=new DexLabel();
                ddv.visitLineNumber(227,L36);
                DexLabel L37=new DexLabel();
                ddv.visitLineNumber(220,L37);
                code.visitLabel(L9);
                code.visitConstStmt(CONST_4,6, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitConstStmt(CONST_STRING,4,"org.mortbay.jetty.welcome");
                code.visitLabel(L10);
                code.visitTypeStmt(INSTANCE_OF,4,9,"Lorg/mortbay/jetty/Request;");
                code.visitJumpStmt(IF_EQZ,4,-1,L19);
                code.visitStmt2R(MOVE_OBJECT,0,9);
                code.visitTypeStmt(CHECK_CAST,0,-1,"Lorg/mortbay/jetty/Request;");
                code.visitStmt2R(MOVE_OBJECT,4,0);
                code.visitStmt2R(MOVE_OBJECT,1,4);
                code.visitLabel(L11);
                code.visitTypeStmt(INSTANCE_OF,4,10,"Lorg/mortbay/jetty/Response;");
                code.visitJumpStmt(IF_EQZ,4,-1,L20);
                code.visitStmt2R(MOVE_OBJECT,0,10);
                code.visitTypeStmt(CHECK_CAST,0,-1,"Lorg/mortbay/jetty/Response;");
                code.visitStmt2R(MOVE_OBJECT,4,0);
                code.visitStmt2R(MOVE_OBJECT,2,4);
                code.visitLabel(L12);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Lorg/mortbay/jetty/Request;","getUserRealm",new String[]{ },"Lorg/mortbay/jetty/security/UserRealm;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7},new Method("Lorg/mortbay/jetty/security/SecurityHandler;","getUserRealm",new String[]{ },"Lorg/mortbay/jetty/security/UserRealm;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,4},new Method("Lorg/mortbay/jetty/Request;","setUserRealm",new String[]{ "Lorg/mortbay/jetty/security/UserRealm;"},"V"));
                code.visitLabel(L13);
                code.visitJumpStmt(IF_NE,11,6,L21);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7,8,1,2},new Method("Lorg/mortbay/jetty/security/SecurityHandler;","checkSecurityConstraints",new String[]{ "Ljava/lang/String;","Lorg/mortbay/jetty/Request;","Lorg/mortbay/jetty/Response;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,4);
                code.visitJumpStmt(IF_NEZ,4,-1,L21);
                code.visitLabel(L14);
                code.visitConstStmt(CONST_4,4, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,4},new Method("Lorg/mortbay/jetty/Request;","setHandled",new String[]{ "Z"},"V"));
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,4,7,new Field("Lorg/mortbay/jetty/security/SecurityHandler;","_userRealm","Lorg/mortbay/jetty/security/UserRealm;"));
                code.visitJumpStmt(IF_EQZ,4,-1,L17);
                code.visitLabel(L15);
                code.visitJumpStmt(IF_NE,11,6,L17);
                code.visitLabel(L16);
                code.visitFieldStmt(IGET_OBJECT,4,7,new Field("Lorg/mortbay/jetty/security/SecurityHandler;","_userRealm","Lorg/mortbay/jetty/security/UserRealm;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Lorg/mortbay/jetty/Request;","getUserPrincipal",new String[]{ },"Ljava/security/Principal;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 4,5},new Method("Lorg/mortbay/jetty/security/UserRealm;","disassociate",new String[]{ "Ljava/security/Principal;"},"V"));
                code.visitLabel(L17);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,3},new Method("Lorg/mortbay/jetty/Request;","setUserRealm",new String[]{ "Lorg/mortbay/jetty/security/UserRealm;"},"V"));
                code.visitLabel(L18);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L19);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Lorg/mortbay/jetty/HttpConnection;","getCurrentConnection",new String[]{ },"Lorg/mortbay/jetty/HttpConnection;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Lorg/mortbay/jetty/HttpConnection;","getRequest",new String[]{ },"Lorg/mortbay/jetty/Request;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitStmt2R(MOVE_OBJECT,1,4);
                code.visitJumpStmt(GOTO,-1,-1,L11);
                code.visitLabel(L20);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Lorg/mortbay/jetty/HttpConnection;","getCurrentConnection",new String[]{ },"Lorg/mortbay/jetty/HttpConnection;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Lorg/mortbay/jetty/HttpConnection;","getResponse",new String[]{ },"Lorg/mortbay/jetty/Response;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitStmt2R(MOVE_OBJECT,2,4);
                code.visitJumpStmt(GOTO,-1,-1,L12);
                code.visitLabel(L21);
                code.visitConstStmt(CONST_4,4, Integer.valueOf(2)); // int: 0x00000002  float:0.000000
                code.visitJumpStmt(IF_NE,11,4,L5);
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_BOOLEAN,4,7,new Field("Lorg/mortbay/jetty/security/SecurityHandler;","_checkWelcomeFiles","Z"));
                code.visitJumpStmt(IF_EQZ,4,-1,L5);
                code.visitConstStmt(CONST_STRING,4,"org.mortbay.jetty.welcome");
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 9,4},new Method("Ljavax/servlet/http/HttpServletRequest;","getAttribute",new String[]{ "Ljava/lang/String;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitJumpStmt(IF_EQZ,4,-1,L5);
                code.visitLabel(L22);
                code.visitConstStmt(CONST_STRING,4,"org.mortbay.jetty.welcome");
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 9,4},new Method("Ljavax/servlet/http/HttpServletRequest;","removeAttribute",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L23);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7,8,1,2},new Method("Lorg/mortbay/jetty/security/SecurityHandler;","checkSecurityConstraints",new String[]{ "Ljava/lang/String;","Lorg/mortbay/jetty/Request;","Lorg/mortbay/jetty/Response;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,4);
                code.visitJumpStmt(IF_NEZ,4,-1,L5);
                code.visitLabel(L24);
                code.visitConstStmt(CONST_4,4, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,4},new Method("Lorg/mortbay/jetty/Request;","setHandled",new String[]{ "Z"},"V"));
                code.visitLabel(L4);
                code.visitFieldStmt(IGET_OBJECT,4,7,new Field("Lorg/mortbay/jetty/security/SecurityHandler;","_userRealm","Lorg/mortbay/jetty/security/UserRealm;"));
                code.visitJumpStmt(IF_EQZ,4,-1,L17);
                code.visitLabel(L25);
                code.visitJumpStmt(IF_NE,11,6,L17);
                code.visitLabel(L26);
                code.visitFieldStmt(IGET_OBJECT,4,7,new Field("Lorg/mortbay/jetty/security/SecurityHandler;","_userRealm","Lorg/mortbay/jetty/security/UserRealm;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Lorg/mortbay/jetty/Request;","getUserPrincipal",new String[]{ },"Ljava/security/Principal;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 4,5},new Method("Lorg/mortbay/jetty/security/UserRealm;","disassociate",new String[]{ "Ljava/security/Principal;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L17);
                code.visitLabel(L5);
                code.visitFieldStmt(IGET_OBJECT,4,7,new Field("Lorg/mortbay/jetty/security/SecurityHandler;","_authenticator","Lorg/mortbay/jetty/security/Authenticator;"));
                code.visitTypeStmt(INSTANCE_OF,4,4,"Lorg/mortbay/jetty/security/FormAuthenticator;");
                code.visitJumpStmt(IF_EQZ,4,-1,L7);
                code.visitConstStmt(CONST_STRING,4,"/j_security_check");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8,4},new Method("Ljava/lang/String;","endsWith",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,4);
                code.visitJumpStmt(IF_EQZ,4,-1,L7);
                code.visitLabel(L27);
                code.visitFieldStmt(IGET_OBJECT,4,7,new Field("Lorg/mortbay/jetty/security/SecurityHandler;","_authenticator","Lorg/mortbay/jetty/security/Authenticator;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7},new Method("Lorg/mortbay/jetty/security/SecurityHandler;","getUserRealm",new String[]{ },"Lorg/mortbay/jetty/security/UserRealm;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 4,5,8,1,2},new Method("Lorg/mortbay/jetty/security/Authenticator;","authenticate",new String[]{ "Lorg/mortbay/jetty/security/UserRealm;","Ljava/lang/String;","Lorg/mortbay/jetty/Request;","Lorg/mortbay/jetty/Response;"},"Ljava/security/Principal;"));
                code.visitLabel(L28);
                code.visitConstStmt(CONST_4,4, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,4},new Method("Lorg/mortbay/jetty/Request;","setHandled",new String[]{ "Z"},"V"));
                code.visitLabel(L6);
                code.visitFieldStmt(IGET_OBJECT,4,7,new Field("Lorg/mortbay/jetty/security/SecurityHandler;","_userRealm","Lorg/mortbay/jetty/security/UserRealm;"));
                code.visitJumpStmt(IF_EQZ,4,-1,L17);
                code.visitLabel(L29);
                code.visitJumpStmt(IF_NE,11,6,L17);
                code.visitLabel(L30);
                code.visitFieldStmt(IGET_OBJECT,4,7,new Field("Lorg/mortbay/jetty/security/SecurityHandler;","_userRealm","Lorg/mortbay/jetty/security/UserRealm;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Lorg/mortbay/jetty/Request;","getUserPrincipal",new String[]{ },"Ljava/security/Principal;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 4,5},new Method("Lorg/mortbay/jetty/security/UserRealm;","disassociate",new String[]{ "Ljava/security/Principal;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L17);
                code.visitLabel(L7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7},new Method("Lorg/mortbay/jetty/security/SecurityHandler;","getHandler",new String[]{ },"Lorg/mortbay/jetty/Handler;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitJumpStmt(IF_EQZ,4,-1,L8);
                code.visitLabel(L31);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7},new Method("Lorg/mortbay/jetty/security/SecurityHandler;","getHandler",new String[]{ },"Lorg/mortbay/jetty/Handler;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 4,8,9,10,11},new Method("Lorg/mortbay/jetty/Handler;","handle",new String[]{ "Ljava/lang/String;","Ljavax/servlet/http/HttpServletRequest;","Ljavax/servlet/http/HttpServletResponse;","I"},"V"));
                code.visitLabel(L8);
                code.visitFieldStmt(IGET_OBJECT,4,7,new Field("Lorg/mortbay/jetty/security/SecurityHandler;","_userRealm","Lorg/mortbay/jetty/security/UserRealm;"));
                code.visitJumpStmt(IF_EQZ,4,-1,L17);
                code.visitLabel(L32);
                code.visitJumpStmt(IF_NE,11,6,L17);
                code.visitLabel(L33);
                code.visitFieldStmt(IGET_OBJECT,4,7,new Field("Lorg/mortbay/jetty/security/SecurityHandler;","_userRealm","Lorg/mortbay/jetty/security/UserRealm;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Lorg/mortbay/jetty/Request;","getUserPrincipal",new String[]{ },"Ljava/security/Principal;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 4,5},new Method("Lorg/mortbay/jetty/security/UserRealm;","disassociate",new String[]{ "Ljava/security/Principal;"},"V"));
                code.visitJumpStmt(GOTO_16,-1,-1,L17);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,4);
                code.visitFieldStmt(IGET_OBJECT,5,7,new Field("Lorg/mortbay/jetty/security/SecurityHandler;","_userRealm","Lorg/mortbay/jetty/security/UserRealm;"));
                code.visitJumpStmt(IF_EQZ,5,-1,L36);
                code.visitLabel(L34);
                code.visitJumpStmt(IF_NE,11,6,L36);
                code.visitLabel(L35);
                code.visitFieldStmt(IGET_OBJECT,5,7,new Field("Lorg/mortbay/jetty/security/SecurityHandler;","_userRealm","Lorg/mortbay/jetty/security/UserRealm;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Lorg/mortbay/jetty/Request;","getUserPrincipal",new String[]{ },"Ljava/security/Principal;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 5,6},new Method("Lorg/mortbay/jetty/security/UserRealm;","disassociate",new String[]{ "Ljava/security/Principal;"},"V"));
                code.visitLabel(L36);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,3},new Method("Lorg/mortbay/jetty/Request;","setUserRealm",new String[]{ "Lorg/mortbay/jetty/security/UserRealm;"},"V"));
                code.visitLabel(L37);
                code.visitStmt1R(THROW,4);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m010_hasConstraints(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/security/SecurityHandler;","hasConstraints",new String[]{ },"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(136,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/security/SecurityHandler;","_constraintMappings","[Lorg/mortbay/jetty/security/ConstraintMapping;"));
                DexLabel L1=new DexLabel();
                code.visitJumpStmt(IF_EQZ,0,-1,L1);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/security/SecurityHandler;","_constraintMappings","[Lorg/mortbay/jetty/security/ConstraintMapping;"));
                code.visitStmt2R(ARRAY_LENGTH,0,0);
                code.visitJumpStmt(IF_LEZ,0,-1,L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                DexLabel L2=new DexLabel();
                code.visitLabel(L2);
                code.visitStmt1R(RETURN,0);
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m011_isCheckWelcomeFiles(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/security/SecurityHandler;","isCheckWelcomeFiles",new String[]{ },"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(145,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_BOOLEAN,0,1,new Field("Lorg/mortbay/jetty/security/SecurityHandler;","_checkWelcomeFiles","Z"));
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m012_setAuthMethod(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/security/SecurityHandler;","setAuthMethod",new String[]{ "Ljava/lang/String;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"method");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(128,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(129,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(130,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(131,L3);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/jetty/security/SecurityHandler;","isStarted",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_EQZ,0,-1,L2);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/jetty/security/SecurityHandler;","_authMethod","Ljava/lang/String;"));
                code.visitJumpStmt(IF_EQZ,0,-1,L2);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/jetty/security/SecurityHandler;","_authMethod","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,3},new Method("Ljava/lang/String;","equals",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_NEZ,0,-1,L2);
                code.visitLabel(L1);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/lang/IllegalStateException;");
                code.visitConstStmt(CONST_STRING,1,"Handler started");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1},new Method("Ljava/lang/IllegalStateException;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitStmt1R(THROW,0);
                code.visitLabel(L2);
                code.visitFieldStmt(IPUT_OBJECT,3,2,new Field("Lorg/mortbay/jetty/security/SecurityHandler;","_authMethod","Ljava/lang/String;"));
                code.visitLabel(L3);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m013_setAuthenticator(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/security/SecurityHandler;","setAuthenticator",new String[]{ "Lorg/mortbay/jetty/security/Authenticator;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"authenticator");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(68,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(69,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_OBJECT,1,0,new Field("Lorg/mortbay/jetty/security/SecurityHandler;","_authenticator","Lorg/mortbay/jetty/security/Authenticator;"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m014_setCheckWelcomeFiles(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/security/SecurityHandler;","setCheckWelcomeFiles",new String[]{ "Z"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"authenticateWelcomeFiles");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(154,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(155,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_BOOLEAN,1,0,new Field("Lorg/mortbay/jetty/security/SecurityHandler;","_checkWelcomeFiles","Z"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m015_setConstraintMappings(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/security/SecurityHandler;","setConstraintMappings",new String[]{ "[Lorg/mortbay/jetty/security/ConstraintMapping;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(6);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"constraintMappings");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(104,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(105,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(107,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(108,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(110,L4);
                DexLabel L5=new DexLabel();
                ddv.visitStartLocal(0,L5,"i","I",null);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(112,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(113,L7);
                ddv.visitStartLocal(1,L7,"mappings","Ljava/lang/Object;",null);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(114,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(110,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(117,L10);
                ddv.visitEndLocal(0,L10);
                ddv.visitEndLocal(1,L10);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_OBJECT,5,4,new Field("Lorg/mortbay/jetty/security/SecurityHandler;","_constraintMappings","[Lorg/mortbay/jetty/security/ConstraintMapping;"));
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,2,4,new Field("Lorg/mortbay/jetty/security/SecurityHandler;","_constraintMappings","[Lorg/mortbay/jetty/security/ConstraintMapping;"));
                code.visitJumpStmt(IF_EQZ,2,-1,L10);
                code.visitLabel(L2);
                code.visitFieldStmt(IPUT_OBJECT,5,4,new Field("Lorg/mortbay/jetty/security/SecurityHandler;","_constraintMappings","[Lorg/mortbay/jetty/security/ConstraintMapping;"));
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,2,4,new Field("Lorg/mortbay/jetty/security/SecurityHandler;","_constraintMap","Lorg/mortbay/jetty/servlet/PathMap;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/jetty/servlet/PathMap;","clear",new String[]{ },"V"));
                code.visitLabel(L4);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L5);
                code.visitFieldStmt(IGET_OBJECT,2,4,new Field("Lorg/mortbay/jetty/security/SecurityHandler;","_constraintMappings","[Lorg/mortbay/jetty/security/ConstraintMapping;"));
                code.visitStmt2R(ARRAY_LENGTH,2,2);
                code.visitJumpStmt(IF_GE,0,2,L10);
                code.visitLabel(L6);
                code.visitFieldStmt(IGET_OBJECT,2,4,new Field("Lorg/mortbay/jetty/security/SecurityHandler;","_constraintMap","Lorg/mortbay/jetty/servlet/PathMap;"));
                code.visitFieldStmt(IGET_OBJECT,3,4,new Field("Lorg/mortbay/jetty/security/SecurityHandler;","_constraintMappings","[Lorg/mortbay/jetty/security/ConstraintMapping;"));
                code.visitStmt3R(AGET_OBJECT,3,3,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Lorg/mortbay/jetty/security/ConstraintMapping;","getPathSpec",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3},new Method("Lorg/mortbay/jetty/servlet/PathMap;","get",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L7);
                code.visitFieldStmt(IGET_OBJECT,2,4,new Field("Lorg/mortbay/jetty/security/SecurityHandler;","_constraintMappings","[Lorg/mortbay/jetty/security/ConstraintMapping;"));
                code.visitStmt3R(AGET_OBJECT,2,2,0);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1,2},new Method("Lorg/mortbay/util/LazyList;","add",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L8);
                code.visitFieldStmt(IGET_OBJECT,2,4,new Field("Lorg/mortbay/jetty/security/SecurityHandler;","_constraintMap","Lorg/mortbay/jetty/servlet/PathMap;"));
                code.visitFieldStmt(IGET_OBJECT,3,4,new Field("Lorg/mortbay/jetty/security/SecurityHandler;","_constraintMappings","[Lorg/mortbay/jetty/security/ConstraintMapping;"));
                code.visitStmt3R(AGET_OBJECT,3,3,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Lorg/mortbay/jetty/security/ConstraintMapping;","getPathSpec",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3,1},new Method("Lorg/mortbay/jetty/servlet/PathMap;","put",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitLabel(L9);
                code.visitStmt2R1N(ADD_INT_LIT8,0,0,1);
                code.visitJumpStmt(GOTO,-1,-1,L5);
                code.visitLabel(L10);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m016_setUserRealm(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/security/SecurityHandler;","setUserRealm",new String[]{ "Lorg/mortbay/jetty/security/UserRealm;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"userRealm");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(86,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(87,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_OBJECT,1,0,new Field("Lorg/mortbay/jetty/security/SecurityHandler;","_userRealm","Lorg/mortbay/jetty/security/UserRealm;"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
