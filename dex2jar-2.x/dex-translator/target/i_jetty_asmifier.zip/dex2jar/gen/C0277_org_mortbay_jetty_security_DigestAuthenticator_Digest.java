package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0277_org_mortbay_jetty_security_DigestAuthenticator_Digest {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(0,"Lorg/mortbay/jetty/security/DigestAuthenticator$Digest;","Lorg/mortbay/jetty/security/Credential;",new String[]{ });
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("DigestAuthenticator.java");
        if(cv!=null){
            DexAnnotationVisitor av00 = cv.visitAnnotation("Ldalvik/annotation/EnclosingClass;", Visibility.SYSTEM);
            if(av00 != null) {
                av00.visit("value", new DexType("Lorg/mortbay/jetty/security/DigestAuthenticator;"));
                av00.visitEnd();
            }
        }
        if(cv!=null){
            DexAnnotationVisitor av00 = cv.visitAnnotation("Ldalvik/annotation/InnerClass;", Visibility.SYSTEM);
            if(av00 != null) {
                av00.visit("accessFlags",  Integer.valueOf(10));
                av00.visit("name", "Digest");
                av00.visitEnd();
            }
        }
        f000_cnonce(cv);
        f001_method(cv);
        f002_nc(cv);
        f003_nonce(cv);
        f004_qop(cv);
        f005_realm(cv);
        f006_response(cv);
        f007_uri(cv);
        f008_username(cv);
        m000__init_(cv);
        m001_check(cv);
        m002_toString(cv);
    }
    public static void f000_cnonce(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(0, new Field("Lorg/mortbay/jetty/security/DigestAuthenticator$Digest;","cnonce","Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f001_method(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(0, new Field("Lorg/mortbay/jetty/security/DigestAuthenticator$Digest;","method","Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f002_nc(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(0, new Field("Lorg/mortbay/jetty/security/DigestAuthenticator$Digest;","nc","Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f003_nonce(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(0, new Field("Lorg/mortbay/jetty/security/DigestAuthenticator$Digest;","nonce","Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f004_qop(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(0, new Field("Lorg/mortbay/jetty/security/DigestAuthenticator$Digest;","qop","Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f005_realm(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(0, new Field("Lorg/mortbay/jetty/security/DigestAuthenticator$Digest;","realm","Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f006_response(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(0, new Field("Lorg/mortbay/jetty/security/DigestAuthenticator$Digest;","response","Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f007_uri(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(0, new Field("Lorg/mortbay/jetty/security/DigestAuthenticator$Digest;","uri","Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f008_username(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(0, new Field("Lorg/mortbay/jetty/security/DigestAuthenticator$Digest;","username","Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void m000__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_CONSTRUCTOR, new Method("Lorg/mortbay/jetty/security/DigestAuthenticator$Digest;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"m");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(273,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(261,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(262,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(263,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(264,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(265,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(266,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(267,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(268,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(269,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(274,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(275,L12);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1},new Method("Lorg/mortbay/jetty/security/Credential;","<init>",new String[]{ },"V"));
                code.visitLabel(L2);
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/jetty/security/DigestAuthenticator$Digest;","method","Ljava/lang/String;"));
                code.visitLabel(L3);
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/jetty/security/DigestAuthenticator$Digest;","username","Ljava/lang/String;"));
                code.visitLabel(L4);
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/jetty/security/DigestAuthenticator$Digest;","realm","Ljava/lang/String;"));
                code.visitLabel(L5);
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/jetty/security/DigestAuthenticator$Digest;","nonce","Ljava/lang/String;"));
                code.visitLabel(L6);
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/jetty/security/DigestAuthenticator$Digest;","nc","Ljava/lang/String;"));
                code.visitLabel(L7);
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/jetty/security/DigestAuthenticator$Digest;","cnonce","Ljava/lang/String;"));
                code.visitLabel(L8);
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/jetty/security/DigestAuthenticator$Digest;","qop","Ljava/lang/String;"));
                code.visitLabel(L9);
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/jetty/security/DigestAuthenticator$Digest;","uri","Ljava/lang/String;"));
                code.visitLabel(L10);
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/jetty/security/DigestAuthenticator$Digest;","response","Ljava/lang/String;"));
                code.visitLabel(L11);
                code.visitFieldStmt(IPUT_OBJECT,2,1,new Field("Lorg/mortbay/jetty/security/DigestAuthenticator$Digest;","method","Ljava/lang/String;"));
                code.visitLabel(L12);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001_check(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/security/DigestAuthenticator$Digest;","check",new String[]{ "Ljava/lang/Object;"},"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(11);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ "Ljava/lang/Exception;"});
                DexLabel L3=new DexLabel();
                DexLabel L4=new DexLabel();
                code.visitTryCatch(L3,L4,new DexLabel[]{L2},new String[]{ "Ljava/lang/Exception;"});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"credentials");
                DexLabel L5=new DexLabel();
                ddv.visitPrologue(L5);
                ddv.visitLineNumber(280,L5);
                ddv.visitLineNumber(285,L0);
                ddv.visitStartLocal(6,L0,"password","Ljava/lang/String;",null);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(287,L6);
                ddv.visitStartLocal(5,L6,"md","Ljava/security/MessageDigest;",null);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(292,L7);
                DexLabel L8=new DexLabel();
                ddv.visitEndLocal(10,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(305,L9);
                ddv.visitStartLocal(3,L9,"ha1","[B",null);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(306,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(307,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(308,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(309,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(321,L14);
                ddv.visitStartLocal(4,L14,"ha2","[B",null);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(322,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(323,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(324,L17);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(325,L18);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(326,L19);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(327,L20);
                DexLabel L21=new DexLabel();
                ddv.visitLineNumber(328,L21);
                DexLabel L22=new DexLabel();
                ddv.visitLineNumber(329,L22);
                DexLabel L23=new DexLabel();
                ddv.visitLineNumber(330,L23);
                DexLabel L24=new DexLabel();
                ddv.visitLineNumber(331,L24);
                DexLabel L25=new DexLabel();
                ddv.visitLineNumber(332,L25);
                DexLabel L26=new DexLabel();
                ddv.visitLineNumber(335,L26);
                ddv.visitStartLocal(1,L26,"digest","[B",null);
                DexLabel L27=new DexLabel();
                ddv.visitLineNumber(340,L27);
                ddv.visitEndLocal(5,L27);
                ddv.visitEndLocal(3,L27);
                ddv.visitEndLocal(4,L27);
                ddv.visitEndLocal(1,L27);
                DexLabel L28=new DexLabel();
                ddv.visitLineNumber(280,L28);
                ddv.visitEndLocal(6,L28);
                ddv.visitRestartLocal(10,L28);
                ddv.visitLineNumber(297,L3);
                ddv.visitRestartLocal(5,L3);
                ddv.visitRestartLocal(6,L3);
                DexLabel L29=new DexLabel();
                ddv.visitLineNumber(298,L29);
                DexLabel L30=new DexLabel();
                ddv.visitLineNumber(299,L30);
                DexLabel L31=new DexLabel();
                ddv.visitLineNumber(300,L31);
                DexLabel L32=new DexLabel();
                ddv.visitLineNumber(301,L32);
                DexLabel L33=new DexLabel();
                ddv.visitLineNumber(302,L33);
                DexLabel L34=new DexLabel();
                ddv.visitRestartLocal(3,L34);
                ddv.visitLineNumber(337,L2);
                ddv.visitEndLocal(10,L2);
                ddv.visitEndLocal(5,L2);
                ddv.visitEndLocal(3,L2);
                DexLabel L35=new DexLabel();
                ddv.visitLineNumber(338,L35);
                ddv.visitStartLocal(2,L35,"e","Ljava/lang/Exception;",null);
                DexLabel L36=new DexLabel();
                ddv.visitLineNumber(340,L36);
                code.visitLabel(L5);
                code.visitTypeStmt(INSTANCE_OF,7,10,"Ljava/lang/String;");
                code.visitJumpStmt(IF_EQZ,7,-1,L28);
                code.visitStmt2R(MOVE_OBJECT,0,10);
                code.visitTypeStmt(CHECK_CAST,0,-1,"Ljava/lang/String;");
                code.visitStmt2R(MOVE_OBJECT,7,0);
                code.visitStmt2R(MOVE_OBJECT,6,7);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_STRING,7,"MD5");
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 7},new Method("Ljava/security/MessageDigest;","getInstance",new String[]{ "Ljava/lang/String;"},"Ljava/security/MessageDigest;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitLabel(L6);
                code.visitTypeStmt(INSTANCE_OF,7,10,"Lorg/mortbay/jetty/security/Credential$MD5;");
                code.visitJumpStmt(IF_EQZ,7,-1,L3);
                code.visitLabel(L7);
                code.visitTypeStmt(CHECK_CAST,10,-1,"Lorg/mortbay/jetty/security/Credential$MD5;");
                code.visitLabel(L8);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10},new Method("Lorg/mortbay/jetty/security/Credential$MD5;","getDigest",new String[]{ },"[B"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitLabel(L9);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Ljava/security/MessageDigest;","reset",new String[]{ },"V"));
                code.visitLabel(L10);
                code.visitFieldStmt(IGET_OBJECT,7,9,new Field("Lorg/mortbay/jetty/security/DigestAuthenticator$Digest;","method","Ljava/lang/String;"));
                code.visitFieldStmt(SGET_OBJECT,8,-1,new Field("Lorg/mortbay/util/StringUtil;","__ISO_8859_1","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7,8},new Method("Ljava/lang/String;","getBytes",new String[]{ "Ljava/lang/String;"},"[B"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,7},new Method("Ljava/security/MessageDigest;","update",new String[]{ "[B"},"V"));
                code.visitLabel(L11);
                code.visitConstStmt(CONST_16,7, Integer.valueOf(58)); // int: 0x0000003a  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,7},new Method("Ljava/security/MessageDigest;","update",new String[]{ "B"},"V"));
                code.visitLabel(L12);
                code.visitFieldStmt(IGET_OBJECT,7,9,new Field("Lorg/mortbay/jetty/security/DigestAuthenticator$Digest;","uri","Ljava/lang/String;"));
                code.visitFieldStmt(SGET_OBJECT,8,-1,new Field("Lorg/mortbay/util/StringUtil;","__ISO_8859_1","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7,8},new Method("Ljava/lang/String;","getBytes",new String[]{ "Ljava/lang/String;"},"[B"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,7},new Method("Ljava/security/MessageDigest;","update",new String[]{ "[B"},"V"));
                code.visitLabel(L13);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Ljava/security/MessageDigest;","digest",new String[]{ },"[B"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitLabel(L14);
                code.visitConstStmt(CONST_16,7, Integer.valueOf(16)); // int: 0x00000010  float:0.000000
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 3,7},new Method("Lorg/mortbay/util/TypeUtil;","toString",new String[]{ "[B","I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitFieldStmt(SGET_OBJECT,8,-1,new Field("Lorg/mortbay/util/StringUtil;","__ISO_8859_1","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7,8},new Method("Ljava/lang/String;","getBytes",new String[]{ "Ljava/lang/String;"},"[B"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,7},new Method("Ljava/security/MessageDigest;","update",new String[]{ "[B"},"V"));
                code.visitLabel(L15);
                code.visitConstStmt(CONST_16,7, Integer.valueOf(58)); // int: 0x0000003a  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,7},new Method("Ljava/security/MessageDigest;","update",new String[]{ "B"},"V"));
                code.visitLabel(L16);
                code.visitFieldStmt(IGET_OBJECT,7,9,new Field("Lorg/mortbay/jetty/security/DigestAuthenticator$Digest;","nonce","Ljava/lang/String;"));
                code.visitFieldStmt(SGET_OBJECT,8,-1,new Field("Lorg/mortbay/util/StringUtil;","__ISO_8859_1","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7,8},new Method("Ljava/lang/String;","getBytes",new String[]{ "Ljava/lang/String;"},"[B"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,7},new Method("Ljava/security/MessageDigest;","update",new String[]{ "[B"},"V"));
                code.visitLabel(L17);
                code.visitConstStmt(CONST_16,7, Integer.valueOf(58)); // int: 0x0000003a  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,7},new Method("Ljava/security/MessageDigest;","update",new String[]{ "B"},"V"));
                code.visitLabel(L18);
                code.visitFieldStmt(IGET_OBJECT,7,9,new Field("Lorg/mortbay/jetty/security/DigestAuthenticator$Digest;","nc","Ljava/lang/String;"));
                code.visitFieldStmt(SGET_OBJECT,8,-1,new Field("Lorg/mortbay/util/StringUtil;","__ISO_8859_1","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7,8},new Method("Ljava/lang/String;","getBytes",new String[]{ "Ljava/lang/String;"},"[B"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,7},new Method("Ljava/security/MessageDigest;","update",new String[]{ "[B"},"V"));
                code.visitLabel(L19);
                code.visitConstStmt(CONST_16,7, Integer.valueOf(58)); // int: 0x0000003a  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,7},new Method("Ljava/security/MessageDigest;","update",new String[]{ "B"},"V"));
                code.visitLabel(L20);
                code.visitFieldStmt(IGET_OBJECT,7,9,new Field("Lorg/mortbay/jetty/security/DigestAuthenticator$Digest;","cnonce","Ljava/lang/String;"));
                code.visitFieldStmt(SGET_OBJECT,8,-1,new Field("Lorg/mortbay/util/StringUtil;","__ISO_8859_1","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7,8},new Method("Ljava/lang/String;","getBytes",new String[]{ "Ljava/lang/String;"},"[B"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,7},new Method("Ljava/security/MessageDigest;","update",new String[]{ "[B"},"V"));
                code.visitLabel(L21);
                code.visitConstStmt(CONST_16,7, Integer.valueOf(58)); // int: 0x0000003a  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,7},new Method("Ljava/security/MessageDigest;","update",new String[]{ "B"},"V"));
                code.visitLabel(L22);
                code.visitFieldStmt(IGET_OBJECT,7,9,new Field("Lorg/mortbay/jetty/security/DigestAuthenticator$Digest;","qop","Ljava/lang/String;"));
                code.visitFieldStmt(SGET_OBJECT,8,-1,new Field("Lorg/mortbay/util/StringUtil;","__ISO_8859_1","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7,8},new Method("Ljava/lang/String;","getBytes",new String[]{ "Ljava/lang/String;"},"[B"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,7},new Method("Ljava/security/MessageDigest;","update",new String[]{ "[B"},"V"));
                code.visitLabel(L23);
                code.visitConstStmt(CONST_16,7, Integer.valueOf(58)); // int: 0x0000003a  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,7},new Method("Ljava/security/MessageDigest;","update",new String[]{ "B"},"V"));
                code.visitLabel(L24);
                code.visitConstStmt(CONST_16,7, Integer.valueOf(16)); // int: 0x00000010  float:0.000000
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 4,7},new Method("Lorg/mortbay/util/TypeUtil;","toString",new String[]{ "[B","I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitFieldStmt(SGET_OBJECT,8,-1,new Field("Lorg/mortbay/util/StringUtil;","__ISO_8859_1","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7,8},new Method("Ljava/lang/String;","getBytes",new String[]{ "Ljava/lang/String;"},"[B"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,7},new Method("Ljava/security/MessageDigest;","update",new String[]{ "[B"},"V"));
                code.visitLabel(L25);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Ljava/security/MessageDigest;","digest",new String[]{ },"[B"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L26);
                code.visitConstStmt(CONST_16,7, Integer.valueOf(16)); // int: 0x00000010  float:0.000000
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1,7},new Method("Lorg/mortbay/util/TypeUtil;","toString",new String[]{ "[B","I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitFieldStmt(IGET_OBJECT,8,9,new Field("Lorg/mortbay/jetty/security/DigestAuthenticator$Digest;","response","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7,8},new Method("Ljava/lang/String;","equalsIgnoreCase",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitLabel(L1);
                code.visitStmt1R(MOVE_RESULT,7);
                code.visitLabel(L27);
                code.visitStmt1R(RETURN,7);
                code.visitLabel(L28);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10},new Method("Ljava/lang/Object;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitStmt2R(MOVE_OBJECT,6,7);
                code.visitJumpStmt(GOTO_16,-1,-1,L0);
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,7,9,new Field("Lorg/mortbay/jetty/security/DigestAuthenticator$Digest;","username","Ljava/lang/String;"));
                code.visitFieldStmt(SGET_OBJECT,8,-1,new Field("Lorg/mortbay/util/StringUtil;","__ISO_8859_1","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7,8},new Method("Ljava/lang/String;","getBytes",new String[]{ "Ljava/lang/String;"},"[B"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,7},new Method("Ljava/security/MessageDigest;","update",new String[]{ "[B"},"V"));
                code.visitLabel(L29);
                code.visitConstStmt(CONST_16,7, Integer.valueOf(58)); // int: 0x0000003a  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,7},new Method("Ljava/security/MessageDigest;","update",new String[]{ "B"},"V"));
                code.visitLabel(L30);
                code.visitFieldStmt(IGET_OBJECT,7,9,new Field("Lorg/mortbay/jetty/security/DigestAuthenticator$Digest;","realm","Ljava/lang/String;"));
                code.visitFieldStmt(SGET_OBJECT,8,-1,new Field("Lorg/mortbay/util/StringUtil;","__ISO_8859_1","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7,8},new Method("Ljava/lang/String;","getBytes",new String[]{ "Ljava/lang/String;"},"[B"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,7},new Method("Ljava/security/MessageDigest;","update",new String[]{ "[B"},"V"));
                code.visitLabel(L31);
                code.visitConstStmt(CONST_16,7, Integer.valueOf(58)); // int: 0x0000003a  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,7},new Method("Ljava/security/MessageDigest;","update",new String[]{ "B"},"V"));
                code.visitLabel(L32);
                code.visitFieldStmt(SGET_OBJECT,7,-1,new Field("Lorg/mortbay/util/StringUtil;","__ISO_8859_1","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,7},new Method("Ljava/lang/String;","getBytes",new String[]{ "Ljava/lang/String;"},"[B"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,7},new Method("Ljava/security/MessageDigest;","update",new String[]{ "[B"},"V"));
                code.visitLabel(L33);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Ljava/security/MessageDigest;","digest",new String[]{ },"[B"));
                code.visitLabel(L4);
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitLabel(L34);
                code.visitJumpStmt(GOTO_16,-1,-1,L9);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,7);
                code.visitStmt2R(MOVE_OBJECT,2,7);
                code.visitLabel(L35);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 2},new Method("Lorg/mortbay/log/Log;","warn",new String[]{ "Ljava/lang/Throwable;"},"V"));
                code.visitLabel(L36);
                code.visitConstStmt(CONST_4,7, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L27);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m002_toString(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/security/DigestAuthenticator$Digest;","toString",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(345,L0);
                code.visitLabel(L0);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/jetty/security/DigestAuthenticator$Digest;","username","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitConstStmt(CONST_STRING,1,",");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/jetty/security/DigestAuthenticator$Digest;","response","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
