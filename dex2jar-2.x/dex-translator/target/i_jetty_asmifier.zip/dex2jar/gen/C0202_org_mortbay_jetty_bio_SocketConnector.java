package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0202_org_mortbay_jetty_bio_SocketConnector {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(ACC_PUBLIC,"Lorg/mortbay/jetty/bio/SocketConnector;","Lorg/mortbay/jetty/AbstractConnector;",new String[]{ });
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("SocketConnector.java");
        if(cv!=null){
            DexAnnotationVisitor av00 = cv.visitAnnotation("Ldalvik/annotation/MemberClasses;", Visibility.SYSTEM);
            if(av00 != null) {
                {
                    DexAnnotationVisitor av01 = av00.visitArray("value");
                    if(av01 != null) {
                        av01.visit(null, new DexType("Lorg/mortbay/jetty/bio/SocketConnector$Connection;"));
                        av01.visitEnd();
                    }
                }
                av00.visitEnd();
            }
        }
        f000__connections(cv);
        f001__serverSocket(cv);
        m000__init_(cv);
        m001_access$000(cv);
        m002_access$100(cv);
        m003_accept(cv);
        m004_close(cv);
        m005_customize(cv);
        m006_doStart(cv);
        m007_doStop(cv);
        m008_getConnection(cv);
        m009_getLocalPort(cv);
        m010_newBuffer(cv);
        m011_newHttpConnection(cv);
        m012_newServerSocket(cv);
        m013_open(cv);
    }
    public static void f000__connections(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PROTECTED, new Field("Lorg/mortbay/jetty/bio/SocketConnector;","_connections","Ljava/util/Set;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f001__serverSocket(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PROTECTED, new Field("Lorg/mortbay/jetty/bio/SocketConnector;","_serverSocket","Ljava/net/ServerSocket;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void m000__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/jetty/bio/SocketConnector;","<init>",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(1);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(59,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(60,L1);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Lorg/mortbay/jetty/AbstractConnector;","<init>",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001_access$000(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_STATIC|ACC_SYNTHETIC, new Method("Lorg/mortbay/jetty/bio/SocketConnector;","access$000",new String[]{ "Lorg/mortbay/jetty/bio/SocketConnector;","Lorg/mortbay/jetty/HttpConnection;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"x0");
                ddv.visitParameterName(1,"x1");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(49,L0);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Lorg/mortbay/jetty/bio/SocketConnector;","connectionOpened",new String[]{ "Lorg/mortbay/jetty/HttpConnection;"},"V"));
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m002_access$100(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_STATIC|ACC_SYNTHETIC, new Method("Lorg/mortbay/jetty/bio/SocketConnector;","access$100",new String[]{ "Lorg/mortbay/jetty/bio/SocketConnector;","Lorg/mortbay/jetty/HttpConnection;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"x0");
                ddv.visitParameterName(1,"x1");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(49,L0);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Lorg/mortbay/jetty/bio/SocketConnector;","connectionClosed",new String[]{ "Lorg/mortbay/jetty/HttpConnection;"},"V"));
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m003_accept(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/bio/SocketConnector;","accept",new String[]{ "I"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visit(null, new DexType("Ljava/lang/InterruptedException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"acceptorID");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(99,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(100,L1);
                ddv.visitStartLocal(1,L1,"socket","Ljava/net/Socket;",null);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(102,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(103,L3);
                ddv.visitStartLocal(0,L3,"connection","Lorg/mortbay/jetty/bio/SocketConnector$Connection;",null);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(104,L4);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,2,3,new Field("Lorg/mortbay/jetty/bio/SocketConnector;","_serverSocket","Ljava/net/ServerSocket;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Ljava/net/ServerSocket;","accept",new String[]{ },"Ljava/net/Socket;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,1},new Method("Lorg/mortbay/jetty/bio/SocketConnector;","configure",new String[]{ "Ljava/net/Socket;"},"V"));
                code.visitLabel(L2);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Lorg/mortbay/jetty/bio/SocketConnector$Connection;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,3,1},new Method("Lorg/mortbay/jetty/bio/SocketConnector$Connection;","<init>",new String[]{ "Lorg/mortbay/jetty/bio/SocketConnector;","Ljava/net/Socket;"},"V"));
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/jetty/bio/SocketConnector$Connection;","dispatch",new String[]{ },"V"));
                code.visitLabel(L4);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m004_close(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/bio/SocketConnector;","close",new String[]{ },"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(90,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(91,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(92,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(93,L3);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/bio/SocketConnector;","_serverSocket","Ljava/net/ServerSocket;"));
                code.visitJumpStmt(IF_EQZ,0,-1,L2);
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/bio/SocketConnector;","_serverSocket","Ljava/net/ServerSocket;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/net/ServerSocket;","close",new String[]{ },"V"));
                code.visitLabel(L2);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/jetty/bio/SocketConnector;","_serverSocket","Ljava/net/ServerSocket;"));
                code.visitLabel(L3);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m005_customize(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/bio/SocketConnector;","customize",new String[]{ "Lorg/mortbay/io/EndPoint;","Lorg/mortbay/jetty/Request;"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(7);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"endpoint");
                ddv.visitParameterName(1,"request");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(125,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(126,L1);
                ddv.visitStartLocal(1,L1,"connection","Lorg/mortbay/jetty/bio/SocketConnector$Connection;",null);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(128,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(129,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(132,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(133,L5);
                code.visitLabel(L0);
                code.visitStmt2R(MOVE_OBJECT,0,5);
                code.visitTypeStmt(CHECK_CAST,0,-1,"Lorg/mortbay/jetty/bio/SocketConnector$Connection;");
                code.visitStmt2R(MOVE_OBJECT,1,0);
                code.visitLabel(L1);
                code.visitFieldStmt(IGET,2,1,new Field("Lorg/mortbay/jetty/bio/SocketConnector$Connection;","_sotimeout","I"));
                code.visitFieldStmt(IGET,3,4,new Field("Lorg/mortbay/jetty/bio/SocketConnector;","_maxIdleTime","I"));
                code.visitJumpStmt(IF_EQ,2,3,L4);
                code.visitLabel(L2);
                code.visitFieldStmt(IGET,2,4,new Field("Lorg/mortbay/jetty/bio/SocketConnector;","_maxIdleTime","I"));
                code.visitFieldStmt(IPUT,2,1,new Field("Lorg/mortbay/jetty/bio/SocketConnector$Connection;","_sotimeout","I"));
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 5},new Method("Lorg/mortbay/io/EndPoint;","getTransport",new String[]{ },"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitTypeStmt(CHECK_CAST,2,-1,"Ljava/net/Socket;");
                code.visitFieldStmt(IGET,3,4,new Field("Lorg/mortbay/jetty/bio/SocketConnector;","_maxIdleTime","I"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3},new Method("Ljava/net/Socket;","setSoTimeout",new String[]{ "I"},"V"));
                code.visitLabel(L4);
                code.visitMethodStmt(INVOKE_SUPER,new int[]{ 4,5,6},new Method("Lorg/mortbay/jetty/AbstractConnector;","customize",new String[]{ "Lorg/mortbay/io/EndPoint;","Lorg/mortbay/jetty/Request;"},"V"));
                code.visitLabel(L5);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m006_doStart(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Lorg/mortbay/jetty/bio/SocketConnector;","doStart",new String[]{ },"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/lang/Exception;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(146,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(147,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(148,L2);
                code.visitLabel(L0);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/util/HashSet;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/util/HashSet;","<init>",new String[]{ },"V"));
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/jetty/bio/SocketConnector;","_connections","Ljava/util/Set;"));
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_SUPER,new int[]{ 1},new Method("Lorg/mortbay/jetty/AbstractConnector;","doStart",new String[]{ },"V"));
                code.visitLabel(L2);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m007_doStop(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Lorg/mortbay/jetty/bio/SocketConnector;","doStop",new String[]{ },"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/lang/Exception;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(7);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexLabel L3=new DexLabel();
                DexLabel L4=new DexLabel();
                code.visitTryCatch(L1,L3,new DexLabel[]{L4},new String[]{ null});
                DexLabel L5=new DexLabel();
                DexLabel L6=new DexLabel();
                code.visitTryCatch(L5,L6,new DexLabel[]{L2},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L7=new DexLabel();
                ddv.visitPrologue(L7);
                ddv.visitLineNumber(153,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(154,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(156,L9);
                ddv.visitStartLocal(2,L9,"set","Ljava/util/Set;",null);
                ddv.visitLineNumber(158,L0);
                ddv.visitLineNumber(159,L1);
                ddv.visitStartLocal(3,L1,"set","Ljava/util/Set;",null);
                ddv.visitLineNumber(161,L3);
                ddv.visitEndLocal(2,L3);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(162,L10);
                ddv.visitStartLocal(1,L10,"iter","Ljava/util/Iterator;",null);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(164,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(165,L12);
                ddv.visitStartLocal(0,L12,"connection","Lorg/mortbay/jetty/bio/SocketConnector$Connection;",null);
                ddv.visitLineNumber(159,L2);
                ddv.visitEndLocal(3,L2);
                ddv.visitEndLocal(1,L2);
                ddv.visitEndLocal(0,L2);
                ddv.visitRestartLocal(2,L2);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(167,L13);
                ddv.visitEndLocal(2,L13);
                ddv.visitRestartLocal(1,L13);
                ddv.visitRestartLocal(3,L13);
                ddv.visitLineNumber(159,L4);
                ddv.visitEndLocal(1,L4);
                DexLabel L14=new DexLabel();
                ddv.visitRestartLocal(2,L14);
                code.visitLabel(L7);
                code.visitMethodStmt(INVOKE_SUPER,new int[]{ 6},new Method("Lorg/mortbay/jetty/AbstractConnector;","doStop",new String[]{ },"V"));
                code.visitLabel(L8);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L9);
                code.visitFieldStmt(IGET_OBJECT,4,6,new Field("Lorg/mortbay/jetty/bio/SocketConnector;","_connections","Ljava/util/Set;"));
                code.visitStmt1R(MONITOR_ENTER,4);
                code.visitLabel(L0);
                code.visitTypeStmt(NEW_INSTANCE,3,-1,"Ljava/util/HashSet;");
                code.visitFieldStmt(IGET_OBJECT,5,6,new Field("Lorg/mortbay/jetty/bio/SocketConnector;","_connections","Ljava/util/Set;"));
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 3,5},new Method("Ljava/util/HashSet;","<init>",new String[]{ "Ljava/util/Collection;"},"V"));
                code.visitLabel(L1);
                code.visitStmt1R(MONITOR_EXIT,4);
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 3},new Method("Ljava/util/Set;","iterator",new String[]{ },"Ljava/util/Iterator;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L10);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 1},new Method("Ljava/util/Iterator;","hasNext",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,4);
                code.visitJumpStmt(IF_EQZ,4,-1,L13);
                code.visitLabel(L11);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 1},new Method("Ljava/util/Iterator;","next",new String[]{ },"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitTypeStmt(CHECK_CAST,0,-1,"Lorg/mortbay/jetty/bio/SocketConnector$Connection;");
                code.visitLabel(L12);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/jetty/bio/SocketConnector$Connection;","close",new String[]{ },"V"));
                code.visitJumpStmt(GOTO,-1,-1,L10);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,5);
                code.visitLabel(L5);
                code.visitStmt1R(MONITOR_EXIT,4);
                code.visitLabel(L6);
                code.visitStmt1R(THROW,5);
                code.visitLabel(L13);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L4);
                code.visitStmt1R(MOVE_EXCEPTION,5);
                code.visitStmt2R(MOVE_OBJECT,2,3);
                code.visitLabel(L14);
                code.visitJumpStmt(GOTO,-1,-1,L5);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m008_getConnection(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/bio/SocketConnector;","getConnection",new String[]{ },"Ljava/lang/Object;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(65,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/bio/SocketConnector;","_serverSocket","Ljava/net/ServerSocket;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m009_getLocalPort(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/bio/SocketConnector;","getLocalPort",new String[]{ },"I"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(138,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(139,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(140,L2);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/bio/SocketConnector;","_serverSocket","Ljava/net/ServerSocket;"));
                code.visitJumpStmt(IF_EQZ,0,-1,L1);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/bio/SocketConnector;","_serverSocket","Ljava/net/ServerSocket;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/net/ServerSocket;","isClosed",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                DexLabel L3=new DexLabel();
                code.visitJumpStmt(IF_EQZ,0,-1,L3);
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(-1)); // int: 0xffffffff  float:NaN
                code.visitLabel(L2);
                code.visitStmt1R(RETURN,0);
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/bio/SocketConnector;","_serverSocket","Ljava/net/ServerSocket;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/net/ServerSocket;","getLocalPort",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m010_newBuffer(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Lorg/mortbay/jetty/bio/SocketConnector;","newBuffer",new String[]{ "I"},"Lorg/mortbay/io/Buffer;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"size");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(118,L0);
                code.visitLabel(L0);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Lorg/mortbay/io/ByteArrayBuffer;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,2},new Method("Lorg/mortbay/io/ByteArrayBuffer;","<init>",new String[]{ "I"},"V"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m011_newHttpConnection(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Lorg/mortbay/jetty/bio/SocketConnector;","newHttpConnection",new String[]{ "Lorg/mortbay/io/EndPoint;"},"Lorg/mortbay/jetty/HttpConnection;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"endpoint");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(112,L0);
                code.visitLabel(L0);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Lorg/mortbay/jetty/HttpConnection;");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/jetty/bio/SocketConnector;","getServer",new String[]{ },"Lorg/mortbay/jetty/Server;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,2,3,1},new Method("Lorg/mortbay/jetty/HttpConnection;","<init>",new String[]{ "Lorg/mortbay/jetty/Connector;","Lorg/mortbay/io/EndPoint;","Lorg/mortbay/jetty/Server;"},"V"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m012_newServerSocket(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Lorg/mortbay/jetty/bio/SocketConnector;","newServerSocket",new String[]{ "Ljava/lang/String;","I","I"},"Ljava/net/ServerSocket;"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(7);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"host");
                ddv.visitParameterName(1,"port");
                ddv.visitParameterName(2,"backlog");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(80,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(84,L1);
                ddv.visitStartLocal(0,L1,"ss","Ljava/net/ServerSocket;",null);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(80,L2);
                ddv.visitEndLocal(0,L2);
                code.visitLabel(L0);
                code.visitJumpStmt(IF_NEZ,4,-1,L2);
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Ljava/net/ServerSocket;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1,5,6},new Method("Ljava/net/ServerSocket;","<init>",new String[]{ "I","I"},"V"));
                code.visitStmt2R(MOVE_OBJECT,0,1);
                code.visitLabel(L1);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitLabel(L2);
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Ljava/net/ServerSocket;");
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 4},new Method("Ljava/net/InetAddress;","getByName",new String[]{ "Ljava/lang/String;"},"Ljava/net/InetAddress;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1,5,6,2},new Method("Ljava/net/ServerSocket;","<init>",new String[]{ "I","I","Ljava/net/InetAddress;"},"V"));
                code.visitStmt2R(MOVE_OBJECT,0,1);
                code.visitJumpStmt(GOTO,-1,-1,L1);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m013_open(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/bio/SocketConnector;","open",new String[]{ },"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(72,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(73,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(74,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(75,L3);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,3,new Field("Lorg/mortbay/jetty/bio/SocketConnector;","_serverSocket","Ljava/net/ServerSocket;"));
                code.visitJumpStmt(IF_EQZ,0,-1,L1);
                code.visitFieldStmt(IGET_OBJECT,0,3,new Field("Lorg/mortbay/jetty/bio/SocketConnector;","_serverSocket","Ljava/net/ServerSocket;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/net/ServerSocket;","isClosed",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_EQZ,0,-1,L2);
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Lorg/mortbay/jetty/bio/SocketConnector;","getHost",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Lorg/mortbay/jetty/bio/SocketConnector;","getPort",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Lorg/mortbay/jetty/bio/SocketConnector;","getAcceptQueueSize",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,0,1,2},new Method("Lorg/mortbay/jetty/bio/SocketConnector;","newServerSocket",new String[]{ "Ljava/lang/String;","I","I"},"Ljava/net/ServerSocket;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(IPUT_OBJECT,0,3,new Field("Lorg/mortbay/jetty/bio/SocketConnector;","_serverSocket","Ljava/net/ServerSocket;"));
                code.visitLabel(L2);
                code.visitFieldStmt(IGET_OBJECT,0,3,new Field("Lorg/mortbay/jetty/bio/SocketConnector;","_serverSocket","Ljava/net/ServerSocket;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Lorg/mortbay/jetty/bio/SocketConnector;","getReuseAddress",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/net/ServerSocket;","setReuseAddress",new String[]{ "Z"},"V"));
                code.visitLabel(L3);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
