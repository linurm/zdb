package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0105_org_mortbay_io_AbstractBuffer {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(ACC_PUBLIC|ACC_ABSTRACT,"Lorg/mortbay/io/AbstractBuffer;","Ljava/lang/Object;",new String[]{ "Lorg/mortbay/io/Buffer;"});
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("AbstractBuffer.java");
        f000_$assertionsDisabled(cv);
        f001___IMMUTABLE(cv);
        f002___READONLY(cv);
        f003___READWRITE(cv);
        f004___VOLATILE(cv);
        f005__access(cv);
        f006__get(cv);
        f007__hash(cv);
        f008__hashGet(cv);
        f009__hashPut(cv);
        f010__mark(cv);
        f011__put(cv);
        f012__string(cv);
        f013__view(cv);
        f014__volatile(cv);
        m000__clinit_(cv);
        m001__init_(cv);
        m002_asArray(cv);
        m003_asImmutableBuffer(cv);
        m004_asMutableBuffer(cv);
        m005_asNonVolatileBuffer(cv);
        m006_asReadOnlyBuffer(cv);
        m007_buffer(cv);
        m008_clear(cv);
        m009_compact(cv);
        m010_duplicate(cv);
        m011_equals(cv);
        m012_equalsIgnoreCase(cv);
        m013_get(cv);
        m014_get(cv);
        m015_get(cv);
        m016_getIndex(cv);
        m017_hasContent(cv);
        m018_hashCode(cv);
        m019_isImmutable(cv);
        m020_isReadOnly(cv);
        m021_isVolatile(cv);
        m022_length(cv);
        m023_mark(cv);
        m024_mark(cv);
        m025_markIndex(cv);
        m026_peek(cv);
        m027_peek(cv);
        m028_poke(cv);
        m029_poke(cv);
        m030_put(cv);
        m031_put(cv);
        m032_put(cv);
        m033_put(cv);
        m034_putIndex(cv);
        m035_readFrom(cv);
        m036_reset(cv);
        m037_rewind(cv);
        m038_setGetIndex(cv);
        m039_setMarkIndex(cv);
        m040_setPutIndex(cv);
        m041_skip(cv);
        m042_slice(cv);
        m043_sliceFromMark(cv);
        m044_sliceFromMark(cv);
        m045_space(cv);
        m046_toDebugString(cv);
        m047_toDetailString(cv);
        m048_toString(cv);
        m049_writeTo(cv);
    }
    public static void f000_$assertionsDisabled(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_STATIC|ACC_FINAL|ACC_SYNTHETIC, new Field("Lorg/mortbay/io/AbstractBuffer;","$assertionsDisabled","Z"), Boolean.valueOf(false));
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f001___IMMUTABLE(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PROTECTED|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/io/AbstractBuffer;","__IMMUTABLE","Ljava/lang/String;"), "IMMUTABLE");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f002___READONLY(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PROTECTED|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/io/AbstractBuffer;","__READONLY","Ljava/lang/String;"), "READONLY");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f003___READWRITE(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PROTECTED|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/io/AbstractBuffer;","__READWRITE","Ljava/lang/String;"), "READWRITE");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f004___VOLATILE(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PROTECTED|ACC_STATIC|ACC_FINAL, new Field("Lorg/mortbay/io/AbstractBuffer;","__VOLATILE","Ljava/lang/String;"), "VOLATILE");
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f005__access(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PROTECTED, new Field("Lorg/mortbay/io/AbstractBuffer;","_access","I"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f006__get(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PROTECTED, new Field("Lorg/mortbay/io/AbstractBuffer;","_get","I"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f007__hash(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PROTECTED, new Field("Lorg/mortbay/io/AbstractBuffer;","_hash","I"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f008__hashGet(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PROTECTED, new Field("Lorg/mortbay/io/AbstractBuffer;","_hashGet","I"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f009__hashPut(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PROTECTED, new Field("Lorg/mortbay/io/AbstractBuffer;","_hashPut","I"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f010__mark(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PROTECTED, new Field("Lorg/mortbay/io/AbstractBuffer;","_mark","I"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f011__put(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PROTECTED, new Field("Lorg/mortbay/io/AbstractBuffer;","_put","I"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f012__string(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PROTECTED, new Field("Lorg/mortbay/io/AbstractBuffer;","_string","Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f013__view(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PROTECTED, new Field("Lorg/mortbay/io/AbstractBuffer;","_view","Lorg/mortbay/io/View;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f014__volatile(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PROTECTED, new Field("Lorg/mortbay/io/AbstractBuffer;","_volatile","Z"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void m000__clinit_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_STATIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/io/AbstractBuffer;","<clinit>",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(1);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(25,L0);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_CLASS,0,new DexType("Lorg/mortbay/io/AbstractBuffer;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/lang/Class;","desiredAssertionStatus",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                DexLabel L1=new DexLabel();
                code.visitJumpStmt(IF_NEZ,0,-1,L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                DexLabel L2=new DexLabel();
                code.visitLabel(L2);
                code.visitFieldStmt(SPUT_BOOLEAN,0,-1,new Field("Lorg/mortbay/io/AbstractBuffer;","$assertionsDisabled","Z"));
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/io/AbstractBuffer;","<init>",new String[]{ "I","Z"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"access");
                ddv.visitParameterName(1,"isVolatile");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(51,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(52,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(53,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(54,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(55,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(56,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(57,L6);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2},new Method("Ljava/lang/Object;","<init>",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitJumpStmt(IF_NEZ,3,-1,L3);
                code.visitJumpStmt(IF_EQZ,4,-1,L3);
                code.visitLabel(L2);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/lang/IllegalArgumentException;");
                code.visitConstStmt(CONST_STRING,1,"IMMUTABLE && VOLATILE");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1},new Method("Ljava/lang/IllegalArgumentException;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitStmt1R(THROW,0);
                code.visitLabel(L3);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(-1)); // int: 0xffffffff  float:NaN
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,0},new Method("Lorg/mortbay/io/AbstractBuffer;","setMarkIndex",new String[]{ "I"},"V"));
                code.visitLabel(L4);
                code.visitFieldStmt(IPUT,3,2,new Field("Lorg/mortbay/io/AbstractBuffer;","_access","I"));
                code.visitLabel(L5);
                code.visitFieldStmt(IPUT_BOOLEAN,4,2,new Field("Lorg/mortbay/io/AbstractBuffer;","_volatile","Z"));
                code.visitLabel(L6);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m002_asArray(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/io/AbstractBuffer;","asArray",new String[]{ },"[B"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(6);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(64,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(65,L2);
                ddv.visitStartLocal(1,L2,"bytes","[B",null);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(66,L3);
                ddv.visitStartLocal(0,L3,"array","[B",null);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(67,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(70,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(69,L6);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,4, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Lorg/mortbay/io/AbstractBuffer;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitTypeStmt(NEW_ARRAY,1,2,"[B");
                code.visitLabel(L2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Lorg/mortbay/io/AbstractBuffer;","array",new String[]{ },"[B"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L3);
                code.visitJumpStmt(IF_EQZ,0,-1,L6);
                code.visitLabel(L4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Lorg/mortbay/io/AbstractBuffer;","getIndex",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitStmt2R(ARRAY_LENGTH,3,1);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0,2,1,4,3},new Method("Lorg/mortbay/io/Portable;","arraycopy",new String[]{ "[B","I","[B","I","I"},"V"));
                code.visitLabel(L5);
                code.visitStmt1R(RETURN_OBJECT,1);
                code.visitLabel(L6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Lorg/mortbay/io/AbstractBuffer;","getIndex",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Lorg/mortbay/io/AbstractBuffer;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,2,1,4,3},new Method("Lorg/mortbay/io/AbstractBuffer;","peek",new String[]{ "I","[B","I","I"},"I"));
                code.visitJumpStmt(GOTO,-1,-1,L5);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m003_asImmutableBuffer(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/io/AbstractBuffer;","asImmutableBuffer",new String[]{ },"Lorg/mortbay/io/Buffer;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(93,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(94,L1);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Lorg/mortbay/io/AbstractBuffer;","isImmutable",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                DexLabel L2=new DexLabel();
                code.visitJumpStmt(IF_EQZ,0,-1,L2);
                code.visitStmt2R(MOVE_OBJECT,0,1);
                code.visitLabel(L1);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitLabel(L2);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,0},new Method("Lorg/mortbay/io/AbstractBuffer;","duplicate",new String[]{ "I"},"Lorg/mortbay/io/ByteArrayBuffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitJumpStmt(GOTO,-1,-1,L1);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m004_asMutableBuffer(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/io/AbstractBuffer;","asMutableBuffer",new String[]{ },"Lorg/mortbay/io/Buffer;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(7);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(108,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(115,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(110,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(111,L3);
                ddv.visitStartLocal(1,L3,"b","Lorg/mortbay/io/Buffer;",null);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(113,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(115,L5);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Lorg/mortbay/io/AbstractBuffer;","isImmutable",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_NEZ,0,-1,L2);
                code.visitStmt2R(MOVE_OBJECT,0,6);
                code.visitLabel(L1);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitLabel(L2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Lorg/mortbay/io/AbstractBuffer;","buffer",new String[]{ },"Lorg/mortbay/io/Buffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 1},new Method("Lorg/mortbay/io/Buffer;","isReadOnly",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_EQZ,0,-1,L5);
                code.visitLabel(L4);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(2)); // int: 0x00000002  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,0},new Method("Lorg/mortbay/io/AbstractBuffer;","duplicate",new String[]{ "I"},"Lorg/mortbay/io/ByteArrayBuffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitJumpStmt(GOTO,-1,-1,L1);
                code.visitLabel(L5);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Lorg/mortbay/io/View;");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Lorg/mortbay/io/AbstractBuffer;","markIndex",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Lorg/mortbay/io/AbstractBuffer;","getIndex",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Lorg/mortbay/io/AbstractBuffer;","putIndex",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,4);
                code.visitFieldStmt(IGET,5,6,new Field("Lorg/mortbay/io/AbstractBuffer;","_access","I"));
                code.visitMethodStmt(INVOKE_DIRECT_RANGE,new int[]{ 0,1,2,3,4,5},new Method("Lorg/mortbay/io/View;","<init>",new String[]{ "Lorg/mortbay/io/Buffer;","I","I","I","I"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L1);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m005_asNonVolatileBuffer(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/io/AbstractBuffer;","asNonVolatileBuffer",new String[]{ },"Lorg/mortbay/io/Buffer;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(87,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(88,L1);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Lorg/mortbay/io/AbstractBuffer;","isVolatile",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                DexLabel L2=new DexLabel();
                code.visitJumpStmt(IF_NEZ,0,-1,L2);
                code.visitStmt2R(MOVE_OBJECT,0,1);
                code.visitLabel(L1);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitLabel(L2);
                code.visitFieldStmt(IGET,0,1,new Field("Lorg/mortbay/io/AbstractBuffer;","_access","I"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,0},new Method("Lorg/mortbay/io/AbstractBuffer;","duplicate",new String[]{ "I"},"Lorg/mortbay/io/ByteArrayBuffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitJumpStmt(GOTO,-1,-1,L1);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m006_asReadOnlyBuffer(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/io/AbstractBuffer;","asReadOnlyBuffer",new String[]{ },"Lorg/mortbay/io/Buffer;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(7);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(102,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(103,L1);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Lorg/mortbay/io/AbstractBuffer;","isReadOnly",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                DexLabel L2=new DexLabel();
                code.visitJumpStmt(IF_EQZ,0,-1,L2);
                code.visitStmt2R(MOVE_OBJECT,0,6);
                code.visitLabel(L1);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitLabel(L2);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Lorg/mortbay/io/View;");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Lorg/mortbay/io/AbstractBuffer;","markIndex",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Lorg/mortbay/io/AbstractBuffer;","getIndex",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Lorg/mortbay/io/AbstractBuffer;","putIndex",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,4);
                code.visitConstStmt(CONST_4,5, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitStmt2R(MOVE_OBJECT,1,6);
                code.visitMethodStmt(INVOKE_DIRECT_RANGE,new int[]{ 0,1,2,3,4,5},new Method("Lorg/mortbay/io/View;","<init>",new String[]{ "Lorg/mortbay/io/Buffer;","I","I","I","I"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L1);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m007_buffer(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/io/AbstractBuffer;","buffer",new String[]{ },"Lorg/mortbay/io/Buffer;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(1);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(120,L0);
                code.visitLabel(L0);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m008_clear(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/io/AbstractBuffer;","clear",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(125,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(126,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(127,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(128,L4);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(-1)); // int: 0xffffffff  float:NaN
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,0},new Method("Lorg/mortbay/io/AbstractBuffer;","setMarkIndex",new String[]{ "I"},"V"));
                code.visitLabel(L2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,1},new Method("Lorg/mortbay/io/AbstractBuffer;","setGetIndex",new String[]{ "I"},"V"));
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,1},new Method("Lorg/mortbay/io/AbstractBuffer;","setPutIndex",new String[]{ "I"},"V"));
                code.visitLabel(L4);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m009_compact(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/io/AbstractBuffer;","compact",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(7);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(132,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(133,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(134,L3);
                ddv.visitStartLocal(2,L3,"s","I",null);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(136,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(137,L5);
                ddv.visitStartLocal(0,L5,"array","[B",null);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(138,L6);
                ddv.visitStartLocal(1,L6,"length","I",null);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(140,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(141,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(145,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(146,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(147,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(149,L12);
                ddv.visitEndLocal(0,L12);
                ddv.visitEndLocal(1,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(133,L13);
                ddv.visitEndLocal(2,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(143,L14);
                ddv.visitRestartLocal(0,L14);
                ddv.visitRestartLocal(1,L14);
                ddv.visitRestartLocal(2,L14);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,5, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Lorg/mortbay/io/AbstractBuffer;","isReadOnly",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitJumpStmt(IF_EQZ,3,-1,L2);
                code.visitTypeStmt(NEW_INSTANCE,3,-1,"Ljava/lang/IllegalStateException;");
                code.visitConstStmt(CONST_STRING,4,"READONLY");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 3,4},new Method("Ljava/lang/IllegalStateException;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitStmt1R(THROW,3);
                code.visitLabel(L2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Lorg/mortbay/io/AbstractBuffer;","markIndex",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitJumpStmt(IF_LTZ,3,-1,L13);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Lorg/mortbay/io/AbstractBuffer;","markIndex",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitStmt2R(MOVE,2,3);
                code.visitLabel(L3);
                code.visitJumpStmt(IF_LEZ,2,-1,L12);
                code.visitLabel(L4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Lorg/mortbay/io/AbstractBuffer;","array",new String[]{ },"[B"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Lorg/mortbay/io/AbstractBuffer;","putIndex",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitStmt3R(SUB_INT,1,3,2);
                code.visitLabel(L6);
                code.visitJumpStmt(IF_LEZ,1,-1,L9);
                code.visitLabel(L7);
                code.visitJumpStmt(IF_EQZ,0,-1,L14);
                code.visitLabel(L8);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Lorg/mortbay/io/AbstractBuffer;","array",new String[]{ },"[B"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Lorg/mortbay/io/AbstractBuffer;","array",new String[]{ },"[B"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 3,2,4,5,1},new Method("Lorg/mortbay/io/Portable;","arraycopy",new String[]{ "[B","I","[B","I","I"},"V"));
                code.visitLabel(L9);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Lorg/mortbay/io/AbstractBuffer;","markIndex",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitJumpStmt(IF_LEZ,3,-1,L10);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Lorg/mortbay/io/AbstractBuffer;","markIndex",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitStmt2R(SUB_INT_2ADDR,3,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,3},new Method("Lorg/mortbay/io/AbstractBuffer;","setMarkIndex",new String[]{ "I"},"V"));
                code.visitLabel(L10);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Lorg/mortbay/io/AbstractBuffer;","getIndex",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitStmt2R(SUB_INT_2ADDR,3,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,3},new Method("Lorg/mortbay/io/AbstractBuffer;","setGetIndex",new String[]{ "I"},"V"));
                code.visitLabel(L11);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Lorg/mortbay/io/AbstractBuffer;","putIndex",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitStmt2R(SUB_INT_2ADDR,3,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,3},new Method("Lorg/mortbay/io/AbstractBuffer;","setPutIndex",new String[]{ "I"},"V"));
                code.visitLabel(L12);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L13);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Lorg/mortbay/io/AbstractBuffer;","getIndex",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitStmt2R(MOVE,2,3);
                code.visitJumpStmt(GOTO,-1,-1,L3);
                code.visitLabel(L14);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,2,1},new Method("Lorg/mortbay/io/AbstractBuffer;","peek",new String[]{ "I","I"},"Lorg/mortbay/io/Buffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,5,3},new Method("Lorg/mortbay/io/AbstractBuffer;","poke",new String[]{ "I","Lorg/mortbay/io/Buffer;"},"I"));
                code.visitJumpStmt(GOTO,-1,-1,L9);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m010_duplicate(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/io/AbstractBuffer;","duplicate",new String[]{ "I"},"Lorg/mortbay/io/ByteArrayBuffer;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(7);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"access");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(75,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(76,L2);
                ddv.visitStartLocal(0,L2,"b","Lorg/mortbay/io/Buffer;",null);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(77,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(79,L4);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,4, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Lorg/mortbay/io/AbstractBuffer;","buffer",new String[]{ },"Lorg/mortbay/io/Buffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L2);
                code.visitTypeStmt(INSTANCE_OF,1,0,"Lorg/mortbay/io/Buffer$CaseInsensitve;");
                DexLabel L5=new DexLabel();
                code.visitJumpStmt(IF_EQZ,1,-1,L5);
                code.visitLabel(L3);
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Lorg/mortbay/io/ByteArrayBuffer$CaseInsensitive;");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Lorg/mortbay/io/AbstractBuffer;","asArray",new String[]{ },"[B"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Lorg/mortbay/io/AbstractBuffer;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1,2,4,3,6},new Method("Lorg/mortbay/io/ByteArrayBuffer$CaseInsensitive;","<init>",new String[]{ "[B","I","I","I"},"V"));
                code.visitLabel(L4);
                code.visitStmt1R(RETURN_OBJECT,1);
                code.visitLabel(L5);
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Lorg/mortbay/io/ByteArrayBuffer;");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Lorg/mortbay/io/AbstractBuffer;","asArray",new String[]{ },"[B"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Lorg/mortbay/io/AbstractBuffer;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1,2,4,3,6},new Method("Lorg/mortbay/io/ByteArrayBuffer;","<init>",new String[]{ "[B","I","I","I"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L4);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m011_equals(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/io/AbstractBuffer;","equals",new String[]{ "Ljava/lang/Object;"},"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(15);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"obj");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(153,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(182,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(157,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(158,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(160,L5);
                ddv.visitStartLocal(2,L5,"b","Lorg/mortbay/io/Buffer;",null);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(161,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(164,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(167,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(169,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(170,L10);
                ddv.visitStartLocal(1,L10,"ab","Lorg/mortbay/io/AbstractBuffer;",null);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(174,L11);
                ddv.visitEndLocal(1,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(175,L12);
                ddv.visitStartLocal(6,L12,"get","I",null);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(176,L13);
                ddv.visitStartLocal(5,L13,"bi","I",null);
                DexLabel L14=new DexLabel();
                ddv.visitStartLocal(7,L14,"i","I",null);
                DexLabel L15=new DexLabel();
                ddv.visitEndLocal(7,L15);
                ddv.visitStartLocal(8,L15,"i","I",null);
                DexLabel L16=new DexLabel();
                ddv.visitRestartLocal(7,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(178,L17);
                ddv.visitEndLocal(8,L17);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(179,L18);
                ddv.visitStartLocal(3,L18,"b1","B",null);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(180,L19);
                ddv.visitStartLocal(4,L19,"b2","B",null);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(181,L20);
                ddv.visitRestartLocal(8,L20);
                DexLabel L21=new DexLabel();
                ddv.visitEndLocal(3,L21);
                ddv.visitEndLocal(4,L21);
                ddv.visitEndLocal(8,L21);
                DexLabel L22=new DexLabel();
                ddv.visitLineNumber(182,L22);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,12, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitConstStmt(CONST_4,11, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L1);
                code.visitJumpStmt(IF_NE,14,13,L3);
                code.visitStmt2R(MOVE,9,12);
                code.visitLabel(L2);
                code.visitStmt1R(RETURN,9);
                code.visitLabel(L3);
                DexLabel L23=new DexLabel();
                code.visitJumpStmt(IF_EQZ,14,-1,L23);
                code.visitTypeStmt(INSTANCE_OF,9,14,"Lorg/mortbay/io/Buffer;");
                code.visitJumpStmt(IF_NEZ,9,-1,L4);
                code.visitLabel(L23);
                code.visitStmt2R(MOVE,9,11);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitLabel(L4);
                code.visitStmt2R(MOVE_OBJECT,0,14);
                code.visitTypeStmt(CHECK_CAST,0,-1,"Lorg/mortbay/io/Buffer;");
                code.visitStmt2R(MOVE_OBJECT,2,0);
                code.visitLabel(L5);
                code.visitTypeStmt(INSTANCE_OF,9,13,"Lorg/mortbay/io/Buffer$CaseInsensitve;");
                code.visitJumpStmt(IF_NEZ,9,-1,L6);
                code.visitTypeStmt(INSTANCE_OF,9,2,"Lorg/mortbay/io/Buffer$CaseInsensitve;");
                code.visitJumpStmt(IF_EQZ,9,-1,L7);
                code.visitLabel(L6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 13,2},new Method("Lorg/mortbay/io/AbstractBuffer;","equalsIgnoreCase",new String[]{ "Lorg/mortbay/io/Buffer;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,9);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitLabel(L7);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 2},new Method("Lorg/mortbay/io/Buffer;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,9);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 13},new Method("Lorg/mortbay/io/AbstractBuffer;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,10);
                code.visitJumpStmt(IF_EQ,9,10,L8);
                code.visitStmt2R(MOVE,9,11);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitLabel(L8);
                code.visitFieldStmt(IGET,9,13,new Field("Lorg/mortbay/io/AbstractBuffer;","_hash","I"));
                code.visitJumpStmt(IF_EQZ,9,-1,L11);
                code.visitTypeStmt(INSTANCE_OF,9,14,"Lorg/mortbay/io/AbstractBuffer;");
                code.visitJumpStmt(IF_EQZ,9,-1,L11);
                code.visitLabel(L9);
                code.visitStmt2R(MOVE_OBJECT,0,14);
                code.visitTypeStmt(CHECK_CAST,0,-1,"Lorg/mortbay/io/AbstractBuffer;");
                code.visitStmt2R(MOVE_OBJECT,1,0);
                code.visitLabel(L10);
                code.visitFieldStmt(IGET,9,1,new Field("Lorg/mortbay/io/AbstractBuffer;","_hash","I"));
                code.visitJumpStmt(IF_EQZ,9,-1,L11);
                code.visitFieldStmt(IGET,9,13,new Field("Lorg/mortbay/io/AbstractBuffer;","_hash","I"));
                code.visitFieldStmt(IGET,10,1,new Field("Lorg/mortbay/io/AbstractBuffer;","_hash","I"));
                code.visitJumpStmt(IF_EQ,9,10,L11);
                code.visitStmt2R(MOVE,9,11);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitLabel(L11);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 13},new Method("Lorg/mortbay/io/AbstractBuffer;","getIndex",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,6);
                code.visitLabel(L12);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 2},new Method("Lorg/mortbay/io/Buffer;","putIndex",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,5);
                code.visitLabel(L13);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 13},new Method("Lorg/mortbay/io/AbstractBuffer;","putIndex",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,7);
                code.visitLabel(L14);
                code.visitStmt2R(MOVE,8,7);
                code.visitLabel(L15);
                code.visitStmt3R(SUB_INT,7,8,12);
                code.visitLabel(L16);
                code.visitJumpStmt(IF_LE,8,6,L21);
                code.visitLabel(L17);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 13,7},new Method("Lorg/mortbay/io/AbstractBuffer;","peek",new String[]{ "I"},"B"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitLabel(L18);
                code.visitStmt2R1N(ADD_INT_LIT8,5,5,-1);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 2,5},new Method("Lorg/mortbay/io/Buffer;","peek",new String[]{ "I"},"B"));
                code.visitStmt1R(MOVE_RESULT,4);
                code.visitLabel(L19);
                DexLabel L24=new DexLabel();
                code.visitJumpStmt(IF_EQ,3,4,L24);
                code.visitStmt2R(MOVE,9,11);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitLabel(L24);
                code.visitStmt2R(MOVE,8,7);
                code.visitLabel(L20);
                code.visitJumpStmt(GOTO,-1,-1,L15);
                code.visitLabel(L21);
                code.visitStmt2R(MOVE,9,12);
                code.visitLabel(L22);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m012_equalsIgnoreCase(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/io/AbstractBuffer;","equalsIgnoreCase",new String[]{ "Lorg/mortbay/io/Buffer;"},"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(14);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"b");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(187,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(188,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(234,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(191,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(194,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(196,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(197,L6);
                ddv.visitStartLocal(1,L6,"ab","Lorg/mortbay/io/AbstractBuffer;",null);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(201,L7);
                ddv.visitEndLocal(1,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(202,L8);
                ddv.visitStartLocal(7,L8,"get","I",null);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(204,L9);
                ddv.visitStartLocal(6,L9,"bi","I",null);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(205,L10);
                ddv.visitStartLocal(2,L10,"array","[B",null);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(206,L11);
                ddv.visitStartLocal(5,L11,"barray","[B",null);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(208,L12);
                DexLabel L13=new DexLabel();
                ddv.visitStartLocal(8,L13,"i","I",null);
                DexLabel L14=new DexLabel();
                ddv.visitEndLocal(8,L14);
                ddv.visitStartLocal(9,L14,"i","I",null);
                DexLabel L15=new DexLabel();
                ddv.visitRestartLocal(8,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(210,L16);
                ddv.visitEndLocal(9,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(211,L17);
                ddv.visitStartLocal(3,L17,"b1","B",null);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(212,L18);
                ddv.visitStartLocal(4,L18,"b2","B",null);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(214,L19);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(215,L20);
                DexLabel L21=new DexLabel();
                ddv.visitLineNumber(216,L21);
                DexLabel L22=new DexLabel();
                ddv.visitLineNumber(218,L22);
                ddv.visitRestartLocal(9,L22);
                DexLabel L23=new DexLabel();
                ddv.visitLineNumber(222,L23);
                ddv.visitEndLocal(8,L23);
                ddv.visitEndLocal(3,L23);
                ddv.visitEndLocal(4,L23);
                ddv.visitEndLocal(9,L23);
                DexLabel L24=new DexLabel();
                ddv.visitRestartLocal(8,L24);
                DexLabel L25=new DexLabel();
                ddv.visitEndLocal(8,L25);
                ddv.visitRestartLocal(9,L25);
                DexLabel L26=new DexLabel();
                ddv.visitRestartLocal(8,L26);
                DexLabel L27=new DexLabel();
                ddv.visitLineNumber(224,L27);
                ddv.visitEndLocal(9,L27);
                DexLabel L28=new DexLabel();
                ddv.visitLineNumber(225,L28);
                ddv.visitRestartLocal(3,L28);
                DexLabel L29=new DexLabel();
                ddv.visitLineNumber(226,L29);
                ddv.visitRestartLocal(4,L29);
                DexLabel L30=new DexLabel();
                ddv.visitLineNumber(228,L30);
                DexLabel L31=new DexLabel();
                ddv.visitLineNumber(229,L31);
                DexLabel L32=new DexLabel();
                ddv.visitLineNumber(230,L32);
                DexLabel L33=new DexLabel();
                ddv.visitLineNumber(232,L33);
                ddv.visitRestartLocal(9,L33);
                DexLabel L34=new DexLabel();
                ddv.visitLineNumber(234,L34);
                ddv.visitEndLocal(3,L34);
                ddv.visitEndLocal(4,L34);
                ddv.visitEndLocal(9,L34);
                code.visitLabel(L0);
                code.visitJumpStmt(IF_NE,13,12,L3);
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,10, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitLabel(L2);
                code.visitStmt1R(RETURN,10);
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 13},new Method("Lorg/mortbay/io/Buffer;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,10);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 12},new Method("Lorg/mortbay/io/AbstractBuffer;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,11);
                code.visitJumpStmt(IF_EQ,10,11,L4);
                code.visitConstStmt(CONST_4,10, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitLabel(L4);
                code.visitFieldStmt(IGET,10,12,new Field("Lorg/mortbay/io/AbstractBuffer;","_hash","I"));
                code.visitJumpStmt(IF_EQZ,10,-1,L7);
                code.visitTypeStmt(INSTANCE_OF,10,13,"Lorg/mortbay/io/AbstractBuffer;");
                code.visitJumpStmt(IF_EQZ,10,-1,L7);
                code.visitLabel(L5);
                code.visitStmt2R(MOVE_OBJECT,0,13);
                code.visitTypeStmt(CHECK_CAST,0,-1,"Lorg/mortbay/io/AbstractBuffer;");
                code.visitStmt2R(MOVE_OBJECT,1,0);
                code.visitLabel(L6);
                code.visitFieldStmt(IGET,10,1,new Field("Lorg/mortbay/io/AbstractBuffer;","_hash","I"));
                code.visitJumpStmt(IF_EQZ,10,-1,L7);
                code.visitFieldStmt(IGET,10,12,new Field("Lorg/mortbay/io/AbstractBuffer;","_hash","I"));
                code.visitFieldStmt(IGET,11,1,new Field("Lorg/mortbay/io/AbstractBuffer;","_hash","I"));
                code.visitJumpStmt(IF_EQ,10,11,L7);
                code.visitConstStmt(CONST_4,10, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitLabel(L7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 12},new Method("Lorg/mortbay/io/AbstractBuffer;","getIndex",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,7);
                code.visitLabel(L8);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 13},new Method("Lorg/mortbay/io/Buffer;","putIndex",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,6);
                code.visitLabel(L9);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 12},new Method("Lorg/mortbay/io/AbstractBuffer;","array",new String[]{ },"[B"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitLabel(L10);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 13},new Method("Lorg/mortbay/io/Buffer;","array",new String[]{ },"[B"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitLabel(L11);
                code.visitJumpStmt(IF_EQZ,2,-1,L23);
                code.visitJumpStmt(IF_EQZ,5,-1,L23);
                code.visitLabel(L12);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 12},new Method("Lorg/mortbay/io/AbstractBuffer;","putIndex",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,8);
                code.visitLabel(L13);
                code.visitStmt2R(MOVE,9,8);
                code.visitLabel(L14);
                code.visitConstStmt(CONST_4,10, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitStmt3R(SUB_INT,8,9,10);
                code.visitLabel(L15);
                code.visitJumpStmt(IF_LE,9,7,L34);
                code.visitLabel(L16);
                code.visitStmt3R(AGET_BYTE,3,2,8);
                code.visitLabel(L17);
                code.visitStmt2R1N(ADD_INT_LIT8,6,6,-1);
                code.visitStmt3R(AGET_BYTE,4,5,6);
                code.visitLabel(L18);
                DexLabel L35=new DexLabel();
                code.visitJumpStmt(IF_EQ,3,4,L35);
                code.visitLabel(L19);
                code.visitConstStmt(CONST_16,10, Integer.valueOf(97)); // int: 0x00000061  float:0.000000
                code.visitJumpStmt(IF_GT,10,3,L20);
                code.visitConstStmt(CONST_16,10, Integer.valueOf(122)); // int: 0x0000007a  float:0.000000
                code.visitJumpStmt(IF_GT,3,10,L20);
                code.visitConstStmt(CONST_16,10, Integer.valueOf(97)); // int: 0x00000061  float:0.000000
                code.visitStmt3R(SUB_INT,10,3,10);
                code.visitStmt2R1N(ADD_INT_LIT8,10,10,65);
                code.visitStmt2R(INT_TO_BYTE,3,10);
                code.visitLabel(L20);
                code.visitConstStmt(CONST_16,10, Integer.valueOf(97)); // int: 0x00000061  float:0.000000
                code.visitJumpStmt(IF_GT,10,4,L21);
                code.visitConstStmt(CONST_16,10, Integer.valueOf(122)); // int: 0x0000007a  float:0.000000
                code.visitJumpStmt(IF_GT,4,10,L21);
                code.visitConstStmt(CONST_16,10, Integer.valueOf(97)); // int: 0x00000061  float:0.000000
                code.visitStmt3R(SUB_INT,10,4,10);
                code.visitStmt2R1N(ADD_INT_LIT8,10,10,65);
                code.visitStmt2R(INT_TO_BYTE,4,10);
                code.visitLabel(L21);
                code.visitJumpStmt(IF_EQ,3,4,L35);
                code.visitConstStmt(CONST_4,10, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitLabel(L35);
                code.visitStmt2R(MOVE,9,8);
                code.visitLabel(L22);
                code.visitJumpStmt(GOTO,-1,-1,L14);
                code.visitLabel(L23);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 12},new Method("Lorg/mortbay/io/AbstractBuffer;","putIndex",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,8);
                code.visitLabel(L24);
                code.visitStmt2R(MOVE,9,8);
                code.visitLabel(L25);
                code.visitConstStmt(CONST_4,10, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitStmt3R(SUB_INT,8,9,10);
                code.visitLabel(L26);
                code.visitJumpStmt(IF_LE,9,7,L34);
                code.visitLabel(L27);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 12,8},new Method("Lorg/mortbay/io/AbstractBuffer;","peek",new String[]{ "I"},"B"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitLabel(L28);
                code.visitStmt2R1N(ADD_INT_LIT8,6,6,-1);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 13,6},new Method("Lorg/mortbay/io/Buffer;","peek",new String[]{ "I"},"B"));
                code.visitStmt1R(MOVE_RESULT,4);
                code.visitLabel(L29);
                DexLabel L36=new DexLabel();
                code.visitJumpStmt(IF_EQ,3,4,L36);
                code.visitLabel(L30);
                code.visitConstStmt(CONST_16,10, Integer.valueOf(97)); // int: 0x00000061  float:0.000000
                code.visitJumpStmt(IF_GT,10,3,L31);
                code.visitConstStmt(CONST_16,10, Integer.valueOf(122)); // int: 0x0000007a  float:0.000000
                code.visitJumpStmt(IF_GT,3,10,L31);
                code.visitConstStmt(CONST_16,10, Integer.valueOf(97)); // int: 0x00000061  float:0.000000
                code.visitStmt3R(SUB_INT,10,3,10);
                code.visitStmt2R1N(ADD_INT_LIT8,10,10,65);
                code.visitStmt2R(INT_TO_BYTE,3,10);
                code.visitLabel(L31);
                code.visitConstStmt(CONST_16,10, Integer.valueOf(97)); // int: 0x00000061  float:0.000000
                code.visitJumpStmt(IF_GT,10,4,L32);
                code.visitConstStmt(CONST_16,10, Integer.valueOf(122)); // int: 0x0000007a  float:0.000000
                code.visitJumpStmt(IF_GT,4,10,L32);
                code.visitConstStmt(CONST_16,10, Integer.valueOf(97)); // int: 0x00000061  float:0.000000
                code.visitStmt3R(SUB_INT,10,4,10);
                code.visitStmt2R1N(ADD_INT_LIT8,10,10,65);
                code.visitStmt2R(INT_TO_BYTE,4,10);
                code.visitLabel(L32);
                code.visitJumpStmt(IF_EQ,3,4,L36);
                code.visitConstStmt(CONST_4,10, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitJumpStmt(GOTO_16,-1,-1,L2);
                code.visitLabel(L36);
                code.visitStmt2R(MOVE,9,8);
                code.visitLabel(L33);
                code.visitJumpStmt(GOTO,-1,-1,L25);
                code.visitLabel(L34);
                code.visitConstStmt(CONST_4,10, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitJumpStmt(GOTO_16,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m013_get(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/io/AbstractBuffer;","get",new String[]{ },"B"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(239,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET,0,2,new Field("Lorg/mortbay/io/AbstractBuffer;","_get","I"));
                code.visitStmt2R1N(ADD_INT_LIT8,1,0,1);
                code.visitFieldStmt(IPUT,1,2,new Field("Lorg/mortbay/io/AbstractBuffer;","_get","I"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,0},new Method("Lorg/mortbay/io/AbstractBuffer;","peek",new String[]{ "I"},"B"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m014_get(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/io/AbstractBuffer;","get",new String[]{ "[B","I","I"},"I"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(7);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"b");
                ddv.visitParameterName(1,"offset");
                ddv.visitParameterName(2,"length");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(244,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(245,L1);
                ddv.visitStartLocal(0,L1,"gi","I",null);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(246,L2);
                ddv.visitStartLocal(1,L2,"l","I",null);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(247,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(255,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(249,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(250,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(252,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(253,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(254,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(255,L10);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Lorg/mortbay/io/AbstractBuffer;","getIndex",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Lorg/mortbay/io/AbstractBuffer;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitLabel(L2);
                code.visitJumpStmt(IF_NEZ,1,-1,L5);
                code.visitLabel(L3);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(-1)); // int: 0xffffffff  float:NaN
                code.visitLabel(L4);
                code.visitStmt1R(RETURN,2);
                code.visitLabel(L5);
                code.visitJumpStmt(IF_LE,6,1,L7);
                code.visitLabel(L6);
                code.visitStmt2R(MOVE,6,1);
                code.visitLabel(L7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,0,4,5,6},new Method("Lorg/mortbay/io/AbstractBuffer;","peek",new String[]{ "I","[B","I","I"},"I"));
                code.visitStmt1R(MOVE_RESULT,6);
                code.visitLabel(L8);
                DexLabel L11=new DexLabel();
                code.visitJumpStmt(IF_LEZ,6,-1,L11);
                code.visitLabel(L9);
                code.visitStmt3R(ADD_INT,2,0,6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,2},new Method("Lorg/mortbay/io/AbstractBuffer;","setGetIndex",new String[]{ "I"},"V"));
                code.visitLabel(L11);
                code.visitStmt2R(MOVE,2,6);
                code.visitLabel(L10);
                code.visitJumpStmt(GOTO,-1,-1,L4);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m015_get(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/io/AbstractBuffer;","get",new String[]{ "I"},"Lorg/mortbay/io/Buffer;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"length");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(260,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(261,L1);
                ddv.visitStartLocal(0,L1,"gi","I",null);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(262,L2);
                ddv.visitStartLocal(1,L2,"view","Lorg/mortbay/io/Buffer;",null);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(263,L3);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Lorg/mortbay/io/AbstractBuffer;","getIndex",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,0,4},new Method("Lorg/mortbay/io/AbstractBuffer;","peek",new String[]{ "I","I"},"Lorg/mortbay/io/Buffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L2);
                code.visitStmt3R(ADD_INT,2,0,4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,2},new Method("Lorg/mortbay/io/AbstractBuffer;","setGetIndex",new String[]{ "I"},"V"));
                code.visitLabel(L3);
                code.visitStmt1R(RETURN_OBJECT,1);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m016_getIndex(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_FINAL, new Method("Lorg/mortbay/io/AbstractBuffer;","getIndex",new String[]{ },"I"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(268,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET,0,1,new Field("Lorg/mortbay/io/AbstractBuffer;","_get","I"));
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m017_hasContent(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/io/AbstractBuffer;","hasContent",new String[]{ },"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(273,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET,0,2,new Field("Lorg/mortbay/io/AbstractBuffer;","_put","I"));
                code.visitFieldStmt(IGET,1,2,new Field("Lorg/mortbay/io/AbstractBuffer;","_get","I"));
                DexLabel L1=new DexLabel();
                code.visitJumpStmt(IF_LE,0,1,L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                DexLabel L2=new DexLabel();
                code.visitLabel(L2);
                code.visitStmt1R(RETURN,0);
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m018_hashCode(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/io/AbstractBuffer;","hashCode",new String[]{ },"I"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(11);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(278,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(280,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(281,L3);
                ddv.visitStartLocal(2,L3,"get","I",null);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(282,L4);
                ddv.visitStartLocal(0,L4,"array","[B",null);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(284,L5);
                DexLabel L6=new DexLabel();
                ddv.visitStartLocal(3,L6,"i","I",null);
                DexLabel L7=new DexLabel();
                ddv.visitEndLocal(3,L7);
                ddv.visitStartLocal(4,L7,"i","I",null);
                DexLabel L8=new DexLabel();
                ddv.visitRestartLocal(3,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(286,L9);
                ddv.visitEndLocal(4,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(287,L10);
                ddv.visitStartLocal(1,L10,"b","B",null);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(288,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(289,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(290,L13);
                ddv.visitRestartLocal(4,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(294,L14);
                ddv.visitEndLocal(3,L14);
                ddv.visitEndLocal(1,L14);
                ddv.visitEndLocal(4,L14);
                DexLabel L15=new DexLabel();
                ddv.visitRestartLocal(3,L15);
                DexLabel L16=new DexLabel();
                ddv.visitEndLocal(3,L16);
                ddv.visitRestartLocal(4,L16);
                DexLabel L17=new DexLabel();
                ddv.visitRestartLocal(3,L17);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(296,L18);
                ddv.visitEndLocal(4,L18);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(297,L19);
                ddv.visitRestartLocal(1,L19);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(298,L20);
                DexLabel L21=new DexLabel();
                ddv.visitLineNumber(299,L21);
                DexLabel L22=new DexLabel();
                ddv.visitLineNumber(300,L22);
                ddv.visitRestartLocal(4,L22);
                DexLabel L23=new DexLabel();
                ddv.visitLineNumber(302,L23);
                ddv.visitEndLocal(1,L23);
                ddv.visitEndLocal(4,L23);
                DexLabel L24=new DexLabel();
                ddv.visitLineNumber(303,L24);
                DexLabel L25=new DexLabel();
                ddv.visitLineNumber(304,L25);
                DexLabel L26=new DexLabel();
                ddv.visitLineNumber(305,L26);
                DexLabel L27=new DexLabel();
                ddv.visitLineNumber(308,L27);
                ddv.visitEndLocal(2,L27);
                ddv.visitEndLocal(0,L27);
                ddv.visitEndLocal(3,L27);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_16,9, Integer.valueOf(122)); // int: 0x0000007a  float:0.000000
                code.visitConstStmt(CONST_4,8, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitConstStmt(CONST_16,7, Integer.valueOf(97)); // int: 0x00000061  float:0.000000
                code.visitLabel(L1);
                code.visitFieldStmt(IGET,5,10,new Field("Lorg/mortbay/io/AbstractBuffer;","_hash","I"));
                code.visitJumpStmt(IF_EQZ,5,-1,L2);
                code.visitFieldStmt(IGET,5,10,new Field("Lorg/mortbay/io/AbstractBuffer;","_hashGet","I"));
                code.visitFieldStmt(IGET,6,10,new Field("Lorg/mortbay/io/AbstractBuffer;","_get","I"));
                code.visitJumpStmt(IF_NE,5,6,L2);
                code.visitFieldStmt(IGET,5,10,new Field("Lorg/mortbay/io/AbstractBuffer;","_hashPut","I"));
                code.visitFieldStmt(IGET,6,10,new Field("Lorg/mortbay/io/AbstractBuffer;","_put","I"));
                code.visitJumpStmt(IF_EQ,5,6,L27);
                code.visitLabel(L2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10},new Method("Lorg/mortbay/io/AbstractBuffer;","getIndex",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10},new Method("Lorg/mortbay/io/AbstractBuffer;","array",new String[]{ },"[B"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L4);
                code.visitJumpStmt(IF_NEZ,0,-1,L14);
                code.visitLabel(L5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10},new Method("Lorg/mortbay/io/AbstractBuffer;","putIndex",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitLabel(L6);
                code.visitStmt2R(MOVE,4,3);
                code.visitLabel(L7);
                code.visitStmt3R(SUB_INT,3,4,8);
                code.visitLabel(L8);
                code.visitJumpStmt(IF_LE,4,2,L23);
                code.visitLabel(L9);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10,3},new Method("Lorg/mortbay/io/AbstractBuffer;","peek",new String[]{ "I"},"B"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitLabel(L10);
                code.visitJumpStmt(IF_GT,7,1,L12);
                code.visitJumpStmt(IF_GT,1,9,L12);
                code.visitLabel(L11);
                code.visitStmt3R(SUB_INT,5,1,7);
                code.visitStmt2R1N(ADD_INT_LIT8,5,5,65);
                code.visitStmt2R(INT_TO_BYTE,1,5);
                code.visitLabel(L12);
                code.visitFieldStmt(IGET,5,10,new Field("Lorg/mortbay/io/AbstractBuffer;","_hash","I"));
                code.visitStmt2R1N(MUL_INT_LIT8,5,5,31);
                code.visitStmt2R(ADD_INT_2ADDR,5,1);
                code.visitFieldStmt(IPUT,5,10,new Field("Lorg/mortbay/io/AbstractBuffer;","_hash","I"));
                code.visitStmt2R(MOVE,4,3);
                code.visitLabel(L13);
                code.visitJumpStmt(GOTO,-1,-1,L7);
                code.visitLabel(L14);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10},new Method("Lorg/mortbay/io/AbstractBuffer;","putIndex",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitLabel(L15);
                code.visitStmt2R(MOVE,4,3);
                code.visitLabel(L16);
                code.visitStmt3R(SUB_INT,3,4,8);
                code.visitLabel(L17);
                code.visitJumpStmt(IF_LE,4,2,L23);
                code.visitLabel(L18);
                code.visitStmt3R(AGET_BYTE,1,0,3);
                code.visitLabel(L19);
                code.visitJumpStmt(IF_GT,7,1,L21);
                code.visitJumpStmt(IF_GT,1,9,L21);
                code.visitLabel(L20);
                code.visitStmt3R(SUB_INT,5,1,7);
                code.visitStmt2R1N(ADD_INT_LIT8,5,5,65);
                code.visitStmt2R(INT_TO_BYTE,1,5);
                code.visitLabel(L21);
                code.visitFieldStmt(IGET,5,10,new Field("Lorg/mortbay/io/AbstractBuffer;","_hash","I"));
                code.visitStmt2R1N(MUL_INT_LIT8,5,5,31);
                code.visitStmt2R(ADD_INT_2ADDR,5,1);
                code.visitFieldStmt(IPUT,5,10,new Field("Lorg/mortbay/io/AbstractBuffer;","_hash","I"));
                code.visitStmt2R(MOVE,4,3);
                code.visitLabel(L22);
                code.visitJumpStmt(GOTO,-1,-1,L16);
                code.visitLabel(L23);
                code.visitFieldStmt(IGET,5,10,new Field("Lorg/mortbay/io/AbstractBuffer;","_hash","I"));
                code.visitJumpStmt(IF_NEZ,5,-1,L25);
                code.visitLabel(L24);
                code.visitConstStmt(CONST_4,5, Integer.valueOf(-1)); // int: 0xffffffff  float:NaN
                code.visitFieldStmt(IPUT,5,10,new Field("Lorg/mortbay/io/AbstractBuffer;","_hash","I"));
                code.visitLabel(L25);
                code.visitFieldStmt(IGET,5,10,new Field("Lorg/mortbay/io/AbstractBuffer;","_get","I"));
                code.visitFieldStmt(IPUT,5,10,new Field("Lorg/mortbay/io/AbstractBuffer;","_hashGet","I"));
                code.visitLabel(L26);
                code.visitFieldStmt(IGET,5,10,new Field("Lorg/mortbay/io/AbstractBuffer;","_put","I"));
                code.visitFieldStmt(IPUT,5,10,new Field("Lorg/mortbay/io/AbstractBuffer;","_hashPut","I"));
                code.visitLabel(L27);
                code.visitFieldStmt(IGET,5,10,new Field("Lorg/mortbay/io/AbstractBuffer;","_hash","I"));
                code.visitStmt1R(RETURN,5);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m019_isImmutable(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/io/AbstractBuffer;","isImmutable",new String[]{ },"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(313,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET,0,1,new Field("Lorg/mortbay/io/AbstractBuffer;","_access","I"));
                DexLabel L1=new DexLabel();
                code.visitJumpStmt(IF_GTZ,0,-1,L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                DexLabel L2=new DexLabel();
                code.visitLabel(L2);
                code.visitStmt1R(RETURN,0);
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m020_isReadOnly(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/io/AbstractBuffer;","isReadOnly",new String[]{ },"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(318,L1);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitLabel(L1);
                code.visitFieldStmt(IGET,0,2,new Field("Lorg/mortbay/io/AbstractBuffer;","_access","I"));
                DexLabel L2=new DexLabel();
                code.visitJumpStmt(IF_GT,0,1,L2);
                code.visitStmt2R(MOVE,0,1);
                DexLabel L3=new DexLabel();
                code.visitLabel(L3);
                code.visitStmt1R(RETURN,0);
                code.visitLabel(L2);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L3);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m021_isVolatile(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/io/AbstractBuffer;","isVolatile",new String[]{ },"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(323,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_BOOLEAN,0,1,new Field("Lorg/mortbay/io/AbstractBuffer;","_volatile","Z"));
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m022_length(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/io/AbstractBuffer;","length",new String[]{ },"I"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(328,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET,0,2,new Field("Lorg/mortbay/io/AbstractBuffer;","_put","I"));
                code.visitFieldStmt(IGET,1,2,new Field("Lorg/mortbay/io/AbstractBuffer;","_get","I"));
                code.visitStmt2R(SUB_INT_2ADDR,0,1);
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m023_mark(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/io/AbstractBuffer;","mark",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(333,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(334,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET,0,2,new Field("Lorg/mortbay/io/AbstractBuffer;","_get","I"));
                code.visitConstStmt(CONST_4,1, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitStmt2R(SUB_INT_2ADDR,0,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,0},new Method("Lorg/mortbay/io/AbstractBuffer;","setMarkIndex",new String[]{ "I"},"V"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m024_mark(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/io/AbstractBuffer;","mark",new String[]{ "I"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"offset");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(338,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(339,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET,0,1,new Field("Lorg/mortbay/io/AbstractBuffer;","_get","I"));
                code.visitStmt2R(ADD_INT_2ADDR,0,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,0},new Method("Lorg/mortbay/io/AbstractBuffer;","setMarkIndex",new String[]{ "I"},"V"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m025_markIndex(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/io/AbstractBuffer;","markIndex",new String[]{ },"I"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(343,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET,0,1,new Field("Lorg/mortbay/io/AbstractBuffer;","_mark","I"));
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m026_peek(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/io/AbstractBuffer;","peek",new String[]{ },"B"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(348,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET,0,1,new Field("Lorg/mortbay/io/AbstractBuffer;","_get","I"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,0},new Method("Lorg/mortbay/io/AbstractBuffer;","peek",new String[]{ "I"},"B"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m027_peek(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/io/AbstractBuffer;","peek",new String[]{ "I","I"},"Lorg/mortbay/io/Buffer;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(9);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"index");
                ddv.visitParameterName(1,"length");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(353,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(355,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(366,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(355,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(359,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(360,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(361,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(362,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(363,L9);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(-1)); // int: 0xffffffff  float:NaN
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,0,6,new Field("Lorg/mortbay/io/AbstractBuffer;","_view","Lorg/mortbay/io/View;"));
                code.visitJumpStmt(IF_NEZ,0,-1,L5);
                code.visitLabel(L2);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Lorg/mortbay/io/View;");
                code.visitStmt3R(ADD_INT,4,7,8);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Lorg/mortbay/io/AbstractBuffer;","isReadOnly",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitJumpStmt(IF_EQZ,1,-1,L4);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitStmt2R(MOVE,5,1);
                DexLabel L10=new DexLabel();
                code.visitLabel(L10);
                code.visitStmt2R(MOVE_OBJECT,1,6);
                code.visitStmt2R(MOVE,3,7);
                code.visitMethodStmt(INVOKE_DIRECT_RANGE,new int[]{ 0,1,2,3,4,5},new Method("Lorg/mortbay/io/View;","<init>",new String[]{ "Lorg/mortbay/io/Buffer;","I","I","I","I"},"V"));
                code.visitFieldStmt(IPUT_OBJECT,0,6,new Field("Lorg/mortbay/io/AbstractBuffer;","_view","Lorg/mortbay/io/View;"));
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,0,6,new Field("Lorg/mortbay/io/AbstractBuffer;","_view","Lorg/mortbay/io/View;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitLabel(L4);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(2)); // int: 0x00000002  float:0.000000
                code.visitStmt2R(MOVE,5,1);
                code.visitJumpStmt(GOTO,-1,-1,L10);
                code.visitLabel(L5);
                code.visitFieldStmt(IGET_OBJECT,0,6,new Field("Lorg/mortbay/io/AbstractBuffer;","_view","Lorg/mortbay/io/View;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Lorg/mortbay/io/AbstractBuffer;","buffer",new String[]{ },"Lorg/mortbay/io/Buffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Lorg/mortbay/io/View;","update",new String[]{ "Lorg/mortbay/io/Buffer;"},"V"));
                code.visitLabel(L6);
                code.visitFieldStmt(IGET_OBJECT,0,6,new Field("Lorg/mortbay/io/AbstractBuffer;","_view","Lorg/mortbay/io/View;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,2},new Method("Lorg/mortbay/io/View;","setMarkIndex",new String[]{ "I"},"V"));
                code.visitLabel(L7);
                code.visitFieldStmt(IGET_OBJECT,0,6,new Field("Lorg/mortbay/io/AbstractBuffer;","_view","Lorg/mortbay/io/View;"));
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Lorg/mortbay/io/View;","setGetIndex",new String[]{ "I"},"V"));
                code.visitLabel(L8);
                code.visitFieldStmt(IGET_OBJECT,0,6,new Field("Lorg/mortbay/io/AbstractBuffer;","_view","Lorg/mortbay/io/View;"));
                code.visitStmt3R(ADD_INT,1,7,8);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Lorg/mortbay/io/View;","setPutIndex",new String[]{ "I"},"V"));
                code.visitLabel(L9);
                code.visitFieldStmt(IGET_OBJECT,0,6,new Field("Lorg/mortbay/io/AbstractBuffer;","_view","Lorg/mortbay/io/View;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,7},new Method("Lorg/mortbay/io/View;","setGetIndex",new String[]{ "I"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L3);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m028_poke(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/io/AbstractBuffer;","poke",new String[]{ "I","Lorg/mortbay/io/Buffer;"},"I"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(12);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"index");
                ddv.visitParameterName(1,"src");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(371,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(379,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(380,L2);
                ddv.visitStartLocal(3,L2,"length","I",null);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(382,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(389,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(390,L5);
                ddv.visitStartLocal(6,L5,"src_array","[B",null);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(391,L6);
                ddv.visitStartLocal(0,L6,"dst_array","[B",null);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(392,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(412,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(393,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(395,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(396,L11);
                ddv.visitStartLocal(4,L11,"s","I",null);
                DexLabel L12=new DexLabel();
                ddv.visitStartLocal(1,L12,"i","I",null);
                DexLabel L13=new DexLabel();
                ddv.visitStartLocal(5,L13,"s","I",null);
                DexLabel L14=new DexLabel();
                ddv.visitEndLocal(10,L14);
                ddv.visitEndLocal(4,L14);
                ddv.visitStartLocal(2,L14,"index","I",null);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(397,L15);
                DexLabel L16=new DexLabel();
                ddv.visitRestartLocal(10,L16);
                DexLabel L17=new DexLabel();
                ddv.visitRestartLocal(4,L17);
                DexLabel L18=new DexLabel();
                ddv.visitEndLocal(5,L18);
                ddv.visitEndLocal(2,L18);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(396,L19);
                DexLabel L20=new DexLabel();
                ddv.visitRestartLocal(5,L20);
                DexLabel L21=new DexLabel();
                ddv.visitRestartLocal(2,L21);
                DexLabel L22=new DexLabel();
                ddv.visitEndLocal(10,L22);
                ddv.visitEndLocal(4,L22);
                DexLabel L23=new DexLabel();
                ddv.visitLineNumber(398,L23);
                ddv.visitRestartLocal(10,L23);
                DexLabel L24=new DexLabel();
                ddv.visitLineNumber(399,L24);
                ddv.visitEndLocal(1,L24);
                ddv.visitEndLocal(5,L24);
                ddv.visitEndLocal(2,L24);
                DexLabel L25=new DexLabel();
                ddv.visitLineNumber(401,L25);
                DexLabel L26=new DexLabel();
                ddv.visitLineNumber(402,L26);
                ddv.visitRestartLocal(4,L26);
                DexLabel L27=new DexLabel();
                ddv.visitRestartLocal(1,L27);
                DexLabel L28=new DexLabel();
                ddv.visitRestartLocal(5,L28);
                DexLabel L29=new DexLabel();
                ddv.visitEndLocal(10,L29);
                ddv.visitEndLocal(4,L29);
                ddv.visitRestartLocal(2,L29);
                DexLabel L30=new DexLabel();
                ddv.visitLineNumber(403,L30);
                DexLabel L31=new DexLabel();
                ddv.visitRestartLocal(10,L31);
                DexLabel L32=new DexLabel();
                ddv.visitRestartLocal(4,L32);
                DexLabel L33=new DexLabel();
                ddv.visitEndLocal(5,L33);
                ddv.visitEndLocal(2,L33);
                DexLabel L34=new DexLabel();
                ddv.visitLineNumber(402,L34);
                DexLabel L35=new DexLabel();
                ddv.visitRestartLocal(5,L35);
                DexLabel L36=new DexLabel();
                ddv.visitRestartLocal(2,L36);
                DexLabel L37=new DexLabel();
                ddv.visitEndLocal(10,L37);
                ddv.visitEndLocal(4,L37);
                DexLabel L38=new DexLabel();
                ddv.visitLineNumber(404,L38);
                ddv.visitRestartLocal(10,L38);
                DexLabel L39=new DexLabel();
                ddv.visitLineNumber(407,L39);
                ddv.visitEndLocal(1,L39);
                ddv.visitEndLocal(5,L39);
                ddv.visitEndLocal(2,L39);
                DexLabel L40=new DexLabel();
                ddv.visitLineNumber(408,L40);
                ddv.visitRestartLocal(4,L40);
                DexLabel L41=new DexLabel();
                ddv.visitRestartLocal(1,L41);
                DexLabel L42=new DexLabel();
                ddv.visitRestartLocal(5,L42);
                DexLabel L43=new DexLabel();
                ddv.visitEndLocal(10,L43);
                ddv.visitEndLocal(4,L43);
                ddv.visitRestartLocal(2,L43);
                DexLabel L44=new DexLabel();
                ddv.visitLineNumber(409,L44);
                DexLabel L45=new DexLabel();
                ddv.visitRestartLocal(10,L45);
                DexLabel L46=new DexLabel();
                ddv.visitRestartLocal(4,L46);
                DexLabel L47=new DexLabel();
                ddv.visitEndLocal(5,L47);
                ddv.visitEndLocal(2,L47);
                DexLabel L48=new DexLabel();
                ddv.visitLineNumber(408,L48);
                DexLabel L49=new DexLabel();
                ddv.visitRestartLocal(5,L49);
                DexLabel L50=new DexLabel();
                ddv.visitRestartLocal(2,L50);
                DexLabel L51=new DexLabel();
                ddv.visitEndLocal(10,L51);
                ddv.visitEndLocal(4,L51);
                DexLabel L52=new DexLabel();
                ddv.visitRestartLocal(10,L52);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,7, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT,7,9,new Field("Lorg/mortbay/io/AbstractBuffer;","_hash","I"));
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 11},new Method("Lorg/mortbay/io/Buffer;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitLabel(L2);
                code.visitStmt3R(ADD_INT,7,10,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9},new Method("Lorg/mortbay/io/AbstractBuffer;","capacity",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,8);
                code.visitJumpStmt(IF_LE,7,8,L4);
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9},new Method("Lorg/mortbay/io/AbstractBuffer;","capacity",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,7);
                code.visitStmt3R(SUB_INT,3,7,10);
                code.visitLabel(L4);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 11},new Method("Lorg/mortbay/io/Buffer;","array",new String[]{ },"[B"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitLabel(L5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9},new Method("Lorg/mortbay/io/AbstractBuffer;","array",new String[]{ },"[B"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L6);
                code.visitJumpStmt(IF_EQZ,6,-1,L9);
                code.visitJumpStmt(IF_EQZ,0,-1,L9);
                code.visitLabel(L7);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 11},new Method("Lorg/mortbay/io/Buffer;","getIndex",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,7);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 6,7,0,10,3},new Method("Lorg/mortbay/io/Portable;","arraycopy",new String[]{ "[B","I","[B","I","I"},"V"));
                code.visitLabel(L8);
                code.visitStmt1R(RETURN,3);
                code.visitLabel(L9);
                code.visitJumpStmt(IF_EQZ,6,-1,L24);
                code.visitLabel(L10);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 11},new Method("Lorg/mortbay/io/Buffer;","getIndex",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,4);
                code.visitLabel(L11);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L12);
                code.visitStmt2R(MOVE,5,4);
                code.visitLabel(L13);
                code.visitStmt2R(MOVE,2,10);
                code.visitLabel(L14);
                code.visitJumpStmt(IF_GE,1,3,L22);
                code.visitLabel(L15);
                code.visitStmt2R1N(ADD_INT_LIT8,10,2,1);
                code.visitLabel(L16);
                code.visitStmt2R1N(ADD_INT_LIT8,4,5,1);
                code.visitLabel(L17);
                code.visitStmt3R(AGET_BYTE,7,6,5);
                code.visitLabel(L18);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9,2,7},new Method("Lorg/mortbay/io/AbstractBuffer;","poke",new String[]{ "I","B"},"V"));
                code.visitLabel(L19);
                code.visitStmt2R1N(ADD_INT_LIT8,1,1,1);
                code.visitStmt2R(MOVE,5,4);
                code.visitLabel(L20);
                code.visitStmt2R(MOVE,2,10);
                code.visitLabel(L21);
                code.visitJumpStmt(GOTO,-1,-1,L14);
                code.visitLabel(L22);
                code.visitStmt2R(MOVE,10,2);
                code.visitLabel(L23);
                code.visitJumpStmt(GOTO,-1,-1,L8);
                code.visitLabel(L24);
                code.visitJumpStmt(IF_EQZ,0,-1,L39);
                code.visitLabel(L25);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 11},new Method("Lorg/mortbay/io/Buffer;","getIndex",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,4);
                code.visitLabel(L26);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L27);
                code.visitStmt2R(MOVE,5,4);
                code.visitLabel(L28);
                code.visitStmt2R(MOVE,2,10);
                code.visitLabel(L29);
                code.visitJumpStmt(IF_GE,1,3,L37);
                code.visitLabel(L30);
                code.visitStmt2R1N(ADD_INT_LIT8,10,2,1);
                code.visitLabel(L31);
                code.visitStmt2R1N(ADD_INT_LIT8,4,5,1);
                code.visitLabel(L32);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 11,5},new Method("Lorg/mortbay/io/Buffer;","peek",new String[]{ "I"},"B"));
                code.visitLabel(L33);
                code.visitStmt1R(MOVE_RESULT,7);
                code.visitStmt3R(APUT_BYTE,7,0,2);
                code.visitLabel(L34);
                code.visitStmt2R1N(ADD_INT_LIT8,1,1,1);
                code.visitStmt2R(MOVE,5,4);
                code.visitLabel(L35);
                code.visitStmt2R(MOVE,2,10);
                code.visitLabel(L36);
                code.visitJumpStmt(GOTO,-1,-1,L29);
                code.visitLabel(L37);
                code.visitStmt2R(MOVE,10,2);
                code.visitLabel(L38);
                code.visitJumpStmt(GOTO,-1,-1,L8);
                code.visitLabel(L39);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 11},new Method("Lorg/mortbay/io/Buffer;","getIndex",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,4);
                code.visitLabel(L40);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L41);
                code.visitStmt2R(MOVE,5,4);
                code.visitLabel(L42);
                code.visitStmt2R(MOVE,2,10);
                code.visitLabel(L43);
                code.visitJumpStmt(IF_GE,1,3,L51);
                code.visitLabel(L44);
                code.visitStmt2R1N(ADD_INT_LIT8,10,2,1);
                code.visitLabel(L45);
                code.visitStmt2R1N(ADD_INT_LIT8,4,5,1);
                code.visitLabel(L46);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 11,5},new Method("Lorg/mortbay/io/Buffer;","peek",new String[]{ "I"},"B"));
                code.visitLabel(L47);
                code.visitStmt1R(MOVE_RESULT,7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9,2,7},new Method("Lorg/mortbay/io/AbstractBuffer;","poke",new String[]{ "I","B"},"V"));
                code.visitLabel(L48);
                code.visitStmt2R1N(ADD_INT_LIT8,1,1,1);
                code.visitStmt2R(MOVE,5,4);
                code.visitLabel(L49);
                code.visitStmt2R(MOVE,2,10);
                code.visitLabel(L50);
                code.visitJumpStmt(GOTO,-1,-1,L43);
                code.visitLabel(L51);
                code.visitStmt2R(MOVE,10,2);
                code.visitLabel(L52);
                code.visitJumpStmt(GOTO,-1,-1,L8);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m029_poke(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/io/AbstractBuffer;","poke",new String[]{ "I","[B","I","I"},"I"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(12);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"index");
                ddv.visitParameterName(1,"b");
                ddv.visitParameterName(2,"offset");
                ddv.visitParameterName(3,"length");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(418,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(425,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(427,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(433,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(434,L4);
                ddv.visitStartLocal(0,L4,"dst_array","[B",null);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(435,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(442,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(438,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(439,L8);
                ddv.visitStartLocal(3,L8,"s","I",null);
                DexLabel L9=new DexLabel();
                ddv.visitStartLocal(1,L9,"i","I",null);
                DexLabel L10=new DexLabel();
                ddv.visitStartLocal(4,L10,"s","I",null);
                DexLabel L11=new DexLabel();
                ddv.visitEndLocal(8,L11);
                ddv.visitEndLocal(3,L11);
                ddv.visitStartLocal(2,L11,"index","I",null);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(440,L12);
                DexLabel L13=new DexLabel();
                ddv.visitRestartLocal(8,L13);
                DexLabel L14=new DexLabel();
                ddv.visitRestartLocal(3,L14);
                DexLabel L15=new DexLabel();
                ddv.visitEndLocal(4,L15);
                ddv.visitEndLocal(2,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(439,L16);
                DexLabel L17=new DexLabel();
                ddv.visitRestartLocal(4,L17);
                DexLabel L18=new DexLabel();
                ddv.visitRestartLocal(2,L18);
                DexLabel L19=new DexLabel();
                ddv.visitEndLocal(8,L19);
                ddv.visitEndLocal(3,L19);
                DexLabel L20=new DexLabel();
                ddv.visitRestartLocal(8,L20);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,5, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT,5,7,new Field("Lorg/mortbay/io/AbstractBuffer;","_hash","I"));
                code.visitLabel(L1);
                code.visitStmt3R(ADD_INT,5,8,11);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7},new Method("Lorg/mortbay/io/AbstractBuffer;","capacity",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,6);
                code.visitJumpStmt(IF_LE,5,6,L3);
                code.visitLabel(L2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7},new Method("Lorg/mortbay/io/AbstractBuffer;","capacity",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,5);
                code.visitStmt3R(SUB_INT,11,5,8);
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7},new Method("Lorg/mortbay/io/AbstractBuffer;","array",new String[]{ },"[B"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L4);
                code.visitJumpStmt(IF_EQZ,0,-1,L7);
                code.visitLabel(L5);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 9,10,0,8,11},new Method("Lorg/mortbay/io/Portable;","arraycopy",new String[]{ "[B","I","[B","I","I"},"V"));
                code.visitLabel(L6);
                code.visitStmt1R(RETURN,11);
                code.visitLabel(L7);
                code.visitStmt2R(MOVE,3,10);
                code.visitLabel(L8);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L9);
                code.visitStmt2R(MOVE,4,3);
                code.visitLabel(L10);
                code.visitStmt2R(MOVE,2,8);
                code.visitLabel(L11);
                code.visitJumpStmt(IF_GE,1,11,L19);
                code.visitLabel(L12);
                code.visitStmt2R1N(ADD_INT_LIT8,8,2,1);
                code.visitLabel(L13);
                code.visitStmt2R1N(ADD_INT_LIT8,3,4,1);
                code.visitLabel(L14);
                code.visitStmt3R(AGET_BYTE,5,9,4);
                code.visitLabel(L15);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7,2,5},new Method("Lorg/mortbay/io/AbstractBuffer;","poke",new String[]{ "I","B"},"V"));
                code.visitLabel(L16);
                code.visitStmt2R1N(ADD_INT_LIT8,1,1,1);
                code.visitStmt2R(MOVE,4,3);
                code.visitLabel(L17);
                code.visitStmt2R(MOVE,2,8);
                code.visitLabel(L18);
                code.visitJumpStmt(GOTO,-1,-1,L11);
                code.visitLabel(L19);
                code.visitStmt2R(MOVE,8,2);
                code.visitLabel(L20);
                code.visitJumpStmt(GOTO,-1,-1,L6);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m030_put(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/io/AbstractBuffer;","put",new String[]{ "Lorg/mortbay/io/Buffer;"},"I"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"src");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(447,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(448,L1);
                ddv.visitStartLocal(1,L1,"pi","I",null);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(449,L2);
                ddv.visitStartLocal(0,L2,"l","I",null);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(450,L3);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Lorg/mortbay/io/AbstractBuffer;","putIndex",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,1,4},new Method("Lorg/mortbay/io/AbstractBuffer;","poke",new String[]{ "I","Lorg/mortbay/io/Buffer;"},"I"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitLabel(L2);
                code.visitStmt3R(ADD_INT,2,1,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,2},new Method("Lorg/mortbay/io/AbstractBuffer;","setPutIndex",new String[]{ "I"},"V"));
                code.visitLabel(L3);
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m031_put(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/io/AbstractBuffer;","put",new String[]{ "[B"},"I"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(6);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"b");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(470,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(471,L1);
                ddv.visitStartLocal(1,L1,"pi","I",null);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(472,L2);
                ddv.visitStartLocal(0,L2,"l","I",null);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(473,L3);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Lorg/mortbay/io/AbstractBuffer;","putIndex",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitStmt2R(ARRAY_LENGTH,3,5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,1,5,2,3},new Method("Lorg/mortbay/io/AbstractBuffer;","poke",new String[]{ "I","[B","I","I"},"I"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitLabel(L2);
                code.visitStmt3R(ADD_INT,2,1,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,2},new Method("Lorg/mortbay/io/AbstractBuffer;","setPutIndex",new String[]{ "I"},"V"));
                code.visitLabel(L3);
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m032_put(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/io/AbstractBuffer;","put",new String[]{ "[B","I","I"},"I"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(7);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"b");
                ddv.visitParameterName(1,"offset");
                ddv.visitParameterName(2,"length");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(462,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(463,L1);
                ddv.visitStartLocal(1,L1,"pi","I",null);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(464,L2);
                ddv.visitStartLocal(0,L2,"l","I",null);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(465,L3);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Lorg/mortbay/io/AbstractBuffer;","putIndex",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,1,4,5,6},new Method("Lorg/mortbay/io/AbstractBuffer;","poke",new String[]{ "I","[B","I","I"},"I"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitLabel(L2);
                code.visitStmt3R(ADD_INT,2,1,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,2},new Method("Lorg/mortbay/io/AbstractBuffer;","setPutIndex",new String[]{ "I"},"V"));
                code.visitLabel(L3);
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m033_put(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/io/AbstractBuffer;","put",new String[]{ "B"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"b");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(455,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(456,L1);
                ddv.visitStartLocal(0,L1,"pi","I",null);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(457,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(458,L3);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/io/AbstractBuffer;","putIndex",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,0,3},new Method("Lorg/mortbay/io/AbstractBuffer;","poke",new String[]{ "I","B"},"V"));
                code.visitLabel(L2);
                code.visitStmt2R1N(ADD_INT_LIT8,1,0,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,1},new Method("Lorg/mortbay/io/AbstractBuffer;","setPutIndex",new String[]{ "I"},"V"));
                code.visitLabel(L3);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m034_putIndex(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_FINAL, new Method("Lorg/mortbay/io/AbstractBuffer;","putIndex",new String[]{ },"I"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(478,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET,0,1,new Field("Lorg/mortbay/io/AbstractBuffer;","_put","I"));
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m035_readFrom(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/io/AbstractBuffer;","readFrom",new String[]{ "Ljava/io/InputStream;","I"},"I"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(11);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"in");
                ddv.visitParameterName(1,"max");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(661,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(662,L2);
                ddv.visitStartLocal(0,L2,"array","[B",null);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(663,L3);
                ddv.visitStartLocal(4,L3,"s","I",null);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(664,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(666,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(668,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(669,L7);
                ddv.visitStartLocal(2,L7,"l","I",null);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(670,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(686,L9);
                ddv.visitEndLocal(2,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(675,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(676,L11);
                ddv.visitStartLocal(1,L11,"buf","[B",null);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(677,L12);
                ddv.visitStartLocal(5,L12,"total","I",null);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(679,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(680,L14);
                ddv.visitRestartLocal(2,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(681,L15);
                DexLabel L16=new DexLabel();
                ddv.visitEndLocal(1,L16);
                ddv.visitEndLocal(5,L16);
                ddv.visitEndLocal(2,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(675,L17);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(681,L18);
                ddv.visitRestartLocal(1,L18);
                ddv.visitRestartLocal(2,L18);
                ddv.visitRestartLocal(5,L18);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(682,L19);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(683,L20);
                ddv.visitStartLocal(3,L20,"p","I",null);
                DexLabel L21=new DexLabel();
                ddv.visitLineNumber(684,L21);
                DexLabel L22=new DexLabel();
                ddv.visitLineNumber(685,L22);
                DexLabel L23=new DexLabel();
                ddv.visitEndLocal(2,L23);
                ddv.visitEndLocal(3,L23);
                DexLabel L24=new DexLabel();
                ddv.visitLineNumber(686,L24);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_16,6, Integer.valueOf(1024)); // int: 0x00000400  float:0.000000
                code.visitConstStmt(CONST_4,7, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8},new Method("Lorg/mortbay/io/AbstractBuffer;","array",new String[]{ },"[B"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8},new Method("Lorg/mortbay/io/AbstractBuffer;","space",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,4);
                code.visitLabel(L3);
                code.visitJumpStmt(IF_LE,4,10,L5);
                code.visitLabel(L4);
                code.visitStmt2R(MOVE,4,10);
                code.visitLabel(L5);
                code.visitJumpStmt(IF_EQZ,0,-1,L10);
                code.visitLabel(L6);
                code.visitFieldStmt(IGET,6,8,new Field("Lorg/mortbay/io/AbstractBuffer;","_put","I"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9,0,6,4},new Method("Ljava/io/InputStream;","read",new String[]{ "[B","I","I"},"I"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitLabel(L7);
                DexLabel L25=new DexLabel();
                code.visitJumpStmt(IF_LEZ,2,-1,L25);
                code.visitLabel(L8);
                code.visitFieldStmt(IGET,6,8,new Field("Lorg/mortbay/io/AbstractBuffer;","_put","I"));
                code.visitStmt2R(ADD_INT_2ADDR,6,2);
                code.visitFieldStmt(IPUT,6,8,new Field("Lorg/mortbay/io/AbstractBuffer;","_put","I"));
                code.visitLabel(L25);
                code.visitStmt2R(MOVE,6,2);
                code.visitLabel(L9);
                code.visitStmt1R(RETURN,6);
                code.visitLabel(L10);
                code.visitJumpStmt(IF_LE,4,6,L16);
                DexLabel L26=new DexLabel();
                code.visitLabel(L26);
                code.visitTypeStmt(NEW_ARRAY,1,6,"[B");
                code.visitLabel(L11);
                code.visitConstStmt(CONST_4,5, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L12);
                code.visitJumpStmt(IF_LEZ,4,-1,L23);
                code.visitLabel(L13);
                code.visitStmt2R(ARRAY_LENGTH,6,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 9,1,7,6},new Method("Ljava/io/InputStream;","read",new String[]{ "[B","I","I"},"I"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitLabel(L14);
                code.visitJumpStmt(IF_GEZ,2,-1,L19);
                code.visitLabel(L15);
                code.visitJumpStmt(IF_LEZ,5,-1,L18);
                code.visitStmt2R(MOVE,6,5);
                code.visitJumpStmt(GOTO,-1,-1,L9);
                code.visitLabel(L16);
                code.visitStmt2R(MOVE,6,4);
                code.visitLabel(L17);
                code.visitJumpStmt(GOTO,-1,-1,L26);
                code.visitLabel(L18);
                code.visitConstStmt(CONST_4,6, Integer.valueOf(-1)); // int: 0xffffffff  float:NaN
                code.visitJumpStmt(GOTO,-1,-1,L9);
                code.visitLabel(L19);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8,1,7,2},new Method("Lorg/mortbay/io/AbstractBuffer;","put",new String[]{ "[B","I","I"},"I"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitLabel(L20);
                code.visitFieldStmt(SGET_BOOLEAN,6,-1,new Field("Lorg/mortbay/io/AbstractBuffer;","$assertionsDisabled","Z"));
                code.visitJumpStmt(IF_NEZ,6,-1,L21);
                code.visitJumpStmt(IF_EQ,2,3,L21);
                code.visitTypeStmt(NEW_INSTANCE,6,-1,"Ljava/lang/AssertionError;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 6},new Method("Ljava/lang/AssertionError;","<init>",new String[]{ },"V"));
                code.visitStmt1R(THROW,6);
                code.visitLabel(L21);
                code.visitStmt2R(SUB_INT_2ADDR,4,2);
                code.visitLabel(L22);
                code.visitJumpStmt(GOTO,-1,-1,L12);
                code.visitLabel(L23);
                code.visitStmt2R(MOVE,6,5);
                code.visitLabel(L24);
                code.visitJumpStmt(GOTO,-1,-1,L9);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m036_reset(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/io/AbstractBuffer;","reset",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(483,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(484,L1);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Lorg/mortbay/io/AbstractBuffer;","markIndex",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_LTZ,0,-1,L1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Lorg/mortbay/io/AbstractBuffer;","markIndex",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,0},new Method("Lorg/mortbay/io/AbstractBuffer;","setGetIndex",new String[]{ "I"},"V"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m037_rewind(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/io/AbstractBuffer;","rewind",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(488,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(489,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(490,L2);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,0},new Method("Lorg/mortbay/io/AbstractBuffer;","setGetIndex",new String[]{ "I"},"V"));
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(-1)); // int: 0xffffffff  float:NaN
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,0},new Method("Lorg/mortbay/io/AbstractBuffer;","setMarkIndex",new String[]{ "I"},"V"));
                code.visitLabel(L2);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m038_setGetIndex(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/io/AbstractBuffer;","setGetIndex",new String[]{ "I"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"getIndex");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(502,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(503,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(504,L2);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT,2,1,new Field("Lorg/mortbay/io/AbstractBuffer;","_get","I"));
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT,0,1,new Field("Lorg/mortbay/io/AbstractBuffer;","_hash","I"));
                code.visitLabel(L2);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m039_setMarkIndex(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/io/AbstractBuffer;","setMarkIndex",new String[]{ "I"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"index");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(512,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(513,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT,1,0,new Field("Lorg/mortbay/io/AbstractBuffer;","_mark","I"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m040_setPutIndex(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/io/AbstractBuffer;","setPutIndex",new String[]{ "I"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"putIndex");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(525,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(526,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(527,L2);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT,2,1,new Field("Lorg/mortbay/io/AbstractBuffer;","_put","I"));
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT,0,1,new Field("Lorg/mortbay/io/AbstractBuffer;","_hash","I"));
                code.visitLabel(L2);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m041_skip(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/io/AbstractBuffer;","skip",new String[]{ "I"},"I"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"n");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(531,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(532,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(533,L2);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Lorg/mortbay/io/AbstractBuffer;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_GE,0,2,L1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Lorg/mortbay/io/AbstractBuffer;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Lorg/mortbay/io/AbstractBuffer;","getIndex",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitStmt2R(ADD_INT_2ADDR,0,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,0},new Method("Lorg/mortbay/io/AbstractBuffer;","setGetIndex",new String[]{ "I"},"V"));
                code.visitLabel(L2);
                code.visitStmt1R(RETURN,2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m042_slice(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/io/AbstractBuffer;","slice",new String[]{ },"Lorg/mortbay/io/Buffer;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(538,L0);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/io/AbstractBuffer;","getIndex",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/io/AbstractBuffer;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,0,1},new Method("Lorg/mortbay/io/AbstractBuffer;","peek",new String[]{ "I","I"},"Lorg/mortbay/io/Buffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m043_sliceFromMark(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/io/AbstractBuffer;","sliceFromMark",new String[]{ },"Lorg/mortbay/io/Buffer;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(543,L0);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/io/AbstractBuffer;","getIndex",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/io/AbstractBuffer;","markIndex",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitStmt2R(SUB_INT_2ADDR,0,1);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitStmt2R(SUB_INT_2ADDR,0,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,0},new Method("Lorg/mortbay/io/AbstractBuffer;","sliceFromMark",new String[]{ "I"},"Lorg/mortbay/io/Buffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m044_sliceFromMark(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/io/AbstractBuffer;","sliceFromMark",new String[]{ "I"},"Lorg/mortbay/io/Buffer;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"length");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(548,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(551,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(549,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(550,L3);
                ddv.visitStartLocal(0,L3,"view","Lorg/mortbay/io/Buffer;",null);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(551,L4);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/io/AbstractBuffer;","markIndex",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitJumpStmt(IF_GEZ,1,-1,L2);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L1);
                code.visitStmt1R(RETURN_OBJECT,1);
                code.visitLabel(L2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/io/AbstractBuffer;","markIndex",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,1,3},new Method("Lorg/mortbay/io/AbstractBuffer;","peek",new String[]{ "I","I"},"Lorg/mortbay/io/Buffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L3);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(-1)); // int: 0xffffffff  float:NaN
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,1},new Method("Lorg/mortbay/io/AbstractBuffer;","setMarkIndex",new String[]{ "I"},"V"));
                code.visitStmt2R(MOVE_OBJECT,1,0);
                code.visitLabel(L4);
                code.visitJumpStmt(GOTO,-1,-1,L1);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m045_space(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/io/AbstractBuffer;","space",new String[]{ },"I"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(556,L0);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/io/AbstractBuffer;","capacity",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitFieldStmt(IGET,1,2,new Field("Lorg/mortbay/io/AbstractBuffer;","_put","I"));
                code.visitStmt2R(SUB_INT_2ADDR,0,1);
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m046_toDebugString(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/io/AbstractBuffer;","toDebugString",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(629,L0);
                code.visitLabel(L0);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Ljava/lang/Object;","getClass",new String[]{ },"Ljava/lang/Class;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitConstStmt(CONST_STRING,1,"@");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_SUPER,new int[]{ 2},new Method("Ljava/lang/Object;","hashCode",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "I"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m047_toDetailString(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/io/AbstractBuffer;","toDetailString",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(11);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(561,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(562,L2);
                ddv.visitStartLocal(0,L2,"buf","Ljava/lang/StringBuffer;",null);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(563,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(564,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(565,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(566,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(567,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(568,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(569,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(570,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(571,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(572,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(573,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(574,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(575,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(577,L16);
                DexLabel L17=new DexLabel();
                ddv.visitStartLocal(4,L17,"i","I",null);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(579,L18);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(580,L19);
                ddv.visitStartLocal(1,L19,"c","C",null);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(582,L20);
                DexLabel L21=new DexLabel();
                ddv.visitLineNumber(583,L21);
                DexLabel L22=new DexLabel();
                ddv.visitLineNumber(577,L22);
                DexLabel L23=new DexLabel();
                ddv.visitLineNumber(582,L23);
                DexLabel L24=new DexLabel();
                ddv.visitLineNumber(586,L24);
                DexLabel L25=new DexLabel();
                ddv.visitLineNumber(588,L25);
                ddv.visitEndLocal(1,L25);
                DexLabel L26=new DexLabel();
                ddv.visitLineNumber(590,L26);
                ddv.visitEndLocal(4,L26);
                DexLabel L27=new DexLabel();
                ddv.visitLineNumber(591,L27);
                ddv.visitStartLocal(2,L27,"count","I",null);
                DexLabel L28=new DexLabel();
                ddv.visitRestartLocal(4,L28);
                DexLabel L29=new DexLabel();
                ddv.visitLineNumber(593,L29);
                DexLabel L30=new DexLabel();
                ddv.visitLineNumber(594,L30);
                ddv.visitRestartLocal(1,L30);
                DexLabel L31=new DexLabel();
                ddv.visitLineNumber(596,L31);
                DexLabel L32=new DexLabel();
                ddv.visitLineNumber(597,L32);
                DexLabel L33=new DexLabel();
                ddv.visitLineNumber(601,L33);
                DexLabel L34=new DexLabel();
                ddv.visitStartLocal(3,L34,"count","I",null);
                DexLabel L35=new DexLabel();
                ddv.visitLineNumber(603,L35);
                ddv.visitEndLocal(2,L35);
                DexLabel L36=new DexLabel();
                ddv.visitLineNumber(605,L36);
                DexLabel L37=new DexLabel();
                ddv.visitLineNumber(606,L37);
                DexLabel L38=new DexLabel();
                ddv.visitLineNumber(591,L38);
                DexLabel L39=new DexLabel();
                ddv.visitRestartLocal(2,L39);
                DexLabel L40=new DexLabel();
                ddv.visitLineNumber(596,L40);
                ddv.visitEndLocal(3,L40);
                DexLabel L41=new DexLabel();
                ddv.visitLineNumber(600,L41);
                DexLabel L42=new DexLabel();
                ddv.visitLineNumber(610,L42);
                ddv.visitEndLocal(1,L42);
                DexLabel L43=new DexLabel();
                ddv.visitLineNumber(611,L43);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_16,7, Integer.valueOf(20)); // int: 0x00000014  float:0.000000
                code.visitConstStmt(CONST_16,6, Integer.valueOf(16)); // int: 0x00000010  float:0.000000
                code.visitConstStmt(CONST_STRING,9,"\\0");
                code.visitConstStmt(CONST_STRING,8,"\\");
                code.visitLabel(L1);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/lang/StringBuffer;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/lang/StringBuffer;","<init>",new String[]{ },"V"));
                code.visitLabel(L2);
                code.visitConstStmt(CONST_STRING,5,"[");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,5},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_SUPER,new int[]{ 10},new Method("Ljava/lang/Object;","hashCode",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,5},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "I"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L4);
                code.visitConstStmt(CONST_STRING,5,",");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,5},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10},new Method("Lorg/mortbay/io/AbstractBuffer;","array",new String[]{ },"[B"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Ljava/lang/Object;","hashCode",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,5},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "I"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L6);
                code.visitConstStmt(CONST_STRING,5,",m=");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,5},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10},new Method("Lorg/mortbay/io/AbstractBuffer;","markIndex",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,5},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "I"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L8);
                code.visitConstStmt(CONST_STRING,5,",g=");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,5},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L9);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10},new Method("Lorg/mortbay/io/AbstractBuffer;","getIndex",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,5},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "I"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L10);
                code.visitConstStmt(CONST_STRING,5,",p=");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,5},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L11);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10},new Method("Lorg/mortbay/io/AbstractBuffer;","putIndex",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,5},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "I"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L12);
                code.visitConstStmt(CONST_STRING,5,",c=");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,5},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L13);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10},new Method("Lorg/mortbay/io/AbstractBuffer;","capacity",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,5},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "I"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L14);
                code.visitConstStmt(CONST_STRING,5,"]={");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,5},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L15);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10},new Method("Lorg/mortbay/io/AbstractBuffer;","markIndex",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,5);
                code.visitJumpStmt(IF_LTZ,5,-1,L26);
                code.visitLabel(L16);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10},new Method("Lorg/mortbay/io/AbstractBuffer;","markIndex",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,4);
                code.visitLabel(L17);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10},new Method("Lorg/mortbay/io/AbstractBuffer;","getIndex",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,5);
                code.visitJumpStmt(IF_GE,4,5,L25);
                code.visitLabel(L18);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10,4},new Method("Lorg/mortbay/io/AbstractBuffer;","peek",new String[]{ "I"},"B"));
                code.visitStmt1R(MOVE_RESULT,5);
                code.visitStmt2R(INT_TO_CHAR,1,5);
                code.visitLabel(L19);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1},new Method("Ljava/lang/Character;","isISOControl",new String[]{ "C"},"Z"));
                code.visitStmt1R(MOVE_RESULT,5);
                code.visitJumpStmt(IF_EQZ,5,-1,L24);
                code.visitLabel(L20);
                code.visitJumpStmt(IF_GE,1,6,L23);
                code.visitConstStmt(CONST_STRING,5,"\\0");
                code.visitStmt2R(MOVE_OBJECT,5,9);
                DexLabel L44=new DexLabel();
                code.visitLabel(L44);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,5},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L21);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1,6},new Method("Ljava/lang/Integer;","toString",new String[]{ "I","I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,5},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L22);
                code.visitStmt2R1N(ADD_INT_LIT8,4,4,1);
                code.visitJumpStmt(GOTO,-1,-1,L17);
                code.visitLabel(L23);
                code.visitConstStmt(CONST_STRING,5,"\\");
                code.visitStmt2R(MOVE_OBJECT,5,8);
                code.visitJumpStmt(GOTO,-1,-1,L44);
                code.visitLabel(L24);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "C"},"Ljava/lang/StringBuffer;"));
                code.visitJumpStmt(GOTO,-1,-1,L22);
                code.visitLabel(L25);
                code.visitConstStmt(CONST_STRING,5,"}{");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,5},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L26);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L27);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10},new Method("Lorg/mortbay/io/AbstractBuffer;","getIndex",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,4);
                code.visitLabel(L28);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10},new Method("Lorg/mortbay/io/AbstractBuffer;","putIndex",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,5);
                code.visitJumpStmt(IF_GE,4,5,L42);
                code.visitLabel(L29);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10,4},new Method("Lorg/mortbay/io/AbstractBuffer;","peek",new String[]{ "I"},"B"));
                code.visitStmt1R(MOVE_RESULT,5);
                code.visitStmt2R(INT_TO_CHAR,1,5);
                code.visitLabel(L30);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1},new Method("Ljava/lang/Character;","isISOControl",new String[]{ "C"},"Z"));
                code.visitStmt1R(MOVE_RESULT,5);
                code.visitJumpStmt(IF_EQZ,5,-1,L41);
                code.visitLabel(L31);
                code.visitJumpStmt(IF_GE,1,6,L40);
                code.visitConstStmt(CONST_STRING,5,"\\0");
                code.visitStmt2R(MOVE_OBJECT,5,9);
                DexLabel L45=new DexLabel();
                code.visitLabel(L45);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,5},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L32);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1,6},new Method("Ljava/lang/Integer;","toString",new String[]{ "I","I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,5},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L33);
                code.visitStmt2R1N(ADD_INT_LIT8,3,2,1);
                code.visitLabel(L34);
                code.visitConstStmt(CONST_16,5, Integer.valueOf(50)); // int: 0x00000032  float:0.000000
                code.visitJumpStmt(IF_NE,2,5,L38);
                code.visitLabel(L35);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10},new Method("Lorg/mortbay/io/AbstractBuffer;","putIndex",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,5);
                code.visitStmt2R(SUB_INT_2ADDR,5,4);
                code.visitJumpStmt(IF_LE,5,7,L38);
                code.visitLabel(L36);
                code.visitConstStmt(CONST_STRING,5," ... ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,5},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L37);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 10},new Method("Lorg/mortbay/io/AbstractBuffer;","putIndex",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,5);
                code.visitStmt3R(SUB_INT,4,5,7);
                code.visitLabel(L38);
                code.visitStmt2R1N(ADD_INT_LIT8,4,4,1);
                code.visitStmt2R(MOVE,2,3);
                code.visitLabel(L39);
                code.visitJumpStmt(GOTO,-1,-1,L28);
                code.visitLabel(L40);
                code.visitConstStmt(CONST_STRING,5,"\\");
                code.visitStmt2R(MOVE_OBJECT,5,8);
                code.visitJumpStmt(GOTO,-1,-1,L45);
                code.visitLabel(L41);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "C"},"Ljava/lang/StringBuffer;"));
                code.visitJumpStmt(GOTO,-1,-1,L33);
                code.visitLabel(L42);
                code.visitConstStmt(CONST_16,5, Integer.valueOf(125)); // int: 0x0000007d  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,5},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "C"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L43);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/lang/StringBuffer;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitStmt1R(RETURN_OBJECT,5);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m048_toString(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/io/AbstractBuffer;","toString",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(617,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(619,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(620,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(621,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(623,L5);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Lorg/mortbay/io/AbstractBuffer;","isImmutable",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                DexLabel L6=new DexLabel();
                code.visitJumpStmt(IF_EQZ,0,-1,L6);
                code.visitLabel(L2);
                code.visitFieldStmt(IGET_OBJECT,0,4,new Field("Lorg/mortbay/io/AbstractBuffer;","_string","Ljava/lang/String;"));
                code.visitJumpStmt(IF_NEZ,0,-1,L4);
                code.visitLabel(L3);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/lang/String;");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Lorg/mortbay/io/AbstractBuffer;","asArray",new String[]{ },"[B"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Lorg/mortbay/io/AbstractBuffer;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1,3,2},new Method("Ljava/lang/String;","<init>",new String[]{ "[B","I","I"},"V"));
                code.visitFieldStmt(IPUT_OBJECT,0,4,new Field("Lorg/mortbay/io/AbstractBuffer;","_string","Ljava/lang/String;"));
                code.visitLabel(L4);
                code.visitFieldStmt(IGET_OBJECT,0,4,new Field("Lorg/mortbay/io/AbstractBuffer;","_string","Ljava/lang/String;"));
                code.visitLabel(L5);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitLabel(L6);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/lang/String;");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Lorg/mortbay/io/AbstractBuffer;","asArray",new String[]{ },"[B"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Lorg/mortbay/io/AbstractBuffer;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1,3,2},new Method("Ljava/lang/String;","<init>",new String[]{ "[B","I","I"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L5);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m049_writeTo(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/io/AbstractBuffer;","writeTo",new String[]{ "Ljava/io/OutputStream;"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(9);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"out");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(636,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(638,L2);
                ddv.visitStartLocal(0,L2,"array","[B",null);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(640,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(655,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(656,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(644,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(645,L7);
                ddv.visitStartLocal(3,L7,"len","I",null);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(646,L8);
                ddv.visitStartLocal(1,L8,"buf","[B",null);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(647,L9);
                ddv.visitStartLocal(4,L9,"offset","I",null);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(649,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(650,L11);
                ddv.visitStartLocal(2,L11,"l","I",null);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(651,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(652,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(653,L14);
                DexLabel L15=new DexLabel();
                ddv.visitEndLocal(1,L15);
                ddv.visitEndLocal(4,L15);
                ddv.visitEndLocal(2,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(645,L16);
                DexLabel L17=new DexLabel();
                ddv.visitRestartLocal(1,L17);
                ddv.visitRestartLocal(4,L17);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(649,L18);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_16,5, Integer.valueOf(1024)); // int: 0x00000400  float:0.000000
                code.visitConstStmt(CONST_4,6, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7},new Method("Lorg/mortbay/io/AbstractBuffer;","array",new String[]{ },"[B"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L2);
                code.visitJumpStmt(IF_EQZ,0,-1,L6);
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7},new Method("Lorg/mortbay/io/AbstractBuffer;","getIndex",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7},new Method("Lorg/mortbay/io/AbstractBuffer;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8,0,5,6},new Method("Ljava/io/OutputStream;","write",new String[]{ "[B","I","I"},"V"));
                code.visitLabel(L4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7},new Method("Lorg/mortbay/io/AbstractBuffer;","clear",new String[]{ },"V"));
                code.visitLabel(L5);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7},new Method("Lorg/mortbay/io/AbstractBuffer;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitLabel(L7);
                code.visitJumpStmt(IF_LE,3,5,L15);
                DexLabel L19=new DexLabel();
                code.visitLabel(L19);
                code.visitTypeStmt(NEW_ARRAY,1,5,"[B");
                code.visitLabel(L8);
                code.visitFieldStmt(IGET,4,7,new Field("Lorg/mortbay/io/AbstractBuffer;","_get","I"));
                code.visitLabel(L9);
                code.visitJumpStmt(IF_LEZ,3,-1,L4);
                code.visitLabel(L10);
                code.visitStmt2R(ARRAY_LENGTH,5,1);
                code.visitJumpStmt(IF_LE,3,5,L17);
                code.visitStmt2R(ARRAY_LENGTH,5,1);
                DexLabel L20=new DexLabel();
                code.visitLabel(L20);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7,4,1,6,5},new Method("Lorg/mortbay/io/AbstractBuffer;","peek",new String[]{ "I","[B","I","I"},"I"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitLabel(L11);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8,1,6,2},new Method("Ljava/io/OutputStream;","write",new String[]{ "[B","I","I"},"V"));
                code.visitLabel(L12);
                code.visitStmt2R(ADD_INT_2ADDR,4,2);
                code.visitLabel(L13);
                code.visitStmt2R(SUB_INT_2ADDR,3,2);
                code.visitLabel(L14);
                code.visitJumpStmt(GOTO,-1,-1,L9);
                code.visitLabel(L15);
                code.visitStmt2R(MOVE,5,3);
                code.visitLabel(L16);
                code.visitJumpStmt(GOTO,-1,-1,L19);
                code.visitLabel(L17);
                code.visitStmt2R(MOVE,5,3);
                code.visitLabel(L18);
                code.visitJumpStmt(GOTO,-1,-1,L20);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
