package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0401_org_mortbay_util_ByteArrayISO8859Writer {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(ACC_PUBLIC,"Lorg/mortbay/util/ByteArrayISO8859Writer;","Ljava/io/Writer;",new String[]{ });
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("ByteArrayISO8859Writer.java");
        f000__bout(cv);
        f001__buf(cv);
        f002__fixed(cv);
        f003__size(cv);
        f004__writer(cv);
        m000__init_(cv);
        m001__init_(cv);
        m002__init_(cv);
        m003_writeEncoded(cv);
        m004_capacity(cv);
        m005_close(cv);
        m006_destroy(cv);
        m007_ensureSpareCapacity(cv);
        m008_flush(cv);
        m009_getBuf(cv);
        m010_getByteArray(cv);
        m011_getLock(cv);
        m012_resetWriter(cv);
        m013_setLength(cv);
        m014_size(cv);
        m015_spareCapacity(cv);
        m016_write(cv);
        m017_write(cv);
        m018_write(cv);
        m019_write(cv);
        m020_write(cv);
        m021_writeTo(cv);
    }
    public static void f000__bout(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/util/ByteArrayISO8859Writer;","_bout","Lorg/mortbay/util/ByteArrayOutputStream2;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f001__buf(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/util/ByteArrayISO8859Writer;","_buf","[B"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f002__fixed(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/util/ByteArrayISO8859Writer;","_fixed","Z"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f003__size(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/util/ByteArrayISO8859Writer;","_size","I"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f004__writer(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/util/ByteArrayISO8859Writer;","_writer","Ljava/io/OutputStreamWriter;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void m000__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/util/ByteArrayISO8859Writer;","<init>",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(43,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(35,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(36,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(37,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(44,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(45,L6);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1},new Method("Ljava/io/Writer;","<init>",new String[]{ },"V"));
                code.visitLabel(L2);
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/util/ByteArrayISO8859Writer;","_bout","Lorg/mortbay/util/ByteArrayOutputStream2;"));
                code.visitLabel(L3);
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/util/ByteArrayISO8859Writer;","_writer","Ljava/io/OutputStreamWriter;"));
                code.visitLabel(L4);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT_BOOLEAN,0,1,new Field("Lorg/mortbay/util/ByteArrayISO8859Writer;","_fixed","Z"));
                code.visitLabel(L5);
                code.visitConstStmt(CONST_16,0, Integer.valueOf(2048)); // int: 0x00000800  float:0.000000
                code.visitTypeStmt(NEW_ARRAY,0,0,"[B");
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/util/ByteArrayISO8859Writer;","_buf","[B"));
                code.visitLabel(L6);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/util/ByteArrayISO8859Writer;","<init>",new String[]{ "I"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"capacity");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(52,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(35,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(36,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(37,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(53,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(54,L6);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1},new Method("Ljava/io/Writer;","<init>",new String[]{ },"V"));
                code.visitLabel(L2);
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/util/ByteArrayISO8859Writer;","_bout","Lorg/mortbay/util/ByteArrayOutputStream2;"));
                code.visitLabel(L3);
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/util/ByteArrayISO8859Writer;","_writer","Ljava/io/OutputStreamWriter;"));
                code.visitLabel(L4);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT_BOOLEAN,0,1,new Field("Lorg/mortbay/util/ByteArrayISO8859Writer;","_fixed","Z"));
                code.visitLabel(L5);
                code.visitTypeStmt(NEW_ARRAY,0,2,"[B");
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/util/ByteArrayISO8859Writer;","_buf","[B"));
                code.visitLabel(L6);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m002__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/util/ByteArrayISO8859Writer;","<init>",new String[]{ "[B"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"buf");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(58,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(35,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(36,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(37,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(59,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(60,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(61,L7);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1},new Method("Ljava/io/Writer;","<init>",new String[]{ },"V"));
                code.visitLabel(L2);
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/util/ByteArrayISO8859Writer;","_bout","Lorg/mortbay/util/ByteArrayOutputStream2;"));
                code.visitLabel(L3);
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/util/ByteArrayISO8859Writer;","_writer","Ljava/io/OutputStreamWriter;"));
                code.visitLabel(L4);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT_BOOLEAN,0,1,new Field("Lorg/mortbay/util/ByteArrayISO8859Writer;","_fixed","Z"));
                code.visitLabel(L5);
                code.visitFieldStmt(IPUT_OBJECT,2,1,new Field("Lorg/mortbay/util/ByteArrayISO8859Writer;","_buf","[B"));
                code.visitLabel(L6);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitFieldStmt(IPUT_BOOLEAN,0,1,new Field("Lorg/mortbay/util/ByteArrayISO8859Writer;","_fixed","Z"));
                code.visitLabel(L7);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m003_writeEncoded(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PRIVATE, new Method("Lorg/mortbay/util/ByteArrayISO8859Writer;","writeEncoded",new String[]{ "[C","I","I"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(9);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"ca");
                ddv.visitParameterName(1,"offset");
                ddv.visitParameterName(2,"length");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(203,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(205,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(206,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(210,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(211,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(212,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(213,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(214,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(215,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(209,L9);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,5,new Field("Lorg/mortbay/util/ByteArrayISO8859Writer;","_bout","Lorg/mortbay/util/ByteArrayOutputStream2;"));
                code.visitJumpStmt(IF_NEZ,0,-1,L9);
                code.visitLabel(L1);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Lorg/mortbay/util/ByteArrayOutputStream2;");
                code.visitStmt2R1N(MUL_INT_LIT8,1,8,2);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1},new Method("Lorg/mortbay/util/ByteArrayOutputStream2;","<init>",new String[]{ "I"},"V"));
                code.visitFieldStmt(IPUT_OBJECT,0,5,new Field("Lorg/mortbay/util/ByteArrayISO8859Writer;","_bout","Lorg/mortbay/util/ByteArrayOutputStream2;"));
                code.visitLabel(L2);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/io/OutputStreamWriter;");
                code.visitFieldStmt(IGET_OBJECT,1,5,new Field("Lorg/mortbay/util/ByteArrayISO8859Writer;","_bout","Lorg/mortbay/util/ByteArrayOutputStream2;"));
                code.visitFieldStmt(SGET_OBJECT,2,-1,new Field("Lorg/mortbay/util/StringUtil;","__ISO_8859_1","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1,2},new Method("Ljava/io/OutputStreamWriter;","<init>",new String[]{ "Ljava/io/OutputStream;","Ljava/lang/String;"},"V"));
                code.visitFieldStmt(IPUT_OBJECT,0,5,new Field("Lorg/mortbay/util/ByteArrayISO8859Writer;","_writer","Ljava/io/OutputStreamWriter;"));
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,0,5,new Field("Lorg/mortbay/util/ByteArrayISO8859Writer;","_writer","Ljava/io/OutputStreamWriter;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,6,7,8},new Method("Ljava/io/OutputStreamWriter;","write",new String[]{ "[C","I","I"},"V"));
                code.visitLabel(L4);
                code.visitFieldStmt(IGET_OBJECT,0,5,new Field("Lorg/mortbay/util/ByteArrayISO8859Writer;","_writer","Ljava/io/OutputStreamWriter;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/io/OutputStreamWriter;","flush",new String[]{ },"V"));
                code.visitLabel(L5);
                code.visitFieldStmt(IGET_OBJECT,0,5,new Field("Lorg/mortbay/util/ByteArrayISO8859Writer;","_bout","Lorg/mortbay/util/ByteArrayOutputStream2;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/util/ByteArrayOutputStream2;","getCount",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,0},new Method("Lorg/mortbay/util/ByteArrayISO8859Writer;","ensureSpareCapacity",new String[]{ "I"},"V"));
                code.visitLabel(L6);
                code.visitFieldStmt(IGET_OBJECT,0,5,new Field("Lorg/mortbay/util/ByteArrayISO8859Writer;","_bout","Lorg/mortbay/util/ByteArrayOutputStream2;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/util/ByteArrayOutputStream2;","getBuf",new String[]{ },"[B"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IGET_OBJECT,2,5,new Field("Lorg/mortbay/util/ByteArrayISO8859Writer;","_buf","[B"));
                code.visitFieldStmt(IGET,3,5,new Field("Lorg/mortbay/util/ByteArrayISO8859Writer;","_size","I"));
                code.visitFieldStmt(IGET_OBJECT,4,5,new Field("Lorg/mortbay/util/ByteArrayISO8859Writer;","_bout","Lorg/mortbay/util/ByteArrayOutputStream2;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4},new Method("Lorg/mortbay/util/ByteArrayOutputStream2;","getCount",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,4);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0,1,2,3,4},new Method("Ljava/lang/System;","arraycopy",new String[]{ "Ljava/lang/Object;","I","Ljava/lang/Object;","I","I"},"V"));
                code.visitLabel(L7);
                code.visitFieldStmt(IGET,0,5,new Field("Lorg/mortbay/util/ByteArrayISO8859Writer;","_size","I"));
                code.visitFieldStmt(IGET_OBJECT,1,5,new Field("Lorg/mortbay/util/ByteArrayISO8859Writer;","_bout","Lorg/mortbay/util/ByteArrayOutputStream2;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Lorg/mortbay/util/ByteArrayOutputStream2;","getCount",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,1);
                code.visitStmt2R(ADD_INT_2ADDR,0,1);
                code.visitFieldStmt(IPUT,0,5,new Field("Lorg/mortbay/util/ByteArrayISO8859Writer;","_size","I"));
                code.visitLabel(L8);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L9);
                code.visitFieldStmt(IGET_OBJECT,0,5,new Field("Lorg/mortbay/util/ByteArrayISO8859Writer;","_bout","Lorg/mortbay/util/ByteArrayOutputStream2;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/util/ByteArrayOutputStream2;","reset",new String[]{ },"V"));
                code.visitJumpStmt(GOTO,-1,-1,L3);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m004_capacity(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/util/ByteArrayISO8859Writer;","capacity",new String[]{ },"I"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(78,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/util/ByteArrayISO8859Writer;","_buf","[B"));
                code.visitStmt2R(ARRAY_LENGTH,0,0);
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m005_close(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/util/ByteArrayISO8859Writer;","close",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(1);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(229,L0);
                code.visitLabel(L0);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m006_destroy(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/util/ByteArrayISO8859Writer;","destroy",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(234,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(235,L1);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/util/ByteArrayISO8859Writer;","_buf","[B"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m007_ensureSpareCapacity(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/util/ByteArrayISO8859Writer;","ensureSpareCapacity",new String[]{ "I"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(6);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"n");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(241,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(243,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(244,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(245,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(246,L5);
                ddv.visitStartLocal(0,L5,"buf","[B",null);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(247,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(249,L7);
                ddv.visitEndLocal(0,L7);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L1);
                code.visitFieldStmt(IGET,1,4,new Field("Lorg/mortbay/util/ByteArrayISO8859Writer;","_size","I"));
                code.visitStmt2R(ADD_INT_2ADDR,1,5);
                code.visitFieldStmt(IGET_OBJECT,2,4,new Field("Lorg/mortbay/util/ByteArrayISO8859Writer;","_buf","[B"));
                code.visitStmt2R(ARRAY_LENGTH,2,2);
                code.visitJumpStmt(IF_LE,1,2,L7);
                code.visitLabel(L2);
                code.visitFieldStmt(IGET_BOOLEAN,1,4,new Field("Lorg/mortbay/util/ByteArrayISO8859Writer;","_fixed","Z"));
                code.visitJumpStmt(IF_EQZ,1,-1,L4);
                code.visitLabel(L3);
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Ljava/io/IOException;");
                code.visitTypeStmt(NEW_INSTANCE,2,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,3,"Buffer overflow: ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitFieldStmt(IGET_OBJECT,3,4,new Field("Lorg/mortbay/util/ByteArrayISO8859Writer;","_buf","[B"));
                code.visitStmt2R(ARRAY_LENGTH,3,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "I"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1,2},new Method("Ljava/io/IOException;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitStmt1R(THROW,1);
                code.visitLabel(L4);
                code.visitFieldStmt(IGET_OBJECT,1,4,new Field("Lorg/mortbay/util/ByteArrayISO8859Writer;","_buf","[B"));
                code.visitStmt2R(ARRAY_LENGTH,1,1);
                code.visitStmt2R(ADD_INT_2ADDR,1,5);
                code.visitStmt2R1N(MUL_INT_LIT8,1,1,4);
                code.visitStmt2R1N(DIV_INT_LIT8,1,1,3);
                code.visitTypeStmt(NEW_ARRAY,0,1,"[B");
                code.visitLabel(L5);
                code.visitFieldStmt(IGET_OBJECT,1,4,new Field("Lorg/mortbay/util/ByteArrayISO8859Writer;","_buf","[B"));
                code.visitFieldStmt(IGET,2,4,new Field("Lorg/mortbay/util/ByteArrayISO8859Writer;","_size","I"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1,3,0,3,2},new Method("Ljava/lang/System;","arraycopy",new String[]{ "Ljava/lang/Object;","I","Ljava/lang/Object;","I","I"},"V"));
                code.visitLabel(L6);
                code.visitFieldStmt(IPUT_OBJECT,0,4,new Field("Lorg/mortbay/util/ByteArrayISO8859Writer;","_buf","[B"));
                code.visitLabel(L7);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m008_flush(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/util/ByteArrayISO8859Writer;","flush",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(1);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(219,L0);
                code.visitLabel(L0);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m009_getBuf(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/util/ByteArrayISO8859Writer;","getBuf",new String[]{ },"[B"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(96,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/util/ByteArrayISO8859Writer;","_buf","[B"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m010_getByteArray(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/util/ByteArrayISO8859Writer;","getByteArray",new String[]{ },"[B"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(255,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(256,L2);
                ddv.visitStartLocal(0,L2,"data","[B",null);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(257,L3);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L1);
                code.visitFieldStmt(IGET,1,4,new Field("Lorg/mortbay/util/ByteArrayISO8859Writer;","_size","I"));
                code.visitTypeStmt(NEW_ARRAY,0,1,"[B");
                code.visitLabel(L2);
                code.visitFieldStmt(IGET_OBJECT,1,4,new Field("Lorg/mortbay/util/ByteArrayISO8859Writer;","_buf","[B"));
                code.visitFieldStmt(IGET,2,4,new Field("Lorg/mortbay/util/ByteArrayISO8859Writer;","_size","I"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1,3,0,3,2},new Method("Ljava/lang/System;","arraycopy",new String[]{ "Ljava/lang/Object;","I","Ljava/lang/Object;","I","I"},"V"));
                code.visitLabel(L3);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m011_getLock(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/util/ByteArrayISO8859Writer;","getLock",new String[]{ },"Ljava/lang/Object;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(66,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/util/ByteArrayISO8859Writer;","lock","Ljava/lang/Object;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m012_resetWriter(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/util/ByteArrayISO8859Writer;","resetWriter",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(224,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(225,L1);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT,0,1,new Field("Lorg/mortbay/util/ByteArrayISO8859Writer;","_size","I"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m013_setLength(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/util/ByteArrayISO8859Writer;","setLength",new String[]{ "I"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"l");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(90,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(91,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT,1,0,new Field("Lorg/mortbay/util/ByteArrayISO8859Writer;","_size","I"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m014_size(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/util/ByteArrayISO8859Writer;","size",new String[]{ },"I"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(72,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET,0,1,new Field("Lorg/mortbay/util/ByteArrayISO8859Writer;","_size","I"));
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m015_spareCapacity(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/util/ByteArrayISO8859Writer;","spareCapacity",new String[]{ },"I"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(84,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/util/ByteArrayISO8859Writer;","_buf","[B"));
                code.visitStmt2R(ARRAY_LENGTH,0,0);
                code.visitFieldStmt(IGET,1,2,new Field("Lorg/mortbay/util/ByteArrayISO8859Writer;","_size","I"));
                code.visitStmt2R(SUB_INT_2ADDR,0,1);
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m016_write(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/util/ByteArrayISO8859Writer;","write",new String[]{ "C"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(6);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"c");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(110,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(111,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(112,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(118,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(115,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(116,L6);
                ddv.visitStartLocal(0,L6,"ca","[C",null);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitConstStmt(CONST_4,2, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,2},new Method("Lorg/mortbay/util/ByteArrayISO8859Writer;","ensureSpareCapacity",new String[]{ "I"},"V"));
                code.visitLabel(L2);
                code.visitJumpStmt(IF_LTZ,5,-1,L5);
                code.visitConstStmt(CONST_16,1, Integer.valueOf(127)); // int: 0x0000007f  float:0.000000
                code.visitJumpStmt(IF_GT,5,1,L5);
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,1,4,new Field("Lorg/mortbay/util/ByteArrayISO8859Writer;","_buf","[B"));
                code.visitFieldStmt(IGET,2,4,new Field("Lorg/mortbay/util/ByteArrayISO8859Writer;","_size","I"));
                code.visitStmt2R1N(ADD_INT_LIT8,3,2,1);
                code.visitFieldStmt(IPUT,3,4,new Field("Lorg/mortbay/util/ByteArrayISO8859Writer;","_size","I"));
                code.visitStmt2R(INT_TO_BYTE,3,5);
                code.visitStmt3R(APUT_BYTE,3,1,2);
                code.visitLabel(L4);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L5);
                code.visitTypeStmt(NEW_ARRAY,0,2,"[C");
                code.visitStmt3R(APUT_CHAR,5,0,3);
                code.visitLabel(L6);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 4,0,3,2},new Method("Lorg/mortbay/util/ByteArrayISO8859Writer;","writeEncoded",new String[]{ "[C","I","I"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L4);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m017_write(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/util/ByteArrayISO8859Writer;","write",new String[]{ "Ljava/lang/String;"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(8);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"s");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(160,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(162,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(179,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(166,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(167,L4);
                ddv.visitStartLocal(2,L4,"length","I",null);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(168,L5);
                DexLabel L6=new DexLabel();
                ddv.visitStartLocal(1,L6,"i","I",null);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(170,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(171,L8);
                ddv.visitStartLocal(0,L8,"c","C",null);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(172,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(168,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(175,L11);
                code.visitLabel(L0);
                code.visitJumpStmt(IF_NEZ,7,-1,L3);
                code.visitLabel(L1);
                code.visitConstStmt(CONST_STRING,3,"null");
                code.visitConstStmt(CONST_4,4, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitConstStmt(CONST_4,5, Integer.valueOf(4)); // int: 0x00000004  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,3,4,5},new Method("Lorg/mortbay/util/ByteArrayISO8859Writer;","write",new String[]{ "Ljava/lang/String;","I","I"},"V"));
                code.visitLabel(L2);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7},new Method("Ljava/lang/String;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitLabel(L4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,2},new Method("Lorg/mortbay/util/ByteArrayISO8859Writer;","ensureSpareCapacity",new String[]{ "I"},"V"));
                code.visitLabel(L5);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L6);
                code.visitJumpStmt(IF_GE,1,2,L2);
                code.visitLabel(L7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7,1},new Method("Ljava/lang/String;","charAt",new String[]{ "I"},"C"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitLabel(L8);
                code.visitJumpStmt(IF_LTZ,0,-1,L11);
                code.visitConstStmt(CONST_16,3, Integer.valueOf(127)); // int: 0x0000007f  float:0.000000
                code.visitJumpStmt(IF_GT,0,3,L11);
                code.visitLabel(L9);
                code.visitFieldStmt(IGET_OBJECT,3,6,new Field("Lorg/mortbay/util/ByteArrayISO8859Writer;","_buf","[B"));
                code.visitFieldStmt(IGET,4,6,new Field("Lorg/mortbay/util/ByteArrayISO8859Writer;","_size","I"));
                code.visitStmt2R1N(ADD_INT_LIT8,5,4,1);
                code.visitFieldStmt(IPUT,5,6,new Field("Lorg/mortbay/util/ByteArrayISO8859Writer;","_size","I"));
                code.visitStmt2R(INT_TO_BYTE,5,0);
                code.visitStmt3R(APUT_BYTE,5,3,4);
                code.visitLabel(L10);
                code.visitStmt2R1N(ADD_INT_LIT8,1,1,1);
                code.visitJumpStmt(GOTO,-1,-1,L6);
                code.visitLabel(L11);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7},new Method("Ljava/lang/String;","toCharArray",new String[]{ },"[C"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitStmt3R(SUB_INT,4,2,1);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 6,3,1,4},new Method("Lorg/mortbay/util/ByteArrayISO8859Writer;","writeEncoded",new String[]{ "[C","I","I"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m018_write(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/util/ByteArrayISO8859Writer;","write",new String[]{ "Ljava/lang/String;","I","I"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(9);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"s");
                ddv.visitParameterName(1,"offset");
                ddv.visitParameterName(2,"length");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(185,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(186,L1);
                DexLabel L2=new DexLabel();
                ddv.visitStartLocal(1,L2,"i","I",null);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(188,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(189,L4);
                ddv.visitStartLocal(0,L4,"c","C",null);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(190,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(186,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(193,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(197,L8);
                ddv.visitEndLocal(0,L8);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,8},new Method("Lorg/mortbay/util/ByteArrayISO8859Writer;","ensureSpareCapacity",new String[]{ "I"},"V"));
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L2);
                code.visitJumpStmt(IF_GE,1,8,L8);
                code.visitLabel(L3);
                code.visitStmt3R(ADD_INT,2,7,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,2},new Method("Ljava/lang/String;","charAt",new String[]{ "I"},"C"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitLabel(L4);
                code.visitJumpStmt(IF_LTZ,0,-1,L7);
                code.visitConstStmt(CONST_16,2, Integer.valueOf(127)); // int: 0x0000007f  float:0.000000
                code.visitJumpStmt(IF_GT,0,2,L7);
                code.visitLabel(L5);
                code.visitFieldStmt(IGET_OBJECT,2,5,new Field("Lorg/mortbay/util/ByteArrayISO8859Writer;","_buf","[B"));
                code.visitFieldStmt(IGET,3,5,new Field("Lorg/mortbay/util/ByteArrayISO8859Writer;","_size","I"));
                code.visitStmt2R1N(ADD_INT_LIT8,4,3,1);
                code.visitFieldStmt(IPUT,4,5,new Field("Lorg/mortbay/util/ByteArrayISO8859Writer;","_size","I"));
                code.visitStmt2R(INT_TO_BYTE,4,0);
                code.visitStmt3R(APUT_BYTE,4,2,3);
                code.visitLabel(L6);
                code.visitStmt2R1N(ADD_INT_LIT8,1,1,1);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitLabel(L7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Ljava/lang/String;","toCharArray",new String[]{ },"[C"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitStmt3R(ADD_INT,3,7,1);
                code.visitStmt3R(SUB_INT,4,8,1);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 5,2,3,4},new Method("Lorg/mortbay/util/ByteArrayISO8859Writer;","writeEncoded",new String[]{ "[C","I","I"},"V"));
                code.visitLabel(L8);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m019_write(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/util/ByteArrayISO8859Writer;","write",new String[]{ "[C"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(7);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"ca");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(124,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(125,L1);
                DexLabel L2=new DexLabel();
                ddv.visitStartLocal(1,L2,"i","I",null);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(127,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(128,L4);
                ddv.visitStartLocal(0,L4,"c","C",null);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(129,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(125,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(132,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(136,L8);
                ddv.visitEndLocal(0,L8);
                code.visitLabel(L0);
                code.visitStmt2R(ARRAY_LENGTH,2,6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,2},new Method("Lorg/mortbay/util/ByteArrayISO8859Writer;","ensureSpareCapacity",new String[]{ "I"},"V"));
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L2);
                code.visitStmt2R(ARRAY_LENGTH,2,6);
                code.visitJumpStmt(IF_GE,1,2,L8);
                code.visitLabel(L3);
                code.visitStmt3R(AGET_CHAR,0,6,1);
                code.visitLabel(L4);
                code.visitJumpStmt(IF_LTZ,0,-1,L7);
                code.visitConstStmt(CONST_16,2, Integer.valueOf(127)); // int: 0x0000007f  float:0.000000
                code.visitJumpStmt(IF_GT,0,2,L7);
                code.visitLabel(L5);
                code.visitFieldStmt(IGET_OBJECT,2,5,new Field("Lorg/mortbay/util/ByteArrayISO8859Writer;","_buf","[B"));
                code.visitFieldStmt(IGET,3,5,new Field("Lorg/mortbay/util/ByteArrayISO8859Writer;","_size","I"));
                code.visitStmt2R1N(ADD_INT_LIT8,4,3,1);
                code.visitFieldStmt(IPUT,4,5,new Field("Lorg/mortbay/util/ByteArrayISO8859Writer;","_size","I"));
                code.visitStmt2R(INT_TO_BYTE,4,0);
                code.visitStmt3R(APUT_BYTE,4,2,3);
                code.visitLabel(L6);
                code.visitStmt2R1N(ADD_INT_LIT8,1,1,1);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitLabel(L7);
                code.visitStmt2R(ARRAY_LENGTH,2,6);
                code.visitStmt2R(SUB_INT_2ADDR,2,1);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 5,6,1,2},new Method("Lorg/mortbay/util/ByteArrayISO8859Writer;","writeEncoded",new String[]{ "[C","I","I"},"V"));
                code.visitLabel(L8);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m020_write(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/util/ByteArrayISO8859Writer;","write",new String[]{ "[C","I","I"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(9);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"ca");
                ddv.visitParameterName(1,"offset");
                ddv.visitParameterName(2,"length");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(142,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(143,L1);
                DexLabel L2=new DexLabel();
                ddv.visitStartLocal(1,L2,"i","I",null);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(145,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(146,L4);
                ddv.visitStartLocal(0,L4,"c","C",null);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(147,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(143,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(150,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(154,L8);
                ddv.visitEndLocal(0,L8);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,8},new Method("Lorg/mortbay/util/ByteArrayISO8859Writer;","ensureSpareCapacity",new String[]{ "I"},"V"));
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L2);
                code.visitJumpStmt(IF_GE,1,8,L8);
                code.visitLabel(L3);
                code.visitStmt3R(ADD_INT,2,7,1);
                code.visitStmt3R(AGET_CHAR,0,6,2);
                code.visitLabel(L4);
                code.visitJumpStmt(IF_LTZ,0,-1,L7);
                code.visitConstStmt(CONST_16,2, Integer.valueOf(127)); // int: 0x0000007f  float:0.000000
                code.visitJumpStmt(IF_GT,0,2,L7);
                code.visitLabel(L5);
                code.visitFieldStmt(IGET_OBJECT,2,5,new Field("Lorg/mortbay/util/ByteArrayISO8859Writer;","_buf","[B"));
                code.visitFieldStmt(IGET,3,5,new Field("Lorg/mortbay/util/ByteArrayISO8859Writer;","_size","I"));
                code.visitStmt2R1N(ADD_INT_LIT8,4,3,1);
                code.visitFieldStmt(IPUT,4,5,new Field("Lorg/mortbay/util/ByteArrayISO8859Writer;","_size","I"));
                code.visitStmt2R(INT_TO_BYTE,4,0);
                code.visitStmt3R(APUT_BYTE,4,2,3);
                code.visitLabel(L6);
                code.visitStmt2R1N(ADD_INT_LIT8,1,1,1);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitLabel(L7);
                code.visitStmt3R(ADD_INT,2,7,1);
                code.visitStmt3R(SUB_INT,3,8,1);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 5,6,2,3},new Method("Lorg/mortbay/util/ByteArrayISO8859Writer;","writeEncoded",new String[]{ "[C","I","I"},"V"));
                code.visitLabel(L8);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m021_writeTo(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/util/ByteArrayISO8859Writer;","writeTo",new String[]{ "Ljava/io/OutputStream;"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"out");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(103,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(104,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,3,new Field("Lorg/mortbay/util/ByteArrayISO8859Writer;","_buf","[B"));
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IGET,2,3,new Field("Lorg/mortbay/util/ByteArrayISO8859Writer;","_size","I"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 4,0,1,2},new Method("Ljava/io/OutputStream;","write",new String[]{ "[B","I","I"},"V"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
