package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0339_org_mortbay_jetty_servlet_Invoker_Request {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(0,"Lorg/mortbay/jetty/servlet/Invoker$Request;","Ljavax/servlet/http/HttpServletRequestWrapper;",new String[]{ });
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("Invoker.java");
        if(cv!=null){
            DexAnnotationVisitor av00 = cv.visitAnnotation("Ldalvik/annotation/EnclosingClass;", Visibility.SYSTEM);
            if(av00 != null) {
                av00.visit("value", new DexType("Lorg/mortbay/jetty/servlet/Invoker;"));
                av00.visitEnd();
            }
        }
        if(cv!=null){
            DexAnnotationVisitor av00 = cv.visitAnnotation("Ldalvik/annotation/InnerClass;", Visibility.SYSTEM);
            if(av00 != null) {
                av00.visit("accessFlags",  Integer.valueOf(0));
                av00.visit("name", "Request");
                av00.visitEnd();
            }
        }
        f000__included(cv);
        f001__pathInfo(cv);
        f002__servletPath(cv);
        f003_this$0(cv);
        m000__init_(cv);
        m001_getAttribute(cv);
        m002_getPathInfo(cv);
        m003_getServletPath(cv);
    }
    public static void f000__included(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(0, new Field("Lorg/mortbay/jetty/servlet/Invoker$Request;","_included","Z"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f001__pathInfo(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(0, new Field("Lorg/mortbay/jetty/servlet/Invoker$Request;","_pathInfo","Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f002__servletPath(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(0, new Field("Lorg/mortbay/jetty/servlet/Invoker$Request;","_servletPath","Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f003_this$0(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_FINAL|ACC_SYNTHETIC, new Field("Lorg/mortbay/jetty/servlet/Invoker$Request;","this$0","Lorg/mortbay/jetty/servlet/Invoker;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void m000__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_CONSTRUCTOR, new Method("Lorg/mortbay/jetty/servlet/Invoker$Request;","<init>",new String[]{ "Lorg/mortbay/jetty/servlet/Invoker;","Ljavax/servlet/http/HttpServletRequest;","Z","Ljava/lang/String;","Ljava/lang/String;","Ljava/lang/String;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(8);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(1,"request");
                ddv.visitParameterName(2,"included");
                ddv.visitParameterName(3,"name");
                ddv.visitParameterName(4,"servletPath");
                ddv.visitParameterName(5,"pathInfo");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(242,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(243,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(244,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(245,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(246,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(247,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(248,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(249,L7);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_OBJECT,2,1,new Field("Lorg/mortbay/jetty/servlet/Invoker$Request;","this$0","Lorg/mortbay/jetty/servlet/Invoker;"));
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1,3},new Method("Ljavax/servlet/http/HttpServletRequestWrapper;","<init>",new String[]{ "Ljavax/servlet/http/HttpServletRequest;"},"V"));
                code.visitLabel(L2);
                code.visitFieldStmt(IPUT_BOOLEAN,4,1,new Field("Lorg/mortbay/jetty/servlet/Invoker$Request;","_included","Z"));
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 6,5},new Method("Lorg/mortbay/util/URIUtil;","addPaths",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/jetty/servlet/Invoker$Request;","_servletPath","Ljava/lang/String;"));
                code.visitLabel(L4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Ljava/lang/String;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitStmt2R1N(ADD_INT_LIT8,0,0,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7,0},new Method("Ljava/lang/String;","substring",new String[]{ "I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/jetty/servlet/Invoker$Request;","_pathInfo","Ljava/lang/String;"));
                code.visitLabel(L5);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/servlet/Invoker$Request;","_pathInfo","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/lang/String;","length",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_NEZ,0,-1,L7);
                code.visitLabel(L6);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/jetty/servlet/Invoker$Request;","_pathInfo","Ljava/lang/String;"));
                code.visitLabel(L7);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001_getAttribute(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/servlet/Invoker$Request;","getAttribute",new String[]{ "Ljava/lang/String;"},"Ljava/lang/Object;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"name");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(270,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(272,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(273,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(279,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(274,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(275,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(276,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(277,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(279,L8);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_BOOLEAN,0,2,new Field("Lorg/mortbay/jetty/servlet/Invoker$Request;","_included","Z"));
                code.visitJumpStmt(IF_EQZ,0,-1,L8);
                code.visitLabel(L1);
                code.visitConstStmt(CONST_STRING,0,"javax.servlet.include.request_uri");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,0},new Method("Ljava/lang/String;","equals",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_EQZ,0,-1,L4);
                code.visitLabel(L2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/jetty/servlet/Invoker$Request;","getContextPath",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/jetty/servlet/Invoker$Request;","_servletPath","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0,1},new Method("Lorg/mortbay/util/URIUtil;","addPaths",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/jetty/servlet/Invoker$Request;","_pathInfo","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0,1},new Method("Lorg/mortbay/util/URIUtil;","addPaths",new String[]{ "Ljava/lang/String;","Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L3);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitLabel(L4);
                code.visitConstStmt(CONST_STRING,0,"javax.servlet.include.path_info");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,0},new Method("Ljava/lang/String;","equals",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_EQZ,0,-1,L6);
                code.visitLabel(L5);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/jetty/servlet/Invoker$Request;","_pathInfo","Ljava/lang/String;"));
                code.visitJumpStmt(GOTO,-1,-1,L3);
                code.visitLabel(L6);
                code.visitConstStmt(CONST_STRING,0,"javax.servlet.include.servlet_path");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,0},new Method("Ljava/lang/String;","equals",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_EQZ,0,-1,L8);
                code.visitLabel(L7);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/jetty/servlet/Invoker$Request;","_servletPath","Ljava/lang/String;"));
                code.visitJumpStmt(GOTO,-1,-1,L3);
                code.visitLabel(L8);
                code.visitMethodStmt(INVOKE_SUPER,new int[]{ 2,3},new Method("Ljavax/servlet/http/HttpServletRequestWrapper;","getAttribute",new String[]{ "Ljava/lang/String;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitJumpStmt(GOTO,-1,-1,L3);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m002_getPathInfo(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/servlet/Invoker$Request;","getPathInfo",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(262,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(263,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(264,L2);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_BOOLEAN,0,1,new Field("Lorg/mortbay/jetty/servlet/Invoker$Request;","_included","Z"));
                DexLabel L3=new DexLabel();
                code.visitJumpStmt(IF_EQZ,0,-1,L3);
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_SUPER,new int[]{ 1},new Method("Ljavax/servlet/http/HttpServletRequestWrapper;","getPathInfo",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L2);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/servlet/Invoker$Request;","_pathInfo","Ljava/lang/String;"));
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m003_getServletPath(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/servlet/Invoker$Request;","getServletPath",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(254,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(255,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(256,L2);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_BOOLEAN,0,1,new Field("Lorg/mortbay/jetty/servlet/Invoker$Request;","_included","Z"));
                DexLabel L3=new DexLabel();
                code.visitJumpStmt(IF_EQZ,0,-1,L3);
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_SUPER,new int[]{ 1},new Method("Ljavax/servlet/http/HttpServletRequestWrapper;","getServletPath",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L2);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/servlet/Invoker$Request;","_servletPath","Ljava/lang/String;"));
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
