package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0338_org_mortbay_jetty_servlet_HashSessionManager {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(ACC_PUBLIC,"Lorg/mortbay/jetty/servlet/HashSessionManager;","Lorg/mortbay/jetty/servlet/AbstractSessionManager;",new String[]{ });
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("HashSessionManager.java");
        if(cv!=null){
            DexAnnotationVisitor av00 = cv.visitAnnotation("Ldalvik/annotation/MemberClasses;", Visibility.SYSTEM);
            if(av00 != null) {
                {
                    DexAnnotationVisitor av01 = av00.visitArray("value");
                    if(av01 != null) {
                        av01.visit(null, new DexType("Lorg/mortbay/jetty/servlet/HashSessionManager$ClassLoadingObjectInputStream;"));
                        av01.visit(null, new DexType("Lorg/mortbay/jetty/servlet/HashSessionManager$Session;"));
                        av01.visitEnd();
                    }
                }
                av00.visitEnd();
            }
        }
        f000__lazyLoad(cv);
        f001__savePeriodMs(cv);
        f002__saveTask(cv);
        f003__scavengePeriodMs(cv);
        f004__sessions(cv);
        f005__sessionsLoaded(cv);
        f006__storeDir(cv);
        f007__task(cv);
        f008__timer(cv);
        m000__init_(cv);
        m001_access$000(cv);
        m002_access$100(cv);
        m003_access$200(cv);
        m004_scavenge(cv);
        m005_addSession(cv);
        m006_doStart(cv);
        m007_doStop(cv);
        m008_getSavePeriod(cv);
        m009_getScavengePeriod(cv);
        m010_getSession(cv);
        m011_getSessionMap(cv);
        m012_getSessions(cv);
        m013_getStoreDirectory(cv);
        m014_invalidateSessions(cv);
        m015_isLazyLoad(cv);
        m016_newSession(cv);
        m017_removeSession(cv);
        m018_restoreSession(cv);
        m019_restoreSessions(cv);
        m020_saveSessions(cv);
        m021_setLazyLoad(cv);
        m022_setMaxInactiveInterval(cv);
        m023_setSavePeriod(cv);
        m024_setScavengePeriod(cv);
        m025_setStoreDirectory(cv);
    }
    public static void f000__lazyLoad(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/servlet/HashSessionManager;","_lazyLoad","Z"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f001__savePeriodMs(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/servlet/HashSessionManager;","_savePeriodMs","I"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f002__saveTask(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/servlet/HashSessionManager;","_saveTask","Ljava/util/TimerTask;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f003__scavengePeriodMs(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/servlet/HashSessionManager;","_scavengePeriodMs","I"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f004__sessions(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PROTECTED, new Field("Lorg/mortbay/jetty/servlet/HashSessionManager;","_sessions","Ljava/util/Map;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f005__sessionsLoaded(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/servlet/HashSessionManager;","_sessionsLoaded","Z"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f006__storeDir(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/servlet/HashSessionManager;","_storeDir","Ljava/io/File;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f007__task(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/servlet/HashSessionManager;","_task","Ljava/util/TimerTask;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f008__timer(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/servlet/HashSessionManager;","_timer","Ljava/util/Timer;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void m000__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/jetty/servlet/HashSessionManager;","<init>",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(59,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(48,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(49,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(53,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(54,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(60,L6);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2},new Method("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","<init>",new String[]{ },"V"));
                code.visitLabel(L2);
                code.visitConstStmt(CONST_16,0, Integer.valueOf(30000)); // int: 0x00007530  float:0.000000
                code.visitFieldStmt(IPUT,0,2,new Field("Lorg/mortbay/jetty/servlet/HashSessionManager;","_scavengePeriodMs","I"));
                code.visitLabel(L3);
                code.visitFieldStmt(IPUT,1,2,new Field("Lorg/mortbay/jetty/servlet/HashSessionManager;","_savePeriodMs","I"));
                code.visitLabel(L4);
                code.visitFieldStmt(IPUT_BOOLEAN,1,2,new Field("Lorg/mortbay/jetty/servlet/HashSessionManager;","_lazyLoad","Z"));
                code.visitLabel(L5);
                code.visitFieldStmt(IPUT_BOOLEAN,1,2,new Field("Lorg/mortbay/jetty/servlet/HashSessionManager;","_sessionsLoaded","Z"));
                code.visitLabel(L6);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001_access$000(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_STATIC|ACC_SYNTHETIC, new Method("Lorg/mortbay/jetty/servlet/HashSessionManager;","access$000",new String[]{ "Lorg/mortbay/jetty/servlet/HashSessionManager;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(1);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"x0");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(44,L0);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Lorg/mortbay/jetty/servlet/HashSessionManager;","scavenge",new String[]{ },"V"));
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m002_access$100(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_STATIC|ACC_SYNTHETIC, new Method("Lorg/mortbay/jetty/servlet/HashSessionManager;","access$100",new String[]{ "Lorg/mortbay/jetty/servlet/HashSessionManager;"},"I"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"x0");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(44,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET,0,1,new Field("Lorg/mortbay/jetty/servlet/HashSessionManager;","_scavengePeriodMs","I"));
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m003_access$200(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_STATIC|ACC_SYNTHETIC, new Method("Lorg/mortbay/jetty/servlet/HashSessionManager;","access$200",new String[]{ "Lorg/mortbay/jetty/servlet/HashSessionManager;"},"Ljava/io/File;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"x0");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(44,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/servlet/HashSessionManager;","_storeDir","Ljava/io/File;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m004_scavenge(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PRIVATE, new Method("Lorg/mortbay/jetty/servlet/HashSessionManager;","scavenge",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(21);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                DexLabel L3=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2,L3},new String[]{ "Ljava/lang/Throwable;",null});
                DexLabel L4=new DexLabel();
                DexLabel L5=new DexLabel();
                DexLabel L6=new DexLabel();
                code.visitTryCatch(L4,L5,new DexLabel[]{L6,L2,L3},new String[]{ "Ljava/lang/Exception;","Ljava/lang/Throwable;",null});
                DexLabel L7=new DexLabel();
                DexLabel L8=new DexLabel();
                code.visitTryCatch(L7,L8,new DexLabel[]{L2,L3},new String[]{ "Ljava/lang/Throwable;",null});
                DexLabel L9=new DexLabel();
                DexLabel L10=new DexLabel();
                code.visitTryCatch(L8,L9,new DexLabel[]{L10},new String[]{ null});
                DexLabel L11=new DexLabel();
                DexLabel L12=new DexLabel();
                code.visitTryCatch(L11,L12,new DexLabel[]{L2,L3},new String[]{ "Ljava/lang/Throwable;",null});
                DexLabel L13=new DexLabel();
                code.visitTryCatch(L13,L3,new DexLabel[]{L3},new String[]{ null});
                DexLabel L14=new DexLabel();
                DexLabel L15=new DexLabel();
                code.visitTryCatch(L14,L15,new DexLabel[]{L10},new String[]{ null});
                DexLabel L16=new DexLabel();
                code.visitTryCatch(L15,L16,new DexLabel[]{L2,L3},new String[]{ "Ljava/lang/Throwable;",null});
                DexLabel L17=new DexLabel();
                DexLabel L18=new DexLabel();
                code.visitTryCatch(L17,L18,new DexLabel[]{L10},new String[]{ null});
                DexLabel L19=new DexLabel();
                code.visitTryCatch(L18,L19,new DexLabel[]{L2,L3},new String[]{ "Ljava/lang/Throwable;",null});
                DexLabel L20=new DexLabel();
                code.visitTryCatch(L19,L20,new DexLabel[]{L3},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L21=new DexLabel();
                ddv.visitPrologue(L21);
                ddv.visitLineNumber(233,L21);
                DexLabel L22=new DexLabel();
                ddv.visitLineNumber(301,L22);
                DexLabel L23=new DexLabel();
                ddv.visitLineNumber(236,L23);
                DexLabel L24=new DexLabel();
                ddv.visitLineNumber(237,L24);
                ddv.visitStartLocal(14,L24,"thread","Ljava/lang/Thread;",null);
                ddv.visitLineNumber(240,L0);
                ddv.visitStartLocal(10,L0,"old_loader","Ljava/lang/ClassLoader;",null);
                DexLabel L25=new DexLabel();
                ddv.visitLineNumber(241,L25);
                DexLabel L26=new DexLabel();
                ddv.visitLineNumber(243,L26);
                ddv.visitLineNumber(247,L4);
                ddv.visitStartLocal(8,L4,"now","J",null);
                DexLabel L27=new DexLabel();
                ddv.visitLineNumber(248,L27);
                ddv.visitLineNumber(258,L5);
                ddv.visitLineNumber(260,L7);
                ddv.visitStartLocal(12,L7,"stale","Ljava/lang/Object;",null);
                ddv.visitLineNumber(263,L8);
                DexLabel L28=new DexLabel();
                ddv.visitStartLocal(3,L28,"i","Ljava/util/Iterator;",null);
                DexLabel L29=new DexLabel();
                ddv.visitEndLocal(12,L29);
                DexLabel L30=new DexLabel();
                ddv.visitLineNumber(265,L30);
                DexLabel L31=new DexLabel();
                ddv.visitLineNumber(266,L31);
                ddv.visitStartLocal(11,L31,"session","Lorg/mortbay/jetty/servlet/HashSessionManager$Session;",null);
                DexLabel L32=new DexLabel();
                ddv.visitLineNumber(267,L32);
                ddv.visitStartLocal(5,L32,"idleTime","J",null);
                DexLabel L33=new DexLabel();
                ddv.visitLineNumber(270,L33);
                DexLabel L34=new DexLabel();
                ddv.visitStartLocal(12,L34,"stale","Ljava/lang/Object;",null);
                ddv.visitLineNumber(250,L6);
                ddv.visitEndLocal(3,L6);
                ddv.visitEndLocal(11,L6);
                ddv.visitEndLocal(5,L6);
                ddv.visitEndLocal(12,L6);
                ddv.visitLineNumber(252,L11);
                ddv.visitStartLocal(2,L11,"e","Ljava/lang/Exception;",null);
                ddv.visitLineNumber(290,L2);
                ddv.visitEndLocal(8,L2);
                ddv.visitEndLocal(2,L2);
                ddv.visitLineNumber(292,L13);
                ddv.visitStartLocal(13,L13,"t","Ljava/lang/Throwable;",null);
                DexLabel L35=new DexLabel();
                ddv.visitLineNumber(293,L35);
                DexLabel L36=new DexLabel();
                ddv.visitEndLocal(13,L36);
                ddv.visitLineNumber(299,L3);
                ddv.visitLineNumber(273,L14);
                ddv.visitRestartLocal(3,L14);
                ddv.visitRestartLocal(8,L14);
                ddv.visitLineNumber(276,L15);
                DexLabel L37=new DexLabel();
                ddv.visitStartLocal(3,L37,"i","I",null);
                DexLabel L38=new DexLabel();
                ddv.visitEndLocal(3,L38);
                ddv.visitStartLocal(4,L38,"i","I",null);
                DexLabel L39=new DexLabel();
                ddv.visitRestartLocal(3,L39);
                DexLabel L40=new DexLabel();
                ddv.visitLineNumber(279,L40);
                ddv.visitEndLocal(4,L40);
                DexLabel L41=new DexLabel();
                ddv.visitLineNumber(280,L41);
                ddv.visitRestartLocal(11,L41);
                DexLabel L42=new DexLabel();
                ddv.visitLineNumber(281,L42);
                ddv.visitRestartLocal(5,L42);
                DexLabel L43=new DexLabel();
                ddv.visitLineNumber(283,L43);
                DexLabel L44=new DexLabel();
                ddv.visitLineNumber(284,L44);
                DexLabel L45=new DexLabel();
                ddv.visitLineNumber(285,L45);
                ddv.visitStartLocal(7,L45,"nbsess","I",null);
                DexLabel L46=new DexLabel();
                ddv.visitLineNumber(286,L46);
                ddv.visitEndLocal(7,L16);
                DexLabel L47=new DexLabel();
                ddv.visitLineNumber(288,L47);
                ddv.visitRestartLocal(4,L47);
                ddv.visitLineNumber(273,L10);
                ddv.visitEndLocal(3,L10);
                ddv.visitEndLocal(11,L10);
                ddv.visitEndLocal(5,L10);
                ddv.visitEndLocal(4,L10);
                ddv.visitLineNumber(295,L19);
                ddv.visitEndLocal(8,L19);
                ddv.visitRestartLocal(13,L19);
                ddv.visitLineNumber(299,L20);
                ddv.visitEndLocal(13,L20);
                code.visitLabel(L21);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 20},new Method("Lorg/mortbay/jetty/servlet/HashSessionManager;","isStopping",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,15);
                code.visitJumpStmt(IF_NEZ,15,-1,L22);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 20},new Method("Lorg/mortbay/jetty/servlet/HashSessionManager;","isStopped",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,15);
                code.visitJumpStmt(IF_EQZ,15,-1,L23);
                code.visitLabel(L22);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L23);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Ljava/lang/Thread;","currentThread",new String[]{ },"Ljava/lang/Thread;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,14);
                code.visitLabel(L24);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 14},new Method("Ljava/lang/Thread;","getContextClassLoader",new String[]{ },"Ljava/lang/ClassLoader;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,10);
                code.visitLabel(L0);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,20);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/servlet/HashSessionManager;","_loader","Ljava/lang/ClassLoader;"));
                code.visitStmt2R(MOVE_OBJECT,15,0);
                code.visitJumpStmt(IF_EQZ,15,-1,L26);
                code.visitLabel(L25);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,20);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/servlet/HashSessionManager;","_loader","Ljava/lang/ClassLoader;"));
                code.visitStmt2R(MOVE_OBJECT,15,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 14,15},new Method("Ljava/lang/Thread;","setContextClassLoader",new String[]{ "Ljava/lang/ClassLoader;"},"V"));
                code.visitLabel(L26);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Ljava/lang/System;","currentTimeMillis",new String[]{ },"J"));
                code.visitLabel(L1);
                code.visitStmt1R(MOVE_RESULT_WIDE,8);
                code.visitLabel(L4);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,20);
                code.visitFieldStmt(IGET_BOOLEAN,0,0,new Field("Lorg/mortbay/jetty/servlet/HashSessionManager;","_sessionsLoaded","Z"));
                code.visitStmt2R(MOVE,15,0);
                code.visitJumpStmt(IF_NEZ,15,-1,L5);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,20);
                code.visitFieldStmt(IGET_BOOLEAN,0,0,new Field("Lorg/mortbay/jetty/servlet/HashSessionManager;","_lazyLoad","Z"));
                code.visitStmt2R(MOVE,15,0);
                code.visitJumpStmt(IF_EQZ,15,-1,L5);
                code.visitLabel(L27);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 20},new Method("Lorg/mortbay/jetty/servlet/HashSessionManager;","restoreSessions",new String[]{ },"V"));
                code.visitLabel(L5);
                code.visitConstStmt(CONST_4,12, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L7);
                code.visitStmt1R(MONITOR_ENTER,20);
                code.visitLabel(L8);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,20);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/servlet/HashSessionManager;","_sessions","Ljava/util/Map;"));
                code.visitStmt2R(MOVE_OBJECT,15,0);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 15},new Method("Ljava/util/Map;","values",new String[]{ },"Ljava/util/Collection;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,15);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 15},new Method("Ljava/util/Collection;","iterator",new String[]{ },"Ljava/util/Iterator;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitLabel(L28);
                code.visitStmt2R(MOVE_OBJECT,15,12);
                code.visitLabel(L29);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 3},new Method("Ljava/util/Iterator;","hasNext",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,16);
                code.visitJumpStmt(IF_EQZ,16,-1,L14);
                code.visitLabel(L30);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 3},new Method("Ljava/util/Iterator;","next",new String[]{ },"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,11);
                code.visitTypeStmt(CHECK_CAST,11,-1,"Lorg/mortbay/jetty/servlet/HashSessionManager$Session;");
                code.visitLabel(L31);
                code.visitFieldStmt(IGET_WIDE,5,11,new Field("Lorg/mortbay/jetty/servlet/HashSessionManager$Session;","_maxIdleMs","J"));
                code.visitLabel(L32);
                code.visitConstStmt(CONST_WIDE_16,16,Long.valueOf(0L)); // long: 0x0000000000000000  double:0.000000
                code.visitStmt3R(CMP_LONG,16,5,16);
                code.visitJumpStmt(IF_LEZ,16,-1,L29);
                code.visitStmt2R(MOVE_OBJECT,0,11);
                code.visitFieldStmt(IGET_WIDE,0,0,new Field("Lorg/mortbay/jetty/servlet/HashSessionManager$Session;","_accessed","J"));
                code.visitStmt2R(MOVE_WIDE_FROM16,16,0);
                code.visitStmt3R(ADD_LONG,16,16,5);
                code.visitStmt3R(CMP_LONG,16,16,8);
                code.visitJumpStmt(IF_GEZ,16,-1,L29);
                code.visitLabel(L33);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 15,11},new Method("Lorg/mortbay/util/LazyList;","add",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitLabel(L9);
                code.visitStmt1R(MOVE_RESULT_OBJECT,12);
                code.visitLabel(L34);
                code.visitStmt2R(MOVE_OBJECT,15,12);
                code.visitJumpStmt(GOTO,-1,-1,L29);
                code.visitLabel(L6);
                code.visitStmt1R(MOVE_EXCEPTION,15);
                code.visitStmt2R(MOVE_OBJECT,2,15);
                code.visitLabel(L11);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 2},new Method("Lorg/mortbay/log/Log;","debug",new String[]{ "Ljava/lang/Throwable;"},"V"));
                code.visitLabel(L12);
                code.visitJumpStmt(GOTO,-1,-1,L5);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,15);
                code.visitStmt2R(MOVE_OBJECT,13,15);
                code.visitLabel(L13);
                code.visitTypeStmt(INSTANCE_OF,15,13,"Ljava/lang/ThreadDeath;");
                code.visitJumpStmt(IF_EQZ,15,-1,L19);
                code.visitLabel(L35);
                code.visitTypeStmt(CHECK_CAST,13,-1,"Ljava/lang/ThreadDeath;");
                code.visitLabel(L36);
                code.visitStmt1R(THROW,13);
                code.visitLabel(L3);
                code.visitStmt1R(MOVE_EXCEPTION,15);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 14,10},new Method("Ljava/lang/Thread;","setContextClassLoader",new String[]{ "Ljava/lang/ClassLoader;"},"V"));
                code.visitStmt1R(THROW,15);
                code.visitLabel(L14);
                code.visitStmt1R(MONITOR_EXIT,20);
                code.visitLabel(L15);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 15},new Method("Lorg/mortbay/util/LazyList;","size",new String[]{ "Ljava/lang/Object;"},"I"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitLabel(L37);
                code.visitStmt2R(MOVE,4,3);
                code.visitLabel(L38);
                code.visitConstStmt(CONST_16,16, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitStmt3R(SUB_INT,3,4,16);
                code.visitLabel(L39);
                code.visitJumpStmt(IF_LEZ,4,-1,L20);
                code.visitLabel(L40);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 15,3},new Method("Lorg/mortbay/util/LazyList;","get",new String[]{ "Ljava/lang/Object;","I"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,11);
                code.visitTypeStmt(CHECK_CAST,11,-1,"Lorg/mortbay/jetty/servlet/HashSessionManager$Session;");
                code.visitLabel(L41);
                code.visitFieldStmt(IGET_WIDE,5,11,new Field("Lorg/mortbay/jetty/servlet/HashSessionManager$Session;","_maxIdleMs","J"));
                code.visitLabel(L42);
                code.visitConstStmt(CONST_WIDE_16,16,Long.valueOf(0L)); // long: 0x0000000000000000  double:0.000000
                code.visitStmt3R(CMP_LONG,16,5,16);
                code.visitJumpStmt(IF_LEZ,16,-1,L16);
                code.visitStmt2R(MOVE_OBJECT,0,11);
                code.visitFieldStmt(IGET_WIDE,0,0,new Field("Lorg/mortbay/jetty/servlet/HashSessionManager$Session;","_accessed","J"));
                code.visitStmt2R(MOVE_WIDE_FROM16,16,0);
                code.visitStmt3R(ADD_LONG,16,16,5);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Ljava/lang/System;","currentTimeMillis",new String[]{ },"J"));
                code.visitStmt1R(MOVE_RESULT_WIDE,18);
                code.visitStmt3R(CMP_LONG,16,16,18);
                code.visitJumpStmt(IF_GEZ,16,-1,L16);
                code.visitLabel(L43);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 11},new Method("Lorg/mortbay/jetty/servlet/HashSessionManager$Session;","timeout",new String[]{ },"V"));
                code.visitLabel(L44);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,20);
                code.visitFieldStmt(IGET_OBJECT,0,0,new Field("Lorg/mortbay/jetty/servlet/HashSessionManager;","_sessions","Ljava/util/Map;"));
                code.visitStmt2R(MOVE_OBJECT_FROM16,16,0);
                code.visitMethodStmt(INVOKE_INTERFACE_RANGE,new int[]{ 16},new Method("Ljava/util/Map;","size",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,7);
                code.visitLabel(L45);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,20);
                code.visitFieldStmt(IGET,0,0,new Field("Lorg/mortbay/jetty/servlet/HashSessionManager;","_minSessions","I"));
                code.visitStmt2R(MOVE_FROM16,16,0);
                code.visitStmt2R(MOVE,0,7);
                code.visitStmt2R(MOVE_FROM16,1,16);
                code.visitJumpStmt(IF_GE,0,1,L16);
                code.visitLabel(L46);
                code.visitStmt2R(MOVE,0,7);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,20);
                code.visitFieldStmt(IPUT,0,1,new Field("Lorg/mortbay/jetty/servlet/HashSessionManager;","_minSessions","I"));
                code.visitLabel(L16);
                code.visitStmt2R(MOVE,4,3);
                code.visitLabel(L47);
                code.visitJumpStmt(GOTO,-1,-1,L38);
                code.visitLabel(L10);
                code.visitStmt1R(MOVE_EXCEPTION,15);
                code.visitLabel(L17);
                code.visitStmt1R(MONITOR_EXIT,20);
                code.visitLabel(L18);
                code.visitStmt1R(THROW,15);
                code.visitLabel(L19);
                code.visitConstStmt(CONST_STRING,15,"Problem scavenging sessions");
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 15,13},new Method("Lorg/mortbay/log/Log;","warn",new String[]{ "Ljava/lang/String;","Ljava/lang/Throwable;"},"V"));
                code.visitLabel(L20);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 14,10},new Method("Ljava/lang/Thread;","setContextClassLoader",new String[]{ "Ljava/lang/ClassLoader;"},"V"));
                code.visitJumpStmt(GOTO_16,-1,-1,L22);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m005_addSession(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Lorg/mortbay/jetty/servlet/HashSessionManager;","addSession",new String[]{ "Lorg/mortbay/jetty/servlet/AbstractSessionManager$Session;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"session");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(306,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(307,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/jetty/servlet/HashSessionManager;","_sessions","Ljava/util/Map;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Lorg/mortbay/jetty/servlet/AbstractSessionManager$Session;","getClusterId",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,1,3},new Method("Ljava/util/Map;","put",new String[]{ "Ljava/lang/Object;","Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m006_doStart(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/servlet/HashSessionManager;","doStart",new String[]{ },"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/lang/Exception;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(68,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(69,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(71,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(73,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(75,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(77,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(78,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(80,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(81,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(84,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(85,L10);
                code.visitLabel(L0);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/util/HashMap;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/util/HashMap;","<init>",new String[]{ },"V"));
                code.visitFieldStmt(IPUT_OBJECT,0,2,new Field("Lorg/mortbay/jetty/servlet/HashSessionManager;","_sessions","Ljava/util/Map;"));
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_SUPER,new int[]{ 2},new Method("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","doStart",new String[]{ },"V"));
                code.visitLabel(L2);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/util/Timer;");
                code.visitConstStmt(CONST_4,1, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1},new Method("Ljava/util/Timer;","<init>",new String[]{ "Z"},"V"));
                code.visitFieldStmt(IPUT_OBJECT,0,2,new Field("Lorg/mortbay/jetty/servlet/HashSessionManager;","_timer","Ljava/util/Timer;"));
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/jetty/servlet/HashSessionManager;","getScavengePeriod",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,0},new Method("Lorg/mortbay/jetty/servlet/HashSessionManager;","setScavengePeriod",new String[]{ "I"},"V"));
                code.visitLabel(L4);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/jetty/servlet/HashSessionManager;","_storeDir","Ljava/io/File;"));
                code.visitJumpStmt(IF_EQZ,0,-1,L9);
                code.visitLabel(L5);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/jetty/servlet/HashSessionManager;","_storeDir","Ljava/io/File;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/io/File;","exists",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_NEZ,0,-1,L7);
                code.visitLabel(L6);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/jetty/servlet/HashSessionManager;","_storeDir","Ljava/io/File;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/io/File;","mkdir",new String[]{ },"Z"));
                code.visitLabel(L7);
                code.visitFieldStmt(IGET_BOOLEAN,0,2,new Field("Lorg/mortbay/jetty/servlet/HashSessionManager;","_lazyLoad","Z"));
                code.visitJumpStmt(IF_NEZ,0,-1,L9);
                code.visitLabel(L8);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/jetty/servlet/HashSessionManager;","restoreSessions",new String[]{ },"V"));
                code.visitLabel(L9);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/jetty/servlet/HashSessionManager;","getSavePeriod",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,0},new Method("Lorg/mortbay/jetty/servlet/HashSessionManager;","setSavePeriod",new String[]{ "I"},"V"));
                code.visitLabel(L10);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m007_doStop(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/servlet/HashSessionManager;","doStop",new String[]{ },"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/lang/Exception;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L3=new DexLabel();
                ddv.visitPrologue(L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(94,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(95,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(97,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(99,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(100,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(103,L9);
                ddv.visitLineNumber(105,L0);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(106,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(107,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(108,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(109,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(110,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(111,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(112,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(113,L17);
                ddv.visitLineNumber(112,L2);
                code.visitLabel(L3);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L4);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/jetty/servlet/HashSessionManager;","_storeDir","Ljava/io/File;"));
                code.visitJumpStmt(IF_EQZ,0,-1,L6);
                code.visitLabel(L5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/jetty/servlet/HashSessionManager;","saveSessions",new String[]{ },"V"));
                code.visitLabel(L6);
                code.visitMethodStmt(INVOKE_SUPER,new int[]{ 2},new Method("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","doStop",new String[]{ },"V"));
                code.visitLabel(L7);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/jetty/servlet/HashSessionManager;","_sessions","Ljava/util/Map;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0},new Method("Ljava/util/Map;","clear",new String[]{ },"V"));
                code.visitLabel(L8);
                code.visitFieldStmt(IPUT_OBJECT,1,2,new Field("Lorg/mortbay/jetty/servlet/HashSessionManager;","_sessions","Ljava/util/Map;"));
                code.visitLabel(L9);
                code.visitStmt1R(MONITOR_ENTER,2);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/jetty/servlet/HashSessionManager;","_saveTask","Ljava/util/TimerTask;"));
                code.visitJumpStmt(IF_EQZ,0,-1,L11);
                code.visitLabel(L10);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/jetty/servlet/HashSessionManager;","_saveTask","Ljava/util/TimerTask;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/util/TimerTask;","cancel",new String[]{ },"Z"));
                code.visitLabel(L11);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/jetty/servlet/HashSessionManager;","_task","Ljava/util/TimerTask;"));
                code.visitJumpStmt(IF_EQZ,0,-1,L13);
                code.visitLabel(L12);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/jetty/servlet/HashSessionManager;","_task","Ljava/util/TimerTask;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/util/TimerTask;","cancel",new String[]{ },"Z"));
                code.visitLabel(L13);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/jetty/servlet/HashSessionManager;","_timer","Ljava/util/Timer;"));
                code.visitJumpStmt(IF_EQZ,0,-1,L15);
                code.visitLabel(L14);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/jetty/servlet/HashSessionManager;","_timer","Ljava/util/Timer;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/util/Timer;","cancel",new String[]{ },"V"));
                code.visitLabel(L15);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT_OBJECT,0,2,new Field("Lorg/mortbay/jetty/servlet/HashSessionManager;","_timer","Ljava/util/Timer;"));
                code.visitLabel(L16);
                code.visitStmt1R(MONITOR_EXIT,2);
                code.visitLabel(L17);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,0);
                code.visitStmt1R(MONITOR_EXIT,2);
                code.visitLabel(L1);
                code.visitStmt1R(THROW,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m008_getSavePeriod(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/servlet/HashSessionManager;","getSavePeriod",new String[]{ },"I"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(185,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(186,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(188,L2);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET,0,1,new Field("Lorg/mortbay/jetty/servlet/HashSessionManager;","_savePeriodMs","I"));
                DexLabel L3=new DexLabel();
                code.visitJumpStmt(IF_GTZ,0,-1,L3);
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L2);
                code.visitStmt1R(RETURN,0);
                code.visitLabel(L3);
                code.visitFieldStmt(IGET,0,1,new Field("Lorg/mortbay/jetty/servlet/HashSessionManager;","_savePeriodMs","I"));
                code.visitStmt2R1N(DIV_INT_LIT16,0,0,1000);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m009_getScavengePeriod(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/servlet/HashSessionManager;","getScavengePeriod",new String[]{ },"I"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(121,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET,0,1,new Field("Lorg/mortbay/jetty/servlet/HashSessionManager;","_scavengePeriodMs","I"));
                code.visitStmt2R1N(DIV_INT_LIT16,0,0,1000);
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m010_getSession(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/servlet/HashSessionManager;","getSession",new String[]{ "Ljava/lang/String;"},"Lorg/mortbay/jetty/servlet/AbstractSessionManager$Session;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ "Ljava/lang/Exception;"});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"idInCluster");
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(314,L0);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(315,L3);
                ddv.visitLineNumber(322,L1);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(323,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(325,L5);
                ddv.visitEndLocal(2,L5);
                ddv.visitLineNumber(317,L2);
                ddv.visitRestartLocal(2,L2);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(319,L6);
                ddv.visitStartLocal(0,L6,"e","Ljava/lang/Exception;",null);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(325,L7);
                ddv.visitEndLocal(0,L7);
                DexLabel L8=new DexLabel();
                ddv.visitEndLocal(2,L8);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_BOOLEAN,1,2,new Field("Lorg/mortbay/jetty/servlet/HashSessionManager;","_sessionsLoaded","Z"));
                code.visitJumpStmt(IF_NEZ,1,-1,L1);
                code.visitFieldStmt(IGET_BOOLEAN,1,2,new Field("Lorg/mortbay/jetty/servlet/HashSessionManager;","_lazyLoad","Z"));
                code.visitJumpStmt(IF_EQZ,1,-1,L1);
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/jetty/servlet/HashSessionManager;","restoreSessions",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/jetty/servlet/HashSessionManager;","_sessions","Ljava/util/Map;"));
                code.visitJumpStmt(IF_NEZ,1,-1,L7);
                code.visitLabel(L4);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L5);
                code.visitStmt1R(RETURN_OBJECT,1);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,1);
                code.visitStmt2R(MOVE_OBJECT,0,1);
                code.visitLabel(L6);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0},new Method("Lorg/mortbay/log/Log;","warn",new String[]{ "Ljava/lang/Throwable;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L1);
                code.visitLabel(L7);
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/jetty/servlet/HashSessionManager;","_sessions","Ljava/util/Map;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 1,3},new Method("Ljava/util/Map;","get",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitLabel(L8);
                code.visitTypeStmt(CHECK_CAST,2,-1,"Lorg/mortbay/jetty/servlet/HashSessionManager$Session;");
                code.visitStmt2R(MOVE_OBJECT,1,2);
                code.visitJumpStmt(GOTO,-1,-1,L5);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m011_getSessionMap(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/servlet/HashSessionManager;","getSessionMap",new String[]{ },"Ljava/util/Map;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(128,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/servlet/HashSessionManager;","_sessions","Ljava/util/Map;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0},new Method("Ljava/util/Collections;","unmodifiableMap",new String[]{ "Ljava/util/Map;"},"Ljava/util/Map;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m012_getSessions(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/servlet/HashSessionManager;","getSessions",new String[]{ },"I"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(135,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/servlet/HashSessionManager;","_sessions","Ljava/util/Map;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0},new Method("Ljava/util/Map;","size",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m013_getStoreDirectory(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/servlet/HashSessionManager;","getStoreDirectory",new String[]{ },"Ljava/io/File;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(362,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/servlet/HashSessionManager;","_storeDir","Ljava/io/File;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m014_invalidateSessions(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Lorg/mortbay/jetty/servlet/HashSessionManager;","invalidateSessions",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(332,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(333,L1);
                ddv.visitStartLocal(2,L1,"sessions","Ljava/util/ArrayList;",null);
                DexLabel L2=new DexLabel();
                ddv.visitStartLocal(0,L2,"i","Ljava/util/Iterator;",null);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(335,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(336,L4);
                ddv.visitStartLocal(1,L4,"session","Lorg/mortbay/jetty/servlet/HashSessionManager$Session;",null);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(338,L5);
                ddv.visitEndLocal(1,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(340,L6);
                code.visitLabel(L0);
                code.visitTypeStmt(NEW_INSTANCE,2,-1,"Ljava/util/ArrayList;");
                code.visitFieldStmt(IGET_OBJECT,3,4,new Field("Lorg/mortbay/jetty/servlet/HashSessionManager;","_sessions","Ljava/util/Map;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 3},new Method("Ljava/util/Map;","values",new String[]{ },"Ljava/util/Collection;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2,3},new Method("Ljava/util/ArrayList;","<init>",new String[]{ "Ljava/util/Collection;"},"V"));
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Ljava/util/ArrayList;","iterator",new String[]{ },"Ljava/util/Iterator;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitLabel(L2);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0},new Method("Ljava/util/Iterator;","hasNext",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitJumpStmt(IF_EQZ,3,-1,L5);
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0},new Method("Ljava/util/Iterator;","next",new String[]{ },"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitTypeStmt(CHECK_CAST,1,-1,"Lorg/mortbay/jetty/servlet/HashSessionManager$Session;");
                code.visitLabel(L4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Lorg/mortbay/jetty/servlet/HashSessionManager$Session;","invalidate",new String[]{ },"V"));
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitLabel(L5);
                code.visitFieldStmt(IGET_OBJECT,3,4,new Field("Lorg/mortbay/jetty/servlet/HashSessionManager;","_sessions","Ljava/util/Map;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 3},new Method("Ljava/util/Map;","clear",new String[]{ },"V"));
                code.visitLabel(L6);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m015_isLazyLoad(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/servlet/HashSessionManager;","isLazyLoad",new String[]{ },"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(372,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_BOOLEAN,0,1,new Field("Lorg/mortbay/jetty/servlet/HashSessionManager;","_lazyLoad","Z"));
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m016_newSession(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Lorg/mortbay/jetty/servlet/HashSessionManager;","newSession",new String[]{ "Ljavax/servlet/http/HttpServletRequest;"},"Lorg/mortbay/jetty/servlet/AbstractSessionManager$Session;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"request");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(345,L0);
                code.visitLabel(L0);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Lorg/mortbay/jetty/servlet/HashSessionManager$Session;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1,2},new Method("Lorg/mortbay/jetty/servlet/HashSessionManager$Session;","<init>",new String[]{ "Lorg/mortbay/jetty/servlet/HashSessionManager;","Ljavax/servlet/http/HttpServletRequest;"},"V"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m017_removeSession(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PROTECTED, new Method("Lorg/mortbay/jetty/servlet/HashSessionManager;","removeSession",new String[]{ "Ljava/lang/String;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"clusterId");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(351,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(352,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/servlet/HashSessionManager;","_sessions","Ljava/util/Map;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,2},new Method("Ljava/util/Map;","remove",new String[]{ "Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m018_restoreSession(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/servlet/HashSessionManager;","restoreSession",new String[]{ "Ljava/io/FileInputStream;"},"Lorg/mortbay/jetty/servlet/HashSessionManager$Session;"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/lang/Exception;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(27);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"fis");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(456,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(457,L1);
                ddv.visitStartLocal(14,L1,"in","Ljava/io/DataInputStream;",null);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(458,L2);
                ddv.visitStartLocal(7,L2,"clusterId","Ljava/lang/String;",null);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(459,L3);
                ddv.visitStartLocal(19,L3,"nodeId","Ljava/lang/String;",null);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(460,L4);
                ddv.visitStartLocal(13,L4,"idChanged","Z",null);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(461,L5);
                ddv.visitStartLocal(10,L5,"created","J",null);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(462,L6);
                ddv.visitStartLocal(8,L6,"cookieSet","J",null);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(463,L7);
                ddv.visitStartLocal(5,L7,"accessed","J",null);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(468,L8);
                ddv.visitStartLocal(17,L8,"lastAccessed","J",null);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(470,L9);
                ddv.visitStartLocal(21,L9,"requests","I",null);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(471,L10);
                ddv.visitStartLocal(22,L10,"session","Lorg/mortbay/jetty/servlet/HashSessionManager$Session;",null);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(472,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(474,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(475,L13);
                ddv.visitStartLocal(23,L13,"size","I",null);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(477,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(478,L15);
                ddv.visitStartLocal(16,L15,"keys","Ljava/util/ArrayList;",null);
                DexLabel L16=new DexLabel();
                ddv.visitStartLocal(12,L16,"i","I",null);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(480,L17);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(481,L18);
                ddv.visitStartLocal(15,L18,"key","Ljava/lang/String;",null);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(478,L19);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(483,L20);
                ddv.visitEndLocal(15,L20);
                DexLabel L21=new DexLabel();
                ddv.visitLineNumber(484,L21);
                ddv.visitStartLocal(20,L21,"ois","Lorg/mortbay/jetty/servlet/HashSessionManager$ClassLoadingObjectInputStream;",null);
                DexLabel L22=new DexLabel();
                ddv.visitEndLocal(25,L22);
                DexLabel L23=new DexLabel();
                ddv.visitLineNumber(486,L23);
                DexLabel L24=new DexLabel();
                ddv.visitLineNumber(487,L24);
                ddv.visitStartLocal(24,L24,"value","Ljava/lang/Object;",null);
                DexLabel L25=new DexLabel();
                ddv.visitLineNumber(484,L25);
                DexLabel L26=new DexLabel();
                ddv.visitLineNumber(489,L26);
                ddv.visitEndLocal(24,L26);
                DexLabel L27=new DexLabel();
                ddv.visitLineNumber(493,L27);
                ddv.visitEndLocal(16,L27);
                ddv.visitEndLocal(12,L27);
                ddv.visitEndLocal(20,L27);
                DexLabel L28=new DexLabel();
                ddv.visitLineNumber(494,L28);
                DexLabel L29=new DexLabel();
                ddv.visitLineNumber(492,L29);
                ddv.visitRestartLocal(25,L29);
                code.visitLabel(L0);
                code.visitTypeStmt(NEW_INSTANCE,14,-1,"Ljava/io/DataInputStream;");
                code.visitStmt2R(MOVE_OBJECT,0,14);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,26);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1},new Method("Ljava/io/DataInputStream;","<init>",new String[]{ "Ljava/io/InputStream;"},"V"));
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 14},new Method("Ljava/io/DataInputStream;","readUTF",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitLabel(L2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 14},new Method("Ljava/io/DataInputStream;","readUTF",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,19);
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 14},new Method("Ljava/io/DataInputStream;","readBoolean",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,13);
                code.visitLabel(L4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 14},new Method("Ljava/io/DataInputStream;","readLong",new String[]{ },"J"));
                code.visitStmt1R(MOVE_RESULT_WIDE,10);
                code.visitLabel(L5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 14},new Method("Ljava/io/DataInputStream;","readLong",new String[]{ },"J"));
                code.visitStmt1R(MOVE_RESULT_WIDE,8);
                code.visitLabel(L6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 14},new Method("Ljava/io/DataInputStream;","readLong",new String[]{ },"J"));
                code.visitStmt1R(MOVE_RESULT_WIDE,5);
                code.visitLabel(L7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 14},new Method("Ljava/io/DataInputStream;","readLong",new String[]{ },"J"));
                code.visitStmt1R(MOVE_RESULT_WIDE,17);
                code.visitLabel(L8);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 14},new Method("Ljava/io/DataInputStream;","readInt",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,21);
                code.visitLabel(L9);
                code.visitTypeStmt(NEW_INSTANCE,22,-1,"Lorg/mortbay/jetty/servlet/HashSessionManager$Session;");
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,22);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,25);
                code.visitStmt2R(MOVE_WIDE,2,10);
                code.visitStmt2R(MOVE_OBJECT,4,7);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1,2,3,4},new Method("Lorg/mortbay/jetty/servlet/HashSessionManager$Session;","<init>",new String[]{ "Lorg/mortbay/jetty/servlet/HashSessionManager;","J","Ljava/lang/String;"},"V"));
                code.visitLabel(L10);
                code.visitStmt2R(MOVE_WIDE,0,8);
                code.visitStmt2R(MOVE_OBJECT_FROM16,2,22);
                code.visitFieldStmt(IPUT_WIDE,0,2,new Field("Lorg/mortbay/jetty/servlet/HashSessionManager$Session;","_cookieSet","J"));
                code.visitLabel(L11);
                code.visitStmt2R(MOVE_WIDE_FROM16,0,17);
                code.visitStmt2R(MOVE_OBJECT_FROM16,2,22);
                code.visitFieldStmt(IPUT_WIDE,0,2,new Field("Lorg/mortbay/jetty/servlet/HashSessionManager$Session;","_lastAccessed","J"));
                code.visitLabel(L12);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 14},new Method("Ljava/io/DataInputStream;","readInt",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,23);
                code.visitLabel(L13);
                code.visitJumpStmt(IF_LEZ,23,-1,L29);
                code.visitLabel(L14);
                code.visitTypeStmt(NEW_INSTANCE,16,-1,"Ljava/util/ArrayList;");
                code.visitMethodStmt(INVOKE_DIRECT_RANGE,new int[]{ 16},new Method("Ljava/util/ArrayList;","<init>",new String[]{ },"V"));
                code.visitLabel(L15);
                code.visitConstStmt(CONST_4,12, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L16);
                code.visitStmt2R(MOVE,0,12);
                code.visitStmt2R(MOVE_FROM16,1,23);
                code.visitJumpStmt(IF_GE,0,1,L20);
                code.visitLabel(L17);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 14},new Method("Ljava/io/DataInputStream;","readUTF",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,15);
                code.visitLabel(L18);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,16);
                code.visitStmt2R(MOVE_OBJECT,1,15);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/util/ArrayList;","add",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitLabel(L19);
                code.visitStmt2R1N(ADD_INT_LIT8,12,12,1);
                code.visitJumpStmt(GOTO,-1,-1,L16);
                code.visitLabel(L20);
                code.visitTypeStmt(NEW_INSTANCE,20,-1,"Lorg/mortbay/jetty/servlet/HashSessionManager$ClassLoadingObjectInputStream;");
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,20);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,25);
                code.visitStmt2R(MOVE_OBJECT,2,14);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,1,2},new Method("Lorg/mortbay/jetty/servlet/HashSessionManager$ClassLoadingObjectInputStream;","<init>",new String[]{ "Lorg/mortbay/jetty/servlet/HashSessionManager;","Ljava/io/InputStream;"},"V"));
                code.visitLabel(L21);
                code.visitConstStmt(CONST_4,12, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L22);
                code.visitStmt2R(MOVE,0,12);
                code.visitStmt2R(MOVE_FROM16,1,23);
                code.visitJumpStmt(IF_GE,0,1,L26);
                code.visitLabel(L23);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 20},new Method("Lorg/mortbay/jetty/servlet/HashSessionManager$ClassLoadingObjectInputStream;","readObject",new String[]{ },"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,24);
                code.visitLabel(L24);
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,16);
                code.visitStmt2R(MOVE,1,12);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/util/ArrayList;","get",new String[]{ "I"},"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,25);
                code.visitTypeStmt(CHECK_CAST,25,-1,"Ljava/lang/String;");
                code.visitStmt2R(MOVE_OBJECT_FROM16,0,22);
                code.visitStmt2R(MOVE_OBJECT_FROM16,1,25);
                code.visitStmt2R(MOVE_OBJECT_FROM16,2,24);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1,2},new Method("Lorg/mortbay/jetty/servlet/HashSessionManager$Session;","setAttribute",new String[]{ "Ljava/lang/String;","Ljava/lang/Object;"},"V"));
                code.visitLabel(L25);
                code.visitStmt2R1N(ADD_INT_LIT8,12,12,1);
                code.visitJumpStmt(GOTO,-1,-1,L22);
                code.visitLabel(L26);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 20},new Method("Lorg/mortbay/jetty/servlet/HashSessionManager$ClassLoadingObjectInputStream;","close",new String[]{ },"V"));
                code.visitLabel(L27);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 14},new Method("Ljava/io/DataInputStream;","close",new String[]{ },"V"));
                code.visitLabel(L28);
                code.visitStmt1R(RETURN_OBJECT,22);
                code.visitLabel(L29);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 22},new Method("Lorg/mortbay/jetty/servlet/HashSessionManager$Session;","initValues",new String[]{ },"V"));
                code.visitJumpStmt(GOTO,-1,-1,L27);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m019_restoreSessions(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/servlet/HashSessionManager;","restoreSessions",new String[]{ },"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/lang/Exception;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(8);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ "Ljava/lang/Exception;"});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L3=new DexLabel();
                ddv.visitPrologue(L3);
                ddv.visitLineNumber(377,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(406,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(382,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(384,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(388,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(389,L8);
                ddv.visitStartLocal(1,L8,"files","[Ljava/io/File;",null);
                DexLabel L9=new DexLabel();
                ddv.visitStartLocal(2,L9,"i","I",null);
                ddv.visitLineNumber(393,L0);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(394,L10);
                ddv.visitStartLocal(3,L10,"in","Ljava/io/FileInputStream;",null);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(395,L11);
                ddv.visitStartLocal(4,L11,"session","Lorg/mortbay/jetty/servlet/HashSessionManager$Session;",null);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(396,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(397,L13);
                ddv.visitLineNumber(389,L1);
                ddv.visitEndLocal(3,L1);
                ddv.visitEndLocal(4,L1);
                ddv.visitLineNumber(399,L2);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(401,L14);
                ddv.visitStartLocal(0,L14,"e","Ljava/lang/Exception;",null);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(405,L15);
                ddv.visitEndLocal(0,L15);
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,5,7,new Field("Lorg/mortbay/jetty/servlet/HashSessionManager;","_storeDir","Ljava/io/File;"));
                code.visitJumpStmt(IF_EQZ,5,-1,L4);
                code.visitFieldStmt(IGET_OBJECT,5,7,new Field("Lorg/mortbay/jetty/servlet/HashSessionManager;","_storeDir","Ljava/io/File;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Ljava/io/File;","exists",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,5);
                code.visitJumpStmt(IF_NEZ,5,-1,L5);
                code.visitLabel(L4);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L5);
                code.visitFieldStmt(IGET_OBJECT,5,7,new Field("Lorg/mortbay/jetty/servlet/HashSessionManager;","_storeDir","Ljava/io/File;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Ljava/io/File;","canRead",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,5);
                code.visitJumpStmt(IF_NEZ,5,-1,L7);
                code.visitLabel(L6);
                code.visitTypeStmt(NEW_INSTANCE,5,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 5},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,6,"Unable to restore Sessions: Cannot read from Session storage directory ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,6},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitFieldStmt(IGET_OBJECT,6,7,new Field("Lorg/mortbay/jetty/servlet/HashSessionManager;","_storeDir","Ljava/io/File;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Ljava/io/File;","getAbsolutePath",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,6},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 5},new Method("Lorg/mortbay/log/Log;","warn",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L4);
                code.visitLabel(L7);
                code.visitFieldStmt(IGET_OBJECT,5,7,new Field("Lorg/mortbay/jetty/servlet/HashSessionManager;","_storeDir","Ljava/io/File;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Ljava/io/File;","listFiles",new String[]{ },"[Ljava/io/File;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L8);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L9);
                code.visitJumpStmt(IF_EQZ,1,-1,L15);
                code.visitStmt2R(ARRAY_LENGTH,5,1);
                code.visitJumpStmt(IF_GE,2,5,L15);
                code.visitLabel(L0);
                code.visitTypeStmt(NEW_INSTANCE,3,-1,"Ljava/io/FileInputStream;");
                code.visitStmt3R(AGET_OBJECT,5,1,2);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 3,5},new Method("Ljava/io/FileInputStream;","<init>",new String[]{ "Ljava/io/File;"},"V"));
                code.visitLabel(L10);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7,3},new Method("Lorg/mortbay/jetty/servlet/HashSessionManager;","restoreSession",new String[]{ "Ljava/io/FileInputStream;"},"Lorg/mortbay/jetty/servlet/HashSessionManager$Session;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitLabel(L11);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Ljava/io/FileInputStream;","close",new String[]{ },"V"));
                code.visitLabel(L12);
                code.visitConstStmt(CONST_4,5, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7,4,5},new Method("Lorg/mortbay/jetty/servlet/HashSessionManager;","addSession",new String[]{ "Lorg/mortbay/jetty/servlet/AbstractSessionManager$Session;","Z"},"V"));
                code.visitLabel(L13);
                code.visitStmt3R(AGET_OBJECT,5,1,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Ljava/io/File;","delete",new String[]{ },"Z"));
                code.visitLabel(L1);
                code.visitStmt2R1N(ADD_INT_LIT8,2,2,1);
                code.visitJumpStmt(GOTO,-1,-1,L9);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,5);
                code.visitStmt2R(MOVE_OBJECT,0,5);
                code.visitLabel(L14);
                code.visitTypeStmt(NEW_INSTANCE,5,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 5},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,6,"Problem restoring session ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,6},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitStmt3R(AGET_OBJECT,6,1,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Ljava/io/File;","getName",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,6},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 5,0},new Method("Lorg/mortbay/log/Log;","warn",new String[]{ "Ljava/lang/String;","Ljava/lang/Throwable;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L1);
                code.visitLabel(L15);
                code.visitConstStmt(CONST_4,5, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitFieldStmt(IPUT_BOOLEAN,5,7,new Field("Lorg/mortbay/jetty/servlet/HashSessionManager;","_sessionsLoaded","Z"));
                code.visitJumpStmt(GOTO,-1,-1,L4);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m020_saveSessions(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/servlet/HashSessionManager;","saveSessions",new String[]{ },"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/lang/Exception;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(10);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexLabel L3=new DexLabel();
                DexLabel L4=new DexLabel();
                code.visitTryCatch(L1,L3,new DexLabel[]{L4,L2},new String[]{ "Ljava/lang/Exception;",null});
                DexLabel L5=new DexLabel();
                DexLabel L6=new DexLabel();
                code.visitTryCatch(L5,L6,new DexLabel[]{L2},new String[]{ null});
                DexLabel L7=new DexLabel();
                DexLabel L8=new DexLabel();
                code.visitTryCatch(L7,L8,new DexLabel[]{L2},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L9=new DexLabel();
                ddv.visitPrologue(L9);
                ddv.visitLineNumber(410,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(445,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(415,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(417,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(421,L13);
                ddv.visitLineNumber(423,L0);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(424,L14);
                ddv.visitStartLocal(5,L14,"itor","Ljava/util/Iterator;",null);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(426,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(427,L16);
                ddv.visitStartLocal(1,L16,"entry","Ljava/util/Map$Entry;",null);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(428,L17);
                ddv.visitStartLocal(4,L17,"id","Ljava/lang/String;",null);
                ddv.visitLineNumber(431,L1);
                ddv.visitStartLocal(6,L1,"session","Lorg/mortbay/jetty/servlet/HashSessionManager$Session;",null);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(432,L18);
                ddv.visitStartLocal(2,L18,"file","Ljava/io/File;",null);
                DexLabel L19=new DexLabel();
                ddv.visitLineNumber(433,L19);
                DexLabel L20=new DexLabel();
                ddv.visitLineNumber(434,L20);
                DexLabel L21=new DexLabel();
                ddv.visitLineNumber(435,L21);
                DexLabel L22=new DexLabel();
                ddv.visitLineNumber(436,L22);
                ddv.visitStartLocal(3,L22,"fos","Ljava/io/FileOutputStream;",null);
                DexLabel L23=new DexLabel();
                ddv.visitLineNumber(437,L23);
                ddv.visitLineNumber(439,L4);
                ddv.visitEndLocal(2,L4);
                ddv.visitEndLocal(3,L4);
                ddv.visitLineNumber(441,L5);
                ddv.visitStartLocal(0,L5,"e","Ljava/lang/Exception;",null);
                ddv.visitLineNumber(444,L2);
                ddv.visitEndLocal(5,L2);
                ddv.visitEndLocal(1,L2);
                ddv.visitEndLocal(4,L2);
                ddv.visitEndLocal(6,L2);
                ddv.visitEndLocal(0,L2);
                ddv.visitRestartLocal(5,L7);
                code.visitLabel(L9);
                code.visitFieldStmt(IGET_OBJECT,7,9,new Field("Lorg/mortbay/jetty/servlet/HashSessionManager;","_storeDir","Ljava/io/File;"));
                code.visitJumpStmt(IF_EQZ,7,-1,L10);
                code.visitFieldStmt(IGET_OBJECT,7,9,new Field("Lorg/mortbay/jetty/servlet/HashSessionManager;","_storeDir","Ljava/io/File;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7},new Method("Ljava/io/File;","exists",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,7);
                code.visitJumpStmt(IF_NEZ,7,-1,L11);
                code.visitLabel(L10);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L11);
                code.visitFieldStmt(IGET_OBJECT,7,9,new Field("Lorg/mortbay/jetty/servlet/HashSessionManager;","_storeDir","Ljava/io/File;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7},new Method("Ljava/io/File;","canWrite",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,7);
                code.visitJumpStmt(IF_NEZ,7,-1,L13);
                code.visitLabel(L12);
                code.visitTypeStmt(NEW_INSTANCE,7,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 7},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,8,"Unable to save Sessions: Session persistence storage directory ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7,8},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitFieldStmt(IGET_OBJECT,8,9,new Field("Lorg/mortbay/jetty/servlet/HashSessionManager;","_storeDir","Ljava/io/File;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 8},new Method("Ljava/io/File;","getAbsolutePath",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,8);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7,8},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitConstStmt(CONST_STRING,8," is not writeable");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7,8},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 7},new Method("Lorg/mortbay/log/Log;","warn",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L10);
                code.visitLabel(L13);
                code.visitStmt1R(MONITOR_ENTER,9);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,7,9,new Field("Lorg/mortbay/jetty/servlet/HashSessionManager;","_sessions","Ljava/util/Map;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 7},new Method("Ljava/util/Map;","entrySet",new String[]{ },"Ljava/util/Set;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 7},new Method("Ljava/util/Set;","iterator",new String[]{ },"Ljava/util/Iterator;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,5);
                code.visitLabel(L14);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 5},new Method("Ljava/util/Iterator;","hasNext",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,7);
                code.visitJumpStmt(IF_EQZ,7,-1,L7);
                code.visitLabel(L15);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 5},new Method("Ljava/util/Iterator;","next",new String[]{ },"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitTypeStmt(CHECK_CAST,1,-1,"Ljava/util/Map$Entry;");
                code.visitLabel(L16);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 1},new Method("Ljava/util/Map$Entry;","getKey",new String[]{ },"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,4);
                code.visitTypeStmt(CHECK_CAST,4,-1,"Ljava/lang/String;");
                code.visitLabel(L17);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 1},new Method("Ljava/util/Map$Entry;","getValue",new String[]{ },"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,6);
                code.visitTypeStmt(CHECK_CAST,6,-1,"Lorg/mortbay/jetty/servlet/HashSessionManager$Session;");
                code.visitLabel(L1);
                code.visitTypeStmt(NEW_INSTANCE,2,-1,"Ljava/io/File;");
                code.visitFieldStmt(IGET_OBJECT,7,9,new Field("Lorg/mortbay/jetty/servlet/HashSessionManager;","_storeDir","Ljava/io/File;"));
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 2,7,4},new Method("Ljava/io/File;","<init>",new String[]{ "Ljava/io/File;","Ljava/lang/String;"},"V"));
                code.visitLabel(L18);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Ljava/io/File;","exists",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,7);
                code.visitJumpStmt(IF_EQZ,7,-1,L20);
                code.visitLabel(L19);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Ljava/io/File;","delete",new String[]{ },"Z"));
                code.visitLabel(L20);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Ljava/io/File;","createNewFile",new String[]{ },"Z"));
                code.visitLabel(L21);
                code.visitTypeStmt(NEW_INSTANCE,3,-1,"Ljava/io/FileOutputStream;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 3,2},new Method("Ljava/io/FileOutputStream;","<init>",new String[]{ "Ljava/io/File;"},"V"));
                code.visitLabel(L22);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6,3},new Method("Lorg/mortbay/jetty/servlet/HashSessionManager$Session;","save",new String[]{ "Ljava/io/FileOutputStream;"},"V"));
                code.visitLabel(L23);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Ljava/io/FileOutputStream;","close",new String[]{ },"V"));
                code.visitLabel(L3);
                code.visitJumpStmt(GOTO,-1,-1,L14);
                code.visitLabel(L4);
                code.visitStmt1R(MOVE_EXCEPTION,7);
                code.visitStmt2R(MOVE_OBJECT,0,7);
                code.visitLabel(L5);
                code.visitTypeStmt(NEW_INSTANCE,7,-1,"Ljava/lang/StringBuilder;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 7},new Method("Ljava/lang/StringBuilder;","<init>",new String[]{ },"V"));
                code.visitConstStmt(CONST_STRING,8,"Problem persisting session ");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7,8},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7,4},new Method("Ljava/lang/StringBuilder;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuilder;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 7},new Method("Ljava/lang/StringBuilder;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,7);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 7,0},new Method("Lorg/mortbay/log/Log;","warn",new String[]{ "Ljava/lang/String;","Ljava/lang/Throwable;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L14);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,7);
                code.visitStmt1R(MONITOR_EXIT,9);
                code.visitLabel(L6);
                code.visitStmt1R(THROW,7);
                code.visitLabel(L7);
                code.visitStmt1R(MONITOR_EXIT,9);
                code.visitLabel(L8);
                code.visitJumpStmt(GOTO_16,-1,-1,L10);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m021_setLazyLoad(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/servlet/HashSessionManager;","setLazyLoad",new String[]{ "Z"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"lazyLoad");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(367,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(368,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_BOOLEAN,1,0,new Field("Lorg/mortbay/jetty/servlet/HashSessionManager;","_lazyLoad","Z"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m022_setMaxInactiveInterval(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/servlet/HashSessionManager;","setMaxInactiveInterval",new String[]{ "I"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"seconds");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(142,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(143,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(144,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(145,L3);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_SUPER,new int[]{ 2,3},new Method("Lorg/mortbay/jetty/servlet/AbstractSessionManager;","setMaxInactiveInterval",new String[]{ "I"},"V"));
                code.visitLabel(L1);
                code.visitFieldStmt(IGET,0,2,new Field("Lorg/mortbay/jetty/servlet/HashSessionManager;","_dftMaxIdleSecs","I"));
                code.visitJumpStmt(IF_LEZ,0,-1,L3);
                code.visitFieldStmt(IGET,0,2,new Field("Lorg/mortbay/jetty/servlet/HashSessionManager;","_scavengePeriodMs","I"));
                code.visitFieldStmt(IGET,1,2,new Field("Lorg/mortbay/jetty/servlet/HashSessionManager;","_dftMaxIdleSecs","I"));
                code.visitStmt2R1N(MUL_INT_LIT16,1,1,1000);
                code.visitJumpStmt(IF_LE,0,1,L3);
                code.visitLabel(L2);
                code.visitFieldStmt(IGET,0,2,new Field("Lorg/mortbay/jetty/servlet/HashSessionManager;","_dftMaxIdleSecs","I"));
                code.visitStmt2R1N(ADD_INT_LIT8,0,0,9);
                code.visitStmt2R1N(DIV_INT_LIT8,0,0,10);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,0},new Method("Lorg/mortbay/jetty/servlet/HashSessionManager;","setScavengePeriod",new String[]{ "I"},"V"));
                code.visitLabel(L3);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m023_setSavePeriod(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/servlet/HashSessionManager;","setSavePeriod",new String[]{ "I"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(10);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"seconds");
                DexLabel L3=new DexLabel();
                ddv.visitPrologue(L3);
                ddv.visitLineNumber(149,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(150,L4);
                ddv.visitStartLocal(6,L4,"oldSavePeriod","I",null);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(151,L5);
                ddv.visitStartLocal(7,L5,"period","I",null);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(152,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(153,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(155,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(157,L9);
                ddv.visitLineNumber(159,L0);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(160,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(161,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(163,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(177,L13);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(179,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(181,L15);
                ddv.visitLineNumber(179,L2);
                code.visitLabel(L3);
                code.visitFieldStmt(IGET,6,8,new Field("Lorg/mortbay/jetty/servlet/HashSessionManager;","_savePeriodMs","I"));
                code.visitLabel(L4);
                code.visitStmt2R1N(MUL_INT_LIT16,7,9,1000);
                code.visitLabel(L5);
                code.visitJumpStmt(IF_GEZ,7,-1,L7);
                code.visitLabel(L6);
                code.visitConstStmt(CONST_4,7, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L7);
                code.visitFieldStmt(IPUT,7,8,new Field("Lorg/mortbay/jetty/servlet/HashSessionManager;","_savePeriodMs","I"));
                code.visitLabel(L8);
                code.visitFieldStmt(IGET_OBJECT,0,8,new Field("Lorg/mortbay/jetty/servlet/HashSessionManager;","_timer","Ljava/util/Timer;"));
                code.visitJumpStmt(IF_EQZ,0,-1,L15);
                code.visitLabel(L9);
                code.visitStmt1R(MONITOR_ENTER,8);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,8,new Field("Lorg/mortbay/jetty/servlet/HashSessionManager;","_saveTask","Ljava/util/TimerTask;"));
                code.visitJumpStmt(IF_EQZ,0,-1,L11);
                code.visitLabel(L10);
                code.visitFieldStmt(IGET_OBJECT,0,8,new Field("Lorg/mortbay/jetty/servlet/HashSessionManager;","_saveTask","Ljava/util/TimerTask;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/util/TimerTask;","cancel",new String[]{ },"Z"));
                code.visitLabel(L11);
                code.visitFieldStmt(IGET,0,8,new Field("Lorg/mortbay/jetty/servlet/HashSessionManager;","_savePeriodMs","I"));
                code.visitJumpStmt(IF_LEZ,0,-1,L14);
                code.visitFieldStmt(IGET_OBJECT,0,8,new Field("Lorg/mortbay/jetty/servlet/HashSessionManager;","_storeDir","Ljava/io/File;"));
                code.visitJumpStmt(IF_EQZ,0,-1,L14);
                code.visitLabel(L12);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Lorg/mortbay/jetty/servlet/HashSessionManager$1;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,8},new Method("Lorg/mortbay/jetty/servlet/HashSessionManager$1;","<init>",new String[]{ "Lorg/mortbay/jetty/servlet/HashSessionManager;"},"V"));
                code.visitFieldStmt(IPUT_OBJECT,0,8,new Field("Lorg/mortbay/jetty/servlet/HashSessionManager;","_saveTask","Ljava/util/TimerTask;"));
                code.visitLabel(L13);
                code.visitFieldStmt(IGET_OBJECT,0,8,new Field("Lorg/mortbay/jetty/servlet/HashSessionManager;","_timer","Ljava/util/Timer;"));
                code.visitFieldStmt(IGET_OBJECT,1,8,new Field("Lorg/mortbay/jetty/servlet/HashSessionManager;","_saveTask","Ljava/util/TimerTask;"));
                code.visitFieldStmt(IGET,2,8,new Field("Lorg/mortbay/jetty/servlet/HashSessionManager;","_savePeriodMs","I"));
                code.visitStmt2R(INT_TO_LONG,2,2);
                code.visitFieldStmt(IGET,4,8,new Field("Lorg/mortbay/jetty/servlet/HashSessionManager;","_savePeriodMs","I"));
                code.visitStmt2R(INT_TO_LONG,4,4);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 0,1,2,3,4,5},new Method("Ljava/util/Timer;","schedule",new String[]{ "Ljava/util/TimerTask;","J","J"},"V"));
                code.visitLabel(L14);
                code.visitStmt1R(MONITOR_EXIT,8);
                code.visitLabel(L15);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,0);
                code.visitStmt1R(MONITOR_EXIT,8);
                code.visitLabel(L1);
                code.visitStmt1R(THROW,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m024_setScavengePeriod(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/servlet/HashSessionManager;","setScavengePeriod",new String[]{ "I"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(10);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"seconds");
                DexLabel L3=new DexLabel();
                ddv.visitPrologue(L3);
                ddv.visitLineNumber(196,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(197,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(199,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(200,L6);
                ddv.visitStartLocal(6,L6,"old_period","I",null);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(201,L7);
                ddv.visitStartLocal(7,L7,"period","I",null);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(202,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(203,L9);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(204,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(206,L11);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(207,L12);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(209,L13);
                ddv.visitLineNumber(211,L0);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(212,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(213,L15);
                DexLabel L16=new DexLabel();
                ddv.visitLineNumber(220,L16);
                DexLabel L17=new DexLabel();
                ddv.visitLineNumber(221,L17);
                DexLabel L18=new DexLabel();
                ddv.visitLineNumber(223,L18);
                ddv.visitLineNumber(221,L2);
                code.visitLabel(L3);
                code.visitJumpStmt(IF_NEZ,9,-1,L5);
                code.visitLabel(L4);
                code.visitConstStmt(CONST_16,9, Integer.valueOf(60)); // int: 0x0000003c  float:0.000000
                code.visitLabel(L5);
                code.visitFieldStmt(IGET,6,8,new Field("Lorg/mortbay/jetty/servlet/HashSessionManager;","_scavengePeriodMs","I"));
                code.visitLabel(L6);
                code.visitStmt2R1N(MUL_INT_LIT16,7,9,1000);
                code.visitLabel(L7);
                code.visitConstStmt(CONST,0, Integer.valueOf(60000)); // int: 0x0000ea60  float:0.000000
                code.visitJumpStmt(IF_LE,7,0,L9);
                code.visitLabel(L8);
                code.visitConstStmt(CONST,7, Integer.valueOf(60000)); // int: 0x0000ea60  float:0.000000
                code.visitLabel(L9);
                code.visitConstStmt(CONST_16,0, Integer.valueOf(1000)); // int: 0x000003e8  float:0.000000
                code.visitJumpStmt(IF_GE,7,0,L11);
                code.visitLabel(L10);
                code.visitConstStmt(CONST_16,7, Integer.valueOf(1000)); // int: 0x000003e8  float:0.000000
                code.visitLabel(L11);
                code.visitFieldStmt(IPUT,7,8,new Field("Lorg/mortbay/jetty/servlet/HashSessionManager;","_scavengePeriodMs","I"));
                code.visitLabel(L12);
                code.visitFieldStmt(IGET_OBJECT,0,8,new Field("Lorg/mortbay/jetty/servlet/HashSessionManager;","_timer","Ljava/util/Timer;"));
                code.visitJumpStmt(IF_EQZ,0,-1,L18);
                code.visitJumpStmt(IF_NE,7,6,L13);
                code.visitFieldStmt(IGET_OBJECT,0,8,new Field("Lorg/mortbay/jetty/servlet/HashSessionManager;","_task","Ljava/util/TimerTask;"));
                code.visitJumpStmt(IF_NEZ,0,-1,L18);
                code.visitLabel(L13);
                code.visitStmt1R(MONITOR_ENTER,8);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,8,new Field("Lorg/mortbay/jetty/servlet/HashSessionManager;","_task","Ljava/util/TimerTask;"));
                code.visitJumpStmt(IF_EQZ,0,-1,L15);
                code.visitLabel(L14);
                code.visitFieldStmt(IGET_OBJECT,0,8,new Field("Lorg/mortbay/jetty/servlet/HashSessionManager;","_task","Ljava/util/TimerTask;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/util/TimerTask;","cancel",new String[]{ },"Z"));
                code.visitLabel(L15);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Lorg/mortbay/jetty/servlet/HashSessionManager$2;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0,8},new Method("Lorg/mortbay/jetty/servlet/HashSessionManager$2;","<init>",new String[]{ "Lorg/mortbay/jetty/servlet/HashSessionManager;"},"V"));
                code.visitFieldStmt(IPUT_OBJECT,0,8,new Field("Lorg/mortbay/jetty/servlet/HashSessionManager;","_task","Ljava/util/TimerTask;"));
                code.visitLabel(L16);
                code.visitFieldStmt(IGET_OBJECT,0,8,new Field("Lorg/mortbay/jetty/servlet/HashSessionManager;","_timer","Ljava/util/Timer;"));
                code.visitFieldStmt(IGET_OBJECT,1,8,new Field("Lorg/mortbay/jetty/servlet/HashSessionManager;","_task","Ljava/util/TimerTask;"));
                code.visitFieldStmt(IGET,2,8,new Field("Lorg/mortbay/jetty/servlet/HashSessionManager;","_scavengePeriodMs","I"));
                code.visitStmt2R(INT_TO_LONG,2,2);
                code.visitFieldStmt(IGET,4,8,new Field("Lorg/mortbay/jetty/servlet/HashSessionManager;","_scavengePeriodMs","I"));
                code.visitStmt2R(INT_TO_LONG,4,4);
                code.visitMethodStmt(INVOKE_VIRTUAL_RANGE,new int[]{ 0,1,2,3,4,5},new Method("Ljava/util/Timer;","schedule",new String[]{ "Ljava/util/TimerTask;","J","J"},"V"));
                code.visitLabel(L17);
                code.visitStmt1R(MONITOR_EXIT,8);
                code.visitLabel(L18);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,0);
                code.visitStmt1R(MONITOR_EXIT,8);
                code.visitLabel(L1);
                code.visitStmt1R(THROW,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m025_setStoreDirectory(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/servlet/HashSessionManager;","setStoreDirectory",new String[]{ "Ljava/io/File;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"dir");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(357,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(358,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_OBJECT,1,0,new Field("Lorg/mortbay/jetty/servlet/HashSessionManager;","_storeDir","Ljava/io/File;"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
