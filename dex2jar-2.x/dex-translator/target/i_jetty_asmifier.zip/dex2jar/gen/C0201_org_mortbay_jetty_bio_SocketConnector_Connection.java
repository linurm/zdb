package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0201_org_mortbay_jetty_bio_SocketConnector_Connection {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(ACC_PUBLIC,"Lorg/mortbay/jetty/bio/SocketConnector$Connection;","Lorg/mortbay/io/bio/SocketEndPoint;",new String[]{ "Ljava/lang/Runnable;"});
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("SocketConnector.java");
        if(cv!=null){
            DexAnnotationVisitor av00 = cv.visitAnnotation("Ldalvik/annotation/EnclosingClass;", Visibility.SYSTEM);
            if(av00 != null) {
                av00.visit("value", new DexType("Lorg/mortbay/jetty/bio/SocketConnector;"));
                av00.visitEnd();
            }
        }
        if(cv!=null){
            DexAnnotationVisitor av00 = cv.visitAnnotation("Ldalvik/annotation/InnerClass;", Visibility.SYSTEM);
            if(av00 != null) {
                av00.visit("accessFlags",  Integer.valueOf(4));
                av00.visit("name", "Connection");
                av00.visitEnd();
            }
        }
        f000__connection(cv);
        f001__dispatched(cv);
        f002__socket(cv);
        f003__sotimeout(cv);
        f004_this$0(cv);
        m000__init_(cv);
        m001_dispatch(cv);
        m002_fill(cv);
        m003_run(cv);
    }
    public static void f000__connection(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(0, new Field("Lorg/mortbay/jetty/bio/SocketConnector$Connection;","_connection","Lorg/mortbay/jetty/HttpConnection;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f001__dispatched(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(0, new Field("Lorg/mortbay/jetty/bio/SocketConnector$Connection;","_dispatched","Z"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f002__socket(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PROTECTED, new Field("Lorg/mortbay/jetty/bio/SocketConnector$Connection;","_socket","Ljava/net/Socket;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f003__sotimeout(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(0, new Field("Lorg/mortbay/jetty/bio/SocketConnector$Connection;","_sotimeout","I"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f004_this$0(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_FINAL|ACC_SYNTHETIC, new Field("Lorg/mortbay/jetty/bio/SocketConnector$Connection;","this$0","Lorg/mortbay/jetty/bio/SocketConnector;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void m000__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/jetty/bio/SocketConnector$Connection;","<init>",new String[]{ "Lorg/mortbay/jetty/bio/SocketConnector;","Ljava/net/Socket;"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(1,"socket");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(180,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(181,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(174,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(182,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(183,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(184,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(185,L6);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_OBJECT,2,1,new Field("Lorg/mortbay/jetty/bio/SocketConnector$Connection;","this$0","Lorg/mortbay/jetty/bio/SocketConnector;"));
                code.visitLabel(L1);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1,3},new Method("Lorg/mortbay/io/bio/SocketEndPoint;","<init>",new String[]{ "Ljava/net/Socket;"},"V"));
                code.visitLabel(L2);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT_BOOLEAN,0,1,new Field("Lorg/mortbay/jetty/bio/SocketConnector$Connection;","_dispatched","Z"));
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,1},new Method("Lorg/mortbay/jetty/bio/SocketConnector;","newHttpConnection",new String[]{ "Lorg/mortbay/io/EndPoint;"},"Lorg/mortbay/jetty/HttpConnection;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/jetty/bio/SocketConnector$Connection;","_connection","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitLabel(L4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Ljava/net/Socket;","getSoTimeout",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitFieldStmt(IPUT,0,1,new Field("Lorg/mortbay/jetty/bio/SocketConnector$Connection;","_sotimeout","I"));
                code.visitLabel(L5);
                code.visitFieldStmt(IPUT_OBJECT,3,1,new Field("Lorg/mortbay/jetty/bio/SocketConnector$Connection;","_socket","Ljava/net/Socket;"));
                code.visitLabel(L6);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001_dispatch(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/bio/SocketConnector$Connection;","dispatch",new String[]{ },"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/lang/InterruptedException;"));
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(189,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(191,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(192,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(194,L3);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/jetty/bio/SocketConnector$Connection;","this$0","Lorg/mortbay/jetty/bio/SocketConnector;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/jetty/bio/SocketConnector;","getThreadPool",new String[]{ },"Lorg/mortbay/thread/ThreadPool;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitJumpStmt(IF_EQZ,0,-1,L1);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/jetty/bio/SocketConnector$Connection;","this$0","Lorg/mortbay/jetty/bio/SocketConnector;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/jetty/bio/SocketConnector;","getThreadPool",new String[]{ },"Lorg/mortbay/thread/ThreadPool;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,2},new Method("Lorg/mortbay/thread/ThreadPool;","dispatch",new String[]{ "Ljava/lang/Runnable;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(IF_NEZ,0,-1,L3);
                code.visitLabel(L1);
                code.visitConstStmt(CONST_STRING,0,"dispatch failed for {}");
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/jetty/bio/SocketConnector$Connection;","_connection","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0,1},new Method("Lorg/mortbay/log/Log;","warn",new String[]{ "Ljava/lang/String;","Ljava/lang/Object;"},"V"));
                code.visitLabel(L2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/jetty/bio/SocketConnector$Connection;","close",new String[]{ },"V"));
                code.visitLabel(L3);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m002_fill(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/bio/SocketConnector$Connection;","fill",new String[]{ "Lorg/mortbay/io/Buffer;"},"I"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/IOException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"buffer");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(198,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(199,L1);
                ddv.visitStartLocal(0,L1,"l","I",null);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(200,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(201,L3);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_SUPER,new int[]{ 1,2},new Method("Lorg/mortbay/io/bio/SocketEndPoint;","fill",new String[]{ "Lorg/mortbay/io/Buffer;"},"I"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitLabel(L1);
                code.visitJumpStmt(IF_GEZ,0,-1,L3);
                code.visitLabel(L2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Lorg/mortbay/jetty/bio/SocketConnector$Connection;","close",new String[]{ },"V"));
                code.visitLabel(L3);
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m003_run(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/bio/SocketConnector$Connection;","run",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(7);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                DexLabel L3=new DexLabel();
                DexLabel L4=new DexLabel();
                DexLabel L5=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2,L3,L4,L5},new String[]{ "Lorg/mortbay/jetty/EofException;","Lorg/mortbay/jetty/HttpException;","Ljava/lang/Throwable;",null});
                DexLabel L6=new DexLabel();
                DexLabel L7=new DexLabel();
                code.visitTryCatch(L1,L6,new DexLabel[]{L7},new String[]{ null});
                DexLabel L8=new DexLabel();
                code.visitTryCatch(L6,L8,new DexLabel[]{L2,L3,L4,L5},new String[]{ "Lorg/mortbay/jetty/EofException;","Lorg/mortbay/jetty/HttpException;","Ljava/lang/Throwable;",null});
                DexLabel L9=new DexLabel();
                DexLabel L10=new DexLabel();
                code.visitTryCatch(L9,L10,new DexLabel[]{L5},new String[]{ null});
                DexLabel L11=new DexLabel();
                DexLabel L12=new DexLabel();
                code.visitTryCatch(L10,L11,new DexLabel[]{L12,L5},new String[]{ "Ljava/io/IOException;",null});
                DexLabel L13=new DexLabel();
                DexLabel L14=new DexLabel();
                DexLabel L15=new DexLabel();
                code.visitTryCatch(L13,L14,new DexLabel[]{L15},new String[]{ null});
                DexLabel L16=new DexLabel();
                DexLabel L17=new DexLabel();
                code.visitTryCatch(L16,L17,new DexLabel[]{L7},new String[]{ null});
                code.visitTryCatch(L17,L3,new DexLabel[]{L2,L3,L4,L5},new String[]{ "Lorg/mortbay/jetty/EofException;","Lorg/mortbay/jetty/HttpException;","Ljava/lang/Throwable;",null});
                DexLabel L18=new DexLabel();
                DexLabel L19=new DexLabel();
                code.visitTryCatch(L18,L19,new DexLabel[]{L5},new String[]{ null});
                DexLabel L20=new DexLabel();
                DexLabel L21=new DexLabel();
                code.visitTryCatch(L19,L20,new DexLabel[]{L21,L5},new String[]{ "Ljava/io/IOException;",null});
                DexLabel L22=new DexLabel();
                DexLabel L23=new DexLabel();
                DexLabel L24=new DexLabel();
                code.visitTryCatch(L22,L23,new DexLabel[]{L24},new String[]{ null});
                DexLabel L25=new DexLabel();
                DexLabel L26=new DexLabel();
                code.visitTryCatch(L25,L26,new DexLabel[]{L5},new String[]{ null});
                DexLabel L27=new DexLabel();
                DexLabel L28=new DexLabel();
                DexLabel L29=new DexLabel();
                code.visitTryCatch(L27,L28,new DexLabel[]{L29},new String[]{ null});
                DexLabel L30=new DexLabel();
                DexLabel L31=new DexLabel();
                code.visitTryCatch(L30,L31,new DexLabel[]{L5},new String[]{ null});
                DexLabel L32=new DexLabel();
                DexLabel L33=new DexLabel();
                code.visitTryCatch(L31,L32,new DexLabel[]{L33,L5},new String[]{ "Ljava/io/IOException;",null});
                DexLabel L34=new DexLabel();
                DexLabel L35=new DexLabel();
                DexLabel L36=new DexLabel();
                code.visitTryCatch(L34,L35,new DexLabel[]{L36},new String[]{ null});
                DexLabel L37=new DexLabel();
                DexLabel L38=new DexLabel();
                code.visitTryCatch(L37,L38,new DexLabel[]{L5},new String[]{ null});
                DexLabel L39=new DexLabel();
                DexLabel L40=new DexLabel();
                code.visitTryCatch(L39,L40,new DexLabel[]{L29},new String[]{ null});
                DexLabel L41=new DexLabel();
                DexLabel L42=new DexLabel();
                code.visitTryCatch(L41,L42,new DexLabel[]{L15},new String[]{ null});
                DexLabel L43=new DexLabel();
                DexLabel L44=new DexLabel();
                DexLabel L45=new DexLabel();
                code.visitTryCatch(L43,L44,new DexLabel[]{L45},new String[]{ null});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(208,L0);
                DexLabel L46=new DexLabel();
                ddv.visitLineNumber(209,L46);
                ddv.visitLineNumber(211,L1);
                DexLabel L47=new DexLabel();
                ddv.visitLineNumber(212,L47);
                ddv.visitLineNumber(214,L6);
                DexLabel L48=new DexLabel();
                ddv.visitLineNumber(216,L48);
                DexLabel L49=new DexLabel();
                ddv.visitLineNumber(218,L49);
                DexLabel L50=new DexLabel();
                ddv.visitLineNumber(220,L50);
                DexLabel L51=new DexLabel();
                ddv.visitLineNumber(221,L51);
                ddv.visitStartLocal(2,L51,"lrmit","I",null);
                DexLabel L52=new DexLabel();
                ddv.visitLineNumber(223,L52);
                DexLabel L53=new DexLabel();
                ddv.visitLineNumber(224,L53);
                DexLabel L54=new DexLabel();
                ddv.visitLineNumber(228,L54);
                ddv.visitEndLocal(2,L54);
                ddv.visitLineNumber(231,L2);
                ddv.visitLineNumber(233,L9);
                ddv.visitStartLocal(0,L9,"e","Lorg/mortbay/jetty/EofException;",null);
                ddv.visitLineNumber(234,L10);
                ddv.visitLineNumber(251,L11);
                DexLabel L55=new DexLabel();
                ddv.visitLineNumber(252,L55);
                ddv.visitLineNumber(254,L13);
                DexLabel L56=new DexLabel();
                ddv.visitLineNumber(255,L56);
                ddv.visitLineNumber(257,L14);
                ddv.visitEndLocal(0,L14);
                ddv.visitLineNumber(212,L7);
                ddv.visitLineNumber(237,L3);
                ddv.visitLineNumber(239,L18);
                ddv.visitStartLocal(0,L18,"e","Lorg/mortbay/jetty/HttpException;",null);
                ddv.visitLineNumber(240,L19);
                ddv.visitLineNumber(251,L20);
                DexLabel L57=new DexLabel();
                ddv.visitLineNumber(252,L57);
                ddv.visitLineNumber(254,L22);
                DexLabel L58=new DexLabel();
                ddv.visitLineNumber(255,L58);
                ddv.visitLineNumber(235,L12);
                ddv.visitStartLocal(0,L12,"e","Lorg/mortbay/jetty/EofException;",null);
                ddv.visitStartLocal(1,L25,"e2","Ljava/io/IOException;",null);
                ddv.visitLineNumber(251,L5);
                ddv.visitEndLocal(0,L5);
                ddv.visitEndLocal(1,L5);
                DexLabel L59=new DexLabel();
                ddv.visitLineNumber(252,L59);
                ddv.visitLineNumber(254,L27);
                DexLabel L60=new DexLabel();
                ddv.visitLineNumber(255,L60);
                ddv.visitLineNumber(251,L28);
                ddv.visitLineNumber(241,L21);
                ddv.visitStartLocal(0,L21,"e","Lorg/mortbay/jetty/HttpException;",null);
                ddv.visitRestartLocal(1,L30);
                ddv.visitLineNumber(243,L4);
                ddv.visitEndLocal(0,L4);
                ddv.visitEndLocal(1,L4);
                DexLabel L61=new DexLabel();
                ddv.visitLineNumber(245,L61);
                ddv.visitStartLocal(0,L61,"e","Ljava/lang/Throwable;",null);
                ddv.visitLineNumber(246,L31);
                ddv.visitLineNumber(251,L32);
                DexLabel L62=new DexLabel();
                ddv.visitLineNumber(252,L62);
                ddv.visitLineNumber(254,L34);
                DexLabel L63=new DexLabel();
                ddv.visitLineNumber(255,L63);
                ddv.visitLineNumber(247,L33);
                ddv.visitRestartLocal(1,L37);
                ddv.visitLineNumber(255,L29);
                ddv.visitEndLocal(0,L29);
                ddv.visitEndLocal(1,L29);
                ddv.visitStartLocal(0,L15,"e","Lorg/mortbay/jetty/EofException;",null);
                DexLabel L64=new DexLabel();
                ddv.visitLineNumber(251,L64);
                ddv.visitEndLocal(0,L64);
                DexLabel L65=new DexLabel();
                ddv.visitLineNumber(252,L65);
                ddv.visitLineNumber(254,L43);
                DexLabel L66=new DexLabel();
                ddv.visitLineNumber(255,L66);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,3,6,new Field("Lorg/mortbay/jetty/bio/SocketConnector$Connection;","this$0","Lorg/mortbay/jetty/bio/SocketConnector;"));
                code.visitFieldStmt(IGET_OBJECT,4,6,new Field("Lorg/mortbay/jetty/bio/SocketConnector$Connection;","_connection","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 3,4},new Method("Lorg/mortbay/jetty/bio/SocketConnector;","access$000",new String[]{ "Lorg/mortbay/jetty/bio/SocketConnector;","Lorg/mortbay/jetty/HttpConnection;"},"V"));
                code.visitLabel(L46);
                code.visitFieldStmt(IGET_OBJECT,3,6,new Field("Lorg/mortbay/jetty/bio/SocketConnector$Connection;","this$0","Lorg/mortbay/jetty/bio/SocketConnector;"));
                code.visitFieldStmt(IGET_OBJECT,3,3,new Field("Lorg/mortbay/jetty/bio/SocketConnector;","_connections","Ljava/util/Set;"));
                code.visitStmt1R(MONITOR_ENTER,3);
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,4,6,new Field("Lorg/mortbay/jetty/bio/SocketConnector$Connection;","this$0","Lorg/mortbay/jetty/bio/SocketConnector;"));
                code.visitFieldStmt(IGET_OBJECT,4,4,new Field("Lorg/mortbay/jetty/bio/SocketConnector;","_connections","Ljava/util/Set;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 4,6},new Method("Ljava/util/Set;","add",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitLabel(L47);
                code.visitStmt1R(MONITOR_EXIT,3);
                code.visitLabel(L6);
                code.visitFieldStmt(IGET_OBJECT,3,6,new Field("Lorg/mortbay/jetty/bio/SocketConnector$Connection;","this$0","Lorg/mortbay/jetty/bio/SocketConnector;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Lorg/mortbay/jetty/bio/SocketConnector;","isStarted",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitJumpStmt(IF_EQZ,3,-1,L64);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Lorg/mortbay/jetty/bio/SocketConnector$Connection;","isClosed",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitJumpStmt(IF_NEZ,3,-1,L64);
                code.visitLabel(L48);
                code.visitFieldStmt(IGET_OBJECT,3,6,new Field("Lorg/mortbay/jetty/bio/SocketConnector$Connection;","_connection","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Lorg/mortbay/jetty/HttpConnection;","isIdle",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitJumpStmt(IF_EQZ,3,-1,L54);
                code.visitLabel(L49);
                code.visitFieldStmt(IGET_OBJECT,3,6,new Field("Lorg/mortbay/jetty/bio/SocketConnector$Connection;","this$0","Lorg/mortbay/jetty/bio/SocketConnector;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Lorg/mortbay/jetty/bio/SocketConnector;","getServer",new String[]{ },"Lorg/mortbay/jetty/Server;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Lorg/mortbay/jetty/Server;","getThreadPool",new String[]{ },"Lorg/mortbay/thread/ThreadPool;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,3);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 3},new Method("Lorg/mortbay/thread/ThreadPool;","isLowOnThreads",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitJumpStmt(IF_EQZ,3,-1,L54);
                code.visitLabel(L50);
                code.visitFieldStmt(IGET_OBJECT,3,6,new Field("Lorg/mortbay/jetty/bio/SocketConnector$Connection;","this$0","Lorg/mortbay/jetty/bio/SocketConnector;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Lorg/mortbay/jetty/bio/SocketConnector;","getLowResourceMaxIdleTime",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitLabel(L51);
                code.visitJumpStmt(IF_LTZ,2,-1,L54);
                code.visitFieldStmt(IGET,3,6,new Field("Lorg/mortbay/jetty/bio/SocketConnector$Connection;","_sotimeout","I"));
                code.visitJumpStmt(IF_EQ,3,2,L54);
                code.visitLabel(L52);
                code.visitFieldStmt(IPUT,2,6,new Field("Lorg/mortbay/jetty/bio/SocketConnector$Connection;","_sotimeout","I"));
                code.visitLabel(L53);
                code.visitFieldStmt(IGET_OBJECT,3,6,new Field("Lorg/mortbay/jetty/bio/SocketConnector$Connection;","_socket","Ljava/net/Socket;"));
                code.visitFieldStmt(IGET,4,6,new Field("Lorg/mortbay/jetty/bio/SocketConnector$Connection;","_sotimeout","I"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3,4},new Method("Ljava/net/Socket;","setSoTimeout",new String[]{ "I"},"V"));
                code.visitLabel(L54);
                code.visitFieldStmt(IGET_OBJECT,3,6,new Field("Lorg/mortbay/jetty/bio/SocketConnector$Connection;","_connection","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Lorg/mortbay/jetty/HttpConnection;","handle",new String[]{ },"V"));
                code.visitLabel(L8);
                code.visitJumpStmt(GOTO,-1,-1,L6);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,3);
                code.visitStmt2R(MOVE_OBJECT,0,3);
                code.visitLabel(L9);
                code.visitConstStmt(CONST_STRING,3,"EOF");
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 3,0},new Method("Lorg/mortbay/log/Log;","debug",new String[]{ "Ljava/lang/String;","Ljava/lang/Object;"},"V"));
                code.visitLabel(L10);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Lorg/mortbay/jetty/bio/SocketConnector$Connection;","close",new String[]{ },"V"));
                code.visitLabel(L11);
                code.visitFieldStmt(IGET_OBJECT,3,6,new Field("Lorg/mortbay/jetty/bio/SocketConnector$Connection;","this$0","Lorg/mortbay/jetty/bio/SocketConnector;"));
                code.visitFieldStmt(IGET_OBJECT,4,6,new Field("Lorg/mortbay/jetty/bio/SocketConnector$Connection;","_connection","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 3,4},new Method("Lorg/mortbay/jetty/bio/SocketConnector;","access$100",new String[]{ "Lorg/mortbay/jetty/bio/SocketConnector;","Lorg/mortbay/jetty/HttpConnection;"},"V"));
                code.visitLabel(L55);
                code.visitFieldStmt(IGET_OBJECT,3,6,new Field("Lorg/mortbay/jetty/bio/SocketConnector$Connection;","this$0","Lorg/mortbay/jetty/bio/SocketConnector;"));
                code.visitFieldStmt(IGET_OBJECT,3,3,new Field("Lorg/mortbay/jetty/bio/SocketConnector;","_connections","Ljava/util/Set;"));
                code.visitStmt1R(MONITOR_ENTER,3);
                code.visitLabel(L13);
                code.visitFieldStmt(IGET_OBJECT,4,6,new Field("Lorg/mortbay/jetty/bio/SocketConnector$Connection;","this$0","Lorg/mortbay/jetty/bio/SocketConnector;"));
                code.visitFieldStmt(IGET_OBJECT,4,4,new Field("Lorg/mortbay/jetty/bio/SocketConnector;","_connections","Ljava/util/Set;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 4,6},new Method("Ljava/util/Set;","remove",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitLabel(L56);
                code.visitStmt1R(MONITOR_EXIT,3);
                code.visitLabel(L14);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L7);
                code.visitStmt1R(MOVE_EXCEPTION,4);
                code.visitLabel(L16);
                code.visitStmt1R(MONITOR_EXIT,3);
                code.visitLabel(L17);
                code.visitStmt1R(THROW,4);
                code.visitLabel(L3);
                code.visitStmt1R(MOVE_EXCEPTION,3);
                code.visitStmt2R(MOVE_OBJECT,0,3);
                code.visitLabel(L18);
                code.visitConstStmt(CONST_STRING,3,"BAD");
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 3,0},new Method("Lorg/mortbay/log/Log;","debug",new String[]{ "Ljava/lang/String;","Ljava/lang/Object;"},"V"));
                code.visitLabel(L19);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Lorg/mortbay/jetty/bio/SocketConnector$Connection;","close",new String[]{ },"V"));
                code.visitLabel(L20);
                code.visitFieldStmt(IGET_OBJECT,3,6,new Field("Lorg/mortbay/jetty/bio/SocketConnector$Connection;","this$0","Lorg/mortbay/jetty/bio/SocketConnector;"));
                code.visitFieldStmt(IGET_OBJECT,4,6,new Field("Lorg/mortbay/jetty/bio/SocketConnector$Connection;","_connection","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 3,4},new Method("Lorg/mortbay/jetty/bio/SocketConnector;","access$100",new String[]{ "Lorg/mortbay/jetty/bio/SocketConnector;","Lorg/mortbay/jetty/HttpConnection;"},"V"));
                code.visitLabel(L57);
                code.visitFieldStmt(IGET_OBJECT,3,6,new Field("Lorg/mortbay/jetty/bio/SocketConnector$Connection;","this$0","Lorg/mortbay/jetty/bio/SocketConnector;"));
                code.visitFieldStmt(IGET_OBJECT,3,3,new Field("Lorg/mortbay/jetty/bio/SocketConnector;","_connections","Ljava/util/Set;"));
                code.visitStmt1R(MONITOR_ENTER,3);
                code.visitLabel(L22);
                code.visitFieldStmt(IGET_OBJECT,4,6,new Field("Lorg/mortbay/jetty/bio/SocketConnector$Connection;","this$0","Lorg/mortbay/jetty/bio/SocketConnector;"));
                code.visitFieldStmt(IGET_OBJECT,4,4,new Field("Lorg/mortbay/jetty/bio/SocketConnector;","_connections","Ljava/util/Set;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 4,6},new Method("Ljava/util/Set;","remove",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitLabel(L58);
                code.visitStmt1R(MONITOR_EXIT,3);
                code.visitJumpStmt(GOTO,-1,-1,L14);
                code.visitLabel(L24);
                code.visitStmt1R(MOVE_EXCEPTION,4);
                code.visitStmt1R(MONITOR_EXIT,3);
                code.visitLabel(L23);
                code.visitStmt1R(THROW,4);
                code.visitLabel(L12);
                code.visitStmt1R(MOVE_EXCEPTION,1);
                code.visitLabel(L25);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1},new Method("Lorg/mortbay/log/Log;","ignore",new String[]{ "Ljava/lang/Throwable;"},"V"));
                code.visitLabel(L26);
                code.visitJumpStmt(GOTO,-1,-1,L11);
                code.visitLabel(L5);
                code.visitStmt1R(MOVE_EXCEPTION,3);
                code.visitFieldStmt(IGET_OBJECT,4,6,new Field("Lorg/mortbay/jetty/bio/SocketConnector$Connection;","this$0","Lorg/mortbay/jetty/bio/SocketConnector;"));
                code.visitFieldStmt(IGET_OBJECT,5,6,new Field("Lorg/mortbay/jetty/bio/SocketConnector$Connection;","_connection","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 4,5},new Method("Lorg/mortbay/jetty/bio/SocketConnector;","access$100",new String[]{ "Lorg/mortbay/jetty/bio/SocketConnector;","Lorg/mortbay/jetty/HttpConnection;"},"V"));
                code.visitLabel(L59);
                code.visitFieldStmt(IGET_OBJECT,4,6,new Field("Lorg/mortbay/jetty/bio/SocketConnector$Connection;","this$0","Lorg/mortbay/jetty/bio/SocketConnector;"));
                code.visitFieldStmt(IGET_OBJECT,4,4,new Field("Lorg/mortbay/jetty/bio/SocketConnector;","_connections","Ljava/util/Set;"));
                code.visitStmt1R(MONITOR_ENTER,4);
                code.visitLabel(L27);
                code.visitFieldStmt(IGET_OBJECT,5,6,new Field("Lorg/mortbay/jetty/bio/SocketConnector$Connection;","this$0","Lorg/mortbay/jetty/bio/SocketConnector;"));
                code.visitFieldStmt(IGET_OBJECT,5,5,new Field("Lorg/mortbay/jetty/bio/SocketConnector;","_connections","Ljava/util/Set;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 5,6},new Method("Ljava/util/Set;","remove",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitLabel(L60);
                code.visitStmt1R(MONITOR_EXIT,4);
                code.visitLabel(L28);
                code.visitStmt1R(THROW,3);
                code.visitLabel(L21);
                code.visitStmt1R(MOVE_EXCEPTION,1);
                code.visitLabel(L30);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1},new Method("Lorg/mortbay/log/Log;","ignore",new String[]{ "Ljava/lang/Throwable;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L20);
                code.visitLabel(L4);
                code.visitStmt1R(MOVE_EXCEPTION,3);
                code.visitStmt2R(MOVE_OBJECT,0,3);
                code.visitLabel(L61);
                code.visitConstStmt(CONST_STRING,3,"handle failed");
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 3,0},new Method("Lorg/mortbay/log/Log;","warn",new String[]{ "Ljava/lang/String;","Ljava/lang/Throwable;"},"V"));
                code.visitLabel(L31);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 6},new Method("Lorg/mortbay/jetty/bio/SocketConnector$Connection;","close",new String[]{ },"V"));
                code.visitLabel(L32);
                code.visitFieldStmt(IGET_OBJECT,3,6,new Field("Lorg/mortbay/jetty/bio/SocketConnector$Connection;","this$0","Lorg/mortbay/jetty/bio/SocketConnector;"));
                code.visitFieldStmt(IGET_OBJECT,4,6,new Field("Lorg/mortbay/jetty/bio/SocketConnector$Connection;","_connection","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 3,4},new Method("Lorg/mortbay/jetty/bio/SocketConnector;","access$100",new String[]{ "Lorg/mortbay/jetty/bio/SocketConnector;","Lorg/mortbay/jetty/HttpConnection;"},"V"));
                code.visitLabel(L62);
                code.visitFieldStmt(IGET_OBJECT,3,6,new Field("Lorg/mortbay/jetty/bio/SocketConnector$Connection;","this$0","Lorg/mortbay/jetty/bio/SocketConnector;"));
                code.visitFieldStmt(IGET_OBJECT,3,3,new Field("Lorg/mortbay/jetty/bio/SocketConnector;","_connections","Ljava/util/Set;"));
                code.visitStmt1R(MONITOR_ENTER,3);
                code.visitLabel(L34);
                code.visitFieldStmt(IGET_OBJECT,4,6,new Field("Lorg/mortbay/jetty/bio/SocketConnector$Connection;","this$0","Lorg/mortbay/jetty/bio/SocketConnector;"));
                code.visitFieldStmt(IGET_OBJECT,4,4,new Field("Lorg/mortbay/jetty/bio/SocketConnector;","_connections","Ljava/util/Set;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 4,6},new Method("Ljava/util/Set;","remove",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitLabel(L63);
                code.visitStmt1R(MONITOR_EXIT,3);
                code.visitJumpStmt(GOTO,-1,-1,L14);
                code.visitLabel(L36);
                code.visitStmt1R(MOVE_EXCEPTION,4);
                code.visitStmt1R(MONITOR_EXIT,3);
                code.visitLabel(L35);
                code.visitStmt1R(THROW,4);
                code.visitLabel(L33);
                code.visitStmt1R(MOVE_EXCEPTION,1);
                code.visitLabel(L37);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1},new Method("Lorg/mortbay/log/Log;","ignore",new String[]{ "Ljava/lang/Throwable;"},"V"));
                code.visitLabel(L38);
                code.visitJumpStmt(GOTO,-1,-1,L32);
                code.visitLabel(L29);
                code.visitStmt1R(MOVE_EXCEPTION,3);
                code.visitLabel(L39);
                code.visitStmt1R(MONITOR_EXIT,4);
                code.visitLabel(L40);
                code.visitStmt1R(THROW,3);
                code.visitLabel(L15);
                code.visitStmt1R(MOVE_EXCEPTION,4);
                code.visitLabel(L41);
                code.visitStmt1R(MONITOR_EXIT,3);
                code.visitLabel(L42);
                code.visitStmt1R(THROW,4);
                code.visitLabel(L64);
                code.visitFieldStmt(IGET_OBJECT,3,6,new Field("Lorg/mortbay/jetty/bio/SocketConnector$Connection;","this$0","Lorg/mortbay/jetty/bio/SocketConnector;"));
                code.visitFieldStmt(IGET_OBJECT,4,6,new Field("Lorg/mortbay/jetty/bio/SocketConnector$Connection;","_connection","Lorg/mortbay/jetty/HttpConnection;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 3,4},new Method("Lorg/mortbay/jetty/bio/SocketConnector;","access$100",new String[]{ "Lorg/mortbay/jetty/bio/SocketConnector;","Lorg/mortbay/jetty/HttpConnection;"},"V"));
                code.visitLabel(L65);
                code.visitFieldStmt(IGET_OBJECT,3,6,new Field("Lorg/mortbay/jetty/bio/SocketConnector$Connection;","this$0","Lorg/mortbay/jetty/bio/SocketConnector;"));
                code.visitFieldStmt(IGET_OBJECT,3,3,new Field("Lorg/mortbay/jetty/bio/SocketConnector;","_connections","Ljava/util/Set;"));
                code.visitStmt1R(MONITOR_ENTER,3);
                code.visitLabel(L43);
                code.visitFieldStmt(IGET_OBJECT,4,6,new Field("Lorg/mortbay/jetty/bio/SocketConnector$Connection;","this$0","Lorg/mortbay/jetty/bio/SocketConnector;"));
                code.visitFieldStmt(IGET_OBJECT,4,4,new Field("Lorg/mortbay/jetty/bio/SocketConnector;","_connections","Ljava/util/Set;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 4,6},new Method("Ljava/util/Set;","remove",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitLabel(L66);
                code.visitStmt1R(MONITOR_EXIT,3);
                code.visitJumpStmt(GOTO_16,-1,-1,L14);
                code.visitLabel(L45);
                code.visitStmt1R(MOVE_EXCEPTION,4);
                code.visitStmt1R(MONITOR_EXIT,3);
                code.visitLabel(L44);
                code.visitStmt1R(THROW,4);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
