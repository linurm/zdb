package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0193_org_mortbay_jetty_Server_ShutdownHookThread {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(0,"Lorg/mortbay/jetty/Server$ShutdownHookThread;","Ljava/lang/Thread;",new String[]{ });
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("Server.java");
        if(cv!=null){
            DexAnnotationVisitor av00 = cv.visitAnnotation("Ldalvik/annotation/EnclosingClass;", Visibility.SYSTEM);
            if(av00 != null) {
                av00.visit("value", new DexType("Lorg/mortbay/jetty/Server;"));
                av00.visitEnd();
            }
        }
        if(cv!=null){
            DexAnnotationVisitor av00 = cv.visitAnnotation("Ldalvik/annotation/InnerClass;", Visibility.SYSTEM);
            if(av00 != null) {
                av00.visit("accessFlags",  Integer.valueOf(10));
                av00.visit("name", "ShutdownHookThread");
                av00.visitEnd();
            }
        }
        f000_hooked(cv);
        f001_servers(cv);
        m000__init_(cv);
        m001__init_(cv);
        m002_createShutdownHook(cv);
        m003_add(cv);
        m004_addAll(cv);
        m005_clear(cv);
        m006_contains(cv);
        m007_remove(cv);
        m008_removeAll(cv);
        m009_run(cv);
    }
    public static void f000_hooked(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/Server$ShutdownHookThread;","hooked","Z"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f001_servers(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/Server$ShutdownHookThread;","servers","Ljava/util/ArrayList;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void m000__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PRIVATE|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/jetty/Server$ShutdownHookThread;","<init>",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(461,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(463,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(464,L2);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1},new Method("Ljava/lang/Thread;","<init>",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitFieldStmt(IPUT_BOOLEAN,0,1,new Field("Lorg/mortbay/jetty/Server$ShutdownHookThread;","hooked","Z"));
                code.visitLabel(L2);
                code.visitTypeStmt(NEW_INSTANCE,0,-1,"Ljava/util/ArrayList;");
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/util/ArrayList;","<init>",new String[]{ },"V"));
                code.visitFieldStmt(IPUT_OBJECT,0,1,new Field("Lorg/mortbay/jetty/Server$ShutdownHookThread;","servers","Ljava/util/ArrayList;"));
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_SYNTHETIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/jetty/Server$ShutdownHookThread;","<init>",new String[]{ "Lorg/mortbay/jetty/Server$1;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"x0");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(461,L0);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Lorg/mortbay/jetty/Server$ShutdownHookThread;","<init>",new String[]{ },"V"));
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m002_createShutdownHook(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PRIVATE, new Method("Lorg/mortbay/jetty/Server$ShutdownHookThread;","createShutdownHook",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(8);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ "Ljava/lang/Exception;"});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L3=new DexLabel();
                ddv.visitPrologue(L3);
                ddv.visitLineNumber(473,L3);
                ddv.visitLineNumber(477,L0);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(479,L4);
                ddv.visitStartLocal(1,L4,"shutdownHook","Ljava/lang/reflect/Method;",null);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(481,L5);
                ddv.visitLineNumber(489,L1);
                ddv.visitEndLocal(1,L1);
                ddv.visitLineNumber(483,L2);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(485,L6);
                ddv.visitStartLocal(0,L6,"e","Ljava/lang/Exception;",null);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(486,L7);
                code.visitLabel(L3);
                code.visitConstStmt(CONST_STRING,2,"JETTY_NO_SHUTDOWN_HOOK");
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 2},new Method("Ljava/lang/Boolean;","getBoolean",new String[]{ "Ljava/lang/String;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitJumpStmt(IF_NEZ,2,-1,L1);
                code.visitFieldStmt(IGET_BOOLEAN,2,7,new Field("Lorg/mortbay/jetty/Server$ShutdownHookThread;","hooked","Z"));
                code.visitJumpStmt(IF_NEZ,2,-1,L1);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_CLASS,2,new DexType("Ljava/lang/Runtime;"));
                code.visitConstStmt(CONST_STRING,3,"addShutdownHook");
                code.visitConstStmt(CONST_4,4, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitTypeStmt(NEW_ARRAY,4,4,"[Ljava/lang/Class;");
                code.visitConstStmt(CONST_4,5, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitConstStmt(CONST_CLASS,6,new DexType("Ljava/lang/Thread;"));
                code.visitStmt3R(APUT_OBJECT,6,4,5);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,3,4},new Method("Ljava/lang/Class;","getMethod",new String[]{ "Ljava/lang/String;","[Ljava/lang/Class;"},"Ljava/lang/reflect/Method;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L4);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Ljava/lang/Runtime;","getRuntime",new String[]{ },"Ljava/lang/Runtime;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitTypeStmt(NEW_ARRAY,3,3,"[Ljava/lang/Object;");
                code.visitConstStmt(CONST_4,4, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitStmt3R(APUT_OBJECT,7,3,4);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2,3},new Method("Ljava/lang/reflect/Method;","invoke",new String[]{ "Ljava/lang/Object;","[Ljava/lang/Object;"},"Ljava/lang/Object;"));
                code.visitLabel(L5);
                code.visitConstStmt(CONST_4,2, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitFieldStmt(IPUT_BOOLEAN,2,7,new Field("Lorg/mortbay/jetty/Server$ShutdownHookThread;","hooked","Z"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,2);
                code.visitStmt2R(MOVE_OBJECT,0,2);
                code.visitLabel(L6);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ },new Method("Lorg/mortbay/log/Log;","isDebugEnabled",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,2);
                code.visitJumpStmt(IF_EQZ,2,-1,L1);
                code.visitLabel(L7);
                code.visitConstStmt(CONST_STRING,2,"No shutdown hook in JVM ");
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 2,0},new Method("Lorg/mortbay/log/Log;","debug",new String[]{ "Ljava/lang/String;","Ljava/lang/Object;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L1);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m003_add(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/Server$ShutdownHookThread;","add",new String[]{ "Lorg/mortbay/jetty/Server;"},"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"server");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(496,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(497,L1);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1},new Method("Lorg/mortbay/jetty/Server$ShutdownHookThread;","createShutdownHook",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/Server$ShutdownHookThread;","servers","Ljava/util/ArrayList;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,2},new Method("Ljava/util/ArrayList;","add",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m004_addAll(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/Server$ShutdownHookThread;","addAll",new String[]{ "Ljava/util/Collection;"},"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"c");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(513,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(514,L1);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1},new Method("Lorg/mortbay/jetty/Server$ShutdownHookThread;","createShutdownHook",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/Server$ShutdownHookThread;","servers","Ljava/util/ArrayList;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,2},new Method("Ljava/util/ArrayList;","addAll",new String[]{ "Ljava/util/Collection;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m005_clear(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/Server$ShutdownHookThread;","clear",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(522,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(523,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(524,L2);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1},new Method("Lorg/mortbay/jetty/Server$ShutdownHookThread;","createShutdownHook",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/Server$ShutdownHookThread;","servers","Ljava/util/ArrayList;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Ljava/util/ArrayList;","clear",new String[]{ },"V"));
                code.visitLabel(L2);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m006_contains(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/Server$ShutdownHookThread;","contains",new String[]{ "Lorg/mortbay/jetty/Server;"},"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"server");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(505,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/Server$ShutdownHookThread;","servers","Ljava/util/ArrayList;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,2},new Method("Ljava/util/ArrayList;","contains",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m007_remove(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/Server$ShutdownHookThread;","remove",new String[]{ "Lorg/mortbay/jetty/Server;"},"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"server");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(531,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(532,L1);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1},new Method("Lorg/mortbay/jetty/Server$ShutdownHookThread;","createShutdownHook",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/Server$ShutdownHookThread;","servers","Ljava/util/ArrayList;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,2},new Method("Ljava/util/ArrayList;","remove",new String[]{ "Ljava/lang/Object;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m008_removeAll(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/Server$ShutdownHookThread;","removeAll",new String[]{ "Ljava/util/Collection;"},"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"c");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(540,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(541,L1);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1},new Method("Lorg/mortbay/jetty/Server$ShutdownHookThread;","createShutdownHook",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/jetty/Server$ShutdownHookThread;","servers","Ljava/util/ArrayList;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,2},new Method("Ljava/util/ArrayList;","removeAll",new String[]{ "Ljava/util/Collection;"},"Z"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m009_run(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/Server$ShutdownHookThread;","run",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(6);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ "Ljava/lang/Exception;"});
                DexLabel L3=new DexLabel();
                DexLabel L4=new DexLabel();
                DexLabel L5=new DexLabel();
                code.visitTryCatch(L3,L4,new DexLabel[]{L5},new String[]{ "Ljava/lang/Exception;"});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L6=new DexLabel();
                ddv.visitPrologue(L6);
                ddv.visitLineNumber(549,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(550,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(551,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(552,L9);
                ddv.visitStartLocal(1,L9,"it","Ljava/util/Iterator;",null);
                DexLabel L10=new DexLabel();
                ddv.visitLineNumber(554,L10);
                DexLabel L11=new DexLabel();
                ddv.visitLineNumber(555,L11);
                ddv.visitStartLocal(2,L11,"svr","Lorg/mortbay/jetty/Server;",null);
                ddv.visitLineNumber(559,L0);
                ddv.visitLineNumber(565,L1);
                DexLabel L12=new DexLabel();
                ddv.visitLineNumber(570,L12);
                ddv.visitLineNumber(572,L5);
                DexLabel L13=new DexLabel();
                ddv.visitLineNumber(574,L13);
                ddv.visitStartLocal(0,L13,"e","Ljava/lang/Exception;",null);
                ddv.visitLineNumber(561,L2);
                ddv.visitEndLocal(0,L2);
                DexLabel L14=new DexLabel();
                ddv.visitLineNumber(563,L14);
                ddv.visitRestartLocal(0,L14);
                DexLabel L15=new DexLabel();
                ddv.visitLineNumber(577,L15);
                ddv.visitEndLocal(2,L15);
                ddv.visitEndLocal(0,L15);
                code.visitLabel(L6);
                code.visitConstStmt(CONST_STRING,3,"Shutdown");
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 5,3},new Method("Lorg/mortbay/jetty/Server$ShutdownHookThread;","setName",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L7);
                code.visitConstStmt(CONST_STRING,3,"Shutdown hook executing");
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 3},new Method("Lorg/mortbay/log/Log;","info",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L8);
                code.visitFieldStmt(IGET_OBJECT,3,5,new Field("Lorg/mortbay/jetty/Server$ShutdownHookThread;","servers","Ljava/util/ArrayList;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Ljava/util/ArrayList;","iterator",new String[]{ },"Ljava/util/Iterator;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitLabel(L9);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 1},new Method("Ljava/util/Iterator;","hasNext",new String[]{ },"Z"));
                code.visitStmt1R(MOVE_RESULT,3);
                code.visitJumpStmt(IF_EQZ,3,-1,L15);
                code.visitLabel(L10);
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 1},new Method("Ljava/util/Iterator;","next",new String[]{ },"Ljava/lang/Object;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitTypeStmt(CHECK_CAST,2,-1,"Lorg/mortbay/jetty/Server;");
                code.visitLabel(L11);
                code.visitJumpStmt(IF_EQZ,2,-1,L9);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/jetty/Server;","stop",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitConstStmt(CONST_STRING,3,"Shutdown hook complete");
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 3},new Method("Lorg/mortbay/log/Log;","info",new String[]{ "Ljava/lang/String;"},"V"));
                code.visitLabel(L12);
                code.visitConstStmt(CONST_WIDE_16,3,Long.valueOf(1000L)); // long: 0x00000000000003e8  double:0.000000
                code.visitLabel(L3);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 3,4},new Method("Ljava/lang/Thread;","sleep",new String[]{ "J"},"V"));
                code.visitLabel(L4);
                code.visitJumpStmt(GOTO,-1,-1,L9);
                code.visitLabel(L5);
                code.visitStmt1R(MOVE_EXCEPTION,0);
                code.visitLabel(L13);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0},new Method("Lorg/mortbay/log/Log;","warn",new String[]{ "Ljava/lang/Throwable;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L9);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,0);
                code.visitLabel(L14);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0},new Method("Lorg/mortbay/log/Log;","warn",new String[]{ "Ljava/lang/Throwable;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L1);
                code.visitLabel(L15);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
