package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0439_org_mortbay_util_ajax_JSON_1 {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(0,"Lorg/mortbay/util/ajax/JSON$1;","Ljava/lang/Object;",new String[]{ "Lorg/mortbay/util/ajax/JSON$Convertible;"});
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("JSON.java");
        if(cv!=null){
            DexAnnotationVisitor av00 = cv.visitAnnotation("Ldalvik/annotation/EnclosingMethod;", Visibility.SYSTEM);
            if(av00 != null) {
                av00.visit("value", new Method("Lorg/mortbay/util/ajax/JSON;","appendJSON",new String[]{ "Ljava/lang/StringBuffer;","Lorg/mortbay/util/ajax/JSON$Convertor;","Ljava/lang/Object;"},"V"));
                av00.visitEnd();
            }
        }
        if(cv!=null){
            DexAnnotationVisitor av00 = cv.visitAnnotation("Ldalvik/annotation/InnerClass;", Visibility.SYSTEM);
            if(av00 != null) {
                av00.visit("accessFlags",  Integer.valueOf(0));
                av00.visit("name", null);
                av00.visitEnd();
            }
        }
        f000_this$0(cv);
        f001_val$convertor(cv);
        f002_val$object(cv);
        m000__init_(cv);
        m001_fromJSON(cv);
        m002_toJSON(cv);
    }
    public static void f000_this$0(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_FINAL|ACC_SYNTHETIC, new Field("Lorg/mortbay/util/ajax/JSON$1;","this$0","Lorg/mortbay/util/ajax/JSON;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f001_val$convertor(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_FINAL|ACC_SYNTHETIC, new Field("Lorg/mortbay/util/ajax/JSON$1;","val$convertor","Lorg/mortbay/util/ajax/JSON$Convertor;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f002_val$object(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_FINAL|ACC_SYNTHETIC, new Field("Lorg/mortbay/util/ajax/JSON$1;","val$object","Ljava/lang/Object;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void m000__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_CONSTRUCTOR, new Method("Lorg/mortbay/util/ajax/JSON$1;","<init>",new String[]{ "Lorg/mortbay/util/ajax/JSON;","Lorg/mortbay/util/ajax/JSON$Convertor;","Ljava/lang/Object;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(291,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_OBJECT,1,0,new Field("Lorg/mortbay/util/ajax/JSON$1;","this$0","Lorg/mortbay/util/ajax/JSON;"));
                code.visitFieldStmt(IPUT_OBJECT,2,0,new Field("Lorg/mortbay/util/ajax/JSON$1;","val$convertor","Lorg/mortbay/util/ajax/JSON$Convertor;"));
                code.visitFieldStmt(IPUT_OBJECT,3,0,new Field("Lorg/mortbay/util/ajax/JSON$1;","val$object","Ljava/lang/Object;"));
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/lang/Object;","<init>",new String[]{ },"V"));
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001_fromJSON(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/util/ajax/JSON$1;","fromJSON",new String[]{ "Ljava/util/Map;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"object");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(289,L0);
                code.visitLabel(L0);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m002_toJSON(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/util/ajax/JSON$1;","toJSON",new String[]{ "Lorg/mortbay/util/ajax/JSON$Output;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"out");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(293,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(294,L1);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,2,new Field("Lorg/mortbay/util/ajax/JSON$1;","val$convertor","Lorg/mortbay/util/ajax/JSON$Convertor;"));
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/util/ajax/JSON$1;","val$object","Ljava/lang/Object;"));
                code.visitMethodStmt(INVOKE_INTERFACE,new int[]{ 0,1,3},new Method("Lorg/mortbay/util/ajax/JSON$Convertor;","toJSON",new String[]{ "Ljava/lang/Object;","Lorg/mortbay/util/ajax/JSON$Output;"},"V"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
