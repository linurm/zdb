package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0237_org_mortbay_jetty_deployer_ConfigurationManager {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(ACC_PUBLIC|ACC_INTERFACE|ACC_ABSTRACT,"Lorg/mortbay/jetty/deployer/ConfigurationManager;","Ljava/lang/Object;",new String[]{ });
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("ConfigurationManager.java");
        m000_getProperties(cv);
    }
    public static void m000_getProperties(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_ABSTRACT, new Method("Lorg/mortbay/jetty/deployer/ConfigurationManager;","getProperties",new String[]{ },"Ljava/util/Map;"));
        if(mv != null) {
            mv.visitEnd();
        }
    }
}
