package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0222_org_mortbay_jetty_client_SocketConnector_1 {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(0,"Lorg/mortbay/jetty/client/SocketConnector$1;","Ljava/lang/Object;",new String[]{ "Ljava/lang/Runnable;"});
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("SocketConnector.java");
        if(cv!=null){
            DexAnnotationVisitor av00 = cv.visitAnnotation("Ldalvik/annotation/EnclosingMethod;", Visibility.SYSTEM);
            if(av00 != null) {
                av00.visit("value", new Method("Lorg/mortbay/jetty/client/SocketConnector;","startConnection",new String[]{ "Lorg/mortbay/jetty/client/HttpDestination;"},"V"));
                av00.visitEnd();
            }
        }
        if(cv!=null){
            DexAnnotationVisitor av00 = cv.visitAnnotation("Ldalvik/annotation/InnerClass;", Visibility.SYSTEM);
            if(av00 != null) {
                av00.visit("accessFlags",  Integer.valueOf(0));
                av00.visit("name", null);
                av00.visitEnd();
            }
        }
        f000_this$0(cv);
        f001_val$connection(cv);
        f002_val$destination(cv);
        m000__init_(cv);
        m001_run(cv);
    }
    public static void f000_this$0(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_FINAL|ACC_SYNTHETIC, new Field("Lorg/mortbay/jetty/client/SocketConnector$1;","this$0","Lorg/mortbay/jetty/client/SocketConnector;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f001_val$connection(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_FINAL|ACC_SYNTHETIC, new Field("Lorg/mortbay/jetty/client/SocketConnector$1;","val$connection","Lorg/mortbay/jetty/client/HttpConnection;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f002_val$destination(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_FINAL|ACC_SYNTHETIC, new Field("Lorg/mortbay/jetty/client/SocketConnector$1;","val$destination","Lorg/mortbay/jetty/client/HttpDestination;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void m000__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_CONSTRUCTOR, new Method("Lorg/mortbay/jetty/client/SocketConnector$1;","<init>",new String[]{ "Lorg/mortbay/jetty/client/SocketConnector;","Lorg/mortbay/jetty/client/HttpConnection;","Lorg/mortbay/jetty/client/HttpDestination;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(68,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_OBJECT,1,0,new Field("Lorg/mortbay/jetty/client/SocketConnector$1;","this$0","Lorg/mortbay/jetty/client/SocketConnector;"));
                code.visitFieldStmt(IPUT_OBJECT,2,0,new Field("Lorg/mortbay/jetty/client/SocketConnector$1;","val$connection","Lorg/mortbay/jetty/client/HttpConnection;"));
                code.visitFieldStmt(IPUT_OBJECT,3,0,new Field("Lorg/mortbay/jetty/client/SocketConnector$1;","val$destination","Lorg/mortbay/jetty/client/HttpDestination;"));
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Ljava/lang/Object;","<init>",new String[]{ },"V"));
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001_run(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/client/SocketConnector$1;","run",new String[]{ },"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexLabel L0=new DexLabel();
                DexLabel L1=new DexLabel();
                DexLabel L2=new DexLabel();
                code.visitTryCatch(L0,L1,new DexLabel[]{L2},new String[]{ "Ljava/io/IOException;"});
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(72,L0);
                ddv.visitLineNumber(84,L1);
                ddv.visitLineNumber(74,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(76,L3);
                ddv.visitStartLocal(0,L3,"e","Ljava/io/IOException;",null);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(77,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(80,L5);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(81,L6);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/jetty/client/SocketConnector$1;","val$connection","Lorg/mortbay/jetty/client/HttpConnection;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1},new Method("Lorg/mortbay/jetty/client/HttpConnection;","handle",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L2);
                code.visitStmt1R(MOVE_EXCEPTION,1);
                code.visitStmt2R(MOVE_OBJECT,0,1);
                code.visitLabel(L3);
                code.visitTypeStmt(INSTANCE_OF,1,0,"Ljava/io/InterruptedIOException;");
                code.visitJumpStmt(IF_EQZ,1,-1,L5);
                code.visitLabel(L4);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0},new Method("Lorg/mortbay/log/Log;","ignore",new String[]{ "Ljava/lang/Throwable;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L1);
                code.visitLabel(L5);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0},new Method("Lorg/mortbay/log/Log;","warn",new String[]{ "Ljava/lang/Throwable;"},"V"));
                code.visitLabel(L6);
                code.visitFieldStmt(IGET_OBJECT,1,2,new Field("Lorg/mortbay/jetty/client/SocketConnector$1;","val$destination","Lorg/mortbay/jetty/client/HttpDestination;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,0},new Method("Lorg/mortbay/jetty/client/HttpDestination;","onException",new String[]{ "Ljava/lang/Throwable;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L1);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
