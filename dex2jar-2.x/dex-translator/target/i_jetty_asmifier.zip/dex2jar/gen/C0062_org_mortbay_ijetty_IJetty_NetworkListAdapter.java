package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0062_org_mortbay_ijetty_IJetty_NetworkListAdapter {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(0,"Lorg/mortbay/ijetty/IJetty$NetworkListAdapter;","Landroid/widget/BaseAdapter;",new String[]{ });
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("IJetty.java");
        if(cv!=null){
            DexAnnotationVisitor av00 = cv.visitAnnotation("Ldalvik/annotation/EnclosingClass;", Visibility.SYSTEM);
            if(av00 != null) {
                av00.visit("value", new DexType("Lorg/mortbay/ijetty/IJetty;"));
                av00.visitEnd();
            }
        }
        if(cv!=null){
            DexAnnotationVisitor av00 = cv.visitAnnotation("Ldalvik/annotation/InnerClass;", Visibility.SYSTEM);
            if(av00 != null) {
                av00.visit("accessFlags",  Integer.valueOf(2));
                av00.visit("name", "NetworkListAdapter");
                av00.visitEnd();
            }
        }
        f000__context(cv);
        f001__ipList(cv);
        f002_this$0(cv);
        m000__init_(cv);
        m001_areAllItemsSelectable(cv);
        m002_getCount(cv);
        m003_getItem(cv);
        m004_getItemId(cv);
        m005_getView(cv);
        m006_isSelectable(cv);
    }
    public static void f000__context(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/ijetty/IJetty$NetworkListAdapter;","_context","Landroid/content/Context;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f001__ipList(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/ijetty/IJetty$NetworkListAdapter;","_ipList","Lorg/mortbay/ijetty/IJetty$IPList;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void f002_this$0(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_FINAL|ACC_SYNTHETIC, new Field("Lorg/mortbay/ijetty/IJetty$NetworkListAdapter;","this$0","Lorg/mortbay/ijetty/IJetty;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void m000__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/ijetty/IJetty$NetworkListAdapter;","<init>",new String[]{ "Lorg/mortbay/ijetty/IJetty;","Landroid/content/Context;","Lorg/mortbay/ijetty/IJetty$IPList;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(1,"context");
                ddv.visitParameterName(2,"ipList");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(127,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(128,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(129,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(130,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(131,L4);
                code.visitLabel(L0);
                code.visitFieldStmt(IPUT_OBJECT,2,1,new Field("Lorg/mortbay/ijetty/IJetty$NetworkListAdapter;","this$0","Lorg/mortbay/ijetty/IJetty;"));
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1},new Method("Landroid/widget/BaseAdapter;","<init>",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitFieldStmt(IPUT_OBJECT,3,1,new Field("Lorg/mortbay/ijetty/IJetty$NetworkListAdapter;","_context","Landroid/content/Context;"));
                code.visitLabel(L2);
                code.visitFieldStmt(IPUT_OBJECT,4,1,new Field("Lorg/mortbay/ijetty/IJetty$NetworkListAdapter;","_ipList","Lorg/mortbay/ijetty/IJetty$IPList;"));
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/ijetty/IJetty$NetworkListAdapter;","_ipList","Lorg/mortbay/ijetty/IJetty$IPList;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/ijetty/IJetty$IPList;","refresh",new String[]{ },"V"));
                code.visitLabel(L4);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001_areAllItemsSelectable(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/ijetty/IJetty$NetworkListAdapter;","areAllItemsSelectable",new String[]{ },"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(140,L0);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m002_getCount(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/ijetty/IJetty$NetworkListAdapter;","getCount",new String[]{ },"I"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(135,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,1,new Field("Lorg/mortbay/ijetty/IJetty$NetworkListAdapter;","_ipList","Lorg/mortbay/ijetty/IJetty$IPList;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0},new Method("Lorg/mortbay/ijetty/IJetty$IPList;","getCount",new String[]{ },"I"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m003_getItem(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/ijetty/IJetty$NetworkListAdapter;","getItem",new String[]{ "I"},"Ljava/lang/Object;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"position");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(150,L0);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 2},new Method("Ljava/lang/Integer;","valueOf",new String[]{ "I"},"Ljava/lang/Integer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m004_getItemId(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/ijetty/IJetty$NetworkListAdapter;","getItemId",new String[]{ "I"},"J"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"position");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(155,L0);
                code.visitLabel(L0);
                code.visitStmt2R(INT_TO_LONG,0,3);
                code.visitStmt1R(RETURN_WIDE,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m005_getView(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/ijetty/IJetty$NetworkListAdapter;","getView",new String[]{ "I","Landroid/view/View;","Landroid/view/ViewGroup;"},"Landroid/view/View;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(7);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"position");
                ddv.visitParameterName(1,"convertView");
                ddv.visitParameterName(2,"parent");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(161,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(163,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(169,L2);
                ddv.visitStartLocal(1,L2,"tv","Landroid/widget/TextView;",null);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(170,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(167,L4);
                ddv.visitEndLocal(1,L4);
                DexLabel L5=new DexLabel();
                ddv.visitRestartLocal(1,L5);
                code.visitLabel(L0);
                code.visitJumpStmt(IF_NEZ,5,-1,L4);
                code.visitLabel(L1);
                code.visitTypeStmt(NEW_INSTANCE,1,-1,"Landroid/widget/TextView;");
                code.visitFieldStmt(IGET_OBJECT,2,3,new Field("Lorg/mortbay/ijetty/IJetty$NetworkListAdapter;","_context","Landroid/content/Context;"));
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 1,2},new Method("Landroid/widget/TextView;","<init>",new String[]{ "Landroid/content/Context;"},"V"));
                code.visitLabel(L2);
                code.visitFieldStmt(IGET_OBJECT,2,3,new Field("Lorg/mortbay/ijetty/IJetty$NetworkListAdapter;","_ipList","Lorg/mortbay/ijetty/IJetty$IPList;"));
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2,4},new Method("Lorg/mortbay/ijetty/IJetty$IPList;","getItem",new String[]{ "I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,2);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 1,2},new Method("Landroid/widget/TextView;","setText",new String[]{ "Ljava/lang/CharSequence;"},"V"));
                code.visitLabel(L3);
                code.visitStmt1R(RETURN_OBJECT,1);
                code.visitLabel(L4);
                code.visitStmt2R(MOVE_OBJECT,0,5);
                code.visitTypeStmt(CHECK_CAST,0,-1,"Landroid/widget/TextView;");
                code.visitStmt2R(MOVE_OBJECT,1,0);
                code.visitLabel(L5);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m006_isSelectable(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/ijetty/IJetty$NetworkListAdapter;","isSelectable",new String[]{ "I"},"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"position");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(145,L0);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitStmt1R(RETURN,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
