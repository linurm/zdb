package dex2jar.gen;
import com.googlecode.d2j.*;
import com.googlecode.d2j.visitors.*;
import static com.googlecode.d2j.DexConstants.*;
import static com.googlecode.d2j.reader.Op.*;
public class C0146_org_mortbay_jetty_EncodedHttpURI {
    public static void accept(DexFileVisitor v) {
        DexClassVisitor cv=v.visit(ACC_PUBLIC,"Lorg/mortbay/jetty/EncodedHttpURI;","Lorg/mortbay/jetty/HttpURI;",new String[]{ });
        if(cv!=null) {
            accept(cv);
            cv.visitEnd();
        }
    }
    public static void accept(DexClassVisitor cv) {
        cv.visitSource("EncodedHttpURI.java");
        f000__encoding(cv);
        m000__init_(cv);
        m001_decodeQueryTo(cv);
        m002_decodeQueryTo(cv);
        m003_getAuthority(cv);
        m004_getCompletePath(cv);
        m005_getDecodedPath(cv);
        m006_getFragment(cv);
        m007_getHost(cv);
        m008_getParam(cv);
        m009_getPath(cv);
        m010_getPathAndParam(cv);
        m011_getPort(cv);
        m012_getQuery(cv);
        m013_getScheme(cv);
        m014_hasQuery(cv);
        m015_toString(cv);
        m016_writeTo(cv);
    }
    public static void f000__encoding(DexClassVisitor cv) {
        DexFieldVisitor fv=cv.visitField(ACC_PRIVATE, new Field("Lorg/mortbay/jetty/EncodedHttpURI;","_encoding","Ljava/lang/String;"), null);
        if(fv != null) {
            fv.visitEnd();
        }
    }
    public static void m000__init_(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC|ACC_CONSTRUCTOR, new Method("Lorg/mortbay/jetty/EncodedHttpURI;","<init>",new String[]{ "Ljava/lang/String;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(2);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"encoding");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(18,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(19,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(20,L2);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_DIRECT,new int[]{ 0},new Method("Lorg/mortbay/jetty/HttpURI;","<init>",new String[]{ },"V"));
                code.visitLabel(L1);
                code.visitFieldStmt(IPUT_OBJECT,1,0,new Field("Lorg/mortbay/jetty/EncodedHttpURI;","_encoding","Ljava/lang/String;"));
                code.visitLabel(L2);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m001_decodeQueryTo(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/EncodedHttpURI;","decodeQueryTo",new String[]{ "Lorg/mortbay/util/MultiMap;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(6);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"parameters");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(122,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(125,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(124,L2);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET,0,4,new Field("Lorg/mortbay/jetty/EncodedHttpURI;","_query","I"));
                code.visitFieldStmt(IGET,1,4,new Field("Lorg/mortbay/jetty/EncodedHttpURI;","_fragment","I"));
                code.visitJumpStmt(IF_NE,0,1,L2);
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L2);
                code.visitFieldStmt(IGET_OBJECT,0,4,new Field("Lorg/mortbay/jetty/EncodedHttpURI;","_raw","[B"));
                code.visitFieldStmt(IGET,1,4,new Field("Lorg/mortbay/jetty/EncodedHttpURI;","_query","I"));
                code.visitStmt2R1N(ADD_INT_LIT8,1,1,1);
                code.visitFieldStmt(IGET,2,4,new Field("Lorg/mortbay/jetty/EncodedHttpURI;","_fragment","I"));
                code.visitFieldStmt(IGET,3,4,new Field("Lorg/mortbay/jetty/EncodedHttpURI;","_query","I"));
                code.visitStmt2R(SUB_INT_2ADDR,2,3);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitStmt2R(SUB_INT_2ADDR,2,3);
                code.visitFieldStmt(IGET_OBJECT,3,4,new Field("Lorg/mortbay/jetty/EncodedHttpURI;","_encoding","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0,1,2,3},new Method("Lorg/mortbay/util/StringUtil;","toString",new String[]{ "[B","I","I","Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(IGET_OBJECT,1,4,new Field("Lorg/mortbay/jetty/EncodedHttpURI;","_encoding","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0,5,1},new Method("Lorg/mortbay/util/UrlEncoded;","decodeTo",new String[]{ "Ljava/lang/String;","Lorg/mortbay/util/MultiMap;","Ljava/lang/String;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L1);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m002_decodeQueryTo(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/EncodedHttpURI;","decodeQueryTo",new String[]{ "Lorg/mortbay/util/MultiMap;","Ljava/lang/String;"},"V"));
        if(mv != null) {
            if(mv!=null){
                DexAnnotationVisitor av00 = mv.visitAnnotation("Ldalvik/annotation/Throws;", Visibility.SYSTEM);
                if(av00 != null) {
                    {
                        DexAnnotationVisitor av01 = av00.visitArray("value");
                        if(av01 != null) {
                            av01.visit(null, new DexType("Ljava/io/UnsupportedEncodingException;"));
                            av01.visitEnd();
                        }
                    }
                    av00.visitEnd();
                }
            }
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(7);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"parameters");
                ddv.visitParameterName(1,"encoding");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(130,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(136,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(133,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(134,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(135,L4);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET,0,4,new Field("Lorg/mortbay/jetty/EncodedHttpURI;","_query","I"));
                code.visitFieldStmt(IGET,1,4,new Field("Lorg/mortbay/jetty/EncodedHttpURI;","_fragment","I"));
                code.visitJumpStmt(IF_NE,0,1,L2);
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitLabel(L2);
                code.visitJumpStmt(IF_NEZ,6,-1,L4);
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,6,4,new Field("Lorg/mortbay/jetty/EncodedHttpURI;","_encoding","Ljava/lang/String;"));
                code.visitLabel(L4);
                code.visitFieldStmt(IGET_OBJECT,0,4,new Field("Lorg/mortbay/jetty/EncodedHttpURI;","_raw","[B"));
                code.visitFieldStmt(IGET,1,4,new Field("Lorg/mortbay/jetty/EncodedHttpURI;","_query","I"));
                code.visitStmt2R1N(ADD_INT_LIT8,1,1,1);
                code.visitFieldStmt(IGET,2,4,new Field("Lorg/mortbay/jetty/EncodedHttpURI;","_fragment","I"));
                code.visitFieldStmt(IGET,3,4,new Field("Lorg/mortbay/jetty/EncodedHttpURI;","_query","I"));
                code.visitStmt2R(SUB_INT_2ADDR,2,3);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitStmt2R(SUB_INT_2ADDR,2,3);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0,1,2,6},new Method("Lorg/mortbay/util/StringUtil;","toString",new String[]{ "[B","I","I","Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0,5,6},new Method("Lorg/mortbay/util/UrlEncoded;","decodeTo",new String[]{ "Ljava/lang/String;","Lorg/mortbay/util/MultiMap;","Ljava/lang/String;"},"V"));
                code.visitJumpStmt(GOTO,-1,-1,L1);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m003_getAuthority(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/EncodedHttpURI;","getAuthority",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(47,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(48,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(49,L2);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET,0,4,new Field("Lorg/mortbay/jetty/EncodedHttpURI;","_authority","I"));
                code.visitFieldStmt(IGET,1,4,new Field("Lorg/mortbay/jetty/EncodedHttpURI;","_path","I"));
                DexLabel L3=new DexLabel();
                code.visitJumpStmt(IF_NE,0,1,L3);
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L2);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,0,4,new Field("Lorg/mortbay/jetty/EncodedHttpURI;","_raw","[B"));
                code.visitFieldStmt(IGET,1,4,new Field("Lorg/mortbay/jetty/EncodedHttpURI;","_authority","I"));
                code.visitFieldStmt(IGET,2,4,new Field("Lorg/mortbay/jetty/EncodedHttpURI;","_path","I"));
                code.visitFieldStmt(IGET,3,4,new Field("Lorg/mortbay/jetty/EncodedHttpURI;","_authority","I"));
                code.visitStmt2R(SUB_INT_2ADDR,2,3);
                code.visitFieldStmt(IGET_OBJECT,3,4,new Field("Lorg/mortbay/jetty/EncodedHttpURI;","_encoding","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0,1,2,3},new Method("Lorg/mortbay/util/StringUtil;","toString",new String[]{ "[B","I","I","Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m004_getCompletePath(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/EncodedHttpURI;","getCompletePath",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(89,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(90,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(91,L2);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET,0,4,new Field("Lorg/mortbay/jetty/EncodedHttpURI;","_path","I"));
                code.visitFieldStmt(IGET,1,4,new Field("Lorg/mortbay/jetty/EncodedHttpURI;","_end","I"));
                DexLabel L3=new DexLabel();
                code.visitJumpStmt(IF_NE,0,1,L3);
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L2);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,0,4,new Field("Lorg/mortbay/jetty/EncodedHttpURI;","_raw","[B"));
                code.visitFieldStmt(IGET,1,4,new Field("Lorg/mortbay/jetty/EncodedHttpURI;","_path","I"));
                code.visitFieldStmt(IGET,2,4,new Field("Lorg/mortbay/jetty/EncodedHttpURI;","_end","I"));
                code.visitFieldStmt(IGET,3,4,new Field("Lorg/mortbay/jetty/EncodedHttpURI;","_path","I"));
                code.visitStmt2R(SUB_INT_2ADDR,2,3);
                code.visitFieldStmt(IGET_OBJECT,3,4,new Field("Lorg/mortbay/jetty/EncodedHttpURI;","_encoding","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0,1,2,3},new Method("Lorg/mortbay/util/StringUtil;","toString",new String[]{ "[B","I","I","Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m005_getDecodedPath(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/EncodedHttpURI;","getDecodedPath",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(75,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(76,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(77,L2);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET,0,4,new Field("Lorg/mortbay/jetty/EncodedHttpURI;","_path","I"));
                code.visitFieldStmt(IGET,1,4,new Field("Lorg/mortbay/jetty/EncodedHttpURI;","_param","I"));
                DexLabel L3=new DexLabel();
                code.visitJumpStmt(IF_NE,0,1,L3);
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L2);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,0,4,new Field("Lorg/mortbay/jetty/EncodedHttpURI;","_raw","[B"));
                code.visitFieldStmt(IGET,1,4,new Field("Lorg/mortbay/jetty/EncodedHttpURI;","_path","I"));
                code.visitFieldStmt(IGET,2,4,new Field("Lorg/mortbay/jetty/EncodedHttpURI;","_param","I"));
                code.visitFieldStmt(IGET,3,4,new Field("Lorg/mortbay/jetty/EncodedHttpURI;","_path","I"));
                code.visitStmt2R(SUB_INT_2ADDR,2,3);
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0,1,2},new Method("Lorg/mortbay/util/URIUtil;","decodePath",new String[]{ "[B","I","I"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m006_getFragment(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/EncodedHttpURI;","getFragment",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(115,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(116,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(117,L2);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET,0,4,new Field("Lorg/mortbay/jetty/EncodedHttpURI;","_fragment","I"));
                code.visitFieldStmt(IGET,1,4,new Field("Lorg/mortbay/jetty/EncodedHttpURI;","_end","I"));
                DexLabel L3=new DexLabel();
                code.visitJumpStmt(IF_NE,0,1,L3);
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L2);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,0,4,new Field("Lorg/mortbay/jetty/EncodedHttpURI;","_raw","[B"));
                code.visitFieldStmt(IGET,1,4,new Field("Lorg/mortbay/jetty/EncodedHttpURI;","_fragment","I"));
                code.visitStmt2R1N(ADD_INT_LIT8,1,1,1);
                code.visitFieldStmt(IGET,2,4,new Field("Lorg/mortbay/jetty/EncodedHttpURI;","_end","I"));
                code.visitFieldStmt(IGET,3,4,new Field("Lorg/mortbay/jetty/EncodedHttpURI;","_fragment","I"));
                code.visitStmt2R(SUB_INT_2ADDR,2,3);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitStmt2R(SUB_INT_2ADDR,2,3);
                code.visitFieldStmt(IGET_OBJECT,3,4,new Field("Lorg/mortbay/jetty/EncodedHttpURI;","_encoding","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0,1,2,3},new Method("Lorg/mortbay/util/StringUtil;","toString",new String[]{ "[B","I","I","Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m007_getHost(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/EncodedHttpURI;","getHost",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(54,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(55,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(56,L2);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET,0,4,new Field("Lorg/mortbay/jetty/EncodedHttpURI;","_host","I"));
                code.visitFieldStmt(IGET,1,4,new Field("Lorg/mortbay/jetty/EncodedHttpURI;","_port","I"));
                DexLabel L3=new DexLabel();
                code.visitJumpStmt(IF_NE,0,1,L3);
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L2);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,0,4,new Field("Lorg/mortbay/jetty/EncodedHttpURI;","_raw","[B"));
                code.visitFieldStmt(IGET,1,4,new Field("Lorg/mortbay/jetty/EncodedHttpURI;","_host","I"));
                code.visitFieldStmt(IGET,2,4,new Field("Lorg/mortbay/jetty/EncodedHttpURI;","_port","I"));
                code.visitFieldStmt(IGET,3,4,new Field("Lorg/mortbay/jetty/EncodedHttpURI;","_host","I"));
                code.visitStmt2R(SUB_INT_2ADDR,2,3);
                code.visitFieldStmt(IGET_OBJECT,3,4,new Field("Lorg/mortbay/jetty/EncodedHttpURI;","_encoding","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0,1,2,3},new Method("Lorg/mortbay/util/StringUtil;","toString",new String[]{ "[B","I","I","Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m008_getParam(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/EncodedHttpURI;","getParam",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(96,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(97,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(98,L2);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET,0,4,new Field("Lorg/mortbay/jetty/EncodedHttpURI;","_param","I"));
                code.visitFieldStmt(IGET,1,4,new Field("Lorg/mortbay/jetty/EncodedHttpURI;","_query","I"));
                DexLabel L3=new DexLabel();
                code.visitJumpStmt(IF_NE,0,1,L3);
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L2);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,0,4,new Field("Lorg/mortbay/jetty/EncodedHttpURI;","_raw","[B"));
                code.visitFieldStmt(IGET,1,4,new Field("Lorg/mortbay/jetty/EncodedHttpURI;","_param","I"));
                code.visitStmt2R1N(ADD_INT_LIT8,1,1,1);
                code.visitFieldStmt(IGET,2,4,new Field("Lorg/mortbay/jetty/EncodedHttpURI;","_query","I"));
                code.visitFieldStmt(IGET,3,4,new Field("Lorg/mortbay/jetty/EncodedHttpURI;","_param","I"));
                code.visitStmt2R(SUB_INT_2ADDR,2,3);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitStmt2R(SUB_INT_2ADDR,2,3);
                code.visitFieldStmt(IGET_OBJECT,3,4,new Field("Lorg/mortbay/jetty/EncodedHttpURI;","_encoding","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0,1,2,3},new Method("Lorg/mortbay/util/StringUtil;","toString",new String[]{ "[B","I","I","Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m009_getPath(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/EncodedHttpURI;","getPath",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(68,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(69,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(70,L2);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET,0,4,new Field("Lorg/mortbay/jetty/EncodedHttpURI;","_path","I"));
                code.visitFieldStmt(IGET,1,4,new Field("Lorg/mortbay/jetty/EncodedHttpURI;","_param","I"));
                DexLabel L3=new DexLabel();
                code.visitJumpStmt(IF_NE,0,1,L3);
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L2);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,0,4,new Field("Lorg/mortbay/jetty/EncodedHttpURI;","_raw","[B"));
                code.visitFieldStmt(IGET,1,4,new Field("Lorg/mortbay/jetty/EncodedHttpURI;","_path","I"));
                code.visitFieldStmt(IGET,2,4,new Field("Lorg/mortbay/jetty/EncodedHttpURI;","_param","I"));
                code.visitFieldStmt(IGET,3,4,new Field("Lorg/mortbay/jetty/EncodedHttpURI;","_path","I"));
                code.visitStmt2R(SUB_INT_2ADDR,2,3);
                code.visitFieldStmt(IGET_OBJECT,3,4,new Field("Lorg/mortbay/jetty/EncodedHttpURI;","_encoding","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0,1,2,3},new Method("Lorg/mortbay/util/StringUtil;","toString",new String[]{ "[B","I","I","Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m010_getPathAndParam(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/EncodedHttpURI;","getPathAndParam",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(82,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(83,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(84,L2);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET,0,4,new Field("Lorg/mortbay/jetty/EncodedHttpURI;","_path","I"));
                code.visitFieldStmt(IGET,1,4,new Field("Lorg/mortbay/jetty/EncodedHttpURI;","_query","I"));
                DexLabel L3=new DexLabel();
                code.visitJumpStmt(IF_NE,0,1,L3);
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L2);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,0,4,new Field("Lorg/mortbay/jetty/EncodedHttpURI;","_raw","[B"));
                code.visitFieldStmt(IGET,1,4,new Field("Lorg/mortbay/jetty/EncodedHttpURI;","_path","I"));
                code.visitFieldStmt(IGET,2,4,new Field("Lorg/mortbay/jetty/EncodedHttpURI;","_query","I"));
                code.visitFieldStmt(IGET,3,4,new Field("Lorg/mortbay/jetty/EncodedHttpURI;","_path","I"));
                code.visitStmt2R(SUB_INT_2ADDR,2,3);
                code.visitFieldStmt(IGET_OBJECT,3,4,new Field("Lorg/mortbay/jetty/EncodedHttpURI;","_encoding","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0,1,2,3},new Method("Lorg/mortbay/util/StringUtil;","toString",new String[]{ "[B","I","I","Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m011_getPort(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/EncodedHttpURI;","getPort",new String[]{ },"I"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(61,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(62,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(63,L2);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET,0,4,new Field("Lorg/mortbay/jetty/EncodedHttpURI;","_port","I"));
                code.visitFieldStmt(IGET,1,4,new Field("Lorg/mortbay/jetty/EncodedHttpURI;","_path","I"));
                DexLabel L3=new DexLabel();
                code.visitJumpStmt(IF_NE,0,1,L3);
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(-1)); // int: 0xffffffff  float:NaN
                code.visitLabel(L2);
                code.visitStmt1R(RETURN,0);
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,0,4,new Field("Lorg/mortbay/jetty/EncodedHttpURI;","_raw","[B"));
                code.visitFieldStmt(IGET,1,4,new Field("Lorg/mortbay/jetty/EncodedHttpURI;","_port","I"));
                code.visitStmt2R1N(ADD_INT_LIT8,1,1,1);
                code.visitFieldStmt(IGET,2,4,new Field("Lorg/mortbay/jetty/EncodedHttpURI;","_path","I"));
                code.visitFieldStmt(IGET,3,4,new Field("Lorg/mortbay/jetty/EncodedHttpURI;","_port","I"));
                code.visitStmt2R(SUB_INT_2ADDR,2,3);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitStmt2R(SUB_INT_2ADDR,2,3);
                code.visitConstStmt(CONST_16,3, Integer.valueOf(10)); // int: 0x0000000a  float:0.000000
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0,1,2,3},new Method("Lorg/mortbay/util/TypeUtil;","parseInt",new String[]{ "[B","I","I","I"},"I"));
                code.visitStmt1R(MOVE_RESULT,0);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m012_getQuery(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/EncodedHttpURI;","getQuery",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(103,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(104,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(105,L2);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET,0,4,new Field("Lorg/mortbay/jetty/EncodedHttpURI;","_query","I"));
                code.visitFieldStmt(IGET,1,4,new Field("Lorg/mortbay/jetty/EncodedHttpURI;","_fragment","I"));
                DexLabel L3=new DexLabel();
                code.visitJumpStmt(IF_NE,0,1,L3);
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L2);
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitLabel(L3);
                code.visitFieldStmt(IGET_OBJECT,0,4,new Field("Lorg/mortbay/jetty/EncodedHttpURI;","_raw","[B"));
                code.visitFieldStmt(IGET,1,4,new Field("Lorg/mortbay/jetty/EncodedHttpURI;","_query","I"));
                code.visitStmt2R1N(ADD_INT_LIT8,1,1,1);
                code.visitFieldStmt(IGET,2,4,new Field("Lorg/mortbay/jetty/EncodedHttpURI;","_fragment","I"));
                code.visitFieldStmt(IGET,3,4,new Field("Lorg/mortbay/jetty/EncodedHttpURI;","_query","I"));
                code.visitStmt2R(SUB_INT_2ADDR,2,3);
                code.visitConstStmt(CONST_4,3, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitStmt2R(SUB_INT_2ADDR,2,3);
                code.visitFieldStmt(IGET_OBJECT,3,4,new Field("Lorg/mortbay/jetty/EncodedHttpURI;","_encoding","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0,1,2,3},new Method("Lorg/mortbay/util/StringUtil;","toString",new String[]{ "[B","I","I","Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m013_getScheme(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/EncodedHttpURI;","getScheme",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(7);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(25,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(26,L2);
                DexLabel L3=new DexLabel();
                ddv.visitLineNumber(42,L3);
                DexLabel L4=new DexLabel();
                ddv.visitLineNumber(27,L4);
                DexLabel L5=new DexLabel();
                ddv.visitLineNumber(28,L5);
                ddv.visitStartLocal(0,L5,"l","I",null);
                DexLabel L6=new DexLabel();
                ddv.visitLineNumber(33,L6);
                DexLabel L7=new DexLabel();
                ddv.visitLineNumber(34,L7);
                DexLabel L8=new DexLabel();
                ddv.visitLineNumber(40,L8);
                DexLabel L9=new DexLabel();
                ddv.visitLineNumber(42,L9);
                code.visitLabel(L0);
                code.visitConstStmt(CONST_16,5, Integer.valueOf(112)); // int: 0x00000070  float:0.000000
                code.visitConstStmt(CONST_16,4, Integer.valueOf(104)); // int: 0x00000068  float:0.000000
                code.visitConstStmt(CONST_16,3, Integer.valueOf(116)); // int: 0x00000074  float:0.000000
                code.visitLabel(L1);
                code.visitFieldStmt(IGET,1,6,new Field("Lorg/mortbay/jetty/EncodedHttpURI;","_scheme","I"));
                code.visitFieldStmt(IGET,2,6,new Field("Lorg/mortbay/jetty/EncodedHttpURI;","_authority","I"));
                code.visitJumpStmt(IF_NE,1,2,L4);
                code.visitLabel(L2);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitLabel(L3);
                code.visitStmt1R(RETURN_OBJECT,1);
                code.visitLabel(L4);
                code.visitFieldStmt(IGET,1,6,new Field("Lorg/mortbay/jetty/EncodedHttpURI;","_authority","I"));
                code.visitFieldStmt(IGET,2,6,new Field("Lorg/mortbay/jetty/EncodedHttpURI;","_scheme","I"));
                code.visitStmt3R(SUB_INT,0,1,2);
                code.visitLabel(L5);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(5)); // int: 0x00000005  float:0.000000
                code.visitJumpStmt(IF_NE,0,1,L7);
                code.visitFieldStmt(IGET_OBJECT,1,6,new Field("Lorg/mortbay/jetty/EncodedHttpURI;","_raw","[B"));
                code.visitFieldStmt(IGET,2,6,new Field("Lorg/mortbay/jetty/EncodedHttpURI;","_scheme","I"));
                code.visitStmt3R(AGET_BYTE,1,1,2);
                code.visitJumpStmt(IF_NE,1,4,L7);
                code.visitFieldStmt(IGET_OBJECT,1,6,new Field("Lorg/mortbay/jetty/EncodedHttpURI;","_raw","[B"));
                code.visitFieldStmt(IGET,2,6,new Field("Lorg/mortbay/jetty/EncodedHttpURI;","_scheme","I"));
                code.visitStmt2R1N(ADD_INT_LIT8,2,2,1);
                code.visitStmt3R(AGET_BYTE,1,1,2);
                code.visitJumpStmt(IF_NE,1,3,L7);
                code.visitFieldStmt(IGET_OBJECT,1,6,new Field("Lorg/mortbay/jetty/EncodedHttpURI;","_raw","[B"));
                code.visitFieldStmt(IGET,2,6,new Field("Lorg/mortbay/jetty/EncodedHttpURI;","_scheme","I"));
                code.visitStmt2R1N(ADD_INT_LIT8,2,2,2);
                code.visitStmt3R(AGET_BYTE,1,1,2);
                code.visitJumpStmt(IF_NE,1,3,L7);
                code.visitFieldStmt(IGET_OBJECT,1,6,new Field("Lorg/mortbay/jetty/EncodedHttpURI;","_raw","[B"));
                code.visitFieldStmt(IGET,2,6,new Field("Lorg/mortbay/jetty/EncodedHttpURI;","_scheme","I"));
                code.visitStmt2R1N(ADD_INT_LIT8,2,2,3);
                code.visitStmt3R(AGET_BYTE,1,1,2);
                code.visitJumpStmt(IF_NE,1,5,L7);
                code.visitLabel(L6);
                code.visitConstStmt(CONST_STRING,1,"http");
                code.visitJumpStmt(GOTO,-1,-1,L3);
                code.visitLabel(L7);
                code.visitConstStmt(CONST_4,1, Integer.valueOf(6)); // int: 0x00000006  float:0.000000
                code.visitJumpStmt(IF_NE,0,1,L9);
                code.visitFieldStmt(IGET_OBJECT,1,6,new Field("Lorg/mortbay/jetty/EncodedHttpURI;","_raw","[B"));
                code.visitFieldStmt(IGET,2,6,new Field("Lorg/mortbay/jetty/EncodedHttpURI;","_scheme","I"));
                code.visitStmt3R(AGET_BYTE,1,1,2);
                code.visitJumpStmt(IF_NE,1,4,L9);
                code.visitFieldStmt(IGET_OBJECT,1,6,new Field("Lorg/mortbay/jetty/EncodedHttpURI;","_raw","[B"));
                code.visitFieldStmt(IGET,2,6,new Field("Lorg/mortbay/jetty/EncodedHttpURI;","_scheme","I"));
                code.visitStmt2R1N(ADD_INT_LIT8,2,2,1);
                code.visitStmt3R(AGET_BYTE,1,1,2);
                code.visitJumpStmt(IF_NE,1,3,L9);
                code.visitFieldStmt(IGET_OBJECT,1,6,new Field("Lorg/mortbay/jetty/EncodedHttpURI;","_raw","[B"));
                code.visitFieldStmt(IGET,2,6,new Field("Lorg/mortbay/jetty/EncodedHttpURI;","_scheme","I"));
                code.visitStmt2R1N(ADD_INT_LIT8,2,2,2);
                code.visitStmt3R(AGET_BYTE,1,1,2);
                code.visitJumpStmt(IF_NE,1,3,L9);
                code.visitFieldStmt(IGET_OBJECT,1,6,new Field("Lorg/mortbay/jetty/EncodedHttpURI;","_raw","[B"));
                code.visitFieldStmt(IGET,2,6,new Field("Lorg/mortbay/jetty/EncodedHttpURI;","_scheme","I"));
                code.visitStmt2R1N(ADD_INT_LIT8,2,2,3);
                code.visitStmt3R(AGET_BYTE,1,1,2);
                code.visitJumpStmt(IF_NE,1,5,L9);
                code.visitFieldStmt(IGET_OBJECT,1,6,new Field("Lorg/mortbay/jetty/EncodedHttpURI;","_raw","[B"));
                code.visitFieldStmt(IGET,2,6,new Field("Lorg/mortbay/jetty/EncodedHttpURI;","_scheme","I"));
                code.visitStmt2R1N(ADD_INT_LIT8,2,2,4);
                code.visitStmt3R(AGET_BYTE,1,1,2);
                code.visitConstStmt(CONST_16,2, Integer.valueOf(115)); // int: 0x00000073  float:0.000000
                code.visitJumpStmt(IF_NE,1,2,L9);
                code.visitLabel(L8);
                code.visitConstStmt(CONST_STRING,1,"https");
                code.visitJumpStmt(GOTO,-1,-1,L3);
                code.visitLabel(L9);
                code.visitFieldStmt(IGET_OBJECT,1,6,new Field("Lorg/mortbay/jetty/EncodedHttpURI;","_raw","[B"));
                code.visitFieldStmt(IGET,2,6,new Field("Lorg/mortbay/jetty/EncodedHttpURI;","_scheme","I"));
                code.visitFieldStmt(IGET,3,6,new Field("Lorg/mortbay/jetty/EncodedHttpURI;","_authority","I"));
                code.visitFieldStmt(IGET,4,6,new Field("Lorg/mortbay/jetty/EncodedHttpURI;","_scheme","I"));
                code.visitStmt2R(SUB_INT_2ADDR,3,4);
                code.visitConstStmt(CONST_4,4, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                code.visitStmt2R(SUB_INT_2ADDR,3,4);
                code.visitFieldStmt(IGET_OBJECT,4,6,new Field("Lorg/mortbay/jetty/EncodedHttpURI;","_encoding","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 1,2,3,4},new Method("Lorg/mortbay/util/StringUtil;","toString",new String[]{ "[B","I","I","Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitJumpStmt(GOTO,-1,-1,L3);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m014_hasQuery(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/EncodedHttpURI;","hasQuery",new String[]{ },"Z"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(3);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(110,L0);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET,0,2,new Field("Lorg/mortbay/jetty/EncodedHttpURI;","_fragment","I"));
                code.visitFieldStmt(IGET,1,2,new Field("Lorg/mortbay/jetty/EncodedHttpURI;","_query","I"));
                DexLabel L1=new DexLabel();
                code.visitJumpStmt(IF_LE,0,1,L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(1)); // int: 0x00000001  float:0.000000
                DexLabel L2=new DexLabel();
                code.visitLabel(L2);
                code.visitStmt1R(RETURN,0);
                code.visitLabel(L1);
                code.visitConstStmt(CONST_4,0, Integer.valueOf(0)); // int: 0x00000000  float:0.000000
                code.visitJumpStmt(GOTO,-1,-1,L2);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m015_toString(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/EncodedHttpURI;","toString",new String[]{ },"Ljava/lang/String;"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(5);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(140,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(141,L1);
                DexLabel L2=new DexLabel();
                ddv.visitLineNumber(142,L2);
                code.visitLabel(L0);
                code.visitFieldStmt(IGET_OBJECT,0,4,new Field("Lorg/mortbay/jetty/EncodedHttpURI;","_rawString","Ljava/lang/String;"));
                code.visitJumpStmt(IF_NEZ,0,-1,L2);
                code.visitLabel(L1);
                code.visitFieldStmt(IGET_OBJECT,0,4,new Field("Lorg/mortbay/jetty/EncodedHttpURI;","_raw","[B"));
                code.visitFieldStmt(IGET,1,4,new Field("Lorg/mortbay/jetty/EncodedHttpURI;","_scheme","I"));
                code.visitFieldStmt(IGET,2,4,new Field("Lorg/mortbay/jetty/EncodedHttpURI;","_end","I"));
                code.visitFieldStmt(IGET,3,4,new Field("Lorg/mortbay/jetty/EncodedHttpURI;","_scheme","I"));
                code.visitStmt2R(SUB_INT_2ADDR,2,3);
                code.visitFieldStmt(IGET_OBJECT,3,4,new Field("Lorg/mortbay/jetty/EncodedHttpURI;","_encoding","Ljava/lang/String;"));
                code.visitMethodStmt(INVOKE_STATIC,new int[]{ 0,1,2,3},new Method("Lorg/mortbay/util/StringUtil;","toString",new String[]{ "[B","I","I","Ljava/lang/String;"},"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitFieldStmt(IPUT_OBJECT,0,4,new Field("Lorg/mortbay/jetty/EncodedHttpURI;","_rawString","Ljava/lang/String;"));
                code.visitLabel(L2);
                code.visitFieldStmt(IGET_OBJECT,0,4,new Field("Lorg/mortbay/jetty/EncodedHttpURI;","_rawString","Ljava/lang/String;"));
                code.visitStmt1R(RETURN_OBJECT,0);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
    public static void m016_writeTo(DexClassVisitor cv) {
        DexMethodVisitor mv=cv.visitMethod(ACC_PUBLIC, new Method("Lorg/mortbay/jetty/EncodedHttpURI;","writeTo",new String[]{ "Lorg/mortbay/util/Utf8StringBuffer;"},"V"));
        if(mv != null) {
            DexCodeVisitor code=mv.visitCode();
            if(code != null) {
                code.visitRegister(4);
                DexDebugVisitor ddv=new DexDebugVisitor(code.visitDebug());
                ddv.visitParameterName(0,"buf");
                DexLabel L0=new DexLabel();
                ddv.visitPrologue(L0);
                ddv.visitLineNumber(147,L0);
                DexLabel L1=new DexLabel();
                ddv.visitLineNumber(148,L1);
                code.visitLabel(L0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 3},new Method("Lorg/mortbay/util/Utf8StringBuffer;","getStringBuffer",new String[]{ },"Ljava/lang/StringBuffer;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,0);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 2},new Method("Lorg/mortbay/jetty/EncodedHttpURI;","toString",new String[]{ },"Ljava/lang/String;"));
                code.visitStmt1R(MOVE_RESULT_OBJECT,1);
                code.visitMethodStmt(INVOKE_VIRTUAL,new int[]{ 0,1},new Method("Ljava/lang/StringBuffer;","append",new String[]{ "Ljava/lang/String;"},"Ljava/lang/StringBuffer;"));
                code.visitLabel(L1);
                code.visitStmt0R(RETURN_VOID);
                code.visitEnd();
            }
            mv.visitEnd();
        }
    }
}
